#include <stdio.h>
#include <stdint.h>

int main()
{
    int32_t a = 0, b = 0, c = 0, sum = 0, d1 = 0, d2 = 0, d3 = 0,  d4;
    int32_t  x = 0, y = 0, z = 0;
    
    
    printf("Please enter the first operand  :");
    scanf("%dx%d",&a, &b);
    
    printf("Please enter the second operand :");
    scanf(" y%dz", &c);
    if(a > 9 | a < 0 | b > 9 | b < 0 | c > 9 | c < 0){
        printf("ERROR : invalid input.");
        return 0;
    }
    printf("Please enter the sum            :");
    scanf("%d",&sum);
    
    if(sum < 0 | sum % 1 > 0 ){
        printf("ERROR : invalid input.");
        return 0;
    }
    
    d1 = sum / 1000;
    d2 =(sum % 1000) / 100;
    d3 = (sum % 100) / 10;
    d4 = sum % 10 ;
    if(b > d4){
        d4 = d4 + 10;
        d3 = d3 - 1;
    }
    if(c > d3){
        d3 = d3 + 10;
        d2 = d2 - 1;
    }
    if(a > d2){
        d2 = d2 + 10;
        d1 = d1 - 1;
    }
    x = d3 - c;
    y = d2 - a;
    z = d4 - b;
    
    if((a * 100 + x * 10 + b + y * 100 + c * 10 + z) != sum){
        printf("ERROR : invalid input.");
        return 0;
    }
    
    printf("Ans: x = %d, y = %d, z = %d", x, y, z);
    
    return 0;
}