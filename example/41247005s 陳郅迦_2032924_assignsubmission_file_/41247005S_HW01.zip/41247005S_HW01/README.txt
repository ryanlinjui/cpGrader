41247005S 陳郅迦

-How I build my code?
hw0101 : Use ANCI escape characters and choose the correct color code to change the color of each part of the lyrics
hw0102 : I used if and arithmetic and decimal concepts to construct this program.
hw0103 : Use arithmetic and if to process the input number in segments, then output them in sequence and combine them into an 8-bit number to complete the conversion and flip.
hw0104 : I used a lot of if and else if statements to determine the hand entered, and report errors when the input is invalid.
hw0105 : Use overflow and variable conversion to output signed and unsigned integers. When you need to output a floating number, use the inputs converted to binary to achieve the purpose.
hw0106 : Add "-" before compiling.

-How to execute my program?
hw0101:Compile with GCC and you can see the result of execution.
hw0102:Compile with GCC, and then enter the number or something according to the topic.
hw0103:Compile with GCC, and then enter the number or something according to the topic.
hw0104:Compile with GCC, and then enter the number or something according to the topic.
hw0105:Compile with GCC, and then enter the number or something according to the topic.
hw0106:You can see the results in hw0106.pdf.

