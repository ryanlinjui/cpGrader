#include <stdio.h>
#include <stdint.h>
int main()
{
    uint16_t num_bef = 0, digit1 = 0, digit2 = 0, digit3 = 0, digit4 = 0, digit5 = 0, digit6 = 0;
    printf("Please enter an unsigned 16-bits number:");
    scanf("%hu", &num_bef);
    printf("Before flip:\n");
    printf("%hu_10 = ",num_bef);
    printf("%o_8\n",num_bef);
    printf("After flip:\n");
    if(num_bef >= 32768){
        digit1 = num_bef / 32768;
        digit2 = (num_bef % 32768) / 4096;
        digit3 = (num_bef % 4096) / 512;
        digit4 = (num_bef % 512) / 64;
        digit5 = (num_bef % 64) / 8;
        digit6 = num_bef % 8;
        printf("%hu%hu%hu%hu%hu%hu_8 = ", digit6, digit5, digit4, digit3, digit2, digit1);
        printf("%hu_10",digit6*32768 + digit5*4096 + digit4*512 + digit3*64 + digit2*8 + digit1);
    }else if(num_bef >= 4096 & num_bef < 32768){
        digit2 = num_bef / 4096;
        digit3 = (num_bef % 4096) / 512;
        digit4 = (num_bef % 512) / 64;
        digit5 = (num_bef % 64) / 8;
        digit6 = num_bef % 8;
        printf("%hu%hu%hu%hu%hu_8 = ", digit6, digit5, digit4, digit3, digit2);
        printf("%hu_10",digit6*4096 + digit5*512 + digit4*64 + digit3*8 + digit2);
    }else if(num_bef >= 512 & num_bef < 4096){
        digit3 = num_bef / 512;
        digit4 = (num_bef % 512) / 64;
        digit5 = (num_bef % 64) / 8;
        digit6 = num_bef % 8;
        printf("%hu%hu%hu%hu_8 = ", digit6, digit5, digit4, digit3);
        printf("%hu_10",digit6*512 + digit5*64 + digit4*8 + digit3);
    }else if(num_bef >= 64 & num_bef < 512){
        digit4 = (num_bef % 512) / 64;
        digit5 = (num_bef % 64) / 8;
        digit6 = num_bef % 8;
        printf("%hu%hu%hu_8 = ", digit6, digit5, digit4);
        printf("%hu_10",digit6*64 + digit5*8 + digit4);
    }else if(num_bef >= 8 & num_bef < 64){
        digit5 = num_bef / 8;
        digit6 = num_bef % 8;
        printf("%hu%hu_8 = ", digit6, digit5);
        printf("%hu_10",digit6*8 + digit5);
    }else if(num_bef >= 1 & num_bef < 8){
        digit6 = num_bef % 8;
        printf("%hu_8 = ", digit6);
        printf("%hu_10",digit6);
    }else if ( num_bef == 0){
        printf("0_8 = 0_10");
    }
    return 0;
}
