#include <stdio.h>
#include <stdint.h>

int main()
{
    
    printf("\x1B[1;31m""[KIM]\nYou are sunlight and I moon\nJoined by the gods of fortune\nMidnight and high noon sharing the sky\nWe have been blessed , you and I\n");
    printf("\x1B[1;34m""\n[CHRIS]\nYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\n");
    printf("\x1B[1;31m""\n[KIM]\nOutside day starts to dawn\n");
    printf("\x1B[1;34m""\n[CHRIS]\nYour moon still floats on high\n");
    printf("\x1B[1;31m""\n[KIM]\nThe birds awake\n");
    printf("\x1B[1;34m""\n[CHRIS]\nThe stars shine too\n");
    printf("\x1B[1;31m""\n[KIM]\nMy hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n\nYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho’s Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n");
    printf("\x1B[1;34m""\n[CHRIS]\nI reach for you\n");
    printf("\x1B[1;32m""\n[KIM & CHRIS]\nAnd we meet in the sky\n");
    printf("\x1B[1;31m""\n[KIM]\nYou are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n");
    printf("\x1B[1;32m""\n[KIM & CHRIS]\nMade of\nSunlight\nMoonlight\n");
    
    return 0;
}
