#include <stdio.h>
#include <stdint.h>
int main()
{
    int32_t h1 = 505, h2 = 505, h3 = 505, h4 = 505, h5 = 505;
    int32_t color1 = 0, color2 = 0, color3 = 0, color4 = 0, color5 = 0; 
    
    printf("Please enter 5 cards:");
    scanf("%d %d %d %d %d", &h1, &h2, &h3, &h4, &h5);
    
    if(h1 == 505 || h2 == 505 || h3 == 505 || h4 == 505 || h5 == 505){
        printf("ERROR : Invalid inputs.\n");
        return 0;
    }
    if(h1 <= 0 || h1 > 52 || h2 <= 0 || h2 > 52|| h3 <= 0 || h3 > 52 || h4 <= 0 || h4 > 52 || h5 <= 0 || h5 > 52){
        printf("ERROR : The entered hand is out of range.\n");
        return 0;
    }
    if(h1 == h2 || h1 == h3 || h1 == h4 || h1 == h5 || h2 == h3 || h2 == h4 || h2 == h5 || h3 == h4 || h3 == h5 || h4 == h5){
        printf("ERROR : The same hand cannot appear twice.\n");
        return 0;
    }
    //color & point converter
    if(h1 >= 1 && h1 <= 13){ color1 = 1;}
    else if(h1 >= 14 && h1 <= 26){ color1 = 2; h1 = h1 - 13;}
    else if(h1 >= 27 && h1 <= 39){ color1 = 3; h1 = h1 - 26;}
    else if(h1 >= 40 && h1 <= 52){ color1 = 4; h1 = h1 - 39;}
    
    if(h2 >= 1 && h2 <= 13){ color2 = 1;}
    else if(h2 >= 14 && h2 <= 26){ color2 = 2; h2 = h2 - 13;}
    else if(h2 >= 27 && h2 <= 39){ color2 = 3; h2 = h2 - 26;}
    else if(h2 >= 40 && h2 <= 52){ color2 = 4; h2 = h2 - 39;}
    
    if(h3 >= 1 && h3 <= 13){ color3 = 1;}
    else if(h3 >= 14 && h3 <= 26){ color3 = 2; h3 = h3 - 13;}
    else if(h3 >= 27 && h3 <= 39){ color3 = 3; h3 = h3 - 26;}
    else if(h3 >= 40 && h3 <= 52){ color3 = 4; h3 = h3 - 39;}
    
    if(h4 >= 1 && h4 <= 13){ color4 = 1;}
    else if(h4 >= 14 && h4 <= 26){ color4 = 2; h4 = h4 - 13;}
    else if(h4 >= 27 && h4 <= 39){ color4 = 3; h4 = h4 - 26;}
    else if(h4 >= 40 && h4 <= 52){ color4 = 4; h4 = h4 - 39;}
    
    if(h5 >= 1 && h5 <= 13){ color5 = 1;}
    else if(h5 >= 14 && h5 <= 26){ color5 = 2; h5 = h5 - 13;}
    else if(h5 >= 27 && h5 <= 39){ color5 = 3; h5 = h5 - 26;}
    else if(h5 >= 40 && h5 <= 52){ color5 = 4; h5 = h5 - 39;} 
    // sorter
    if(h1 > h2) { int temp = h1; h1 = h2; h2 = temp; }
    if(h1 > h3) { int temp = h1; h1 = h3; h3 = temp; }
    if(h1 > h4) { int temp = h1; h1 = h4; h4 = temp; }
    if(h1 > h5) { int temp = h1; h1 = h5; h5 = temp; }
    
    if(h2 > h3) { int temp = h2; h2 = h3; h3 = temp; }
    if(h2 > h4) { int temp = h2; h2 = h4; h4 = temp; }
    if(h2 > h5) { int temp = h2; h2 = h5; h5 = temp; }

    if(h3 > h4) { int temp = h3; h3 = h4; h4 = temp; }
    if(h3 > h5) { int temp = h3; h3 = h5; h5 = temp; }

    if(h4 > h5) { int temp = h4; h4 = h5; h5 = temp; }

    //printf("%d %d %d %d %d\n",h1,h2,h3,h4,h5);
    //printf("%d %d %d %d %d\n",color1,color2,color3,color4,color5);
   
    if(color1 == color2 && color2 == color3 && color3 == color4 && color4 == color5 && ((h5 - h4) == (h4 - h3) == (h3 - h2) == (h2 - h1) == 1) || (h1 == 1 && h2 == 10 && h3 == 11 && h4 == 12 && h5 == 13)){
    	printf("Straight Flush\n");
        return 0;
    }else if((h1 == h2 && h1 == h3 && h1 == h4) || (h2 == h3 && h2 == h4 && h2 == h5)){
        printf("Four of a Kind\n");
        return 0;
    }else if((h1 == h2 && h2 == h3 && h4 == h5) || (h1 == h2 && h3 == h4 && h4 == h5)){
        printf("Full House\n");
        return 0;
    }else if(color1 == color2 && color2 == color3 && color3 == color4 && color4 == color5){
        printf("Flush\n");
        return 0;
    }else if((h5 - h4) ==  1 && (h4 - h3) == 1 && (h3 - h2) == 1 && (h2 - h1) == 1){
        printf("Straight\n");
        return 0;
    }else if((h1 == h2 && h2 == h3) || (h2 == h3 && h3 == h4) ||(h3 == h4 && h4 == h5)){
        printf("Three of a Kind\n");
        return 0;
    }else if((h1 == h2 && h3 == h4) || (h1 == h2 && h4 == h5) || (h2 == h3 && h4 == h5)){
        printf("Two Pair\n");
        return 0;
    }else if(h1 == h2 || h2 == h3 || h3 == h4 || h4 == h5){
        printf("One Pair\n");
        return 0;
    }else{
        printf("High Card\n");
        return 0;
    }
    return 0;
}


 
    
    
