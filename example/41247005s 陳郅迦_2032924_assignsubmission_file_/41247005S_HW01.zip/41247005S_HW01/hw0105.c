#include <stdio.h>
#include <stdint.h>

int main()
{
    uint16_t var = 13163;
    int32_t mode = 2529346103, expo = 0;
    double frac = 0.0; 
    char sign = 0;
    
    printf("Please input a hex:");
    scanf("%hX", &var);
    if(var == 13163){
        printf("ERROR: Invalid input.\n");
        return 0;
    }
    
    printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
    scanf("%d", &mode);
    
    if(mode == 2529346103 || mode < 1 || mode > 3 || mode % 1 > 0){
        printf("ERROR: Invalid input.\n");
        return 0;
    }
    int32_t d1 = var / 32768, d2 =  var % 32768 / 16384, d3 = var % 16384 / 8192,
    d4 = var % 8192 / 4096, d5 = var % 4096 / 2048, d6 = var % 2048 / 1024, 
    d7 = var % 1024 / 512, d8 = var % 512 / 256, d9 = var % 256 / 128, d10 = var % 128 / 64,
    d11 = var % 64 / 32, d12 = var % 32 / 16, d13 = var % 16 / 8, d14 = var % 8 / 4, d15 = var % 4 / 2, d16 = var % 2 / 1;
    
    printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",var, d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14, d15, d16);
    
    switch(mode){
        case 1:
        printf("Converted integer is: %d\n", (int16_t)var);
        break;
        case 2:
        printf("Converted unsigned integer is: %u\n", var);
        break;
        case 3:
        if(d1 == 1){
            sign = 45;
        }else{
            sign = 32;
        }
        expo = 16*d2 + 8*d3 + 4*d4 + 2*d5 + 1*d6;
        frac = 0.5*d7 + 0.25*d8 + 0.125*d9 + 0.0625*d10 + 0.03125*d11 + 0.015625*d12 + 0.0078125*d13 + 0.00390625*d14 + 0.00195312*d15 + 0.00097656*d16;
        
        if(d1 = 0 && expo == 0 && frac == 0){
            printf("Converted float is: +0.0\n");
            return 0;
        }else if(d1 = 1 && expo == 0 && frac == 0){
            printf("Converted float is: -0.0\n");
            return 0;
        }else if(d1 = 0 && expo == 31 && frac == 0){
            printf("Converted float is: +INF\n");
            return 0;
        }else if(d1 = 1 && expo == 31 && frac == 0){
            printf("Converted float is: -INF\n");
            return 0;
        }else if(expo == 31 && frac != 0){
            printf("Converted float is: NAN\n");
            return 0;
        }
        printf("Converted float is:%c%lf*2^%d\n",sign, frac + 1, expo - 15);
        break;
        default:
        printf("ERROR: invalid input.\n");
        break;
    }   
    return 0;
}