#include <stdio.h>


int main()
{
    printf("\033[31m%s\n","[KIM]\n" 
    "You are sunlight and I moon \n"
    "Joined by the gods of fortune \n"
    "Midnight and high noon sharing the sky \n"
    "We have been blessed , you and I\n");//red

    printf("\033[34m%s\n", "[CHRIS]\n"
    "You are here like a mystery\n"
    "I'm from a world that's so different from all that you are\n"
    "How in the light of one night did we come so far?\n"); //blue

    printf("\033[31m%s\n","[KIM]\n"
    "Outside day starts to dawn\n"); //red

    printf("\033[34m%s\n", "[CHRIS]\n"
    "Your moon still floats on high"); //blue

    printf("\033[31m%s\n","[KIM]\n"
    "The birds awake\n"); //red

    printf("\033[34m%s\n", "[CHRIS]\n"
    "The stars shine too\n"); //blue

    printf("\033[31m%s\n","[KIM]\n"
    "My hands still shake\n"
    "See upcoming pop shows\n"
    "Get tickets for your favorite artists\n"
    "You might also like\n"
    "My Boy Only Breaks His Favorite Toys\n"
    "Taylor Swift\n"
    "Who’s Afraid of Little Old Me?\n"
    "Taylor Swift\n"
    "Guilty as Sin?\n"
    "Taylor Swift\n"); //red

    printf("\033[34m%s\n", "[CHRIS]\n"
    "I reach for you\n"); //blue

    printf("\033[32m%s", "[KIM & CHRIS]\n"
    "And we meet in the sky\n");//green

    printf("\033[31m%s\n","[KIM]\n"
    "You are sunlight and I moon\n"
    "Joined here\n"
    "Brightening the sky with the flame of love\n");//red

    printf("\033[32m%s\n","[KIM & CHRIS]\n"
    "Made of\n"
    "Sunlight\n"
    "Moonlight\n");


    return(0);
}
