Name        : Felice Irlyn (曾)
Student Id  : 41347052S

How to build my code:
hw0101 --> To make the text red i use this code "\033[31m%s", blue text "\033[34m%s", green text "\033[32m%s".

hw0102 --> i use "if(a>9 || a<0 || b>9 || b<0)" so that the input value can't exceed 9, ex: input 12x3 then "error.Please  try again" will appear.
i use %10, /10 and /100 to divide the sum into several variables.

hw0103 --> to find before flip %u_8 i use % 8 . ex: octal += (the value you enter % 8).
flipped_n = flipped_n*10 + flip is to buils the flipped version of number, using base 10.
flipped_o += (temp % 10)*place is to converts the flipped number into octal format

hw0104 --> i use if ,else if and else.
i compare the rank of the cards.

hw0105 --> in use if, else, and switch.
i use %X to print out the input
use if and else to find the binary
to find signed integer i use int16_t
to find unsigned integer in here i use %u for unsigned
