#include<stdio.h>
#include<stdint.h>
int main()
{

    int32_t hex=0,s1=0,s2=0,t1=0,t2=0,t3=0,t4=0,t5=0,t6=0,t7=0,t8=0,t9=0,t10=0,t11=0,t12=0,t13=0,t14=0,t15=0,t16=0;
    int32_t  f;
    float f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,f14,f15,f16,s3,exp;

    printf("Please input a hex:");
    if(scanf("%x",&hex)==0)printf("error\n");
    else {
    printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
    scanf("%d",&s2);
    if(s2>3||s2<0)printf("error");
    else{
    s1=hex;
    //Convert decimal to binary
    t1=hex%65536/32768;
    t2=hex%32768/16384;
    t3=hex%16384/8192;
    t4=hex%8192/4096;
    t5=hex%4096/2048;
    t6=hex%2048/1024;
    t7=hex%1024/512;
    t8=hex%512/256;
    t9=hex%256/128;
    t10=hex%128/64;
    t11=hex%64/32;
    t12=hex%32/16;
    t13=hex%16/8;
    t14=hex%8/4;
    t15=hex%4/2;
    t16=hex%2;
    f1=t1;f2=t2;f3=t3;f4=t4;f5=t5;f6=t6;f7=t7;f8=t8;f9=t9;f10=t10;f11=t11;f12=t12;f13=t13;f14=t14;f15=t15;f16=t16;
    printf("Binary of %X is:%d%d%d%d  %d%d%d%d  %d%d%d%d  %d%d%d%d\n",hex,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);
    f=hex;
        f7=f7/2;
        f8=f8/4;
        f9=f9/8;
        f10=f10/16;
        f11=f11/32;
        f12=f12/64;
        f13=f13/128;
        f14=f14/256;
        f15=f15/512;
        f16=f16/1024;
        s3=1+f7+f8+f9+f10+f11+f12+f13+f14+f15+f16;
        f=s3;
        exp=f2*16+f3*8+f4*4+f5*2+f6;
        
    if(s2==1)printf("Converted integer is :%hd\n",hex);
    if(s2==2)printf("Converted unsighed integer is :%hu\n",hex);
    if(s2==3)
    {
    float EXP;
    if(t1==0&&exp==0&&s3==1)printf("Converted float is: +0.0\n");
    else if(t1==1&&exp==0&&s3==1)printf("Converted float is: -0.0\n");
    else if(t1==0&&exp==31&&s3==1)printf("Converted float is: +INF\n");
    else if(t1==1&&exp==31&&s3==1)printf("Converted float is: -INF\n");
    else if(exp==31&&s3!=1)printf("NAN\n");
    else if(t1==1)
    {
        exp=exp-15;
        printf("Converted float is: -%f*2^%.f\n",s3,exp);
    }
    else
     {
        exp=exp-15;
        printf("Converted float is: %f*2^%.f\n",s3,exp);
     }
    }
    }
    }
}
    