#include<stdio.h>
#include<stdint.h>
int main()
{
    int32_t a=-1,b=-1,c=-1,x=-1,y=-1,z=-1,sum=-1;
    printf("Please enter the first operand :");
    scanf("%dx%d",&a,&b);
    printf("Please enter the secend operand:");
    scanf (" y%dz",&c);
    printf("Please enter the sum           :");
    scanf(" %d",&sum);
    if(a<0||b<0||c<0)printf("error\n");
    else if(a*100+c*10+b>sum||a>=10||b>=10||c>=10||a*100+c*10+b+999<sum)printf("error\n");
    else 
    {   if(sum/100!=0)
        {
            if(sum%10>=b)
            {
                z=(sum%10)-b;
            }
            else 
            {
                z=(sum%10)-b+10;
            }
            if(z+b<10)
            {
                if(sum%100/10>=c)x=sum%100/10-c;
                else x=(sum%100/10)-c+10;
            }
            else
            {
                if(sum%100/10-1>=c)x=(sum%100/10)-1-c;
                else x=(sum%100/10)-c+9;
            }
            if(x+c<10)
            {
                if(sum/100>=a)y=(sum/100)-a;
                else y=(sum/100)-c+10;
            }
            else 
            {
                if(sum/100-1>=a)y=(sum/100)-1-a;
                else y=(sum/10)-c+9;
            }
        }
        else
        {
            if(sum%10>=b)z=(sum%10)-b;
            else z=b-(sum%10)+10;
            if(sum%10+b<=10)
            {
                if(sum%100/10>=c)x=(sum%100/10)-c;
                else x=(sum%100/10)-c+10;
            }
            else
            {
                if(sum%100/10-1>=c)x=(sum%100/10)-1-c;
                else x=(sum%100/10)-c+9;
            }
            if(sum%100/10+c<10)y=(sum/100)-a;
            else y=(sum/100)-a; 
        }
        printf("Ans: x = %d, y = %d, z = %d\n",x,y,z);
    }
}