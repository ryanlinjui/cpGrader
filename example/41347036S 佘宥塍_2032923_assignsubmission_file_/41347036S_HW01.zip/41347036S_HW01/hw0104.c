#include<stdio.h>
#include<stdint.h>
int main()
{
    int32_t c1=0,c2=0,c3=0,c4=0,c5=0,y1=0,y2=0,y3=0,y4=0,y5=0,s1=0,s2=0,s3=0,s4=0,s5=0,n1=0,n2=0,n3=0,n4=0,n5=0,ky1=0,kn1=0,kn2=0,kn3=0,kn4=0,kn5=0;
    printf("Please enter 5 cards:");
    if(scanf("%d %d %d %d %d",&c1,&c2,&c3,&c4,&c5)==0)printf("error\n");
    else if(c1==c2||c1==c3||c1==c4||c1==c5||c2==c3||c2==c4||c2==c5||c3==c4||c3==c5||c4==c5||c1<1||c1>52||c2<1||c2>52||c3<1||c3>52||c3<1||c4>52||c5<1||c5>52)printf("error\n");
    else{
//card color
    y1=(c1-1)/13;
    y2=(c2-1)/13;
    y3=(c3-1)/13;
    y4=(c4-1)/13;
    y5=(c5-1)/13;
//card number
    s1=((c1-1)%13)+1;
    s2=(c2-1)%13+1;
    s3=((c3-1)%13)+1;
    s4=((c4-1)%13)+1;
    s5=((c5-1)%13)+1;
//card number sort
    n1=s1;
    if(s2>=n1)
    {
        n2=n1;
        n1=s2;
    }
    else n2=s2;
    if(s3>=n1)
    {
        n3=n2;
        n2=n1;
        n1=s3;
    }
    else if(s3>=n2)
    {
        n3=n2;
        n2=s3;
    }
    else n3=s3;
    if(s4>=n1)
    {
        n4=n3;
        n3=n2;
        n2=n1;
        n1=s4;
    }
    else if(s4>=n2)
    {
        n4=n3;
        n3=n2;
        n2=s4;
    }
    else if(s4>=n3)
    {
        n4=n3;
        n3=s4;
    }
    else n4=s4;
    if(s5>=n1)
    {
        n5=n4;
        n4=n3;
        n3=n2;
        n2=n1;
        n1=s5;
    }
    else if(s5>=n2)
    {
        n5=n4;
        n4=n3;
        n3=n2;
        n2=s5;
    }
    else if(s5>=n3)
    {
        n5=n4;
        n4=n3;
        n3=s5;
    }
    else if(s5>=n4)
    {
        n5=n4;
        n4=s5;
    }
    else n5=s5;
//classify card type
//flash
if(y1==y2&&y1==y3&&y1==y4&&y1==y5)ky1=2;
// straight
if(n1==5&&n2==4&&n3==3&&n4==2&&n5==1||n1==6&&n2==5&&n3==4&&n4==3&&n5==2
||n1==7&&n2==6&&n3==5&&n4==4&&n5==3||n1==8&&n2==7&&n3==6&&n4==5&&n5==4
||n1==9&&n2==8&&n3==7&&n4==6&&n5==5||n1==10&&n2==9&&n3==8&&n4==7&&n5==6
||n1==11&&n2==10&&n3==9&&n4==8&&n5==7||n1==12&&n2==11&&n3==10&&n4==9&&n5==8
||n1==13&&n2==12&&n3==11&&n4==10&&n5==9||n1==13&&n2==12&&n3==11&&n4==10&&n5==1)kn1=2;
//four of the kind
if(n1==n2&&n1==n3&&n1==n4||n1==n2&&n1==n3&&n1==n5||n1==n2&&n1==n5&&n1==n4||n1==n5&&n1==n3&&n1==n4||n2==n3&&n2==n4&&n2==n5)kn2=2;
//three of the kind
if(n1==n2&&n1==n3||n3==n4&&n4==n5)kn3=2;
//two pair
if(n1==n2&&n3==n4||n1==n2&&n4==n5||n2==n3&&n4==n5)kn4=2;
//pair
if(n1==n2||n2==n3||n3==n4||n4==n5)kn5=2;
if(kn1==2&&ky1==2)printf("Straight Flush\n");
else if(kn2==2)printf("Four Of A Kind\n");
else if(kn3==2&&kn4==2)printf("Full House\n");
else if(ky1==2)printf("Flush\n");
else if(kn1==2)printf("Straight\n");
else if(kn3==2)printf("Three Of A Kind\n");
else if(kn4==2)printf("Two Pair\n");
else if(kn5==2)printf("One Pair\n");
else printf("High Card\n");
    }
    return 0;
}