#include<stdio.h>
#include<stdint.h>
int main()
{
    uint16_t num=-1,g=-1,f=-1,e=-1,d=-1,c=-1,b=-1,a=-1,ans=-1;
    uint32_t test=0;
    printf("Please enter an unsigned 16-bits number:");
    if(scanf("%hd",&num)==0)printf("error\n");
    else {
    a=num%(8*8*8*8*8*8)/(8*8*8*8*8);
    b=num%(8*8*8*8*8)/(8*8*8*8);
    c=num%(8*8*8*8)/(8*8*8);
    d=num%(8*8*8)/(8*8);
    e=num%(8*8)/8;
    f=num%8;
    printf("Before Flip:\n%d_10 = ",num);
    if(a!=0) printf("%d%d%d%d%d%d_8\n",a,b,c,d,e,f);
    else if(a==0&&b==0&&c==0&&d==0&&e==0) printf("%d_8\n",f);
    else if(a==0&&b==0&&c==0&&d==0) printf("%d%d_8\n",e,f);
    else if(a==0&&b==0&&c==0) printf("%d%d%d_8\n",d,e,f);
    else if(a==0&&b==0) printf("%d%d%d%d_8\n",c,d,e,f);
    else if(a==0) printf("%d%d%d%d%d_8\n",b,c,d,e,f);
    printf("After Flip:\n");

    test=f*100000+e*10000+d*1000+c*100+b*10+a;

    if(test%1000000==0) printf("%d_8 = ",test/1000000);
    else if(test%100000==0) printf("%d_8 = ",test/100000);
    else if(test%10000==0) printf("%d_8 = ",test/10000);
    else if(test%1000==0) printf("%d_8 = ",test/1000);
    else if(test%100==0) printf("%d_8 = ",test/100);
    else if(test%10==0) printf("%d_8 = ",test/10);
    else printf("%d_8 = ",test);

    if(a!=0) ans=f*(8*8*8*8*8)+e*(8*8*8*8)+d*(8*8*8)+c*(8*8)+b*8+a;
    else if(a==0&&b==0&&c==0&&d==0&&e==0) ans=f;
    else if(a==0&&b==0&&c==0&&d==0) ans=f*8+e;
    else if(a==0&&b==0&&c==0) ans=f*(8*8)+e*8+d;
    else if(a==0&&b==0) ans=f*(8*8*8)+e*(8*8)+d*8+c;
    else if(a==0) ans=f*(8*8*8*8)+e*(8*8*8)+d*(8*8)+c*8+b;
    printf("%d_10\n",ans);
    return 0;
    }
    }
