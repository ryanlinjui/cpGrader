#include <stdio.h>
#include <stdint.h>

int main() {
    int32_t fst1 = 0, fst2 = 0;
    int32_t sec = 0;
    int32_t sum = 0;
    int32_t tri = 0, squ = 0, cir = 0;
    
    printf("Please enter the first  operand: ");
    scanf(" %dx%d", &fst1, &fst2);
    fflush(stdin);
    printf("Please enter the second operand: ");
    scanf(" y%dz", &sec);
    fflush(stdin);
    printf("Please enter the sum           : ");
    scanf(" %d", &sum);
    fflush(stdin);    
       
    if((fst1 < 10 && fst1 > 0) && (fst2 < 10 && fst2 >= 0) && (sec < 10 && sec >= 0)) {
        cir = (sum - fst2) % 10;
        tri = ((sum - (sec*10 + cir + fst2)) / 10) % 10;
        squ = (sum - (100*fst1 + 10*tri + fst2) - (10*sec + cir)) / 100;
        
        printf("x = %d, y = %d, z = %d\n", tri, squ, cir);

    }
    
    else {
        printf("error\n");
    }
        
    return 0;
}
