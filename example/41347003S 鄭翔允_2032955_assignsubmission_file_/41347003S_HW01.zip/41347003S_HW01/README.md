41347003s 鄭翔允

1. How to build my codes?

    Makefile by using command "make".


2. How to execute the built programs?

	-hw0101
	
		(1)Run the "hwXXYY" file after using Makefile.

	
	-hw0102

		(1). Run the "hwXXYY" file after using Makefile.
		
		(2). Enter the first operand in format "INTxINT".

		(3). Enter the second operand in format "yINTz".

		(4). Enter the value of sum.


	-hw0103

		(1). Run the "hwXXYY" file after using Makefile.

		(2). Enter a unsigned 16-bits decimal number.


	-hw0104

		(1). Run the "hwXXYY" file after using Makefile.

		(2). Enter five numbers which are in the range [1, 52] in format "int int int int int".


	-hw0105

		(1). Run the "hwXXYY" file after using Makefile.

		(2). Enter a 16-bits hexadecimal number.

		(3). Choose an output type (1:signed integer, 2:unsigned integer, 3:float).


    -Bonus: Makefile for Multiple files (hw0106)
    
        It is a PDF file.
