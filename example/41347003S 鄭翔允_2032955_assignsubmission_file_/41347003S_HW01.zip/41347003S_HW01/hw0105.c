#include <stdio.h>
#include <stdint.h>

int main() {
    int32_t input = 0;
    int16_t input_1 = 0;
    uint16_t input_2 = 0;
    uint16_t choice = 0;
    int16_t b_1 = 0, b_2 = 0, b_3 = 0, b_4 = 0, b_5 = 0, b_6 = 0, b_7 = 0, b_8 = 0;
    int16_t b_9 = 0, b_10 = 0, b_11 = 0, b_12 = 0, b_13 = 0, b_14 = 0, b_15 = 0, b_16 = 0;
    int32_t outType = 0;
    
    //input
    printf("Please input a hex:");
    scanf("%x", &input);
    input_1 = input;
    input_2 = input;
    
    //output type
    printf("Please choose the output type (1:integer, 2:unsigned integer, 3:float):");
    scanf("%hu", &choice);
    
    //Process_1: Convert to binary
    
    //input = b_1 * 2^16 + b_2 * 2^15 + b_3 * 2^14 + b_4 * 2^13 + ...
    b_1 = input / (2*2*2*2 * 2*2*2*2 * 2*2*2*2 * 2*2*2);
    
    int32_t temp = input - (b_1 * (2*2*2*2 * 2*2*2*2 * 2*2*2*2 * 2*2*2));
    //temp在此 = b_2 * 2^15 + b_3 * 2^14 + b_4 * 2^13 + ...
    b_2 = temp / (2*2*2*2 * 2*2*2*2 * 2*2*2*2 * 2*2);
    
    temp = temp - (b_2 * (2*2*2*2 * 2*2*2*2 * 2*2*2*2 * 2*2));
    b_3 = temp / (2*2*2*2 * 2*2*2*2 * 2*2*2*2 * 2);
    
    temp = temp - (b_3 * (2*2*2*2 * 2*2*2*2 * 2*2*2*2 * 2));
    b_4 = temp / (2*2*2*2 * 2*2*2*2 * 2*2*2*2);
    
    temp = temp - (b_4 * (2*2*2*2 * 2*2*2*2 * 2*2*2*2));
    b_5 = temp / (2*2*2*2 * 2*2*2*2 * 2*2*2);
    
    temp = temp - (b_5 * (2*2*2*2 * 2*2*2*2 * 2*2*2));
    b_6 = temp / (2*2*2*2 * 2*2*2*2 * 2*2);
    
    temp = temp - (b_6 * (2*2*2*2 * 2*2*2*2 * 2*2));
    b_7 = temp / (2*2*2*2 * 2*2*2*2 * 2);
    
    temp = temp - (b_7 * (2*2*2*2 * 2*2*2*2 * 2));
    b_8 = temp / (2*2*2*2 * 2*2*2*2);
    
    temp = temp - (b_8 * (2*2*2*2 * 2*2*2*2));
    b_9 = temp / (2*2*2*2 * 2*2*2);
    
    temp = temp - (b_9 * (2*2*2*2 * 2*2*2));
    b_10 = temp / (2*2*2*2 * 2*2);
    
    temp = temp - (b_10 * (2*2*2*2 * 2*2));
    b_11 = temp / (2*2*2*2 * 2);
    
    temp = temp - (b_11 * (2*2*2*2 * 2));
    b_12 = temp / (2*2*2*2);
    
    temp = temp - (b_12 * (2*2*2*2));
    b_13 = temp / (2*2*2);
    
    temp = temp - (b_13 * (2*2*2));
    b_14 = temp / (2*2);
    
    temp = temp - (b_14 * (2*2));
    b_15 = temp / 2;
    
    temp = temp - (b_15 * 2);
    b_16 = temp;
    
    //Binary convertion result
    printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n", input, b_1, b_2, b_3, b_4, b_5, b_6, b_7, b_8, b_9, b_10, b_11, b_12, b_13, b_14, b_15, b_16);
    
    //Process 2: Convert to other types
    
    //other types convertion result (1.integer, 2.unsigned integer, 3.float)
    if(choice == 1) {
        //signed integer
        printf("Converted integer is: %d\n", input_1);
    }
    
    else if(choice == 2) {
        //unsigned integer
        printf("Converted unsigned integer is: %d\n", input_2);
    }
    
    else if(choice == 3) {
        //float [format: Sign(1.F) * 2^EXP-15]
        int32_t EXP = (b_2 * (2*2*2*2) + b_3 * (2*2*2) + b_4 * (2*2) + b_5 * 2 + b_6);
        
        double F = (double)b_7 / 2 + (double)b_8 / (2*2) + (double)b_9 / (2*2*2) + (double)b_10 / (2*2*2*2) + (double)b_11 / (2*2*2*2 * 2) + (double)b_12 / (2*2*2*2 * 2*2) + (double)b_13 / (2*2*2*2 * 2*2*2) + (double)b_14 / (2*2*2*2 * 2*2*2*2) + (double)b_15 / (2*2*2*2 * 2*2*2*2 * 2) + (double)b_16 / (2*2*2*2 * 2*2*2*2 * 2*2);
        
        if(EXP == 0 && F == 0) {
            if(b_1 == 0) {
                printf("Converted float is: +%.1lf\n", F);
            }
            else {
                printf("Converted float is: -%.1lf\n", F);
            }
        }
        else if(EXP >= 31 && F == 0) {
            if(b_1 == 0) {
                printf("Converted float is: +INF\n");
            }
            else {
                printf("Converted float is: -INF\n");
            }
        }
        
        else if(EXP >= 31 && F != 0) {
            printf("Converted float is: NAN\n");
        }
        
        else if(b_1 == 0) {
            printf("Converted float is: %lf*2^%d\n", 1+F, EXP - 15);
        }
        else {
            printf("Converted float is: -%lf*2^%d\n", 1+F, EXP - 15);
        }
    }
    
    else {
        printf("Error, question 2 only accept 1 or 2 or 3\n");
    }
    
    return 0;
}
