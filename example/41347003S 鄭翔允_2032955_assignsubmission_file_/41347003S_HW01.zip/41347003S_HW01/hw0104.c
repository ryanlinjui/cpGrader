#include <stdio.h>
#include <stdint.h>

int main() {
    int32_t input_1 = 0, input_2 = 0, input_3 = 0, input_4 = 0, input_5 = 0;
    int32_t card_1 = 0, card_2 = 0, card_3 = 0, card_4 = 0, card_5 = 0;
    int32_t num_1 = 0, num_2 = 0, num_3 = 0, num_4 = 0, num_5 = 0;
    int32_t suit_1 = 0, suit_2 = 0, suit_3 = 0, suit_4 = 0, suit_5 = 0;
    
    int32_t temp_a = 0, temp_b = 0; //temp_a 用於牌號交換用（排序用）；temp_b 用於牌本身交換用（隨num交換）
    
    printf("Please enter 5 cards: ");
    scanf("%d", &input_1);
    fflush(stdin);
    scanf("%d", &input_2);
    fflush(stdin);
    scanf("%d", &input_3);
    fflush(stdin);
    scanf("%d", &input_4);
    fflush(stdin);
    scanf("%d", &input_5);
    fflush(stdin);
    
    //號碼
    if(input_1 % 13 == 0) {
        num_1 = 13;
    }
    else {
        num_1 = input_1 % 13;
    }
    
    if(input_2 % 13 == 0) {
        num_2 = 13;
    }
    else {
        num_2 = input_2 % 13;
    }
    
    if(input_3 % 13 == 0) {
        num_3 = 13;
    }
    else {
        num_3 = input_3 % 13;
    }
    
    if(input_4 % 13 == 0) {
        num_4 = 13;
    }
    else {
        num_4 = input_4 % 13;
    }
    
    if(input_5 % 13 == 0) {
        num_5 = 13;
    }
    else {
        num_5 = input_5 % 13;
    }
    
    //重新排序（號碼順、由小到大）
    //第一次
    if(num_1 > num_2) {
        temp_a = num_1;
        num_1 = num_2;
        num_2 = temp_a;
        
        temp_b = input_1;
        input_1 = input_2;
        input_2 = temp_b;
    }
    
    if(num_2 > num_3) {
        temp_a = num_2;
        num_2 = num_3;
        num_3 = temp_a;
        
        temp_b = input_2;
        input_2 = input_3;
        input_3 = temp_b;
    }
        
    if(num_3 > num_4) {
        temp_a = num_3;
        num_3 = num_4;
        num_4 = temp_a;
        
        temp_b = input_3;
        input_3 = input_4;
        input_4 = temp_b;
    }
            
    if(num_4 > num_5) {
        temp_a = num_4;
        num_4 = num_5;
        num_5 = temp_a;
        
        temp_b = input_4;
        input_4 = input_5;
        input_5 = temp_b;
    }
    
    //第二次
    if(num_1 > num_2) {
        temp_a = num_1;
        num_1 = num_2;
        num_2 = temp_a;
        
        temp_b = input_1;
        input_1 = input_2;
        input_2 = temp_b;
    }
    
    if(num_2 > num_3) {
        temp_a = num_2;
        num_2 = num_3;
        num_3 = temp_a;
        
        temp_b = input_2;
        input_2 = input_3;
        input_3 = temp_b;
    }
        
    if(num_3 > num_4) {
        temp_a = num_3;
        num_3 = num_4;
        num_4 = temp_a;
        
        temp_b = input_3;
        input_3 = input_4;
        input_4 = temp_b;
    }
            
    if(num_4 > num_5) {
        temp_a = num_4;
        num_4 = num_5;
        num_5 = temp_a;
        
        temp_b = input_4;
        input_4 = input_5;
        input_5 = temp_b;
    }
    
    //第三次
    if(num_1 > num_2) {
        temp_a = num_1;
        num_1 = num_2;
        num_2 = temp_a;
        
        temp_b = input_1;
        input_1 = input_2;
        input_2 = temp_b;
    }
    
    if(num_2 > num_3) {
        temp_a = num_2;
        num_2 = num_3;
        num_3 = temp_a;
        
        temp_b = input_2;
        input_2 = input_3;
        input_3 = temp_b;
    }
        
    if(num_3 > num_4) {
        temp_a = num_3;
        num_3 = num_4;
        num_4 = temp_a;
        
        temp_b = input_3;
        input_3 = input_4;
        input_4 = temp_b;
    }
            
    if(num_4 > num_5) {
        temp_a = num_4;
        num_4 = num_5;
        num_5 = temp_a;
        
        temp_b = input_4;
        input_4 = input_5;
        input_5 = temp_b;
    }
    
    //第四次
    if(num_1 > num_2) {
        temp_a = num_1;
        num_1 = num_2;
        num_2 = temp_a;
        
        temp_b = input_1;
        input_1 = input_2;
        input_2 = temp_b;
    }
    
    if(num_2 > num_3) {
        temp_a = num_2;
        num_2 = num_3;
        num_3 = temp_a;
        
        temp_b = input_2;
        input_2 = input_3;
        input_3 = temp_b;
    }
        
    if(num_3 > num_4) {
        temp_a = num_3;
        num_3 = num_4;
        num_4 = temp_a;
        
        temp_b = input_3;
        input_3 = input_4;
        input_4 = temp_b;
    }
            
    if(num_4 > num_5) {
        temp_a = num_4;
        num_4 = num_5;
        num_5 = temp_a;
        
        temp_b = input_4;
        input_4 = input_5;
        input_5 = temp_b;
    }
    
    //排序完，重新分配
    card_1 = input_1;
    card_2 = input_2;
    card_3 = input_3;
    card_4 = input_4;
    card_5 = input_5;
    
    /*
    if(card_1 % 13 == 0) {
        num_1 = 13;
    }
    else {
        num_1 = input_1 % 13;
    }
    */
    
    if(card_2 % 13 == 0) {
        num_2 = 13;
    }
    else {
        num_2 = input_2 % 13;
    }
    
    if(card_3 % 13 == 0) {
        num_3 = 13;
    }
    else {
        num_3 = input_3 % 13;
    }
    
    if(card_4 % 13 == 0) {
        num_4 = 13;
    }
    else {
        num_4 = input_4 % 13;
    }
    
    if(card_5 % 13 == 0) {
        num_5 = 13;
    }
    else {
        num_5 = input_5 % 13;
    }
    
    //花色
    suit_1 = (card_1 - 1) / 13;
    suit_2 = (card_2 - 1) / 13;
    suit_3 = (card_3 - 1) / 13;
    suit_4 = (card_4 - 1) / 13;
    suit_5 = (card_5 - 1) / 13;
    
    //Sort the cards.
    if(card_1 == card_2 || card_1 == card_3 || card_1 == card_4 || card_1 == card_5 || card_2 == card_3 || card_2 == card_4 || card_2 == card_5 || card_3 == card_4 || card_3 == card_5 || card_4 == card_5) {
        printf("error\n");
    }
    
    else if((card_1 >= 1 && card_1 <= 52) && (card_2 >= 1 && card_2 <= 52) && (card_3 >= 1 && card_3 <= 52) && (card_4 >= 1 && card_4 <= 52) && (card_5 >= 1 && card_5 <= 52)) {
        
        if((suit_1 == suit_2 && suit_2 == suit_3 && suit_3 == suit_4 && suit_4 == suit_5) && (num_5 == num_4 + 1 && num_4 == num_3 + 1 && num_3 == num_2 + 1 && num_2 == num_1 + 1)) {
            
            printf("Straight flush\n");
        }
        
        else if((num_1 == num_2 && num_2 == num_3 && num_3 == num_4 && num_4 != num_5) || (num_1 != num_2 && num_2 == num_3 && num_3 == num_4 && num_4 == num_5)) {
            
            printf("Four of a kind\n");
        }
        
        else if((num_1 == num_2 && num_2 == num_3 && num_3 != num_4 && num_4 == num_5) || (num_1 == num_2 && num_2 != num_3 && num_3 == num_4 && num_4 == num_5)) {
            
            printf("Full house\n");
        }
        
        else if(suit_1 == suit_2 && suit_2 == suit_3 && suit_3 == suit_4 && suit_4 == suit_5) {
            
            printf("Flush\n");
        }
        
        else if((num_5 == num_4 + 1 && num_4 == num_3 + 1 && num_3 == num_2 + 1 && num_2 == num_1 + 1) || (num_1 == 1 && num_2 == 10 && num_3 == 11 && num_4 == 12 && num_5 == 13)) {
            
            printf("Straight\n");
        }
        
        else if((num_1 == num_2 && num_2 == num_3 && num_3 != num_4 && num_4 != num_5) || (num_1 != num_2 && num_2 == num_3 && num_3 == num_4 && num_4 != num_5) || (num_1 != num_2 && num_2 != num_3 && num_3 == num_4 && num_4 == num_5)) {
            
            printf("Three of a kind\n");
        }
        
        else if((num_1 != num_2 && num_2 == num_3 && num_3 != num_4 && num_4 == num_5) || (num_1 == num_2 && num_2 != num_3 && num_3 != num_4 && num_4 == num_5) || (num_1 == num_2 && num_2 != num_3 && num_3 == num_4 && num_4 != num_5)) {
            
            printf("Two pair\n");
        }
        
        else if((num_1 == num_2 && num_2 != num_3 && num_3 != num_4 && num_4 != num_5) || (num_1 != num_2 && num_2 == num_3 && num_3 != num_4 && num_4 != num_5) || (num_1 != num_2 && num_2 != num_3 && num_3 == num_4 && num_4 != num_5) || (num_1 != num_2 && num_2 != num_3 && num_3 != num_4 && num_4 == num_5)) {
            
            printf("One pair\n");
        }
        
        else {
            printf("High card\n");
        }
    }
    
    else {
        printf("error\n");
    }
    
    return 0;
}
