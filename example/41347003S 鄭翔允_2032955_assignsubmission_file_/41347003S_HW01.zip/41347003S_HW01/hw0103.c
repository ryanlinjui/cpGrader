#include <stdio.h>
#include <stdint.h>

int main() {
    uint16_t num = 0;
    uint16_t num_mod = 0;
    uint16_t temp_a = 0, temp_b = 0, temp_c = 0, temp_d = 0, temp_e = 0, temp_f = 0;
    uint16_t octalTran = 0;
    
    printf("Please enter an unsigned 16-bits number: ");
    scanf("%hu", &num);
        
    //process of flip
    
    temp_a = num / (8*8*8*8*8);
    temp_b = (num - temp_a*(8*8*8*8*8)) / (8*8*8*8);
    temp_c = (num - (temp_a*(8*8*8*8*8) + temp_b*(8*8*8*8))) / (8*8*8);
    temp_d = (num - (temp_a*(8*8*8*8*8) + temp_b*(8*8*8*8) + temp_c*(8*8*8))) / (8*8);
    temp_e = (num - (temp_a*(8*8*8*8*8) + temp_b*(8*8*8*8) + temp_c*(8*8*8) + temp_d*(8*8))) / 8;
    temp_f = num - (temp_a*(8*8*8*8*8) + temp_b*(8*8*8*8) + temp_c*(8*8*8) + temp_d*(8*8) + temp_e*8);
    
    //transform the flipped octal number to a decimal one
    
    if(temp_a != 0) {
        octalTran += temp_f*(8*8*8*8*8) + temp_e*(8*8*8*8) + temp_d*(8*8*8) + temp_c*(8*8) + temp_b*8 + temp_a;
    }
    else if(temp_b != 0) {
        octalTran += temp_f*(8*8*8*8) + temp_e*(8*8*8) + temp_d*(8*8) + temp_c*8 + temp_b;
    }
    else if(temp_c != 0) {
        octalTran += temp_f*(8*8*8) + temp_e*(8*8) + temp_d*8 + temp_c;
    }
    else if(temp_d != 0) {
        octalTran += temp_f*(8*8) + temp_e*8 + temp_d;
    }
    else if(temp_e != 0) {
        octalTran += temp_f*8 + temp_e;
    }
    else if(temp_f != 0) {
        octalTran += temp_f;
    }
    
    //display result
    
    printf("Before Flip:\n");
    printf("%d_10 = %o_8\n", num, num);
    
    printf("After  Flip:\n");
    printf("%u", temp_f);
    
    if(temp_d != 0 || temp_c != 0 || temp_b != 0 || temp_a != 0 || (temp_e != 0 && temp_d == 0 && temp_c == 0 && temp_b == 0 && temp_a == 0)) {
        printf("%u", temp_e);
    }
    if(temp_c != 0 || temp_b != 0 || temp_a != 0 || (temp_d != 0 && temp_c == 0 && temp_b == 0 && temp_a == 0)) {
        printf("%u", temp_d);
    }
    if(temp_b != 0 || temp_a != 0 || (temp_c != 0 && temp_b == 0 && temp_a == 0)) {
        printf("%u", temp_c);
    }
    if(temp_b != 0 || (temp_b == 0 && temp_a != 0)) {
        printf("%u", temp_b);
    }
    if(temp_a != 0) {
        printf("%u", temp_a);
    }
    
    printf("_8 = %d_10\n", octalTran);
    
    return 0;
}
