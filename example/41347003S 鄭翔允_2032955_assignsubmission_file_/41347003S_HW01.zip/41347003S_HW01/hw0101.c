#include <stdio.h>

#define red "\e[0;31m"
#define blu "\e[0;34m"
#define grn "\e[0;32m"

int main() {
    printf(red"[KIM]\nYou are sunlight and I moon\nJoined by the gods of fortune\nMidnight and high moon sharing the sky\nWe have been blessed, you and I\n");
    printf(blu"\n[CHRIS]\nYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow the light of one night did we come so far?\n");
    printf(red"\n[KIM]\nOutside day starts to dawn\n");
    printf(blu"\n[CHRIS]\nYour moon still floats on high\n");
    printf(red"\n[KIM]\nThe birds awake\n");
    printf(blu"\n[CHRIS]\nThe stars shine too\n");
    printf(red"\n[KIM]\nMy hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n\nYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho ’ s Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n");
    printf(blu"\n[CHRIS]\nI reach for you\n");
    printf(grn"\n[KIM & CHRIS]\nAnd we meet in the sky\n");
    printf(blu"\n[KIM]\nYou are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n");
    printf(grn"\n[KIM & CHRIS]\nMade of\nSunlight\nMoonlight\n");
    
    return 0;
}
