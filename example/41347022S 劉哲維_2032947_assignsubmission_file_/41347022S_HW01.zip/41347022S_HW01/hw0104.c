#include<stdio.h>
#include<stdint.h>
#include<stdbool.h>

int main()
{
  int32_t a=0,b=0,c=0,d=0,e=0,fa=0,fb=0,fc=0,fd=0,fe=0,na=0,nb=0,nc=0,nd=0,ne=0;
  int32_t a0=0,a1=0,a2=0,a3=0,a4=0,a5=0,a6=0,a7=0,a8=0,a9=0,a10=0,a11=0,a12=0;
  int32_t pair=0;

  printf("Please enter 5 cards: ");
  scanf(" %d%d%d%d%d",&a,&b,&c,&d,&e);
  if(a>52||b>52||c>52||d>52||e>52)
  {
    printf("Input error\n");
    return 0;
  }
  if(a<1||b<1||c<1||d<1||e<1)
  {
    printf("Input error\n");
    return 0;
  }
  if(a==b||a==c||a==d||a==e)
  {
    printf("Input error\n");
    return 0;
  }
  if(b==c||b==d||b==e)
  {
    printf("Input error\n");
    return 0;
  }
   if(c==d||c==e)
  {
    printf("Input error\n");
    return 0;
  }
   if(d==e)
  {
    printf("Input error\n");
    return 0;
  }
  
  na=(a-1)%13;
  nb=(b-1)%13;
  nc=(c-1)%13;
  nd=(d-1)%13;
  ne=(e-1)%13;
  
  fa=(a-1)/13;
  fb=(b-1)/13;
  fc=(c-1)/13;
  fd=(d-1)/13;
  fe=(e-1)/13;
  
  a0=(na==0)+(nb==0)+(nc==0)+(nd==0)+(ne==0);
  a1=(na==1)+(nb==1)+(nc==1)+(nd==1)+(ne==1);
  a2=(na==2)+(nb==2)+(nc==2)+(nd==2)+(ne==2);
  a3=(na==3)+(nb==3)+(nc==3)+(nd==3)+(ne==3);
  a4=(na==4)+(nb==4)+(nc==4)+(nd==4)+(ne==4);
  a5=(na==5)+(nb==5)+(nc==5)+(nd==5)+(ne==5);
  a6=(na==6)+(nb==6)+(nc==6)+(nd==6)+(ne==6);
  a7=(na==7)+(nb==7)+(nc==7)+(nd==7)+(ne==7);
  a8=(na==8)+(nb==8)+(nc==8)+(nd==8)+(ne==8);
  a9=(na==9)+(nb==9)+(nc==9)+(nd==9)+(ne==9);
  a10=(na==10)+(nb==10)+(nc==10)+(nd==10)+(ne==10);
  a11=(na==11)+(nb==11)+(nc==11)+(nd==11)+(ne==11);
  a12=(na==12)+(nb==12)+(nc==12)+(nd==12)+(ne==12);
  
  pair=(a0==2)+(a1==2)+(a2==2)+(a3==2)+(a4==2)+(a5==2)+(a6==2)+(a7==2)+(a8==2)+(a9==2)+(a10==2)+(a11==2)+(a12==2);
  
  bool bol1=(a0==3)||(a1==3)||(a2==3)||(a3==3)||(a4==3)||(a5==3)||(a6==3)||(a7==3)||(a8==3)||(a9==3)||(a10==3)||(a11==3)||(a12==3);
  bool bol2=(a0==2)||(a1==2)||(a2==2)||(a3==2)||(a4==2)||(a5==2)||(a6==2)||(a7==2)||(a8==2)||(a9==2)||(a10==2)||(a11==2)||(a12==2);
  
  if(a0==1&&a1==1&&a2==1&&a3==1&&a4==1&&fa==fb&&fb==fc&&fc==fd&&fd==fe)
  printf("Straight flush\n");
  else if(a1==1&&a2==1&&a3==1&&a4==1&&a5==1&&fa==fb&&fb==fc&&fc==fd&&fd==fe)
  printf("Straight flush\n");
  else if(a2==1&&a3==1&&a4==1&&a5==1&&a6==1&&fa==fb&&fb==fc&&fc==fd&&fd==fe)
  printf("Straight flush\n");
  else if(a3==1&&a4==1&&a5==1&&a6==1&&a7==1&&fa==fb&&fb==fc&&fc==fd&&fd==fe)
  printf("Straight flush\n");
  else if(a4==1&&a5==1&&a6==1&&a7==1&&a8==1&&fa==fb&&fb==fc&&fc==fd&&fd==fe)
  printf("Straight flush\n");
  else if(a5==1&&a6==1&&a7==1&&a8==1&&a9==1&&fa==fb&&fb==fc&&fc==fd&&fd==fe)
  printf("Straight flush\n");
  else if(a6==1&&a7==1&&a8==1&&a9==1&&a10==1&&fa==fb&&fb==fc&&fc==fd&&fd==fe)
  printf("Straight flush\n");
  else if(a7==1&&a8==1&&a9==1&&a10==1&&a11==1&&fa==fb&&fb==fc&&fc==fd&&fd==fe)
  printf("Straight flush\n");
  else if(a8==1&&a9==1&&a10==1&&a11==1&&a12==1&&fa==fb&&fb==fc&&fc==fd&&fd==fe)
  printf("Straight flush\n"); 
  else if(a9==1&&a10==1&&a11==1&&a12==1&&a0==1&&fa==fb&&fb==fc&&fc==fd&&fd==fe)
  printf("Straight flush\n");
  
  else if(a0==4||a1==4||a2==4||a3==4||a4==4||a5==4||a6==4||a7==4||a8==4||a9==4||a10==4||a11==4||a12==4)
  printf("Four of a kind\n");
  
  else if(bol1+bol2==2)
  printf("Full house\n");
  
  else if(fa==fb&&fb==fc&&fc==fd&&fd==fe)
  printf("Flush\n");
  
  else if(a0==1&&a1==1&&a2==1&&a3==1&&a4==1)
  printf("Straight\n");
  else if(a1==1&&a2==1&&a3==1&&a4==1&&a5==1)
  printf("Straight\n");
  else if(a2==1&&a3==1&&a4==1&&a5==1&&a6==1)
  printf("Straight\n");
  else if(a3==1&&a4==1&&a5==1&&a6==1&&a7==1)
  printf("Straight\n");
  else if(a4==1&&a5==1&&a6==1&&a7==1&&a8==1)
  printf("Straight\n");
  else if(a5==1&&a6==1&&a7==1&&a8==1&&a9==1)
  printf("Straight\n");
  else if(a6==1&&a7==1&&a8==1&&a9==1&&a10==1)
  printf("Straight\n");
  else if(a7==1&&a8==1&&a9==1&&a10==1&&a11==1)
  printf("Straight\n");
  else if(a9==1&&a10==1&&a11==1&&a12==1&&a0==1)
  printf("Straight\n");
  
  else if(a0==3||a1==3||a2==3||a3==3||a4==3||a5==3||a6==3||a7==3||a8==3||a9==3||a10==3||a11==3||a12==3)
  printf("Three of a kind\n");
  
  else if(pair==2)
  printf("Two pair\n");
  
  else if(bol2==1)
  printf("One pair\n");
  
  else
  printf("High Card\n");
  
  return 0;
}
