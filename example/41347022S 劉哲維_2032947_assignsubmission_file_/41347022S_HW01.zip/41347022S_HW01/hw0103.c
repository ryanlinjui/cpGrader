#include<stdio.h>
#include<stdint.h>
int main()
{
  int32_t a=0,a1=0,a2=0,a3=0,a4=0,a5=0,a6=0;
  printf("Please enter an unsigned 16-bits number: ");
  scanf("%d",&a);
  printf("Before flip:\n");
  printf("%d_10 = %o_8\n",a,a);
  
  a1=a%8;
  a/=8;
  a2=a%8;
  a/=8;
  a3=a%8;
  a/=8;
  a4=a%8;
  a/=8;
  a5=a%8;
  a/=8;
  a6=a%8;
  a/=8;
  
  a=a1*100000+a2*10000+a3*1000+a4*100+a5*10+a6;
  
  if(a%10==0)
  a/=10;
  if(a%10==0)
  a/=10;
  if(a%10==0)
  a/=10;
  if(a%10==0)
  a/=10;
  if(a%10==0)
  a/=10;
  
  a1=a%10;
  a/=10;
  a2=a%10;
  a/=10;
  a3=a%10;
  a/=10;
  a4=a%10;
  a/=10;
  a5=a%10;
  a/=10;
  a6=a%10;
  a/=10;
  
  a=a6*32768+a5*4096+a4*512+a3*64+a2*8+a1;
  
  printf("After flip:\n");
  printf("%o_8 = %d_10\n",a,a);
  return 0;
}
