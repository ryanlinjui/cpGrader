#include<stdio.h>
#include<stdint.h>

int main()
{
  int32_t a=0,b=0,c=0,sum=0,x=0,y=0,z=0,ans=0;
  printf("Please enter the first operand: ");
  scanf(" %dx%d",&a,&b);
  if(a>=10||b>=10)
  {
    printf("Input error\n");
    return 0;
  }
  printf("Please enter the second operand: ");
  scanf(" y%dz",&c);
  if(c>=10)
  {
    printf("Input error\n");
    return 0;
  }
  printf("Please enter the sum: ");
  scanf(" %d",&sum);
  if(sum>=1999)
  {
    printf("Input error\n");
    return 0;
  }
  ans=sum-100*a-10*c-b;
  y=ans/100;
  x=ans/10-10*y;
  z=ans-100*y-10*x;
  printf("Ans: x=%d, y=%d, z=%d\n",x,y,z);
  return 0;
}
