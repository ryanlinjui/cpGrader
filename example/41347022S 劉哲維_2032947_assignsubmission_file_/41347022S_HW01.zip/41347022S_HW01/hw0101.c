#include<stdio.h>

int main()
{
  printf("\033[0;31m[KIM]\nYou are sunlight and I moon\033[m\n");
  printf("\033[0;31mJoined by the gods of fortune\nMidnight and high noon sharing the sky\033[m\n");
  printf("\033[0;31mWe have been blessed , you and I\033[m\n\n");
  printf("\033[0;34m[CHRIS]\nYou are here like a mystery\033[m\n");
  printf("\033[0;34mI'm from a world that's so different from all that you are\033[m\n");
  printf("\033[0;34mHow in the light of one night did we come so far?\033[m\n\n");
  printf("\033[0;31m[KIM]\nOutside day starts to dawn\033[m\n\n");
  printf("\033[0;34m[CHRIS]\nYour moon still floats on high\033[m\n\n");
  printf("\033[0;31m[KIM]\nThe birds awake\033[m\n\n");
  printf("\033[0;34m[CHRIS]\nThe stars shine too\033[m\n\n");
  printf("\033[0;31m[KIM]\nMy hands still shake\nSee upcoming pop shows\033[m\n");
  printf("\033[0;31mGet tickets for your favorite artists\n\nYou might also like\033[m\n");
  printf("\033[0;31mMy Boy Only Breaks His Favorite Toys\nTaylor Swift\033[m\n");
  printf("\033[0;31mWho’s Afraid of Little Old Me?\nTaylor Swift\033[m\n");
  printf("\033[0;31mGuilty as Sin?\nTaylor Swift\033[m\n\n");
  printf("\033[0;34m[CHRIS]\nI reach for you\033[m\n\n");
  printf("\033[0;32m[KIM & CHRIS]\nAnd we meet in the sky\033[m\n\n");
  printf("\033[0;34m[KIM]\nYou are sunlight and I moon\033[m\n");
  printf("\033[0;34mJoined here\nBrightening the sky with the flame of love\033[m\n\n");
  printf("\033[0;32m[KIM & CHRIS]\nMade of\nSunlight\nMoonlight\033[m\n");
}
