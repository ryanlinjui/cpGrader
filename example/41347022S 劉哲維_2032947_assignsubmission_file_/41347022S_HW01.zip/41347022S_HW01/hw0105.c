#include<stdio.h>
#include<stdint.h>

int main()
{
  int32_t h0=0,h=0,t=0;
  int32_t a1=0,a2=0,a3=0,a4=0,a5=0,a6=0,a7=0,a8=0,a9=0,a10=0,a11=0,a12=0,a13=0,a14=0,a15=0,a16=0;
  int32_t sint=0,exp=0;
  float F=0;
  
  printf("Please input a hex:");
  scanf("%X",&h);
  printf("Please choose the output type(1:integer,2:unsigned integer,3:float): ");
  scanf("%d",&t);
  
  h0=h;
  
  a1=h%2;
  h/=2;
  a2=h%2;
  h/=2;
  a3=h%2;
  h/=2;
  a4=h%2;
  h/=2;
  a5=h%2;
  h/=2;
  a6=h%2;
  h/=2;
  a7=h%2;
  h/=2;
  a8=h%2;
  h/=2;
  a9=h%2;
  h/=2;
  a10=h%2;
  h/=2;
  a11=h%2;
  h/=2;
  a12=h%2;
  h/=2;
  a13=h%2;
  h/=2;
  a14=h%2;
  h/=2;
  a15=h%2;
  h/=2;
  a16=h%2;
  h/=2;
 
  if(t==1||t==2||t==3)
  {
    if(t==1)
    {
      if(a16==1)
      {
        a16=-a16+1;
        a15=-a15+1;
        a14=-a14+1;
        a13=-a13+1;
        a12=-a12+1;
        a11=-a11+1;
        a10=-a10+1;
        a9=-a9+1;
        a8=-a8+1;
        a7=-a7+1;
        a6=-a6+1;
        a5=-a5+1;
        a4=-a4+1;
        a3=-a3+1;
        a2=-a2+1;
        a1=-a1+1;
        sint=a16*32768+a15*16384+a14*8192+a13*4096+a12*2048+a11*1024+a10*512+a9*256+a8*128+a7*64+a6*32+a5*16+a4*8+a3*4+a2*2+a1;
        printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",h0,a16,a15,a14,a13,a12,a11,a10,a9,a8,a7,a6,a5,a4,a3,a2,a1);
        printf("Converted integer is: %d\n",sint);
      }
      if(a16==0)
      {
        printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",h0,a16,a15,a14,a13,a12,a11,a10,a9,a8,a7,a6,a5,a4,a3,a2,a1);
        printf("Converted integer is: %d\n",h0);
      }
    }
  
    if(t==2)
    {
      printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",h0,a16,a15,a14,a13,a12,a11,a10,a9,a8,a7,a6,a5,a4,a3,a2,a1);
      printf("Converted unsigned integer is: %d\n",h0);
    }
  
    if(t==3)
    {
      if(a16==1)
      {
      exp=a15*16+a14*8+a13*4+a12*2+a11-15;
      F=a10*0.5+a9*0.25+a8*0.125+a7*0.0625+a6*0.03125+a5*0.015625+a4*0.0078125+a3*0.00390625+a2*0.001953125+a1*0.0009765625+1;
      printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",h0,a16,a15,a14,a13,a12,a11,a10,a9,a8,a7,a6,a5,a4,a3,a2,a1);
      printf("Converted unsigned float is: -%f*2^%d\n",F,exp);
      }
      if(a16==0)
      {
      exp=a15*16+a14*8+a13*4+a12*2+a11-15;
      F=a10*0.5+a9*0.25+a8*0.125+a7*0.0625+a6*0.03125+a5*0.015625+a4*0.0078125+a3*0.00390625+a2*0.001953125+a1*0.0009765625+1;
      printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",h0,a16,a15,a14,a13,a12,a11,a10,a9,a8,a7,a6,a5,a4,a3,a2,a1);
      printf("Converted unsigned float is: %f*2^%d\n",F,exp);
      }
    }
  
    return 0;
  }
  
  else
  {
    printf("Input error\n");
    return 0;
  }
}
