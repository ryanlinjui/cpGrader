#include <stdio.h>
#include <stdint.h>

int main()
{
    // input
    int32_t fa, fb, fc, sa, sb, sc, ans, cur;
    char check;
    
    // 輸入第一個操作數
    printf("Please enter the first  operand: ");
    if (scanf("%dx%d", &fa, &fc) != 2 || fa > 9 || fc > 9) {
        printf("Error: Invalid first operand.\n");
        return 1;  // 結束程式
    }

    // 輸入第二個操作數
    printf("Please enter the second operand: ");
    if (scanf(" y%dz", &sb) != 1|| sb > 9) {
        printf("Error: Invalid second operand.\n");
        return 1;  // 結束程式
    }
    
    // 輸入和
    printf("Please enter the sum           : ");
    if (scanf("%d%c", &ans, &check) != 2 || ans > 1998 || check != '\n') {
        printf("Error: Invalid sum.\n");
        return 1;  // 結束程式
    }
    
    /*  test
    printf("%d%c%d\n", fa, tempa, fc);
    printf("%c%d%c\n", tempb, sb, tempc);
    printf("%d\n", ans);
     */
    
    // compute
    if (ans % 10 - fc> 0) {
        cur = ans % 10;
    } else {
        ans -= 10;
        cur = ans % 10 + 10;
    }
    sc = cur - fc; // second = cur - first
    
    if ((ans % 100) / 10 - sb > 0) {
        cur = (ans % 100) / 10;
    } else {
        ans -= 100;
        cur = (ans % 100) / 10 + 10;
    }
    fb = cur - sb; // first = cr - second
    
    sa = ans / 100 - fa;
    
    // output
    printf("Ans: x = %d, y = %d, z = %d\n", fb, sa, sc);
    
    return 0;
}
