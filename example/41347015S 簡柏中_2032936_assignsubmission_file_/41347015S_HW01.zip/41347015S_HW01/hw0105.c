#include <stdio.h>
#include <stdint.h>

// 將二進制轉換為 IEEE 754 浮點數
#include <stdio.h>
#include <stdint.h>

// 將二進制轉換為 IEEE 754 浮點數
/*
1.符號位（S）：第 1 位，0 表示正數，1 表示負數。
2.指數位（EXP）：第 2 位到第 6 位，表示數字的指數部分。
3.小數部分（F）：第 7 位到第 16 位，表示小數部分。
*/

// mainmainmainmain
int main() {
    uint16_t hex_input;
    int choice;

    // 十六進制input
    printf("Please input a hex:");
    // 判斷scanf是否成功讀取
    if (scanf("%hx", &hex_input) != 1 || hex_input > 0xFFFF) {
        printf("Error: Invalid hex input!\n");
        return 1;
    }

    // chooseeeeee
    printf("Please choose the output type (1:integer,2:unsigned integer,3:float):");
    scanf("%d", &choice);
    if (choice < 1 || choice > 3) {
        printf("Error!!!\n");
        return 1;
    }
    
    // output 二進
    uint16_t num = hex_input;
    printf("Binary of %04X is: ", num);
    
    // for
    printf("%d", (num >> 15) & 1);
    printf("%d", (num >> 14) & 1);
    printf("%d", (num >> 13) & 1);
    printf("%d", (num >> 12) & 1);
    printf(" ");
    printf("%d", (num >> 11) & 1);
    printf("%d", (num >> 10) & 1);
    printf("%d", (num >> 9) & 1);
    printf("%d", (num >> 8) & 1);
    printf(" ");
    printf("%d", (num >> 7) & 1);
    printf("%d", (num >> 6) & 1);
    printf("%d", (num >> 5) & 1);
    printf("%d", (num >> 4) & 1);
    printf(" ");
    printf("%d", (num >> 3) & 1);
    printf("%d", (num >> 2) & 1);
    printf("%d", (num >> 1) & 1);
    printf("%d", (num >> 0) & 1);
    printf("\n");
    
    // 根據剛才選擇的
    switch (choice) {
        case 1: {
            // 轉換為有符號整數 d
            int16_t signed_value = (int16_t) hex_input;
            printf("Converted integer is: %d\n", signed_value);
            break;
        }
        case 2: {
            // 轉換為無號整數 u
            uint16_t unsigned_value = hex_input;
            printf("Converted unsigned integer is: %u\n", unsigned_value);
            break;
        }
        case 3: {
            // 轉換為浮點數
            uint16_t num = hex_input;
            int sign = (num >> 15) & 1;  // 提取符號位
            int exponent = (num >> 10) & 0x1F;  // 提取指數位 (5 位)
            int fraction = num & 0x3FF;  // 提取小數位 (10 位)

            // 檢查邊界情況：如果所有位元都是 0，則輸出 0 或 -0
            if (exponent == 0 && fraction == 0) {
                if (sign) {
                    printf("Converted float is: -0.0\n");
                } else {
                    printf("Converted float is: +0.0\n");
                }
                return 0; //
            }

            // 檢查是否為無窮大或 NaN
            if (exponent == 0x1F) {
                if (fraction == 0) {
                    // 無窮大
                    printf("Converted float is: %sINF\n", sign ? "-" : "+");
                } else {
                    // 非數值 NaN
                    printf("Converted float is: NaN\n");
                }
                return 0; //
            }

            // 計算 1.F 和實際指數（偏移量 15）
            float f = 1 + fraction / (float)(1 << 10);
            int exp_value = exponent - 15;

            // 計算並根據符號位調整正負
            printf("Converted float is: %.6f*2^%d\n", sign ? -f : f, exp_value);
            break;
        }
        // error!
        default:
            printf("Invalid choice\n");
    }

    return 0;
}
