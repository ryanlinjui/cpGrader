#include <stdio.h>
#include <stdint.h>
#include <math.h>

int main()
{
    uint16_t num10, rev8 = 0, multi = 0;
    printf("Please enter an unsigned 16-bits number: ");
    scanf("%hu", &num10);
    if (num10 > 65535) {
      printf("Error!number out of range\n");
      return 1;
    }
    printf("Before Flip:\n");
    printf("%hu_10 = %o_8\n", num10, num10);
    
    // 10 to 8 and rev
    if (num10 > 0) {
        rev8 *= 10;
        rev8 += num10 % 8;
        num10 = num10 / 8;
    }
    if (num10 > 0) {
        rev8 *= 10;
        rev8 += num10 % 8;
        num10 = num10 / 8;
    }
    if (num10 > 0) {
        rev8 *= 10;
        rev8 += num10 % 8;
        num10 = num10 / 8;
    }
    if (num10 > 0) {
        rev8 *= 10;
        rev8 += num10 % 8;
        num10 = num10 / 8;
    }
    if (num10 > 0) {
        rev8 *= 10;
        rev8 += num10 % 8;
        num10 = num10 / 8;
    }
    if (num10 > 0) {
        rev8 *= 10;
        rev8 += num10 % 8;
        num10 = num10 / 8;
    }
        
    // rev8 to 10
    uint16_t ans8 = rev8;
    
    num10 = 0;
    if (rev8 > 0) {
        num10 += (int)(pow(8, multi)) * (rev8 % 10);
        multi += 1;
        rev8 /= 10;
    }
    if (rev8 > 0) {
        num10 += (int)(pow(8, multi)) * (rev8 % 10);
        multi += 1;
        rev8 /= 10;
    }
    if (rev8 > 0) {
        num10 += (int)(pow(8, multi)) * (rev8 % 10);
        multi += 1;
        rev8 /= 10;
    }
    if (rev8 > 0) {
        num10 += (int)(pow(8, multi)) * (rev8 % 10);
        multi += 1;
        rev8 /= 10;
    }
    if (rev8 > 0) {
        num10 += (int)(pow(8, multi)) * (rev8 % 10);
        multi += 1;
        rev8 /= 10;
    }
    if (rev8 > 0) {
        num10 += (int)(pow(8, multi)) * (rev8 % 10);
        multi += 1;
        rev8 /= 10;
    }
    
    printf("After  Flip:\n");
    printf("%hu_8 = %d_10\n", ans8, num10);
    
    
    return 0;
}
