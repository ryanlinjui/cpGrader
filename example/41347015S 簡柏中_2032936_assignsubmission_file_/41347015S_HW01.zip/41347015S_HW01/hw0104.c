#include <stdio.h>
#include <stdint.h>

// 判斷牌型
int main()
{
    // input
    int32_t a, b, c, d, e, temp;
    printf("Please enter 5 cards: ");
    
    scanf("%d", &a);
    if (a > 52 || a < 1) {
        printf("Error: Invalid\n");
        return 1;
    }
    scanf("%d", &b);
    if (b > 52 || b < 1) {
        printf("Error: Invalid\n");
        return 1;
    }
    scanf("%d", &c);
    if (c > 52 || c < 1) {
        printf("Error: Invalid\n");
        return 1;
    }
    scanf("%d", &d);
    if (d > 52 || d < 1) {
        printf("Error: Invalid\n");
        return 1;
    }
    scanf("%d", &e);
    if (e > 52 || e < 1) {
        printf("Error: Invalid\n");
        return 1;
    }
    
    
    // sort
    if (a > b) {
        temp = a;
        a = b;
        b = temp;
    }
    if (b > c) {
        temp = b;
        b = c;
        c = temp;
    }
    if (c > d) {
        temp = c;
        c = d;
        d = temp;
    }
    if (d > e) {
        temp = d;
        d = e;
        e = temp;
    }
    if (a > b) {
        temp = a;
        a = b;
        b = temp;
    }
    if (b > c) {
        temp = b;
        b = c;
        c = temp;
    }
    if (c > d) {
        temp = c;
        c = d;
        d = temp;
    }
    if (a > b) {
        temp = a;
        a = b;
        b = temp;
    }
    if (b > c) {
        temp = b;
        b = c;
        c = temp;
    }
    if (a > b) {
        temp = a;
        a = b;
        b = temp;
    }
    
    // 1&4 同花順 or 同花
    if ( ((1 <= a && a <= 13) && (1 <= e && e <= 13)) || ((14 <= a && a <= 26) && (14 <= e && e <= 26)) || ((27 <= a && a <= 39) && (27 <= e && e <= 39)) || ((40 <= a && a <= 52) && (40 <= e && e <= 52)) ) {
        // 如果是順子 輸出同花順
        if ((e-d == 1 && d-c == 1 && c-b == 1 && b-a == 1) && (a%13 != 11 || a%13 != 12 || a%13 != 0)) {
            printf("Straight Flush\n");
        } else { // 否則輸出同花
            printf("Flush\n");
        }
    } else {
        // %13 and sort 因為同花的可能性已經排除 將純數字排序過後來判斷
        a %= 13;
        if (a == 0) a = 13;
        b %= 13;
        if (b == 0) b = 13;
        c %= 13;
        if (c == 0) c = 13;
        d %= 13;
        if (d == 0) d = 13;
        e %= 13;
        if (e == 0) e = 13;
        // sort
        if (a > b) {
            temp = a;
            a = b;
            b = temp;
        }
        if (b > c) {
            temp = b;
            b = c;
            c = temp;
        }
        if (c > d) {
            temp = c;
            c = d;
            d = temp;
        }
        if (d > e) {
            temp = d;
            d = e;
            e = temp;
        }
        if (a > b) {
            temp = a;
            a = b;
            b = temp;
        }
        if (b > c) {
            temp = b;
            b = c;
            c = temp;
        }
        if (c > d) {
            temp = c;
            c = d;
            d = temp;
        }
        if (a > b) {
            temp = a;
            a = b;
            b = temp;
        }
        if (b > c) {
            temp = b;
            b = c;
            c = temp;
        }
        if (a > b) {
            temp = a;
            a = b;
            b = temp;
        }
        // ------------------------------
        // 2 鐵支
        if (a == d || b == e) {
            printf("Four of a kind\n");
        }
        
        // 3&6 葫蘆 or 三條
        else if (a == c || b == d || c == e) {
            if ((a == b && c == d && d == e) || (a == b && b == c && d == e)) {
                printf("Full house\n");
            } else {
                printf("Three of a kind\n");
            }
        }
        
        // 5 順子
        else if ((e - d == 1 && d - c == 1 && c - b == 1 && b - a == 1) || (a == 10 && b == 11 && c == 12 && d == 13))  {
            printf("Straight\n");
        }
        
        // 7 兩對
        else if ((a == b && c == d) || (b == c && d == e) || (a == b && d == e)) {
            printf("Two pair\n");
        }
        
        // 8 一對
        else if ((a == b) || (b == c) || (c == d) || (d == e)) {
            printf("One pair\n");
        }
        
        // 9 高牌
        else {
            printf("High Card\n");
        }
    }
    
    // test
    /*
    for (int i = 0; i < 5; i++) {
        printf("%d\n", arr[i]);
    }
    */

    return 0;
}
