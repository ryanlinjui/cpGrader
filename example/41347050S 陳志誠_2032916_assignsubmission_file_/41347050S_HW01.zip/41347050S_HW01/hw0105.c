#include <stdio.h>
#include <stdint.h>
int main(){
    int32_t hex;
    int32_t a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p;
    printf("Please input a hex:");
    scanf("%x", &hex);
    //printf("%d\n", hex);
    int32_t x = hex;

    if(x>65535||x<0){
        printf("Error: Please input 16-bit hex");
    }
    int32_t type;
    printf("Please choose the output type(1:integer,2:unsigned integer,3:float):");
    scanf("%1d",&type);
    if(type>3 || type <1){
        printf("Error: Please choose between 1,2 or 3");
    }

//convert hex to binary
    if((x/2)>=0 && x<2 && x!=0){
        a=1;
        x=0;
    }else if((x/2)>=0 && x!=0){  
        a=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x!= 0){
        b=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        b=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        c=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        c=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        d=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        d=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        e=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        e=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        f=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        f=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        g=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        g=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        h=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        h=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        i=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        i=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        j=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        j=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        k=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        k=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        l=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        l=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        m=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        m=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        n=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        n=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        o=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        o=x%2;
        x=x/2;
    }
    if((x/2)>=0 && x<2 && x !=0){
        p=1;
        x=0;
    }else if((x/2)>=0 && x != 0){
        p=x%2;
        x=x/2;
    }
    printf("Binary of %x is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",hex,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a);

    if(type==2){
    //unsigned
        int32_t ui=0;
        if(a==1){ui=ui+1; }
        if(b==1){ui=ui+2;}
        if(c==1){ui=ui+4;}
        if(d==1){ui=ui+8;}
        if(e==1){ui=ui+16;}
        if(f==1){ui=ui+32;}
        if(g==1){ui=ui+64;}
        if(h==1){ui=ui+128;}
        if(i==1){ui=ui+256;}
        if(j==1){ui=ui+512;}
        if(k==1){ui=ui+1024;}
        if(l==1){ui=ui+2048;}
        if(m==1){ui=ui+4096;}
        if(n==1){ui=ui+8192;}
        if(o==1){ui=ui+16384;}
        if(p==1){ui=ui+32768;}
        printf("Converted unsigned integer is:%d\n",ui);
    }
    int32_t si;
    if(type==1){
    //integer
    //2^16 = 65536
        si=65536-hex;
        printf("Converted signed integer is:-%d\n",si);

    }
    int32_t exp;

    if(type==3){
        if(o==1){exp=exp+16;}
        if(n==1){exp=exp+8;}
        if(m==1){exp=exp+4;}
        if(l==1){exp=exp+2;}
        if(k==1){exp=exp+1;}
        exp=exp-15;

        float ff=0;
        if(j==1){ff=ff+0.5;}
        if(i==1){ff=ff+0.25;}
        if(h==1){ff=ff+0.125;}
        if(g==1){ff=ff+0.0625;}
        if(f==1){ff=ff+0.03125;}
        if(e==1){ff=ff+0.015625;}
        if(d==1){ff=ff+0.0078125;}
        if(c==1){ff=ff+0.00390625;}
        if(b==1){ff=ff+0.001953125;}
        if(a==1){ff=ff+0.0009765625;}
        ff=1+ff;
        
        if(p==1){
            printf("-%f*2^%d\n",ff,exp);
        }
        else if(p==0){
            printf("%f*2^%d\n",ff,exp);
        }
    }
return 0;
}