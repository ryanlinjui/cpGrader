#include <stdio.h>
#include <stdint.h>

int main(){
    int32_t a,b,c,d,e;
    int32_t a1,b1,c1,d1,e1;
    printf("Please enter 5 cards:");
    scanf("%d %d %d %d %d", &a,&b,&c,&d,&e);

    a1=a;b1=b;c1=c;d1=d;e1=e;

    if(a<1||a>52||b<1||b>52||c<1||c>52||d<1||d>52||e<1||e>52){
        printf("Error: the input must be \"int int int int int\" with int between 1-52");
        return 1;
    }
    if(a>13){
        a=a%13;
    }else if(a<14){
        a=a;
    }
    if(b>13){
        b=b%13;
    }else if(b<14){
        b=b;
    }
    if(c>13){
        c=c%13;
    }else if(c<14){
        c=c;
    }
    if(d>13){
        d=d%13;
    }else if(d<14){
        d=d;
    }
    if(e>13){
        e=e%13;
    }else if(e<14){
        e=e;
    }

    int32_t x;
    if(a>b){
        x = a;
        a = b;
        b = x;
    }if(b>c){
        x = b;
        b = c;
        c = x;
    }if(c>d){
        x = c;
        c = d;
        d = x;
    }if(d>e){
        x = d;
        d = e;
        e = x;
    }if(a>b){
        x = a;
        a = b;
        b = x;
    }if(b>c){
        x = b;
        b = c;
        c = x;
    }if(c>d){
        x = c;
        c = d;
        d = x;
    }if(d>e){
        x = d;
        d = e;
        e = x;
    }if(a>b){
        x = a;
        a = b;
        b = x;
    }if(b>c){
        x = b;
        b = c;
        c = x;
    }if(c>d){
        x = c;
        c = d;
        d = x;
    }if(d>e){
        x = d;
        d = e;
        e = x;
    }if(a>b){
        x = a;
        a = b;
        b = x;
    }if(b>c){
        x = b;
        b = c;
        c = x;
    }if(c>d){
        x = c;
        c = d;
        d = x;
    }if(d>e){
        x = d;
        d = e;
        e = x;
    }
    printf("%d%d%d%d%d\n",a,b,c,d,e);

    int32_t y;
    if((a1-1)/13==(b1-1)/13 && (b1-1)/13==(c1-1)/13 && (c1-1)/13==(d1-1)/13 && (d1-1)/13==(e1-1)/13 && a+1==b && b+1==c && c+1==d && d+1==e){
        printf("Straght Flush\n");
    }
    else if(a==b && b==c && c==d || b==c && c==d && d==e){
        printf("Four of a Kind\n");
    }
    else if(a==b && b==c && d==e || a==b && c==d && d==e){
        printf("Full House\n");
    }
    else if((a1-1)/13==(b1-1)/13 && (b1-1)/13==(c1-1)/13 && (c1-1)/13==(d1-1)/13 && (d1-1)/13==(e1-1)/13){
        printf("Flush\n");
    }
    else if(a+1==b && b+1==c && c+1==d && d+1==e){
        printf("Straight\n");
    }
    else if(a==b && b==c || b==c && c==d || c==d && d==e){
        printf("Three of a Kind\n");
    }
    else if(a==b && c==d || a==b && d==e || b==c && d==e){
        printf("Two Pair\n");
    }
    else if(a==b || b==c || c==d ||d==e){
        printf("One Pair\n");
    }
    else{
        printf("High Card\n");
    }

return 0;
}