#include <stdio.h>
#include <stdint.h>
#include <string.h>

int main(){

    int32_t a, b, c;

    printf("Please enter the first operand :");
    if (scanf("%1dx%1d",&a,&b) !=2 ||a < 0 || a > 9 || b<0 || b>9){
        printf("Error:the input format for the first operand must be int-x-int with int between 0-9\n");
        return 1;
    }
    printf("Please enter the second operand:");
    if (scanf(" y%1dz",&c) !=1 || c <0  || c > 9){
        printf("Error:the input format for the second operand must be y-int-z with int between 0-9\n");
        return 1;
    }
    

    int32_t sum;
    printf("Please enter the sum           :");
    scanf("%d",&sum);

    int32_t known,def;
    known = a*100 + c*10 + b;
    def = sum - known;

    if(sum>1998){
        printf("Error:the input format for the sum must be between 0-1998\n");
        return 1;
    }else if(sum<known){
        printf("Error:this number can't be calculate\n");
        return 1;
    }
    if(sum>(known+999)){
        printf("Error:this number can't be calculate\n");
        return 1;
    }

   //d=y , e = x , f = z
    def = sum - known;
    int32_t d,e,f;
    d = def/100;
    e = (def%100)/10;
    f = (def%100)%10;

    printf("ans: x=%d, y=%d, z=%d\n",e,d,f);

return 0;
}
