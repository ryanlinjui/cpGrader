
student id : 41347050S
name : 陳志誠

to compile the program run : make 
onced compiled run : ./hwXXYY