#include <stdio.h>
#include <stdint.h>

int main(){

    int32_t y,a,b,c,d,e,f;
    int32_t x,z;
    int32_t intbefore, octalbefore, octalafter, intafter;

    printf("Please enter an unsigned 16-bits number:");
    scanf(" %d",&x);
    intbefore = x;
//unsigned integer is 0 to 65535
    if (x<0||x>65535){
        printf("Error: you must input unsigned integer wich is between 0 to 65535");
        return 1;
    }
    // unsigned integer confert to octal number max is 177777
    if(x==0){
        y=0;
    }else if((x/8)>=0 && x<8 && x!=0){
        a=x;
        x=0;
        y=1;
    }else if((x/8)>=0 && x!=0){  
        a=x%8;
        x=x/8;
        y=1;
    }

    if((x/8)>=0 && x<8 && x!= 0){
        b=x;
        x=0;
        y=2;
    }else if((x/8)>=0 && x != 0){
        b=x%8;
        x=x/8;
        y=2;
    }

    if((x/8)>=0 && x<8 && x !=0){
        c=x;
        x=0;
        y=3;
    }else if((x/8)>=0 && x != 0){
        c=x%8;
        x=x/8;
        y=3;
    }
    
    if((x/8)>=0 && x<8 && x != 0){
        d=x;
        x=0;
        y=4;
    }else if ((x/8)>=0 && x !=0){
        d=x%8;
        x=x/8;
        y=4;
    }
    
    if((x/8)>=0 && x<8 && x != 0 ){
        e=x;
        x=x/8;
        y=5;
    }else if ((x/8)>=0 && x !=0){
        e=x%8;
        x=x/8;
        y=5;
    }

    if((x/8)>=0 && x<8 && x != 0 ){
        f=x;
        x=x/8;
        y=6;
    }else if ((x/8)>=0 && x !=0){
        f=x%8;
        x=x/8;
        y=6;
    }

    if(y==0){
        octalbefore = x;
        octalafter = x;
        intafter = x;
    }else if(y==6){
        octalbefore = f*100000 + e*10000 + d*1000 + c*100 + b*10 + a;
        octalafter = a*100000 + b*10000 + c*1000 + d*100 + e*10 + f*1;
        intafter = a*(8*8*8*8*8) + b*(8*8*8*8) + c*(8*8*8) + d*(8*8) + e*8 + f*1;
    }else if(y==5){
        octalbefore = e*10000 + d*1000 + c*100 + b*10 + a;
        octalafter = a*10000 + b*1000 + c*100 + d*10 + e;
        intafter = a*(8*8*8*8) + b*(8*8*8) + c*(8*8) + d*8 + e*1; //8^0 =1
    }else if (y==4){
        octalbefore = d*1000 + c*100 + b*10 + a;
        octalafter = a*1000 + b*100 + c*10 + d;
        intafter = a*(8*8*8) + b*(8*8) + c*(8) + d*1; //8^0 =1
    }else if (y==3){
        octalbefore = c*100 + b*10 + a;
        octalafter = a*100 + b*10 + c;
        intafter = a*(8*8) + b*(8) + c*1; //8^0 =1
    }else if (y==2){
        octalbefore = b*10 + a;
        octalafter = a*10 + b;
        intafter = a*(8) + b*1; //8^0 =1
    }else if (y==1){
        octalbefore = a;
        octalafter = a;
    }
    
    printf("Before Flip:\n");
    printf("%d_10 = %d_8\n",intbefore,octalbefore);
    printf("After Flip:\n");
    printf("%d_8 = %d_10\n",octalafter,intafter);


return 0;
}