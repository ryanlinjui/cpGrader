#include <stdio.h>

int main() {
    const char *r = "\033[31m";
    const char *b = "\033[34m";
    const char *g = "\033[32m";
    const char *reset = "\033[0m";  
    printf("%s[KIM]\n", r);
    printf("You are sunlight and I moon\n");
    printf("Joined by the gods of fortune\n");
    printf("Midnight and high noon sharing the sky\n");
    printf("We have been blessed, you and I\n\n");

    printf("%s[CHRIS]\n", b);
    printf("You are here like a mystery\n");
    printf("I'm from a world that's so different from all that you are\n");
    printf("How in the light of one night did we come so far?\n\n");

    printf("%s[KIM]\n", r);
    printf("Outside day starts to dawn\n\n");

    printf("%s[CHRIS]\n", b);
    printf("Your moon still floats on high\n\n");

    printf("%s[KIM]\n", r);
    printf("The birds awake\n\n");

    printf("%s[CHRIS]\n", b);
    printf("The stars shine too\n\n");

    printf("%s[KIM]\n", r);
    printf("My hands still shake\n");
    printf("See upcoming pop shows\n");
    printf("Get tickets for your favorite artists\n\n");

    printf("You might also like\n");
    printf("My Boy Only Breaks His Favorite Toys\n");
    printf("Taylor Swift\n");
    printf("Who's Afraid of Little Old Me?\n");
    printf("Taylor Swift\n");
    printf("Guilty as Sin?\n");
    printf("Taylor Swift\n\n");

    printf("%s[CHRIS]\n", b);
    printf("I reach for you\n\n");

    printf("%s[KIM & CHRIS]\n", g);
    printf("And we meet in the sky\n\n");

    printf("%s[KIM]\n", r);
    printf("You are sunlight and I moon\n");
    printf("Joined here\n");
    printf("Brightening the sky with the flame of love\n\n");


    printf("%s[KIM & CHRIS]\n", g);
    printf("Made of\n");
    printf("Sunlight\n");
    printf("Moonlight\n");
    
    printf("%s", reset); 

    return 0;
}