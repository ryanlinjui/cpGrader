#include<stdio.h>
#include<stdint.h>
int main(){
	int a,b,c,d,q,w,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16;
	int ans=0;
	float F=0;
	int exp=0;
	printf("Please input a hex:");
	scanf("%X",&q);
	a=q/4096;
	b=(q%4096)/256;
	c=(q%256)/16;
	d=q%16;
	printf("Binary of %X is:",q);
//	printf("%X %X %X %X\n",a,b,c,d);
        switch (a) {
            case 0: printf("0000 "); i1=0;i2=0;i3=0;i4=0;break;
            case 1: printf("0001 "); i1=0;i2=0;i3=0;i4=1;break;
            case 2: printf("0010 "); i1=0;i2=0;i3=1;i4=0;break;
            case 3: printf("0011 "); i1=0;i2=0;i3=1;i4=1;break;
            case 4: printf("0100 "); i1=0;i2=1;i3=0;i4=0;break;
            case 5: printf("0101 "); i1=0;i2=1;i3=0;i4=1;break;
            case 6: printf("0110 "); i1=0;i2=1;i3=1;i4=0;break;
            case 7: printf("0111 "); i1=0;i2=1;i3=1;i4=1;break;
            case 8: printf("1000 "); i1=1;i2=0;i3=0;i4=0;break;
            case 9: printf("1001 "); i1=1;i2=0;i3=0;i4=1;break;
            case 10: printf("1010 "); i1=1;i2=0;i3=1;i4=0;break;
            case 11: printf("1011 "); i1=1;i2=0;i3=1;i4=1;break;
            case 12: printf("1100 "); i1=1;i2=1;i3=0;i4=0;break;
            case 13: printf("1101 "); i1=1;i2=1;i3=0;i4=1;break;
            case 14: printf("1110 "); i1=1;i2=1;i3=1;i4=0;break;
            case 15: printf("1111 "); i1=1;i2=1;i3=1;i4=1;break;
	}
	switch (b) {
            case 0: printf("0000 "); i5=0;i6=0;i7=0;i8=0;break;
            case 1: printf("0001 "); i5=0;i6=0;i7=0;i8=1;break;
            case 2: printf("0010 "); i5=0;i6=0;i7=1;i8=0;break;
            case 3: printf("0011 "); i5=0;i6=0;i7=1;i8=1;break;
            case 4: printf("0100 "); i5=0;i6=1;i7=0;i8=0;break;
            case 5: printf("0101 "); i5=0;i6=1;i7=0;i8=1;break;
            case 6: printf("0110 "); i5=0;i6=1;i7=1;i8=0;break;
            case 7: printf("0111 "); i5=0;i6=1;i7=1;i8=1;break;
            case 8: printf("1000 "); i5=1;i6=0;i7=0;i8=0;break;
            case 9: printf("1001 "); i5=1;i6=0;i7=0;i8=1;break;
            case 10: printf("1010 "); i5=1;i6=0;i7=1;i8=0;break;
            case 11: printf("1011 "); i5=1;i6=0;i7=1;i8=1;break;
            case 12: printf("1100 "); i5=1;i6=1;i7=0;i8=0;break;
            case 13: printf("1101 "); i5=1;i6=1;i7=0;i8=1;break;
            case 14: printf("1110 "); i5=1;i6=1;i7=1;i8=0;break;
            case 15: printf("1111 "); i5=1;i6=1;i7=1;i8=1;break;
        }
	switch (c) {
            case 0: printf("0000 "); i9=0;i10=0;i11=0;i12=0;break;
            case 1: printf("0001 "); i9=0;i10=0;i11=0;i12=1;break;
            case 2: printf("0010 "); i9=0;i10=0;i11=1;i12=0;break;
            case 3: printf("0011 "); i9=0;i10=0;i11=1;i12=1;break;
            case 4: printf("0100 "); i9=0;i10=1;i11=0;i12=0;break;
            case 5: printf("0101 "); i9=0;i10=1;i11=0;i12=1;break;
            case 6: printf("0110 "); i9=0;i10=1;i11=1;i12=0;break;
            case 7: printf("0111 "); i9=0;i10=1;i11=1;i12=1;break;
            case 8: printf("1000 "); i9=1;i10=0;i11=0;i12=0;break;
            case 9: printf("1001 "); i9=1;i10=0;i11=0;i12=1;break;
            case 10: printf("1010 "); i9=1;i10=0;i11=1;i12=0;break;
            case 11: printf("1011 "); i9=1;i10=0;i11=1;i12=1;break;
            case 12: printf("1100 "); i9=1;i10=1;i11=0;i12=0;break;
            case 13: printf("1101 "); i9=1;i10=1;i11=0;i12=1;break;
            case 14: printf("1110 "); i9=1;i10=1;i11=1;i12=0;break;
            case 15: printf("1111 "); i9=1;i10=1;i11=1;i12=1;break;
        }
	switch (d) {
            case 0: printf("0000 "); i13=0;i14=0;i15=0;i16=0;break;
            case 1: printf("0001 "); i13=0;i14=0;i15=0;i16=1;break;
            case 2: printf("0010 "); i13=0;i14=0;i15=1;i16=0;break;
            case 3: printf("0011 "); i13=0;i14=0;i15=1;i16=1;break;
            case 4: printf("0100 "); i13=0;i14=1;i15=0;i16=0;break;
            case 5: printf("0101 "); i13=0;i14=1;i15=0;i16=1;break;
            case 6: printf("0110 "); i13=0;i14=1;i15=1;i16=0;break;
            case 7: printf("0111 "); i13=0;i14=1;i15=1;i16=1;break;
            case 8: printf("1000 "); i13=1;i14=0;i15=0;i16=0;break;
            case 9: printf("1001 "); i13=1;i14=0;i15=0;i16=1;break;
            case 10: printf("1010 "); i13=1;i14=0;i15=1;i16=0;break;
            case 11: printf("1011 "); i13=1;i14=0;i15=1;i16=1;break;
            case 12: printf("1100 "); i13=1;i14=1;i15=0;i16=0;break;
            case 13: printf("1101 "); i13=1;i14=1;i15=0;i16=1;break;
            case 14: printf("1110 "); i13=1;i14=1;i15=1;i16=0;break;
            case 15: printf("1111 "); i13=1;i14=1;i15=1;i16=1;break;
        }
	printf("\n");
	printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
	scanf("%d",&w);
	if(w==1){
		printf("Convert integer is:");
		if(i1==0)ans=i2*2*2*2*2*2*2*2*2*2*2*2*2*2*2+i3*2*2*2*2*2*2*2*2*2*2*2*2*2+i4*2*2*2*2*2*2*2*2*2*2*2*2+i5*2*2*2*2*2*2*2*2*2*2*2+i6*2*2*2*2*2*2*2*2*2*2+i7*2*2*2*2*2*2*2*2*2+i8*2*2*2*2*2*2*2*2+i9*2*2*2*2*2*2*2+i10*2*2*2*2*2*2+i11*2*2*2*2*2+i12*2*2*2*2+i13*2*2*2+i14*2*2+i15*2+i16;
		else{
			printf("-");
			if(i2==0) ans+=2*2*2*2*2*2*2*2*2*2*2*2*2*2;
			if(i3==0) ans+=2*2*2*2*2*2*2*2*2*2*2*2*2;
			if(i4==0) ans+=2*2*2*2*2*2*2*2*2*2*2*2;
			if(i5==0) ans+=2*2*2*2*2*2*2*2*2*2*2;
			if(i6==0) ans+=2*2*2*2*2*2*2*2*2*2;
			if(i7==0) ans+=2*2*2*2*2*2*2*2*2;
			if(i8==0) ans+=2*2*2*2*2*2*2*2;
			if(i9==0) ans+=2*2*2*2*2*2*2;
			if(i10==0) ans+=2*2*2*2*2*2;
			if(i11==0) ans+=2*2*2*2*2;
			if(i12==0) ans+=2*2*2*2;
			if(i13==0) ans+=2*2*2;
			if(i14==0) ans+=2*2;
			if(i15==0) ans+=2;
			if(i16==0) ans+=1;
			ans+=1;
		}
		printf("%d\n",ans);
	}
	if(w==2){
		printf("Converted unsigned integer is:");
                ans=i1*2*2*2*2*2*2*2*2*2*2*2*2*2*2*2+i2*2*2*2*2*2*2*2*2*2*2*2*2*2*2+i3*2*2*2*2*2*2*2*2*2*2*2*2*2+i4*2*2*2*2*2*2*2*2*2*2*2*2+i5*2*2*2*2*2*2*2*2*2*2*2+i6*2*2*2*2*2*2*2*2*2*2+i7*2*2*2*2*2*2*2*2*2+i8*2*2*2*2*2*2*2*2+i9*2*2*2*2*2*2*2+i10*2*2*2*2*2*2+i11*2*2*2*2*2+i12*2*2*2*2+i13*2*2*2+i14*2*2+i15*2+i16;
                printf("%d\n",ans);
        }
	if(w==3){
		printf("Converted float is:");
		if(i1==1) printf("-");
		exp=i2*2*2*2*2+i3*2*2*2+i4*2*2+i5*2+i6-15;
		F=1+i7*0.5+i8*0.25+i9*0.125+i10*0.0625+i11*0.03125+i12*0.015625+i13*0.0078125+i14*0.00390625+i15*0.001953125+i16*0.0009765625;
		if(exp==-15&&F==0) printf("0");
		else if(exp==16&&F==0) printf("\u221E\n");
		else if(exp==16&&F!=0) printf("NAN\n");
		else printf("%f*2^%d\n",F,exp);
	}	

 	return 0;
}
	 
