#include<stdio.h>
#include<stdint.h>
int main(){
	int32_t a,b,c,s,d,e,f,g,x,y,z;
	printf("Please enter the first operand:");
	scanf("%dx%d",&a,&b);
	printf("Please enter the second operand:");
        scanf(" y%dz",&c);
//	printf("%d,%d,%d",a,b,c);
	printf("Please enter the sum:");
	scanf("%d",&s);
	d=s/1000;
	e=(s/100)%10;
	f=(s/10)%10;
	g=s%10;
//	printf("%d,%d,%d,%d",d,e,f,g);
	if(g-b<0){
		z=g+10-b;
		f-=1;
	}else{
		z=g-b;
	}
	if(f-c<0){
		x=f+10-c;
		e-=1;
	}else{
		x=f-c;
	}
	if(e-a<0){
		y=e+10-a;
	}else{
		y=e-a;
	}
	printf("x=%d,y=%d,z=%d\n",x,y,z);
	return 0;
}
