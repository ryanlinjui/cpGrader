#include<stdio.h>
#include<stdint.h>
int main(){
	int32_t a,b,c,d,e,f,sa,sb,sc,sd,se;
	printf( "Please enter 5 cards (1-54):\n" );
    	scanf( "%d %d %d %d %d",&a,&b,&c,&d,&e );
	if(a<1||b<1||c<1||d<1||e<1) {
		printf( "Wrong Input!\n" );
       		 return 0;
	}
	if(a>54||b>54||c>54||d>54||e>54) {
                printf( "Wrong Input!\n" );
                 return 0;
        }
	//suit
	sa=(a-1)/13;
	sb=(b-1)/13;
	sc=(c-1)/13;
	sd=(d-1)/13;
	se=(e-1)/13;
	if(a%13>b%13){
		f=b;
		b=a;
		a=f;
	}
	if(a%13>c%13){  
                f=c;
                c=a;
                a=f;
        }
	if(a%13>d%13){
                f=d;
                d=a;
                a=f;
        }
	if(a%13>e%13){
                f=e;
                e=a;
                a=f;
        }
	if(b%13>c%13){  
                f=c;
                c=b;
                b=f;
        }
        if(b%13>d%13){
                f=d;
                d=b;
                b=f;
        }
        if(b%13>e%13){
                f=e;
                e=b;
                b=f;
        }
        if(c%13>d%13){
                f=d;
                d=c;
                c=f;
        }
	if(c%13>e%13){
                f=e;
                e=c;
                c=f;
        }
	if(d%13>e%13){
                f=e;
                e=d;
                d=f;
        }

	if(sa==sb&&sb==sc&&sc==sd&&sd==se){
		if(b-a==1&&c-b==1&&d-c==1&&e-d==1) printf("Straight Flush\n");
		else if(a%13==10&&b%13==11&&c%13==12&&d%13==0&&e%13==1) printf("Straight Flush\n");
/*		else if(a%13==11&&b%13==12&&c%13==0&&d%13==1&&e%13==2) printf("Flush\n");
		else if(a%13==12&&b%13==0&&c%13==1&&d%13==2&&e%13==3) printf("Flush\n");
		else if(a%13==0&&b%13==1&&c%13==2&&d%13==3&&e%13==4) printf("Flush\n");*/
		else printf("Flush\n");		
	}else{
		if(b%13-a%13==1&&c%13-b%13==1&&d%13-c%13==1&&e%13-d%13==1) printf("Straight\n");
                else if(a%13==10&&b%13==11&&c%13==12&&d%13==0&&e%13==1) printf("Straight\n");
                else if(a%13==11&&b%13==12&&c%13==0&&d%13==1&&e%13==2) printf("Straight\n");
                else if(a%13==12&&b%13==0&&c%13==1&&d%13==2&&e%13==3) printf("Straight\n");
                else if(a%13==0&&b%13==1&&c%13==2&&d%13==3&&e%13==4) printf("Straight\n");
	}

	if(a%13==b%13&&b%13==c%13&&c%13==d%13&&d%13!=e%13) printf("Four of a kind\n");
	else if(a%13==b%13&&b%13==c%13&&c%13==e%13&&d%13!=e%13) printf("Four of a kind\n");
	else if(a%13==b%13&&b%13==d%13&&d%13==e%13&&c%13!=e%13) printf("Four of a kind\n");
	else if(a%13==c%13&&c%13==d%13&&d%13==e%13&&b%13!=e%13) printf("Four of a kind\n");
	else if(b%13==c%13&&c%13==d%13&&d%13==e%13&&a%13!=e%13) printf("Four of a kind\n");
	else{
		if(a%13==b%13&&b%13==c%13&&c%13!=d%13&&d%13!=e%13) printf("Three of a kind\n");
        	if(a%13!=b%13&&b%13==c%13&&c%13==d%13&&d%13!=e%13) printf("Three of a kind\n");
        	if(a%13!=b%13&&b%13!=c%13&&c%13==d%13&&d%13==e%13) printf("Three of a kind\n");
	}

	if(a%13==b%13&&b%13==c%13&&c%13!=d%13&&d%13==e%13) printf("Full house\n");
	else if(a%13==b%13&&b%13!=c%13&&c%13==d%13&&d%13==e%13) printf("Full house\n");

	if(a%13==b%13&&b%13!=c%13&&c%13==d%13&&d%13!=e%13&&e%13!=a%13) printf("Two pairs\n");
	else if(a%13!=b%13&&b%13==c%13&&c%13!=d%13&&d%13==e%13&&e%13!=a%13) printf("Two pairs\n");
	else if(a%13==b%13&&b%13!=c%13&&c%13!=d%13&&d%13==e%13) printf("Two pairs\n");

	if(a%13==b%13&&b%13!=c%13&&c%13!=d%13&&d%13!=e%13) printf("One pair\n");
	else if(a%13!=b%13&&b%13==c%13&&c%13!=d%13&&d%13!=e%13) printf("One pair\n");
	else if(a%13!=b%13&&b%13!=c%13&&c%13==d%13&&d%13!=e%13) printf("One pair\n");
	else if(a%13!=b%13&&b%13!=c%13&&c%13!=d%13&&d%13==e%13) printf("One pair\n");
	else if(sa!=sb||sb!=sc||sc!=sd||sd!=se) printf("High card\n");
	return 0;
}

