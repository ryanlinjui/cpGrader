#include<stdio.h>
 int main(){
	 printf("\033[1;31m");
	 printf("[Kim]\n");
	 printf("You are sunlight and I moon\n");
	 printf("Joined by the gods of fortune\n");
	 printf("Midnight and high noon sharing the sky\n");
	 printf("We have been blessed , you and I\n");
	 printf("\033[1;33m");
	 printf("\n[CHRIS]\n");
	 printf("You are here like a mystery\n");
	 printf("I'm from a world that's so different from all that you are\n");
	 printf("How in the light of one night did we come so far?\n");
	 printf("\033[1;31m");
         printf("\n[KIM]\n");
	 printf("Outside day starts to dawn\n");
	 printf("\033[1;33m");
         printf("\n[CHRIS]\n");
	 printf("Your moon still floats on high\n");
	 printf("\033[1;31m");
         printf("\n[Kim]\n");
	 printf("The birds awake\n");
	 printf("\033[1;33m");
         printf("\n[CHRIS]\n");
	 printf("The stars shine too\n");
	 printf("\033[1;31m");
         printf("\n[Kim]\n");
	 printf("My hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n");
	 printf("\nYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho’s Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n");
	 printf("\033[1;33m");
         printf("\n[CHRIS]\n");
	 printf("I reach for you\n");
	 printf("\033[1;32m");
         printf("\n[KIM & CHRIS]\n");
	 printf("And we meet in the sky\n");
	 printf("\033[1;31m");
         printf("\n[Kim]\n");
	 printf("You are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n");
	 printf("\033[1;32m");
         printf("\n[KIM & CHRIS]\n");
	 printf("Made of\nSunlight\nMoonlight\n");
	 return 0;

 }
