#include<stdio.h>
#include<stdint.h>
int main(){
	int32_t x,a,b,c,d,e,f,sum;
	printf("Please enter an unsigned 16-bits number:");
	scanf("%d",&x);
	printf("Before Flip:\n%d_10 = %o_8\n",x,x);
	a=x%(8*8*8*8*8*8)/(8*8*8*8*8);
	b=x%(8*8*8*8*8)/(8*8*8*8);
	c=x%(8*8*8*8)/(8*8*8);
	d=x%(8*8*8)/(8*8);
	e=x%(8*8)/8;
	f=x%8;
	printf("After Flip:\n");
	if(a!=0){
		if(f!=0) printf("%d%d%d%d%d%d_8 =",f,e,d,c,b,a);
		else if(f==0&&e!=0) printf("%d%d%d%d%d_8 =",e,d,c,b,a);
		else if(f==0&&e==0&&d!=0) printf("%d%d%d%d_8 =",d,c,b,a);
		else if(f==0&&e==0&&d==0&&c!=0) printf("%d%d%d_8 =",c,b,a);
		else if(f==0&&e==0&&d==0&&c==0&&b!=0) printf("%d%d_8 =",b,a);
		else if(f==0&&e==0&&d==0&&c==0&&b==0&&a!=0) printf("%d_8 =",a);
		sum=f*8*8*8*8*8+e*8*8*8*8+d*8*8*8+c*8*8+b*8+a;
	}else if(a==0&&b!=0){
		if(f!=0) printf("%d%d%d%d%d_8 =",f,e,d,c,b);
                else if(f==0&&e!=0) printf("%d%d%d%d_8 =",e,d,c,b);
                else if(f==0&&e==0&&d!=0) printf("%d%d%d_8 =",d,c,b);
                else if(f==0&&e==0&&d==0&&c!=0) printf("%d%d_8 =",c,b);
                else if(f==0&&e==0&&d==0&&c==0&&b!=0) printf("%d_8 =",b);
                sum=f*8*8*8*8+e*8*8*8+d*8*8+c*8+b;
	}else if(a==0&&b==0&&c!=0){
		if(f!=0) printf("%d%d%d%d_8 =",f,e,d,c);
                else if(f==0&&e!=0) printf("%d%d%d_8 =",e,d,c);
                else if(f==0&&e==0&&d!=0) printf("%d%d_8 =",d,c);
                else if(f==0&&e==0&&d==0&&c!=0) printf("%d_8 =",c);
                sum=f*8*8*8+e*8*8+d*8+c;
	}else if(a==0&&b==0&&c==0&&d!=0){
		if(f!=0) printf("%d%d%d_8 =",f,e,d);
                else if(f==0&&e!=0) printf("%d%d_8 =",e,d);
                else if(f==0&&e==0&&d!=0) printf("%d_8 =",d);
                sum=f*8*8+e*8+d;
	}else if(a==0&&b==0&&c==0&&d==0&&e!=0){
		if(f!=0) printf("%d%d_8 =",f,e);
                else if(f==0&&e!=0) printf("%d_8 =",e);
                sum=f*8+e;
	}else if(a==0&&b==0&&c==0&&d==0&&e==0&&f!=0){
                printf("%d_8 =",f);
                sum=f;
	}else if(a==0&&b==0&&c==0&&d==0&&e==0&&f==0){
                printf("%d_8 =",f);
                sum=f;
        }
	printf(" %d_10\n",sum);
	return 0;
}

