-----------------
Author:
41347029S
許宸暟
-----------------

Guide:
	hw0101:
		run hw0101

	hw0102:
		input axb ,ycz , sum respectively
		a,b,c==number variable
	
	hw0103:
		input a 16bit-integer

	hw0104:
		input 5 integer in 1-52 represent 52 card

	hw0105:
		input a 16bit-hexadecimal then choose the desire convert form

	hw0106:
		when use make command add parameter -i