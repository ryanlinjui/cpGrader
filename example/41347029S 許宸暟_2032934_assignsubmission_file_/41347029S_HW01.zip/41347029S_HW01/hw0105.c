#include<stdio.h>
#include<stdint.h>
//num 48-57 65-70
int main(){
    int32_t b=0,b1=10000,b2=10000,b3=10000,b4=10000,ct=1,bt;
    char a=0,a1=0,a2=0,a3=0,a4=0;
    printf("Please input a hex:");
    int32_t t=scanf("%c%c%c%c",&a1,&a2,&a3,&a4);
    if(a1==1){printf("NG input!!!!!\n");return 0;}//(a>70&&a<97)||a>102
    else if(a1<48||(a1>57&&a1<65)||(a1>70&&a1<97)||a1>102){printf("NG input!!!!!\n");return 0;}
    if(a2!=0){ct++;if(a2<48||(a2>57&&a2<65)||(a2>70&&a2<97)||a2>102){printf("NG input!!!!!\n");return 0;}}
    if(a3!=0){ct++;if(a3<48||(a3>57&&a3<65)||(a3>70&&a3<97)||a3>102){printf("NG input!!!!!\n");return 0;}}
    if(a4!=0){ct++;if(a4<48||(a4>57&&a4<65)||(a4>70&&a4<97)||a4>102){printf("NG input!!!!!\n");return 0;}}
    printf("Please choose the output type(1:integer,2:unsigned integer,3:float):");
    t=scanf("%d",&b);
    if(t==0||b<1||b>3){printf("NG input!!!!!\n");return 0;}
    printf("Binary of %c%c%c%c is:", a1,a2,a3,a4);
    if(ct>=1){
        a=a1;
        if(a=='0'){printf("0000");b4=10000;}
        else if(a=='1'){printf("0001");b4=10001;}
        else if(a=='2'){printf("0010");b4=10010;}
        else if(a=='3'){printf("0011");b4=10011;}
        else if(a=='4'){printf("0100");b4=10100;}
        else if(a=='5'){printf("0101");b4=10101;}
        else if(a=='6'){printf("0110");b4=10110;}
        else if(a=='7'){printf("0111");b4=10111;}
        else if(a=='8'){printf("1000");b4=11000;}
        else if(a=='9'){printf("1001");b4=11001;}
        else if(a=='A'||a=='a'){printf("1010");b4=11010;}
        else if(a=='B'||a=='b'){printf("1011");b4=11011;}
        else if(a=='C'||a=='c'){printf("1100");b4=11100;}
        else if(a=='D'||a=='d'){printf("1101");b4=11101;}
        else if(a=='E'||a=='e'){printf("1110");b4=11110;}
        else if(a=='F'||a=='f'){printf("1111");b4=11111;}
    }
    else{printf("0000");}
    printf(" ");
    if(ct>=2){
        a=a2;
        if(a=='0'){printf("0000");b3=10000;}
        else if(a=='1'){printf("0001");b3=10001;}
        else if(a=='2'){printf("0010");b3=10010;}
        else if(a=='3'){printf("0011");b3=10011;}
        else if(a=='4'){printf("0100");b3=10100;}
        else if(a=='5'){printf("0101");b3=10101;}
        else if(a=='6'){printf("0110");b3=10110;}
        else if(a=='7'){printf("0111");b3=10111;}
        else if(a=='8'){printf("1000");b3=11000;}
        else if(a=='9'){printf("1001");b3=11001;}
        else if(a=='A'||a=='a'){printf("1010");b3=11010;}
        else if(a=='B'||a=='b'){printf("1011");b3=11011;}
        else if(a=='C'||a=='c'){printf("1100");b3=11100;}
        else if(a=='D'||a=='d'){printf("1101");b3=11101;}
        else if(a=='E'||a=='e'){printf("1110");b3=11110;}
        else if(a=='F'||a=='f'){printf("1111");b3=11111;}
    }
    else{printf("0000");}
    printf(" ");
    if(ct>=3){
        a=a3;
        if(a=='0'){printf("0000");b2=10000;}
        else if(a=='1'){printf("0001");b2=10001;}
        else if(a=='2'){printf("0010");b2=10010;}
        else if(a=='3'){printf("0011");b2=10011;}
        else if(a=='4'){printf("0100");b2=10100;}
        else if(a=='5'){printf("0101");b2=10101;}
        else if(a=='6'){printf("0110");b2=10110;}
        else if(a=='7'){printf("0111");b2=10111;}
        else if(a=='8'){printf("1000");b2=11000;}
        else if(a=='9'){printf("1001");b2=11001;}
        else if(a=='A'||a=='a'){printf("1010");b2=11010;}
        else if(a=='B'||a=='b'){printf("1011");b2=11011;}
        else if(a=='C'||a=='c'){printf("1100");b2=11100;}
        else if(a=='D'||a=='d'){printf("1101");b2=11101;}
        else if(a=='E'||a=='e'){printf("1110");b2=11110;}
        else if(a=='F'||a=='f'){printf("1111");b2=11111;}
    }
    else{printf("0000");}
    printf(" ");
    if(ct>=4){
        a=a4;
        if(a=='0'){printf("0000");b1=10000;}
        else if(a=='1'){printf("0001");b1=10001;}
        else if(a=='2'){printf("0010");b1=10010;}
        else if(a=='3'){printf("0011");b1=10011;}
        else if(a=='4'){printf("0100");b1=10100;}
        else if(a=='5'){printf("0101");b1=10101;}
        else if(a=='6'){printf("0110");b1=10110;}
        else if(a=='7'){printf("0111");b1=10111;}
        else if(a=='8'){printf("1000");b1=11000;}
        else if(a=='9'){printf("1001");b1=11001;}
        else if(a=='A'||a=='a'){printf("1010");b1=11010;}
        else if(a=='B'||a=='b'){printf("1011");b1=11011;}
        else if(a=='C'||a=='c'){printf("1100");b1=11100;}
        else if(a=='D'||a=='d'){printf("1101");b1=11101;}
        else if(a=='E'||a=='e'){printf("1110");b1=11110;}
        else if(a=='F'||a=='f'){printf("1111");b1=11111;}
    }
    else{printf("0000");}
    printf("\n");
    int32_t tt=0;
    double td=1.0;
    if(b==1){
        if((b4/1000)%10==1){//neg
            if((b1/1000)%10==0){tt+=8;}
            if((b1/100)%10==0){tt+=4;}
            if((b1/10)%10==0){tt+=2;}
            if(b1%10==0){tt+=1;}

            if((b2/1000)%10==0){tt+=128;}
            if((b2/100)%10==0){tt+=64;}
            if((b2/10)%10==0){tt+=32;}
            if(b2%10==0){tt+=16;}
            
            if((b3/1000)%10==0){tt+=2048;}
            if((b3/100)%10==0){tt+=1024;}
            if((b3/10)%10==0){tt+=512;}
            if(b3%10==0){tt+=256;}

            if((b4/100)%10==0){tt+=16384;}
            if((b4/10)%10==0){tt+=8192;}
            if(b4%10==0){tt+=4096;}
            tt++;
            tt*=-1;
        }
        else{
            if((b1/1000)%10==1){tt+=8;}
            if((b1/100)%10==1){tt+=4;}
            if((b1/10)%10==1){tt+=2;}
            if(b1%10==1){tt+=1;}

            if((b2/1000)%10==1){tt+=128;}
            if((b2/100)%10==1){tt+=64;}
            if((b2/10)%10==1){tt+=32;}
            if(b2%10==1){tt+=16;}
            
            if((b3/1000)%10==1){tt+=2048;}
            if((b3/100)%10==1){tt+=1024;}
            if((b3/10)%10==1){tt+=512;}
            if(b3%10==1){tt+=256;}

            if((b4/100)%10==1){tt+=16384;}
            if((b4/10)%10==1){tt+=8192;}
            if(b4%10==1){tt+=4096;}
        }
        printf("Converted integer is:%d\n", tt);
        return 0;
    }
    else if(b==2){
        if((b1/1000)%10==1){tt+=8;}
        if((b1/100)%10==1){tt+=4;}
        if((b1/10)%10==1){tt+=2;}
        if(b1%10==1){tt+=1;}

        if((b2/1000)%10==1){tt+=128;}
        if((b2/100)%10==1){tt+=64;}
        if((b2/10)%10==1){tt+=32;}
        if(b2%10==1){tt+=16;}
            
        if((b3/1000)%10==1){tt+=2048;}
        if((b3/100)%10==1){tt+=1024;}
        if((b3/10)%10==1){tt+=512;}
        if(b3%10==1){tt+=256;}

        if((b4/1000)%10==1){tt+=32768;}
        if((b4/100)%10==1){tt+=16384;}
        if((b4/10)%10==1){tt+=8192;}
        if(b4%10==1){tt+=4096;}
        printf("Converted unsigned integer is:%d\n",tt);
        return 0;
    }
    else{//wrong way
        printf("Converted float is:");
        //tt is exp
        if((b3/1000)%10==1){tt+=2;}
        if((b3/100)%10==1){tt+=1;}

        if((b4/100)%10==1){tt+=16;}
        if((b4/10)%10==1){tt+=8;}
        if(b4%10==1){tt+=4;}

        if((b1/1000)%10==1){td+=0.0078125;}
        if((b1/100)%10==1){td+=0.00390625;}
        if((b1/10)%10==1){td+=0.001953125;}
        if(b1%10==1){td+=0.0009765625;}

        if((b2/1000)%10==1){td+=0.125;}
        if((b2/100)%10==1){td+=0.0625;}
        if((b2/10)%10==1){td+=0.03125;}
        if(b2%10==1){td+=0.015625;}
            
        if((b3/10)%10==1){td+=0.5;}
        if(b3%10==1){td+=0.25;}
        
        if(tt==31&&td!=1){printf("NAN\n");return 0;}
        if((b4/1000)%10==1){printf("-");}
        if(tt==31&&td==1){printf("INF\n");return 0;}
        if(td==1&&tt==0){printf("0.0\n");return 0;}
        else{if(tt==0){td-=1;tt+=1;}printf("%f*2^%d\n",td,(tt-15));return 0;}
    }
    //use char 16bit
}