#include<stdio.h>
#include<stdint.h>

int main(){
    int32_t a=-1,b=-1,c=-1,d=-1,x,y,z,t=0;
    printf("please input 1st operand:");
    scanf("%dx%d", &a , &b);
    printf("please input 2nd operand:");
    scanf("\ny%dz",&c);
    printf("please input the sum:");
    scanf("%d",&d);
    if(a>9||a<0||b>9||b<0||c>9||c<0){printf("NG input!!\n");return 0;}
    t=d%10;
    if(t<b){
        d-=10;
        t+=10;
    }
    z=t-b;
    d/=10;
    t=d%10;
    if(t<c){
        d-=10;
        t+=10;
    }
    x=t-c;
    d/=10;
    t=d;
    if(t<a){printf("NG input.");return 0;}
    y=t-a;
    printf("ANS x==%d y==%d z==%d\n", x,y,z);

}
