#include<stdio.h>
#include<stdint.h>
/////////jqka2 10jqa 
int main(){
    int32_t h1=-1,h2=-1,h3=-1,h4=-1,h5=-1,p1,p2,p3,p4,p5,n1,n2,n3,n4,n5,t;
    printf("Please enter 5 cards:");
    scanf("%d %d %d %d %d",&h1,&h2,&h3,&h4,&h5);
    if(h1<1||h1>52||h2<1||h2>52||h3<1||h3>52||h4<1||h4>52||h5<1||h5>52){printf("NG input!!!!\n");return 0;}
    if(h1==h2||h1==h3||h1==h4||h1==h5||h2==h3||h2==h4||h2==h5||h3==h4||h3==h5||h4==h5){printf("NG input!!!!\n");return 0;}
    p1=(h1-1)/13;
    p2=(h2-1)/13;
    p3=(h3-1)/13;
    p4=(h4-1)/13;
    p5=(h5-1)/13;
    n1=(h1-1)%13+1;
    n2=(h2-1)%13+1;
    n3=(h3-1)%13+1;
    n4=(h4-1)%13+1;
    n5=(h5-1)%13+1;

    if(n1>n2){
        t=p1;p1=p2;p2=t;
        t=n1;n1=n2;n2=t;
    }
    if(n2>n3){
        t=p2;p2=p3;p3=t;
        t=n2;n2=n3;n3=t;
    }
    if(n3>n4){
        t=p3;p3=p4;p4=t;
        t=n3;n3=n4;n4=t;
    }
    if(n4>n5){
        t=p4;p4=p5;p5=t;
        t=n4;n4=n5;n5=t;
    }
    if(n1>n2){
        t=p1;p1=p2;p2=t;
        t=n1;n1=n2;n2=t;
    }
    if(n2>n3){
        t=p2;p2=p3;p3=t;
        t=n2;n2=n3;n3=t;
    }
    if(n3>n4){
        t=p3;p3=p4;p4=t;
        t=n3;n3=n4;n4=t;
    }
    if(n1>n2){
        t=p1;p1=p2;p2=t;
        t=n1;n1=n2;n2=t;
    }
    if(n2>n3){
        t=p2;p2=p3;p3=t;
        t=n2;n2=n3;n3=t;
    }
    if(n1>n2){
        t=p1;p1=p2;p2=t;
        t=n1;n1=n2;n2=t;
    }

    if(p1==p2&&p1==p3&&p1==p4&&p1==p5){
        if(n1+1==n2&&n2+1==n3&&n3+1==n4&&n4+1==n5||(n1==1&&n2==2&&n3==11&&n4==12&&n5==13)||(n1==1&&n2==10&&n3==11&&n4==12&&n5==13)){
            printf("Straight flush\n");
            return 0;
        }
        else{
            printf("Flush\n");
            return 0;
        }
    }
    else{
        if(n1+1==n2&&n2+1==n3&&n3+1==n4&&n4+1==n5||(n1==1&&n2==2&&n3==11&&n4==12&&n5==13)||(n1==1&&n2==10&&n3==11&&n4==12&&n5==13)){
            printf("Straight\n");
            return 0;
        }

        if(n1!=n2&&n2!=n3&&n3!=n4&&n4!=n5){
            printf("High card\n");
            return 0;
        }
        if((n1==n2&&n2==n3&&n3==n4)||(n1==n2&&n2==n3&&n3==n5)||(n1==n2&&n2==n4&&n4==n5)||(n1==n3&&n3==n4&&n4==n5)||(n2==n3&&n3==n4&&n4==n5)){
            printf("Four of a kind\n");
            return 0;
        }

        if(n2==n3&&n3==n4){
            printf("Three of a kind\n");
            return 0;
        }
        if(n1==n2&&n2==n3){
            if(n4==n5){
                printf("Full house\n");
                return 0;
            }
            else{
                printf("Three of a kind\n");
                return 0;
            }
        }
        if(n3==n4&&n4==n5){
            if(n1==n2){
                printf("Full house\n");
                return 0;
            }
            else{
                printf("Three of a kind\n");
                return 0;
            }
        }
        t=0;
        if(n1==n2){
            t++;
        }
        if(n2==n3){
            t++;
        }
        if(n3==n4){
            t++;
        }
        if(n4==n5){
            t++;
        }
        if(t==2){
            printf("Two pair\n");
            return 0;
        }
        else if(t==1){
            printf("One pair\n");
            return 0;
        }
        else{
            printf("High card\n");
            return 0;
        }
    }
}