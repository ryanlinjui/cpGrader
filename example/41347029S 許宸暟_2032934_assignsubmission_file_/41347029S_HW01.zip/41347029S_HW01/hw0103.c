#include<stdio.h>
#include<stdint.h>

int main(){
    int32_t a=-1,ct=0;
    printf("please input an unsigned 16-bits number:");
    scanf("%d",&a);
    if(a<0||a>65535){printf("NG input!!!\n");return 0;}
    printf("Before Flip:\n%d_8 = ", a);
    ct=printf("%o", a);
    printf("_10\n");
    int32_t nf=0,n=0,d=0;
    if(ct==1){
        nf+=a%8;
    }
    else if(ct==2){
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
    }
    else if(ct==3){
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
    }
    else if(ct==4){
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
    }
    else if(ct==5){
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
    }
    else if(ct==6){
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
        a/=8;
        nf*=10;
        nf+=a%8;
    }
    printf("After Flip:\n%d_8 = ", nf);
    if(ct==1){
        d+=nf%10;
    }
    else if(ct==2){
        d+=nf%10;
        nf/=10;
        d+=(nf%10)*8;
    }
    else if(ct==3){
        d+=nf%10;
        nf/=10;
        d+=(nf%10)*8;
        nf/=10;
        d+=(nf%10)*64;
    }
    else if(ct==4){
        d+=nf%10;
        nf/=10;
        d+=(nf%10)*8;
        nf/=10;
        d+=(nf%10)*64;
        nf/=10;
        d+=(nf%10)*512;
    }
    else if(ct==5){
        d+=nf%10;
        nf/=10;
        d+=(nf%10)*8;
        nf/=10;
        d+=(nf%10)*64;
        nf/=10;
        d+=(nf%10)*512;
        nf/=10;
        d+=(nf%10)*4096;
    }
    else if(ct==6){
        d+=nf%10;
        nf/=10;
        d+=(nf%10)*8;
        nf/=10;
        d+=(nf%10)*64;
        nf/=10;
        d+=(nf%10)*512;
        nf/=10;
        d+=(nf%10)*4096;
        nf/=10;
        d+=(nf%10)*32768;
    }
    printf("%d_10", d);
}