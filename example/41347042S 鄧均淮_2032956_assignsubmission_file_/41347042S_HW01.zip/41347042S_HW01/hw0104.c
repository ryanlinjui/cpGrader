#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>


int main(){
	
	uint16_t k1=0,k2=0,k3=0,k4=0,k5=0;
	printf("Please enter 5 cards: ");
	if(scanf("%hd %hd %hd %hd %hd",&k5,&k4,&k3,&k2,&k1) !=5){
		printf("error input\n");
		return 0;
	}
	
	if(k1<1 || 52<k1){
		printf("error input\n");
		return 0;
	}
	if(k2<1 || 52<k2){
		printf("error input\n");
		return 0;
	}
	if(k3<1 || 52<k3){
		printf("error input\n");
		return 0;
	}
	if(k4<1 || 52<k4){
		printf("error input\n");
		return 0;
	}
	if(k5<1 || 52<k5){
		printf("error input\n");
		return 0;
	}
	
	uint16_t S=0,H=0,B=0,C=0; //方塊  愛心 黑桃 梅花
	uint16_t nA=0,n2=0,n3=0,n4=0,n5=0,n6=0,n7=0,n8=0,n9=0,n10=0,nJ=0,nQ=0,nK=0;
	
	if(1 <= k1 && k1 <= 13){
		B++;
	}else if(14 <= k1 && k1 <= 26){
		H++;
	}else if(27 <= k1 && k1 <= 39){
		S++;
	}else if(40 <= k1 && k1 <= 52){
		C++;
	}
	
	if(1 <= k2 && k2<= 13){
		B++;
	}else if(14 <= k2 && k2 <= 26){
		H++;
	}else if(27 <= k2 && k2 <= 39){
		S++;
	}else if(40 <= k2 && k2 <= 52){
		C++;
	}
	
	if(1 <= k3 && k3<= 13){
		B++;
	}else if(14 <= k3 && k3 <= 26){
		H++;
	}else if(27 <= k3 && k3 <= 39){
		S++;
	}else if(40 <= k3 && k3 <= 52){
		C++;
	}
	
	if(1 <= k4 && k4<= 13){
		B++;
	}else if(14 <= k4 && k4 <= 26){
		H++;
	}else if(27 <= k4 && k4 <= 39){
		S++;
	}else if(40 <= k4 && k4 <= 52){
		C++;
	}
	
	if(1 <= k5 && k5<= 13){
		B++;
	}else if(14 <= k5 && k5 <= 26){
		H++;
	}else if(27 <= k5 && k5 <= 39){
		S++;
	}else if(40 <= k5 && k5 <= 52){
		C++;
	}
	
	switch((k1-1)%13){
		
		case 0:
			nA++;
			break;
		case 1:
			n2++;
			break;
		case 2:
			n3++;
			break;
		case 3:
			n4++;
			break;
		case 4:
			n5++;
			break;
		case 5:
			n6++;
			break;
		case 6:
			n7++;
			break;
		case 7:
			n8++;
			break;
		case 8:
			n9++;
			break;
		case 9:
			n10++;
			break;
		case 10:
			nJ++;
			break;
		case 11:
			nQ++;
			break;
		case 12:
			nK++;
			break;
			
	}
	
	switch((k2-1)%13){
		
		case 0:
			nA++;
			break;
		case 1:
			n2++;
			break;
		case 2:
			n3++;
			break;
		case 3:
			n4++;
			break;
		case 4:
			n5++;
			break;
		case 5:
			n6++;
			break;
		case 6:
			n7++;
			break;
		case 7:
			n8++;
			break;
		case 8:
			n9++;
			break;
		case 9:
			n10++;
			break;
		case 10:
			nJ++;
			break;
		case 11:
			nQ++;
			break;
		case 12:
			nK++;
			break;
			
	}
	switch((k3-1)%13){
		
		case 0:
			nA++;
			break;
		case 1:
			n2++;
			break;
		case 2:
			n3++;
			break;
		case 3:
			n4++;
			break;
		case 4:
			n5++;
			break;
		case 5:
			n6++;
			break;
		case 6:
			n7++;
			break;
		case 7:
			n8++;
			break;
		case 8:
			n9++;
			break;
		case 9:
			n10++;
			break;
		case 10:
			nJ++;
			break;
		case 11:
			nQ++;
			break;
		case 12:
			nK++;
			break;
			
	}
	switch((k4-1)%13){
		
		case 0:
			nA++;
			break;
		case 1:
			n2++;
			break;
		case 2:
			n3++;
			break;
		case 3:
			n4++;
			break;
		case 4:
			n5++;
			break;
		case 5:
			n6++;
			break;
		case 6:
			n7++;
			break;
		case 7:
			n8++;
			break;
		case 8:
			n9++;
			break;
		case 9:
			n10++;
			break;
		case 10:
			nJ++;
			break;
		case 11:
			nQ++;
			break;
		case 12:
			nK++;
			break;
			
	}
	
	switch((k5-1)%13){
		
		case 0:
			nA++;
			break;
		case 1:
			n2++;
			break;
		case 2:
			n3++;
			break;
		case 3:
			n4++;
			break;
		case 4:
			n5++;
			break;
		case 5:
			n6++;
			break;
		case 6:
			n7++;
			break;
		case 7:
			n8++;
			break;
		case 8:
			n9++;
			break;
		case 9:
			n10++;
			break;
		case 10:
			nJ++;
			break;
		case 11:
			nQ++;
			break;
		case 12:
			nK++;
			break;
			
	}
	
	//printf("%d %d %d %d %d %d %d %d %d %d %d %d %d\n",nA,n2,n3,n4,n5,n6,n7,n8,n9,n10,nJ,nQ,nK);
	//SSprintf("%d %d %d %d\n",S,H,B,C);
	
	bool Straight = false , Flush = false;
	
	if(S == 5 || H == 5 || B == 5 || C == 5){
		Flush = true;
	}
	
	if(nA == 1 && n2 == 1 && n3 == 1 && n4 == 1 && n5 == 1){
		Straight = true;
	}else if(n2 == 1 && n3 == 1 && n4 == 1 && n5 == 1 && n6 == 1){
		Straight = true;
	}else if(n3 == 1 && n4 == 1 && n5 == 1 && n6 == 1 && n7 == 1){
		Straight = true;
	}else if(n4 == 1 && n5 == 1 && n6 == 1 && n7 == 1 && n8 == 1){
		Straight = true;
	}else if(n5 == 1 && n6 == 1 && n7 == 1 && n8 == 1 && n9 == 1){
		Straight = true;
	}else if(n6 == 1 && n7 == 1 && n8 == 1 && n9 == 1 && n10 == 1){
		Straight = true;
	}else if(n7 == 1 && n8 == 1 && n9 == 1 && n10 == 1 && nJ == 1){
		Straight = true;
	}else if(n8 == 1 && n9 == 1 && n10 == 1 && nJ == 1 && nQ == 1){
		Straight = true;
	}else if(n9 == 1 && n10 == 1 && nJ == 1 && nQ == 1 && nK == 1){
		Straight = true;
	}else if(n10 == 1 && nJ == 1 && nQ == 1 && nK == 1 && nA == 1){
		Straight = true;
	}
	
	if(Straight == true && Flush == true ){
		printf("Straight flush\n");
		return 0;
	}else if(Straight == true && Flush == false ){
		printf("Straight\n");
		return 0;
	}else if(Straight == false && Flush == true ){
		printf("Flush\n");
		return 0;
	}
	
	if(nA == 4 || n2 == 4 || n3 == 4 || n4 == 4 || n5 == 4 ||n6 == 4 || n7 == 4 || n8 == 4 || n9 == 4){
		printf("Four of a kind\n");
		return 0;
	}else if(n10 == 4 || nJ == 4 || nQ == 4 || nK == 4){
		printf("Four of a kind\n");
		return 0;
	}
	
	bool three_in_same = false , two_in_same = false;
	uint16_t pairs_num = 0;
	
	if(nA == 3 || n2 == 3 || n3 == 3 || n4 == 3 || n5 == 3 ||n6 == 3 || n7 == 3 || n8 == 3 || n9 == 3){
		three_in_same = true;
	}else if(n10 == 3 || nJ == 3 || nQ == 3|| nK == 3){
		three_in_same = true;
	}
	
	
	if(nA == 2){
		
		two_in_same = true;
		pairs_num++;
	}
	if(n2 == 2){
		two_in_same = true;
		pairs_num++;
	}
	if(n3 == 2){
		two_in_same = true;
		pairs_num++;
	} 
	if(n4 == 2){
		two_in_same = true;
		pairs_num++;
	}
	if(n5 == 2){
		two_in_same = true;
		pairs_num++;
	}
	if(n6 == 2){
		two_in_same = true;
		pairs_num++;
	}
	if(n7 == 2){
		two_in_same = true;
		pairs_num++;
	}
	if(n8 == 2){
		two_in_same = true;
		pairs_num++;
	}
	if(n9 == 2){
		two_in_same = true;
		pairs_num++;
	}
	if(n10 == 2){
		two_in_same = true;
		pairs_num++;
	}
	if(nJ == 2){
		two_in_same = true;
		pairs_num++;
	}
	if(nQ == 2){
		two_in_same = true;
		pairs_num++;
	}
	if(nK == 2){
		two_in_same = true;
		pairs_num++;
	}
	
	//printf("%d %d\n",three_in_same,two_in_same);
	
	if(three_in_same == true && two_in_same == true ){
		printf("Full house\n");
		return 0;
	}else if(three_in_same == true && two_in_same == false ){
		printf("Three of a kind\n");
		return 0;
	}else if(three_in_same == false && two_in_same == true ){
		if(pairs_num == 2){
			printf("Two pair\n");
			return 0;
		}else if(pairs_num == 1){
			printf("One pair\n");
			return 0;
		}
		
		
	}
	
	printf("High card\n");
	
	
	
	return 0;
}
