#include <stdio.h>

int main(){
	printf("\033[31m[KIM]\nYou are sunlight and I moon\n");
	printf("Joined by the gods of fortune\n");
	printf("Midnight and high noon sharing the sky\n");
	printf("We have been blessed , you and I\n");

	printf("\033[34m[CHRIS]\n");
 	printf("You are here like a mystery\n");
 	printf("I'm from a world that's so different from all that you are\n");
 	printf("How in the light of one night did we come so far?\n");

 	printf("\033[31m[KIM]\n");
 	printf("Outside day starts to dawn\n");
 	printf("\033[34m[CHRIS]\n");
 	printf("Your moon still floats on high\n");

	printf("\033[31m[KIM]\n");
 	printf("The birds awake\n");
	printf("\033[34m[CHRIS]\n");
 	printf("The stars shine too\n");
	printf("\033[31m[KIM]\n");
 	printf("My hands still shake\n");
 	printf("See upcoming pop shows\n");
 	printf("Get tickets for your favorite artists\n");

 	printf("You might also like\n");
 	printf("My Boy Only Breaks His Favorite Toys\n");
 	printf("Taylor Swift\n");
 	printf("Who’s Afraid of Little Old Me?\n");
 	printf("Taylor Swift\n");
 	printf("Guilty as Sin?\n");
 	printf("Taylor Swift\n");

	printf("\033[34m[CHRIS]\n");
 	printf("I reach for you\n");

 	printf("\033[32m[KIM & CHRIS]\n");
 	printf("And we meet in the sky\n");
	printf("\033[31m[KIM]\n");
 	printf("You are sunlight and I moon\n");
 	printf("Joined here\n");
 	printf("Brightening the sky with the flame of love\n");

	printf("\033[32m[KIM & CHRIS]\n");
 	printf("Made of\n");
 	printf("Sunlight\n");
 	printf("Moonlight\n");
		
		
	return 0;
}
