#include <stdio.h>
#include <stdint.h>

int main(){
	
	int32_t num=0,save=0,mode=0;
	printf("Please input a hex: ");
	if(scanf("%x",&num) != 1){
		printf("error input\n");
		return 0;
	
	}
	save = num;
	int32_t A1=0,A2=0,A3=0,A4=0,A5=0,A6=0,A7=0,A8=0,A9=0,A10=0,A11=0,A12=0,A13=0,A14=0,A15=0,A16=0;
	
	A16 = num % 2;
	num = num / 2;
	A15 = num % 2;
	num = num / 2;
	A14 = num % 2;
	num = num / 2;
	A13 = num % 2;
	num = num / 2;
	A12 = num % 2;
	num = num / 2;
	A11 = num % 2;
	num = num / 2;
	A10 = num % 2;
	num = num / 2;
	A9 = num % 2;
	num = num / 2;
	A8 = num % 2;
	num = num / 2;
	A7 = num % 2;
	num = num / 2;
	A6 = num % 2;
	num = num / 2;
	A5 = num % 2;
	num = num / 2;
	A4 = num % 2;
	num = num / 2;
	A3 = num % 2;
	num = num / 2;
	A2 = num % 2;
	num = num / 2;
	A1 = num % 2;
	
	printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float): "); //mode choose
	scanf("%d",&mode);
	
	printf("Binary of %X is: ",save);
	
	printf("%d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",A1,A2,A3,A4,A5,A6,A7,A8,A9,A10,A11,A12,A13,A14,A15,A16);
	
	
	
	if(mode == 1){
		
		if(A1 == 0){ //+
			int16_t number=0;
			number = A2*16384 + A3*8192 + A4*4096 + A5*2048 + A6*1024 + A7*512 + A8*256;
			number = number + A9*128 + A10*64 + A11*32 + A12*16 + A13*8 + A14*4 + A15*2 + A16*1;
			printf("Converted integer is: %d\n",number);
		}else if(A1 == 1){
			int16_t number=0;
			
			if(A1){
				A1 = 0;
			}else{
				A1 = 1;
			}
			
			if(A2){
				A2 = 0;
			}else{
				A2 = 1;
			}
			
			if(A3){
				A3 = 0;
			}else{
				A3 = 1;
			}
			
			if(A4){
				A4 = 0;
			}else{
				A4 = 1;
			}
			if(A5){
				A5 = 0;
			}else{
				A5 = 1;
			}
			
			if(A6){
				A6 = 0;
			}else{
				A6 = 1;
			}
			
			if(A7){
				A7 = 0;
			}else{
				A7 = 1;
			}
			
			if(A8){
				A8 = 0;
			}else{
				A8 = 1;
			}
			
			if(A9){
				A9 = 0;
			}else{
				A9 = 1;
			}
			
			if(A10){
				A10 = 0;
			}else{
				A10 = 1;
			}
			
			if(A11){
				A11 = 0;
			}else{
				A11 = 1;
			}
			
			if(A12){
				A12 = 0;
			}else{
				A12 = 1;
			}
			if(A13){
				A13 = 0;
			}else{
				A13 = 1;
			}
			
			if(A14){
				A14 = 0;
			}else{
				A14 = 1;
			}
			
			if(A15){
				A15 = 0;
			}else{
				A15 = 1;
			}
			
			if(A16){
				A16 = 0;
			}else{
				A16 = 1;
			}
			
			number = A1*32768 + A2*16384 + A3*8192 + A4*4096 + A5*2048 + A6*1024 + A7*512 + A8*256;
			number = number + A9*128 + A10*64 + A11*32 + A12*16 + A13*8 + A14*4 + A15*2 + A16*1;
			number++;
			printf("Converted integer is: -%d\n",number);
	
		}
			
	
	}
	
	if(mode == 2){
		
		uint16_t Number=0;
		Number = A1*32768 + A2*16384 + A3*8192 + A4*4096 + A5*2048 + A6*1024 + A7*512 + A8*256;
		Number = Number + A9*128 + A10*64 + A11*32 + A12*16 + A13*8 + A14*4 + A15*2 + A16*1;
		
		printf("%d\n",Number);
		printf("Converted unsigned integer is: %d\n",Number);
	
	}else if(mode == 3){
		float NumberF=0;
		int16_t EXP=0;
		EXP = 16*A2 + 8*A3 + 4*A4 + 2*A5 + 1*A6;
		NumberF = 1 + 0.00097656*A16 + 0.00195312*A15 + 0.00390625*A14 + 0.0078125*A13 +  0.015625*A12 + 0.03125*A11 + 0.0625*A10 + 0.125*A9 + 0.25*A8 + 0.5*A7;
		
		
		if(EXP == 0 && NumberF == 1.0){
			if(A1 == 1){ // negative
 		
				printf("Converted unsigned integer is: -0.000000\n"); //-1.233398*2^8
				return 0;
			}else{
				printf("Converted unsigned integer is: 0.000000\n");
				return 0;
			}
		}
		
		if(EXP == 31 && NumberF == 1.0){
			if(A1 == 1){ // negative
 		
				printf("Converted unsigned integer is: -INF\n"); //-1.233398*2^8
				return 0;
			}else{
				printf("Converted unsigned integer is: INF\n");
				return 0;
			}
		}
		
		if(EXP == 31 && NumberF != 1.0){
			printf("Converted unsigned integer is: NAN\n"); //-1.233398*2^8
			return 0;
		}
 		if(A1 == 1){ // negative
 		
			printf("Converted unsigned integer is: -%f*2^%d\n",NumberF,EXP - 15); //-1.233398*2^8
		}else{
			printf("Converted unsigned integer is: %f*2^%d\n",NumberF,EXP - 15);
		}
	
	}
		
	
	
	
	
	
	return 0;
}
