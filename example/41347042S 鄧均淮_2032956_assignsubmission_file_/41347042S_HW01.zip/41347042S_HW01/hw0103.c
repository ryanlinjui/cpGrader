#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

int main(){
	uint16_t number=0;
	printf("Please enter an unsigned 16-bits number:");
	if(scanf("%hd",&number)!=1){
		printf("error input!\n");
		return 0;
	}
	printf("Before Flip:\n");
	printf("%hd_10 = %o_8\n",number,number);
	printf("After Flip:\n");
	
	uint16_t t8_6=0,t8_5=0,t8_4=0,t8_3=0,t8_2=0,t8_1=0;
		if(number >= 32768){//6
			t8_6 = number % 8;
			number = number / 8 ;
			t8_5 = number % 8;
			number = number / 8 ;
			t8_4 = number % 8;
			number = number / 8 ;
			t8_3 = number % 8;
			number = number / 8 ;
			t8_2 = number % 8;
			number = number / 8 ;
			t8_1 = number % 8;
			number = number / 8 ;
		
		
		}else if(number >= 4096){ //5
			t8_5 = number % 8;
			number = number / 8 ;
			t8_4 = number % 8;
			number = number / 8 ;
			t8_3 = number % 8;
			number = number / 8 ;
			t8_2 = number % 8;
			number = number / 8 ;
			t8_1 = number % 8;
			number = number / 8 ;
		
		}else if(number >= 512){ //4
			t8_4 = number % 8;
			number = number / 8 ;
			t8_3 = number % 8;
			number = number / 8 ;
			t8_2 = number % 8;
			number = number / 8 ;
			t8_1 = number % 8;
			number = number / 8 ;
		
		}else if(number >= 64){ //3
			t8_3 = number % 8;
			number = number / 8 ;
			t8_2 = number % 8;
			number = number / 8 ;
			t8_1 = number % 8;
			number = number / 8 ;
		
		}else if(number >= 8){ //2
			t8_2 = number % 8;
			number = number / 8 ;
			t8_1 = number % 8;
			number = number / 8 ;
		
		}else{ //1
			t8_1 = number % 8;
			number = number / 8 ;
		
		}
	bool num_appear = false;
	if(t8_6!=0 || num_appear == true){
		printf("%d",t8_6);
		num_appear = true;
	}
	if(t8_5!=0 || num_appear == true){
		printf("%d",t8_5);
		num_appear = true;
	}
	if(t8_4!=0 || num_appear == true){
		printf("%d",t8_4);
		num_appear = true;
	}
	if(t8_3!=0 || num_appear == true){
		printf("%d",t8_3);
		num_appear = true;
	}
	if(t8_2!=0 || num_appear == true){
		printf("%d",t8_2);
		num_appear = true;
	}
	printf("%d_8",t8_1);
	printf(" = ");
	
	int new_number=0;
	
	new_number = t8_6 * 32768 + t8_5 * 4096 + t8_4 * 512 + t8_3 * 64 + t8_2 * 8 +  t8_1;
	
	printf("%d_10\n",new_number);	
	return 0;
}
