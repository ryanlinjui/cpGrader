#include <stdio.h>
#include <stdint.h>

int main(){
	
	int8_t a1=0,x=0,a3=0,y=0,b2=0,z=0;
	int64_t sum=0;
	printf("Please enter the first operand : ");
	if (scanf("%hhdx%hhd",&a1, &a3) != 2) {
        	printf("error input\n");
        	return 0;
    	}
    	scanf("%*c");
	if(a1>9 || a1<0 || a3>9 || a3<0){
		printf("error input\n");
		return 0;
	}
	
	printf("Please enter the second operand: ");
	if (scanf("y%hhdz", &b2) != 1) {
        	printf("error input\n");
        	return 0;
    	}
	scanf("%*c");
	if(b2>9 || b2<0 ){
		printf("error input\n");
		return 0;
	}
	
	printf("Please enter the sum           : ");
	if(scanf("%ld",&sum) != 1){
		printf("error input\n");
		return 0;
	}
	//scanf("%*c");
	fflush(stdin);
	if(sum>1998){
		printf("error input ( Max is 1998 => 999+999 = 1998)\n");
		return 0;
	}
	
	int8_t sum_1000=0,sum_100=0,sum_10=0,sum_1=0;
	if(sum>=1000){
		sum_1000 = sum/1000;
		sum -= sum_1000*1000;
	
	}
	sum_100 = sum/100;
	sum_10 = (sum - sum_100*100)/10;
	sum_1 = (sum - sum_100*100 - sum_10 *10);
	
	
	
	
	if(sum_1 < a3){ //有進位
		
		
		b2++;
		z = 10 + sum_1 - a3;	
	}else{
		z = sum_1 - a3;
	}
	if(sum_10 < b2){ //有進位
		a1++;
		x = 10 + sum_10 - b2;	
	}else{
		x = sum_10 - b2;
	} 
	
	if(sum_1000==1){ 
		sum_100 +=10;
		y = sum_100 - a1;
	}else{
		y = sum_100 - a1;
	} 
	
	printf("Ans: x = %hhd, y = %hhd, z = %hhd\n",x,y,z);
	
	



	return 0;
}
