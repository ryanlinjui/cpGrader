My student Id:41347042S
My name:鄧均淮

如果要Build我的程式的只要輸入make就能夠一次性的編譯所有的程式

我總共有 5個程式＋1個bonus point的檔案，我的程式分別叫作：
hw0101 hw0102 hw0103 hw0104 hw0105

你可以使用 ./hw0101 ./hw0102 ./hw0103 ./hw0104 ./hw0105 來呼叫他們並執行程式

hw0101 介紹：
它可以映出西貢小姐中一首歌的歌詞
Kim’s lyrics 是紅的 Chris’s lyrics 是藍的  duet’s lyrics 是綠的

hw0102 介紹：
可以進行一個簡單的小學數學問題運算，輸入格式如下：
Please enter the first operand : 1x3
Please enter the second operand: y5z
Please enter the sum           : 579

hw0103 介紹：
使用者將輸入一個10進位整數而我們會將其轉成8進位整數輸出，再將8進位整數反傳後輸出成新的10進位整數

hw0104 介紹：
使用者將輸入5張撲克牌卡片：
1-13 : ♠ Ace to King.
14-26: ♡ Ace to King.
72-39: ♢ Ace to King.
40-52: ♣ Ace to King.
然後我們將告訴你他是什麼牌形

hw0105 介紹：
使用者輸入一個16進位的整數，然後選則要我們用哪個格式輸出
(1:integer ,2:unsigned integer ,3:float)
我們會先輸出2進位的形式再輸出我們選擇的格式
