#include <stdio.h>
#include <stdint.h>
#include <math.h>
int main() {
    int32_t num;
    int32_t reversed = 0;

    printf("Please enter an unsigned 16-bits number: ");
    scanf("%u", &num);

    printf("Before Flip:\n");
    printf("%u_10 = %o_8\n", num, num);
    
   if(32768<=num&&num<=65535){
   		int digit1 = num % 8; num /= 8;  
    	int digit2 = num % 8; num /= 8;  
    	int digit3 = num % 8; num /= 8; 
    	int digit4 = num % 8; num /= 8;  
    	int digit5 = num % 8; num /= 8;  
    	int digit6 = num % 8; num /= 8;
    	 reversed = digit6+digit5 * pow(8,1)+ digit4 *pow(8,2)+ digit3 *pow(8,3)+ digit2 * pow(8,4)+ digit1*pow(8,5);}
    
	
    
    else if(4096<=num&&num<32768){
   		int32_t digit1 = num % 8; num /= 8;  
    	int32_t digit2 = num % 8; num /= 8;  
    	int32_t digit3 = num % 8; num /= 8; 
    	int32_t digit4 = num % 8; num /= 8;  
    	int32_t digit5 = num % 8; num /= 8; 
    	
    	 reversed =digit5 * pow(8,0)+ digit4 *pow(8,1)+ digit3 *pow(8,2)+ digit2 * pow(8,3)+ digit1*pow(8,4);}
    
	
    else if(512<=num&&num<4096){
   		int32_t digit1 = num % 8; num /= 8;  
    	int32_t digit2 = num % 8; num /= 8;  
    	int32_t digit3 = num % 8; num /= 8; 
        int32_t digit4 = num % 8; num /= 8;  
    	
    	
    	 reversed = digit4 *pow(8,0)+ digit3 *pow(8,1)+ digit2 * pow(8,2)+ digit1*pow(8,3);}
	 else if(64<=num&&num<512){
   		int32_t digit1 = num % 8; num /= 8;  
    	int32_t digit2 = num % 8; num /= 8;  
    	int32_t digit3 = num % 8; num /= 8; 
    	
    	
    	
    	 reversed = digit3 *pow(8,0)+ digit2 *pow(8,1)+ digit1 * pow(8,2);}
     else if(8<=num&&num<64){
   		int32_t digit1 = num % 8; num /= 8;  
    	int32_t digit2 = num % 8; num /= 8;  
    	 
    	
    	
    	
    	 reversed = digit2 *pow(8,0)+ digit1 *pow(8,1);}
    else if(0<=num&&num<8){
   		 reversed =num;}
    
    

    printf("After Flip:\n");
    printf("%o_8 = %u_10\n", reversed, reversed);

    return 0;
}

