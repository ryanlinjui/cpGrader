#include <stdio.h>
#include <stdint.h>
int main() {
    int32_t num1,num2,num3,sum;
    int32_t x,y,z;
    printf("Please enter the first operand:");
    scanf("%dx%d", &num1, &num2);
    if(num1<0||num1>9||num2<0||num2>9){
    	printf("error");
    	return 0;
	}
	getchar();
	printf("Please enter the second operand:");
    scanf("y%dz", &num3);
    getchar();
    if(num3<0||num3>9){
    	printf("error");
    	return 0;
	}

	printf("Please enter the sum:");
	scanf("%d", &sum);
	int unitplace=sum%10;
	int tenplace=sum/10%10;
	int hundredplace=sum/100%10;
	if(unitplace<num2&&tenplace<num3&&hundredplace<num1){
		z=10+unitplace-num2;
		x=10+tenplace-num3-1;
		y=10+hundredplace-num1-1;
		  
	}
	else if(unitplace>num2&&tenplace>num3&&hundredplace<num1){
		z=unitplace-num2;
		x=tenplace-num3;
		y=10+hundredplace-num1;
		  
	}
   else if(unitplace>num2&&tenplace<num3&&hundredplace>num1){
		z=unitplace-num2;
		x=10+tenplace-num3;
		y=hundredplace-num1-1;
		  
	}
	else if(unitplace<num2&&tenplace>num3&&hundredplace>num1){
		z=10+unitplace-num2;
		x=tenplace-num3-1;
		y=hundredplace-num1;
		  
	}
	else if(unitplace>num2&&tenplace<num3&&hundredplace<num1){
		z=unitplace-num2;
		x=10+tenplace-num3;
		y=10+hundredplace-num1-1;
		  
	}
	else if(unitplace<num2&&tenplace<num3&&hundredplace>num1){
		z=10+unitplace-num2;
		x=10+tenplace-num3-1;
		y=hundredplace-num1-1;
		  
	}
	else if(unitplace<num2&&tenplace>num3&&hundredplace<num1){
		z=10+unitplace-num2;
		x=tenplace-num3-1;
		y=10+hundredplace-num1;
		  
	}
	else if(unitplace>num2&&tenplace>num3&&hundredplace>num1){
		z=unitplace-num2;
		x=tenplace-num3;
		y=hundredplace-num1;
		  
	}
	printf("Ans: x = %d, y = %d, z = %d\n",x,y,z);
	return 0;}
