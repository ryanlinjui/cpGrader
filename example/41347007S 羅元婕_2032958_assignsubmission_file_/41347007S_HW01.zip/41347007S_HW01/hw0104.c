#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int32_t card1, card2, card3, card4, card5,min,min1;
	int32_t rank1, rank2, rank3, rank4, rank5;
	int suit1, suit2, suit3, suit4, suit5;
	printf("Please enter 5 cards:");
	scanf("%d%d%d%d%d",&card1,&card2,&card3,&card4,&card5);

  
    rank1 = (card1 - 1) % 13 + 1;
    rank2 = (card2 - 1) % 13 + 1;
    rank3 = (card3 - 1) % 13 + 1;
    rank4 = (card4 - 1) % 13 + 1;
    rank5 = (card5 - 1) % 13 + 1;
    
    suit1 = (card1 - 1) / 13;
    suit2 = (card2 - 1) / 13;
    suit3 = (card3 - 1) / 13;
    suit4 = (card4 - 1) / 13;
    suit5 = (card5 - 1) / 13;
    
    min=rank1;
    if (rank2 < min) min = rank2 ;
    if ( rank3< min) min = rank3;
    if ( rank4< min) min =  rank4;
    if ( rank5< min) min =  rank5;
    
    if (suit1 == suit2 && suit1 == suit3 && suit1 == suit4 && suit1 == suit5) {
        
        if ((( rank1 == min + 1) || ( rank2 == min + 1) || ( rank3== min + 1) || ( rank4== min + 1) || ( rank5 == min + 1)) &&
        (( rank1== min + 2) || ( rank2== min + 2) || ( rank3== min + 2) || ( rank4== min + 2) || (rank5== min + 2)) &&
        (( rank1== min + 3) || ( rank2 == min + 3) || ( rank3== min + 3) || ( rank4== min + 3) || ( rank5== min + 3)) &&
        (( rank1== min + 4) || ( rank2== min + 4) || ( rank3== min + 4) || ( rank4== min + 4) || ( rank5== min + 4))) { 
            printf("Straight Flush\n");
        } }
    else if ((rank1 == rank2 && rank2 == rank3 && rank3 == rank4) || 
        (rank1 == rank2 && rank2 == rank3 && rank3 == rank5) || 
        (rank1 == rank2 && rank2 == rank4 && rank4 == rank5) || 
        (rank1 == rank3 && rank3 == rank4 && rank4 == rank5) || 
        (rank2 == rank3 && rank3 == rank4 && rank4 == rank5)){
            printf("Four of a kind\n");	
	}
	else if ((rank1 == rank2 && rank2 == rank3 && rank4 == rank5) ||  
        (rank1 == rank2 && rank2 == rank4 && rank3 == rank5) ||
        (rank1 == rank2 && rank2 == rank5 && rank3 == rank4) ||
        (rank1 == rank3 && rank3 == rank4 && rank2 == rank5) ||
        (rank1 == rank3 && rank3 == rank5 && rank2 == rank4) ||
        (rank1 == rank4 && rank4 == rank5 && rank2 == rank3) ||
        (rank2 == rank3 && rank3 == rank4 && rank1 == rank5) ||
        (rank2 == rank3 && rank3 == rank5 && rank1 == rank4) ||
        (rank2 == rank4 && rank4 == rank5 && rank1 == rank3) ||
        (rank3 == rank4 && rank4 == rank5 && rank1 == rank2)) {
        printf("Full house\n");
    }
    
    else if(suit1 == suit2 && suit2 == suit3 && suit3 == suit4 && suit4 == suit5) {
        printf("Flush\n");
    } 
    else if (((rank1== min + 1) || (rank2== min + 1) || (rank3== min + 1) || ( rank4== min + 1) || (rank5== min + 1)) &&
        ((rank1== min + 2) || (rank2== min + 2) || (rank3== min + 2) || (rank4== min + 2) || (rank5== min + 2)) &&
        ((rank1== min + 3) || (rank2== min + 3) || (rank3== min + 3) || (rank4== min + 3) || (rank5== min + 3)) &&
        ((rank1== min + 4) || (rank2== min + 4) || (rank3== min + 4) || (rank4== min + 4) || (rank5== min + 4))) {
        printf("Straight\n ");
    } 
    else if ((rank1 == rank2 && rank2 == rank3) ||  
        (rank1 == rank2 && rank2 == rank4) ||
        (rank1 == rank2 && rank2 == rank5) ||
        (rank1 == rank3 && rank3 == rank4) ||
        (rank1 == rank3 && rank3 == rank5 ) ||
        (rank1 == rank4 && rank4 == rank5) ||
        (rank2 == rank3 && rank3 == rank4) ||
        (rank2 == rank3 && rank3 == rank5 ) ||
        (rank2 == rank4 && rank4 == rank5 ) ||
        (rank3 == rank4 && rank4 == rank5 )) {
        printf("Three of a kind\n");
    }
    else if ((rank1 == rank2 && rank3 == rank4 && rank1 != rank3 && rank5 != rank1 && rank5 != rank3) || 
        (rank1 == rank2 && rank3 == rank5 && rank1 != rank3 && rank4 != rank1 && rank4 != rank3) || 
        (rank1 == rank2 && rank4 == rank5 && rank1 != rank4 && rank3 != rank1 && rank3 != rank4) || 
        (rank1 == rank3 && rank2 == rank4 && rank1 != rank2 && rank5 != rank1 && rank5 != rank2) || 
        (rank1 == rank3 && rank2 == rank5 && rank1 != rank2 && rank4 != rank1 && rank4 != rank2) || 
        (rank1 == rank3 && rank4 == rank5 && rank1 != rank4 && rank2 != rank1 && rank2 != rank4) || 
        (rank1 == rank4 && rank2 == rank3 && rank1 != rank2 && rank5 != rank1 && rank5 != rank2) || 
        (rank1 == rank4 && rank2 == rank5 && rank1 != rank2 && rank3 != rank1 && rank3 != rank2) || 
        (rank1 == rank4 && rank3 == rank5 && rank1 != rank3 && rank2 != rank1 && rank2 != rank3) || 
        (rank1 == rank5 && rank2 == rank3 && rank1 != rank2 && rank4 != rank1 && rank4 != rank2) || 
        (rank1 == rank5 && rank2 == rank4 && rank1 != rank2 && rank3 != rank1 && rank3 != rank2) || 
        (rank1 == rank5 && rank3 == rank4 && rank1 != rank3 && rank2 != rank1 && rank2 != rank3) || 
        (rank2 == rank3 && rank4 == rank5 && rank2 != rank4 && rank1 != rank2 && rank1 != rank4) || 
        (rank2 == rank4 && rank3 == rank5 && rank2 != rank3 && rank1 != rank2 && rank1 != rank3) || 
        (rank2 == rank5 && rank3 == rank4 && rank2 != rank3 && rank1 != rank2 && rank1 != rank3)) { 
        
        printf("Two pair\n");}
     else if ((rank1 == rank2 && rank3 != rank1 && rank4 != rank1 && rank5 != rank1) || 
        (rank1 == rank3 && rank2 != rank1 && rank4 != rank1 && rank5 != rank1) || 
        (rank1 == rank4 && rank2 != rank1 && rank3 != rank1 && rank5 != rank1) || 
        (rank1 == rank5 && rank2 != rank1 && rank3 != rank1 && rank4 != rank1) || 
        (rank2 == rank3 && rank1 != rank2 && rank4 != rank2 && rank5 != rank2) || 
        (rank2 == rank4 && rank1 != rank2 && rank3 != rank2 && rank5 != rank2) || 
        (rank2 == rank5 && rank1 != rank2 && rank3 != rank2 && rank4 != rank2) || 
        (rank3 == rank4 && rank1 != rank3 && rank2 != rank3 && rank5 != rank3) || 
        (rank3 == rank5 && rank1 != rank3 && rank2 != rank3 && rank4 != rank3) || 
        (rank4 == rank5 && rank1 != rank4 && rank2 != rank4 && rank3 != rank4)) { 
        printf("One pair\n");
    }
    else{
    	printf("High card\n");
	}


	return 0;
}
