#include <stdio.h>
#include <stdint.h>
#include<math.h>
int main() {
    uint16_t hexInput;
    int32_t choice;
    int32_t sign;
    int32_t exp;
    float fraction = 1.0;
    

   
    printf("Please input a hex: ");
    scanf("%hx", &hexInput);
    getchar();
   
    printf("Please choose the output type (1: signed integer, 2: unsigned integer, 3: float): ");
    scanf("%d", &choice);
    getchar();
  
    printf("Binary of %X is: ", hexInput);

    
    printf("%d", (hexInput >> 15) & 1);
    printf("%d", (hexInput >> 14) & 1);
    printf("%d", (hexInput >> 13) & 1);
    printf("%d", (hexInput >> 12) & 1);
    printf(" "); 
    printf("%d", (hexInput >> 11) & 1);
    printf("%d", (hexInput >> 10) & 1);
    printf("%d", (hexInput >> 9) & 1);
    printf("%d", (hexInput >> 8) & 1);
    printf(" "); 
    printf("%d", (hexInput >> 7) & 1);
    printf("%d", (hexInput >> 6) & 1);
    printf("%d", (hexInput >> 5) & 1);
    printf("%d", (hexInput >> 4) & 1);
    printf(" "); 
    printf("%d", (hexInput >> 3) & 1);
    printf("%d", (hexInput >> 2) & 1);
    printf("%d", (hexInput >> 1) & 1);
    printf("%d", hexInput & 1);
    printf("\n");

    
    switch (choice) {
        case 1: { 
            int16_t signedInt = (int16_t)hexInput;
            printf("Converted signed integer is: %d\n", signedInt);
            break;
        }
        case 2: { 
            printf("Converted unsigned integer is: %u\n", hexInput);
            break;
        }
        case 3: {  
             if ((hexInput & 0x8000) == 0x8000) {
                    sign = -1; 
             } else {
                    sign = 1;   
             }
            
             exp += pow(2,4)*((hexInput >> 14) & 1) ;
             
             
             exp+=pow(2,3)*((hexInput >> 13) & 1);
            
             exp+=pow(2,2)*((hexInput >> 12) & 1) ;
             
             exp+=pow(2,1)*((hexInput >> 11) & 1) ;
             
             exp+=pow(2,0)*((hexInput >> 10) & 1) ;
           
             exp-=15;
   
    if ((hexInput & 0x0200) == 0x0200) {
        fraction += 1.0 / 2.0;  
    }
    if ((hexInput & 0x0100) == 0x0100) {
        fraction += 1.0 / 4.0; 
    }
    if ((hexInput & 0x0080) == 0x0080) {
        fraction += 1.0 / 8.0;  
    }
    if ((hexInput & 0x0040) == 0x0040) {
        fraction += 1.0 / 16.0; 
    }
    if ((hexInput & 0x0020) == 0x0020) {
        fraction += 1.0 / 32.0;
    }
    if ((hexInput & 0x0010) == 0x0010) {
        fraction += 1.0 / 64.0;
    }
    if ((hexInput & 0x0008) == 0x0008) {
        fraction += 1.0 / 128.0; 
    }
    if ((hexInput & 0x0004) == 0x0004) {
        fraction += 1.0 / 256.0; 
    }
    if ((hexInput & 0x0002) == 0x0002) {
        fraction += 1.0 / 512.0; 
    }
    if ((hexInput & 0x0001) == 0x0001) {
        fraction += 1.0 / 1024.0; 
    }

   
    float result = sign * fraction;

 
    printf("Converted float is: %f*2^%d\n", result,exp);
        }
        
    }

    return 0;
}



