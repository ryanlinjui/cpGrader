
#include <stdio.h>

int main() {
    printf("\033[1;31m"); 
    printf("[KIM]\n");
    printf("You are sunlight and I moon\n");
    printf("Joined by the gods of fortune\n");
    printf("Midnight and high noon sharing the sky\n");
    printf("We have been blessed , you and I\n\n");

    printf("\033[1;34m");
    printf("[CHRIS]\n");
    printf("You are here like a mystery\n");
    printf("I'm from a world that's so different from all that you are\n");
    printf("How in the light of one night did we come so far?\n\n");

    printf("\033[1;31m"); 
    printf("[KIM]\n");
    printf("Outside day starts to dawn\n\n");

    printf("\033[1;34m");
    printf("[CHRIS]\n");
    printf("Your moon still floats on high\n\n");

    printf("\033[1;31m"); 
    printf("[KIM]\n");
    printf("The birds awake\n\n");

    printf("\033[1;34m");
    printf("[CHRIS]\n");
    printf("The stars shine too\n\n");

    printf("\033[1;31m");  
    printf("[KIM]\n");
    printf("My hands still shake\n\n");

    printf("\033[1;34m");
    printf("[CHRIS]\n");
    printf("I reach for you\n\n");

    printf("\033[1;32m");
    printf("[KIM & CHRIS]\n");
    printf("And we meet in the sky\n\n");

    printf("\033[1;31m"); 
    printf("[KIM]\n");
    printf("You are sunlight and I moon\n");
    printf("Joined here\n");
    printf("Brightening the sky with the flame of love\n\n");

    printf("\033[1;32m");
    printf("[KIM & CHRIS]\n");
    printf("Made of\n");
    printf("Sunlight\n");
    printf("Moonlight\n");


    return 0;
}

