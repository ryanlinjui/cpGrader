#include<stdio.h>
#include<stdint.h>

int main()
{
	uint32_t number ;
	int32_t choose ;
	
	int16_t n1 ;
	int16_t n2 ;
	int16_t n3 ;
	int16_t n4 ;
	int16_t n5 ;
	int16_t n6 ;
	int16_t n7 ;
	int16_t n8 ;
	int16_t n9 ;
	int16_t n10 ;
	int16_t n11 ;
	int16_t n12 ;
	int16_t n13 ;
	int16_t n14 ;
	int16_t n15 ;
	int16_t n16 ;
	
	uint32_t original ;
	
	int32_t chosen1 ;
	double chosen3 ;
	
	int32_t EXP;
	double F;
	
	printf("Please input a hex:");
	scanf("%X", &number);
	
	original = number;
	chosen3 = number;
	
	n1 = number/(2*2*2*2*2*2*2*2*2*2*2*2*2*2*2);
	number = number-n1*(2*2*2*2*2*2*2*2*2*2*2*2*2*2*2);
	n2 = number/(2*2*2*2*2*2*2*2*2*2*2*2*2*2);
	number = number-n2*(2*2*2*2*2*2*2*2*2*2*2*2*2*2);
	n3 = number/(2*2*2*2*2*2*2*2*2*2*2*2*2);
	number = number-n3*(2*2*2*2*2*2*2*2*2*2*2*2*2);
	n4 = number/(2*2*2*2*2*2*2*2*2*2*2*2);
	number = number-n4*(2*2*2*2*2*2*2*2*2*2*2*2);
	n5 = number/(2*2*2*2*2*2*2*2*2*2*2);
	number = number-n5*(2*2*2*2*2*2*2*2*2*2*2);
	n6 = number/(2*2*2*2*2*2*2*2*2*2);
	number = number-n6*(2*2*2*2*2*2*2*2*2*2);
	n7 = number/(2*2*2*2*2*2*2*2*2);
	number = number-n7*(2*2*2*2*2*2*2*2*2);
	n8 = number/(2*2*2*2*2*2*2*2);
	number = number-n8*(2*2*2*2*2*2*2*2);
	n9 = number/(2*2*2*2*2*2*2);
	number = number-n9*(2*2*2*2*2*2*2);
	n10 = number/(2*2*2*2*2*2);
	number = number-n10*(2*2*2*2*2*2);
	n11 = number/(2*2*2*2*2);
	number = number-n11*(2*2*2*2*2);
	n12 = number/(2*2*2*2);
	number = number-n12*(2*2*2*2);
	n13 = number/(2*2*2);
	number = number-n13*(2*2*2);
	n14 = number/(2*2);
	number = number-n14*(2*2);
	n15 = number/2;
	number = number-n15*2;
	n16 = number%2;
	
	printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
	scanf("%d", &choose);
	if(choose > 3 || choose<1)
	{
		printf("error\n");
		return 0;
	}
	
	printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n", original, n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16);
	
	if(choose == 2)
	{
		printf("Coverted unsigned integer is: %d\n", original);
	}
	
	if(choose == 1 && n1 == 0)
	{
		printf("Coverted  integer is: %d\n", original);
	}
	
	if(choose == 1 && n1 == 1)
	{
		
		number = original - 1;
		
		n1 = number/(2*2*2*2*2*2*2*2*2*2*2*2*2*2*2);
		number = number-n1*(2*2*2*2*2*2*2*2*2*2*2*2*2*2*2);
		n2 = number/(2*2*2*2*2*2*2*2*2*2*2*2*2*2);
		number = number-n2*(2*2*2*2*2*2*2*2*2*2*2*2*2*2);
		n3 = number/(2*2*2*2*2*2*2*2*2*2*2*2*2);
		number = number-n3*(2*2*2*2*2*2*2*2*2*2*2*2*2);
		n4 = number/(2*2*2*2*2*2*2*2*2*2*2*2);
		number = number-n4*(2*2*2*2*2*2*2*2*2*2*2*2);
		n5 = number/(2*2*2*2*2*2*2*2*2*2*2);
		number = number-n5*(2*2*2*2*2*2*2*2*2*2*2);
		n6 = number/(2*2*2*2*2*2*2*2*2*2);
		number = number-n6*(2*2*2*2*2*2*2*2*2*2);
		n7 = number/(2*2*2*2*2*2*2*2*2);
		number = number-n7*(2*2*2*2*2*2*2*2*2);
		n8 = number/(2*2*2*2*2*2*2*2);
		number = number-n8*(2*2*2*2*2*2*2*2);
		n9 = number/(2*2*2*2*2*2*2);
		number = number-n9*(2*2*2*2*2*2*2);
		n10 = number/(2*2*2*2*2*2);
		number = number-n10*(2*2*2*2*2*2);
		n11 = number/(2*2*2*2*2);
		number = number-n11*(2*2*2*2*2);
		n12 = number/(2*2*2*2);
		number = number-n12*(2*2*2*2);
		n13 = number/(2*2*2);
		number = number-n13*(2*2*2);
		n14 = number/(2*2);
		number = number-n14*(2*2);
		n15 = number/2;
		number = number-n15*2;
		n16 = number%2;	
		
		if(n1 == 1)
		{
			n1 = 0;
		}
		else if(n1 == 0 )
		{
			n1 = 1;
		}
		
		if(n2 == 1)
		{
			n2 = 0;
		}
		else if(n2 == 0 )
		{
			n2 = 1;
		}
		
		if(n3 == 1 )
		{
			n3 = 0;
		}
		else if(n3 == 0 )
		{
			n3 = 1;
		}
		
		if(n4 == 1)
		{
			n4 = 0;
		}
		else if(n4 == 0)
		{
			n4 = 1;
		}
		
		if(n5 == 1 )
		{
			n5 = 0;
		}
		else if(n5 == 0 )
		{
			n5 = 1;
		}
		
		if(n6 == 1 )
		{
			n6 = 0;
		}
		else if(n6 == 0)
		{
			n6 = 1;
		}
		
		if(n7 == 1 )
		{
			n7 = 0;
		}
		else if(n7 == 0)
		{
			n7 = 1;
		}
		
		if(n8 == 1 )
		{
			n8 = 0;
		}
		else if(n8 == 0)
		{
			n8 = 1;
		}
		
		if(n9 == 1 )
		{
			n9 = 0;
		}
		else if(n9 == 0)
		{
			n9 = 1;
		}
		
		if(n10 == 1 )
		{
			n10 = 0;
		}
		else if(n10 == 0 )
		{
			n10 = 1;
		}
		
		if(n11 == 1 )
		{
			n11 = 0;
		}
		else if(n11 == 0 )
		{
			n11 = 1;
		}
		
		if(n12 == 1 )
		{
			n12 = 0;
		}
		else if(n12 == 0 )
		{
			n12 = 1;
		}
		
		if(n13 == 1)
		{
			n13 = 0;
		}
		else if(n13 == 0)
		{
			n13 = 1;
		}
		
		if(n14 == 1 )
		{
			n14 = 0;
		}
		else if(n14 == 0 )
		{
			n14 = 1;
		}
		
		if(n15 == 1 )
		{
			n15 = 0;
		}
		else if(n15 == 0 )
		{
			n15 = 1;
		}
		
		if(n16 == 1 )
		{
			n16 = 0;
		}
		else if(n16 == 0 )
		{
			n16 = 1;
		}
	
	chosen1 = 
	((n1*(2*2*2*2*2*2*2*2*2*2*2*2*2*2*2))+
	(n2*(2*2*2*2*2*2*2*2*2*2*2*2*2*2))+
	(n3*(2*2*2*2*2*2*2*2*2*2*2*2*2))+
	(n4*(2*2*2*2*2*2*2*2*2*2*2*2))+
	(n5*(2*2*2*2*2*2*2*2*2*2*2))+
	(n6*(2*2*2*2*2*2*2*2*2*2))+
	(n7*(2*2*2*2*2*2*2*2*2))+
	(n8*(2*2*2*2*2*2*2*2))+
	(n9*(2*2*2*2*2*2*2))+
	(n10*(2*2*2*2*2*2))+
	(n11*(2*2*2*2*2))+
	(n12*(2*2*2*2))+
	(n13*(2*2*2))+
	(n14*(2*2))+
	(n15*2)+
	(n16))*-1;
	
	printf("Coverted  integer is: %d\n", chosen1);		
	}
	
	if(choose == 3 && n1 == 0)
	{
		if(n2 == 1 && n3 == 1 && n4 == 1 && n5 == 1 && n6 == 1 && n7 == 0 && n8 == 0 && n9 == 0 && n10 == 0 && n11 == 0 && n12 == 0 && n13 == 0 && n14 == 0 && n15 == 0 && n16 == 0)
		{
			printf("Coverted  float is: +INF\n");
		}
		else if(n2 == 0 && n3 == 0 && n4 == 0 && n5 == 0 && n6 == 0 && n7 == 0 && n8 == 0 && n9 == 0 && n10 == 0 && n11 == 0 && n12 == 0 && n13 == 0 && n14 == 0 && n15 == 0 && n16 == 0)
		{
			printf("Coverted  float is: +0.0\n");
		}
		else if(n2 == 1 && n3 == 1 && n4 == 1 && n5 == 1 && n6 == 1 &&( n7 != 0 || n8 != 0 || n9 != 0 || n10 != 0 || n11 != 0 || n12 != 0 || n13 != 0 || n14 != 0 || n15 != 0 || n16 != 0))
		{
			printf("Coverted  float is: NAN\n");
		}
		else
		{	
			EXP = n2*16 + n3*8 + n4*4 + n5*2 + n6 ;
			F = n7*0.5 + n8*0.25 + n9*0.125 + n10*0.0625 + n11*0.03125 + n12*0.015625 + n13*0.0078125 + n14*0.00390625 + n15*0.001953125 + n16*0.0009765625 + 1;
			if(EXP == 30)
			{
				chosen3 = F * 32768;
			}
			
			else if (EXP == 29)
			{
				chosen3 = F * 16384;
			}
			
			else if (EXP == 28)
			{
				chosen3 = F * 8192;
			}
			
			else if (EXP == 27)
			{
				chosen3 = F * 4096;
			}
			
			else if (EXP == 26)
			{
				chosen3 = F * 2048;
			}
			
			else if (EXP == 25)
			{
				chosen3 = F * 1024;
			}
			
			else if (EXP == 24)
			{
				chosen3 = F * 512;
			}
			
			else if (EXP == 23)
			{
				chosen3 = F * 256;
			}
			
			else if (EXP == 22)
			{
				chosen3 = F * 128;
			}
			
			else if (EXP == 21)
			{
				chosen3 = F * 64;
			}
			
			else if (EXP == 20)
			{
				chosen3 = F * 32;
			}
			
			else if (EXP == 19)
			{
				chosen3 = F * 16;
			}
			
			else if (EXP == 18)
			{
				chosen3 = F * 8;
			}
			
			else if (EXP == 17)
			{
				chosen3 = F * 4;
			}
			
			else if (EXP == 16)
			{
				chosen3 = F * 2;
			}
			
			else if (EXP == 15)
			{
				chosen3 = F ;
			}
			
			else if (EXP == 14)
			{
				chosen3 = F * 0.5;
			}
			
			else if (EXP == 13)
			{
				chosen3 = F * 0.25;
			}
			
			else if (EXP == 12)
			{
				chosen3 = F * 0.125;
			}
			
			else if (EXP == 11)
			{
				chosen3 = F * 0.0625;
			}
			
			else if (EXP == 10)
			{
				chosen3 = F * 0.03125;
			}
			
			else if (EXP == 9)
			{
				chosen3 = F * 0.015625;
			}
			
			else if (EXP == 8)
			{
				chosen3 = F * 0.0078125;
			}
			
			else if (EXP == 7)
			{
				chosen3 = F * 0.00390625;
			}
			
			else if (EXP == 6)
			{
				chosen3 = F * 0.001953125;
			}
			
			else if (EXP == 5)
			{
				chosen3 = F * 0.0009765625;
			}
			
			else if (EXP == 4)
			{
				chosen3 = F * 0.00048828125;
			}
			
			else if (EXP == 3)
			{
				chosen3 = F * 0.00024414062;
			}
			
			else if (EXP == 2)
			{
				chosen3 = F * 0.00012207031;
			}
			
			else if (EXP == 1)
			{
				chosen3 = F * 0.00006103515;
			}
			
			else if (EXP == 0)
			{
				chosen3 = F * 0.00003051757;
			}
			printf("Coverted  float is: %e\n", chosen3);
		}
	}
	
	if(choose == 3 && n1 == 1)
	{
		if(n2 == 1 && n3 == 1 && n4 == 1 && n5 == 1 && n6 == 1 && n7 == 0 && n8 == 0 && n9 == 0 && n10 == 0 && n11 == 0 && n12 == 0 && n13 == 0 && n14 == 0 && n15 == 0 && n16 == 0)
		{
			printf("Coverted  float is: -INF\n");	
		}
		else if(n2 == 0 && n3 == 0 && n4 == 0 && n5 == 0 && n6 == 0 && n7 == 0 && n8 == 0 && n9 == 0 && n10 == 0 && n11 == 0 && n12 == 0 && n13 == 0 && n14 == 0 && n15 == 0 && n16 == 0)
		{
			printf("Coverted  float is: -0.0\n");
		}
		else if(n2 == 1 && n3 == 1 && n4 == 1 && n5 == 1 && n6 == 1 &&( n7 != 0 || n8 != 0 || n9 != 0 || n10 != 0 || n11 != 0 || n12 != 0 || n13 != 0 || n14 != 0 || n15 != 0 || n16 != 0))
		{
			printf("Coverted  float is: NAN\n");
		}
	else
		{	
			EXP = n2*16 + n3*8 + n4*4 + n5*2 + n6 ;
			F = n7*0.5 + n8*0.25 + n9*0.125 + n10*0.0625 + n11*0.03125 + n12*0.015625 + n13*0.0078125 + n14*0.00390625 + n15*0.001953125 + n16*0.0009765625 + 1;
			if(EXP == 30)
			{
				chosen3 = F * 32768;
			}
			
			else if (EXP == 29)
			{
				chosen3 = F * 16384;
			}
			
			else if (EXP == 28)
			{
				chosen3 = F * 8192;
			}
			
			else if (EXP == 27)
			{
				chosen3 = F * 4096;
			}
			
			else if (EXP == 26)
			{
				chosen3 = F * 2048;
			}
			
			else if (EXP == 25)
			{
				chosen3 = F * 1024;
			}
			
			else if (EXP == 24)
			{
				chosen3 = F * 512;
			}
			
			else if (EXP == 23)
			{
				chosen3 = F * 256;
			}
			
			else if (EXP == 22)
			{
				chosen3 = F * 128;
			}
			
			else if (EXP == 21)
			{
				chosen3 = F * 64;
			}
			
			else if (EXP == 20)
			{
				chosen3 = F * 32;
			}
			
			else if (EXP == 19)
			{
				chosen3 = F * 16;
			}
			
			else if (EXP == 18)
			{
				chosen3 = F * 8;
			}
			
			else if (EXP == 17)
			{
				chosen3 = F * 4;
			}
			
			else if (EXP == 16)
			{
				chosen3 = F * 2;
			}
			
			else if (EXP == 15)
			{
				chosen3 = F ;
			}
			
			else if (EXP == 14)
			{
				chosen3 = F * 0.5;
			}
			
			else if (EXP == 13)
			{
				chosen3 = F * 0.25;
			}
			
			else if (EXP == 12)
			{
				chosen3 = F * 0.125;
			}
			
			else if (EXP == 11)
			{
				chosen3 = F * 0.0625;
			}
			
			else if (EXP == 10)
			{
				chosen3 = F * 0.03125;
			}
			
			else if (EXP == 9)
			{
				chosen3 = F * 0.015625;
			}
			
			else if (EXP == 8)
			{
				chosen3 = F * 0.0078125;
			}
			
			else if (EXP == 7)
			{
				chosen3 = F * 0.00390625;
			}
			
			else if (EXP == 6)
			{
				chosen3 = F * 0.001953125;
			}
			
			else if (EXP == 5)
			{
				chosen3 = F * 0.0009765625;
			}
			
			else if (EXP == 4)
			{
				chosen3 = F * 0.00048828125;
			}
			
			else if (EXP == 3)
			{
				chosen3 = F * 0.00024414062;
			}
			
			else if (EXP == 2)
			{
				chosen3 = F * 0.00012207031;
			}
			
			else if (EXP == 1)
			{
				chosen3 = F * 0.00006103515;
			}
			
			else if (EXP == 0)
			{
				chosen3 = F * 0.00003051757;
			}
			
			chosen3 = chosen3*(-1);
	printf("Coverted  float is: %e\n", chosen3);		
	}
	}
	return 0;
}
