#include<stdio.h>
#include<stdint.h>

int main()
{
	uint16_t begin;
	uint64_t last;
	int32_t one;
	int32_t two;
	int32_t three;
	int32_t four;
	int32_t five;
	int32_t six;
	
	printf("Please enter an unsigned 16-bits number: ");
	scanf("%hd", &begin);
	printf("Before Flip:\n");
	printf("%d_10 = %o_8\n", begin, begin);
	
	printf("After Flip:\n");
	
	one = begin%8;
	two = (begin/8)%8;
	three = ((begin/8)/8)%8;
	four = (((begin/8)/8)/8)%8;
	five = ((((begin/8)/8)/8)/8)%8;
	six = (((((begin/8)/8)/8)/8)/8)%8;
	
	if(one != 0)
	{
		if(two == 0 && three == 0 && four == 0 && five == 0 && six == 0)
		{
			last = one;
			printf("%d_8 = %ld_10\n", one, last);
		}
	
		else if(three == 0 && four == 0 && five == 0 && six == 0)
		{
			last = one*8 + two;
			printf("%d%d_8 = %ld_10\n", one, two, last);
		}
	
		else if(four == 0 && five == 0 && six == 0)
		{
			last = one*8*8 + two*8 + three;
			printf("%d%d%d_8 = %ld_10\n", one, two, three, last);
		}
		
		else if(five == 0 && six == 0)
		{
			last = one*8*8*8 + two*8*8 + three*8 + four;
			printf("%d%d%d%d_8 = %ld_10\n", one, two, three, four, last);
		}	
	
		else if(six == 0)
		{
			last = one*8*8*8*8 + two*8*8*8 + three*8*8 + four*8 + five;
			printf("%d%d%d%d%d_8 = %ld_10\n", one, two, three, four, five, last);
		}	
	}
	
	else if(one == 0)
	{
		if(two == 0 && three == 0 && four == 0 && five == 0 && six == 0)
		{
			last = one;
			printf("%d_8 = %ld_10\n", one, last);
		}
		else if( two != 0)
		{
			if(three == 0 && four == 0 && five == 0 && six == 0)
			{
				last = one*8 + two;
				printf("%d_8 = %ld_10\n", two, last);
			}
	
			else if(four == 0 && five == 0 && six == 0)
			{
				last = one*8*8 + two*8 + three;
				printf("%d%d_8 = %ld_10\n", two, three, last);
			}
		
			else if(five == 0 && six == 0)
			{
				last = one*8*8*8 + two*8*8 + three*8 + four;
				printf("%d%d%d_8 = %ld_10\n", two, three, four, last);
			}	
	
			else if(six == 0)
			{
				last = one*8*8*8*8 + two*8*8*8 + three*8*8 + four*8 + five;
				printf("%d%d%d%d_8 = %ld_10\n", two, three, four, five, last);
			}	
		}
		else if (two == 0)
		{
			if(three == 0 && four == 0 && five == 0 && six == 0)
			{
				last = one*8 + two;
				printf("%d_8 = %ld_10\n", two, last);
			}
			else if(three != 0)
			{
				if(four == 0 && five == 0 && six == 0)
				{
					last = one*8*8 + two*8 + three;
					printf("%d_8 = %ld_10\n", three, last);
				}
		
				else if(five == 0 && six == 0)
				{
					last = one*8*8*8 + two*8*8 + three*8 + four;
					printf("%d%d_8 = %ld_10\n", three, four, last);
				}	
	
				else if(six == 0)
				{
					last = one*8*8*8*8 + two*8*8*8 + three*8*8 + four*8 + five;
					printf("%d%d%d_8 = %ld_10\n", three, four, five, last);
				}	
			}
			else if(three == 0)
			{
				if(four == 0 && five == 0 && six == 0)
				{
					last = one*8*8 + two*8 + three;
					printf("%d_8 = %ld_10\n", three, last);
				}
				else if(four != 0)
				{	
					if(five == 0 && six == 0)
					{
						last = one*8*8*8 + two*8*8 + three*8 + four;
						printf("%d_8 = %ld_10\n", four, last);
					}	
	
					else if(six == 0)
					{
						last = one*8*8*8*8 + two*8*8*8 + three*8*8 + four*8 + five;
						printf("%d%d_8 = %ld_10\n", four, five, last);
					}	
				}
				else if(four == 0)
				{	
					if(five == 0 && six == 0)
					{
						last = one*8*8*8 + two*8*8 + three*8 + four;
						printf("%d_8 = %ld_10\n", four, last);
					}	
					else if(five !=0)
					{
						if(six == 0)
						{
							last = one*8*8*8*8 + two*8*8*8 + three*8*8 + four*8 + five;
							printf("%d_8 = %ld_10\n", five, last);
						}
					}
					else if(five == 0)
					{
						if (six != 0)
						{
							last = six;
							printf("%d_8 = %ld_10\n", six, last); 	
						}
						else if(six == 0)
						{
							last = one*8*8*8*8 + two*8*8*8 + three*8*8 + four*8 + five;
							printf("%d_8 = %ld_10\n", five, last);
						}
		
					}
				}
			}
		}
	}
	if(one != 0 && two != 0 && three != 0 && four != 0 && five != 0 && six != 0)
	{
		last = one*8*8*8*8*8 + two*8*8*8*8 + three*8*8*8 + four*8*8 + five*8 + six;
		printf("%d%d%d%d%d%d_8 = %ld_10\n", one, two, three, four, five, six, last);
	}
	
	return 0;
}
