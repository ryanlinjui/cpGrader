#include<stdio.h>

int main()
{
printf("\033[31m[KIM]\033[0m\n");
printf("\033[31mYou are sunlight and I moon\033[0m\n");
printf("\033[31mJoined by the gods of fortune\033[0m\n");
printf("\033[31mMidnight and high noon sharing the sky\033[0m\n");
printf("\033[31mWe have been blessed , you and I\033[0m\n");
printf("\n");

printf("\033[34m[CHRIS]\033[0m\n");
printf("\033[34mYou are here like a mystery\033[0m\n");
printf("\033[34mI'm from a world that's so different from all that you are\033[0m\n");
printf("\033[34mHow in the light of one night did we come so far?\033[0m\n");
printf("\n");

printf("\033[31m[KIM]\033[0m\n");
printf("\033[31mOutside day starts to dawn\033[0m\n");
printf("\n");

printf("\033[34m[CHRIS]\033[0m\n");
printf("\033[34mYour moon still floats on high\033[0m\n");
printf("\n");

printf("\033[31m[KIM]\033[0m\n");
printf("\033[31mThe birds awake\033[0m\n");
printf("\n");

printf("\033[34m[CHRIS]\033[0m\n");
printf("\033[34mThe stars shine too\033[0m\n");
printf("\n");

printf("\033[31m[KIM]\033[0m\n");
printf("\033[31mMy hands still shake\033[0m\n");
printf("\033[31mSee upcoming pop shows\033[0m\n");
printf("\033[31mGet tickets for your favorite artists\033[0m\n");
printf("\n");

printf("\033[31mYou might also like\033[0m\n");
printf("\033[31mMy Boy Only Breaks His Favorite Toys\033[0m\n");
printf("\033[31mTaylor Swift\033[0m\n");
printf("\033[31mWho’s Afraid of Little Old Me?\033[0m\n");
printf("\033[31mTaylor Swift\033[0m\n");
printf("\033[31mGuilty as Sin?\033[0m\n");
printf("\033[31mTaylor Swift\033[0m\n");
printf("\n");

printf("\033[34m[CHRIS]\033[0m\n");
printf("\033[34mI reach for you\033[0m\n");
printf("\n");

printf("\033[32m[KIM & CHRIS]\033[0m\n");
printf("\033[32mAnd we meet in the sky\033[0m\n");
printf("\n");

printf("\033[31m[KIM]\033[0m\n");
printf("\033[31mYou are sunlight and I moon\033[0m\n");
printf("\033[31mJoined here\033[0m\n");
printf("\033[31mBrightening the sky with the flame of love\033[0m\n");
printf("\n");

printf("\033[32m[KIM & CHRIS]\033[0m\n");
printf("\033[32mMade of\033[0m\n");
printf("\033[32mSunlight\033[0m\n");
printf("\033[32mMoonlight\033[0m\n");

return 0;

}
