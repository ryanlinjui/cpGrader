#include<stdio.h>
#include<stdint.h>

int main()
{
	int32_t a = 15;
	int32_t x;
	int32_t b = 15;
	int32_t y;
	int32_t c = 15;
	int32_t z;
	int32_t sum;
	
	printf("Please enter the first  operand: ");
	scanf("%dx%d", &a, &b);
	if(a>9||b>9)
	{
		printf("error\n");
		return 0;
	}
	
	printf("Please enter the second operand: ");
	scanf("\ny%dz", &c);
	if(c>9)
	{
		printf("error\n");
		return 0;
	}
	
	printf("Please enter the sum           : ");
	scanf("\n%d", &sum);
	
	if(sum>1998)
	{
		printf("error\n");
		return 0;
	}
	
	
	z = ((sum-100*a-10*c-b)%10);
	x = (((sum-100*a-10*c-b-z)%100)/10);
	y = (((sum-100*a-10*c-b-z-10*x)/100)%10);
	
	printf("Ans: x = %d, y = %d, z = %d\n", x, y ,z);
	
	return 0;
}
