#include<stdio.h>
#include<stdint.h>

int main()
{
	int32_t a = 88;
	int32_t b = 88;
	int32_t c = 88;
	int32_t d = 88;
	int32_t e = 88;
	int32_t mid;
	
	printf("Please enter 5 cards: ");
	scanf("%d %d %d %d %d", &a, &b, &c, &d, &e);
	
	if(a<=0 || a>52 || b<=0 || b>52 || c<=0 || c>52 || d<=0 || d>52 || e<=0 || e>52 )
	{
		printf("error\n");
		return 0;
	}
	
	
	int32_t la = ((a-1)%13)+1;
	int32_t lb = ((b-1)%13)+1;
	int32_t lc = ((c-1)%13)+1;
	int32_t ld = ((d-1)%13)+1;
	int32_t le = ((e-1)%13)+1;
	
	if(a<b)
	{
		mid = a;
		a = b;
		b = mid;
	}
	if(b<c)
	{
		mid = b;
		b = c;
		c = mid;
	}
	if(c<d)
	{
		mid = c;
		c = d;
		d = mid;
	}
	if(d<e)
	{
		mid = d;
		d = e;
		e = mid;
	}
	if(a<b)
	{
		mid = a;
		a = b;
		b = mid;
	}
	if(b<c)
	{
		mid = b;
		b = c;
		c = mid;
	}
	if(c<d)
	{
		mid = c;
		c = d;
		d = mid;
	}
	if(a<b)
	{
		mid = a;
		a = b;
		b = mid;
	}
	if(b<c)
	{
		mid = b;
		b = c;
		c = mid;
	}
	if(a<b)
	{
		mid = a;
		a = b;
		b = mid;
	}
	
	if(a == b || b == c || c == d || d == e )
	{
		printf("error\n");
		return 0;
	}
	
	if(la<lb)
	{
		mid = la;
		la = lb;
		lb = mid;
	}
	if(lb<lc)
	{
		mid = lb;
		lb = lc;
		lc = mid;
	}
	if(lc<ld)
	{
		mid = lc;
		lc = ld;
		ld = mid;
	}
	if(ld<le)
	{
		mid = ld;
		ld = le;
		le = mid;
	}
	if(la<lb)
	{
		mid = la;
		la = lb;
		lb = mid;
	}
	if(lb<lc)
	{
		mid = lb;
		lb = lc;
		lc = mid;
	}
	if(lc<ld)
	{
		mid = lc;
		lc = ld;
		ld = mid;
	}
	if(la<lb)
	{
		mid = la;
		la = lb;
		lb = mid;
	}
	if(lb<lc)
	{
		mid = lb;
		lb = lc;
		lc = mid;
	}
	if(la<lb)
	{
		mid = la;
		la = lb;
		lb = mid;
	}
	
	if((a-1)/13 == (e-1)/13 && a-1 == b && b-1 == c && c-1 == d && d-1 == e)
	{
		printf("Straight flush\n");
	}
	
	else if(le == 1 && ld == 10 && lc == 11 && lb == 12 && la == 13 && (a-1)/13 == (e-1)/13)
	{
		printf("Straight flush\n");
	}
	
	else if((a%13 == b%13 && a%13 == c%13 && a%13 == d%13)||(a%13 == b%13 && a%13 == c%13 && a%13 == e%13)||(a%13 == b%13 && a%13 == e%13 && a%13 == d%13)||(a%13 == e%13 && a%13 == c%13 && a%13 == d%13)||(b%13 == c%13 && b%13 == d%13 && b%13 == e%13))
	{
		printf("Four of a kind\n");
	}
	
	else if((a%13 == b%13 && c%13 == d%13 && c%13 == e%13)||(a%13 == c%13 && b%13 == d%13 && b%13 == e%13)||(a%13 == d%13 && b%13 == c%13 && b%13 == e%13)||(a%13 == e%13 && b%13 == c%13 && b%13 == d%13)||(b%13 == c%13 && a%13 == d%13 && a%13 == e%13)||(b%13 == d%13 && a%13 == c%13 && a%13 == e%13)||(b%13 == e%13 && a%13 == c%13 && a%13 == d%13)||(c%13 == d%13 && a%13 == b%13 && a%13 == e%13)||(c%13 == e%13 && a%13 == b%13 && a%13 == d%13)||(d%13 == e%13 && a%13 == b%13 && a%13 == c%13))
	{
		printf("Full house\n");
	}
	
	else if((a-1)/13 == (e-1)/13)
	{
		printf("Flush\n");
	}
	
	else if(la-1 == lb && lb-1 == lc && lc-1 == ld && ld-1 == le)
	{
		printf("Straight\n");
	}
	
	else if(la == 13 && lb == 12 && lc == 11 && ld == 10 && le == 1)
	{
		printf("Straight\n");
	}
	
	else if((la == lb && la == lc) || (lb == lc && lb == ld) || (lc == ld && lc == le))
	{
		printf("Three of a kind\n");
	}
	
	else if((lb == lc && ld == le) || (la == lb && ld == le) || (la == lb && lc == ld))
	{
		printf("Two pair\n");
	}
	
	else if(la == lb || lb == lc || lc == ld || ld == le )
	{
		printf("One pair\n");
	}
	
	else
	{
		printf("High card\n");
	}

	return 0;
}
