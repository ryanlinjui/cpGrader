#include <stdio.h>
#include <stdint.h>

int main()
{
/*
variables
*/
	uint16_t uinput=0;int32_t input=-1;
	int8_t error=1;int16_t clcl=-1;int32_t flip=0;uint16_t dgt=1;
	uint16_t st=-1; uint16_t nd=-1; uint16_t rd=-1; uint16_t fr=-1; uint16_t ff=-1; uint16_t sx=-1;
//-------------------------------------------------------------------------
/*
get input
*/
	printf("Please enter an unsigned 16-bits number:");
	scanf("%d",&input);
//-------------------------------------------------------------------------
/*
calculation the octal and judge whether the input is appropriate
*/
	if (input<0||input>65535){
		error = 1;
	}else{
		error = 0;
		uinput = input;
		st=uinput%8; clcl=uinput/8;
		nd=clcl%8; clcl=clcl/8;
		rd=clcl%8; clcl=clcl/8;
		fr=clcl%8; clcl=clcl/8;
		ff=clcl%8; clcl=clcl/8;
		sx=clcl%8; clcl=clcl/8;
	}
//-------------------------------------------------------------------------
if(error == 0){
	printf("Before Flip:\n");
	printf("%d",uinput);
	printf("_10 = ");
	if (sx>0){
		printf("%d%d%d%d%d%d",sx,ff,fr,rd,nd,st);
		printf("_8\n");
		printf("After Flip:\n");
		if(st!=0){
			printf("%d%d%d%d%d%d",st,nd,rd,fr,ff,sx);
		}else{
			if(nd!=0){
				printf("%d%d%d%d%d",nd,rd,fr,ff,sx);
			}else{
				if(rd!=0){
				printf("%d%d%d%d",rd,fr,ff,sx);
				}else{
					if(fr!=0){
						printf("%d%d%d",fr,ff,sx);
					}else{
						if(ff!=0){
							printf("%d%d",ff,sx);
						}else{
							printf("%d",sx);
						}
					}
				}
			}
		}
		printf("_8 = ");
		dgt=1;
		flip=0;
		flip=flip+sx*dgt;
		dgt=dgt*8;
		flip=flip+ff*dgt;
		dgt=dgt*8;
		flip=flip+fr*dgt;
		dgt=dgt*8;
		flip=flip+rd*dgt;
		dgt=dgt*8;
		flip=flip+nd*dgt;
		dgt=dgt*8;
		flip=flip+st*dgt;
		printf("%d",flip);
		printf("_10\n");
	}else{
		if(ff>0){
			printf("%d%d%d%d%d",ff,fr,rd,nd,st);
			printf("_8\n");
			printf("After Flip:\n");
			if(st!=0){
				printf("%d%d%d%d%d",st,nd,rd,fr,ff);
			}else{
				if(nd!=0){
					printf("%d%d%d%d",nd,rd,fr,ff);
				}else{
					if(rd!=0){
					printf("%d%d%d",rd,fr,ff);
					}else{
						if(fr!=0){
							printf("%d%d",fr,ff);
						}else{
								printf("%d",ff);
						}
					}
				}
			}
			printf("_8 = ");
			dgt=1;
			flip=0;
			flip=flip+ff*dgt;
			dgt=dgt*8;
			flip=flip+fr*dgt;
			dgt=dgt*8;
			flip=flip+rd*dgt;
			dgt=dgt*8;
			flip=flip+nd*dgt;
			dgt=dgt*8;
			flip=flip+st*dgt;
			printf("%d",flip);
			printf("_10\n");
		}else{
			if(fr>0){
				printf("%d%d%d%d",fr,rd,nd,st);
				printf("_8\n");
				printf("After Flip:\n");
				if(st!=0){
				printf("%d%d%d%d",st,nd,rd,fr);
				}else{
					if(nd!=0){
						printf("%d%d%d",nd,rd,fr);
					}else{
						if(rd!=0){
						printf("%d%d",rd,fr);
						}else{
							printf("%d",fr);
						}
					}
				}
				printf("_8 = ");
				dgt=1;
				flip=0;
				flip=flip+fr*dgt;
				dgt=dgt*8;
				flip=flip+rd*dgt;
				dgt=dgt*8;
				flip=flip+nd*dgt;
				dgt=dgt*8;
				flip=flip+st*dgt;
				printf("%d",flip);
				printf("_10\n");
			}else{
				if(rd>0){
					printf("%d%d%d",rd,nd,st);
					printf("_8\n");
					printf("After Flip:\n");
					if(st!=0){
					printf("%d%d%d",st,nd,rd);
					}else{
						if(nd!=0){
							printf("%d%d",nd,rd);
						}else{
							printf("%d",rd);
						}
					}
					printf("_8 = ");
					dgt=1;
					flip=0;
					flip=flip+rd*dgt;
					dgt=dgt*8;
					flip=flip+nd*dgt;
					dgt=dgt*8;
					flip=flip+st*dgt;
					printf("%d",flip);
					printf("_10\n");
				}else{
					if(nd>0){
						printf("%d%d",nd,st);
						printf("_8\n");
						printf("After Flip:\n");
						if(st!=0){
							printf("%d%d",st,nd);
						}else{
							printf("%d",nd);
						}
						printf("_8 = ");
						dgt=1;
						flip=0;
						flip=flip+nd*dgt;
						dgt=dgt*8;
						flip=flip+st*dgt;
						printf("%d",flip);
						printf("_10\n");
					}else{
						printf("%d",st);
						printf("_8\n");
						printf("After Flip:\n");
						printf("%d",st);
						printf("_8 = ");
						printf("%hd",uinput);
						printf("_10\n");
					}
				}
			}
		}
	}
}else{
	printf("Wrong Input!\n");
}
	//printf();
	return 0;
}
