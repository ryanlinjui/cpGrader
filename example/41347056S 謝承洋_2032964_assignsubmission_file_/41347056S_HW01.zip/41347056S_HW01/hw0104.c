#include <stdio.h>
#include <stdint.h>

int main(){
int32_t st=-1;int32_t nd=-1;int32_t rd=-1;int32_t fr=-1;int32_t ff=-1;int32_t clcltion=0;uint8_t wng=0;uint8_t smcl=0;uint32_t tmp=0;uint8_t str=0;uint8_t pr=0;uint8_t thknd=0;uint8_t frknd=0;uint8_t hghcrd=1;
int32_t cl_st=-1;int32_t nm_st=-1;
int32_t cl_nd=-1;int32_t nm_nd=-1;
int32_t cl_rd=-1;int32_t nm_rd=-1;
int32_t cl_fr=-1;int32_t nm_fr=-1;
int32_t cl_ff=-1;int32_t nm_ff=-1;
//----------------------------------------------------------------
	printf("Please enter your cards' numbers:");
	scanf("%d %i %i %i %i",&st,&nd,&rd,&fr,&ff);
//----------------------------------------------------------------
//simple check the input
	if(st<1||st>52){
		wng=1;
	}
	if(nd<1||nd>52){
		wng=1;
	}
	if(rd<1||rd>52){
		wng=1;
	}
	if(fr<1||fr>52){
		wng=1;
	}
	if(ff<1||ff>52){
		wng=1;
	}
//----------------------------------------------------------------
//first card
	clcltion = st;
	if (1<=clcltion||clcltion<=52){
		if(1<=clcltion && clcltion<=13){
			cl_st=1;
		}
		if(14<=clcltion && clcltion<=26){
			cl_st=2;
		}
		if(27<=clcltion && clcltion<=39){
			cl_st=3;
		}
		if(40<=clcltion && clcltion<=52){
			cl_st=4;
		}
		nm_st=(clcltion-1)%13+1;
	}
	else{
		wng = 1;
	}
//----------------------------------------------------------------
//second card
	clcltion = nd;
	if (1<=clcltion||clcltion<=52){
		if(1<=clcltion && clcltion<=13){
			cl_nd=1;
		}
		if(14<=clcltion && clcltion<=26){
			cl_nd=2;
		}
		if(27<=clcltion && clcltion<=39){
			cl_nd=3;
		}
		if(40<=clcltion && clcltion<=52){
			cl_nd=4;
		}
		nm_nd=(clcltion-1)%13+1;
	}
	else{
		wng = 1;
	}
//----------------------------------------------------------------
//third card
	clcltion = rd;
	if (1<=clcltion||clcltion<=52){
		if(1<=clcltion && clcltion<=13){
			cl_rd=1;
		}
		if(14<=clcltion && clcltion<=26){
			cl_rd=2;
		}
		if(27<=clcltion && clcltion<=39){
			cl_rd=3;
		}
		if(40<=clcltion && clcltion<=52){
			cl_rd=4;
		}
		nm_rd=(clcltion-1)%13+1;
	}
	else{
		wng = 1;
	}
//----------------------------------------------------------------
//fourth card
	clcltion = fr;
	if (1<=clcltion||clcltion<=52){
		if(1<=clcltion && clcltion<=13){
			cl_fr=1;
		}
		if(14<=clcltion && clcltion<=26){
			cl_fr=2;
		}
		if(27<=clcltion && clcltion<=39){
			cl_fr=3;
		}
		if(40<=clcltion && clcltion<=52){
			cl_fr=4;
		}
		nm_fr=(clcltion-1)%13+1;
	}
	else{
		wng = 1;
	}
//----------------------------------------------------------------
//fifth card
	clcltion = ff;
	if (1<=clcltion||clcltion<=52){
		if(1<=clcltion && clcltion<=13){
			cl_ff=1;
		}
		if(14<=clcltion && clcltion<=26){
			cl_ff=2;
		}
		if(27<=clcltion && clcltion<=39){
			cl_ff=3;
		}
		if(40<=clcltion && clcltion<=52){
			cl_ff=4;
		}
		nm_ff=(clcltion-1)%13+1;
	}
	else{
		wng = 1;
	}
//----------------------------------------------------------------
//report wrong input
	if (wng==1){
	printf("Wrong input!\n");
}else{
//----------------------------------------------------------------
//arrange in order
	if(nm_st>nm_nd){
		tmp=nm_st;
		nm_st=nm_nd;
		nm_nd=tmp;
	}
	if(nm_st>nm_rd){
		tmp=nm_st;
		nm_st=nm_rd;
		nm_rd=tmp;
	}
	if(nm_st>nm_fr){
		tmp=nm_st;
		nm_st=nm_fr;
		nm_fr=tmp;
	}
	if(nm_st>nm_ff){
		tmp=nm_st;
		nm_st=nm_ff;
		nm_ff=tmp;
	}
	if(nm_nd>nm_rd){
		tmp=nm_nd;
		nm_nd=nm_rd;
		nm_rd=tmp;
	}
	if(nm_nd>nm_fr){
		tmp=nm_nd;
		nm_nd=nm_fr;
		nm_fr=tmp;
	}
	if(nm_nd>nm_ff){
		tmp=nm_nd;
		nm_nd=nm_ff;
		nm_ff=tmp;
	}
	if(nm_rd>nm_fr){
		tmp=nm_rd;
		nm_rd=nm_fr;
		nm_fr=tmp;
	}
	if(nm_rd>nm_ff){
		tmp=nm_rd;
		nm_rd=nm_ff;
		nm_ff=tmp;
	}
	if(nm_fr>nm_ff){
		tmp=nm_fr;
		nm_fr=nm_ff;
		nm_ff=tmp;
	}
//----------------------------------------------------------------
//judge if flush	
	if (cl_st==cl_nd){
		smcl+=1;
		if (cl_st==cl_rd){
			smcl+=1;
			if (cl_st==cl_fr){
				smcl+=1;
				if (cl_st==cl_ff){
					smcl+=1;
				}
			}
		}
	}
//----------------------------------------------------------------
//judge if str
	if((nm_st+1==nm_nd&&nm_st+2==nm_rd&&nm_st+3==nm_fr&&nm_st+4==nm_ff)||
	(nm_st+9==nm_nd&&nm_st+10==nm_rd&&nm_st+11==nm_fr&&nm_st+12==nm_ff)){
		str=1;
	}
//----------------------------------------------------------------
//judge all kinds of number of a kind
	if(nm_st==nm_nd){
		if(nm_st==nm_rd){
			if(nm_st==nm_fr){
				frknd=1;
			}else{
				thknd=1;
				if(nm_fr==nm_ff){
					pr+=1;
				}
			}
		}else{
			pr+=1;
			if(nm_rd==nm_fr){
				if(nm_rd==nm_ff){
					thknd=1;
				}else{
					pr+=1;
					if(nm_fr==nm_ff){
						pr+=1;
					}
				}
			}
		}
	}else{
		if(nm_nd==nm_rd){
			if(nm_nd==nm_fr){
				if(nm_nd==nm_ff){
					frknd=1;
				}else{
					thknd=1;
				}
			}else{
				pr+=1;
				if(nm_fr==nm_ff){
					pr+=1;
				}
			}
		}else{
			if(nm_rd==nm_fr){
				if(nm_rd==nm_ff){
					thknd=1;
				}else{
					pr+=1;
				}
			}else{
				if(nm_fr==nm_ff){
					pr+=1;
				}
			}
		}
	}
//----------------------------------------------------------------
//output
	if(smcl==4&&str==1){
		printf("Straight Flush\n");
	}else{
		if(frknd==1){
			printf("Four Of A Kind\n");
		}else{
			if(thknd==1&&pr==1){
				printf("Full House\n");
			}else{
				if(smcl==4){
					printf("Flush\n");
				}else{
					if(str==1){
						printf("Straight\n");
					}else{
						if(thknd==1){
							printf("Three Of A Kind\n");
						}else{
							if(pr==2){
								printf("Two Pair\n");
							}else{
								if(pr==1){
									printf("One Pair\n");
								}else{
									printf("High Card\n");
								}
							}
						}
					}
				}
			}
		}
	}
//----------------------------------------------------------------
}
//----------------------------------------------------------------
//test area :D
	/*printf("%d %d %d %d %d",fs,sc,th,fr,ff);
	printf("%d %d %d %d %d\n",nm_st,nm_nd,nm_rd,nm_fr,nm_ff);
	printf("%d %d %d %d %d\n",cl_st,cl_nd,cl_rd,cl_fr,cl_ff);
	printf("%hhd\n",str);
	printf("%hhd\n",smcl);
	printf("%hhd %hhd %hhd\n",pr,thknd,frknd);
	*/
//----------------------------------------------------------------
	return 0;
}




