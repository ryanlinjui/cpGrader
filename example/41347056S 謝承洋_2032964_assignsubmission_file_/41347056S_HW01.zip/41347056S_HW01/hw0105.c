#include<stdio.h>
#include<stdint.h>

int main(){
//----------------------------------------------------------------
//variables
	int8_t sgn=0; uint8_t wng=1;
	int32_t bs5=0;int32_t bs4=0;int32_t bs3=0;int32_t bs2=0; int32_t bs1=0;
	int32_t fr10=0;int32_t fr9=0;int32_t fr8=0;int32_t fr7=0;int32_t fr6=0;
	int32_t fr5=0;int32_t fr4=0;int32_t fr3=0;int32_t fr2=0; int32_t fr1=0;
	uint16_t input=0;uint8_t chc=0;int32_t bs=0;float fr=0;
//----------------------------------------------------------------
//get input
	printf("Please input a hex:");
	scanf("%hx",&input);
	printf("Please choose the output type(1:integer,2:unsigned integer,3:float):");
	scanf("%hhd",&chc);
	if(chc<1||chc>3){
		wng=1;
	}else{
		wng=0;
	}
//----------------------------------------------------------------
//fill the variables
if(wng==1){
	printf("Wrong Input!\n");
}else{
	sgn=input/32768;
	bs5=(input/16384)-(input/32768)*2;
	bs4=(input/8192)-(input/16384)*2;
	bs3=(input/4096)-(input/8192)*2;
	bs2=(input/2048)-(input/4096)*2;
	bs1=(input/1024)-(input/2048)*2;
	fr10=(input/512)-(input/1024)*2;
	fr9=(input/256)-(input/512)*2;
	fr8=(input/128)-(input/256)*2;
	fr7=(input/64)-(input/128)*2;
	fr6=(input/32)-(input/64)*2;
	fr5=(input/16)-(input/32)*2;
	fr4=(input/8)-(input/16)*2;
	fr3=(input/4)-(input/8)*2;
	fr2=(input/2)-(input/4)*2;
	fr1=(input/1)-(input/2)*2;
//----------------------------------------------------------------
//output
	printf("Binary of %hx is: ",input);
	printf("%hhd%d%d%d ",sgn,bs5,bs4,bs3);
	printf("%d%d%d%d ",bs2,bs1,fr10,fr9);
	printf("%d%d%d%d ",fr8,fr7,fr6,fr5);
	printf("%d%d%d%d\n",fr4,fr3,fr2,fr1);
	if(chc==1){
		printf("Converted integer is: ");
		printf("%d\n",input);
	}
	if(chc==2){
		printf("Converted unsigned integer is: ");
		printf("%hi\n",input);
	}
	if(chc==3){
		bs=bs5*16+bs4*8+bs3*4+bs2*2+bs1*1;
		fr=(float)fr10/2+(float)fr9/4+(float)fr8/8+(float)fr7/16+(float)fr6/32+(float)fr5/64+(float)fr4/128+(float)fr3/256+(float)fr2/512+(float)fr1/1024;
		if(bs==0){
//bs5==0 && bs4==0 && bs3==0 && bs2==0 && bs1==0
			if(fr==0){
				printf("Converted float is: 0\n");
			}else{
				printf("Converted float is: ");
				if(sgn==1){
					printf("-");
				}
				printf("%f*2^%d\n",fr,bs-15);
			}
		}else{
			if(bs==31){
				if(fr==0){
					printf("Converted float is: ");
					if(sgn==1){
						printf("Negative infinite\n");
					}else{
						printf("Positve infinite\n");
					}
				}
				if(fr!=0){
					printf("The number is not appropriate to be converted in float!\n");
				}
			}else{
				printf("Converted float is: ");
				if(sgn==1){
					printf("-");
				}
				printf("%f*2^%d\n",(float)1+fr,bs-15);
			}
		}
	}
//----------------------------------------------------------------
//test area:D
	//printf("%hhd\n",sgn);
	//printf("%d\n",bs);

	return 0;
}
}
