#include <stdio.h>
#include <stdint.h>

int main()
{
	int32_t tp_hn = -1;int32_t tp_nt = -1;
	int32_t md_tn = -1;
	int32_t sum = -1;
	int8_t error=1;
	//smmns for summary after the minus
	int32_t smmns = -1;
	int32_t x = -1;int32_t y = -1; int32_t z = -1;

//get input
	printf("Please enter the first  operand:");
	scanf("%dx%d",&tp_hn,&tp_nt);
	if(tp_hn<0||tp_hn>=10||tp_nt<0||tp_nt>=10){
		error=1;
	}else{
		printf("Please enter the second operand:");
		scanf(" y%dz",&md_tn);
		if(md_tn<0||md_tn>=10){
			error=1;
		}else{
			printf("Please enter the sum:");
			scanf(" %d",&sum);
			if(sum<0||sum>1998){
				error=1;
			}else{
				error=0;
			}
		}
	}
	

//output
	if(error==0){
		smmns = sum-(tp_hn*100+md_tn*10+tp_nt);
		y = smmns/100;
		x = smmns%100/10;
		z = smmns%10;
		if(x<0||x>=10||y<0||y>=10||z<0||z>=10){
			printf("Wrong Input!\n");
		}else{
			printf("x = %i, y = %i, z = %i\n",x,y,z);
		}
	}else{
		printf("Wrong Input!\n");
	}
//test area :D
	//printf("%d%d%d",tp_hn,tp_nt,md_tn);
	
	return 0;
}
