#include <stdio.h>
#include <stdint.h>

int main()
{
//31 for red; 34 for blue 32 for green
	//printf("\033[37m\033[0m\n");
	//printf("\033[34mtest2\033[0m\n");
	printf("[KIM]\n");
	printf("\33[31mYou are sunlight and I moon\33[0m\n");
	printf("\33[31mJoined by the gods of fortune\33[0m\n");
	printf("\33[31mMidnight and high noon sharing the sky\33[0m\n");
	printf("\33[31mWe have been blessed, you and I\33[0m\n");
	printf("\n[CHRIS]\n");
	printf("\33[34mYou are here like a mystery\n"
	"I'm from a world that's so different from all that you are\n"
	"How in the light of one night did we come so far?\33[0m\n\n[KIM]\n");
	printf("\33[31mOutside day starts to dawn\33[0m\n\n");
	printf("[CHRIS]\n\33[34mYour moon still floats on high\33[0m\n\n");
	printf("[KIM]\n\33[31mThe birds awake\33[0m\n\n");
	printf("[CHRIS]\n\33[34mThe stars shine too\33[0m\n\n");
	printf("[KIM]\n\33[31mMy hands still shake\n"
	"See upcoming pop shows\n"
	"Get tickets for your favorite artist\n\n"
	"You might also like\n"
	"My Boys Only Breaks His Favorite Toys\n"
	"Taylor Swift\n"
	"Who' s Afraid Of Little Old Me?\n"
	"Taylor Swift\n"
	"Guity As Sin?\n"
	"Taylor Swift\33[0m\n\n");
	printf("[CHRIS]\n\33[34mI reach for you\33[0m\n\n");
	printf("[KIM & CHRIS]\n\33[32mAnd we meet in the sky\33[0m\n\n");
	printf("[KIM]\n\33[31mYou are sunlight and I moon\n"
	"Joined here\n"
	"Brightening the sky with the flame of love\33[0m\n\n");
	printf("[KIM & CHRIS]\n\33[32m"
	"Made of\n"
	"Sunlight\n"
	"Moonlight\33[0m\n");

	return 0;
}
