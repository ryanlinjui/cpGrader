#include <stdio.h>
#include <stdint.h>

int main(){
    int32_t card1 = 0, card2 = 0, card3 = 0, card4 = 0, card5 = 0; 
    int32_t suit1, suit2, suit3, suit4, suit5;
    int32_t num1, num2, num3, num4, num5;
    int32_t s_num = 13;
    int32_t s_card;
    
    printf("Please enter 5 cards:");
    scanf("%d%d%d%d%d", &card1, &card2, &card3, &card4, &card5);
    //printf("%d%d%d%d%d\n", card1, card2, card3, card4, card5);
    if( (card1 < 1) || (card2 < 1) || (card3 < 1) || (card4 < 1) || (card5 < 1) || (card1 > 52) || (card2 > 52) || (card3 > 52) || (card4 > 52) || (card5 > 52) ){
        printf("Input error\n");
        return 0;
    }
    if( (card1 == card2) || (card1 == card3) || (card1 == card4) || (card1 == card5) || (card3 == card2) || (card4 == card2) || (card5 == card2) || (card3 == card4) || (card3 == card5) || (card4 == card5) ){
        printf("Input error\n");
        return 0;
    }
    if( card1 < 14 ){
        suit1 = 1;
        num1 = card1;
    }
    else if( card1 < 27 ){
        suit1 = 2;
        num1 = card1 - 13;
    }
    else if( card1 < 40 ){
        suit1 = 3;
        num1 = card1 - 26;
    }
    else{
        suit1 = 4;
        num1 = card1 - 39;
    }    
    if( card2 < 14 ){
        suit2 = 1;
        num2 = card2;
    }
    else if( card2 < 27 ){
        suit2 = 2;
        num2 = card2 - 13;
    }
    else if( card2 < 40 ){
        suit2 = 3;
        num2 = card2 - 26;
    }
    else{
        suit2 = 4;
        num2 = card2 - 39;
    }
    if( card3 < 14 ){
        suit3 = 1;
        num3 = card3;
    }
    else if( card3 < 27 ){
        suit3 = 2;
        num3 = card3 - 13;
    }
    else if( card3 < 40 ){
        suit3 = 3;
        num3 = card3 - 26;
    }
    else{
        suit3 = 4;
        num3 = card3 - 39;
    }
    if( card4 < 14 ){
        suit4 = 1;
        num4 = card4;
    }
    else if( card4 < 27 ){
        suit4 = 2;
        num4 = card4 - 13;
    }
    else if( card4 < 40 ){
        suit4 = 3;
        num4 = card4 - 26;
    }
    else{
        suit4 = 4;
        num4 = card4 - 39;
    }
    if( card5 < 14 ){
        suit5 = 1;
        num5 = card5;
    }
    else if( card5 < 27 ){
        suit5 = 2;
        num5 = card5 - 13;
    }
    else if( card5 < 40 ){
        suit5 = 3;
        num5 = card5 - 26;
    }
    else{
        suit5 = 4;
        num5 = card5 - 39;
    }
    //-----------------------
    if( ( suit1 == suit2) && ( suit2 == suit3 ) && ( suit3 == suit4 ) && ( suit4 == suit5) ){
        if( num1 < s_num ){
            s_num = num1;
            s_card = 1;
        }
        if( num2 < s_num ){
            s_num = num2;
            s_card = 2;
        }
        if( num3 < s_num ){
            s_num = num3;
            s_card = 3;
        }
        if( num4 < s_num ){
            s_num = num4;
            s_card = 4;
        }
        if( num5 < s_num ){
            s_num = num5;
            s_card = 5;
        }
        if( s_num > 10){
            printf("Flush\n");
            return 0;
        }
        else if( s_num == 1 && (num1 == 13 || num2 == 13 || num3 == 13 || num4 == 13 || num5 == 13)){
            if( ((num1 == 1) || (num2 == 1) || (num3 == 1) || (num4 == 1) || (num5 == 1)) && ((num1 == 10) || (num2 == 10) || (num3 == 10) || (num4 == 10) || (num5 == 10)) && ((num1 == 11) || (num2 == 11) || (num3 == 11) || (num4 == 11) || (num5 == 11)) && ((num1 == 12) || (num2 == 12) || (num3 == 12) || (num4 == 12) || (num5 == 12)) && ((num1 == 13) || (num2 == 13) || (num3 == 13) || (num4 == 13) || (num5 == 13)) ){
                printf("Straight flush\n");
                return 0;
            }
            else{
                printf("Flush\n");
                return 0;
            }
        }
        else{
            if( s_card == 1 ){
                if( ((num2 == s_num + 1) || (num3 == s_num + 1) || ( num4 == s_num + 1) || (num5 == s_num + 1)) && ((num2 == s_num + 2) || (num3 == s_num + 2) || (num4 == s_num + 2) || (num5 == s_num + 2)) && ((num2 == s_num + 3) || (num3 == s_num + 3) || (num4 == s_num + 3) || (num5 == s_num + 3)) && ((num2 == s_num + 4) || (num3 == s_num + 4) || (num4 == s_num + 4) || (num5 == s_num + 4)) ){
                    printf("Straight flush\n");
                    return 0;                    
                }
                else{
                    printf("Flush\n");
                    return 0;
                }
            }
            if( s_card == 2 ){
                if( ((num1 == s_num + 1) || (num3 == s_num + 1) || ( num4 == s_num + 1) || (num5 == s_num + 1)) && ((num1 == s_num + 2) || (num3 == s_num + 2) || (num4 == s_num + 2) || (num5 == s_num + 2)) && ((num1 == s_num + 3) || (num3 == s_num + 3) || (num4 == s_num + 3) || (num5 == s_num + 3)) && ((num1 == s_num + 4) || (num3 == s_num + 4) || (num4 == s_num + 4) || (num5 == s_num + 4)) ){
                    printf("Straight flush\n");
                    return 0;                    
                }
                else{
                    printf("flush\n");
                    return 0;
                }
            }
            if( s_card == 3 ){
                if( ((num1 == s_num + 1) || (num2 == s_num + 1) || ( num4 == s_num + 1) || (num5 == s_num + 1)) && ((num1 == s_num + 2) || (num2 == s_num + 2) || (num4 == s_num + 2) || (num5 == s_num + 2)) && ((num1 == s_num + 3) || (num2 == s_num + 3) || (num4 == s_num + 3) || (num5 == s_num + 3)) && ((num1 == s_num + 4) || (num2 == s_num + 4) || (num4 == s_num + 4) || (num5 == s_num + 4)) ){
                    printf("Straight flush\n");
                    return 0;                    
                }
                else{
                    printf("Flush\n");
                    return 0;
                }
            }
            if( s_card == 4 ){
                if( ((num1 == s_num + 1) || (num2 == s_num + 1) || ( num3 == s_num + 1) || (num5 == s_num + 1)) && ((num1 == s_num + 2) || (num2 == s_num + 2) || (num3 == s_num + 2) || (num5 == s_num + 2)) && ((num1 == s_num + 3) || (num2 == s_num + 3) || (num3 == s_num + 3) || (num5 == s_num + 3)) && ((num1 == s_num + 4) || (num2 == s_num + 4) || (num3 == s_num + 4) || (num5 == s_num + 4)) ){
                    printf("Straight flush\n");
                    return 0;                    
                }
                else{
                    printf("Flush\n");
                    return 0;
                }
            }
            if( s_card == 5 ){
                if( ((num1 == s_num + 1) || (num2 == s_num + 1) || ( num3 == s_num + 1) || (num4 == s_num + 1)) && ((num1 == s_num + 2) || (num2 == s_num + 2) || (num3 == s_num + 2) || (num4 == s_num + 2)) && ((num1 == s_num + 3) || (num2 == s_num + 3) || (num3 == s_num + 3) || (num4 == s_num + 3)) && ((num1 == s_num + 4) || (num2 == s_num + 4) || (num3 == s_num + 4) || (num4 == s_num + 4)) ){
                    printf("Straight flush\n");
                    return 0;                    
                }
                else{
                    printf("Flush\n");
                    return 0;
                }
            }
        
        }
    }
    else if( (num1 == num2 && num2 == num3 && num3 == num4) || (num1 == num2 && num2 == num3 && num3 == num5) || (num1 == num2 && num2 == num5 && num5 == num4) ||(num1 == num5 && num5 == num3 && num3 == num4) || (num5 == num2 && num2 == num3 && num3 == num4) ){
        printf("Four of a kind\n");
        return 0;        
    }
    else if( ((num1 == num2) && (num2 == num3)) || ((num1 == num2) && (num2 == num4)) || ((num1 == num2) && (num2 == num5)) || ((num1 == num4) && (num4 == num3)) || ((num1 == num5) && (num5 == num3)) || ((num1 == num4) && (num4 == num5)) || ((num4 == num2) && (num2 == num3)) || ((num5 == num2) && (num2 == num3)) || ((num5 == num2) && (num2 == num4)) || ((num3 == num4) && (num4 == num5)) ){
        if( (num1 == num2) && (num2 == num3) ){
            if( num4 == num5 ){
                printf("Full house\n");
                return 0;
            }
            else{
                printf("Three pair\n");
                return 0;
            }
        }
        else if( (num1 == num2) && (num2 == num4) ){
            if( num3 == num5 ){
                printf("Full house\n");
                return 0;
            }
            else{
                printf("Three pair\n");
                return 0;
            }
        }
        else if( (num1 == num2) && (num2 == num5) ){
            if( num3 == num4 ){
                printf("Full house\n");
                return 0;
            }
            else{
                printf("Three pair\n");
                return 0;
            }
        }
        else if( (num1 == num3) && (num3 == num4) ){
            if( num2 == num5 ){
                printf("Full house\n");
                return 0;
            }
            else{
                printf("Three pair\n");
                return 0;
            }
        }
        else if( (num1 == num3) && (num3 == num5) ){
            if( num2 == num4 ){
                printf("Full house\n");
                return 0;
            }
            else{
                printf("Three pair\n");
                return 0;
            }
        }
        else if( (num1 == num5) && (num5 == num4) ){
            if( num3 == num2 ){
                printf("Full house\n");
                return 0;
            }
            else{
                printf("Three pair\n");
                return 0;
            }
        }
        else if( num3 == num2 && num2 == num4 ){
            if( num1 == num5 ){
                printf("Full house\n");
                return 0;
            }
            else{
                printf("Three pair\n");
                return 0;
            }
        }
        else if( num3 == num2 && num2 == num5 ){
            if( num1 == num4 ){
                printf("Full house\n");
                return 0;
            }
            else{
                printf("Three pair\n");
                return 0;
            }
        }
        else if( num5 == num2 && num2 == num4 ){
            if( num3 == num1 ){
                printf("Full house\n");
                return 0;
            }
            else{
                printf("Three pair\n");
                return 0;
            }
        }
        else{
            if( num1 == num2 ){
                printf("Full house\n");
                return 0;
            }
            else{
                printf("Three pair\n");
                return 0;
            }
        }
    }
    else if( (num1 == num2) || (num1 == num3) || (num1 == num4) || (num1 == num5) || (num3 == num2) || (num4 == num2) || (num5 == num2) || (num3 == num4) || (num3 == num5) || (num4 == num5) ){
        if( num1 == num2){
            if( (num3 == num4) || (num3 == num5) || (num4 == num5) ){
                printf("Two pair\n");
                return 0;
            }
            else{
                printf("One pair\n");
                return 0;
            }
        }
        else if( num1 == num3){
            if( (num2 == num4) || (num2 == num5) || (num4 == num5) ){
                printf("Two pair\n");
                return 0;
            }
            else{
                printf("One pair\n");
                return 0;
            }
        }
        else if( num1 == num4){
            if( (num2 == num3) || (num2 == num5) || (num3 == num5) ){
                printf("Two pair\n");
                return 0;
            }
            else{
                printf("One pair\n");
                return 0;
            }
        }
        else if( num1 == num5){
            if( (num2 == num4) || (num2 == num3) || (num4 == num3) ){
                printf("Two pair\n");
                return 0;
            }
            else{
                printf("One pair\n");
                return 0;
            }
        }
        else if( num2 == num3){
            if( (num1 == num4) || (num1 == num5) || (num4 == num5) ){
                printf("Two pair\n");
                return 0;
            }
            else{
                printf("One pair\n");
                return 0;
            }
        }
        else if( num2 == num4){
            if( (num1 == num3) || (num1 == num5) || (num3 == num5) ){
                printf("Two pair\n");
                return 0;
            }
            else{
                printf("One pair\n");
                return 0;
            }
        }
        else if( num2 == num5){
            if( (num1 == num4) || (num1 == num3) || (num4 == num3) ){
                printf("Two pair\n");
                return 0;
            }
            else{
                printf("One pair\n");
                return 0;
            }
        }
        else if( num4 == num3){
            if( (num2 == num1) || (num2 == num5) || (num1 == num5) ){
                printf("Two pair\n");
                return 0;
            }
            else{
                printf("One pair\n");
                return 0;
            }
        }
        else if( num5 == num3){
            if( (num2 == num4) || (num2 == num1) || (num4 == num1) ){
                printf("Two pair\n");
                return 0;
            }
            else{
                printf("One pair\n");
                return 0;
            }
        }
        else{
            if( (num2 == num1) || (num2 == num3) || (num1 == num3) ){
                printf("Two pair\n");
                return 0;
            }
            else{
                printf("One pair\n");
                return 0;
            }
        }       
    }
    //---- 
    else{
        if( num1 < s_num ){
            s_num = num1;
            s_card = 1;
        }
        if( num2 < s_num ){
            s_num = num2;
            s_card = 2;
        }
        if( num3 < s_num ){
            s_num = num3;
            s_card = 3;
        }
        if( num4 < s_num ){
            s_num = num4;
            s_card = 4;
        }
        if( num5 < s_num ){
            s_num = num5;
            s_card = 5;
        }
        if( s_num > 10){
            printf("High card\n");
            return 0;
        }
        else if( s_num == 1 && (num1 == 13 || num2 == 13 || num3 == 13 || num4 == 13 || num5 == 13)){
            if( ((num1 == 1) || (num2 == 1) || (num3 == 1) || (num4 == 1) || (num5 == 1)) && ((num1 == 10) || (num2 == 10) || (num3 == 10) || (num4 == 10) || (num5 == 10)) && ((num1 == 11) || (num2 == 11) || (num3 == 11) || (num4 == 11) || (num5 == 11)) && ((num1 == 12) || (num2 == 12) || (num3 == 12) || (num4 == 12) || (num5 == 12)) && ((num1 == 13) || (num2 == 13) || (num3 == 13) || (num4 == 13) || (num5 == 13)) ){
                printf("Straight\n");
                return 0;
            }
            else{
                printf("High card\n");
                return 0;
            }
        }
        else{
            if( s_card == 1 ){
                if( ((num2 == s_num + 1) || (num3 == s_num + 1) || ( num4 == s_num + 1) || (num5 == s_num + 1)) && ((num2 == s_num + 2) || (num3 == s_num + 2) || (num4 == s_num + 2) || (num5 == s_num + 2)) && ((num2 == s_num + 3) || (num3 == s_num + 3) || (num4 == s_num + 3) || (num5 == s_num + 3)) && ((num2 == s_num + 4) || (num3 == s_num + 4) || (num4 == s_num + 4) || (num5 == s_num + 4)) ){
                    printf("Straight\n");
                    return 0;                    
                }
                else{
                    printf("High card\n");
                    return 0;
                }
            }
            if( s_card == 2 ){
                if( ((num1 == s_num + 1) || (num3 == s_num + 1) || ( num4 == s_num + 1) || (num5 == s_num + 1)) && ((num1 == s_num + 2) || (num3 == s_num + 2) || (num4 == s_num + 2) || (num5 == s_num + 2)) && ((num1 == s_num + 3) || (num3 == s_num + 3) || (num4 == s_num + 3) || (num5 == s_num + 3)) && ((num1 == s_num + 4) || (num3 == s_num + 4) || (num4 == s_num + 4) || (num5 == s_num + 4)) ){
                    printf("Straight\n");
                    return 0;                    
                }
                else{
                    printf("High card\n");
                    return 0;
                }
            }
            if( s_card == 3 ){
                if( ((num1 == s_num + 1) || (num2 == s_num + 1) || ( num4 == s_num + 1) || (num5 == s_num + 1)) && ((num1 == s_num + 2) || (num2 == s_num + 2) || (num4 == s_num + 2) || (num5 == s_num + 2)) && ((num1 == s_num + 3) || (num2 == s_num + 3) || (num4 == s_num + 3) || (num5 == s_num + 3)) && ((num1 == s_num + 4) || (num2 == s_num + 4) || (num4 == s_num + 4) || (num5 == s_num + 4)) ){
                    printf("Straight\n");
                    return 0;                    
                }
                else{
                    printf("High card\n");
                    return 0;
                }
            }
            if( s_card == 4 ){
                if( ((num1 == s_num + 1) || (num2 == s_num + 1) || ( num3 == s_num + 1) || (num5 == s_num + 1)) && ((num1 == s_num + 2) || (num2 == s_num + 2) || (num3 == s_num + 2) || (num5 == s_num + 2)) && ((num1 == s_num + 3) || (num2 == s_num + 3) || (num3 == s_num + 3) || (num5 == s_num + 3)) && ((num1 == s_num + 4) || (num2 == s_num + 4) || (num3 == s_num + 4) || (num5 == s_num + 4)) ){
                    printf("Straight\n");
                    return 0;                    
                }
                else{
                    printf("High card\n");
                    return 0;
                }
            }
            if( s_card == 5 ){
                if( ((num1 == s_num + 1) || (num2 == s_num + 1) || ( num3 == s_num + 1) || (num4 == s_num + 1)) && ((num1 == s_num + 2) || (num2 == s_num + 2) || (num3 == s_num + 2) || (num4 == s_num + 2)) && ((num1 == s_num + 3) || (num2 == s_num + 3) || (num3 == s_num + 3) || (num4 == s_num + 3)) && ((num1 == s_num + 4) || (num2 == s_num + 4) || (num3 == s_num + 4) || (num4 == s_num + 4)) ){
                    printf("Straight\n");
                    return 0;                    
                }
                else{
                    printf("High card\n");
                    return 0;
                }
            }
        }   
    }
    return 0;
}