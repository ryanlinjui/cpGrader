#include <stdio.h>
#include <stdint.h>

int main(){

    int32_t num = -1;
    int32_t octal1, octal2, octal3, octal4, octal5, octal6;
    int32_t after_num = 0;
    
    printf("Please enter an unsigned 16-bits number: ");
    scanf("%d",&num);
    if( num < 0 || num > 65535 ){
        printf("Input Error\n");
        return 0;
    }
    octal6 = num%8;
    octal5 = num/8;
    octal4 = octal5/8;
    octal5 = octal5%8;
    octal3 = octal4/8;
    octal4 = octal4%8;
    octal2 = octal3/8;
    octal3 = octal3%8;
    octal1 = octal2/8;
    octal2 = octal2%8;
    //printf("octal = %d%d%d%d%d%d\n",octal1, octal2, octal3, octal4, octal5, octal6);
    
    if( num < 8 ){
        printf("Before Flip:\n");
        printf("%d_10 = %d_8\n", num, octal6);
        printf("After  Flip:\n");
        printf("%d_8 = %d_10\n", octal6, num);
    }
    else if( num < 64 ){
        printf("Before Flip:\n");
        printf("%d_10 = %d%d_8\n", num, octal5, octal6);
        printf("After  Flip:\n");
        after_num = octal6*8 + octal5;
        printf("%d%d_8 = %d_10\n", octal6, octal5, after_num);
    }
    else if( num < 512 ){
        printf("Before Flip:\n");
        printf("%d_10 = %d%d%d_8\n", num, octal4, octal5, octal6);
        printf("After  Flip:\n");
        after_num = octal6*8*8 + octal5*8 + octal4;
        printf("%d%d%d_8 = %d_10\n", octal6, octal5, octal4, after_num);
    }
    else if( num < 4096 ){
        printf("Before Flip:\n");
        printf("%d_10 = %d%d%d%d_8\n", num, octal3, octal4, octal5, octal6);
        printf("After  Flip:\n");
        after_num = octal6*8*8*8 + octal5*8*8 + octal4*8 + octal3;
        printf("%d%d%d%d_8 = %d_10\n", octal6, octal5, octal4, octal3, after_num);
    }
    else if( num < 32768 ){
        printf("Before Flip:\n");
        printf("%d_10 = %d%d%d%d%d_8\n", num, octal2, octal3, octal4, octal5, octal6);
        printf("After  Flip:\n");
        after_num = octal6*8*8*8*8 + octal5*8*8*8 + octal4*8*8 + octal3*8 + octal2;
        printf("%d%d%d%d%d_8 = %d_10\n", octal6, octal5, octal4, octal3, octal2, after_num);
    }
    else{
        printf("Before Flip:\n");
        printf("%d_10 = %d%d%d%d%d%d_8\n", num, octal1, octal2, octal3, octal4, octal5, octal6);
        printf("After  Flip:\n");
        after_num = octal6*8*8*8*8*8 + octal5*8*8*8*8 + octal4*8*8*8 + octal3*8*8 + octal2*8 + octal1;
        printf("%d%d%d%d%d%d_8 = %d_10\n", octal6, octal5, octal4, octal3, octal2, octal1, after_num);
    }
    return 0;
}