#include <stdio.h>
#include <stdint.h>

int main(){

    int32_t A1, A3, B2;
    int32_t sum;
    int32_t sum1, sum2, sum3, sum4;
    int32_t x, y, z;
    
    printf("Please enter the first  operand:");
    scanf("%d%*c%d", &A1, &A3);
    if( A1 >= 10 || A1 < 0 || A3 >= 10 || A3 < 0){
        printf("Input ERROR\n");
        return 0;
    }
    printf("Please enter the second operand:");
    scanf("\n");
    scanf("%*c%d%*c", &B2);
    if( B2 >= 10 || B2 < 0){
        printf("Input ERROR\n");
        return 0;
    }
    printf("Please enter the sum           :");
    scanf("%d", &sum);
    if( sum >= 2000 || sum < 0){
        printf("Abnormal sum value\n");
        return 0;
    }
    printf("A1 = %d, A3 = %d, B2 = %d\n", A1, A3, B2);
    
    sum1 = sum/1000;
    sum2 = (sum/100)-(sum1*10);
    sum3 = (sum/10)-(sum1*100)-(sum2*10);
    sum4 = sum-(sum1*1000)-(sum2*100)-(sum3*10);
    //printf("Sum = %d,%d,%d,%d\n", sum1, sum2, sum3, sum4);
    
    if( sum4 >= A3 ){
        z = sum4 - A3;     
    }
    else{
        z = sum4 + 10 - A3;
        sum3 -= 1;
    }
    if( sum3 >= B2 ){
        x = sum3 - B2; 
    }
    else{
        x = sum3 + 10 - B2;
        sum2 -= 1;
    }
    if( sum2 >= A1 ){
        y = sum2 - A1; 
    }
    else{
        y = sum2 + 10 - A1;
        sum1 -= 1;
    }
    int32_t csum = (A3+z) + 10*(B2+x) + 100*(A1+y);
    //printf("csum = %d\n",csum);
    if( sum > csum ){
        printf("Abnormal sum value\n");
        return 0;
    }
    printf("Ans: x = %d, y = %d, z = %d\n", x, y, z);
    
    return 0;
}