#include <stdio.h>
#include <stdint.h>

int main(){
    int32_t bit1, bit2, bit3, bit4, bit5, bit6, bit7, bit8, bit9, bit10, bit11, bit12, bit13, bit14, bit15, bit16;
    int32_t type = 0;
    int32_t integer;
    int32_t EXP = 0;
    double F = 1.0;
    
    int32_t hex;
    printf("Please input a hex:");
    scanf("%x", &hex);
    //--
    if( hex < 1 || hex > 65535 ){
        printf("Input error\n");
        return 0;
    }
    //--
    printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
    scanf("%d", &type);
    int32_t copy_hex = hex;
    //--
    if( type < 1 || type > 3 ){
        printf("Input error\n");
        return 0;
    }
    //--
    if( (hex/32768) == 1 ){
        bit1 = 1;
        hex -= 32768;
    }
    if( (hex/16384) == 1 ){
        bit2 = 1;
        hex -= 16384;
    }
    if( (hex/8192) == 1 ){
        bit3 = 1;
        hex -= 8192;
    }
    if( (hex/4096) == 1 ){
        bit4 = 1;
        hex -= 4096;
    }
    if( (hex/2048) == 1 ){
        bit5 = 1;
        hex -= 2048;
    }
    if( (hex/1024) == 1 ){
        bit6 = 1;
        hex -= 1024;
    }
    if( (hex/512) == 1 ){
        bit7 = 1;
        hex -= 512;
    }
    if( (hex/256) == 1 ){
        bit8 = 1;
        hex -= 256;
    }
    if( (hex/128) == 1 ){
        bit9 = 1;
        hex -= 128;
    }

    if( (hex/64) == 1 ){
        bit10 = 1;
        hex -= 64;
    }
    if( (hex/32) == 1 ){
        bit11 = 1;
        hex -= 32;
    }
    if( (hex/16) == 1 ){
        bit12 = 1;
        hex -= 16;
    }
    if( (hex/8) == 1 ){
        bit13 = 1;
        hex -= 8;
    }
    if( (hex/4) == 1 ){
        bit14 = 1;
        hex -= 4;
    }
    if( (hex/2) == 1 ){
        bit15 = 1;
        hex -= 2;
    }
    if( hex == 1 ){
        bit16 = 1;
        hex -= 1;
    }
    else{
        bit16 = 0;
    }
    //--
    
    //printf("%d\n",hex);
    //printf("%x\n",hex);
    printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n", copy_hex, bit1, bit2, bit3, bit4, bit5, bit6, bit7, bit8, bit9, bit10, bit11, bit12, bit13, bit14, bit15, bit16);
    if( type == 2 ){
        printf("Converted unsigned integer is: %d\n", copy_hex);
        return 0;
    }
    else if( type == 1 ){
        if( bit1 == 0 ){
            printf("Converted integer is: %d\n", copy_hex);
            return 0;
        }
        else{
            if( bit2 == 0 ){
                integer += 16384; 
            }
            if( bit3 == 0 ){
                integer += 8192; 
            }
            if( bit4 == 0 ){
                integer += 4096; 
            }
            if( bit5 == 0 ){
                integer += 2048; 
            }
            if( bit6 == 0 ){
                integer += 1024; 
            }
            if( bit7 == 0 ){
                integer += 512; 
            }
            if( bit8 == 0 ){
                integer += 256; 
            }
            if( bit9 == 0 ){
                integer += 128; 
            }
            if( bit10 == 0 ){
                integer += 64; 
            }
            if( bit11 == 0 ){
                integer += 32; 
            }
            if( bit12 == 0 ){
                integer += 16; 
            }
            if( bit13 == 0 ){
                integer += 8; 
            }
            if( bit14 == 0 ){
                integer += 4; 
            }
            if( bit15 == 0 ){
                integer += 2; 
            }
            if( bit16 == 0 ){
                integer += 1; 
            }
            integer += 1;
            printf("Converted integer is: -%d\n", integer);
            return 0;
        }
    }
    else{
        if( bit2 == 1 ){
            EXP += 16;
        }
        if( bit3 == 1 ){
            EXP += 8;
        }
        if( bit4 == 1 ){
            EXP += 4;
        }
        if( bit5 == 1 ){
            EXP += 2;
        }
        if( bit6 == 1 ){
            EXP += 1;
        }
        EXP -= 15;
        if( bit7 == 1){
            F += 0.5;
        }
        if( bit8 == 1){
            F += 0.25;
        }
        if( bit9 == 1){
            F += 0.125;
        }
        if( bit10 == 1){
            F += 0.0625;
        }
        if( bit11 == 1){
            F += 0.03125;
        }
        if( bit12 == 1){
            F += 0.015625;
        }
        if( bit13 == 1){
            F += 0.0078125;
        }
        if( bit14 == 1){
            F += 0.00390625;
        }
        if( bit15 == 1){
            F += 0.00195312;
        }
        if( bit16 == 1){
            F += 0.00097656;
        }
        if( bit1 == 0 ){
            printf("Converted float is: %.6f*2^%d\n", F, EXP);
            return 0;
        }
        else{
            printf("Converted float is: -%.6f*2^%d\n", F, EXP);
            return 0;
        }
        
        return 0;
    }    
    return 0;
}