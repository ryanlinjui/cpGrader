#include<stdio.h>
#include<stdint.h>

uint16_t num = 0;
uint16_t n = 0;
//num_8是abcdef;
uint32_t num_8 = 0;
uint16_t a = 0;
uint16_t b = 0;
uint16_t c = 0;
uint16_t d = 0;
uint16_t e = 0;
uint16_t f = 0;
//uint16_t x = 6;//位數
uint32_t new_8 = 0;
uint16_t new = 0;


int main()
{
    printf("Please enter an unsigned 16-bits number: ");
    scanf("%hd", &num);
    if( num < 0 || num > 65535)
    {
        printf("wrong number");
    }
    else
    {
        n = num;
        f = n % 8;
        n = n / 8;
        //printf("%d\n", f);
        //printf("%d\n", num);
        e = n % 8;
        n = n / 8;
        d = n % 8;
        n = n / 8;
        c = n % 8;
        n = n / 8;
        b = n % 8;
        n = n / 8;
        a = n % 8;
        //printf("a=%d b=%d c=%d d=%d e=%d f=%d", a, b, c, d, e, f);

        num_8 = a*100000 + b*10000 + c*1000 + d*100 + e*10 + f;
        //printf("num_8 is :%d\n", num_8);

        if(a==0)
        {
            new_8 = f*10000 + e*1000 + d*100 + c*10 + b;
            if(b==0)
            {
                new_8 = f*1000 + e*100 + d*10 + c;
                if(c==0)
                {
                    new_8 = f*100 + e*10 + d;
                    if(d==0)
                    {
                        new_8 = f*10 + e;
                        if(e==0)
                        {
                            new_8 = f;
                            if(f==0)
                            {
                                new_8 = 0;
                            }
                        }
                    }
                }
            }
        }
        else
        {
            new_8 = f*100000 + e*10000 + d*1000 + c*100 + b*10 + a;
        }
        //printf("%d\n", new_8);
    }
    new = f*8*8*8*8*8 + e*8*8*8*8 + d*8*8*8 + c*8*8 + b*8 + a;

    printf("Before Flip:\n");
    printf("%d_10 = %d_8\n", num, num_8);
    printf("After Flip:\n");
    printf("%d_8 = %d_10\n", new_8, new);
}