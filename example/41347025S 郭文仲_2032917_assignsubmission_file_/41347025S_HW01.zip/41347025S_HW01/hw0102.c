#include<stdio.h>
#include<stdint.h>

int32_t a = -1;
int32_t b = -1;
int32_t c = -1;
int32_t num = 0;
int32_t sum = 0;
int32_t ans = 0;
int32_t x = 0;
int32_t y = 0;
int32_t z = 0;

int main()
{
    printf("please enter the first operand:\n");
    scanf("%dx%d", &a, &b);
    if( a<0 || a>9 || c<0 || c>9 )
    {
        printf("wrong format!");
        return 0;
    }
    else
    {
        printf("please enter the second operand:\n");
        scanf("\ny%dz", &c);
        if( c<0 || c>9 )
        {
            printf("wrong format!");
            return 0;
        }
        else
        {
            printf("please enter the sum:\n");
            scanf("\n%d", &sum);

            if( sum < 0 || sum > 1152)
            {
                printf("no answer");
                return 0;
            }
            else
            {
                num = 100*a + 10*c + b;
                ans = sum - num;
                y = ans / 100;
                x = (ans / 10) % 10;
                z = ans % 10;
                //printf("%d - %d = %d\n", sum, num, ans);
                if(ans < 0)
                {
                    printf("wrong sum (too small)");
                }
                else
                {
                    printf("Ans: x = %d, y = %d, z = %d\n", x, y, z);
                }
                return 0;
            }
        }
    }
    
    
}