#include<stdio.h>
#include<stdint.h>

uint16_t num = 0;
uint16_t mode = 0;

uint16_t n = 0;//same as num, use n to count
uint16_t binary1 = 0;
uint16_t binary2 = 0;
uint16_t binary3 = 0;
uint16_t binary4 = 0;
uint16_t binary5 = 0;
uint16_t binary6 = 0;
uint16_t binary7 = 0;
uint16_t binary8 = 0;
uint16_t binary9 = 0;
uint16_t binary10 = 0;
uint16_t binary11 = 0;
uint16_t binary12 = 0;
uint16_t binary13 = 0;
uint16_t binary14 = 0;
uint16_t binary15 = 0;
uint16_t binary16 = 0;

uint16_t F = 0;
uint16_t EXP = 0;
uint16_t S = 0;
float numF = 0;
int16_t power = 0;

int main()
{
    printf("Please input a hex:\n");
    scanf("%hx", &num);

    printf("Please choose the output type (1:integer, 2:unsigned integer, 3:float):\n");
    scanf("\n%hd", &mode);
    //printf("%x, %d, %d", num, num, mode);

    //display binaries
    n = num;

    binary16 += n%2;
    n=n/2;
    binary15 += n%2;
    n=n/2;
    binary14 += n%2;
    n=n/2;
    binary13 += n%2;
    n=n/2;

    binary12 += n%2;
    n=n/2;
    binary11 += n%2;
    n=n/2;
    binary10 += n%2;
    n=n/2;
    binary9 += n%2;
    n=n/2;

    binary8 += n%2;
    n=n/2;
    binary7 += n%2;
    n=n/2;
    binary6 += n%2;
    n=n/2;
    binary5 += n%2;
    n=n/2;

    binary4 += n%2;
    n=n/2;
    binary3 += n%2;
    n=n/2;
    binary2 += n%2;
    n=n/2;
    binary1 += n%2;
    n=n/2;

    if(mode == 1)
    {
        printf("Binary of %hx is : %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu\n", num , binary1, binary2, binary3, binary4, binary5, binary6, binary7, binary8, binary9, binary10, binary11, binary12, binary13, binary14, binary15, binary16);
        printf("Converted integer is: %hd\n", num);
    }

    if(mode == 2)
    {
        printf("Binary of %hx is : %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu\n", num , binary1, binary2, binary3, binary4, binary5, binary6, binary7, binary8, binary9, binary10, binary11, binary12, binary13, binary14, binary15, binary16);
        printf("Converted integer is: %hu\n", num);
    }

    if(mode == 3)
    {
        //1 00000 0000000000
        //1 2~6 7~16
        F = num % (2*2*2*2*2*2*2*2*2*2);//7~16
        EXP = (num/(2*2*2*2*2*2*2*2*2*2)) % (2*2*2*2*2);//2~6
        S = num/(2*2*2*2*2*2*2*2*2*2*2*2*2*2*2);//1

        if(EXP == 0 && F == 0)
        {
            printf("Binary of %hx is : %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu\n", num , binary1, binary2, binary3, binary4, binary5, binary6, binary7, binary8, binary9, binary10, binary11, binary12, binary13, binary14, binary15, binary16);
            if(S == 0)printf("Converted float is: 0\n");
            if(S == 1)printf("Converted float is: -0\n");
        }
        else if(EXP == ((2*2*2*2*2) - 1) && F == 0)
        {
            printf("Binary of %hx is : %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu\n", num , binary1, binary2, binary3, binary4, binary5, binary6, binary7, binary8, binary9, binary10, binary11, binary12, binary13, binary14, binary15, binary16);
            if(S == 0)printf("Converted float is: ∞\n");
            if(S == 1)printf("Converted float is: -∞\n");
        }
        else if(EXP == ((2*2*2*2*2) - 1) && F != 0)
        {
            printf("Binary of %hx is : %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu\n", num , binary1, binary2, binary3, binary4, binary5, binary6, binary7, binary8, binary9, binary10, binary11, binary12, binary13, binary14, binary15, binary16);
            printf("Converted float is: NAN\n");
        }
        else
        {
            numF += (F%2) * 1.0/(2*2*2*2*2*2*2*2*2*2);
            F = F/2;
            numF += (F%2) * 1.0/(2*2*2*2*2*2*2*2*2);
            F = F/2;
            numF += (F%2) * 1.0/(2*2*2*2*2*2*2*2);
            F = F/2;
            numF += (F%2) * 1.0/(2*2*2*2*2*2*2);
            F = F/2;
            numF += (F%2) * 1.0/(2*2*2*2*2*2);
            F = F/2;
            numF += (F%2) * 1.0/(2*2*2*2*2);
            F = F/2;
            numF += (F%2) * 1.0/(2*2*2*2);
            F = F/2;
            numF += (F%2) * 1.0/(2*2*2);
            F = F/2;
            numF += (F%2) * 1.0/(2*2);
            F = F/2;
            numF += (F%2) * 1.0/(2);

            numF += 1;
            if(S == 0)numF *= 1;
            if(S == 1)numF *= -1;
            
            power = EXP - 15;
            
            printf("Binary of %hx is : %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu\n", num , binary1, binary2, binary3, binary4, binary5, binary6, binary7, binary8, binary9, binary10, binary11, binary12, binary13, binary14, binary15, binary16);
            printf("Converted float is: %f*2^%hd\n", numF, power);
        }


        //test
        //numF = num - EXP * (2*2*2*2*2*2*2*2*2*2) + (2*2*2*2-1) * (2*2*2*2*2*2*2*2*2*2);
        /*
        for (int i = 15; i >= 0; i--) {
        // 使用位元運算來取得每個位的值
        unsigned int bit = (numF >> i) & 1;
        printf("%u", bit);
        }
        printf("\n"); // 換行
        */
    }
}