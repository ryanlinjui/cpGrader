#include<stdio.h>
#include<stdint.h>
#include<stdbool.h>

int8_t a = 0;
int8_t b = 0;
int8_t c = 0;
int8_t d = 0;
int8_t e = 0;
bool legal = 1;
//大小檢測
int8_t ai = 1;
int8_t bi = 1;
int8_t ci = 1;
int8_t di = 1;
int8_t ei = 1;
//各張牌的數字項(1~13)
int8_t na = 0;
int8_t nb = 0;
int8_t nc = 0;
int8_t nd = 0;
int8_t ne = 0;
//各張牌的數字項(1~13)的排序
int8_t la = 0;
int8_t lb = 0;
int8_t lc = 0;
int8_t ld = 0;
int8_t le = 0;
//花色
int8_t fa = 0;
int8_t fb = 0;
int8_t fc = 0;
int8_t fd = 0;
int8_t fe = 0;
//對數
int8_t fourPair = 0;
int8_t threePair = 0;
int8_t twoPair = 0;
int8_t _1 = 0;//1的張數
int8_t _2 = 0;
int8_t _3 = 0;
int8_t _4 = 0;
int8_t _5 = 0;
int8_t _6 = 0;
int8_t _7 = 0;
int8_t _8 = 0;
int8_t _9 = 0;
int8_t _10 = 0;
int8_t _11 = 0;
int8_t _12 = 0;
int8_t _13 = 0;
//最終分類
int8_t cat = 0;
//實際分類會用到的：
//花色(fa~fe), 對數(fourPair, threePair, twoPair), 排序後數字(la~le)

int main()
{
    printf("Please enter 5 cards:\n");
    scanf("%hhd %hhd %hhd %hhd %hhd", &a, &b, &c, &d, &e);

    if(a==0||b==0||c==0||d==0||e==0)legal = 0;
    if(a<0||a>52||b<0||b>52||c<0||c>52||d<0||d>52||e<0||e>52)legal = 0;
    if(a==b||a==c||a==d||a==e||b==c||b==d||b==e||c==d||c==e||d==e)legal = 0;

    if(!legal)
    {
        printf("illegal cards\n");
    }
    else
    {
        //花色
        if(a>=1 && a<=13)fa = 1;
        if(a>=14 && a<=26)fa = 2;
        if(a>=27 && a<=39)fa = 3;
        if(a>=40 && a<=52)fa = 4;

        if(b>=1 && b<=13)fb = 1;
        if(b>=14 && b<=26)fb = 2;
        if(b>=27 && b<=39)fb = 3;
        if(b>=40 && b<=52)fb = 4;

        if(c>=1 && c<=13)fc = 1;
        if(c>=14 && c<=26)fc = 2;
        if(c>=27 && c<=39)fc = 3;
        if(c>=40 && c<=52)fc = 4;

        if(d>=1 && d<=13)fd = 1;
        if(d>=14 && d<=26)fd = 2;
        if(d>=27 && d<=39)fd = 3;
        if(d>=40 && d<=52)fd = 4;

        if(e>=1 && e<=13)fe = 1;
        if(e>=14 && e<=26)fe = 2;
        if(e>=27 && e<=39)fe = 3;
        if(e>=40 && e<=52)fe = 4;

        //找pair
        if(a%13 == 0)na = 13;
        else na = a%13;
        if(b%13 == 0)nb = 13;
        else nb = b%13;
        if(c%13 == 0)nc = 13;
        else nc = c%13;
        if(d%13 == 0)nd = 13;
        else nd = d%13;
        if(e%13 == 0)ne = 13;
        else ne = e%13;

        if(na == 1)_1 += 1;
        if(na == 2)_2 += 1;
        if(na == 3)_3 += 1;
        if(na == 4)_4 += 1;
        if(na == 5)_5 += 1;
        if(na == 6)_6 += 1;
        if(na == 7)_7 += 1;
        if(na == 8)_8 += 1;
        if(na == 9)_9 += 1;
        if(na == 10)_10 += 1;
        if(na == 11)_11 += 1;
        if(na == 12)_12 += 1;
        if(na == 13)_13 += 1;

        if(nb == 1)_1 += 1;
        if(nb == 2)_2 += 1;
        if(nb == 3)_3 += 1;
        if(nb == 4)_4 += 1;
        if(nb == 5)_5 += 1;
        if(nb == 6)_6 += 1;
        if(nb == 7)_7 += 1;
        if(nb == 8)_8 += 1;
        if(nb == 9)_9 += 1;
        if(nb == 10)_10 += 1;
        if(nb == 11)_11 += 1;
        if(nb == 12)_12 += 1;
        if(nb == 13)_13 += 1;

        if(nc == 1)_1 += 1;
        if(nc == 2)_2 += 1;
        if(nc == 3)_3 += 1;
        if(nc == 4)_4 += 1;
        if(nc == 5)_5 += 1;
        if(nc == 6)_6 += 1;
        if(nc == 7)_7 += 1;
        if(nc == 8)_8 += 1;
        if(nc == 9)_9 += 1;
        if(nc == 10)_10 += 1;
        if(nc == 11)_11 += 1;
        if(nc == 12)_12 += 1;
        if(nc == 13)_13 += 1;

        if(nd == 1)_1 += 1;
        if(nd == 2)_2 += 1;
        if(nd == 3)_3 += 1;
        if(nd == 4)_4 += 1;
        if(nd == 5)_5 += 1;
        if(nd == 6)_6 += 1;
        if(nd == 7)_7 += 1;
        if(nd == 8)_8 += 1;
        if(nd == 9)_9 += 1;
        if(nd == 10)_10 += 1;
        if(nd == 11)_11 += 1;
        if(nd == 12)_12 += 1;
        if(nd == 13)_13 += 1;

        if(ne == 1)_1 += 1;
        if(ne == 2)_2 += 1;
        if(ne == 3)_3 += 1;
        if(ne == 4)_4 += 1;
        if(ne == 5)_5 += 1;
        if(ne == 6)_6 += 1;
        if(ne == 7)_7 += 1;
        if(ne == 8)_8 += 1;
        if(ne == 9)_9 += 1;
        if(ne == 10)_10 += 1;
        if(ne == 11)_11 += 1;
        if(ne == 12)_12 += 1;
        if(ne == 13)_13 += 1;
        
        if(_1==4||_2==4||_3==4||_4==4||_5==4||_6==4||_7==4||_8==4||_9==4||_10==4||_11==4||_12==4||_13==4)
        {
            fourPair = 1;
        }
        if(_1==3||_2==3||_3==3||_4==3||_5==3||_6==3||_7==3||_8==3||_9==3||_10==3||_11==3||_12==3||_13==3)
        {
            threePair = 1;
        }
        if(_1==2)twoPair += 1;
        if(_2==2)twoPair += 1;
        if(_3==2)twoPair += 1;
        if(_4==2)twoPair += 1;
        if(_5==2)twoPair += 1;
        if(_6==2)twoPair += 1;
        if(_7==2)twoPair += 1;
        if(_8==2)twoPair += 1;
        if(_9==2)twoPair += 1;
        if(_10==2)twoPair += 1;
        if(_11==2)twoPair += 1;
        if(_12==2)twoPair += 1;
        if(_13==2)twoPair += 1;

        //printf("fourPair:%d , threePair:%d , twoPair:%d", fourPair, threePair, twoPair);

        //排序（大小）
        if(fourPair ==0 && threePair == 0 && twoPair == 0)
        {
            if((na-nb)>0)ai+=1;
            if((na-nc)>0)ai+=1;
            if((na-nd)>0)ai+=1;
            if((na-ne)>0)ai+=1;

            if((nb-na)>0)bi+=1;
            if((nb-nc)>0)bi+=1;
            if((nb-nd)>0)bi+=1;
            if((nb-ne)>0)bi+=1;

            if((nc-nb)>0)ci+=1;
            if((nc-na)>0)ci+=1;
            if((nc-nd)>0)ci+=1;
            if((nc-ne)>0)ci+=1;

            if((nd-nb)>0)di+=1;
            if((nd-nc)>0)di+=1;
            if((nd-na)>0)di+=1;
            if((nd-ne)>0)di+=1;

            if((ne-nb)>0)ei+=1;
            if((ne-nc)>0)ei+=1;
            if((ne-nd)>0)ei+=1;
            if((ne-na)>0)ei+=1;

            //printf("%d %d %d %d %d\n", ai ,bi, ci, di, ei);
            //將na~ne從小到大排a~e
            switch(ai)
            {
                case 1:
                la = na;
                break;
                case 2:
                lb = na;
                break;
                case 3:
                lc = na;
                break;
                case 4:
                ld = na;
                break;
                case 5:
                le = na;
                break;
            }
            switch(bi)
            {
                case 1:
                la = nb;
                break;
                case 2:
                lb = nb;
                break;
                case 3:
                lc = nb;
                break;
                case 4:
                ld = nb;
                break;
                case 5:
                le = nb;
                break;
            }
            switch(ci)
            {
                case 1:
                la = nc;
                break;
                case 2:
                lb = nc;
                break;
                case 3:
                lc = nc;
                break;
                case 4:
                ld = nc;
                break;
                case 5:
                le = nc;
                break;
            }
            switch(di)
            {
                case 1:
                la = nd;
                break;
                case 2:
                lb = nd;
                break;
                case 3:
                lc = nd;
                break;
                case 4:
                ld = nd;
                break;
                case 5:
                le = nd;
                break;
            }
            switch(ei)
            {
                case 1:
                la = ne;
                break;
                case 2:
                lb = ne;
                break;
                case 3:
                lc = ne;
                break;
                case 4:
                ld = ne;
                break;
                case 5:
                le = ne;
                break;
            }
            //printf("%hhd %hhd %hhd %hhd %hhd\n", la, lb, lc, ld, le);
        }
        
        //開始分類
        //1, 4
        if(fa == fb && fb == fc && fc == fd && fd == fe)
        {
            if(la+1 == lb && lb+1 == lc && lc+1 == ld && ld+1 == le)
            {
                cat = 1;
            }
            else if(la+9 == lb && lb+1 == lc && lc+1 == ld && ld+1 == le)
            {
                cat = 1;
            }
            else
            {
                cat = 4;
            }
        }
        //2
        else if(fourPair == 1)
        {
            cat = 2;
        }
        //3
        else if(threePair == 1 && twoPair ==1)
        {
            cat = 3;
        }
        //5
        else if(la+1==lb && lb+1==lc && lc+1==ld && ld+1==le)
        {
            cat = 5;
        }
        else if(la+9==lb && lb+1==lc && lc+1==ld && ld+1==le)
        {
            cat = 5;
        }
        //6
        else if(threePair == 1)
        {
            cat = 6;
        }
        //7
        else if(twoPair == 2)
        {
            cat = 7;
        }
        //8
        else if(twoPair == 1)
        {
            cat = 8;
        }
        //9
        else
        {
            cat = 9;
        }
        //printf("%d %d %d %d %d", na, nb, nc, nd, ne);
        //輸出
        switch(cat)
        {
            case 1:
            printf("Straight flash\n");
            break;

            case 2:
            printf("Four of a kind\n");
            break;

            case 3:
            printf("Full house\n");
            break;

            case 4:
            printf("Flush\n");
            break;

            case 5:
            printf("Straight\n");
            break;

            case 6:
            printf("Three of a kind\n");
            break;

            case 7:
            printf("Two pair\n");
            break;

            case 8:
            printf("One pair\n");
            break;

            case 9:
            printf("High card\n");
            break;
        }

        return 0;
    }
}