#include<stdio.h>
#include<stdint.h>
int main(){

    uint32_t input=0,flip=0,input_8=0,input1=0,input2=0,input3=0,input4=0,input5=0,input_8_1=0,input_8_2=0,input_8_3=0,input_8_4=0,input_8_5=0,input_8_6=0,ans_10=0/*input6=0,input7=0,input8=0,input9=0,input10=0,input11=0,input12=0,input13=0,input14=0,input15=0,input16=0*/;
    printf("Please enter an unsigned 16-bits number: ");
    scanf("%d",&input);

    printf("Before Flip:\n");
    printf("%d_10 = %o_8\n",input,input);
    printf("After Flip:\n");

    input_8_6=input/32768;
    input_8_5=input%32768/4096;
    input_8_4=input%4096/512;
    input_8_3=input%512/64;
    input_8_2=input%64/8;
    input_8_1=input%8;    

    if(input_8_6!=0){
        flip=input_8_1*100000+input_8_2*10000+input_8_3*1000+input_8_4*100+input_8_5*10+input_8_6;
    }else if(input_8_5!=0){
        flip=input_8_1*10000+input_8_2*1000+input_8_3*100+input_8_4*10+input_8_5;
    }else if(input_8_4!=0){
        flip=input_8_1*1000+input_8_2*100+input_8_3*10+input_8_4;
    }else if(input_8_3!=0){
        flip=input_8_1*100+input_8_2*10+input_8_3;
    }else if(input_8_2!=0){
        flip=input_8_1*10+input_8_2;
    }else if(input_8_1!=0){
        flip=input_8_1;
    }else{}

    if(input_8_6!=0){
        ans_10=input_8_6+input_8_5*8+input_8_4*64+input_8_3*512+input_8_2*4096+input_8_1*32796;
    }else if(input_8_5!=0){
        ans_10=input_8_5+input_8_4*8+input_8_3*64+input_8_2*512+input_8_1*4096;
    }else if(input_8_4!=0){
        ans_10=input_8_4+input_8_3*8+input_8_2*64+input_8_1*512;
    }else if(input_8_3!=0){
        ans_10=input_8_3+input_8_2*8+input_8_1*64;
    }else if(input_8_2!=0){
        ans_10=input_8_2+input_8_1*8;
    }else if(input_8_1!=0){
        ans_10=input_8_1;
    }
    
        printf("%d_8 = %d_10\n",flip,ans_10);
    
    
    return 0;
    
}