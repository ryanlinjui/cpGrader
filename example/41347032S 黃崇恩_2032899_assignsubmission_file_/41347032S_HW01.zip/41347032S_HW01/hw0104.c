#include<stdio.h>
#include<stdint.h>
int main(){

    int32_t card1=-1,card2=-1,card3=-1,card4=-1,card5=-1,cardch=0,S=0,H=0,D=0,C=0,a=0,b=0,c=0,d=0,e=0  ,f=0,g=0,h=0,i=0,j=0  ,k=0,l=0,m=0 ,pair=0;

    printf("Please enter 5 cards: ");
    scanf("%d %d %d %d %d",&card1,&card2,&card3,&card4,&card5);

    if(card1>card2){
        cardch=card1,card1=card2,card2=cardch;
    }if(card1>card3){
        cardch=card1,card1=card3,card3=cardch;
    }if(card1>card4){
        cardch=card1,card1=card4,card4=cardch;
    }if(card1>card5){
        cardch=card1,card1=card5,card5=cardch;
    }if(card2>card3){
        cardch=card2,card2=card3,card3=cardch;
    }if(card2>card4){
        cardch=card2,card2=card4,card4=cardch;
    }if(card2>card5){
        cardch=card2,card2=card5,card5=cardch;
    }if(card3>card4){
        cardch=card3,card3=card4,card4=cardch;
    }if(card3>card5){
        cardch=card3,card3=card5,card5=cardch;
    }if(card4>card5){
        cardch=card4,card4=card5,card5=cardch;
    }

    if (card1%13==1){
        a=a+1;
    }if (card2%13==1){
        a=a+1;
    }if (card3%13==1){
        a=a+1;
    }if (card4%13==1){
        a=a+1;
    }if (card5%13==1){
        a=a+1;
    } if (card1%13==2){
        b=b+1;
    }if (card2%13==2){
        b=b+1;
    }if (card3%13==2){
        b=b+1;
    }if (card4%13==2){
        b=b+1;
    }if (card5%13==2){
        b=b+1;
    } if (card1%13==3){
        c=c+1;
    }if (card2%13==3){
        c=c+1;
    }if (card3%13==3){
        c=c+1;
    }if (card4%13==3){
        c=c+1;
    }if (card5%13==3){
        c=c+1;
    } if (card1%13==4){
        d=d+1;
    }if (card2%13==4){
        d=d+1;
    }if (card3%13==4){
        d=d+1;
    }if (card4%13==4){
        d=d+1;
    }if (card5%13==4){
        d=d+1;
    } if (card1%13==5){
        e=e+1;
    }if (card2%13==5){
        e=e+1;
    }if (card3%13==5){
        e=e+1;
    }if (card4%13==5){
        e=e+1;
    }if (card5%13==5){
        e=e+1;
    } if (card1%13==6){
        f=f+1;
    }if (card2%13==6){
        f=f+1;
    }if (card3%13==6){
        f=f+1;
    }if (card4%13==6){
        f=f+1;
    }if (card5%13==6){
        f=f+1;
    } if (card1%13==7){
        g=g+1;
    }if (card2%13==7){
        g=g+1;
    }if (card3%13==7){
        g=g+1;
    }if (card4%13==7){
        g=g+1;
    }if (card5%13==7){
        g=g+1;
    } if (card1%13==8){
        h=h+1;
    }if (card2%13==8){
        h=h+1;
    }if (card3%13==8){
        h=h+1;
    }if (card4%13==8){
        h=h+1;
    }if (card5%13==8){
        h=h+1;
    } if (card1%13==9){
        i=i+1;
    }if (card2%13==9){
        i=i+1;
    }if (card3%13==9){
        i=i+1;
    }if (card4%13==9){
        i=i+1;
    }if (card5%13==9){
        i=i+1;
    } if (card1%13==10){
        j=j+1;
    }if (card2%13==10){
        j=j+1;
    }if (card3%13==10){
        j=j+1;
    }if (card4%13==10){
        j=j+1;
    }if (card5%13==10){
        j=j+1;
    } if (card1%13==11){
        k=k+1;
    }if (card2%13==11){
        k=k+1;
    }if (card3%13==11){
        k=k+1;
    }if (card4%13==11){
        k=k+1;
    }if (card5%13==11){
        k=k+1;
    } if (card1%13==12){
        l=l+1;
    }if (card2%13==12){
        l=l+1;
    }if (card3%13==12){
        l=l+1;
    }if (card4%13==12){
        l=l+1;
    }if (card5%13==12){
        l=l+1;
    } if (card1%13==0){
        m=m+1;
    }if (card2%13==0){
        m=m+1;
    }if (card3%13==0){
        m=m+1;
    }if (card4%13==0){
        m=m+1;
    }if (card5%13==0){
        m=m+1;
    }
    if(a==2){
        pair=pair+1;
    }if(b==2){
        pair=pair+1;
    }if(c==2){
        pair=pair+1;
    }if(d==2){
        pair=pair+1;
    }if(e==2){
        pair=pair+1;
    }if(f==2){
        pair=pair+1;
    }if(g==2){
        pair=pair+1;
    }if(h==2){
        pair=pair+1;
    }if(i==2){
        pair=pair+1;
    }if(j==2){
        pair=pair+1;
    }if(k==2){
        pair=pair+1;
    }if(l==2){
        pair=pair+1;
    }if(m==2){
        pair=pair+1;
    }

    if(card5>52||card1<=0){
        printf("Error\n");
    }
    else{
    if(card1<=13&&card2<=13&&card3<=13&&card4<=13&&card5<=13){
        if(card1+1==card2&&card2+1==card3&&card3+1==card4&&card4+1==card5){
            printf("Straight Flush\n");
        }else if(card1+12==card5&&card2+1==card3&&card3+1==card4&&card4+1==card5){
            printf("Straight Flush\n");
        }else{
            printf("Flush\n");
        }
    }else if(card1>13&&card1<=26&&card2>13&&card2<=26&&card3>13&&card3<=26&&card4>13&&card4<=26&&card5>13&&card5<=26){
        if(card1+1==card2&&card2+1==card3&&card3+1==card4&&card4+1==card5){
            printf("Straight Flush\n");
        }else if(card1+12==card5&&card2+1==card3&&card3+1==card4&&card4+1==card5){
            printf("Straight Flush\n");
        }else{
            printf("Flush\n");
        }
    }else if(card1>26&&card1<=39&&card2>26&&card2<=39&&card3>26&&card3<=39&&card4>26&&card4<=39&&card5>26&&card5<=39){
        if(card1+1==card2&&card2+1==card3&&card3+1==card4&&card4+1==card5){
            printf("Straight Flush\n");
        }else if(card1+12==card5&&card2+1==card3&&card3+1==card4&&card4+1==card5){
            printf("Straight Flush\n");
        }else{
            printf("Flush\n");
        }
    }else if(card1>39&&card1<=52&&card2>39&&card2<=52&&card3>39&&card3<=52&&card4>39&&card4<=52&&card5>39&&card5<=52){
        if(card1+1==card2&&card2+1==card3&&card3+1==card4&&card4+1==card5){
            printf("Straight Flush\n");
        }else if(card1+12==card5&&card2+1==card3&&card3+1==card4&&card4+1==card5){
            printf("Straight Flush\n");
        }else{
            printf("Flush\n");
        }
    }else if(card1%13+1==card2%13&&card2%13+1==card3%13&&card3%13+1==card4%13&&card4%13+1==card5%13){
        printf("Straight\n");
    }else if(card1%13-1==card5%13&&card2%13+1==card3%13&&card3%13+1==card4%13&&card4%13+1==card5%13){
        printf("Straight\n");
    }else if(a==4||b==4||c==4||d==4||e==4||f==4||g==4||h==4||i==4||j==4||k==4||l==4||m==4){
        printf("Four of a kind\n");
    }else if(a==3||b==3||c==3||d==3||e==3||f==3||g==3||h==3||i==3||j==3||k==3||l==3||m==3){
        if(a==2||b==2||c==2||d==2||e==2||f==2||g==2||h==2||i==2||j==2||k==2||l==2||m==2){
            printf("Full House\n");
        }else{
            printf("Three of a kind\n");
        }
    }else if(a==2||b==2||c==2||d==2||e==2||f==2||g==2||h==2||i==2||j==2||k==2||l==2||m==2){
        if (pair==2){
            printf("Two pair\n");
        }else{
            printf("One pair\n");
        }
    }else{
        printf("High card\n");
    }
    }

    return 0;
}