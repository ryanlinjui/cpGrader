#include<stdio.h>
#include<stdint.h>
int main(){

    printf("\033[31m[KIM]\nYou are sunlight and I moon\nJoined by the gods of fortune\nMidnight and high noon sharing the sky\nWe have been blessed , you and I\n\n\033[m");
    printf("\033[34m[CHRIS]\nYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\n\n\033[m");
    printf("\033[31m[KIM]\nOutside day starts to dawn\n\n\033[m");
    printf("\033[34m[CHRIS]\nYour moon still floats on high\n\n\033[m");
    printf("\033[31m[KIM]\nThe birds awake\n\n\033[m");
    printf("\033[34m[CHRIS]\nThe stars shine too\n\n\033[m");
    printf("\033[31m[KIM]\nMy hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n\nYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho’ s Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n\n\033[m");
    printf("\033[34m[CHRIS]\nI reach for you\n\n\033[m");
    printf("\033[32m[KIM & CHRIS]\nAnd we meet in the sky\n\n\033[m");
    printf("\033[31m[KIM]\nYou are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n\n\033[m");
    printf("\033[32m[KIM & CHRIS]\nMade of\nSunlight\nMoonlight\n\n\033[m");
    return 0;
}