#include<stdio.h>
#include<stdint.h>
int main(){

    int32_t input=-1,a=0,b=0,c=0,d=0,choose=4,exp=0,aa=0,bb=0,exp_15=0,F=0;
    double ans=0,ff=0;
    //hex=abcd

    printf("Please input a hex:");
    scanf("%x",&input);
    scanf("%d",&choose);


    a=input%65536/4096;
    b=input%4096/256;
    c=input%256/16;
    d=input%16;    

    if(choose=4){
        printf("Error\n");
    }
    else{

    printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
    scanf("%d",&choose);

    if(choose>3||choose<1){
        printf("Error\n");
    }
    else{
    if(a==2){
        a=10;
    }else if(a==3){
        a=11;
    }else if(a==4){
        a=100;
    }else if(a==5){
        a=101;
    }else if(a==6){
        a=110;
    }else if(a==7){
        a=111;
    }else if(a==8){
        a=1000;
    }else if(a==9){
        a=1001;
    }else if(a==10){
        a=1010;
    }else if(a==11){
        a=1011;
    }else if(a==12){
        a=1100;
    }else if(a==13){
        a=1101;
    }else if(a==14){
        a=1110;
    }else if(a==15){
        a=1111;
    }   
    if(b==2){
        b=10;
    }else if(b==3){
        b=11;
    }else if(b==4){
        b=100;
    }else if(b==5){
        b=101;
    }else if(b==6){
        b=110;
    }else if(b==7){
        b=111;
    }else if(b==8){
        b=1000;
    }else if(b==9){
        b=1001;
    }else if(b==10){
        b=1010;
    }else if(b==11){
        b=1011;
    }else if(b==12){
        b=1100;
    }else if(b==13){
        b=1101;
    }else if(b==14){
        b=1110;
    }else if(b==15){
        b=1111;
    }
    if(c==2){
        c=10;
    }else if(c==3){
        c=11;
    }else if(c==4){
        c=100;
    }else if(c==5){
        c=101;
    }else if(c==6){
        c=110;
    }else if(c==7){
        c=111;
    }else if(c==8){
        c=1000;
    }else if(c==9){
        c=1001;
    }else if(c==10){
        c=1010;
    }else if(c==11){
        c=1011;
    }else if(c==12){
        c=1100;
    }else if(c==13){
        c=1101;
    }else if(c==14){
        c=1110;
    }else if(c==15){
        c=1111;
    }
    if(d==2){
        d=10;
    }else if(d==3){
        d=11;
    }else if(d==4){
        d=100;
    }else if(d==5){
        d=101;
    }else if(d==6){
        d=110;
    }else if(d==7){
        d=111;
    }else if(d==8){
        d=1000;
    }else if(d==9){
        d=1001;
    }else if(d==10){
        d=1010;
    }else if(d==11){
        d=1011;
    }else if(d==12){
        d=1100;
    }else if(d==13){
        d=1101;
    }else if(d==14){
        d=1110;
    }else if(d==15){
        d=1111;
    }
    printf("Binary of %X is: ",input);
    printf("%04d %04d %04d %04d\n",a,b,c,d);

    if(choose==1){
        if(input>32767){
            input=input-65536;
            printf("Converted integer is: %d\n",input);
        }else{
            printf("Converted unsigned integer is: %d\n",input);
        }
    }else if(choose==2){
        printf("Converted unsigned integer is: %d\n",input);
    }else if(choose==3){

        bb=b;
        aa=a;
        if(aa/1000==0){
            bb=bb/100;
        }else{
            aa=(aa-1000);
            bb=bb/100;
        }
        if(aa==0){
            exp=exp;
        }else if(aa==1){
            exp=exp+4;
        }else if(aa==10){
            exp=exp+8;
        }else if(aa==11){
            exp=exp+12;
        }else if(aa==100){
            exp=exp+16;
        }else if(aa==101){
            exp=exp+20;
        }else if(aa==110){
            exp=exp+24;
        }else if(aa==111){
            exp=exp+28;
        }
        if(bb==0){
            exp=exp;
        }else if(bb==1){
            exp=exp+1;
        }else if(bb==10){
            exp=exp+2;
        }else if(bb==11){
            exp=exp+3;
        }
        //printf("exp=%d\n",exp);
        F=(b%100)*100000000+c*10000+d;
        //printf("F=%010d\n",F);
        
        if(exp==0&&F==0&&a<1000){
            printf("Converted float is: +0.0\n");
        }else if(exp==0&&F==0){
            printf("Converted float is: -0.0\n");
        }else if(exp==31&&F==0&&a<1000){
            printf("Converted float is: +INF\n");
        }else if(exp==31&&F==0){
            printf("Converted float is: -INF\n");
        }else if(exp==31){
            printf("Converted float is: NAN\n");
        }else {
        ff=1+(F/1000000000)*0.5+(F%1000000000/100000000)*0.5*0.5+(F%100000000/10000000)*0.5*0.5*0.5+(F%10000000/1000000)*0.5*0.5*0.5*0.5+(F%1000000/100000)*0.5*0.5*0.5*0.5*0.5+(F%100000/10000)*0.5*0.5*0.5*0.5*0.5*0.5+(F%10000/1000)*0.5*0.5*0.5*0.5*0.5*0.5*0.5+(F%1000/100)*0.5*0.5*0.5*0.5*0.5*0.5*0.5*0.5+(F%100/10)*0.5*0.5*0.5*0.5*0.5*0.5*0.5*0.5*0.5+(F%10/1)*0.5*0.5*0.5*0.5*0.5*0.5*0.5*0.5*0.5*0.5;

        exp_15=exp-15;

        if(a>=8){
            printf("Converted float is: -%f*2^%d\n",ff,exp_15);
        }else{
            printf("Converted float is: %f*2^%d\n",ff,exp_15);
        }
        }
        }
        }
        return 0;
    }












    
}