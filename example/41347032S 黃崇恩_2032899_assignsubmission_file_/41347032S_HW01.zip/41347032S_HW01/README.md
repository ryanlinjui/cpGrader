My student id :
    41347032S

My name :
    黃崇恩

I have completed all of the problems.
Just make the makefile and the files would be complied successfully.








