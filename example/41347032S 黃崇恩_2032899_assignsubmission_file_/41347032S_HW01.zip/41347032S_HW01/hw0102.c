#include<stdio.h>
#include<stdint.h>
int main(){

    int32_t X=0,Y=0,Z=0,first=0,first2=0,second=0,sum=0,sum1=0,sum2=0,sum34=0,error1=0,error2=0;
    char x,y,z;

    printf("Please enter the first  operand: ");
    scanf(" %d %c %d",&first,&x,&first2);
    printf("Please enter the second operand: ");
    scanf(" %c %d %c",&y,&second,&z);
    printf("Please enter the sum           : ");
    scanf(" %d",&sum);

    sum1=sum%10;
    sum2=(sum/10)%10;
    sum34=(sum/100);
    
    error1=sum-first*100+second*10+first2;
    error2=first*100+second*10+first2;

    if(sum1<first2){
        Z=sum1+10-first2;
        sum2=sum2-1;
    }else{
        Z=sum1-first2;
    }
    if (sum2>=second){
        X=sum2-second;
        Y=sum34-first;
    }else{
        X=sum2+10-second;
        Y=sum34-1-first;
    }
    if(first>=10||first2>=10||second>=10||error1>=999||sum<error2){
        printf("Error\n");
    }else{
        printf("Ans: x=%d, y=%d, z=%d\n",X,Y,Z);
    }
    return 0;
}
