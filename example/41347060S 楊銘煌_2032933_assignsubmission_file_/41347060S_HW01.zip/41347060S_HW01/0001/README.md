# 41347060S' Homework 1 for Computer Programming (I)
This folder includes:
- `assets/` for lyrics file
- Code `hw0101.c` to `hw0105.c`
- Markdown `hw0106.md` to answer the bonus question 1.6
