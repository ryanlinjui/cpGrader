#include <stdio.h>

int main() {
  unsigned int number;
  int factor = 32768;
  printf("Please input a hex: ");
  scanf("%x", &number);
  unsigned int swap = number;

  printf("Please choose the output type(1:integer,2:unsigned integer,3:float): ");
  int choice;
  scanf("%d", &choice);
  if (choice != 1 && choice != 2 && choice != 3) {
    printf("Illegal choice! program terminating.\n");
    return 1;
  }

  printf("Binary of %X is: ", number);
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf(" ");
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf(" ");
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf(" ");
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf("%d", (number - number % factor) / factor); number = number % factor; factor = factor / 2;
  printf("\n");

  int bit;
  number = swap;
  factor = 32768;
  if (choice == 1) {
    int converted = 0;
    int is_negative = 0;
    if (number - number % factor) {
      is_negative = 1;
      number = number - 1;
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
      if (!(number - number % factor)) converted = converted + factor; number = number % factor; factor = factor / 2;
    }
    else converted = number;
      
    printf("Converted Integer: ");
    if (is_negative) printf("-");
    printf("%d\n", converted);
  }
  if (choice == 2) {
    printf("Converted Unsigned Integer: %d\n", number);
  }
  if (choice == 3) {
    float converted = 0;
    float fraction = 1;
    float ffactor = 0.5;
    int exponent = 0;
    int efactor = 16;
    int is_negative = 0;
    if (number - number % factor) is_negative = 1; number = number % factor; factor = factor / 2;
    
    if (number - number % factor) exponent = exponent + efactor; efactor = efactor / 2; number = number % factor; factor = factor / 2;
    if (number - number % factor) exponent = exponent + efactor; efactor = efactor / 2; number = number % factor; factor = factor / 2;
    if (number - number % factor) exponent = exponent + efactor; efactor = efactor / 2; number = number % factor; factor = factor / 2;
    if (number - number % factor) exponent = exponent + efactor; efactor = efactor / 2; number = number % factor; factor = factor / 2;
    if (number - number % factor) exponent = exponent + efactor; efactor = efactor / 2; number = number % factor; factor = factor / 2;

    if (number - number % factor) fraction = fraction + ffactor; ffactor = ffactor / 2; number = number % factor; factor = factor / 2;
    if (number - number % factor) fraction = fraction + ffactor; ffactor = ffactor / 2; number = number % factor; factor = factor / 2;
    if (number - number % factor) fraction = fraction + ffactor; ffactor = ffactor / 2; number = number % factor; factor = factor / 2;
    if (number - number % factor) fraction = fraction + ffactor; ffactor = ffactor / 2; number = number % factor; factor = factor / 2;
    if (number - number % factor) fraction = fraction + ffactor; ffactor = ffactor / 2; number = number % factor; factor = factor / 2;
    if (number - number % factor) fraction = fraction + ffactor; ffactor = ffactor / 2; number = number % factor; factor = factor / 2;
    if (number - number % factor) fraction = fraction + ffactor; ffactor = ffactor / 2; number = number % factor; factor = factor / 2;
    if (number - number % factor) fraction = fraction + ffactor; ffactor = ffactor / 2; number = number % factor; factor = factor / 2;
    if (number - number % factor) fraction = fraction + ffactor; ffactor = ffactor / 2; number = number % factor; factor = factor / 2;
    if (number - number % factor) fraction = fraction + ffactor; ffactor = ffactor / 2; number = number % factor; factor = factor / 2;
    
    printf("Converted Float: ");
    if (is_negative) printf("-");
    printf("%f", fraction);
    printf("*2^%d\n", exponent - 15);
  }
  return 0;
}
