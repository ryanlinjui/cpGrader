#include<stdio.h>
#include<stdint.h>

int main(){
    //讀取的變數
    int32_t first1,first2,second1,sum1=0;
    //總和的變數：1千位,2百位,3十位,4一位
    int32_t sum1_1,sum1_2,sum1_3,sum1_4=0;
    //所求x,y,z
    int32_t x,y,z=0;
    printf("$ ./hw0102\n");
    //讀取第一排
    printf("Please enter the first operand:");
    scanf("%dx%d",&first1,&first2);
    if(first1<0||first1>9||first2<0||first2>9){
        printf("you enter the wrong number\n");
        return 0;
    }else{
        //讀取第二排
        printf("Please enter the second operand:");
        scanf("%*[^0-9]%d",&second1);
    }
    if(second1<0||second1>9){
        printf("you enter the wrong number\n");
        return 0;
    }else{
        //讀取總和
        printf("Please enter the sum :");
        scanf("%*[^0-9]%d",&sum1);
    }
    if(sum1<100||sum1>1998){
        printf("you enter the wrong number\n");
        return 0;
    }
    //拆解總和
    sum1_1=sum1/1000;
    sum1_2=(sum1/100)%10;
    sum1_3=(sum1/10)%10;
    sum1_4=sum1%10;
    //進位判斷 if有進位，else沒進位
    if(first2>sum1_4){
        z=10+sum1_4-first2;
        //十位數，有進位
        if(second1>sum1_3){
            x=10+sum1_3-second1-1;
        }else{
            x=sum1_3-second1-1;
        }
    }else{
        z=sum1_4-first2;
        //十位數，沒進位
        if(second1>sum1_3){
            x=10+sum1_3-second1;
        }else{
            x=sum1_3-second1;
        }
    }
    if(second1>sum1_3){
        //百位計算，有進位
        if(sum1_1==1){
            y=10+sum1_2-first1-1;
        }else{
            y=10+sum1_2-first1;
        }
    }else{
        //百位計算，沒進位
        if(sum1_1==1){
            y=sum1_2-first1-1;
        }else{
            y=sum1_2-first1;
        }
    }
    printf("ANS: x=%d,y=%d,z=%d\n",x,y,z);
    return 0;
}