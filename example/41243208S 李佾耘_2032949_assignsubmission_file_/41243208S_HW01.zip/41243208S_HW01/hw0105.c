#include<stdio.h>
#include<stdint.h>

int main(){
    //carry為輸入值，四個數分別為carry161 162 163 164，carry2為2進位，ans三個代表輸出的答案，tem為暫存值
    uint32_t carry16,carry161,carry162,carry163,carry164,ans2,tem,choose=0;
    //存四個16進位數翻轉後的數
    int32_t flip1,flip2,flip3,flip4=0;
    float ans3;
    int32_t ans1;
    printf("$ ./hw0105\n");
    printf("Please input a hex:");
    scanf("%X",&carry16);
    printf("Please choose the output type(1:integer, 2:unsigned integer, 3:float):");
    scanf("%d",&choose);
    if(choose<1||choose>3){
        printf("You enter wrong number.");
        return 0;
    }
    carry161=carry16/4096;
    tem=carry16-carry161*4096;
    carry162=tem/256;
    tem=tem-carry162*256;
    carry163=tem/16;
    tem=tem-carry163/16;
    carry164=tem%16;
    //第一個數
    printf("Binary of %X is: ",carry16);
    printf("%d",carry161/8);
    tem=carry161-(carry161/8)*8;
    printf("%d",tem/4);
    tem=tem-(tem/4)*4;
    printf("%d",tem/2);
    tem=tem-(tem/2)*2;
    printf("%d ",tem);
    //第二個數
    printf("%d",carry162/8);
    tem=carry162-(carry162/8)*8;
    printf("%d",tem/4);
    tem=tem-(tem/4)*4;
    printf("%d",tem/2);
    tem=tem-(tem/2)*2;
    printf("%d ",tem);
    //第三個數
    printf("%d",carry163/8);
    tem=carry163-(carry163/8)*8;
    printf("%d",tem/4);
    tem=tem-(tem/4)*4;
    printf("%d",tem/2);
    tem=tem-(tem/2)*2;
    printf("%d ",tem);
    //第四個數
    printf("%d",carry164/8);
    tem=carry164-(carry164/8)*8;
    printf("%d",tem/4);
    tem=tem-(tem/4)*4;
    printf("%d",tem/2);
    tem=tem-(tem/2)*2;
    printf("%d \n",tem);
    //printf("%d %d %d %d %d",carry16,carry161,carry162,carry163,carry164);
    //判斷尾數是否為0，方便之後處理負數
    if(carry164>0){
        tem=4;
    }else if(carry163>0){
        tem=3;
    }else if(carry162>0){
        tem=2;
    }else{
        tem=1;
    }
    //列印使用者想要的結果
    if(choose==1){
        if(carry161/8==1){
            if(tem==4){
                carry164=carry164-1;
            }else if(tem==3){
                carry163=carry163-1;
                carry164=15;
            }else if(tem==2){
                carry162=carry162-1;
                carry164=15;
                carry163=15;
            }else{
                carry161=carry161-1;
                carry164=15;
                carry163=15;
                carry162=15;
            }
            carry161=15-carry161;
            carry162=15-carry162;
            carry163=15-carry163;
            carry164=15-carry164;
            ans1=(carry161*4096+carry162*256+carry163*16+carry164)*-1;
            printf("Converted integer is:%d",ans1);
        }else{
            printf("%d",carry16);
        }
    }else if(choose==2){
        ans2=carry161*4096+carry162*256+carry163*16+carry164;
        printf("Converted unsigned integer is:%d\n",ans2);
    }
    return 0;
}