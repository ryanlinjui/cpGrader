#include<stdio.h>
#include<stdint.h>

int main(){
    //設定五數字狀態
    int32_t sta1,sta2,sta3,sta4,sta5=0;
    //設定五輸入值，和一暫存值
    int32_t num1,num2,num3,num4,num5,tem=0;
    //設定五轉化後(無花色)的數字
    int32_t non1,non2,non3,non4,non5=0;
    printf("$ ./hw0104\n");
    printf("Please enter 5 cards:");
    //讀取數字
    scanf("%d %d %d %d %d",&num1,&num2,&num3,&num4,&num5);
    //記錄無花色數字
    non1=(num1-1)%13+1;
    non2=(num2-1)%13+1;
    non3=(num3-1)%13+1;
    non4=(num4-1)%13+1;
    non5=(num5-1)%13+1;
    //數字1判斷花色，1為黑桃，2為愛心，3為方塊，4為梅花
    if(num1<1){
        printf("You enter wrong number\n");
        return 0;
    }else if( (num1-1)/13<1 ){
        sta1=1;
    }else if( (num1-1)/13<2 ){
        sta1=2;
    }else if( (num1-1)/13<3 ){
        sta1=3;
    }else if( (num1-1)/13<4 ){
        sta1=4;
    }else{
        printf("You enter wrong number\n");
        return 0;
    }
    //數字2判斷
    if(num2<1){
        printf("You enter wrong number\n");
        return 0;
    }else if( (num2-1)/13<1 ){
        sta2=1;
    }else if( (num2-1)/13<2 ){
        sta2=2;
    }else if( (num2-1)/13<3 ){
        sta2=3;
    }else if( (num2-1)/13<4 ){
        sta2=4;
    }else{
        printf("You enter wrong number\n");
        return 0;
    }
    //數字3判斷
    if(num3<1){
        printf("You enter wrong number\n");
        return 0;
    }else if( (num3-1)/13<1 ){
        sta3=1;
    }else if( (num3-1)/13<2 ){
        sta3=2;
    }else if( (num3-1)/13<3 ){
        sta3=3;
    }else if( (num3-1)/13<4 ){
        sta3=4;
    }else{
        printf("You enter wrong number\n");
        return 0;
    }
    //數字4判斷
    if(num4<1){
        printf("You enter wrong number\n");
        return 0;
    }else if( (num4-1)/13<1 ){
        sta4=1;
    }else if( (num4-1)/13<2 ){
        sta4=2;
    }else if( (num4-1)/13<3 ){
        sta4=3;
    }else if( (num4-1)/13<4 ){
        sta4=4;
    }else{
        printf("You enter wrong number\n");
        return 0;
    }
    //數字5判斷
    if(num5<1){
        printf("You enter wrong number\n");
        return 0;
    }else if( (num5-1)/13<1 ){
        sta5=1;
    }else if( (num5-1)/13<2 ){
        sta5=2;
    }else if( (num5-1)/13<3 ){
        sta5=3;
    }else if( (num5-1)/13<4 ){
        sta5=4;
    }else{
        printf("You enter wrong number\n");
        return 0;
    }
    //由大到小排列數字
    //如果數字2比較大
    if(non2>non1){
        tem=non1;
        non1=non2;
        non2=tem;
        //狀態交換
        tem=sta1;
        sta1=sta2;
        sta2=tem;
        tem=num1;
        num1=num2;
        num2=tem;
    }
    //如果數字3比較大
    if(non3>non2){
        tem=non2;
        non2=non3;
        non3=tem;
        tem=sta2;
        sta2=sta3;
        sta3=tem;
        tem=num2;
        num2=num3;
        num3=tem;
        if(non2>non1){
        tem=non1;
        non1=non2;
        non2=tem;
        tem=sta1;
        sta1=sta2;
        sta2=tem;
        tem=num1;
        num1=num2;
        num2=tem;
        }
    }
    //如果數字4比較大
    if(non4>non3){
        tem=non3;
        non3=non4;
        non4=tem;
        tem=sta3;
        sta3=sta4;
        sta4=tem;
        tem=num3;
        num3=num4;
        num4=tem;
    }
    if(non3>non2){
        tem=non2;
        non2=non3;
        non3=tem;
        tem=sta2;
        sta2=sta3;
        sta3=tem;
        tem=num2;
        num2=num3;
        num3=tem;
    }
    if(non2>non1){
        tem=non1;
        non1=non2;
        non2=tem;
        tem=sta1;
        sta1=sta2;
        sta2=tem;
        tem=num1;
        num1=num2;
        num2=tem;
    }    
    //如果數字5比較大
    if(non5>non4){
        tem=non4;
        non4=non5;
        non5=tem;
        tem=sta4;
        sta4=sta5;
        sta5=tem;
        tem=num4;
        num4=num5;
        num5=tem;
    }
    if(non4>non3){
        tem=non3;
        non3=non4;
        non4=tem;
        tem=sta3;
        sta3=sta4;
        sta4=tem;
        tem=num3;
        num3=num4;
        num4=tem;
    }
    if(non3>non2){
        tem=non2;
        non2=non3;
        non3=tem;
        tem=sta2;
        sta2=sta3;
        sta3=tem;
        tem=num2;
        num2=num3;
        num3=tem;
    }
    if(non2>non1){
        tem=non1;
        non1=non2;
        non2=tem;
        tem=sta1;
        sta1=sta2;
        sta2=tem;
        tem=num1;
        num1=num2;
        num2=tem;
    }
    //防呆，避免輸入同樣的數字
    if(num1==num2||num2==num3||num3==num4||num4==num5){
        printf("You enter wrong number\n");
        return 0;
    }
    //判斷同花和順子
    if(sta1==sta2&&sta2==sta3&&sta3==sta4&&sta4==sta5){
        if(non1-1==non2&&non2-1==non3&&non3-1==non4&&non4-1==non5){
            printf("Straight flush");
            return 0;
        }else if(non1==10||non2==11||non3==12||non4==13||non5==1){
            printf("Straight flush");
            return 0;
        }
        printf("Flush");
        return 0;
    }
    if(non1-1==non2&&non2-1==non3&&non3-1==non4&&non4-1==non5){
        printf("Straight");
        return 0;
    }else if(non1==10||non2==11||non3==12||non4==13||non5==1){
        printf("Straight");
        return 0;
    }
    //判斷Four of a kind
    if(non1==non2&&non2==non3&&non3==non4){
        printf("Four of a kind");
        return 0;
    }
    if(non2==non3&&non3==non4&&non4==non5){
        printf("Four of a kind");
        return 0;
    }
    //判斷Full house和Three of a kind
    if(non1==non2&&non2==non3){
        if(non4==non5){
            printf("Full house");
            return 0;
        }
        printf("Three of a kind");
        return 0;
    }
    if(non3==non4&&non4==non5){
        if(non1==non2){
            printf("Full house");
            return 0;
        }
        printf("Three of a kind");
        return 0;
    }
    if(non2==non3&&non3==non4){
        printf("Three of a kind");
        return 0;
    }
    //判斷pair
    if(non1==non2){
        if(non3==non4||non4==non5){
            printf("Two pair");
            return 0;
        }
        printf("One pair");
        return 0;
    }
    if(non2==non3){
        if(non4==non5){
            printf("Two pair");
            return 0;
        }
        printf("One pair");
        return 0;
    }
    if(non3==non4||non4==non5){
        printf("One pair");
        return 0;
    }
    printf("High card");
    /*printf("num %d %d %d %d %d\n",num1,num2,num3,num4,num5);
    printf("sta %d %d %d %d %d\n",sta1,sta2,sta3,sta4,sta5);
    printf("non %d %d %d %d %d\n",non1,non2,non3,non4,non5);
    */
    return 0;
}