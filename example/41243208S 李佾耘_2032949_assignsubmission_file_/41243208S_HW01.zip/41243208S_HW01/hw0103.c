#include<stdio.h>
#include<stdint.h>

int main(){
    uint64_t input=0;
    uint32_t num=0;
    //紀錄八進位，1~6位，以及一個暫存值，一個狀態值
    int32_t amount,amount1,amount2,amount3,amount4,amount5,amount6,tem,state=0;
    printf("$ ./hw0103\n");
    printf("Please enter an unsigned 16-bits number:");
    scanf("%ld",&input);
    if(input>65535){
        printf("You enter wrong number\n");
        return 0;
    }else{
        num=input;
    }
    printf("%d\n",num);
    //判斷8進位每一位數
    amount6=num/32768;
    tem=num%32768;
    if(tem/4096==8){
        amount5=(tem/4096)-1;
        tem=4096;
    }else{
        amount5=tem/4096;
        tem=tem%4096;
    }
    if(tem/512==8){
        amount4=(tem/512)-1;
        tem=512;
    }else{
        amount4=tem/512;
        tem=tem%512;
    }
    if(tem/64==8){
        amount3=(tem/64)-1;
        tem=64;
    }else{
        amount3=tem/64;
        tem=tem%64;
    }
    if(tem/8==8){
        amount2=(tem/8)-1;
        tem=tem%8;
    }else{
        amount2=tem/8;
        tem=tem%8;
    }
    amount1=tem%8;
    //判斷有幾位數(八進位)
    //tem等於整個八進位數
    if(amount6>0){
        //printf("%d%d%d%d%d%d\n",amount6,amount5,amount4,amount3,amount2,amount1);
        state=6;
        tem=amount6*100000+amount5*10000+amount4*1000+amount3*100+amount2*10+amount1;
    }else if(amount5>0){
        //printf("%d%d%d%d%d\n",amount5,amount4,amount3,amount2,amount1);
        state=5;
        tem=amount5*10000+amount4*1000+amount3*100+amount2*10+amount1;
    }else if(amount4>0){
        //printf("%d%d%d%d\n",amount4,amount3,amount2,amount1);
        state=4;
        tem=amount4*1000+amount3*100+amount2*10+amount1;
    }else if(amount3>0){
        //printf("%d%d%d\n",amount3,amount2,amount1);
        state=3;
        tem=amount3*100+amount2*10+amount1;
    }else if(amount2>0){
        //printf("%d%d\n",amount2,amount1);
        state=2;
        tem=amount2*10+amount1;
    }else{
        //printf("%d\n",amount1);
        state=1;
        tem=amount1;
    }
    //輸出文字
    printf("Before Flip:\n");
    printf("%d_10 = ",num);
    printf("%d_8\n",tem);
    printf("After Flip:\n");
    //翻轉八進位，tem存取翻取後的值
    if(state>5){
        tem=amount1*100000+amount2*10000+amount3*1000+amount4*100+amount5*10+amount6;
    }else if(state>4){
        tem=amount1*10000+amount2*1000+amount3*100+amount4*10+amount5;
    }else if(state>3){
        tem=amount1*1000+amount2*100+amount3*10+amount4;
    }else if(state>2){
        tem=amount1*100+amount2*10+amount3;
    }else if(state>1){
        tem=amount1*10+amount2;
    }else{
        tem=amount1;
    }
    //輸出翻轉後的八進位
    printf("%d_8 = ",tem);
    //計算十進位
    if(state>5){
        tem=amount1*32768+amount2*4096+amount3*512+amount4*64+amount5*8+amount6;
    }else if(state>4){
        tem=amount1*4096+amount2*512+amount3*64+amount4*8+amount5;
    }else if(state>3){
        tem=amount1*512+amount2*64+amount3*8+amount4;
    }else if(state>2){
        tem=amount1*64+amount2*8+amount3;
    }else if(state>1){
        tem=amount1*8+amount2;
    }else{
        tem=amount1;
    }
    printf("%d_10\n",tem);
    return 0;
}