#include<stdio.h>
#include<stdint.h>

int main(){
	printf("\x1b[31m[KIM]\n");
	printf("\x1b[31mYou are sunlight and I moon\n");
	printf("\x1b[31mJoined by the gods of fortune\n");
	printf("\x1b[31mMidnight and high noon sharing the sky\n");
	printf("\x1b[31mWe have been blessed , you and I\n");
	printf("\x1b[34m\n[CHRIS]\n");
	printf("\x1b[34mYou are here like a mystery\n");
	printf("\x1b[34mI'm from a world that's so different from all that you are\n");
	printf("\x1b[34mHow in the light of one night did we come so far?\n");
	printf("\x1b[31m\n[KIM]\n");
	printf("\x1b[31mOutside day starts to dawn\n");
	printf("\x1b[34m\n[CHRIS]\n");
	printf("\x1b[34mYour moon still floats on high\n");
	printf("\x1b[31m\n[KIM]\n");
	printf("\x1b[31mThe birds awake\n");
	printf("\x1b[34m\n[CHRIS]\n");
	printf("\x1b[34mThe stars shine too\n");
	printf("\x1b[31m\n[KIM]\n");
	printf("\x1b[31mMy hands still shake\n");
	printf("\x1b[31mSee upcoming pop shows\n");
	printf("\x1b[31mGet tickets for your favorite artists\n");
	printf("\x1b[31mYou might also like\n");
	printf("\x1b[31mMy Boy Only Breaks His Favorite Toys\n");
	printf("\x1b[31mTaylor Swift\n");
	printf("\x1b[31mWho’s Afraid of Little Old Me?\n");
	printf("\x1b[31mTaylor Swift\n");
	printf("\x1b[31mGuilty as Sin?\n");
	printf("\x1b[31mTaylor Swift\n");
	printf("\x1b[34m\n[CHRIS]\n");
	printf("\x1b[34mI reach for you\n");
	printf("\x1b[32m\n[KIM & CHRIS]\n");
	printf("\x1b[32mAnd we meet in the sky\n");
	printf("\x1b[31m\n[KIM]\n");
	printf("\x1b[31mYou are sunlight and I moon\n");
	printf("\x1b[31mJoined here\n");
	printf("\x1b[31mBrightening the sky with the flame of love\n");
	printf("\x1b[32m\n[KIM & CHRIS]\n");
	printf("\x1b[32mMade of\n");
	printf("\x1b[32mSunlight\n");
	printf("\x1b[32mMoonlight\n");

	return 0;
}
