# HW01

## Personal Profile

Author:江禹叡
Student ID:41347026s

## How to build the code

```bash
make
```
It will compile the code with gcc.

## How to execute the built programs

```bash
./hw010x
```
Substitute the number of HW for x.

## 1.6 Bonus: Makefile for Multiple files

Ans: add `-` before gcc

all:
    -gcc a.c -o a
    -gcc b.c -o b

