#include <stdio.h>

#define red "\x1b[;31;1m" 
#define blue "\x1b[34;1m"
#define green "\x1b[;32;1m"

int main(){
    printf(red"You are sunlight and I moon\n");
    printf(red"Joined by the gods of fortune\n");
    printf(red"Midnight and high noon sharing the sky\n");
    printf(red"We have been blessed , you and I\n\n");
    
    printf(blue"You are here like a mystery\n");
    printf(blue"I'm from a world that 's so different from all that you are\n");
    printf(blue"How in the light of one night did we come so far?\n\n");

    printf(red"Outside day starts to dawn\n\n");

    printf(blue"Your moon still floats on high\n\n");

    printf(red"The birds awake\n\n");

    printf(blue"The stars shine too\n\n");

    printf(red"My hands still shake\n");
    printf(red"See upcoming pop shows\n");
    printf(red"Get tickets for your favorite artists\n\n");

    printf(red"You might also like\n");
    printf(red"My Boy Only Breaks His Favorite Toys\n");
    printf(red"Taylor Swift\n");
    printf(red"Who ’ s Afraid of Little Old Me?\n");
    printf(red"Taylor Swift\n");
    printf(red"Guilty as Sin?\n");
    printf(red"Taylor Swift\n\n");

    printf(blue"I reach for you\n\n");

    printf(green"And we meet in the sky\n\n");

    printf(red"You are sunlight and I moon\n");
    printf(red"Joined here\n");
    printf(red"Brightening the sky with the flame of love\n\n");

    printf(green"Made of\n");
    printf(green"Sunlight\n");
    printf(green"Moonlight\n");
}