#include <stdio.h>
#include <stdint.h>

//66535

int main(){
    printf("Please enter an unsigned 16-bits number: ");

    uint32_t n = 0, fin;
    scanf(" %d", &n);

    printf("Before Flip:\n");
    printf("%d_10 = %o_8\n", n, n);
    printf("After Flip:\n");



    //要知道8進位的那個是幾個位數才知道怎麼翻轉數字
    if (n > 077777){//有六位
        uint32_t tmp, n1, n2, n3, n4, n5, n6;

        n1 = n / 32768 % 8;
        n2 = n / 4096 % 8;
        n3 = n / 512 % 8;
        n4 = n / 64 % 8;
        n5 = n / 8 % 8;
        n6 = n / 1 % 8;



        tmp = n1;
        n1 = n6;
        n6 = tmp;
        tmp = n2;
        n2 = n5;
        n5 = tmp;
        tmp = n3;
        n3 = n4;
        n4 = tmp;

        fin = n1 * 32768 + n2 * 4096 + n3 * 512 + n4 * 64 + n5 * 8 + n6 * 1;
    }
    else if (n > 07777){//有五位
        uint32_t tmp, n1, n2, n3, n4, n5;

        n1 = n / 4096 % 8;
        n2 = n / 512 % 8;
        n3 = n / 64 % 8;
        n4 = n / 8 % 8;
        n5 = n / 1 % 8;


        tmp = n1;
        n1 = n5;
        n5 = tmp;
        tmp = n2;
        n2 = n4;
        n4 = tmp;

        fin = n1 * 4096 + n2 * 512 + n3 * 64 + n4 * 8 + n5 * 1;
    }
    else if (n > 0777){//有四位
        uint32_t tmp, n1, n2, n3, n4;


        n1 = n / 512 % 8;
        n2 = n / 64 % 8;
        n3 = n / 8 % 8;
        n4 = n / 1 % 8;

        tmp = n1;
        n1 = n4;
        n4 = tmp;
        tmp = n2;
        n2 = n3;
        n3 = tmp;

        fin = n1 * 512 + n2 * 64 + n3 * 8 + n4 * 1;
    }
    else if (n > 077){//有三位
        uint32_t tmp, n1, n2, n3;

        n1 = n / 64 % 8;
        n2 = n / 8 % 8;
        n3 = n / 1 % 8;

        tmp = n1;
        n1 = n3;
        n3 = tmp;

        fin = n1 * 64 + n2 * 8 + n3 * 1;
    }
    else if (n > 07){//有兩位
        uint32_t tmp, n1, n2;
        n1 = n / 8 % 8;
        n2 = n / 1 % 8;

        tmp = n1;
        n1 = n2;
        n2 = tmp;

        fin = n1 * 8 + n2 * 1;
    }
    else{//只有一位
        fin = n;
    }

    printf("%o_8 = %d_10\n", fin, fin);

}
//65535 2^16 10進位
//177777

