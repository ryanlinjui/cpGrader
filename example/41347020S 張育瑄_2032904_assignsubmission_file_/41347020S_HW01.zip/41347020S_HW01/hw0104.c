#include <stdio.h>
#include <stdint.h>



int main(){
    printf("Please enter 5 cards separated by spaces:");
    int32_t n1, n2, n3, n4, n5;//存原始數字
    int32_t c1, c2, c3, c4, c5;//存花色
    int32_t b1, b2, b3, b4, b5;//存數字大小

    if(!scanf("%d%d%d%d%d",&n1,&n2,&n3,&n4,&n5)){
        printf("INPUT ERROR!!!\n");
        return 0;
    }

    //判斷輸入有超過52、1，有沒有重複輸入的牌
    if (n1 > 52){
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (n2 > 52){
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (n3 > 52){
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (n4 > 52){
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (n5 > 52){
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (n1 < 1){
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (n2 < 1){
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (n3 < 1){
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (n4 < 1){
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (n5 < 1){
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if ((n1 == n2) && (n1 == n3) && (n1 == n4) && (n1 == n5) && (n2 == n3) && (n2 == n4) && (n2 == n5) && (n3 == n4) && (n3 == n5) && (n4 == n5)){
        printf("INPUT ERROR!!!\n");
        return 0;
    }

    
    //判斷花色
    if ((n1 - 1) / 13 == 0) c1 = 1;
    else if ((n1 - 1) / 13 == 1) c1 = 2;
    else if ((n1 - 1) / 13 == 2) c1 = 3;
    else c1 = 4;
    if ((n2 - 1) / 13 == 0) c2 = 1;
    else if ((n2 - 1) / 13 == 1) c2 = 2;
    else if ((n2 - 1) / 13 == 2) c2 = 3;
    else c2 = 4;
    if ((n3 - 1) / 13 == 0) c3 = 1;
    else if ((n3 - 1) / 13 == 1) c3 = 2;
    else if ((n3 - 1) / 13 == 2) c3 = 3;
    else c3 = 4;
    if ((n4 - 1) / 13 == 0) c4 = 1;
    else if ((n4 - 1) / 13 == 1) c4 = 2;
    else if ((n4 - 1) / 13 == 2) c4 = 3;
    else c4 = 4;
    if ((n5 - 1) / 13 == 0) c5 = 1;
    else if ((n5 - 1) / 13 == 1) c5 = 2;
    else if ((n5 - 1) / 13 == 2) c5 = 3;
    else c5 = 4;

    //判斷數字大小
    b1 = n1 % 13;
    if (b1 == 0) b1 = 13;
    b2 = n2 % 13;
    if (b2 == 0) b2 = 13;
    b3 = n3 % 13;
    if (b3== 0) b3 = 13;
    b4 = n4 % 13;
    if (b4 == 0) b4 = 13;
    b5 = n5 % 13;
    if (b5 == 0) b5 = 13;
    
    /*
    printf("number = %d, %d, %d, %d, %d\n", n1, n2, n3, n4, n5);
    printf("color = %d, %d, %d, %d, %d\n", c1, c2, c3, c4, c5);
    printf("big = %d, %d, %d, %d, %d\n", b1, b2, b3, b4, b5);
    */

    //除錯
    if ((b1 == b2 && b2 == b3 && b3 == b4) || (b1 == b2 && b2 == b3 && b3 == b5) || (b1 == b2 && b2 == b4 && b4 == b5) || (b1 == b3 && b3 == b4 && b4 == b5) || (b2 == b3 && b3 == b4 && b4 == b5)){
        //看看是不是四個一樣
        printf("Full of a kind\n");//2 Full of a kind 鐵支
    }
    else if (c1 == c2 && c2 == c3 && c3 == c4 && c4 == c5){
        int32_t ma = 0, mi = 14;
        if (b1 > ma) ma = b1;
        if (b2 > ma) ma = b2;
        if (b3 > ma) ma = b3;
        if (b4 > ma) ma = b4;
        if (b5 > ma) ma = b5;
        if (b1 < mi) mi = b1;
        if (b2 < mi) mi = b2;
        if (b3 < mi) mi = b3;
        if (b4 < mi) mi = b4;
        if (b5 < mi) mi = b5;

        if (((b1 != b2) && (b1 != b3) && (b1 != b4) && (b1 != b5) && (b2 != b3) && (b2 != b4) && (b2 != b5) && (b3 != b4) && (b3 != b5) && (b4 != b5)) &&  (ma - 4 == mi)){
            printf("Straight flush\n");//1 Straight flush** 同花順
        }
        //如果有Ａ的情況
        else if (mi == 1 && ((b1 != b2) && (b1 != b3) && (b1 != b4) && (b1 != b5) && (b2 != b3) && (b2 != b4) && (b2 != b5) && (b3 != b4) && (b3 != b5) && (b4 != b5))){
            int32_t bb1, bb2, bb3, bb4, bb5;
            if (b1 != 1) bb1 = b1;
            else bb1 = 14;
            if (b2 != 1) bb2 = b2;
            else bb2 = 14;
            if (b3 != 1) bb3 = b3;
            else bb3 = 14;
            if (b4 != 1) bb4 = b4;
            else bb4 = 14;
            if (b5 != 1) bb5 = b5;
            else bb5 = 14;
            int32_t max = 0, min = 14;
            if (bb1 > max) max = bb1;
            if (bb2 > max) max = bb2;
            if (bb3 > max) max = bb3;
            if (bb4 > max) max = bb4;
            if (bb5 > max) max = bb5;
            if (bb1 < min) min = bb1;
            if (bb2 < min) min = bb2;
            if (bb3 < min) min = bb3;
            if (bb4 < min) min = bb4;
            if (bb5 < min) min = bb5;
            if (max - min == 4){
                printf("Straight flush\n");//1 Straight flush** 同花順
            }
            else{
                printf("Flush\n");//4 Flush 同花（？
            }
        }
        else{
            printf("Flush\n");//4 Flush 同花（？
        }
    }
    else if(((b1 != b2) && (b1 != b3) && (b1 != b4) && (b1 != b5) && (b2 != b3) && (b2 != b4) && (b2 != b5) && (b3 != b4) && (b3 != b5) && (b4 != b5))){
        int32_t ma = 0, mi = 14;
        if (b1 > ma) ma = b1;
        if (b2 > ma) ma = b2;
        if (b3 > ma) ma = b3;
        if (b4 > ma) ma = b4;
        if (b5 > ma) ma = b5;
        if (b1 < mi) mi = b1;
        if (b2 < mi) mi = b2;
        if (b3 < mi) mi = b3;
        if (b4 < mi) mi = b4;
        if (b5 < mi) mi = b5;
        if (ma - mi == 4){
            printf("straight\n");
        }
        //如果有Ａ的情況
        else if (mi == 1 && ((b1 != b2) && (b1 != b3) && (b1 != b4) && (b1 != b5) && (b2 != b3) && (b2 != b4) && (b2 != b5) && (b3 != b4) && (b3 != b5) && (b4 != b5))){
            int32_t bb1, bb2, bb3, bb4, bb5;
            if (b1 != 1) bb1 = b1;
            else bb1 = 14;
            if (b2 != 1) bb2 = b2;
            else bb2 = 14;
            if (b3 != 1) bb3 = b3;
            else bb3 = 14;
            if (b4 != 1) bb4 = b4;
            else bb4 = 14;
            if (b5 != 1) bb5 = b5;
            else bb5 = 14;
            int32_t max = 0, min = 14;
            if (bb1 > max) max = bb1;
            if (bb2 > max) max = bb2;
            if (bb3 > max) max = bb3;
            if (bb4 > max) max = bb4;
            if (bb5 > max) max = bb5;
            if (bb1 < min) min = bb1;
            if (bb2 < min) min = bb2;
            if (bb3 < min) min = bb3;
            if (bb4 < min) min = bb4;
            if (bb5 < min) min = bb5;
            if (max - min == 4){
                printf("straight\n");
            }
            else {
                printf("High card\n");//9 High card
            }
        }
        else {
            printf("High card\n");//9 High card
        }
    }
    else if  ((b1 == b2 && b3 == b4 && b4 == b5) || (b1 == b3 && b2 == b4 && b4 == b5) || (b1 == b4 && b2 == b3 && b3 == b5) || (b1 == b5 && b3 == b4 && b4 == b2) || (b2 == b3 && b1 == b4 && b4 == b5) || (b2 == b4 && b1 == b3 && b3 == b5) || (b2 == b5 && b1 == b4 && b4 == b3) || (b3 == b4 && b1 == b2 && b2 == b5) || (b3 == b5 && b1 == b2 && b2 == b4) || (b5 == b4 && b1 == b2 && b2 == b3)){
        printf("Full house\n");//3 Full house 葫蘆
    }
    else if (((b1 != b2) && (b3 == b4 && b4 == b5)) || ((b1 != b3) && (b2 == b4 && b4 == b5)) || ((b1 != b4) && (b2 == b3 && b3 == b5)) || ((b1 != b5) && (b3 == b4 && b4 == b2)) || ((b2 != b3) && (b1 == b4 && b4 == b5)) || ((b2 != b4) && (b1 == b3 && b3 == b5)) || ((b2 != b5) && (b1 == b4 && b4 == b3)) || ((b3 != b4) && (b1 == b2 && b2 == b5)) || ((b3 != b5) && (b1 == b2 && b2 == b4)) || ((b4 != b5) && (b1 == b2 && b2 == b3))){
        printf("Three of a kind\n");//6 Three of a kind 3 pair
    }
    else if (((b1 == b2) && (b3 == b4)) || ((b1 == b2) && (b3 == b5)) || ((b1 == b2) && (b4 == b5)) || ((b1 == b3) && (b2 == b4)) || ((b1 == b3) && (b2 == b5)) || ((b1 == b3) && (b4 == b5)) || ((b1 == b4) && (b2 == b3)) || ((b1 == b4) && (b2 == b5)) || ((b1 == b4) && (b3 == b5)) || ((b1 == b5) && (b2 == b3)) || ((b1 == b5) && (b2 == b4)) || ((b1 == b5) && (b3 == b4)) || ((b2 == b3) && (b4 == b5)) || ((b2 == b4) && (b3 == b5)) || ((b2 == b5) && (b3 == b4))){
        printf("Two pair\n");//7 Two pair
    }
    else if ((b1 == b2 && b3 != b4 && b3 != b5 && b4 != b5) || (b1 == b3 && b2 != b4 && b2 != b5 && b4 != b5) ||(b1 == b4 && b2 != b3 && b2 != b5 && b3 != b5) || (b1 == b5 && b2 != b3 && b2 != b4 && b3 != b4) || (b2 == b3 && b1 != b4 && b1 != b5 && b4 != b5) || (b2 == b4 && b1 != b3 && b1 != b5 && b3 != b5) || (b2 == b5 && b1 != b3 && b1 != b4 && b3 != b4) || (b3 == b4 && b1 != b2 && b1 != b5 && b2 != b5) || (b3 == b5 && b1 != b2 && b1 != b4 && b2 != b4) || (b4 == b5 && b1 != b2 && b1 != b3 && b2 != b3)){
        printf("One pair\n");//8 One pair
    }
    else{//9 High card
        printf("High card\n");
    }
    return 0;
}

/*
1~13 黑桃
14~26 紅心
27~39 菱形
40~52 梅花

*/