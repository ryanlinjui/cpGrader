#include <stdio.h>
#include <stdint.h>

int main(){

    
    //輸入數字part
    int32_t x = 0, y = 0, z = 0,a1 = 0, a3 = 0, b2 = 0, c1 = 0, c2 = 0, c3 = 0;
    printf("Please enter the first operand:");
    scanf(" %dx%d", &a1, &a3);
    if (a1 >= 10) {
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (a1 < 0){
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (a3 >= 10) {
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (a3 < 0){
        printf("INPUT ERROR!!!\n");
        return 0;
    }

    printf("Please enter the second operand:");
    scanf(" y%dz", &b2);
    if (b2 >= 10) {
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (b2 < 0){
        printf("INPUT ERROR!!!\n");
        return 0;
    }

    printf("Please enter the sum :");
    scanf(" %d", &c3);

    if (c3 < (a1 * 100 + b2 * 10 + a3 * 1)){
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (c3 > (a1 * 100 + b2 * 10 + a3 * 1) + 999){
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    if (c3 >= 2000) {
        printf("No Solution!!!\n");
        return 0;
    }
    
    c1 = c3 /100;
    c2 = c3 / 10 % 10;
    c3 = c3 / 1 % 10;
    
    //計算
    if (c3 - a3 < 0 && c2 - b2 - 1 < 0){
        z = c3 - a3 + 10;
        x = c2 - b2 - 1 + 10;
        y = c1 - a1 - 1;
    }
    if (c3 - a3 < 0 && c2 - b2 - 1 >= 0){
        z = c3 - a3 + 10;
        x = c2 - b2 - 1;
        y = c1 - a1;
    }
    if (c3 - a3 >= 0 && c2 - b2 < 0){
        z = c3 - a3;
        x = c2 - b2 + 10;
        y = c1 - a1 - 1;
    }
    if (c3 - a3 >= 0 && c2 - b2 >= 0){
        z = c3 - a3;
        x = c2 - b2;
        y = c1 - a1;
    }


    printf("Ans: x = %d, y = %d, z = %d\n", x, y, z);
    
    return 0;
}