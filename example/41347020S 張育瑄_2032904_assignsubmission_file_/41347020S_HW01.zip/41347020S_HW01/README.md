# My student ID and your name.
My student ID is : 41347020S
My name is :張育瑄

# How to build my code.
1.
unzip 41347020S_HW01.zip
2.
cd 41347020S_HW01
3.
make

# How to execute my built programs.
1.
./hw0101
2.
./hw0102
3.
./hw0103
4.
./hw0104
5.
./hw0105
