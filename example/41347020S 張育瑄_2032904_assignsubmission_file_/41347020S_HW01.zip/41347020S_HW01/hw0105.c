#include <stdio.h>
#include <stdint.h>

/*
有一點問題的區：
1.輸入的十六進位英文字都會大寫英文嗎？還是會出現小寫英文？
2.擋輸入是小數？？？
*/


int main(){


    int32_t number = 0, typ;
    int32_t bin1, bin2, bin3, bin4;
    printf("Please input a hex: ");
    scanf("%X", &number);
    if (number > 65535){//如果輸入的16進位數字超過四位的話（？
        printf("INPUT ERROR!!!\n");
        return 0;
    }
    printf("Please choose the output type (1: integer ,2: unsigned integer ,3:float):");
    scanf(" %d", &typ);


    //16進位改2進位
    bin1 = 1000 * (number / 32768 % 2) + 100 * (number / 16384 % 2) + 10 * (number / 8192 % 2) + 1 * (number / 4096 % 2);
    bin2 = 1000 * (number / 2048 % 2) + 100 * (number / 1024 % 2) + 10 * (number / 512 % 2) + 1 * (number / 256 % 2);
    bin3 = 1000 * (number / 128 % 2) + 100 * (number / 64 % 2) + 10 * (number / 32 % 2) + 1 * (number / 16 % 2);
    bin4 = 1000 * (number / 8 % 2) + 100 * (number / 4 % 2) + 10 * (number / 2 % 2) + 1 * (number / 1 % 2);
    //如果number前面有0的話要手動加上去
    if (number < 16){
        printf("Binary of 000%X is : ", number);
    }
    else if (number < 256){
        printf("Binary of 00%X is : ", number);
    }
    else if (number < 4096){
        printf("Binary of 0%X is : ", number);
    }
    else{
        printf("Binary of %X is : ", number);
    }

    
    //如果其中一個bin<1000，那就可能不會輸出四位數 -> 看數字大小前面手動加上 -> ok
    if (bin1 < 10){
        printf("000%d ", bin1);
    }else if (bin1 < 100){
        printf("00%d ", bin1);
    }else if (bin1 < 1000){
        printf("0%d ", bin1);
    }else {
        printf("%d ", bin1);
    }
    if (bin2 < 10){
        printf("000%d ", bin2);
    }else if(bin2 < 100){
        printf("00%d ", bin2); 
    }else if (bin2 <1000){
        printf("0%d ", bin2);
    }else{
        printf("%d ", bin2);
    }
    if (bin3 < 1000){
        printf("000%d ", bin3);
    }else if(bin3 < 100){
        printf("00%d ", bin3); 
    }else if (bin3 <1000){
        printf("0%d ", bin3);
    }else {
        printf("%d ", bin3);
    }
    if (bin4 < 1000){
        printf("000%d\n", bin4);
    }else if(bin4 < 100){
        printf("00%d\n", bin4); 
    }else if (bin4 <1000){
        printf("0%d\n", bin4);
    }else{
        printf("%d\n", bin4);
    }


    if (typ == 1){//integer
        //如果第一個數字是0那他就是正的，直接輸出就好了
        //如果第一個數字是1，那他就是負的，要先翻轉再加一，最後輸出前面要有負號
        if (bin1 < 1000){
            printf("Converted integer is: %d\n", number);
        }
        else {
            int32_t bi1, bi2, bi3, bi4;
            int32_t ten = 0;
            //先把0和1都弄成相反的
            bi1 = 1111 - bin1;
            bi2 = 1111 - bin2;
            bi3 = 1111 - bin3;
            bi4 = 1111 - bin4;
            //把二進位的數字用成十進位，再加一
            ten += 325768 * (bi1 / 1000 % 10) + 16384 * (bi1 / 100 % 10) + 8192 * (bi1 / 10 % 10) + 4096 * (bi1 / 1 % 10);
            ten += 2048 * (bi2 / 1000 % 10) + 1024 * (bi2 / 100 % 10) + 512 * (bi2 / 10 % 10) + 256 * (bi2 / 1 % 10);
            ten += 128 * (bi3 / 1000 % 10) + 64 * (bi3 / 100 % 10) + 32 * (bi3 / 10 % 10) + 16 * (bi3 / 1 % 10);
            ten += 8 * (bi4 / 1000 % 10) + 4 * (bi4 / 100 % 10) + 2 * (bi4 / 10 % 10) + 1 * (bi4 / 1 % 10) + 1;
        
            printf("Converted integer is: -%d\n", ten);
        }
    }
    else if (typ == 2){//unsigned integer
        printf("Converted unsigned integer is: %d\n", number);
    }
    else if (typ == 3){//float
        //特殊情況
        if (number == 0){//+0.0
            printf("Converted float is: +0.0\n");
        }else if (bin1 == 1000 && bin2 == 0 && bin3 == 0 && bin4 == 0){//-0.0
            printf("Converted float is: -0.0\n");
        }
        else if (bin1 == 111 && bin2 == 1100 && bin3 == 0 && bin4 == 0){//+INF
            printf("Converted float is: +INF\n");
        }
        else if (bin1 == 1111 && bin2 == 1100 && bin3 == 0 && bin4 == 0){//-INF
            printf("Converted float is: -INF\n");
        }
        else if (bin1 % 1000 == 111 && bin2 / 100 == 11){//NAN
            printf("Converted float is: NAN\n");
        }
        else {//一般情況
            if (bin1 / 1000 % 10 == 0){
                printf("Converted float is: ");
            }
            else {
                printf("Converted float is: -");
            }
            int32_t exp;
            float f = 0;
            exp = 16 * (bin1 / 100 % 10)+ 8 * (bin1 / 10 % 10) + 4 * (bin1 / 1 % 10) + 2 * (bin2 / 1000 % 10) + 1 * (bin2 / 100 % 10);
            f += 1 + 0.5 * (bin2 / 10 % 10)+ 0.25 * (bin2 / 1 % 10);
            f += 0.125 * (bin3 / 1000 % 10) + 0.0625 * (bin3 / 100 % 10) + 0.03125 * (bin3 / 10 % 10) + 0.015625 * (bin3 / 1 % 10);
            f += 0.0078125 * (bin4 / 1000 % 10) + 0.00390625 * (bin4 / 100 % 10) + 0.001953125 * (bin4 / 10 % 10) + 0.0009765625 * (bin4 / 1 % 10);
            printf("%f*2^%d\n", f, exp - 15);
        }
        
        
    }
    
    return 0;
}