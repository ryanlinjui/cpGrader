#include <stdio.h>
#include <stdlib.h>

int main()
{
int a, b, c, d, e, f, x, y, z;
printf("Please enter the first operand:");	
scanf(" %dx%d", &a,&b);
if(a >= 10 || a < 0 || b >= 10 || b < 0){
	printf("%dx%d is not an allowed operent.",a,b);
	exit(0);}
printf("Please enter the second operand:");
scanf(" y%dz", &c);
if(c >= 10 || c < 0){
        printf("y%dz is not an allowed operent.",c);
        exit(0);}
printf("Please enter the sum:");
scanf(" %d", &d);
e=a*100+c*10+b;
f=d-e;
z=f%10;
x=(f%100-z)/10;
y=(f-x*10-z)/100;
printf("Ans: x=%d, y=%d, z=%d",x,y,z);
return 0;
}

