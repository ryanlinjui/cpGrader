#include <stdio.h>

#define RED "\x1b[;31;1m"

#define BLUE "\x1b[;34;1m"

#define GRN "\x1b[;32;1m"

int main()

{

printf(RED"[KIM]\n");
printf(RED"You are sunlight and I moon\n");
printf(RED"Joined by the gods of fortune\n");
printf(RED"Midnight and high noon sharing the sky\n");
printf(RED"We have been blessed, you and\n\n");
printf(BLUE"[CHRIS]\n");
printf(BLUE"You are here like a mystery\n");
printf(BLUE"I'm from a world that's so different from all that you are\n");
printf(BLUE"How in the light of one night did we come so far?\n\n");
printf(RED"[KIM]\n");
printf(RED"Outside day starts to dawn\n\n");
printf(BLUE"[CHRIS]\n");
printf(BLUE"Your moon still floats on high\n\n");
printf(RED"[KIM]\n");
printf(RED"The birds awake\n\n");
printf(BLUE"[CHRIS]\n");
printf(BLUE"The stars shine too\n\n");
printf(RED"[KIM]\n");
printf(RED"My hands still shake\n");
printf(RED"See upcoming pop shows\n");
printf(RED"Get tickets foryour favorite artists\n\n");
printf(RED"You might also like\n");
printf(RED"My Boy Only Breaks His Favorite Toys\n");
printf(RED"Taylor Swift\n");
printf(RED"Who's Afraid of Little Old Me?\n");
printf(RED"Taylor Swift\n");
printf(RED"Guilty as Sin?\n");
printf(RED"Taylor Swift\n\n");
printf(BLUE"[CHRIS]\n");
printf(BLUE"I reach for you\n\n");
printf(GRN"[KIM & CHRIS]\n");
printf(GRN"And we meet in the sky\n\n");
printf(RED"[KIM]\n");
printf(RED"You are sunlight and I moon\n");
printf(RED"Joined here\n");
printf(RED"Brightening the sky with the flame of love\n\n");
printf(GRN"[KIM & CHRIS]\n");
printf(GRN"Made of\n");
printf(GRN"Sunlight\n");
printf(GRN"Moonlight\n");
return 0;
}
