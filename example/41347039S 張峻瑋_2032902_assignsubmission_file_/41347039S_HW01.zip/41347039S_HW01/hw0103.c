#include <stdio.h>

int main()
{
int a,b,c,d,f,g,h,i,j,k,l,m,n,o,p,q;
printf("Please enter an unsigned 16-bits number:");
scanf(" %d", &a);
p=a;
b=a/32768;
a-=b*32768;
c=a/4096;
a-=c*4096;
d=a/512;
a-=d*512;
f=a/64;
a-=f*64;
g=a/8;
a-=g*8;
h=b*100000+c*10000+d*1000+f*100+g*10+a;
if(b > 0){
	i=(a*100000+g*10000+f*1000+d*100+c*10+b);
}else if(c > 0){
	i=(a*10000+g*1000+f*100+d*10+c);
}else if(d > 0){
        i=(a*1000+g*100+f*10+d);
}else if(f > 0){
        i=(a*100+g*10+f);
}else if(g > 0){
        i=(a*10+g);
}else{
	i=a;
}
q=i;
j=i/100000;
i-=j*100000;
k=i/10000;
i-=k*10000;
l=i/1000;
i-=l*1000;
m=i/100;
i-=m*100;
n=i/10;
i-=n*10;
o=j*32768+k*4096+l*512+m*64+n*8+i;
printf("Before Flip:\n%d_10 = %d_8\nAfter  Flip:\n%d_8 = %d_10\n",p,h,q,o);
return 0;
}
