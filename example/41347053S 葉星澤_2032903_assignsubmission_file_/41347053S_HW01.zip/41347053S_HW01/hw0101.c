#include<stdio.h>

#define RED  "\x1b[31m"
#define BLUE  "\x1b[34m"
#define GREEN  "\x1b[32m"
#define DEFC "\x1b[00m"

int main(){

	printf("%s[KIM]\nYou are sunlight and I moon\nJoined by the gods of fortune\n",RED);
	printf("%sMidnight and high noon sharing the sky\nWe have been blessed, you and I\n\n",RED);

	printf("%s[CHRIS]\nYou are here like a mystery\n",BLUE);
	printf("%sI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\n\n",BLUE);
	
	printf("%s[KIM]\nOutside day starts to dawn\n\n",RED);

	printf("%s[CHRIS]\nYour moon still floats on high\n\n",BLUE);

	printf("%s[KIM]\nThe birds awake\n\n",RED);

	printf("%s[CHRIS]\nThe stars shine too\n\n",BLUE);

	printf("%s[KIM]\nMy hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n",RED);
	printf("%sYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho’s Afraid of Little Old Me?",RED);
	printf("%sTaylor Swift\nGuilty as Sin?\nTaylor Swift\n\n",RED);
	
	printf("%s[CHRIS]\nI reach for you\n\n",BLUE);
	
	printf("%s[KIM & CHRIS]\nAnd we meet in the sky\n\n",GREEN);

	printf("%s[KIM]\nYou are sunlight and I moon\nJoined here\n",RED);
	printf("%sBrightening the sky with the flame of love\n\n",RED);
	
	printf("%s[KIM & CHRIS]\nMade of\nSunlight\nMoonlight\n",GREEN);

	printf("%s",DEFC);

	return 0;

}


/*[KIM]
You are sunlight and I moon
Joined by the gods of fortune
Midnight and high noon sharing the sky
We have been blessed, you and I

[CHRIS]
You are here like a mystery
I'm from a world that's so different from all that you are
How in the light of one night did we come so far?

[KIM]
Outside day starts to dawn

[CHRIS]
Your moon still floats on high

[KIM]
The birds awake

[CHRIS]
The stars shine too
========================================================================
[KIM]
My hands still shake
See upcoming pop shows
Get tickets for your favorite artists

You might also like
My Boy Only Breaks His Favorite Toys
Taylor Swift
Who’s Afraid of Little Old Me?
Taylor Swift
Guilty as Sin?
Taylor Swift
*/
