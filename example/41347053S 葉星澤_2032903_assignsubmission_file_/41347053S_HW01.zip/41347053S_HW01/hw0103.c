#include<stdio.h>
#include<stdint.h>
int main(){

	int32_t deci;
	printf("Please enter an unsigned 16-bits number: ");
	scanf("%d",&deci);
	int32_t dicimal_user = deci; // decimal number
 // devidenc decimal
	int32_t o5,o4,o3,o2,o1;
	if(deci >=32768){
		o5 = deci/32768;
		deci = deci%32768;
	}else{o5 = 0;}
	if(deci >=4096){
		o4 = deci/4096;
		deci = deci%4096;
	}else{o4 = 0;
	}
	if(deci >=512){ 
                o3 = deci/512;
                deci = deci%512;
        }else{ o3 = 0;}
        if(deci >=64){ 
                o2 = deci/64;
                deci = deci%64;
        }else{ o2 = 0;
        }if(deci >= 8){
		o1 = deci/8;
		deci = deci%8;
	}else{o1 = 0;	}
	int32_t value_oc;
	//value_oc = (10000*o5)+(1000*o4)+(100*o3)+(10*o2)+(1*o1);
	value_oc = (deci*1)+(o1*10)+(o2*100)+(o3*1000)+(o4*10000)+(o5*100000);
//	printf("%d%d%d%d%d%d\n",o5,o4,o3,o2,o1,deci);
//	printf("%d\n",value_oc);

	//filip
	int32_t fo5,fo4,fo3,fo2,fo1,founit;
	fo5 = deci;
	fo4 = o1;
	fo3 = o2;
        fo2 = o3;
	fo1 = o4;
	founit = o5;
//	printf("%d%d%d%d%d%d\n",fo5,fo4,fo3,fo2,fo1,founit);
	int32_t value_oc_filip;
	value_oc_filip = (founit*1)+(fo1*10)+(fo2*100)+(fo3*1000)+(fo4*10000)+(fo5*100000);
//	printf("octal flip %d",value_oc_filip);
	//chang oct flip to R number
	int32_t n = value_oc_filip;
	if(n%10==0){
	n=n/10;}
	if(n%10==0){ 
        n=n/10;}
	if(n%10==0){ 
        n=n/10;}
        if(n%10==0){ 
        n=n/10; }
	if(n%10==0){ 
        n=n/10;}
	int32_t r_num_ocf = n;
//	printf("real num oct : %d\n",r_num_ocf);
//devide octal number
	int32_t d5,d4,d3,d2,d1;
	int num = r_num_ocf;
	if(num >=100000){d5 = num/100000;num=num%100000;}else{d5=0;}
	if(num >=10000){d4 = num/10000;num = num%10000;}else{d4=0;}
	if(num >=1000){d3 = num/1000;num=num%1000;}else{d3=0;}
        if(num >=100){d2 = num/100;num=num%100;}else{d2=0;}
	if(num >=10){d1 = num/10;num=num%10;}else{d1=0;}
//	printf("%d%d%d%d%d%d\n",d5,d4,d3,d2,d1,num);
// 8 to 10
	int32_t deci_re;
	deci_re = (d5*32768)+(d4*4096)+(d3*512)+(d2*64)+(d1*8)+(num*1);
//octal_re = (32768*of5)+(4096*of4)+(512*of3)+(64*of2)+(8*of1)+(1*d1);
	printf("Before Flip:\n%d_10 = %d_8\n",dicimal_user,value_oc);
	printf("After Flip:\n%d_8 = %d_10\n",r_num_ocf,deci_re);
	return 0;
}
