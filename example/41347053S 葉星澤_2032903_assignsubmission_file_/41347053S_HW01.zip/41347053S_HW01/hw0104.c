#include<stdio.h>
#include<stdint.h>

int main(){
	int32_t card1,card2,card3,card4,card5;// contain card
	int32_t f1,f2,f3,f4,f5; //each card of fig
	printf("Please enter 5 cards: ");
	scanf("%d %d %d %d %d",&card1,&card2,&card3,&card4,&card5);

	//find fig
	f1 = (card1-1)/13; // = 0 is 1-13
	f2 = (card2-1)/13;// = 1 is 14-26
	f3 = (card3-1)/13;// = 2 is 27-39
	f4 = (card4-1)/13;// = 3 is 40-52
	f5 = (card5-1)/13 ;
	//find rank
//	printf("%d %d %d %d %d\n",f1,f2,f3,f4,f5);
	//find rank for compare /for example 13 ==13 , 14 ==1
	int32_t rank1,rank2,rank3,rank4,rank5;
	if(card1%13==0){
	rank1= 13;
		}else{rank1 = (card1%13);}
	if(card2%13==0){
	rank2 = 13;
		}else{rank2 = (card2%13);}
	if(card3%13==0){
	rank3 =13;
		}else{rank3 = (card3%13);}
	if(card4%13==0){
	rank4 =13;
		}else{rank4 = (card4%13);}
	if(card5%13 ==0)
	{rank5 =13;
		}else{rank5 = (card5%13);}

// 1 2 3 4 5
	if(f1 == f2&&f2==f3&&f3==f4&&f4==f5  && rank2==rank1+1&&rank3==rank2+1 && rank4==rank3+1&&rank5 == rank4+1){
		printf("Straight Flush\n");}
	else if(rank1 == rank2 && rank2==rank3 && rank3==rank4){
		printf("Four of kind\n");}
	else if(rank1 == rank2 && rank2 == rank3 && rank4 == rank5){
		printf("Full House\n");}
	else if(f1 == f2&&f2==f3&&f3==f4&&f4==f5){
		printf("Flush\n");}
// i want to cry
	else if(rank2 == rank1+1 && rank3 ==rank2+1 && rank4 == rank3+1 && rank5== rank4+1){
		printf("Straight\n");}
	else if(rank1 == rank2 && rank2 == rank3){
		printf("Three of a kind\n");}
	else if((rank1 == rank2 && rank3 == rank4)){
		printf("Two pair\n");}
	else if(rank1 == rank2 || rank2 == rank3 ||rank3==rank4||rank4==rank5){
		printf("One pair\n");}
	else{
		printf("High card\n");
	}

	return 0;
}


