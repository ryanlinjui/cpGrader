#include<stdio.h>
#include<stdint.h>

int main(){
	int32_t user_;
	uint32_t hExInput;


	printf("Please input a hex:");
	scanf("%x",&hExInput);
	//devide each number for calculat to digit number;
	uint32_t b15,b14,b13,b12,b11,b10,b9,b8,b7,b6,b5,b4,b3,b2,b1,b0;
	b15 = (hExInput/32768)%2;
	b14 = (hExInput/16384)%2;
	b13 = (hExInput/8192)%2;
	b12 = (hExInput/4096)%2;
        b11 = (hExInput/2048)%2;
        b10 = (hExInput/1024)%2;
	b9 = (hExInput/512)%2;
 	b8 = (hExInput/256)%2;
	b7 = (hExInput/128)%2;
 	b6 = (hExInput/64)%2;
 	b5 = (hExInput/32)%2;
	b4 = (hExInput/16)%2;
 	b3 = (hExInput/8)%2;
	b2 = (hExInput/4)%2;
 	b1 = (hExInput/2)%2;
	b0 = (hExInput/1)%2;
//
	//16 > degit

	printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
	scanf("%d",&user_);

	printf("Binary of %X is: ",hExInput);
	printf("%d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",b15,b14,b13,b12,b11,b10,b9,b8,b7,b6,b5,b4,b3,b2,b1,b0);
	//for unsigned integer
	uint32_t case2uint = (b0*1)+(b1*2)+(b2*4)+(b3*8)+(b4*16)+(b5*32)+(b6*64)+(b7*128)+(b8*256)+(b9*512)+(b10*1024)+(b11*2048)+(b12*4096)+(b13*8192)+(b14*16384)+(b15*32768);

	switch(user_){
	case 1:

	if(b15 == 1){
		
		uint32_t flip;
		//Flip
		uint32_t f0,f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,f14,f15;
		if(b0==0)
			{f0=1;}else{f0=0;}
		if(b1==0)
                	{f1=1;}else{f1=0;}
		if(b2==0)
                	{f2=1;}else{f2=0;}
                if(b3==0)
                	{f3=1;}else{f3=0;}
		if(b4==0)
                	{f4=1;}else{f4=0;}
                if(b5==0)
                	{f5=1;}else{f5=0;}
		if(b6==0)
                        {f6=1;}else{f6=0;}
                if(b7==0)
                        {f7=1;}else{f7=0;}
                if(b8==0)
                        {f8=1;}else{f8=0;}
                if(b9==0)
                        {f9=1;}else{f9=0;}
                if(b10==0)
                        {f10=1;}else{f10=0;}
                if(b11==0)
                        {f11=1;}else{f11=0;}
		if(b12==0)
                        {f12=1;}else{f12=0;}
                if(b13==0)
                        {f13=1;}else{f13=0;}
                if(b14==0)
                        {f14=1;}else{f14=0;}
                if(b15==0)
                        {f15=1;}else{f15=0;}
	//	printf("befor : %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",b15,b14,b13,b12,b11,b10,b9,b8,b7,b6,b5,b4,b3,b2,b1,b0);
	//	printf("ater : %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",f15,f14,f13,f12,f11,f10,f9,f8,f7,f6,f5,f4,f3,f2,f1,f0);
		//find bit for usr two complement
		int32_t bitflip = f0+(f1*2)+(f2*4)+(f3*8)+(f4*16)+(f5*32)+(f6*64)+(f7*128)+(f8*256)+(f9*512)+(f10*1024)+(f11*2048)+(f12*4096)+(f13*8192)+(f14*16384)+(f15*32768);
		int32_t signed_res = -(bitflip+1);
		printf("Converted integer is: ");
		printf("%d\n",signed_res);

	}else{
		printf("Converted integer is: ");
		printf("%d\n",case2uint);
	}

		break;
	case 2:
		printf("Converted unsigned integer is: %u\n",case2uint);
		break;
	case 3:
		printf("Converted float is: ");
		int32_t exp = 0;
		if(b14==1){exp=exp+16;}
		if(b13==1){exp=exp+8;}
		if(b12==1){exp=exp+4;}
		if(b11==1){exp=exp+2;}
		if(b10==1){exp=exp+1;}
		exp = exp -15;
		//find Float
		float f_value = 0.0;
		if(b9==1){f_value += 0.5;}
		if(b8==1){f_value += 0.25;}
		if(b7==1){f_value += 0.125;}
		if(b6==1){f_value += 0.0625;}
		if(b5==1){f_value += 0.03125;}
		if(b4==1){f_value += 0.015625;}
		if(b3==1){f_value += 0.0078125;}
		if(b2==1){f_value += 0.00390625;}
		if(b1==1){f_value += 0.001953125;}
		if(b0==1){f_value += 0.0009765625;}
		f_value = 1+f_value;

		if(b15 == 1){
		printf("-%f 2^%d\n",f_value,exp);
		}else if(b15 == 0){
		printf(" %f 2^%d\n",f_value,exp);
		}
		break;
	default:
		printf("Eror,Please select 1-3 :) \n");
		break;
	}


	return 0;
}

