41347053S 葉星澤

How to build a code
-please use 'make' command to execute all c file

How to execute a code
1)./hw0101
2)./hw0102
3)./hw0103
4)./hw0104
5)./hw0105


