#include<stdio.h>
#include<stdint.h>
int main(){
	int32_t num1,num2,num3;// user input
	char x,y,z; // user input
	int32_t sum; // user input
//	int32_t res_x,res_y,res_z;
	int32_t hundy,decix,unitz; //contian value of each number core value
        int32_t valx,valy,valz; //for calculate x,y,z
	int32_t rx,ry,rz;// value of x,y,z

	printf("Please enter the first operand : ");
	scanf("%d %c %d",&num1,&x,&num2);
	printf("Please enter the second operand: ");
	scanf(" %c %d %c",&y,&num3,&z);
	printf("Please enter the sum           : ");
	scanf("%d",&sum);

	if(num1/10 >=1 | num2/10 >=1){
		printf("%d%c%d is not an allowed operand.\n",num1,x,num2);
	}
	else{
		hundy = num1*100;
        	decix = num3*10;
        	unitz = num2*1;

	        valz = sum-unitz;
		valx = valz-decix;
		valy = valx-hundy;

		ry = valy/100;
		rx = (valx/10)%10;
		rz = valz%10;
 	//procesing
	printf("Ans: x = %d, y = %d, z = %d\n",rx,ry,rz);
	}
	return 0;
}
