#include<stdio.h>
int main(){
    printf("\033[31m[KIM]\nYou are sunlight and I moon\nJoined by the gods of fortune\nMidnight and high noon sharing the sky\nWe have been blessed , you and I\033[m\n");
    printf("\033[34m\n[CHRIS]\nYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\033[m\n");
    printf("\033[31m\n[KIM]\nOutside day starts to dawn\033[m\n");
    printf("\033[34m\n[CHRIS]\nYour moon still floats on high\033[m\n");
    printf("\033[31m\n[KIM]\nThe birds awake\033[m\n");
    printf("\033[34m\n[CHRIS]\nThe stars shine too\033[m\n");
    printf("\033[31m\n[KIM]\nMy hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n\nYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho’s Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\033[m\n");
    printf("\033[34m\n[CHRIS]\nI reach for you\033[m\n");
    printf("\033[32m\n[KIM & CHRIS]\nAnd we meet in the sky\033[m\n");
    printf("\033[31m\n[KIM]\nYou are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\033[m\n");
    printf("\033[32m\n[KIM & CHRIS]\nMade of\nSunlight\nMoonlight\033[m\n");
}