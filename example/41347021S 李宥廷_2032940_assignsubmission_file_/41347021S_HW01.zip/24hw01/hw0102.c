#include<stdio.h>
#include<stdint.h>
int main(){
    int32_t a=0,b=0,c=0,x=0,y=0,z=0,sum=0,te=0,hu=0,num=0;
    printf("Please enter the first  operand: ");
    scanf(" %dx%d",&a,&c);
    printf("Please enter the second operand: ");
    scanf(" y%dz",&b);
    printf("Please enter the sum           : ");
    scanf(" %d",&sum);
    num=a*100+b*10+c;
    if(sum<num){
        printf("Worng input, the sum should be larger than %d%d%d.\n",a,b,c);
    }else if(sum>num+999){
        printf("Wrong input, the sum should be smaller than %d.\n",num+999);
    }else if(sum>999&&sum<=num+999){
        if(sum%10<c){
            z=sum%10+10-c;
            te=1;
        }else{
            z=sum%10-c;
        }
        if(sum%100/10-te<b){
            x=sum%100/10+10-b-te;
            hu=1;
        }else{
            x=sum%100/10-b-te;
        }
        if(sum/100-hu<a){
            y=sum/100+10-a-hu;
        }else{
            y=sum/100-a-hu;
        }
        printf("Ans: x = %d, y = %d, z = %d\n",x,y,z);
    }else if(sum<1000&&sum>=0){
        if(sum%10<c){
            z=sum%10+10-c;
            te=1;
        }else{
            z=sum%10-c;
        }
        if(sum%100/10-te<b){
            x=sum%100/10+10-b-te;
            hu=1;
        }else{
            x=sum%100/10-b-te;
        }
        if(sum/100-hu<a){
            y=sum/100+10-a-hu;
        }else{
            y=sum/100-a-hu;
        }
        printf("Ans: x = %d, y = %d, z = %d\n",x,y,z);
    }
}