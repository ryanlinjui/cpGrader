#include<stdio.h>
#include<stdint.h>
int main(){
    int32_t ori=0,type=0,tmp=0;
    printf("Please input a hex: ");
    scanf("%x",&ori);
    printf("Please choose the output type(1:integer,2:unsigned integer,3:float):");
    scanf("%d",&type);
    uint8_t o1=0,o2=0,o3=0,o4=0,o5=0,o6=0,o7=0,o8=0,o9=0,o10=0,o11=0,o12=0,o13=0,o14=0,o15=0,o16=0,n;
    tmp=ori;
    if(ori>65535||ori<0){
        printf("Wrong input, the input should be between FFFF and 0");
    }else if(ori<65536&&ori>4095){
        n=1;
        o1=tmp/32768;
        if(o1){
            tmp-=32768;
        }
        o2=tmp/16384;
        if(o2){
            tmp-=16384;
        }
        o3=tmp/8192;
        if(o3){
            tmp-=8192;
        }
        o4=tmp/4096;
        if(o4){
            tmp-=4096;
        }
        o5=tmp/2048;
        if(o5){
            tmp-=2048;
        }
        o6=tmp/1024;
        if(o6){
            tmp-=1024;
        }
        o7=tmp/512;
        if(o7){
            tmp-=512;
        }
        o8=tmp/256;
        if(o8){
            tmp-=256;
        }
        o9=tmp/128;
        if(o9){
            tmp-=128;
        }
        o10=tmp/64;
        if(o10){
            tmp-=64;
        }
        o11=tmp/32;
        if(o11){
            tmp-=32;
        }
        o12=tmp/16;
        if(o12){
            tmp-=16;
        }
        o13=tmp/8;
        if(o13){
            tmp-=8;
        }
        o14=tmp/4;
        if(o14){
            tmp-=4;
        }
        o15=tmp/2;
        if(o15){
            tmp-=2;
        }
        o16=tmp;
        printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",ori,o1,o2,o3,o4,o5,o6,o7,o8,o9,o10,o11,o12,o13,o14,o15,o16);
    }else if(ori<4096&&ori>255){
        n=2;
        o1=tmp/2048;
        if(o1){
            tmp-=2048;
        }
        o2=tmp/1024;
        if(o2){
            tmp-=1024;
        }
        o3=tmp/512;
        if(o3){
            tmp-=512;
        }
        o4=tmp/256;
        if(o4){
            tmp-=256;
        }
        o5=tmp/128;
        if(o5){
            tmp-=128;
        }
        o6=tmp/64;
        if(o6){
            tmp-=64;
        }
        o7=tmp/32;
        if(o7){
            tmp-=32;
        }
        o8=tmp/16;
        if(o8){
            tmp-=16;
        }
        o9=tmp/8;
        if(o9){
            tmp-=8;
        }
        o10=tmp/4;
        if(o10){
            tmp-=4;
        }
        o11=tmp/2;
        if(o11){
            tmp-=2;
        }
        o12=tmp;
        printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",ori,o13,o14,o15,o16,o1,o2,o3,o4,o5,o6,o7,o8,o9,o10,o11,o12);
    }else if(ori<256&&ori>15){
        n=3;
        o1=tmp/128;
        if(o1){
            tmp-=128;
        }
        o2=tmp/64;
        if(o2){
            tmp-=64;
        }
        o3=tmp/32;
        if(o3){
            tmp-=32;
        }
        o4=tmp/16;
        if(o4){
            tmp-=16;
        }
        o5=tmp/8;
        if(o5){
            tmp-=8;
        }
        o6=tmp/4;
        if(o6){
            tmp-=4;
        }
        o7=tmp/2;
        if(o7){
            tmp-=2;
        }
        o8=tmp;
        printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",ori,o9,o10,o11,o12,o13,o14,o15,o16,o1,o2,o3,o4,o5,o6,o7,o8);
    }else if(ori<16&&ori>0){
        n=4;
        o1=tmp/8;
        if(o1){
            tmp-=8;
        }
        o2=tmp/4;
        if(o2){
            tmp-=4;
        }
        o3=tmp/2;
        if(o3){
            tmp-=2;
        }
        o4=tmp;
        printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",ori,o5,o6,o7,o8,o9,o10,o11,o12,o13,o14,o15,o16,o1,o2,o3,o4);
    }else if(ori==0){
        n=4;
        o1=0;o2=0;o3=0;o4=0;o5=0;o6=0;o7=0;o8=0;o9=0;o10=0;o11=0;o12=0;o13=0;o14=0;o15=0;o16=0;
        printf("Binary of %X is 0000 0000 0000 0000\n",ori);
    }
    uint8_t pn=o1;
    if(pn==1){
        pn==-1;
    }else if(pn==0){
        pn==1;
    }
    int32_t exponent=o2*16+o3*8+o4*4+o5*2+o6;
    float F=o7*0.5+o8*0.25+o9*0.125+o10*0.0625+o11*0.03125+o12*0.015625+o13*0.0078125+o14*0.00390625+o15*0.001953125+o16*0.0009765625;
    switch(type){
        case 1:
        switch(n){
            case 1:
            if(o1==1){
                printf("Converted integer is: %d\n",ori-65536);break;
            }else{
                printf("Converted integer is: %u\n",ori);break;
            }
            case 2:
            if(o1==1){
                printf("Converted integer is: %d\n",ori-4096);break;
            }else{
                printf("Converted integer is: %u\n",ori);break;
            }
            case 3:
            if(o1==1){
                printf("Converted integer is: %d\n",ori-512);break;
            }else{
                printf("Converted integer is: %u\n",ori);break;
            }
            case 4:
            if(o1==1){
                printf("Converted integer is: %d\n",ori-64);break;
            }else{
                printf("Converted integer is: %u\n",ori);break;
            }
        }
        break;
        case 2:
        printf("Converted unsigned integer is: %u\n",ori);
        break;
        case 3:
        if(exponent==31){
            if(F==0){
                if(pn==1){
                    printf("Converted float is: -INF\n");
                }else{
                    printf("Converted float is: +INF\n");
                }
            }else{
                printf("Converted float is: NAN\n");
            }
        }else if(exponent==0){
            if(pn==1){
                printf("Converted float is: -0.0\n");
            }else{
                printf("Converted float is: +0.0\n");
            }
        }else{
            printf("Converted float is: %f*2^%d\n",pn*(1+F),exponent-15);
        }
        break;
        default:
        printf("The output type should be 1, 2 or 3.\n");
        break;
    }
}