-My Student ID : 
    41347021S 李宥廷

-How to build my code :
    Just make the makefile and my homework files would be compiled successfully.

-How to execute my built programs :
    Open in terminal after making the makefile.

-Anything I want to notify the TAs :
    The answer to the bonus question is in the file "hw0106.txt".