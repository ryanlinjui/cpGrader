#include<stdio.h>
#include<stdint.h>
int main(){
    int32_t a,b,c,d,e,tmp=0;
    printf("Please enter 5 cards: ");
    scanf(" %d %d %d %d %d",&a,&b,&c,&d,&e);
    if(a>b){
        tmp=a;a=b;b=tmp;
    }
    if(b>c){
        tmp=b;b=c;c=tmp;
    }
    if(c>d){
        tmp=c;c=d;d=tmp;
    }
    if(d>e){
        tmp=d;d=e;e=tmp;
    }
    if(a>b){
        tmp=a;a=b;b=tmp;
    }
    if(b>c){
        tmp=b;b=c;c=tmp;
    }
    if(c>d){
        tmp=c;c=d;d=tmp;
    }
    if(a>b){
        tmp=a;a=b;b=tmp;
    }
    if(b>c){
        tmp=b;b=c;c=tmp;
    }
    if(a>b){
        tmp=a;a=b;b=tmp;
    }
    if(a<1||e>52){
        printf("Wrong input, the cards should be between 1 to 52.\n");
        return 0;
    }
    uint8_t ab,ac,ad,ae,bc,bd,be,cd,ce,de,s3,s2; //mn: m and n same number ; s3, s2: 3/2 same
    ab=(b==a+13||b==a+26||b==a+39);ac=(c==a+13||c==a+26||c==a+39);ad=(d==a+13||d==a+26||d==a+39);ae=(e==a+13||e==a+26||e==a+39);
    bc=(c==b+13||c==b+26||c==b+39);bd=(d==b+13||d==b+26||d==b+39);be=(e==b+13||e==b+26||e==b+39);cd=(d==c+13||d==c+26||d==c+39);
    ce=(e==c+13||e==c+26||e==c+39);de=(e==d+13||e==d+26||e==d+39);
    s3=ab&&bc||ab&&bd||ab&&be||ac&&cd||ac&&ce||ad&&de||bc&&cd||bc&&ce||bd&&de||cd&&de;
    s2==ab&&ac&&ad&&ae&&bc&&bd&&be&&cd&&cd&&de;
    if(a==b||a==c||a==d||a==e||b==c||b==d||b==e||c==d||c==e||d==e){
        printf("Wrong input, the cards shouldn't be the same.\n");
        return 0;
    }else if(e-a<13){
        if(((a==1||a==14||a==27||a==40)&&(e==13||e==26||e==39||e==52)&&(c==b+1&&d==b+2&&e==b+3))||(b==a+1&&c==a+2&&d==a+3&&e==a+4)){
            printf("Straight Flush\n");
        }else{
            printf("Flush\n");
        }
    }else if(ab&&bc&&cd||ab&&bc&&ce||ab&&bd&&de||ac&&cd&&de||bc&&cd&&de){
        printf("Four of a kind\n");
    }else if((ab&&bc&&!de||ab&&bd&&!ce||ab&&be&&!cd||ac&&cd&&!be||ac&&ce&&!bd||ad&&de&&!bc||bc&&cd&&!ae||bc&&ce&&!ad||bd&&de&&!ac||cd&&de&&!ab)){
        printf("Three of a kind\n");
    }else if(s3&&s2){
        printf("Full House\n");
    }else if((b==a+14||b==a+27||b==a+40)&&(c==a+15||c==a+28||c==a+41)&&(d==a+16||d==a+29||d==a+42)&&(e==a+17||e==a+30||e==a+43)&&(a!=13||a!=26||a!=39||a!=52)&&(b!=13||b!=26||b!=39||b!=52)&&(c!=13||c!=26||c!=39||c!=52)){
        printf("Straight\n");
    }else if(ab&&cd||ab&&ce||ab&&de||ac&&bd||ac&&be||ac&&de||ad&&bc||ad&&be||ad&&ce||ae&&bc||ae&&bd||ae&&cd||bc&&de||bd&&ce||be&&cd){
        printf("Two pair\n");
    }else if(s2){
        printf("One pair\n");
    }else{
        printf("High card\n");
    }
}