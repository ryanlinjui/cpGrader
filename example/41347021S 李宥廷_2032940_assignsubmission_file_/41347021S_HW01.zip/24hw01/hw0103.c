#include<stdio.h>
#include<stdint.h>
int main(){
    uint32_t ori=0;
    printf("Please enter an unsigned 16-bits integer: ");
    scanf("%u",&ori);
    int32_t o1=0,o2=0,o3=0,o4=0,o5=0,o6=0,tmp=ori;
    if(tmp>65535||tmp<0){
        printf("Wrong input, the input should be between 0 to 65535.\n");
    }else if(ori<65536&&ori>32767){
        o1=tmp%8;tmp/=8;o2=tmp%8;tmp/=8;o3=tmp%8;tmp/=8;o4=tmp%8;tmp/=8;o5=tmp%8;tmp/=8;o6=tmp%8;tmp/=8;
        printf("Before Flip:\n%hu_10 = %d%d%d%d%d%d_8\n",ori,o6,o5,o4,o3,o2,o1);
        printf("After Flip:\n%d_8 = %d_10\n",o1*100000+o2*10000+o3*1000+o4*100+o5*10+o6,o1*32768+o2*4096+o3*512+o4*64+o5*8+o6);
    }else if(ori<32768&&ori>4095){
        o1=tmp%8;tmp/=8;o2=tmp%8;tmp/=8;o3=tmp%8;tmp/=8;o4=tmp%8;tmp/=8;o5=tmp%8;tmp/=8;
        printf("Before Flip:\n%hu_10 = %d%d%d%d%d_8\n",ori,o5,o4,o3,o2,o1);
        printf("After Flip:\n%d_8 = %d_10\n",o1*10000+o2*1000+o3*100+o4*10+o5,o1*4096+o2*512+o3*64+o4*8+o5);
    }else if(ori<4096&&ori>511){
        o1=tmp%8;tmp/=8;o2=tmp%8;tmp/=8;o3=tmp%8;tmp/=8;o4=tmp%8;tmp/=8;
        printf("Before Flip:\n%hu_10 = %d%d%d%d_8\n",ori,o4,o3,o2,o1);
        printf("After Flip:\n%d_8 = %d_10\n",o1*1000+o2*100+o3*10+o4,o1*512+o2*64+o3*8+o4);
    }else if(ori<512&&ori>63){
        o1=tmp%8;tmp/=8;o2=tmp%8;tmp/=8;o3=tmp%8;tmp/=8;
        printf("Before Flip:\n%hu_10 = %d%d%d_8\n",ori,o3,o2,o1);
        printf("After Flip:\n%d_8 = %d_10\n",o1*100+o2*10+o3,o1*64+o2*8+o3);
    }else if(ori<64&&ori>7){
        o1=tmp%8;tmp/=8;o2=tmp%8;tmp/=8;
        printf("Before Flip:\n%hu_10 = %d%d_8\n",ori,o2,o1);
        printf("After Flip:\n%d_8 = %d_10\n",o1*10+o2,o1*8+o2);
    }else if(ori<8&&ori>=0){
        o1=tmp%8;tmp/=8;
        printf("Before Flip:\n%hu_10 = %d_8\n",ori,o1);
        printf("After Flip:\n%d_8 = %d_10\n",o1,o1);
    }
}