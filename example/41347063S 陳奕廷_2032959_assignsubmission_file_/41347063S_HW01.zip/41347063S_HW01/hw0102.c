#include<stdio.h>
#include<stdint.h>

int main()
{
	int32_t a=0,b=0,c=0,sum=0;
	int32_t x=0,y=0,z=0;
	printf("Please enter first operand:\n");
	scanf("%dx%d",&a,&b);
	printf("Please enter second operand:\n");
	scanf("\ny%dz",&c);
	printf("Please enter sum:\n");
	scanf("%d",&sum);
	if(a>9||b>9||c>9||a<0||b<0||c<0)
	{
	printf("error");
	return 0;
	}
        int32_t A = 100*a + b;
	int32_t	B = 10*c;
	if(sum%10-b<0)
	{
		z=sum%10+10-b;
		c=c+1;
	}
	else z=sum%10-b;
	printf("z=%d",z);
	if((sum/10)%10-c<0)
	{
		x=(sum/10)%10+10-c;
		a=a+1;
	}
	else x=(sum/10)%10-c;
	
	if((sum/100)%10-a<0)
	{
		y=(sum/100)%10+10-a;
	
	}
	else y=(sum/100)%10-a;

	A += 10*x;
	B += 100*y + z;
	
	if(A+B == sum)
	{
	printf("Ans: x = %d, y = %d, z = %d",x,y,z);
	
	}
return 0;
}
