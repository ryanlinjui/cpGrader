#include<stdio.h>
#include<stdint.h>

int main()
{
	int32_t c1=0,c2=0,c3=0,c4=0,c5=0; 
	printf("Please enter 5 cards:\n");
	scanf("%d %d %d %d %d",&c1,&c2,&c3,&c4,&c5);
	
	if(c1<1||c2<1||c3<1||c4<1||c5<1||c1>52||c2>52||c3>52||c4>52||c5>52)
	{
	printf("wrong input\n");
	return 0;
	}
	if(c1==c2||c2==c3||c3==c4||c4==c5||c1==c5||c1==c3||c1==c4||c2==c4||c5==c2||c5==c3)
	{
	printf("wrong input\n");
	return 0;
	}
	
	int32_t n1=0,n2=0,n3=0,n4=0,n5=0;
	n1=c1%13;
	n2=c2%13;
	n3=c3%13;
	n4=c4%13;
	n5=c5%13;
	
	int32_t f1=0,f2=0,f3=0,f4=0,f5=0;
	f1=(c1-n1)/13;
	f2=(c2-n2)/13;
	f3=(c3-n3)/13;
	f4=(c4-n4)/13;
	f5=(c5-n5)/13;
	
	int32_t spade=0,heart=0,diamond=0,club=0;
	if (f1==0)
	spade=spade+1;
	if (f2==0)
	spade=spade+1;
	if (f3==0)
	spade=spade+1;
	if (f4==0)
	spade=spade+1;
	if (f5==0)
	spade=spade+1;
	if (f1==1)
	heart=heart+1;
	if (f2==1)
	heart=heart+1;
	if (f3==1)
	heart=heart+1;
	if (f4==1)
	heart=heart+1;
	if (f5==1)
	heart=heart+1;
	if (f1==2)
	diamond=diamond+1;
	if (f2==2)
	diamond=diamond+1;
	if (f3==2)
	diamond=diamond+1;
	if (f4==2)
	diamond=diamond+1;
	if (f5==2)
	diamond=diamond+1;
	if (f1==3)
	club=club+1;
	if (f2==3)
	club=club+1;
	if (f3==3)
	club=club+1;
	if (f4==3)
	club=club+1;
	if (f5==3)
	club=club+1;
	
	int32_t h1=0,h2=0,h3=0,h4=0,h5=0,h6=0,h7=0,h8=0,h9=0,h10=0,hj=0,hq=0,hk=0;
	if (n1==1)
	h1=h1+1;
	if (n2==1)
	h1=h1+1;
	if (n3==1)
	h1=h1+1;
	if (n4==1)
	h1=h1+1;
	if (n5==1)
	h1=h1+1;
	if (n1==2)
	h2=h2+1;
	if (n2==2)
	h2=h2+1;
	if (n3==2)
	h2=h2+1;
	if (n4==2)
	h2=h2+1;
	if (n5==2)
	h2=h2+1;
	if (n1==3)
	h3=h3+1;
	if (n2==3)
	h3=h3+1;
	if (n3==3)
	h3=h3+1;
	if (n4==3)
	h3=h3+1;
	if (n5==3)
	h3=h3+1;
	if (n1==4)
	h4=h4+1;
	if (n2==4)
	h4=h4+1;
	if (n3==4)
	h4=h4+1;
	if (n4==4)
	h4=h4+1;
	if (n5==4)
	h4=h4+1;
	if (n1==5)
	h5=h5+1;
	if (n2==5)
	h5=h5+1;
	if (n3==5)
	h5=h5+1;
	if (n4==5)
	h5=h5+1;
	if (n5==5)
	h5=h5+1;
	if (n1==6)
	h6=h6+1;
	if (n2==6)
	h6=h6+1;
	if (n3==6)
	h6=h6+1;
	if (n4==6)
	h6=h6+1;
	if (n5==6)
	h6=h6+1;
	if (n1==7)
	h7=h7+1;
	if (n2==7)
	h7=h7+1;
	if (n3==7)
	h7=h7+1;
	if (n4==7)
	h7=h7+1;
	if (n5==7)
	h7=h7+1;
	if (n1==8)
	h8=h8+1;
	if (n2==8)
	h8=h8+1;
	if (n3==8)
	h8=h8+1;
	if (n4==8)
	h8=h8+1;
	if (n5==8)
	h8=h8+1;
	if (n1==9)
	h9=h9+1;
	if (n2==9)
	h9=h9+1;
	if (n3==9)
	h9=h9+1;
	if (n4==9)
	h9=h9+1;
	if (n5==9)
	h9=h9+1;
	if (n1==10)
	h10=h10+1;
	if (n2==10)
	h10=h10+1;
	if (n3==10)
	h10=h10+1;
	if (n4==10)
	h10=h10+1;
	if (n5==10)
	h10=h10+1;
	if (n1==11)
	hj=hj+1;
	if (n2==11)
	hj=hj+1;
	if (n3==11)
	hj=hj+1;
	if (n4==11)
	hj=hj+1;
	if (n5==11)
	hj=hj+1;
	if (n1==12)
	hq=hq+1;
	if (n2==12)
	hq=hq+1;
	if (n3==12)
	hq=hq+1;
	if (n4==12)
	hq=hq+1;
	if (n5==12)
	hq=hq+1;
	if (n1==0)
	hk=hk+1;
	if (n2==0)
	hk=hk+1;
	if (n3==0)
	hk=hk+1;
	if (n4==0)
	hk=hk+1;
	if (n5==0)
	hk=hk+1;
	
	int32_t four=0;
	
	if (h1==4||h2==4||h3==4||h4==4||h5==4||h6==4||h7==4||h8==4||h9==4||h10==4||hj==4||hq==4||hk==4)
	four=four+1;
	
	int32_t tri=0;
	
	if (h1==3||h2==3||h3==3||h4==3||h5==3||h6==3||h7==3||h8==3||h9==3||h10==3||hj==3||hq==3||hk==3)
	tri=tri+1;
	
	int32_t pair=0;
	
	if (h1==2||h2==2||h3==2||h4==2||h5==2||h6==2||h7==2||h8==2||h9==2||h10==2||hj==2||hq==2||hk==2)
	pair=pair+1;
	
	int32_t straight=0;
	
	if (h1==1&&h2==1&&h3==1&&h4==1&&h5==1)
	straight=straight+1;
	if (h2==1&&h3==1&&h4==1&&h5==1&&h6==1)
	straight=straight+1;
	if (h3==1&&h4==1&&h5==1&&h6==1&&h7==1)
	straight=straight+1;
	if (h4==1&&h5==1&&h6==1&&h7==1&&h8==1)
	straight=straight+1;
	if (h5==1&&h6==1&&h7==1&&h8==1&&h9==1)
	straight=straight+1;
	if (h6==1&&h7==1&&h8==1&&h9==1&&h10==1)
	straight=straight+1;
	if (h7==1&&h8==1&&h9==1&&h10==1&&hj==1)
	straight=straight+1;
	if (h8==1&&h9==1&&h10==1&&hj==1&&hq==1)
	straight=straight+1;
	if (h9==1&&h10==1&&hj==1&&hq==1&&hk==1)
	straight=straight+1;
	if (h10==1&&hj==1&&hq==1&&hk==1&&h1==1)
	straight=straight+1;
	
	int32_t full=0;
	if (spade==5||heart==5||diamond==5||club==5)
	full=full+1;
	
	
	if (full==1&&straight==1)
	printf("Straight Flush\n");
	
	if (four==1)
	printf("Four Of A Kind\n");
	
	if (tri==1&&pair==1)
	printf("Full House\n");
	
	if (full==1&&straight==0)
	printf("Flush\n");
	
	if (full==0&&straight==1)
	printf("Straight\n");
	
	if (tri==1&&pair==0)
	printf("Three Of A Kind\n");
	
	if (pair==2)
	printf("Two Pair\n");
	
	if (pair==1&&tri==0)
	printf("One Pair\n");
	
	if (pair==0&&tri==0&&four==0&&full==0&&straight==0)
	printf("High Card\n");
	
	return 0;
	
}
