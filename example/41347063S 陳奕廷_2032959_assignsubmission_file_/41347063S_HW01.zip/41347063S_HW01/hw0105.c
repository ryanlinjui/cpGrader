#include<stdio.h>
#include<stdint.h>

int main()

{

	int32_t in=0;
	
	printf("Please input a hex:\n");
	scanf("%X",&in);
	
	int32_t a=0,b=0,c=0,d=0,e=0,f=0,g=0,h=0,i=0,j=0,k=0,l=0,m=0,n=0,o=0,p=0;
	
	p=in%2;
	o=(in/2)%2;
	n=(in/4)%2;
	m=(in/8)%2;
	l=(in/16)%2;
	k=(in/32)%2;
	j=(in/64)%2;
	i=(in/128)%2;
	h=(in/256)%2;
	g=(in/512)%2;
	f=(in/1024)%2;
	e=(in/2048)%2;
	d=(in/4096)%2;
	c=(in/8192)%2;
	b=(in/16384)%2;
	a=(in/32768)%2;
	
	int32_t type=0;
	printf("Please choose the output type(1:integer,2:unsigned integer,3:float):\n");
	scanf("%d",&type);
	if(type!=1||type!=2||type!=3)
	{
	printf("wrong input\n");
	return 0;
	}
	switch(type){
		case 1:
			
			printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",in,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p);
			
			
			if(a==1)
			{
			a=-a+1;
			b=-b+1;
			c=-c+1;
			d=-d+1;
			e=-e+1;
			f=-f+1;
			g=-g+1;
			h=-h+1;
			i=-i+1;
			j=-j+1;
			k=-k+1;
			l=-l+1;
			m=-m+1;
			n=-n+1;
			o=-o+1;
			p=-p+1;
			
			int32_t inte=0;
			inte=-(a*32768+b*16384+c*8192+d*4096+e*2048+f*1024+g*512+h*256+i*128+j*64+k*32+l*16+m*8+n*4+o*2+p)+1;
			
			printf("Converted integer is: %d\n",inte);
			}
			else if (a==0)
			{
			printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",in,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p);
			printf("Converted integer is: %d\n",in);
			
			}
			break;
		case 2:
			
			printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",in,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p);
			printf("Converted unsign integer is: %d\n",in);
			
			break;
			
		case 3:
			
			if (a==0)
			{
			int32_t exp=0;
			exp=b*16+c*8+d*4+e*2+f;
			exp=exp-15;
			
			float fl=0;
			fl=(g*0.5+h*0.25+i*0.125+j*0.0625+k*0.03125+l*0.015625+m*0.0078125+n*0.00390625+o*0.001953125+p*0.0009765625);
			fl=fl+1;
			
			printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",in,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p);
			printf("Converted float is: %f*2^%d\n",fl,exp);
			}
			
			else
			{
			int32_t exp=0;
			exp=b*16+c*8+d*4+e*2+f;
			exp=exp-15;
			
			float fl=0;
			fl=(g*0.5+h*0.25+i*0.125+j*0.0625+k*0.03125+l*0.015625+m*0.0078125+n*0.00390625+o*0.001953125+p*0.0009765625);
			fl=-(fl+1);
			
			printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",in,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p);
			printf("Converted float is: %f*2^%d\n",fl,exp);
			}
			break;
	}
return 0;	
			
			
		
	
}
