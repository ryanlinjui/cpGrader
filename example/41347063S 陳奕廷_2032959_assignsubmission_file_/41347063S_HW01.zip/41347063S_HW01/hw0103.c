#include<stdio.h>
#include<stdint.h>

int main()
{
	int32_t n=0,a=0,b=0,c=0,d=0,e=0,f=0;
	printf("Please enter a unsignd 16-bits number:\n");
	scanf("%d",&n);
	f=n%8;
	e=(n/8)%8;
	d=(n/64)%8;
	c=(n/512)%8;
	b=(n/4096)%8;
	a=(n/32768)%8;
	int32_t eight=0;
	eight=f+10*e+100*d+1000*c+10000*b+100000*a;
	printf("Before Flip:\n");
	printf("%d_10 = %d_8\n",n,eight);
	
	int32_t eightf=0;
	eightf=a+10*b+100*c+1000*d+10000*e+100000*f;
	
	if (eightf%10==0)
	eightf=eightf/10;
	if (eightf%10==0)
	eightf=eightf/10;
	if (eightf%10==0)
	eightf=eightf/10;
	if (eightf%10==0)
	eightf=eightf/10;
	if (eightf%10==0)
	eightf=eightf/10;
	
	int32_t af=0,bf=0,cf=0,df=0,ef=0,ff=0;
	ff=eightf%10;
	ef=(eightf/10)%10;
	df=(eightf/100)%10;
	cf=(eightf/1000)%10;
	bf=(eightf/10000)%10;
	af=(eightf/100000)%10;
	
	int32_t tenf=0;
	tenf=ff+8*ef+64*df+512*cf+4096*bf+32768*af;
	printf("After Flip:\n");
	printf("%d_8 = %d_10\n",eightf,tenf);
	
	return 0;
}
