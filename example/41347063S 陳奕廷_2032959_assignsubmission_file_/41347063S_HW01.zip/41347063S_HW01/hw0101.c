#include<stdio.h>
int main(int argc,char **argv)
{
	printf("\033[31m[KIM]\n\033[0m");
	printf("\033[31mYou are sunlight and I moon\nJoined by the gods of fortune\n\033[0m");
	printf("\033[31mMidnight and high noon sharing the sky\nWe have been blessed , you and I\n\033[0m");
	printf("\n");
	printf("\033[34m[CHRIS]\nYou are here like a mystery\033[0m");
	printf("\033[34mI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\033[0m");
	printf("\n");
	printf("\033[31m[KIM]\n\033[0m");
	printf("\033[31mOutside day starts to dawn\n\033[0m");
	printf("\n");
	printf("\033[34m[CHRIS]\nYour moon still floats on high\n\033[0m");
	printf("\n");
	printf("\033[31m[KIM]\nThe birds awake\n\033[0m");
	printf("\n");
	printf("\033[34m[CHRIS]\nThe stars shine too\n\033[0m");
	printf("\n");
	printf("\033[31m[KIM]\nMy hands still shake\n\033[0m");
	printf("\033[31mSee upcoming pop shows\nGet tickets for your favorite artists\n\033[0m");
	printf("\n");
	printf("\033[31mYou might also like\nMy Boy Only Breaks His Favorite Toys\n\033[0m");
	printf("\033[31mTaylor Swift\nWho’s Afraid of Little Old Me?\n\033[0m");
	printf("\033[31mTaylor Swift\nGuilty as Sin?\nTaylor Swift\n\033[0m");
	printf("\n");
	printf("\033[34m[CHRIS]\nI reach for you\n\033[0m");
	printf("\n");
	printf("\033[32m[KIM & CHRIS]\nAnd we meet in the sky\n\033[0m");
	printf("\n");
	printf("\033[31m[KIM]\nYou are sunlight and I moon\n\033[0m");
	printf("\033[31mJoined here\nBrightening the sky with the flame of love\n\033[0m");
	printf("\n");
	printf("\033[32m[KIM & CHRIS]\nMade of\n\033[0m");
	printf("\033[32mSunlight\nMoonlight\n\033[0m");
return 0;
}
