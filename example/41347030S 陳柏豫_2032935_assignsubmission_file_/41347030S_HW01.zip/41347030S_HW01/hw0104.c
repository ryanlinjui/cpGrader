#include<stdio.h>
#include<stdint.h>

int main(){

	int32_t a=0;
	int32_t b=0;
	int32_t c=0;
	int32_t d=0;
	int32_t e=0;
	int32_t fa=0;
	int32_t fb=0;
	int32_t fc=0;
	int32_t fd=0;
	int32_t fe=0;
	int32_t na=0;
	int32_t nb=0;
	int32_t nc=0;
	int32_t nd=0;
	int32_t ne=0;
	int32_t t=0;
	
	printf("Please enter 5 cards: ");
	scanf("%d %d %d %d %d",&a, &b, &c, &d, &e);
	
	
	if( a>52 || b>52 || c>52 || d>52 || e>52 || a<0 || b<0 || c<0 || d<0 || e<0 )
	{printf("\nerror\n");
	
	return 0;
	}
	if( a==b && b==c && c==d && d==e && e==a )
	{printf("\nerror\n");
	
	return 0;
	}
	
	//花色
	fa = (a-1)/13;
	fb = (b-1)/13;
	fc = (c-1)/13;
	fd = (d-1)/13;
	fe = (e-1)/13;
	
	//數字
	na = (a-1)%13+1;
	nb = (b-1)%13+1;
	nc = (c-1)%13+1;
	nd = (d-1)%13+1;
	ne = (e-1)%13+1;
	
	//排序大到小
	if(na > nb){t = na; na = nb; nb = t;}
	if(nb > nc){t = nb; nb = nc; nc = t;}
	if(nc > nd){t = nc; nc = nd; nd = t;}
	if(nd > ne){t = nd; nd = ne; ne = t;}
	if(na > nb){t = na; na = nb; nb = t;}
	if(nb > nc){t = nb; nb = nc; nc = t;}
	if(nc > nd){t = nc; nc = nd; nd = t;}
	if(na > nb){t = na; na = nb; nb = t;}
	if(nb > nc){t = nb; nb = nc; nc = t;}
	if(na > nb){t = na; na = nb; nb = t;}
	
	//printf("\n%d,%d,%d,%d,%d",na,nb,nc,nd,ne);
	
	//同花順
	if(fa==fb && fb==fc && fc==fd && fd==fe && na+1==nb && nb+1==nc && nc+1==nd && nd+1==ne)
	printf("\nStraight flush\n");
	else if(fa==fb && fb==fc && fc==fd && fd==fe && na+9==nb && nb+1==nc && nc+1==nd && nd+1==ne)
	printf("\nStraight flush\n");
	
	//鐵支
	else if(na==nb && nb==nc && nc==nd)
	printf("\nFour of a kind\n");
	else if(nb==nc && nc==nd && nd==ne)
	printf("\nFour of a kind\n");
	
	//葫蘆
	else if(na==nb && nb==nc && nd==ne)
	printf("\nFull house\n");
	else if(na==nb && nc==nd && nd==ne)
	printf("\nFull house\n");
	
	//同花
	else if(fa==fb && fb==fc && fc==fd && fd==fe)
	printf("\nFlush\n");
	
	//順子
	else if(na+1==nb && nb+1==nc && nc+1==nd && nd+1==ne)
	printf("\nStraight\n");
	else if(na+9==nb && nb+1==nc && nc+1==nd && nd+1==ne)
	printf("\nStraight\n");
	
	//三條
	else if(na==nb && nb==nc)
	printf("\nThree of a kind\n");
	else if(nc==nd && nd==ne)
	printf("\nThree of a kind\n");
	else if(nb==nc && nc==nd)
	printf("\nThree of a kind\n");
	
	//2對子
	else if(na==nb && nc==nd)
	printf("\nTwo pair\n");
	else if(nb==nc && nd==ne)
	printf("\nTwo pair\n");
	else if(na==nb && nd==ne)
	printf("\nTwo pair\n");
	
	//對子
	else if(na==nb)
	printf("\nOne pair\n");
	else if(nb==nc)
	printf("\nOne pair\n");
	else if(nc==nd)
	printf("\nOne pair\n");
	else if(nd==ne)
	printf("\nOne pair\n");
	
	//散卡
	else
	printf("\nHigh card\n");
	
	
	return 0;

}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
