#include<stdio.h>
#include<stdint.h>

int main()
{

	uint32_t hex ;
	int32_t e ;
	int32_t result;
	int32_t n1 =0 ;
	int32_t n2 =0 ;
	int32_t n3 =0 ;
	int32_t n4 =0 ;
	int32_t n5 =0 ;
	int32_t n6 =0 ;
	int32_t n7 =0 ;
	int32_t n8 =0 ;
	int32_t n9 =0 ;
	int32_t n10 =0 ;
	int32_t n11 =0 ;
	int32_t n12 =0 ;
	int32_t n13 =0 ;
	int32_t n14 =0 ;
	int32_t n15 =0 ;
	int32_t n16 =0 ;
	float l; 
	
	printf("Please input a hex:");
	scanf("%x",&hex);
	printf("\nPlease choose the output type(1:integer,2:unsigned integer,3:float):");
	scanf("%d",&e );
	
	printf("Binary of %X is: ",hex );
	//四位
	int32_t a = (hex/4096)%16;
	printf("%d%d%d%d ",(a/8)%2 ,(a/4)%2 ,(a/2)%2 ,a%2 );
	
	//三位
	int32_t b = (hex/256)%16;
	printf("%d%d%d%d ",(b/8)%2 ,(b/4)%2 ,(b/2)%2 ,b%2 );
	
	//二位
	int32_t c = (hex/16)%16;
	printf("%d%d%d%d ",(c/8)%2 ,(c/4)%2 ,(c/2)%2 ,c%2 );
	
	//一位
	int32_t d = hex%16;
	printf("%d%d%d%d\n ",(d/8)%2 ,(d/4)%2 ,(d/2)%2 ,d%2 );
	
	n16 = (a/8)%2;
	n15 = (a/4)%2;
	n14 = (a/2)%2;
	n13 = a%2;
	n12 = (b/8)%2;
	n11 = (b/4)%2;
	n10 = (b/2)%2;
	n9  = b%2;
	n8  = (c/8)%2;
	n7  = (c/4)%2;
	n6  = (c/2)%2;
	n5  = c%2;
	n4  = (d/8)%2;
	n3  = (d/4)%2;
	n2  = (d/2)%2;
	n1  = d%2;
	//integer
	if(e == 1 && n16 == 0)
	{
	
	result = (((a/8)%2)*32768)+(((a/4)%2)*16384)+(((a/2)%2)*8192)+((a%2)*4096)+(((b/8)%2)*2048)+(((b/4)%2)*1024)+	(((b/2)%2)*512)+((b%2)*256)+(((c/8)%2)*128)+(((c/4)%2)*64)+(((c/2)%2)*32)+((c%2)*16)+(((d/8)%2)*8)+(((d/4)%2)*4)+(((d/2)%2)*2)+((d%2)*1);
	
	printf("Converted integer is: %d", result);
	
	return 0;
	}
	
	else if(e == 1 && n16 == 1)
	{
	hex = hex-1;
	
	if(n16 == 1)
	n16 = 0;
	else if(n16 == 0)
	n16 = 1;
	if(n15 == 1)
	n15 = 0;
	else if(n15 == 0)
	n15 = 1;
	if(n14 == 1)
	n14 = 0;
	else if(n14 == 0)
	n14 = 1;
	if(n13 == 1)
	n13 = 0;
	else if(n13 == 0)
	n13 = 1;
	if(n12 == 1)
	n12 = 0;
	else if(n12 == 0)
	n12 = 1;
	if(n11 == 1)
	n11 = 0;
	else if(n11 == 0)
	n11 = 1;
	if(n10 == 1)
	n10 = 0;
	else if(n10 == 0)
	n10 = 1;
	if(n9 == 1)
	n9 = 0;
	else if(n9 == 0)
	n9 = 1;
	if(n8 == 1)
	n8 = 0;
	else if(n8 == 0)
	n8 = 1;
	if(n7 == 1)
	n7 = 0;
	else if(n7 == 0)
	n7 = 1;
	if(n6 == 1)
	n6 = 0;
	else if(n6 == 0)
	n6 = 1;
	if(n5 == 1)
	n5 = 0;
	else if(n5 == 0)
	n5 = 1;
	if(n4 == 1)
	n4 = 0;
	else if(n4 == 0)
	n4 = 1;
	if(n3 == 1)
	n3 = 0;
	else if(n3 == 0)
	n3 = 1;
	if(n2 == 1)
	n2 = 0;
	else if(n2 == 0)
	n2 = 1;
	if(n1 == 1)
	n1 = 0;
	else if(n1 == 0)
	n1 = 1;
	
	result = (n16*32768)+(n15*16384)+(n14*8192)+(n13*4096)+(n12*2048)+(n11*1024)+(n10*512)+(n9*256)+(n8*128)+(n7*64)+(n6*32)+(n5*16)+(n4*8)+(n3*4)+(n2*2)+(n1*1)+1;
	
	printf("Converted integer is: -%d", result);
	
	return 0;
	}
	//unsigned integer
	else if(e == 2)
	{
	
	result = (((a/8)%2)*32768)+(((a/4)%2)*16384)+(((a/2)%2)*8192)+((a%2)*4096)+(((b/8)%2)*2048)+(((b/4)%2)*1024)+	(((b/2)%2)*512)+((b%2)*256)+(((c/8)%2)*128)+(((c/4)%2)*64)+(((c/2)%2)*32)+((c%2)*16)+(((d/8)%2)*8)+(((d/4)%2)*4)+(((d/2)%2)*2)+((d%2)*1);
	
	printf("Converted unsigned integer is: %d", result);
	
	return 0;
	}
	
	//float
	else if(e == 3 && n16 == 0)
	{
	result = (((a/8)%2)*32768)+(((a/4)%2)*16384)+(((a/2)%2)*8192)+((a%2)*4096)+(((b/8)%2)*2048)+(((b/4)%2)*1024)+	(((b/2)%2)*512)+((b%2)*256)+(((c/8)%2)*128)+(((c/4)%2)*64)+(((c/2)%2)*32)+((c%2)*16)+(((d/8)%2)*8)+(((d/4)%2)*4)+(((d/2)%2)*2)+((d%2)*1);
	l = result;
	printf("Converted float is: %e", l);
	
	return 0;
	}
	else if(e ==3 && n16 == 1)
	{
	hex = hex-1;
	
	if(n16 == 1)
	n16 = 0;
	else if(n16 == 0)
	n16 = 1;
	if(n15 == 1)
	n15 = 0;
	else if(n15 == 0)
	n15 = 1;
	if(n14 == 1)
	n14 = 0;
	else if(n14 == 0)
	n14 = 1;
	if(n13 == 1)
	n13 = 0;
	else if(n13 == 0)
	n13 = 1;
	if(n12 == 1)
	n12 = 0;
	else if(n12 == 0)
	n12 = 1;
	if(n11 == 1)
	n11 = 0;
	else if(n11 == 0)
	n11 = 1;
	if(n10 == 1)
	n10 = 0;
	else if(n10 == 0)
	n10 = 1;
	if(n9 == 1)
	n9 = 0;
	else if(n9 == 0)
	n9 = 1;
	if(n8 == 1)
	n8 = 0;
	else if(n8 == 0)
	n8 = 1;
	if(n7 == 1)
	n7 = 0;
	else if(n7 == 0)
	n7 = 1;
	if(n6 == 1)
	n6 = 0;
	else if(n6 == 0)
	n6 = 1;
	if(n5 == 1)
	n5 = 0;
	else if(n5 == 0)
	n5 = 1;
	if(n4 == 1)
	n4 = 0;
	else if(n4 == 0)
	n4 = 1;
	if(n3 == 1)
	n3 = 0;
	else if(n3 == 0)
	n3 = 1;
	if(n2 == 1)
	n2 = 0;
	else if(n2 == 0)
	n2 = 1;
	if(n1 == 1)
	n1 = 0;
	else if(n1 == 0)
	n1 = 1;
	
	result = (n16*32768)+(n15*16384)+(n14*8192)+(n13*4096)+(n12*2048)+(n11*1024)+(n10*512)+(n9*256)+(n8*128)+(n7*64)+(n6*32)+(n5*16)+(n4*8)+(n3*4)+(n2*2)+(n1*1)+1;
	l = result;
	printf("Converted float is: -%e", l);
	
	return 0;
	}
	return 0;
}
