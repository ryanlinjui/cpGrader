#include<stdio.h>
#include<stdint.h>

int main()
{

	int32_t dec = 0;
	int32_t oct = 0;
	int32_t roct = 0;
	int32_t roct_to_dec = 0;
	{
	printf("Please enter an unsigned 16-bits number:");
	scanf("%d",&dec);
	
	{
	oct += (dec/8/8/8/8/8)%8*100000;
	oct += (dec/8/8/8/8)%8*10000;
	oct += (dec/8/8/8)%8*1000;
	oct += (dec/8/8)%8*100;
	oct += (dec/8)%8*10;
	oct += dec%8;
	
	{
	if(180000> oct && oct >=100000)
	{
	roct += (oct%10)*100000;
	roct += ((oct/10)%10)*10000;
	roct += ((oct/100)%10)*1000;
	roct += ((oct/1000)%10)*100;
	roct += ((oct/10000)%10)*10;
	roct += (oct/100000)%10;
	}
	else if(100000> oct && oct >=10000)
	{
	roct += (oct%10)*10000;
	roct += ((oct/10)%10)*1000;
	roct += ((oct/100)%10)*100;
	roct += ((oct/1000)%10)*10;
	roct += (oct/10000)%10;
	}
	else if(10000> oct && oct >=1000)
	{
	roct += (oct%10)*1000;
	roct += ((oct/10)%10)*100;
	roct += ((oct/100)%10)*10;
	roct += (oct/1000)%10;
	}
	else if(1000> oct && oct >=100)
	{
	roct += (oct%10)*100;
	roct += ((oct/10)%10)*10;
	roct += (oct/100)%10;
	}
	else if(100> oct && oct >=10)
	{
	roct += (oct%10)*10;
	roct += (oct/10)%10;
	}
	else if(10> oct && oct >=0)
	{
	roct += oct%10;
	}
	}

	
	{
	roct_to_dec += (roct/100000)*35768;
	roct_to_dec += ((roct/10000)%10)*4096;
	roct_to_dec += ((roct/1000)%10)*512;
	roct_to_dec += ((roct/100)%10)*64;
	roct_to_dec += ((roct/10)%10)*8;
	roct_to_dec += roct%10;
	
	{
	printf("\nBefore Flip:");
	printf("\n%d_10 = %d_8", dec, oct);
	printf("\nAfter Flip:");
	printf("\n%d_8 = %d_10\n", roct, roct_to_dec);    
	
	}
	return 0;
}
}
}
}
