#include<stdio.h>
#include<stdint.h>

int main()

{
	int32_t a = 0;
	int32_t b = 0;
	int32_t c = 0;
	int32_t d = 0;
	int32_t x = 0;
	int32_t y = 0;
	int32_t z = 0;
	
	printf("Please enter the first operand:\n");
	scanf("%dx%d", &a, &b);
		if(a >= 10)
		{
		printf("error messege\n");
		return 0;
		}
			if(b >= 10)
			{
			printf("error messege\n");
			return 0;
			}
	printf("Please enter the second operand:\n");
	scanf("\ny%dz", &c);
		if(c >= 10)
		{
		printf("error messege\n");
		return 0;
		}
	printf("Please enter the sum:\n");
	scanf("%d", &d);
	
	//d-100*a-10*c-b = 100*y+10*x+z
	
	z = (d-100*a-10*c-b)%10;	
	x = ((d-100*a-10*c-b-z)%100)/10;	
	y = ((d-100*a-10*c-b-z-x)%1000)/100;
	
	printf("\nAns: x=%d,y=%d,z=%d\n", x,y,z);
	
	return 0;
}
