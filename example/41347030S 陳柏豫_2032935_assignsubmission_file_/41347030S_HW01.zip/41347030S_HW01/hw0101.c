#include<stdio.h>

//RED   \033[1;31m   
//BLUE  \033[1;34m
//GREEN \033[1;32m
//blank \033[0m

int main(){
	//RED
	printf("\033[1;31m[KIM]\n");
	printf("You are sunlight and I moon\n");
	printf("Joined by the gods of fortune\n");
	printf("Midnight and high noon sharing the sky\n");
	printf("We have been blessed you and I\033[0m\n\n");
	//BLUE
	printf("\033[1;34m[CHRIS]\n");
	printf("You are here like a mystery\n");
	printf("I´m form a world that´s so different from all that you are\n");
	printf("How in the light in one night did we come so far?\033[0m\n\n");
	//RED
	printf("\033[1;31m[KIM]\n");
	printf("Outside day starts to dawn\033[0m\n\n");
	//BLUE
	printf("\033[1;34m[CHRIS]\n");
	printf("Your moon still floats on high\033[0m\n\n");
	//RED
	printf("\033[1;31m[KIM]\n");
	printf("The birds awake\033[0m\n\n");
	//BLUE
	printf("\033[1;34m[CHRIS]\n");
	printf("The stars shine too\033[0m\n\n");
	//RED
	printf("\033[1;31m[KIM]\n");
	printf("My hands still shake\n");
	printf("See upcoming pop shows\n");
	printf("Get tickets for your favorite artists\n\n");
	
	printf("You might also like\n");
	printf("My Boy Only Breaks His Favorite Toys\n");
	printf("Taylor swift\n");
	printf("Who´s Afraid of Little Old Me?\n");
	printf("Taylor swift\n");
	printf("Guilty as Sin\n");
	printf("Taylor swift\033[0m\n\n");
	//BLUE
	printf("\033[1;34m[CHRIS]\n");
	printf("I reach for you\n\n");
	//GREEN
	printf("\033[1;32m[KIM & CHRIS]\n");
	printf("And we meet in the sky\033[0m\n\n");
	//RED
	printf("\033[1;31m[KIM]\n");
	printf("You are sunlight and I moon\n");
	printf("Joined here\n");
	printf("Brightening the sky with the flames of love\033[0m\n\n");
	//GREEN
	printf("\033[1;32m[KIM & CHRIS]\n");
	printf("Made of\n");
	printf("Sunlight\n");
	printf("Moonlight\033[0m\n");
	
		return 0;
}

