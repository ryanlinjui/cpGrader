#include <stdio.h>

int main() {
    
    int a1, a2, a3, a4, a5;
    int b1, b2, b3, b4, b5;
    
    printf("Please enter 5 cards:\n");
    scanf("%d%d%d%d%d", &a1, &a2, &a3, &a4, &a5);
    
    if(a1 >= 1 && a1 <= 13)
    {
    	//printf("a1是黑桃\n");
    	b1 = 1;
    	//printf("a1=%d\n", a1);
    }
    else if(a1 >= 14 && a1 <= 26)
    {
    	//printf("a1是愛心\n");
    	b1 = 2;
    	a1=a1-13;
    	//printf("a1=%d\n", a1);
    }
    	else if(a1 >= 27 && a1 <= 39)
    	{
    		//printf("a1是菱形\n");
    		b1 = 3;
    		a1=a1-26;
    		//printf("a1=%d\n", a1);
    	}
    		else if(a1 >= 40 && a1 <= 52)
    		{
    			//printf("a1是葉子\n");
    			b1 = 4;
    			a1=a1-39;
    			//printf("a1=%d\n", a1);
    		}
    		
    if(a2 >= 1 && a2 <= 13)
    {
    	//printf("a2是黑桃\n");
    	b2 = 1;
    	//printf("a2=%d\n", a2);
    }
    else if(a2 >= 14 && a2 <= 26)
    {
    	//printf("a2是愛心\n");
    	b2 = 2;
    	a2=a2-13;
    	//printf("a2=%d\n", a2);
    }
    	else if(a2 >= 27 && a2 <= 39)
    	{
    		//printf("a2是菱形\n");
    		b2 = 3;
    		a2=a2-26;
    		//printf("a2=%d\n", a2);
    	}
    		else if(a2 >= 40 && a2 <= 52)
    		{
    			//printf("a2是葉子\n");
    			b2 = 4;
    			a2=a2-39;
    			//printf("a2=%d\n", a2);
    		}
    		
    if(a3 >= 1 && a3 <= 13)
    {
    	//printf("a3是黑桃\n");
    	b3 = 1;
    	//printf("a3=%d\n", a3);
    }
    else if(a3 >= 14 && a3 <= 26)
    {
    	//printf("a3是愛心\n");
    	b3 = 2;
    	a3=a3-13;
    	//printf("a3=%d\n", a3);
    }
    	else if(a3 >= 27 && a3 <= 39)
    	{
    		//printf("a3是菱形\n");
    		b3 = 3;
    		a3=a3-26;
    		//printf("a3=%d\n", a3);
    	}
    		else if(a3 >= 40 && a3 <= 52)
    		{
    			//printf("a3是葉子\n");
    			b3 = 4;
    			a3=a3-39;
    			//printf("a3=%d\n", a3);
    		}
    		
    if(a4 >= 1 && a4 <= 13)
    {
    	//printf("a4是黑桃\n");
    	b4 = 1;
    	//printf("a4=%d\n", a4);
    }
    else if(a4 >= 14 && a4 <= 26)
    {
    	//printf("a4是愛心\n");
    	b4 = 2;
    	a4=a4-13;
    	//printf("a4=%d\n", a4);
    }
    	else if(a4 >= 27 && a4 <= 39)
    	{
    		//printf("a4是菱形\n");
    		b4 = 3;
    		a4=a4-26;
    		//printf("a4=%d\n", a4);
    	}
    		else if(a4 >= 40 && a4 <= 52)
    		{
    			//printf("a4是葉子\n");
    			b4 = 4;
    			a4=a4-39;
    			//printf("a4=%d\n", a4);
    		}
    		
    if(a5 >= 1 && a5 <= 13)
    {
    	//printf("a5是黑桃\n");
    	b5 = 1;
    	//printf("a5=%d\n", a5);
    }
    else if(a5 >= 14 && a5 <= 26)
    {
    	//printf("a5是愛心\n");
    	b5 = 2;
    	a5=a5-13;
    	//printf("a5=%d\n", a5);
    }
    	else if(a5 >= 27 && a5 <= 39)
    	{
    		//printf("a5是菱形\n");
    		b5 = 3;
    		a5=a5-26;
    		//printf("a5=%d\n", a5);
    	}
    		else if(a5 >= 40 && a5 <= 52)
    		{
    			//printf("a5是葉子\n");
    			b5 = 4;
    			a5=a5-39;
    			//printf("a5=%d\n", a5);
    		}
    int c;
    	
    if (a1 > a2) { c = a1; a1 = a2; a2 = c; }
    if (a2 > a3) { c = a2; a2 = a3; a3 = c; }
    if (a3 > a4) { c = a3; a3 = a4; a4 = c; }
    if (a4 > a5) { c = a4; a4 = a5; a5 = c; }
    
    if (a1 > a2) { c = a1; a1 = a2; a2 = c; }
    if (a2 > a3) { c = a2; a2 = a3; a3 = c; }
    if (a3 > a4) { c = a3; a3 = a4; a4 = c; }
    
    if (a1 > a2) { c = a1; a1 = a2; a2 = c; }
    if (a2 > a3) { c = a2; a2 = a3; a3 = c; }
    
    if (a1 > a2) { c = a1; a1 = a2; a2 = c; }
    	
    	//printf("排序結果: %d, %d, %d, %d, %d\n", a1, a2, a3, a4, a5);
    				
    if(b1 == b2 && b2 == b3 && b3 == b4 && b4 == b5)//如果全同花色
    {
    	
    	
    	if(a1+1 == a2 &&  a2+1 == a3 && a3+1 == a4 && a4+1 == a5 )//如果是順號
    	{
    		printf("straight Flush\n");//輸出同花順
    	}
    	else{ printf("Flush\n");}//否則輸出同花
    }
    else
    {
    	if(a1 == a2 || a1 == a3 || a1 == a4 || a1 == a5 || a2 == a3 || a2 == a4|| a2 == a5 || a3 == a4 || a3 == a5 || a4 == a5)//如果有相同的點
    	{
    		if(a1 == a2 && a2 == a3 && a3 == a4)//如果有前四個相同的點（已經由小道大排序過）
    		{
    			printf("Four of a kind\n");//輸出鐵支
    		}
    		else if(a2 == a3 && a3 == a4 && a4 == a5)
    		{
    			printf("Four of a kind\n");//輸出鐵支
    		}
    		else if(a1 == a2 && a2 == a3)
    		{
    			printf("Three of a kind\n");
    		}
    		else if(a2 == a3 && a3 == a4)
    		{
    			printf("Three of a kind\n");
    		}
    		else if(a3 == a4 && a4 == a5)
    		{
    			printf("Three of a kind\n");
    		}
    		else if(a1 == a2)
    		{
    			if(a3 == a4 && a4 == a5)
    			{
    				printf("Full house\n");
    			}
    			else if(a3 == a4 && a4 != a5)
    			{
    				printf("Two pair\n");
    			}
    			else if(a4 == a5 && a4 != a3)
    			{
    				printf("Two pair\n");
    			}
    			else if(a3 != a4 && a4 != a5)
    			{
    				printf("One pair\n");
    			}
    		}
    		else if(a4 == a5)
    		{
    			if(a1 == a2 && a2 == a3)
    			{
    				printf("Full house\n");
    			}
    			else if(a2 == a3 && a2 != a1)
    			{
    				printf("Two pair\n");
    			}
    			else if(a2 == a1 && a2 != a3)
    			{
    				printf("Two pair\n");
    			}
    			else if(a1 != a2 && a2 != a3)
    			{
    				printf("One pair\n");
    			}
    			
    		}
    		else if(a2 == a3 && a1 != a4 && a4 != a5 && a5 != a1)
    		{
    			printf("One pair\n");
    		}
    		else if(a3 == a4 && a1 != a2 && a2 != a5 && a5 != a1)
    		{
    			printf("One pair\n");
    		}
    		
    	
    	
     			
     	}
     	else if(a1+1 == a2 &&  a2+1 == a3 && a3+1 == a4 && a4+1 == a5 )//如果是順號
    	{
    		printf("straight\n");//輸出straight
    	}
    	else
    	{
    		printf("High card");
    	}
     		
     } 
     		
     	
     	
   
    	
    
    return 0;
}
