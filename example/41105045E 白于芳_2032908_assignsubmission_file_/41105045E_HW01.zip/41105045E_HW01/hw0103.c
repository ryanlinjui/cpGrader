#include <stdio.h>
#include <stdint.h>
int main()
{
	unsigned int num = 0;
	int num_8 = 0;
	int num1;
	int numr;
	int numc = 0;
	int a = 1;
	
	printf("Please enter an unsigned 16-bits number:\n");
	scanf("%d", &num);
	num1 = num;
	printf("Before Flip:\n");
	printf("%d_10=", num);
	
	if ( num >= 8)
	{
		
		numr = num % 8;//找到num的餘數 
		num_8 = num_8 + ( num % 8 ) * a;//將找到的餘數算進新的八進位
		numc = numc *10 + ( num % 8 ) ;
		num = num / 8;//重新設定num的值
		a=a * 10;
		
		if ( num >= 8 )
		{
			numr = num % 8;
			num_8 = num_8 + ( num % 8 ) * a;
			numc = numc * 10 + ( num % 8 );
			num = num / 8;
			a=a * 10;
			
			if(num >= 8 )
			{
				numr = num % 8;
				num_8 = num_8 + ( num % 8 ) * a;
				numc = numc  * 10 + ( num % 8 );
				num = num / 8;
				a=a * 10;
				
				if(num >= 8 )
				{
					numr = num % 8;
					num_8 = num_8 + ( num % 8 ) * a;
					numc = numc * 10 + ( num % 8 );
					num = num / 8;
					a=a * 10;
					
					if(num >= 8 )
					{
						numr = num % 8;
						num_8 = num_8 + ( num % 8 ) * a;
						numc = numc * 10 + ( num % 8 );
						num = num / 8;
						a=a * 10;
						
						if(num >= 8 )
						{
							numr = num % 8;
							num_8 = num_8 + ( num % 8 ) * a;
							numc = numc * 10 + ( num % 8 );
							num = num / 8;
						}
						
					}
						
				}	
			
			}
			
		}
		
	}
	if( num < 8 )
	{
		 numr = num % 8;
		 num_8 = num_8 + ( num % 8 ) * a;
		 numc = numc * 10 + ( num % 8 );
		 num = num / 8;
		 printf("%d_8\n", num_8);
	}
	
	printf("After Flip:\n");
	printf("%d_8=", numc);
	int numcq=0;
	int numcr1;
	int numcr2;
	int numcr3;
	int numcr4;
	int numcr5;
	int numcr6;
	int num_10;
	
	if(numc > 0 )
	{
		numcr1 = numc % 10;//中間轉換數除以10的餘數存到中間數餘數1（numcr1）
		//printf("numcr1=%d\n", numcr1);
		numc = numc / 10;//中間轉換數除以10的商數
		//printf("numc=%d\n", numc);
	}
		if(numc > 0 )
		{
			numcr2 = numc % 10;
			//printf("numcr2=%d\n", numcr2);
			numc = numc / 10;
			//printf("numc=%d\n", numc);
		}
			if(numc > 0 )
			{
				numcr3 = numc % 10;
				//printf("numcr3=%d\n", numcr3);
				numc = numc / 10;
				//printf("numc=%d\n", numc);
			}
				if(numc > 0 )
				{
					numcr4 = numc % 10;
					//printf("numcr4=%d\n", numcr4);
					numc = numc / 10;
					//printf("numc=%d\n", numc);
				}
					if(numc > 0 )
					{
						numcr5 = numc % 10;
						//printf("numcr5=%d\n", numcr5);
						numc = numc / 10;
						//printf("numcq=%d\n", numc);
					}
						if(numc > 0 )
						{
							numcr6 = numc % 10;
							//printf("numcr6=%d\n", numcr6);
							numc = numc / 10;
							//printf("numcq=%d\n", numc);
						}
						num_10 = numcr1 * 1 + numcr2 * 8  + numcr3 * 8 * 8  + numcr4 * 8 * 8 * 8  + numcr5 * 8 * 8 * 8 * 8 + numcr6 * 8 * 8 * 8 * 8 * 8 ;
	printf("%d_10\n", num_10);
	
	
	

	 
	 
	 
	 
	 return 0;
	 
}




