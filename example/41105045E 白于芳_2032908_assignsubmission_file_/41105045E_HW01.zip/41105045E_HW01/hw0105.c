#include <stdio.h>

int main() 
{
    int num;
    int ot;
    
    printf("Please input a hex:");
    scanf("%x", &num);
    printf("%x\n", num);
    //printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
    //scanf("%d\n", &ot);
    
    
    //計算十進位轉二進位
    int r=0;
    int num_201 = 0;//設一個每四位一組的二進位從右到左的第一組
    int num_202 = 0;
    int num_203 = 0;
    int num_204 = 0;
    int r1, r2, r3, r4;
    int num_2 = 0;//一個新的二進位數
    int a=1;//幫助新的二進位數組成
    int w1=0, w2=0, w3=0, w4=0;
    
        
    if(num > 0 )
    {
    	num_201 = num_201 + (num % 2) * 1;
    	num_2 = num_2 + (num % 2) * a;
    	num = num / 2;
    	a = a *10;
    	printf("num_201=%d, num_2=%d, num=%d\n", num_201, num_2, num);
    	
    }
    	if(num > 0 )
    	{
    		num_201 = num_201 + (num % 2) *10;
    		num_2 = num_2 + (num % 2) * a;
    		r1 = num % 2;
    		if(r1 = 0)
    		{
    			w1 = w1 + 1;
    		}
    		num = num / 2;
    		a = a * 10;
    		printf("num_201=%0*d, num_2=%d, num=%d\n", w1, num_201, num_2, num);
    	
    	}
    		if(num > 0 )
    		{
    			num_201 = num_201 + (num % 2) *100;
    			num_2 = num_2 + (num % 2) * a;
    			r1 = num % 2;
    			if(r1 = 0)
    			{
    				w1 = w1 + 1;
    			}
    			num = num / 2;
    			a = a * 10;
    			printf("num_201=%0*d, num_2=%d, num=%d\n", w1, num_201, num_2, num);
    	
    		}
    			if(num > 0 )
    			{
    				num_201 = num_201 + (num % 2) *1000;
    				num_2 = num_2 + (num % 2) * a;
    				r1 = num % 2;
    				if(r1 = 0)
    					{
    						w1 = w1 + 1;
    					}
    				num = num / 2;
    				a = a * 10; 
    				printf("num_201=%0*d, num_2=%d, num=%d\n", w1, num_201, num_2, num);
    				
    	
    			}
    				if(num > 0 )
    				{
    					num_202 = num_202 + (num % 2) *1;
    					num_2 = num_2 + (num % 2) * a;
    					num = num / 2;
    					a = a * 10;
    					printf("num_202=%d, num_2=%d, num=%d\n", num_202, num_2, num);
    	
    				}
    					if(num > 0 )
    					{
    						num_202 = num_202 + (num % 2) *10;
    						num_2 = num_2 + (num % 2) * a;
    						r2 = num % 2;
    						if(r2 = 0)
    							{
    								w2 = w2 + 1;
    							}
    						num = num / 2;
    						a = a * 10;
    						printf("num_202=%0*d, num_2=%d, num=%d\n", w2, num_202, num_2, num);
    	
    					}
    						if(num > 0 )
    						{
    							num_202 = num_202 + (num % 2) *100;
    							num_2 = num_2 + (num % 2) * a;
    							r2 = num % 2;
    							if(r2 = 0)
    								{
    									w2 = w2 + 1;
    								}
    							num = num / 2;
    							a = a * 10;
    							printf("num_202=%0*d, num_2=%d, num=%d\n", w2, num_202, num_2, num);
    	
    						}
    							if(num > 0 )
    							{
    								num_202 = num_202 + (num % 2) *1000;
    								num_2 = num_2 + (num % 2) * a;
    								r2 = num % 2;
    								if(r2 = 0)
    									{
    										w2 = w2 + 1;
    									}
    								num = num / 2;
    								a = a * 10;
    								printf("num_202=%0*d, num_2=%d, num=%d\n", w2, num_202, num_2, num);
    	
    							}
    								if(num > 0 )
    								{
    									num_203 = num_203 + (num % 2) *1;
    									num_2 = num_2 + (num % 2) * a;
    									num = num / 2;
    									a = a * 10;
    									printf("num_203=%d, num_2=%d, num=%d\n", num_203, num_2, num);
    	
    								}
    									if(num > 0 )
    									{
    										num_203 = num_203 + (num % 2) *10;
    										num_2 = num_2 + (num % 2) * a;
    										r3 = num % 2;
    										if(r3 = 0)
    										{
    											w3 = w3 + 1;
    										}
    										num = num / 2;
    										a = a * 10;
    										printf("num_203=%0*d, num_2=%d, num=%d\n", w3, num_203, num_2, num);
    	
    									}
    										if(num > 0 )
    										{
    											num_203 = num_203 + (num % 2) *100;
    											num_2 = num_2 + (num % 2) * a;
    											r3 = num % 2;
    											if(r3 = 0)
    											{
    												w3 = w3 + 1;
    											}
    											num = num / 2;
    											a = a * 10;
    											printf("num_203=%0*d, num_2=%d, num=%d\n", w3, num_203, num_2, num);
    	
    										}
    											if(num > 0 )
    											{
    												num_203 = num_203 + (num % 2) *1000;
    												num_2 = num_2 + (num % 2) * a;
    												r3 = num % 2;
    												if(r3 = 0)
    												{
    													w3 = w3 + 1;
    												}
    												num = num / 2;
    												a = a * 10;
    												printf("num_203=%0*d, num_2=%d, num=%d\n", w3, num_203, num_2, num);
    	
    											}
    												if(num > 0 )
    												{
    													num_204 = num_204 + (num % 2) *1;
    													num_2 = num_2 + (num % 2) * a;
    													num = num / 2;
    													a = a * 10;
    													printf("num_204=%d, num_2=%d, num=%d\n", num_204, num_2, num);
    												}
    													if(num > 0 )
    													{
    														num_204 = num_204 + (num % 2) *10;
    														num_2 = num_2 + (num % 2) * a;
    														r4 = num % 2;
    														if(r4 = 0)
    														{
    															w4 = w4 + 1;
    														}
    														num = num / 2;
    														a = a * 10;
    														printf("num_204=%0*d, num_2=%d, num=%d\n", w4, num_204, num_2, num);
    													}
    														if(num > 0 )
    														{
    															num_204 = num_204 + (num % 2) *100;
    															num_2 = num_2 + (num % 2) * a;
    															r4 = num % 2;
    															if(r4 = 0)
    															{
    																w4 = w4 + 1;
    															}
    															num = num / 2;
    															a = a * 10;
    															printf("num_204=%0*d, num_2=%d, num=%d\n", w4, num_204, num_2, num);
    														}
    															if(num > 0 )
    															{
    																num_204 = num_204 + (num % 2) *100;
    																num_2 = num_2 + (num % 2) * a;
    																r4 = num % 2;
    																if(r4 = 0)
    																{
    																	w4 = w4 + 1;
    																}
    																num = num / 2;
    																a = a * 10;
    																printf("num_204=%0*d, num_2=%d, num=%d\n", w4, num_204, num_2, num);
    															}
    	
    											
    

    return 0;
}
