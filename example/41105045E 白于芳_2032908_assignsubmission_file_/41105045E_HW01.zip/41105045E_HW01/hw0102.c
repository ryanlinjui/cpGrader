#include <stdio.h>

int main()
{
	int num_0101, num_0103, num_0202;
	char x, y, z;
	int sum;
	int sum1, sum2, sum3, sum4;
	
	printf("Please enter the first operand:\n");
	scanf("%d%c%d", &num_0101, &x, &num_0103);
	printf("Please enter the second operand:\n");
	scanf(" %c%d%c", &y, &num_0202, &z);
	printf("Please enter the sum:\n");
	scanf("%d", &sum);
	
	if(sum > 0)
	{
		sum4 = sum % 10;
		sum = sum / 10;
		//printf("第一個餘數：%d,新的商：%d\n", sum4, sum);
	}
		if(sum > 0)
		{
		sum3 = sum % 10;
		sum = sum / 10;
		//printf("第二個餘數：%d,新的商：%d\n", sum3, sum);
		}
			if(sum > 0)
			{
				sum2 = sum % 10;
				sum = sum / 10;
				//printf("第三個餘數：%d,新的商：%d\n", sum2, sum);
			}
				if(sum > 0)
				{
					sum1 = sum % 10;
					sum = sum / 10;
					//printf("第四個餘數：%d,新的商：%d\n", sum1, sum);
				}	
				
				if(sum4 < num_0103)//t
				{
					z = 10 - ( num_0103 - sum4);
					
					if(sum3 - 1 < num_0202)//tt
					{
						x = (sum + 10 - num_0202 - 1) +10;
						
						if(sum2 - 1 < num_0101)//ttt
						{
							y = 10 - ( num_0101 - sum2 - 1);
						}
						else//ttf
						{
							y = sum2 - 1 - num_0101;			
						}
					}
					else//tf
					{
						x = (sum3 + 10) - 1 - num_0202;
						
						if(sum2  < num_0101)//tft
						{
							y = 10 - ( num_0101 - sum2);
						}
						else//tff
						{
							y = sum2 - num_0101;			
						}
					}
				}	
				else//f
				{
					z = sum4 - num_0103;
					
					if(sum3 < num_0202)//ft
					{
						x = 10 - ( num_0202 - sum3);
						
						if(sum2 -1 < num_0101)//ftt
						{
							y = (sum1 * 10 + sum2 - 1 - num_0101 );
						}
						else//ftf
						{
							y = sum2 - 1 - num_0101;			
						}
					}
					else//ff
					{
						x = sum3 - num_0202;
						if(sum2 < num_0101)//fft
						{
							y = (sum1 * 10 + sum2 - num_0101);
						}
						else//fff
						{
							y = sum2 - num_0101;			
						}
					}
				}
					printf("x=%d, y=%d,z =%d\n", x, y, z);
				
				
				
				
				
	return 0;
}
