#include<stdio.h>
#include<stdint.h>

int main(){
  char c1, c2, c3 ,c4;
  int16_t c11 = 0, c12 = 0, c13 = 0, c14 = 0, c21 = 0, c22 = 0, c23 = 0, c24 = 0, c31 = 0, c32 = 0, c33 = 0, c34 = 0, c41 = 0, c42 = 0, c43 = 0, c44 = 0,k = 0,EXP = 0;
  double F;
  printf("Please input a hex:");
  scanf("%c%c%c%c",&c1,&c2,&c3,&c4);
  if(c1>='0'&&c1<='9')
    c1 = c1 - '0';
  else if(c1>='A'&&c1<='F')
    c1 = c1 - 'A' + 10;
  else if(c1>= 'a'&&c1<='f')
    c1 = c1 - 'a' + 10;
  if(c2>='0'&&c2<='9')
    c2 = c2 - '0';
  else if(c2>='A'&&c2<='F')
    c2 = c2 - 'A' + 10;
  else if(c2>= 'a'&&c2<='f')
    c2 = c2 - 'a' + 10;
  if(c3>='0'&&c3<='9')
    c3 = c3 - '0';
  else if(c3>='A'&&c3<='F')
    c3 = c3 - 'A' + 10;
  else if(c3>= 'a'&&c3<='f')
    c3 = c3 - 'a' + 10;
  if(c4>='0'&&c4<='9')
    c4 = c4 - '0';
  else if(c4>='A'&&c4<='F')
    c4 = c4 - 'A' + 10;
  else if(c4>= 'a'&&c4<='f')
    c4 = c4 - 'a' + 10;
  
  c11 = c1%2;
  c12 = c1/2%2;
  c13 = c1/4%2;
  c14 = c1/8%2;

  c21 = c2%2;
  c22 = c2/2%2;
  c23 = c2/4%2;
  c24 = c2/8%2;

  c31 = c3%2;
  c32 = c3/2%2;
  c33 = c3/4%2;
  c34 = c3/8%2;

  c41 = c4%2;
  c42 = c4/2%2;
  c43 = c4/4%2;
  c44 = c4/8%2;

  k = c1*16*16*16+c2*16*16+c3*16+c4;
  printf("Please choose the output type(1:integer,2:unsigned integer, 3:float):");
  int16_t choose;
  scanf("%hd",&choose);
  printf("Binary of %hX is:%d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",k,c14,c13,c12,c11,c24,c23,c22,c21,c34,c33,c32,c31,c44,c43,c42,c41);
  if(choose == 1){
   printf("Converted integer is:%hd",k); 
  }
  else if(choose == 2){
    printf("Converted unsigned integer is:%u",k);   
  }
  else if(choose == 3){
    printf("Converted float is:");
    EXP = c13*16+c12*8+c11*4+c24*2+c23;
    F = c22*1 +  c21*(1/2.0)+ c34*(1/4.0) + c33*(1/8.0) + c32*(1/16.0) + c31*(1/32.0) + c44*(1/64.0) + c43*(1/128.0) + c42*(1/256.0) + c41*(1/512.0);
     if(c14 == 1){
            if(EXP == 0 && F == 0)
              printf("-0.0\n");
            else if(EXP == 31 && F == 0)
              printf("-INF\n");
            else if(EXP == 31 && F != 0)
              printf("NAN\n");
            else
             printf("-%f*2^%d\n",F,EXP-15);
    }
    else   if(c14 == 0){
    if(EXP == 0 && F == 0)
              printf("0.0\n");
            else if(EXP == 31 && F == 0)
              printf("INF\n");
            else if(EXP == 31 && F != 0)
              printf("NAN\n");
             else 	
              printf("%f*2^%d\n",F,EXP-15);
        }
}
}