#include<stdio.h>
#include<stdint.h>

int main(){
int32_t  t1=-1,t2=-1,t3=-1,t0=-1;
int32_t x =0, y=0, z=0;
int32_t c1=0, c2=0;
printf("Please enter the first operand\n");
scanf("%dx%d",&t0,&t1);
printf("Please enter the second operand\n"); 
scanf("\ny%dz",&t2);
printf("Please enter the sum\n");
scanf("%d",&t3);
  if( t1 < 0 || (t1 > 10 )){
    printf("error message\n");
    return 0;
}
if( t2 < 0 || (t2 > 10 )){
    printf("error message\n");
    return 0;
}
if( t3 < 0 || (t3 > 2000 )){
    printf("error message\n");
    return 0;
}
if( t0 < 0 || (t0 > 10 )){
    printf("error message\n");
    return 0;
}

if(t3%10 < t1){
  z = t3%10 + 10 - t1;
  c1 = 1;
  z =  z%10;
}
else
  z = t3%10 - t1;
if(t3%100/10 < (t2 + c1)){
  x = t3%100/10 + 10 - t2 - c1;
  c2 = 1;
  x = x%10;
}
else
  x= t3%100/10 - t2 - c2;
y = t3/100 - t0 - c2;
if(x<0||y<0||z<0)
  printf("error message");
else
printf("Ans: x = %d, y = %d, z =%d\n",x,y,z);
}