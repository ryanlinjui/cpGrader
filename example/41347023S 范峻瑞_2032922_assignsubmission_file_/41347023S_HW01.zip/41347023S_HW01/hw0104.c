#include<stdio.h>
#include<stdint.h>

int main(){
  double  c1 = 0,c2 = 0,c3 = 0,c4 = 0,c5 = 0;
  int32_t temp, c1c, c2c, c3c, c4c, c5c, c1m, c2m, c3m, c4m, c5m;
  printf("Please enter 5 cards:");
  double mini = 0;
  scanf("%lf %lf %lf %lf %lf",&c1,&c2,&c3,&c4,&c5);
  c1m = c1;
  c2m = c2;
  c3m = c3;
  c4m = c4;
  c5m = c5;
 if((c1m == c2m)||(c1m == c3m)||(c1m == c4m)||(c1m == c5m)||(c2m == c3m)||(c2m == c4m)||(c2m == c5m)||(c3m == c4m)||(c3m == c4m)||(c4m == c5m)||(c1m - c1 != 0) || (c2m - c2 != 0) || (c3m - c3 != 0) || (c4m - c4 != 0) || (c5m - c5 != 0) || c1>52 || c1<1 || c2 > 52 || c2 < 1 || c3 > 52 || c3 < 1 || c4 > 52 || c4 < 1 || c5 >52 || c5 < 1){
   printf("error message\n");
   return 0;
   }
  c1m -= 1;
  c2m -= 1;
  c3m -= 1;
  c4m -= 1;
  c5m -= 1;
  c1c = c1m / 13;
  c2c = c2m / 13;
  c3c = c3m / 13;
  c4c = c4m / 13;
  c5c = c5m / 13;
  c1m = (c1m % 13) + 1;
  c2m = (c2m % 13) + 1;
  c3m = (c3m % 13) + 1;
  c4m = (c4m % 13) + 1;
  c5m = (c5m % 13) + 1;
   if(c1m>c2m){
     temp = c1m;
      c1m = c2m;
      c2m = temp;
    }
    if(c2m>c3m){
     temp = c2m;
      c2m = c3m;
      c3m = temp;
    }
    if(c3m>c4m){
     temp = c3m;
      c3m = c4m;
      c4m = temp;
    }
    if(c4m>c5m){
     temp = c4m;
      c4m = c5m;
      c5m = temp;
    }
      if(c1m>c2m){
       temp = c1m;
        c1m = c2m;
        c2m = temp;
      }
      if(c2m>c3m){
       temp = c2m;
        c2m = c3m;
        c3m = temp;
      }
      if(c3m>c4m){
       temp = c3m;
        c3m= c4m;
        c4m = temp;
      }  if(c1m>c2m){
       temp = c1m;
        c1m = c2m;
        c2m = temp;
      }
      if(c2m>c3m){
       temp = c2m;
        c2m = c3m;
        c3m = temp;
      }
      if(c1m>c2m){
        temp = c1m;
        c1m = c2m;
        c2m = temp;
      }
  if(((c2m-c1m) == (c3m-c2m) && (c3m-c2m) == (c4m-c3m) && (c4m-c3m)== (c5m-c4m))||((c1m==1)&&(c2m==10)&&(c3m==11)&&(c4m==12)&&(c5m==13))){
    if(c1c == c2c && c2c == c3c && c3c == c4c && c4c == c5c)
      printf("Straight Flush\n");
    else
      printf("Straight\n");
}
  else if((c1m == c2m && c2m == c3m && c3m == c4m
)||c5m == c2m && c2m == c3m && c3m == c4m)
    printf("Four of a kind\n");
  else if((c1m == c2m && c2m == c3m && c4m == c5m)||c1m == c2m && c3m == c4m && c4m == c5m)
    printf( "Full House\n");
  else if(c1c == c2c && c2c == c3c && c3c == c4c && c4c == c5c)
    printf("Flush\n");
  else if((c1m == c2m && c2m == c3m)||(c2m == c3m && c3m == c4m)||(c3m == c4m && c4m== c5m))
    printf("Three of a kind\n");
  else if((c1m == c2m && c3m == c4m)||(c2m == c3m && c4m == c5m)||(c1m == c2m && c4m== c5m))
    printf("Two Pair\n");
  else if((c1m == c2m)||(c2m == c3m)||(c3m == c4m)|| (c4m == c5m))
    printf("One Pair\n");
  else
    printf("High Card\n");
return 0;
}