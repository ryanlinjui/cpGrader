 #include<stdio.h>
  #include<stdint.h>

  int main(){
    int16_t a=0,b=0,c=0,d=0,e=0,f=0,g=0,num=0, k1=1, k2=1, k3=1, k4=1 ,k5=1,k6=1;
  printf("Please enter an unsigned 16-bits number:");
  int16_t k = -1, t = 0;
  scanf("%d",&k);
if(k<0){
printf("error message");
return 0;
}
  int16_t temp = k;
  printf("Before flip:\n");
  printf("%d_10 = ",k);
    a = k%8;
    b = k/8%8;
    c = k/8/8%8;
    d = k/8/8/8%8;
    e = k/8/8/8/8%8;
    f = k/8/8/8/8/8%8;
    g = k/8/8/8/8/8/8%8;
    int16_t i = printf("%o", k);
    printf("_8\n");
    if(i>6){
      k1=8;
      k2=8;
      k3=8;
      k4=8;
      k5=8;
      k6=8;
    }
   else if(i>5){
      k1 = 8;
      k2 = 8;
      k3 = 8;
      k4 = 8;
      k5 = 8;
    }
    else if (i>4){
      k1 = 8;
      k2 = 8;
      k3 = 8;
      k4 = 8;
    }
    else if(i>3){
      k1 = 8;
      k2 = 8;
      k3 = 8;
    }
    else if(i>2){
      k1 = 8;
      k2 = 8;
    }
    else if(i>1){
      k1 = 8;
    }
    num = a*k1*k2*k3*k4*k5*k6 + b*k2*k3*k4*k5*k6 + c*k3*k4*k5*k6 + d*k4*k5*k6 + e*k5*k6 + f*k6+g;
    printf("After flip:\n");
    printf("%o_8 = %d_10\n",num,num);
  return 0;
  }