#include <stdio.h>
#include <stdint.h>

int main()
{
    int a = 0 , b = 0 , c = 0 , d = 0 , e = 0 ;
    int a1 = 0 , b1 = 0 , c1 = 0 , d1 = 0 , e1 = 0 ;
    printf("Please enter 5 cards: ") ;
    scanf("%d %d %d %d %d", &a1 , &b1 , &c1 , &d1 , &e1 ) ;

    a = a1%13 ;
    b = b1%13 ;
    c = c1%13 ;
    d = d1%13 ;
    e = e1%13 ;

    while( a > b || b > c || c > d || d > e )
    {
        if(a>b)
        {
            int i = 0 ;
            i = a ; 
            a = b ;
            b = i ;
        }
        if(b>c)
        {
            int i = 0 ;
            i = b ; 
            b = c ;
            c = i ;
        }
        if(c>d)
        {
            int i = 0 ;
            i = c ; 
            c = d ;
            d = i ;
        }
        if(d>e)
        {
            int i = 0 ;
            i = d ; 
            d = e ;
            e = i ;
        }
        
    }

    while( a1 > b1 || b1 > c1 || c1 > d1 || d1 > e1 )
    {
        if(a1>b1)
        {
            int i = 0 ;
            i = a1 ; 
            a1 = b1 ;
            b1 = i ;
        }
        if(b1>c1)
        {
            int i = 0 ;
            i = b1 ; 
            b1 = c1 ;
            c1 = i ;
        }
        if(c1>d1)
        {
            int i = 0 ;
            i = c1 ; 
            c1 = d1 ;
            d1 = i ;
        }
        if(d1>e1)
        {
            int i = 0 ;
            i = d1 ; 
            d1 = e1 ;
            e1 = i ;
        }
        
    }

    if(a1<1 || e1>52)
    {
        printf("ERROR\n") ;
        return 0 ;
    }

    if(a1==b1 || b1==c1 || c1==d1 || d1==e1)
    {
        printf("ERROR\n") ;
        return 0 ;
    }
    if(b1-a1==1 && c1-b1==1 && d1-c1==1 && e1-d1==1 && b!=1 && c!=1 && d!=1 )
    {
        printf("Straight flush\n") ;
        return 0 ;
    }

    if(b-a==1 && c-b==1 && d-c==1 && e-d==1 && b!=1 && c!=1 && d!=1 )
    {
        printf("Straight\n") ;
        return 0 ;
    }
    
    if((a==b && b==c && c==d) || (b==c && c==d && d==e))
    {
        printf("Four of a kind\n") ;
        return 0 ;
    }

    if((a==b && b==c) || (b==c && c==d) ||(c==d && d==e))
    {
        if(a==b || d==e)
        {
            printf("Full house\n") ;
            return 0 ;
        }
        else
        {
            printf("Three of a kind\n") ;
            return 0 ;
        }
    }

    if(a1/13==b1/13 && b1/13==c1/13 && c1/13==d1/13 && d1/13==e1/13)
    {
        printf("Flush\n") ;
        return 0 ;
    }

    if((a==b && c==d) || (a==b && d==e) || (b==c && d==e))
    {
        printf("Two pair\n") ;
        return 0 ;
    }

    if(a==b || b==c || c==d || d==e)
    {
        printf("One pair\n") ;
        return 0 ;
    }

    printf("High card\n") ;
    return 0 ;
}