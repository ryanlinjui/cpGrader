#include <stdio.h>
#include <stdint.h>

int main()
{
    int32_t i = 0 ;
    int32_t n = 1 ;
    int32_t input16 = 0 ;
    int32_t input16_1 = 0 ;
    int32_t a = 0 ;
    int32_t b = 0 ;
    int32_t c = 0 ;
    int32_t d = 0 ;
    int32_t outputi = 0 ;
    int32_t exp = 0 ;
    double f = 0 ;
    int32_t outputf = 0 ;

    printf("Please input a hex:") ;
    scanf("%X" , &input16) ;
    fflush(stdin) ;

    printf("Please choose the output type(1:integer,2:unsigned integer,3:float):") ;
    scanf("%d" , &i) ;
    printf("Binary of %X is : " , input16) ;

    input16_1 = input16 ;
    n = input16_1/0x1000 ;
    input16_1 %= 0x1000 ;
    switch(n)
    {
        case 0: 
            printf("0000 ") ;
            a = 0000 ;
            break ;
        case 1:
            printf("0001 ") ;
            a = 0001 ;
            break ;
        case 2:
            printf("0010 ") ;
            a = 0010 ;
            break ;
        case 3:
            printf("0011 ") ;
            a = 0011 ;
            break ;
        case 4:
            printf("0100 ") ;
            a = 0100 ;
            break ;
        case 5:
            printf("0101 ") ;
            a = 0101 ;
            break ;
        case 6:
            printf("0110 ") ;
            a = 0110 ;
            break ;
        case 7:
            printf("0111 ") ;
            a = 0111 ;
            break ;
        case 8:
            printf("1000 ") ;
            a = 1000 ;
            break ;
        case 9:
            printf("1001 ") ;
            a = 1001 ;
            break ;
        case 10:
            printf("1010 ") ;
            a = 1010 ;
            break ;
        case 11:
            printf("1011 ") ;
            a = 1011 ;
            break ;
        case 12:
            printf("1100 ") ;
            a = 1100 ;
            break ;
        case 13:
            printf("1101 ") ;
            a = 1101 ;
            break ;
        case 14:
            printf("1110 ") ;
            a = 1110 ;
            break ;
        case 15:
            printf("1111 ") ;
            a = 1111 ;
            break ;
    }
    n = input16_1/0x100 ;
    input16_1 %= 0x100 ;
    switch(n)
    {
        case 0: 
            printf("0000 ") ;
            b = 0000 ;
            break ;
        case 1:
            printf("0001 ") ;
            b = 0001 ;
            break ;
        case 2:
            printf("0010 ") ;
            b = 0010 ;
            break ;
        case 3:
            printf("0011 ") ;
            b = 0011 ;
            break ;
        case 4:
            printf("0100 ") ;
            b = 0100 ;
            break ;
        case 5:
            printf("0101 ") ;
            b = 0101 ;
            break ;
        case 6:
            printf("0110 ") ;
            b = 0110 ;
            break ;
        case 7:
            printf("0111 ") ;
            b = 0111 ;
            break ;
        case 8:
            printf("1000 ") ;
            b = 1000 ;
            break ;
        case 9:
            printf("1001 ") ;
            b = 1001 ;
            break ;
        case 10:
            printf("1010 ") ;
            b = 1010 ;
            break ;
        case 11:
            printf("1011 ") ;
            b = 1011 ;
            break ;
        case 12:
            printf("1100 ") ;
            b = 1100 ;
            break ;
        case 13:
            printf("1101 ") ;
            b = 1101 ;
            break ;
        case 14:
            printf("1110 ") ;
            b = 1110 ;
            break ;
        case 15:
            printf("1111 ") ;
            b = 1111 ;
            break ;
    }
    n = input16_1/0x10 ;
    input16_1 %= 0x10 ;
    switch(n)
    {
        case 0: 
            printf("0000 ") ;
            c = 0000 ;
            break ;
        case 1:
            printf("0001 ") ;
            c = 0001 ;
            break ;
        case 2:
            printf("0010 ") ;
            c = 0010 ;
            break ;
        case 3:
            printf("0011 ") ;
            c = 0011 ;
            break ;
        case 4:
            printf("0100 ") ;
            c = 0100 ;
            break ;
        case 5:
            printf("0101 ") ;
            c = 0101 ;
            break ;
        case 6:
            printf("0110 ") ;
            c = 0110 ;
            break ;
        case 7:
            printf("0111 ") ;
            c = 0111 ;
            break ;
        case 8:
            printf("1000 ") ;
            c = 1000 ;
            break ;
        case 9:
            printf("1001 ") ;
            c = 1001 ;
            break ;
        case 10:
            printf("1010 ") ;
            c = 1010 ;
            break ;
        case 11:
            printf("1011 ") ;
            c = 1011 ;
            break ;
        case 12:
            printf("1100 ") ;
            c = 1100 ;
            break ;
        case 13:
            printf("1101 ") ;
            c = 1101 ;
            break ;
        case 14:
            printf("1110 ") ;
            c = 1110 ;
            break ;
        case 15:
            printf("1111 ") ;
            c = 1111 ;
            break ;
    }
    n = input16_1 ;
    switch(n)
    {
        case 0: 
            printf("0000 ") ;
            d = 0000 ;
            break ;
        case 1:
            printf("0001 ") ;
            d = 0001 ;
            break ;
        case 2:
            printf("0010 ") ;
            d = 0010 ;
            break ;
        case 3:
            printf("0011 ") ;
            d = 0011 ;
            break ;
        case 4:
            printf("0100 ") ;
            d = 0100 ;
            break ;
        case 5:
            printf("0101 ") ;
            d = 0101 ;
            break ;
        case 6:
            printf("0110 ") ;
            d = 0110 ;
            break ;
        case 7:
            printf("0111 ") ;
            d = 0111 ;
            break ;
        case 8:
            printf("1000 ") ;
            d = 1000 ;
            break ;
        case 9:
            printf("1001 ") ;
            d = 1001 ;
            break ;
        case 10:
            printf("1010 ") ;
            d = 1010 ;
            break ;
        case 11:
            printf("1011 ") ;
            d = 1011 ;
            break ;
        case 12:
            printf("1100 ") ;
            d = 1100 ;
            break ;
        case 13:
            printf("1101 ") ;
            d = 1101 ;
            break ;
        case 14:
            printf("1110 ") ;
            d = 1110 ;
            break ;
        case 15:
            printf("1111 ") ;
            d = 1111 ;
            break ;
    }
    

    switch(i)
    {
        case 1:
            if((a/1000) == 0)
            {
                printf("\nConverted integer is: %d" , input16) ;
            }
            else
            {
                if((d%10) == 0)
                {
                    outputi += 1 ;
                }
                if(((d/10)%10) == 0)
                {
                    outputi += 2 ;
                }
                if(((d/100)%10) == 0)
                {
                    outputi += 4 ;
                }
                if((d/1000) == 0)
                {
                    outputi += 8 ;
                }

                if((c%10) == 0)
                {
                    outputi += 16 ;
                }
                if(((c/10)%10) == 0)
                {
                    outputi += 32 ;
                }
                if(((c/100)%10) == 0)
                {
                    outputi += 64 ;
                }
                if((c/1000) == 0)
                {
                    outputi += 128 ;
                }

                if((b%10) == 0)
                {
                    outputi += 256 ;
                }
                if(((b/10)%10) == 0)
                {
                    outputi += 512 ;
                }
                if(((b/100)%10) == 0)
                {
                    outputi += 1024 ;
                }
                if((b/1000) == 0)
                {
                    outputi += 2048 ;
                }

                if((a%10) == 0)
                {
                    outputi += 4096 ;
                }
                if(((a/10)%10) == 0)
                {
                    outputi += 8192 ;
                }
                if(((a/100)%10) == 0)
                {
                    outputi += 16384 ;
                }
                outputi += 1 ;
                printf("\nConverted integer is: -%d" , outputi) ;
            }
            break ;
        case 2 :
            printf("\nConverted unsigned integer is: %d" , input16) ;
            break ;
        case 3 :
            if(((b/100)%10) == 1)
            {
                exp += 1 ;
            }
            if((b/1000) == 1)
            {
                exp += 2 ;
            }
            if((a%10) == 1)
            {
                exp += 4 ;
            }
            if(((a/10)%10) == 1)
            {
                exp += 8 ;
            }
            if(((a/100)%10) == 1)
            {
                exp += 16 ;
            }

            if((d%10) == 1)
            {
                f += 0.0009765625 ;
            }
            if(((d/10)%10) == 1)
            {
                f += 0.001953125 ;
            }
            if(((d/100)%10) == 1)
            {
                f += 0.00390625 ;
            }
            if((d/1000) == 1)
            {
                f += 0.0078125 ;
            }

            if((c%10) == 1)
            {
                f += 0.015625 ;
            }
            if(((c/10)%10) == 1)
            {
                f += 0.03125 ;
            }
            if(((c/100)%10) == 1)
            {
                f += 0.0625 ;
            }
            if((c/1000) == 1)
            {
                f += 0.125 ;
            }

            if((b%10) == 1)
            {
                f += 0.25 ;
            }
            if(((b/10)%10) == 1)
            {
                f += 0.5 ;
            }
            
            printf("\nConverted float is: ") ;
            if(a/1000 == 1)
            {
                printf("-") ;
            }
            else
            {
                printf("+") ; 
            }

            if(exp == 0 && f == 0)
            {
                printf("0\n") ;
                break ;
            }
            if(exp == 31 && f == 0)
            {
                printf("INF\n") ;
                break ;
            }
            if(exp == 31 && f != 0)
            {
                printf("NAN\n") ;
                break ;
            }
            f += 1 ;
            exp -= 15 ;
            printf("%lf*2^%d\n" , f ,exp ) ;
            break ;
        default :
            printf("ERROR\n") ;
            break ;
    }
    
}