#include <stdio.h>
#include <stdint.h>

int main()
{
    int32_t input10 = 0 ;
    int32_t input8 = 0 ;
    int32_t reverse8 = 0 ;
    int32_t reverse10 = 0 ;
    int32_t i = 1 ;

    printf("Please enter an unsigned 16-bits number: ") ;
    scanf("%d" , &input10 ) ;
    printf("Before Flip:\n") ;
    printf("%d_10 " , input10) ; 

    while (input10 > 0)
    {
        input8 = input8 + (input10%8)*i ;
        input10 = input10/8 ;
        i *= 10 ;
    }

    printf("= %d_8\n" , input8) ;
    printf("After Flip:\n") ; 
    
    while (input8 > 0)
    {
        i /= 10 ;
        reverse8 = reverse8 + (input8%10)*i ;
        input8 = input8/10 ;
    }
    printf("%d_8 " , reverse8 ) ;

    i = 1 ; 
    while (reverse8 > 0)
    {
        reverse10 = reverse10 + (reverse8%10)*i ;
        reverse8 = reverse8/10 ;
        i *= 8 ;
    }
    printf("= %d_10\n" , reverse10) ;
    return 0 ;
}