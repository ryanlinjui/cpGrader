#include <stdio.h>
#include <stdint.h>

int main()
{
    int32_t a = 0 ;
    int32_t b = 0 ;
    int32_t c = 0 ;
    int32_t sum = 0 ;
    int32_t x = 0 ;
    int32_t y = 0 ;
    int32_t z = 0 ;
    
    printf("Please enter the first  operand: ") ;
    scanf("%dx%d" , &a , &b ) ;
    fflush(stdin) ;

    printf("Please enter the second operand: ") ;
    scanf(" y%dz" , &c ) ;
    fflush(stdin) ;
    
    printf("Please enter the sum           : ") ;
    scanf(" %d" , &sum ) ;
    fflush(stdin) ;
    
    if(a>9)
    {
        printf("ERROR\n") ;
        return 0 ;
    }
    if(b>9)
    {
        printf("ERROR\n") ;
        return 0 ;
    }
    if(c>9)
    {
        printf("ERROR\n") ;
        return 0 ;
    }
    if((sum/100) <a )
    {
        printf("ERROR\n") ;
        return 0 ;
    }
    
    int32_t S1 = 0 ;
    int32_t S2 = 0 ;
    int32_t S3 = 0 ;
    int32_t S4 = 0 ;

    S1 = sum%10 ;
    S2 = (sum/10)%10 ;
    S3 = (sum/100)%10 ;
    S4 = (sum/1000) ;
        
    if(S1 >= b)
    {
        z = S1-b ;
    }
    else
    {
        z = S1+10-b ;
        S2 -= 1 ;
    }
        
    if(S2 >= c)
    {
        x = S2-c ;
    }
    else
    {
        x = S2+10-c ;
        S3 -= 1 ;
    }

    if(S3 >= a)
    {
        y = S3-a ;
    }
    else
    {
        y = S3+10-a ;
        S4 -= 1 ;
    }
    
    printf("Ans : x = %d, y = %d, z = %d\n" , x , y , z ) ;
}
