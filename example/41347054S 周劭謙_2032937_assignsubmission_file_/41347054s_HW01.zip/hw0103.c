#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
int main()
{
	uint32_t a=0;
	printf("Please enter an unsigned 16-bits number: ");
	scanf("%d",&a);
	uint32_t b0=0,b1=0,b2=0,b3=0,b4=0,b5=0,b6=0;
	uint32_t tmp = a;
	b0 = a%8;a/=8;
	b1 = a%8;a/=8;
	b2 = a%8;a/=8;
	b3 = a%8;a/=8;
	b4 = a%8;a/=8;
	b5 = a%8;a/=8;
	b6 = a%8;a/=8;
	
	printf("Before Flip:\n");
	printf("%d_10 = ",tmp);
	if(!b6){
		if(!b5){
			if(!b4){
				if(!b3){
					if(!b2){
						if(!b1)printf("%d",b0);
						else{
							printf("%d%d",b1,b0);
							b0^=b1;b1^=b0;b0^=b1;
						}
					}
					else{
						printf("%d%d%d",b2,b1,b0);
						b0^=b2;b2^=b0;b0^=b2;
					}
					
				}
				else {
					printf("%d%d%d%d",b3,b2,b1,b0);
					b0^=b3;b3^=b0;b0^=b3;
					b1^=b2;b2^=b1;b1^=b2;
				}
				
			}
			else {
				printf("%d%d%d%d%d",b4,b3,b2,b1,b0);
				b0^=b4;b4^=b0;b0^=b4;
				b1^=b3;b3^=b1;b1^=b3;
			}
		}
		else {
			printf("%d%d%d%d%d%d",b5,b4,b3,b2,b1,b0);
			b0^=b5;b5^=b0;b0^=b5;
			b1^=b4;b4^=b1;b1^=b4;
			b2^=b3;b3^=b2;b2^=b3;
		}
	}else {
		printf("%d%d%d%d%d%d%d",b6,b5,b4,b3,b2,b1,b0);
		b0^=b6;b6^=b0;b0^=b6;
		b1^=b5;b5^=b1;b1^=b5;
		b2^=b4;b4^=b2;b2^=b4;
	}
	printf("_8\n");
	printf("After Flip:\n");
	a = 0;
	int32_t pw=1;
	a+=b0*pw; pw*=8;
	a+=b1*pw; pw*=8;
	a+=b2*pw; pw*=8;
	a+=b3*pw; pw*=8;
	a+=b4*pw; pw*=8;
	a+=b5*pw; pw*=8;
	a+=b6*pw; pw*=8;
	
	if(!b6){
		if(!b5){
			if(!b4){
				if(!b3){
					if(!b2){
						if(!b1)printf("%d",b0);
						else{
							printf("%d%d",b1,b0);
						}
					}
					else{
						printf("%d%d%d",b2,b1,b0);
					}
					
				}
				else {
					printf("%d%d%d%d",b3,b2,b1,b0);
				}
				
			}
			else {
				printf("%d%d%d%d%d",b4,b3,b2,b1,b0);
			}
		}
		else {
			printf("%d%d%d%d%d%d",b5,b4,b3,b2,b1,b0);
		}
	}else {
		printf("%d%d%d%d%d%d%d",b6,b5,b4,b3,b2,b1,b0);
	}
	printf("_8 = %d_10\n",a);
}