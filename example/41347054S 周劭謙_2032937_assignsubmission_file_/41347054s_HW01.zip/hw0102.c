#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
int main(){
	int32_t a = -1,b = -1,c = -1;
	printf("Please enter the first operand: ");
	if(!scanf("%dx%d",&a,&b)){
		printf("Input Error\n");
		return 0;
	}
	//printf("%d %d",a,b);
    if(a>9 || b>9 || a<0 || b<0){
		printf("Input Error\n");
		return 0;
	}
	printf("Please enter the second operand: ");
	if(!scanf("\ny%dz",&c)){
		printf("Input Error\n");
		return 0;
	}
	if(c>9 || c<0){
		printf("Input Error\n");
		return 0;
	}
	//printf("%d %d %d\n",a,b,c);
	int32_t sum = 0,carry = 0;
	printf("Please enter the sum: ");
	scanf("\n%d",&sum);
	if(sum<0){
		printf("Input Error\n");
		return 0;
	}
	
	int32_t x = 0,y = 0,z = 0;
	z = sum%10 - b;
	if(z < 0){
		z += 10;
		carry = 1;
	}
	
	int32_t tmp = sum;
	sum/=10;
	x = sum%10 - c - carry; 
	
	carry = 0;
	if(x<0){
		carry = 1;
		x+=10;
	}
	
	sum/=10;
	y = sum-carry-a;
	if(y<0)y+=10;
	if(y<0 || y>9){
		printf("No Solution\n");
		return 0;
	}
    //printf("%d %d %d\n",y,x,z);
	//printf("%d %d %d\n",a,c,b);
	tmp -= 100*(a+y) + 10*(x+c) + (b+z);
	if(tmp){
		printf("No Solution\n");
		return 0;
	}
	printf("x = %d, y = %d, z = %d\n",x,y,z);
	
}