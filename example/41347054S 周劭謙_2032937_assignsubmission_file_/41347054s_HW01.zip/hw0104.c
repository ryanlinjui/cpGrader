#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
int main()
{
	int32_t a=0,b=0,c=0,d=0,e=0;
	printf("Please enter five cards\n");
	if(!scanf("%d",&a) || !scanf("%d",&b) || !scanf("%d",&c) || !scanf("%d",&d) || !scanf("%d",&e)){
		printf("Input Error\n");
		return 0;
	}
	//manual bubble sort
	//(a,b) -> (a,a^b) -> (b,a^b) -> (b,a)
	if(a>b){a ^= b;b ^= a;a ^= b;}
	if(b>c){b ^= c;c ^= b;b ^= c;}
	if(c>d){c ^= d;d ^= c;c ^= d;}
	if(d>e){d ^= e;e ^= d;d ^= e;}

	if(a>b){a ^= b;b ^= a;a ^= b;}
	if(b>c){b ^= c;c ^= b;b ^= c;}
	if(c>d){c ^= d;d ^= c;c ^= d;}

	if(a>b){a ^= b;b ^= a;a ^= b;}
	if(b>c){b ^= c;c ^= b;b ^= c;}

	if(a>b){a ^= b;b ^= a;a ^= b;}
	if(a<0 || e>52){
		printf("Input Error\n");
		return 0;
	}

	int32_t sa = (a-1)/13; 
	int32_t sb = (b-1)/13; 
	int32_t sc = (c-1)/13;
	int32_t sd = (d-1)/13;
	int32_t se = (e-1)/13;

	int32_t va = (a-1)%13; 
	int32_t vb = (b-1)%13; 
	int32_t vc = (c-1)%13;
	int32_t vd = (d-1)%13;
	int32_t ve = (e-1)%13;
	//bubble sort values
	if(va>vb){va ^= vb;vb ^= va;va ^= vb;}
	if(vb>vc){vb ^= vc;vc ^= vb;vb ^= vc;}
	if(vc>vd){vc ^= vd;vd ^= vc;vc ^= vd;}
	if(vd>ve){vd ^= ve;ve ^= vd;vd ^= ve;}

	if(va>vb){va ^= vb;vb ^= va;va ^= vb;}
	if(vb>vc){vb ^= vc;vc ^= vb;vb ^= vc;}
	if(vc>vd){vc ^= vd;vd ^= vc;vc ^= vd;}

	if(va>vb){va ^= vb;vb ^= va;va ^= vb;}
	if(vb>vc){vb ^= vc;vc ^= vb;vb ^= vc;}

	if(va>vb){va ^= vb;vb ^= va;va ^= vb;}
	
	bool flush = (sa == sb && sb == sc && sc == sd && sd == se);
	bool straight = (vb == va+1 && vc == vb+1 && vd == vc+1 && ve == vd+1);
	if(va == 0 && vb == 9 && vc == 10 && vd == 11 && ve == 12)straight = 1;

	if(flush && straight){
		printf("Straight Flush\n");
		return 0;
	}
	if((va==vb && vb==vc && vc==vd) || (vb==vc && vc==vd && vd==ve)){
		printf("Four of a kind\n");
		return 0;
	}
	if((va==vb && vb==vc && vd==ve) || (va==vb && vc==vd && vd==ve)){
		printf("Full House\n");
		return 0;
	}
	if(flush){
		printf("Flush\n");
		return 0;
	}
	if(straight){
		printf("Straight\n");
		return 0;
	}
	if((va == vb && vb == vc) || (vb == vc && vc == vd) || (vc == vd && vd == ve)){
		printf("Three of a kind\n");
		return 0;
	}
	int32_t pairs = 0;
	pairs += (va==vb);
	pairs += (vb==vc);
	pairs += (vc==vd);
	pairs += (vd==ve);
	if(pairs == 2)printf("Two pair\n");
	else if(pairs == 1)printf("One pair\n");
	else printf("High card\n");

	return 0;
}