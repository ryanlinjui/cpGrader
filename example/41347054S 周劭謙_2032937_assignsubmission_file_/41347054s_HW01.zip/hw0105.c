#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
int main()
{
	int32_t a = 0;
	printf("Please input a hex\n");
	scanf("%x",&a);
	int32_t c0,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15;
	c0=c1=c2=c3=c4=c5=c6=c7=c8=c9=c10=c11=c12=c13=c14=c15=0;
	c0 = a&1;a/=2;
	c1 = a&1;a/=2;
	c2 = a&1;a/=2;
	c3 = a&1;a/=2;
	c4 = a&1;a/=2;
	c5 = a&1;a/=2;
	c6 = a&1;a/=2;
	c7 = a&1;a/=2;
	c8 = a&1;a/=2;
	c9 = a&1;a/=2;
	c10 = a&1;a/=2;
	c11 = a&1;a/=2;
	c12 = a&1;a/=2;
	c13 = a&1;a/=2;
	c14 = a&1;a/=2;
	c15 = a&1;a/=2;
	printf("%d%d%d%d ",c15,c14,c13,c12);
	printf("%d%d%d%d ",c11,c10,c9,c8);
	printf("%d%d%d%d ",c7,c6,c5,c4);
	printf("%d%d%d%d\n",c3,c2,c1,c0);
	
	printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):\n");
	int32_t type = 0;
	scanf("%d",&type);
	if(type<1 || type>3){
		printf("Invalid Output\n");
		return 0;
	}
	
	if(type <= 2){
		int32_t ans = 0;
		int32_t pw = 1;
		int32_t b = c15;
		if(type == 2)b = 0;
		ans += (b^c0)*pw;pw*=2;
		ans += (b^c1)*pw;pw*=2;
		ans += (b^c2)*pw;pw*=2;
		ans += (b^c3)*pw;pw*=2;
		ans += (b^c4)*pw;pw*=2;
		ans += (b^c5)*pw;pw*=2;
		ans += (b^c6)*pw;pw*=2;
		ans += (b^c7)*pw;pw*=2;
		ans += (b^c8)*pw;pw*=2;
		ans += (b^c9)*pw;pw*=2;
		ans += (b^c10)*pw;pw*=2;
		ans += (b^c11)*pw;pw*=2;
		ans += (b^c12)*pw;pw*=2;
		ans += (b^c13)*pw;pw*=2;
		ans += (b^c14)*pw;pw*=2;
		ans += (b^c15)*pw;
		if(type == 1 && c15){
			ans++;
			ans *= -1;
		}
		if(type == 1)printf("Converted integer is: %d\n",ans);
		else printf("Converted unsigned integer is: %d\n",ans);
	}else{
		printf("Converted float is: ");
		int32_t exp = 0;
		int32_t pw = 1;
		exp += c10*pw;pw*=2;
		exp += c11*pw;pw*=2;
		exp += c12*pw;pw*=2;
		exp += c13*pw;pw*=2;
		exp += c14*pw;pw*=2;
		
		int32_t sum = 0;
		pw = 1;
		sum += c0*pw;pw*=2;
		sum += c1*pw;pw*=2;
		sum += c2*pw;pw*=2;
		sum += c3*pw;pw*=2;
		sum += c4*pw;pw*=2;
		sum += c5*pw;pw*=2;
		sum += c6*pw;pw*=2;
		sum += c7*pw;pw*=2;
		sum += c8*pw;pw*=2;
		sum += c9*pw;pw*=2;
		
		float f = sum;
		f /= pw;
		f+=1;
		
		if(!exp && !sum){
			if(c15)printf("-0.0\n");
			else printf("+0.0\n");
			return 0;
		}
		if(exp==31){
			if(!sum){
				if(c15)printf("-INF\n");
				else printf("+INF\n");
			}else{
				printf("NAN\n");
			}
			return 0;
		}
		if(c15)f *= -1;
		printf("%f*2^%d\n",f,exp-15);
		
	}
	
	
}