﻿# Author

41347054s

Chew Shao Qian
周劭谦 

# How to Compile 

make

# How to run

./hw0101

./hw0102

./hw0103

./hw0104

./hw0105

# Explanation of each code
## P1

Lyrics of a song are outputted in different colors depending on the singer/s that sang the verse.

## P2
The code finds a solution $(a,b,c)$ over the equation

$$\overline{axb} + \overline{ybz} = s$$ 

where $x,y,z$ and $s$ are given by user input. $x,y,z$ are assumed to be integers between 0 and 9, otherwise the code checks for this and outputs an error if violated.

The code simulates a standard addition algorithm of two numbers with a carry bit. Denote $s_i$ as the digit at the $i$-th digit of $s$ from right to left.

$c=s_0-z\mod{10}$

$b=s_1 - x - [z>s0]\mod{10}$

$a=(s-10s_1-s_0) - y - [x+[z>s0] > s_1]\mod{10}$


Answer is outputted if the equation is satisfied.

## P3

The code reads an integer in decimal, outputs it in octal base then reverses the digits of the number in octal and outputs it both in octal and decimal base.

Since for loops are not allowed, each of the 6 possible digits are read individually and reversed to convert back and forth between different bases

## P4

The code reads a hand of 5 poker hands denoted by integers between 1 and 53 and outputs the highest hand rank.

Each card is split into a number pair denoting suit and value by the formula:

$suit  = c-1\mod{13}$

$value = \lfloor \frac{c-1}{13} \rfloor$

The cards are sorted twice separately by suit and by value, this is done manually with a bubble sort where each individual swap is hard-coded in.

### straights and flush

Straight and Flush are two distinct attributes the hand can have, so both attributes are checked. These two attributes are enough to detect straights, flush and straight flushs.

### Four of a kind, Three of a kind and Full house    

These three hands all contain at least 3 duplicates the number of hard coded comparisons are relatively few. As the cards are sorted by value, duplicates can be checked by only comparing sets of adjacent cards.

### Two pair and pair

Number of adjacent pairs are counted and the hand rank is determined by the count.

## P5

The code reads a 16 bit hexadecimal and converts it to a 16 bit integer, unsigned integer or float depending on the user's choice.

Each of the 16 bit are manually hard coded and extracted by the formula

$b_i = \lfloor x/2^i \rfloor \mod{2}$

After $b_1,b_2,\ldots,b_{16}$ are extracted, conversion is a matter of careful calculation.






