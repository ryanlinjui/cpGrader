#include<stdio.h>
#include<stdint.h>

int main()
{
	uint16_t a,b,c,d,e,f,ten,tenten;
	printf("Please enter an unsigned 16-bits number:\n");
	
	scanf("%hu",&ten);
	printf("Before Flip: \n");
	printf("%hu_10",ten);
	
	tenten=ten;
	a=ten%8;
	ten=ten/8;
	b=ten%8;
	ten=ten/8;
	c=ten%8;
	ten=ten/8;
	d=ten%8;
	ten=ten/8;
	e=ten%8;
	ten=ten/8;
	//f=ten%8;
	//ten=ten/8;
	
	//printf("Before Flip: \n");
	//printf("%hu_10",ten);
	printf(" = ");
	if(tenten>32767) 
		f=1;
	if(tenten<32768)
		f=0;
	if(f==0 && e!=0 )
		printf("%d%d%d%d%d_8\n",e,d,c,b,a);
	else if (f==0 && e==0 && d!=0)
		printf("%d%d%d%d_8\n",d,c,b,a);
	else if(f==0 && e==0 && d==0 && c!=0)
		printf("%d%d%d_8\n",c,b,a);
	else if(f==0 && e==0 && d==0 && c==0 && b!=0)
		printf("%d%d_8\n",b,a);
	else if(f==0 && e==0 && d==0 && c==0 && b==0 && a!=0)
		printf("%d_8\n",a);
	else if(tenten==0)
		printf("0_8\n");
	else if(f!=0)
		printf("%d%d%d%d%d%d_8\n",f,e,d,c,b,a);
		
	printf("After Flip: \n");
	uint32_t A,B,C,D,E,F;
	long to_ten,eight;
	A=a;
	B=b;
	C=c;
	D=d;
	E=e;
	F=f;
	//printf("%d%d%d%d%d%d\n",A,B,C,D,E,F);
	if(F!=0){
		printf("%d%d%d%d%d%d_8",A,B,C,D,E,F);
		to_ten=F+E*10+D*100+C*1000+B*10000+A*100000;}
	if(F==0 && E!=0){
		printf("%d%d%d%d%d_8",A,B,C,D,E);
		to_ten=A*10000+B*1000+C*100+D*10+E*1;}
	if(F==0 && E==0 && D!=0){
		printf("%d%d%d%d_8",A,B,C,D);
		to_ten=A*1000+B*100+C*10+D;}
	if(F==0 && E==0 && D==0 && C!=0){
		printf("%d%d%d_8",A,B,C);
		to_ten=A*100+B*10+C;}
	if(F==0 && E==0 && D==0 && C==0 && B!=0){
		printf("%d%d_8",A,B);
		to_ten=A*10+B;}
	if(F==0 && E==0 && D==0 && C==0 && B==0 && A!=0){
		printf("%d_8",A);
		to_ten=A;}
	printf(" = ");
	//printf("%d",to_ten);
	//printf("%d this is to ten\n",to_ten);
	//printf("to ten is %d\n",to_ten);
	
	
	int32_t aa=0,bb=0,cc=0,dd=0,ee=0,ff=0,gg=0;
	aa=to_ten%10;
	to_ten=to_ten/10;
	bb=to_ten%10;
	to_ten=to_ten/10;
	cc=to_ten%10;
	to_ten=to_ten/10;
	dd=to_ten%10;
	to_ten=to_ten/10;
	ee=to_ten%10;
	to_ten=to_ten/10;
	ff=to_ten%10;
	to_ten=to_ten/10;
	
	//aa=to_ten%10;
	//bb=(to_ten/10)%10;
	//cc=(to_ten/10)%10; 
	//dd=(to_ten/10)%10;
	//ee=(to_ten/10)%10;
	//ff=(to_ten/10)%10;
	

	
	//aa=to_ten%10;
	//to_ten/=10;
	//bb=to_ten%10;
	//to_ten/=10;
	//cc=to_ten%10;
	//to_ten/=10;
	//dd=to_ten%10;
	//to_ten/=10;
	//ee=to_ten%10;
	//to_ten/=10;
	//ff=to_ten&10;
	
	//to_ten/=10;
	//gg=to_ten&10;
	//printf("a=%d b=%d c=%d d=%d e=%d f=%d g=%d\n",aa,bb,cc,dd,ee,ff,gg);
	//if(aa<1) aa=0;
	//if(bb<1) bb=0;
	//if(cc<1) cc=0;
	//if(dd<1) dd=0;
	//if(ee<1) ee=0;
	//if(ff<1) ff=0;
	//printf("a=%d b=%d c=%d d=%d e=%d f=%d g=%d\n",aa,bb,cc,dd,ee,ff,gg);
	//printf("to ten is %d",to_ten);
	
	eight=aa*1+bb*8+cc*64+dd*512+ee*4096+ff*32768;
	printf("%ld_10\n",eight);
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
