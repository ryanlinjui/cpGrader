#include <stdio.h>
#include <stdint.h>

int main(){
	
	int32_t num1,num2,num3,x,y,z,sum;
	
	printf("Please enter the first operand : ");
	scanf(" %dx%d",&num1,&num2);
	if(num1>9 || num2>9){
		printf("Wrong Input\n");
		return 0;}
	printf("Please enter the second operand : ");
	scanf(" y%dz",&num3);
	if(num3>9){ 
		printf("Wrong Input\n");
		return 0;}
	printf("Please enter the sum : ");
	scanf(" %d",&sum);
	if(sum>1998){
		printf("Wrong Input\n");
		return 0;}
	int32_t num,ans;
	num=100*num1+10*num3+num2;
	ans=sum-num;
	z=ans%10;
	ans/=10;
	x=ans%10;
	ans/=10;
	y=ans%10;
	
	printf("x=%d y=%d z=%d\n",x,y,z);
}
	
	
	
	
	

