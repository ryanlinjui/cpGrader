#include <stdio.h>
int main()
{
	printf("\033[31m"); //red kim
	printf("[KIM]\nYou are sunlight and I moon\nJoined by the gods of fortune\nMidnight and high noon sharing the sky\nWe have been blessed, you and I\n\n");
	printf("\033[34m"); //blue chris
	printf("[CHRIS]\nYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\n\n");
	printf("\033[31m"); //red kim
	printf("[KIM]\nOutside day starts to dawn\n\n");
	printf("\033[34m"); //blue chris
	printf("[CHRIS]\nYour moon still floats on high\n\n");
	printf("\033[31m"); //red kim
	printf("[KIM]\nThe birds awake\n\n");
	printf("\033[34m"); //blue chris
	printf("[CHRIS]\nThe stars shine too\n\n");
	printf("\033[31m"); //red kim
	printf("My hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n\n");
	printf("You might also like\nMy Boy Only Breaks His Favorite Toys\nWho's Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n\n");
	printf("\033[34m"); //blue chris
	printf("[CHRIS]\nI reach for you\n\n");
	printf("\033[32m"); //green all duet's
	printf("[KIM & CHRIS]\nAnd we meet in the sky\n\n");
	printf("\033[31m"); //red kim
	printf("[KIM]\nYou are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n\n");
	printf("\033[32m"); //green all duet's
	printf("[KIM & CHRIS]\nMade of\nSunlight\nMoonlight\n");
	printf("\033[0m");
	return 0;
}
	
