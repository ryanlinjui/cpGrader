#include<stdio.h>
#include<stdint.h>

int main(){
	int16_t card1=0,card2=0,card3=0,card4=0,card5=0;
	int16_t card1flower,card2flower,card3flower,card4flower,card5flower; 
	int16_t num1,num2,num3,num4,num5;    //number  ex: heart 13 or spade 10
	//flower=4->clubs  flower=3->diamond  flower=2->heart  flower=1->spade
	printf("Please enter 5 cards\n");
	scanf("%hd %hd %hd %hd %hd",&card1,&card2,&card3,&card4,&card5);
	
	if(card1>52||card2>52||card3>52||card4>52||card5>52)
	{
		printf("Wrong Input\n");
		return 0;
	}
	if(card1<=0||card2<=0||card3<=0||card4<=0||card5<=0){
		printf("Wrong Input\n");
		return 0;
	}
	if(card1==card2||card1==card3||card1==card4||card1==card5||card2==card3||card2==card4||card2==card5||card3==card4||card3==card5||card4==card5){
		printf("Wrong Input\n");
		return 0;}
		
	num1=card1%13;
	num2=card2%13;
	num3=card3%13;
	num4=card4%13;
	num5=card5%13;
	
	if(num1==0) num1=13;
	if(num2==0) num2=13;
	if(num3==0) num3=13;
	if(num4==0) num4=13;
	if(num5==0) num5=13;
	
	if(card1>=1 && card1<=13) card1flower=1;
	else if (card1>=14 && card1<=26) card1flower=2;
	else if (card1>=27 && card1<=39) card1flower=3;
	else if (card1>=40 && card1<=52) card1flower=4;
	
	if(card2>=1 && card2<=13) card2flower=1;
	else if (card2>=14 && card2<=26) card2flower=2;
	else if (card2>=27 && card2<=39) card2flower=3;
	else if (card2>=40 && card2<=52) card2flower=4;
	
	if(card3>=1 && card3<=13) card3flower=1;
	else if (card3>=14 && card3<=26) card3flower=2;
	else if (card3>=27 && card3<=39) card3flower=3;
	else if (card3>=40 && card3<=52) card3flower=4;
	
	if(card4>=1 && card4<=13) card4flower=1;
	else if (card4>=14 && card4<=26) card4flower=2;
	else if (card4>=27 && card4<=39) card4flower=3;
	else if (card4>=40 && card4<=52) card4flower=4;
	
	if(card5>=1 && card5<=13) card5flower=1;
	else if (card5>=14 && card5<=26) card5flower=2;
	else if (card5>=27 && card5<=39) card5flower=3;
	else if (card5>=40 && card5<=52) card5flower=4;
	
	
	
	//int32_t statement=0;  // 1.straight flush 2.four of a king ... ... 9.high card.
	
	//now I have set that  when I enter a number(1~52) ,then it convert to the flower and the num(1~13)
	
	//printf("%d %d %d %d %d",card1num,card2num,card3num,card4num,card5num);
	
	int32_t first,second,third,fourth,fifth;
	
	first = num1;

    // Compare with the second number
	if (num2 > first) {
        	second = first;
        	first = num2;}
	else {
        	second = num2;}
    // Compare with the third number
   	if (num3 > first) {
		third = second;
		second = first;
		first = num3;}
	else if (num3 > second) {
        	third = second;
		second = num3;}
	else {
        	third = num3;}

    // Compare with the fourth number
	if (num4 > first) {
       	 	fourth = third;
		third = second;
       		second = first;
		first = num4;}
	else if (num4 > second) {
        	fourth = third;
        	third = second;
        	second = num4;}
	else if (num4 > third) {
        	fourth = third;
        	third = num4;}
	else {
        	fourth = num4;}


    // Compare with the fifth number
	if (num5 > first) {
		fifth = fourth;
        	fourth = third;
		third = second;
        	second = first;
        	first = num5;}
	else if (num5 > second) {
       	 	fifth = fourth;
       	 	fourth = third;
       	 	third = second;
      	  	second = num5;}
	else if (num5 > third) {
      	  	fifth = fourth;
      	  	fourth = third;
       	 	third = num5;}
	else if (num5 > fourth) {
       	 	fifth = fourth;
       	 	fourth = num5;}
	else {fifth = num5;}
	
	//printf("%d %d %d %d %d\n",card1flower,card2flower,card3flower,card4flower,card5flower);
	
	//printf("%d %d %d %d %d\n",first,second,third,fourth,fifth);
	//(first-1==second&&second-1==third&&third-1==fourth&&fourth-1==fifth)
	if(((card1flower==card2flower && card2flower==card3flower && card3flower==card4flower && card4flower==card5flower)&&(first-1==second&&second-1==third&&third-1==fourth&&fourth-1==fifth))||(card1flower==card2flower && card2flower==card3flower && card3flower==card4flower && card4flower==card5flower&&first==13&&second==12&&third==11&&fourth==10&&fifth==1))
	{
		printf("Straight flush\n");
		return 0;
	}
	else if((first-fifth==4)||(first==13&&second==12&&third==11&&fourth==10&&fifth==1))
	{
		printf("Straight\n");
		return 0;
	}
	if((first==second&&second==third&&third==fourth)||second==third&&third==fourth&&fourth==fifth)
	{
		printf("Four of a kind\n");
		return 0;
	}
	if((first==second&&second==third&&fourth==fifth)||(first==second&&third==fourth&&fourth==fifth))
	{
		printf("Full house\n");
		return 0;
	}
	else if((first==second&&second==third&&fourth!=fifth)||(first!=second&&third==fourth&&fourth==fifth))
	{
		printf("Three of a kind\n");
		return 0;
	}
	
	if((card1flower==card2flower&&card2flower==card3flower&&card4flower==card5flower)&&(first-fifth!=4))
	{
		printf("Flush\n");
		return 0;
	}
	if((first==second&&third==fourth&&first!=fifth&&third!=fifth&&first!=third)||(second==third&&fourth==fifth&&first!=second&&first!=fifth&&second!=fifth)||(first==second&&fourth==fifth&&third!=first&&third!=fifth&&first!=fifth))
	{
		printf("Two pair\n");
		return 0;
	}
	if((first==second&&first!=third&&first!=fourth&&first!=fifth&&third!=fourth&&fourth!=fifth&&third!=fifth)||(second==third&&second!=first&&second==fourth&&second==fifth&&first!=fourth&&first!=fifth&&fourth!=fifth)||(third==fourth&&third!=first&&third!=second&&third!=fifth&&first!=fourth&&first!=fifth&&fourth!=fifth)||(fourth==fifth&&fourth!=first&&fourth!=second&&fourth!=third&&first!=second&&first!=third&&second!=third))
	{
		printf("One pair\n");
		return 0;
	}
	printf("High card\n");
	return 0;
	
}
		
		
		
		
		
		

	
	

    
    
    
    
    
    
