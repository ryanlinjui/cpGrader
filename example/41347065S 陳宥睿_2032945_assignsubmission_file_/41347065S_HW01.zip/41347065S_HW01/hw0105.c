#include<stdio.h>
#include<stdint.h>
int main(){
	int32_t hex,a1,a2,a3,a4,b1,b2,b3,b4,c1,c2,c3,c4,d1,d2,d3,d4,tmp;
	
	printf("Please input a hex :");
	scanf("%x",&hex);
	tmp=hex;
	if(hex>=32768){
		a1=1;
		hex=hex-32768;
	}else{
		a1=0;
	}
	if(hex>=16384){
		a2=1;
		hex=hex-16384;
	}else{
		a2=0;
	}
	if(hex>=8192){
		a3=1;
		hex=hex-8192;}
	else{
		a3=0;}
	if(hex>=4096){
		a4=1;
		hex=hex-4096;}
	else{
		a4=0;}
	if(hex>=2048){
		b1=1;
		hex=hex-2048;}
	else{
		b1=0;}
	if(hex>=1024){
		b2=1;
		hex=hex-1024;}
	else{
		b2=0;}
	if(hex>=512){
		b3=1;
		hex=hex-512;}
	else{
		b3=0;}
	if(hex>=256){
		b4=1;
		hex=hex-256;}
	else{
		b4=0;}
	if(hex>=128){
		c1=1;
		hex=hex-128;}
	else{
		c1=0;}
	if(hex>=64){
		c2=1;
		hex=hex-64;}
	else{
		c2=0;}
	if(hex>=32){
		c3=1;
		hex=hex-32;}
	else{
		c3=0;}
	if(hex>=16){
		c4=1;
		hex=hex-16;}
	else {
		c4=0;}
	if(hex>=8){
		d1=1;
		hex=hex-8;}
	else{
		d1=0;}
	if(hex>=4){
		d2=1;
		hex=hex-4;}
	else{
		d2=0;}
	if(hex>=2){
		d3=1;
		hex=hex-2;}
	else{
		d3=0;}
	if(hex==1) d4=1;
	if(hex==0) d4=0;
	
	int32_t type,exp,integer=0;
	float F;
	
	printf("Please choose the output type(1:integer,2:unsigned interger,3:float):");
	scanf("%d",&type);
	if(type!=1&&type!=2&&type!=3){
	  printf("Type Input Error\n");
	  return 0;}
	
	
	printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",tmp,a1,a2,a3,a4,b1,b2,b3,b4,c1,c2,c3,c4,d1,d2,d3,d4);
	switch(type){
	
	case(1):
		if(a1==1){
			a1=-a1+1;
			a2=-a2+1;
			a3=-a3+1;
			a4=-a4+1;
			b1=-b1+1;
			b2=-b2+1;
			b3=-b3+1;
			b4=-b4+1;
			c1=-c1+1;
			c2=-c2+1;
			c3=-c3+1;
			c4=-c4+1;
			d1=-d1+1;
			d2=-d2+1;
			d3=-d3+1;
			d4=-d4+1;
				integer=a1*32768+a2*16384+a3*8192+a4*4096+b1*2048+b2*1024+b3*512+b4*256+c1*128+c2*64+c3*32+c4*16+d1*8+d2*4+d3*2+d4*1+1;
				
				printf("Converted integer is: %d\n",integer*-1);}
			
			
		else if(a1==0){printf("Converted integer is: %d\n",tmp);}
		break;
		
	case(2):
		printf("Converted unsigned integer is: %d\n",tmp);
		break;
	
	case(3):
		if(a1==1){
			exp=a2*16+a3*8+a4*4+b1*2+b2*1;
			exp=exp-15;
			F=b3*0.5+b4*0.25+c1*0.125+c2*0.0625+c3*0.03125+c4*0.015625+d1*0.0078125+d2*0.00390625+d3*0.001953125+d4*0.0009765625;
			F+=1;
			printf("Converted float is %f*2^%d\n",-F,exp);}
		else if(a1==0){
			exp=a2*16+a3*8+a4*4+b1*2+b2*1;
			exp=exp-15;
			F=b3*0.5+b4*0.25+c1*0.125+c2*0.0625+c3*0.03125+c4*0.015625+d1*0.0078125+d2*0.00390625+d3*0.001953125+d4*0.0009765625;
			F+=1;
			printf("Converted float is %f*2^%d\n",F,exp);}
		break;
		
	}
	
	
}
		
		
		
		
		
	
	
	

