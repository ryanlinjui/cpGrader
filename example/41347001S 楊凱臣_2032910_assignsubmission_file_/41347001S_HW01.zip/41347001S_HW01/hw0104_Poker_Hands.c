#include <stdio.h> 
#include <stdint.h> 

int main(){
    int32_t card1 = 0,card2 = 0,card3 = 0,card4 = 0,card5 = 0,temp = 0;
    int32_t suit1 = 0,suit2 = 0,suit3 = 0,suit4 = 0,suit5 = 0;
    int32_t value1 = 0,value2 = 0,value3 = 0,value4 = 0,value5 = 0;
    int32_t type = 0;
    //get input
    printf("Please enter 5 cards: ");
    if(!scanf("%d %d %d %d %d",&card1,&card2,&card3,&card4,&card5)){
        printf("Invalid input.\n");
    }
    
    //check
    if (card1 < 1 || card1  >  52 || card2 < 1 || card2  >  52 || card3 < 1 || card3  >  52 || card4 < 1 || card4  >  52 || card5 < 1 || card5  >  52) {
        printf("Invalid card input.\n");
        return 1;
    }

    //sort
    if(card1 > card2){
        temp  =  card1;
        card1 = card2;
        card2 = temp;
    }
    if(card2 > card3){
        temp = card2;
        card2 = card3;
        card3 = temp;
    }
    if(card3 > card4){
        temp = card3;
        card3 = card4;
        card4 = temp;
    }
    if(card4 > card5){
        temp = card4;
        card4 = card5;
        card5 = temp;
    }

    if(card1 > card2){
        temp = card1;
        card1 = card2;
        card2 = temp;
    }
    if(card2 > card3){
        temp = card2;
        card2 = card3;
        card3 = temp;
    }
    if(card3 > card4){
        temp = card3;
        card3 = card4;
        card4 = temp;
    }

    if(card1 > card2){
        temp = card1;
        card1 = card2;
        card2 = temp;
    }
    if(card2 > card3){
        temp = card2;
        card2 = card3;
        card3 = temp;
    }
    
    if(card1 > card2){
        temp = card1;
        card1 = card2;
        card2 = temp;
    }

    //check
    if (card1==card2||card2==card3||card3==card4||card4==card5){
        printf("Invalid Input. Each card must be different.\n");
        return 0;
    }
    //get suit
    suit1 = (((card1-1)/13)+1);
    suit2 = (((card2-1)/13)+1);
    suit3 = (((card3-1)/13)+1);
    suit4 = (((card4-1)/13)+1);
    suit5 = (((card5-1)/13)+1);

    //get card value
    value1 = (((card1-1)%13)+1);
    value2 = (((card2-1)%13)+1);
    value3 = (((card3-1)%13)+1);
    value4 = (((card4-1)%13)+1);
    value5 = (((card5-1)%13)+1);
    //sort card value
    if(value1 > value2){
        temp = value1;
        value1 = value2;
        value2 = temp;
    }
    if(value2 > value3){
        temp = value2;
        value2 = value3;
        value3 = temp;
    }
    if(value3 > value4){
        temp = value3;
        value3 = value4;
        value4 = temp;
    }
    if(value4 > value5){
        temp = value4;
        value4 = value5;
        value5 = temp;
    }

    if(value1 > value2){
        temp = value1;
        value1 = value2;
        value2 = temp;
    }
    if(value2 > value3){
        temp = value2;
        value2 = value3;
        value3 = temp;
    }
    if(value3 > value4){
        temp = value3;
        value3 = value4;
        value4 = temp;
    }

    if(value1 > value2){
        temp = value1;
        value1 = value2;
        value2 = temp;
    }
    if(value2 > value3){
        temp = value2;
        value2 = value3;
        value3 = temp;
    }

    if(value1 > value2){
        temp = value1;
        value1 = value2;
        value2 = temp;
    }

    //get hands type

    if(suit1 == suit2 && suit1 == suit3 && suit1 == suit4 && suit1 == suit5){
        if(value2-value1 == 1 && value3-value2 == 1 && value4-value3 == 1 && value5-value4 == 1){
            type = 1;
        }
        else if(value1 == 1 && value2 == 10 && value3 == 11 && value4 == 12 && value5 == 13){
            type = 1;
        }
        else{
            type = 4;
        }
    }
    else if(value2-value1 == 1 && value3-value2 == 1 && value4-value3 == 1 && value5-value4 == 1){
        type = 5;
    }
    else if(value1 == 1 && value2 == 10 && value3 == 11 && value4 == 12 && value5 == 13){
        type = 5;
    }
    else if ((value1 == value2 && value2 == value3 && value3 == value4) || (value2 == value3 && value3 == value4 && value4 == value5)){
        type = 2;
    }
    else if (((value1 == value2 && value2 == value3) && (value4 == value5)) || ((value1 == value2) && (value3 == value4 && value4 == value5))){
        type = 3;
    }
    else if ((value1 == value2 && value2 == value3) || (value2 == value3 && value3 == value4) || (value3 == value4 && value4 == value5)){
        type = 6;
    }
    else if ((value1 == value2 && (value3 == value4 || value4 == value5)) || (value2 == value3 && value4 == value5)){
        type = 7;
    }
    else if (value1 == value2 || value2 == value3 || value3 == value4 || value4 == value5){
        type = 8;
    }
    else{
        type = 9;
    }
    
    if (type == 1){
        printf("Straight Flush\n");
    }
    else if (type == 2) {
        printf("Four of a kind\n");
    }
    else if (type == 3) {
        printf("Full house\n");
    }
    else if (type == 4) {
        printf("Flush\n");
    }
    else if (type == 5) {
        printf("Straight\n");
    }
    else if (type == 6) {
        printf("Three of a kind\n");
    }
    else if (type == 7) {
        printf("Two pair\n");
    }
    else if (type == 8) {
        printf("One pair\n");
    }
    else{
        printf("High card\n");
    }

    // printf("%d %d %d %d %d\n",card1,card2,card3,card4,card5);
    // printf("%d %d %d %d %d\n",suit1,suit2,suit3,suit4,suit5);
    // printf("%d %d %d %d %d\n",value1,value2,value3,value4,value5);
    return 0;
}