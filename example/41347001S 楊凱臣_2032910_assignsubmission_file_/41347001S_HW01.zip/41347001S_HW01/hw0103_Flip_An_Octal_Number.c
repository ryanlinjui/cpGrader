#include <stdio.h>
#include <stdint.h>

int main(){
    uint16_t num=0,savenum=0;
    uint32_t reverse_o=0,reverse_o_to_d=0,save_reverse_o=0;
    //get input
    printf("Please enter an unsigned 16-bits number: ");
    if(scanf("%hu",&num)!=1){
        printf("Invalid input.\n");
        return 0;
    }

    
    savenum=num;
    if(num>0){
        reverse_o=num%8;
        num=num/8;
    }
    if(num>0){
        reverse_o=reverse_o*10+num%8;
        num=num/8;
    }
    if(num>0){
        reverse_o=reverse_o*10+num%8;
        num=num/8;
    }
    if(num>0){
        reverse_o=reverse_o*10+num%8;
        num=num/8;
    }
    if(num>0){
        reverse_o=reverse_o*10+num%8;
        num=num/8;
    }
    if(num>0){
        reverse_o=reverse_o*10+num%8;
        num=num/8;
    }

    // get reverse value
    save_reverse_o=reverse_o;
    if(reverse_o>0){
        reverse_o_to_d=reverse_o_to_d+(reverse_o%10)*1;
        reverse_o=reverse_o/10;
    }
    if(reverse_o>0){
        reverse_o_to_d=reverse_o_to_d+(reverse_o%10)*8;
        reverse_o=reverse_o/10;
    }
    if(reverse_o>0){
        reverse_o_to_d=reverse_o_to_d+(reverse_o%10)*8*8;
        reverse_o=reverse_o/10;
    }
    if(reverse_o>0){
        reverse_o_to_d=reverse_o_to_d+(reverse_o%10)*8*8*8;
        reverse_o=reverse_o/10;
    }
    if(reverse_o>0){
        reverse_o_to_d=reverse_o_to_d+(reverse_o%10)*8*8*8*8;
        reverse_o=reverse_o/10;
    }
    if(reverse_o>0){
        reverse_o_to_d=reverse_o_to_d+(reverse_o%10)*8*8*8*8*8;
        reverse_o=reverse_o/10;
    }
    if(reverse_o>0){
        reverse_o_to_d=reverse_o_to_d+(reverse_o%10)*8*8*8*8*8*8;
        reverse_o=reverse_o/10;
    }

    
    //print answer
    printf("Before flip:\n");
    printf("%d_10 = %o_8\n",savenum,savenum);
    printf("After flip:\n");
    printf("%d_8 = %d_10\n",save_reverse_o,reverse_o_to_d);
    
    return 0;
}