#include <stdio.h>
#include <stdint.h>

#define E15 32768
#define E14 16384
#define E13 8192
#define E12 4096
#define E11 2048
#define E10 1024
#define E9 512
#define E8 256
#define E7 128
#define E6 64
#define E5 32
#define E4 16
#define E3 8
#define E2 4
#define E1 2
#define E0 1

int main(){
    uint32_t num=0,option=0,savenum,ansnum=0;
    int16_t bi0=0,bi1=0,bi2=0,bi3=0,bi4=0,bi5=0,bi6=0,bi7=0,bi8=0;
    int16_t bi9=0,bi10=0,bi11=0,bi12=0,bi13=0,bi14=0,bi15=0;
    float fraction=0;
    int16_t sign=0,exp=0;
    
    printf("Please input a hex:");
    if(!scanf("%X",&num)){
        printf("Invalid input.\n");
        return 0;
    }
    savenum=num;
    printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
    if(!scanf("%d",&option)||option>3||option<1){
        printf("Invalid input. The input must be an integer between 1 and 3.\n");
        return 0;
    }
    // printf("%d\n",num);

    //get binary number
    bi0=num%2;
    num=num/2;
    bi1=num%2;
    num=num/2;
    bi2=num%2;
    num=num/2;
    bi3=num%2;
    num=num/2;
    bi4=num%2;
    num=num/2;
    bi5=num%2;
    num=num/2;
    bi6=num%2;
    num=num/2;
    bi7=num%2;
    num=num/2;
    bi8=num%2;
    num=num/2;
    bi9=num%2;
    num=num/2;
    bi10=num%2;
    num=num/2;
    bi11=num%2;
    num=num/2;
    bi12=num%2;
    num=num/2;
    bi13=num%2;
    num=num/2;
    bi14=num%2;
    num=num/2;
    bi15=num%2;
    num=num/2;

    num=savenum;

    printf("Binary of %04X is: ",num);
    printf("%d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",bi15,bi14,bi13,bi12,bi11,bi10,bi9,bi8,bi7,bi6,bi5,bi4,bi3,bi2,bi1,bi0);

    if (option==1){
        printf("Converted integer is: ");
        ansnum=bi15*-E15;
        ansnum+=bi14*E14;
        ansnum+=bi13*E13;
        ansnum+=bi12*E12;
        ansnum+=bi11*E11;
        ansnum+=bi10*E10;
        ansnum+=bi9*E9;
        ansnum+=bi8*E8;
        ansnum+=bi7*E7;
        ansnum+=bi6*E6;
        ansnum+=bi5*E5;
        ansnum+=bi4*E4;
        ansnum+=bi3*E3;
        ansnum+=bi2*E2;
        ansnum+=bi1*E1;
        ansnum+=bi0*E0;
        printf("%d\n",ansnum);
    }
    else if (option==2){
        printf("Converted unsigned integer is:");
        printf("%d\n",num);
    }
    else if (option==3){
        if(bi15==1){
            sign=-1;
        }
        else{
            sign=1;
        }
        exp=(bi14*E4+bi13*E3+bi12*E2+bi11*E1+bi10*E0);
        fraction = (bi9 * 1.0 / E1) + (bi8 * 1.0 / E2) + (bi7 * 1.0 / E3);
        fraction += (bi6 * 1.0 / E4) + (bi5 * 1.0 / E5) + (bi4 * 1.0 / E6);
        fraction += (bi3 * 1.0 / E7) + (bi2 * 1.0 / E8) + (bi1 * 1.0 / E9) + (bi0 * 1.0 / E10);
        
        printf("Converted float is: ");
        if(fraction==0){
            if((exp-15)==16){
                if(sign==1){
                    printf("+INF\n");
                }
                else{
                    printf("-INF\n");
                }
            }
            else if(exp==0){
                if(sign==1){
                    printf("+0.0\n");
                }
                else{
                    printf("-0.0\n");
                }
            }
            else{
                printf("%f*2^%d\n",sign*(E0+fraction),exp-15);
            }
        }
        else if(fraction!=0&&(exp-15)==16){
            printf("NAN\n");
        }
        else{
            printf("%f*2^%d\n",sign*(E0+fraction),exp-15);
        }
        
    }

    return 0;
}