#include <stdio.h>
#include <stdint.h>

int main(){
    int32_t a=0,b=0,c=0;
    int32_t x=0,y=0,z=0;
    int32_t sum=0;
    int32_t num1=0,num2=0;

    //input
    printf("Please enter the first  operand: ");
    if(scanf("%dx%d", &a, &b)!=2){
        printf("Invalid input: Please follow the format 'axb', where 'a' and 'b' are digits.\n");
        return 0;
    }
    if(a < 0 || a > 9 || b < 0 || b > 9){
        printf("Invalid input: Both 'a' and 'b' must be digits between 0 and 9.\n");
        return 0;
    }

    printf("Please enter the second operand: ");
    if(scanf(" y%dz", &c) != 1){
        printf("Invalid input: Please follow the format 'ycz', where 'c' is a digit.\n");
        return 0;
    }
    if(c < 0 || c > 9){
        printf("Invalid input: 'c' must be a digit between 0 and 9.\n");
        return 0;
    }

    printf("Please enter the sum           : ");
    if(scanf("%d", &sum) != 1){
        printf("Invalid input: The sum must be an integer.\n");
        return 0;
    }
    if(sum < 0){  
        printf("Invalid input: The sum must be non-negative.\n");
        return 0;
    }

    //get answer
    num1=100*a+10*c+b;
    num2=sum-num1;
    z=num2%10;
    x=(num2/10)%10;
    y=(num2/100);
    if(x<0||y<0||z<0||x>9||y>9||z>9){
        printf("Invalid Input. The answers of x,y and z must be digits between 0 and 9.\n");
        return 0;
    }
    //print answer
    printf("Ans: x = %d, y = %d, z = %d\n",x,y,z);

    return 0;
}