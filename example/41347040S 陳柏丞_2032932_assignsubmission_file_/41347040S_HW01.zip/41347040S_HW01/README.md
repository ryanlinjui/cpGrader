# Homework Program Developed by CBC
Created by 41347040S 陳柏丞

## How to Build
Use the following single command to build the program:
```bash
make
```

## How to Execute the Code
The executable files are named according to the format `hwXXYY`, where `XX` represents the homework number and `YY` represents the problem number. For example, `hw0102` is the executable for homework #1, problem 2.
```bash
./hw0102
```

## Executable Programs
After running the `make` command, six executable files will be produced. They can be executed with the following commands:
```bash
./hw0101
./hw0102
./hw0103
./hw0104
./hw0105
./b
```
The file named `b` indicates that errors in `a.c` were ignored during compilation.