#include <stdio.h>
#include <stdint.h>

int main(){

    int32_t n1_hand = -1;
    int32_t n1_one = -1;

    int32_t n2_ten = -1;

    int32_t sum = -1;

    printf("%-31s: ","Please enter the first  operand");
    scanf("%dx%d",&n1_hand,&n1_one);

    printf("%-31s: ","Please enter the second operand");
    scanf("\ny%dz",&n2_ten);

    printf("%-31s: ","Please enter the sum");
    scanf("%d",&sum);

    if( n1_hand > 9 || n1_hand < 0 ||
        n1_one > 9 || n1_one < 0 ||
        n2_ten > 9 || n2_ten < 0 )
        {
            printf("I think your input is kinda wrong, so I leaf.\n");
            return 0;
        }
        
    int32_t x=0,y=0,z=0;
    z = sum % 10 - n1_one;
    if(z<0){
        z+=10;
        x--;
    }
    x += (sum % 100) / 10 - n2_ten;
    if(x<0){
        x+=10;
        y--;
    }
    y += (sum / 100) - n1_hand;

    if(x>9 || x<0 || y>9 || y<0 || z>9 || z<0)
    {
        printf("I think your input is kinda wrong, so I leaf.\n");
        return 0;
    }

    printf("Ans: x = %d, y = %d, z = %d\n" , x, y, z);

    return 0;
}