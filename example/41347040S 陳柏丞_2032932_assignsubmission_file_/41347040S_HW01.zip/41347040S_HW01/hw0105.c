#include <stdio.h>
#include <stdint.h>

int main(){
    
    int32_t hex_in = -1;

    printf("Please input a hex:");
    scanf("%x",&hex_in);

    if(hex_in == -1){
        printf("Ya know? Your input is kinda weird.\n");
        return 0;
    }

    uint16_t hex = hex_in;
    uint8_t output_type = 0;

    printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
    scanf("%hhd",&output_type);

    if(output_type < 1 || output_type > 3)
    {
        printf("No kinda type, bye.");
        return 0;
    }

    uint8_t bin_1, bin_2, bin_3, bin_4, bin_5, bin_6, bin_7, bin_8;
    uint8_t bin_9, bin_10, bin_11, bin_12, bin_13, bin_14, bin_15, bin_16;

    bin_1 = hex / 32768 % 2;
    bin_2 = hex / 16384 % 2;
    bin_3 = hex / 8192 % 2;
    bin_4 = hex / 4096 % 2;
    bin_5 = hex / 2048 % 2;
    bin_6 = hex / 1024 % 2;
    bin_7 = hex / 512 % 2;
    bin_8 = hex / 256 % 2;
    bin_9 = hex / 128 % 2;
    bin_10 = hex / 64 % 2;
    bin_11 = hex / 32 % 2;
    bin_12 = hex / 16 % 2;
    bin_13 = hex / 8 % 2;
    bin_14 = hex / 4 % 2;
    bin_15 = hex / 2 % 2;
    bin_16 = hex % 2;

    printf("Binary of %hX is: %hhd%hhd%hhd%hhd %hhd%hhd%hhd%hhd %hhd%hhd%hhd%hhd %hhd%hhd%hhd%hhd\n",
        hex,
        bin_1, bin_2, bin_3, bin_4, bin_5, bin_6, bin_7, bin_8,
        bin_9, bin_10, bin_11, bin_12, bin_13, bin_14, bin_15, bin_16);

    if(output_type == 1)
    {
        printf("Converted integer is: %hd\n",hex);
    }
    else if (output_type == 2)
    {
        printf("Converted unsigned integer is: %hu\n",hex);
    }
    else if (output_type == 3)
    {   

        int16_t exp = bin_2 * 16 + bin_3 * 8 + bin_4 * 4 + bin_5 * 2 + bin_6 - 15;

        double hexd = (double)bin_7 / 2 + (double)bin_8 / 4 + (double)bin_9 / 8 + (double)bin_10 / 16 + (double)bin_11 / 32 + (double)bin_12 / 64 + (double)bin_13 / 128 + (double)bin_14 / 256 + (double)bin_15 / 512 + (double)bin_16 / 1024;
        if(exp != -15){
            hexd += 1;
        }
        else{
            exp = -14;
        }

        //printf("hexd: %lf, exp: %hd\n",hexd,exp);
        printf("Converted float is: ");

        if(exp == 16 && hexd != 1){
            printf("NAN\n");
            return 0;
        }

        if(hex % 65536 / 32768){
            printf("-");
        }
        else if(exp == -14 && hexd == 0){
            printf("+");
        }
        if(exp == -14 && hexd == 0){
            printf("0.0");
        }
        else if(exp == 16 && hexd == 1){
            printf("INF");
        }
        else{
            printf("%lf*2^%hd", hexd , exp);
        }
        printf("\n");
    }
    
    

    return 0;
}