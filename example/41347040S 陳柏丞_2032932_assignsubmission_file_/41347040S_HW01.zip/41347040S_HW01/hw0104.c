#include <stdio.h>
#include <stdint.h>

int main(){
    
    uint8_t card1 = 0 ,card2 = 0 ,card3 = 0 ,card4 = 0 ,card5 = 0 ;

    printf("Please enter 5 cards: ");
    scanf("%hhd %hhd %hhd %hhd %hhd",&card1,&card2,&card3,&card4,&card5);

    uint8_t card_count = 1;

    if (card2 != card1) card_count++;
    if (card3 != card2 && card3 != card1) card_count++;
    if (card4 != card3 && card4 != card2 && card4 != card1) card_count++;
    if (card5 != card4 && card5 != card3 && card5 != card2 && card5 != card1) card_count++;

    if(
        card1 <= 0 || card1 >=53 ||
        card2 <= 0 || card2 >=53 ||
        card3 <= 0 || card3 >=53 ||
        card4 <= 0 || card4 >=53 ||
        card5 <= 0 || card5 >=53 ||
        card_count<5
    )
    {
        printf("I think we are playing different card game. Try again.\n");
        return 0;
    }
    //Sort

    // First
    if (card2 < card1) {
        uint8_t temp = card1;
        card1 = card2;
        card2 = temp;
    }
    if (card3 < card2) {
        uint8_t temp = card2;
        card2 = card3;
        card3 = temp;
    }
    if (card4 < card3) {
        uint8_t temp = card3;
        card3 = card4;
        card4 = temp;
    }
    if (card5 < card4) {
        uint8_t temp = card4;
        card4 = card5;
        card5 = temp;
    }

    // Second
    if (card2 < card1) {
        uint8_t temp = card1;
        card1 = card2;
        card2 = temp;
    }
    if (card3 < card2) {
        uint8_t temp = card2;
        card2 = card3;
        card3 = temp;
    }
    if (card4 < card3) {
        uint8_t temp = card3;
        card3 = card4;
        card4 = temp;
    }

    // Third
    if (card2 < card1) {
        uint8_t temp = card1;
        card1 = card2;
        card2 = temp;
    }
    if (card3 < card2) {
        uint8_t temp = card2;
        card2 = card3;
        card3 = temp;
    }

    // Forth
    if (card2 < card1) {
        uint8_t temp = card1;
        card1 = card2;
        card2 = temp;
    }

    //Sort compledted

    /*type
        0 for ♠
        1 for ♡
        2 for ♢
        3 for ♣
    */
    uint8_t type1 ,type2 ,type3 ,type4 ,type5 ;
    uint8_t value1,value2,value3,value4,value5;
    uint8_t value_count = 1;
    uint8_t type_count = 1;

    type1 = (card1 - 1) / 13;
    value1 = card1 % 13;
    if (value1 == 0) value1 = 13;

    type2 = (card2 - 1) / 13;
    value2 = card2 % 13;
    if (value2 == 0) value2 = 13;
    if (value2 != value1) value_count++ ;
    if (type2 != type1) type_count++;

    type3 = (card3 - 1) / 13;
    value3 = card3 % 13;
    if (value3 == 0) value3 = 13;
    if (value3 != value2 && value3 != value1) value_count++ ;
    if (type3 != type2) type_count++;

    type4 = (card4 - 1) / 13;
    value4 = card4 % 13;
    if (value4 == 0) value4 = 13;
    if (value4 != value3 && value4 != value2 && value4 != value1) value_count++ ;
    if (type4 != type3) type_count++;

    type5 = (card5 - 1) / 13;
    value5 = card5 % 13;
    if (value5 == 0) value5 = 13;
    if (value5 != value4 && value5 != value3 && value5 != value2 && value5 != value1) value_count++ ;
    if (type5 != type4) type_count++;

    //Straight Flush
    if(
        type_count == 1 && 
        (
            type1 == type2 && type2 == type3 && type3 == type4 && type4 == type5 && value2 - value1 == 1 && value3 - value2 == 1 && value4 - value3 == 1 && value5 - value4 == 1 ||
            value1 == 1 && value2 == 10 && value3 == 11 && value4 == 12 && value5 == 13
        )
        )
        {
            printf("Straight Flush\n");
            return 0;
        }

    //Four of a kind
    uint8_t same_count = 0;
    uint8_t different_count = 0;

    if(value1 == value2)same_count++;
    else different_count++;
    if(value1 == value3)same_count++;
    else different_count++;
    if(value1 == value4)same_count++;
    else different_count++;
    if(value1 == value5)same_count++;
    else different_count++;

    if( value_count == 2 && type_count==4 && 
        (
            (same_count == 0 && different_count==4) || (same_count==3 && different_count==1)
        )
        )
    {
        printf("Four Of A Kind\n");
        return 0;
    }

    //Full house
    if( 
        value_count == 2 &&
        ( 
            (same_count == 2 && different_count == 2) || (same_count == 1 && different_count == 3)
        ) 
        )
    {
        printf("Full House\n");
        return 0;
    }

    //Flush
    if(type1 == type2 && type2 == type3 && type3 == type4 && type4 == type5)
    {
        printf("Flush\n");
        return 0;
    }

    //Straight
    uint8_t value1_S = value1,value2_S = value2,value3_S = value3,value4_S = value4 ,value5_S = value5;
    if (value2_S < value1_S) {
        uint8_t temp = value1_S;
        value1_S = value2_S;
        value2_S = temp;
    }
    if (value3_S < value2_S) {
        uint8_t temp = value2_S;
        value2_S = value3_S;
        value3_S = temp;
    }
    if (value4_S < value3_S) {
        uint8_t temp = value3_S;
        value3_S = value4_S;
        value4_S = temp;
    }
    if (value5_S < value4_S) {
        uint8_t temp = value4_S;
        value4_S = value5_S;
        value5_S = temp;
    }

    if (value2_S < value1_S) {
        uint8_t temp = value1_S;
        value1_S = value2_S;
        value2_S = temp;
    }
    if (value3_S < value2_S) {
        uint8_t temp = value2_S;
        value2_S = value3_S;
        value3_S = temp;
    }
    if (value4_S < value3_S) {
        uint8_t temp = value3_S;
        value3_S = value4_S;
        value4_S = temp;
    }

    if (value2_S < value1_S) {
        uint8_t temp = value1_S;
        value1_S = value2_S;
        value2_S = temp;
    }
    if (value3_S < value2_S) {
        uint8_t temp = value2_S;
        value2_S = value3_S;
        value3_S = temp;
    }

    if (value2_S < value1_S) {
        uint8_t temp = value1_S;
        value1_S = value2_S;
        value2_S = temp;
    }

    if(value2_S - value1_S == 1 && value3_S - value2_S == 1 && value4_S - value3_S == 1 && value5_S - value4_S == 1 ||
        value1_S == 1 && value2_S == 10 && value3_S == 11 && value4_S == 12 && value5_S == 13
    )
    {
        printf("Straight\n");
        return 0;
    }

    //Three of a kind

    if( value_count == 3 &&
        (
            (value1 == value2 && value2 == value3) ||
            (value1 == value2 && value2 == value4) ||
            (value1 == value2 && value2 == value5) ||
            (value1 == value3 && value3 == value4) ||
            (value1 == value3 && value3 == value5) ||
            (value1 == value4 && value4 == value5) ||
            (value2 == value3 && value3 == value4) ||
            (value2 == value3 && value3 == value5) ||
            (value2 == value4 && value4 == value5) ||
            (value3 == value4 && value4 == value5)
        )
        )
    {
        printf("Three Of A Kind\n");
        return 0;
    }

    //Two pair
    if( value_count == 3 )
    {
        printf("Two Pair\n");
        return 0;
    }

    //One pair
    if(value_count == 4){
        printf("One Pair\n");
        return 0;
    }

    printf("High Card\n");
    return 0;
}