#include <stdio.h>
#include <stdint.h>

int main(){

    int32_t number_in = -1;

    printf("Please enter an unsigned 16-bits number:");
    scanf("%d", &number_in);

    if(number_in == -1){
        printf("Hmmmmm, it's strange.\n");
        return 0;
    }
    uint16_t number = number_in;

    printf("Before Flip:\n");
    printf("%d_10 = %o_8\n",number,number);

    uint8_t oct_5, oct_4, oct_3, oct_2, oct_1, oct_0;

    oct_5 = (number % 262144) / 32768;
    oct_4 = (number % 32768) / 4096;
    oct_3 = (number % 4096) / 512;
    oct_2 = (number % 512) / 64;
    oct_1 = (number % 64) / 8;
    oct_0 = (number % 8);

    uint32_t multiplier = 1;
    uint32_t fliped_number = 0;

    if(oct_5 != 0){
        fliped_number += oct_5 * multiplier;
        multiplier*=8;
    }
    if(oct_4 != 0){
        fliped_number += oct_4 * multiplier;
        multiplier*=8;
    }
    if(oct_3 != 0){
        fliped_number += oct_3 * multiplier;
        multiplier*=8;
    }
    if(oct_2 != 0){
        fliped_number += oct_2 * multiplier;
        multiplier*=8;
    }
    if(oct_1 != 0){
        fliped_number += oct_1 * multiplier;
        multiplier*=8;
    }
    if(oct_0 != 0){
        fliped_number += oct_0 * multiplier;
        multiplier*=8;
    }
    
    printf("After Flip:\n");
    printf("%o_8 = %d_10\n",fliped_number,fliped_number);

    return 0;
}