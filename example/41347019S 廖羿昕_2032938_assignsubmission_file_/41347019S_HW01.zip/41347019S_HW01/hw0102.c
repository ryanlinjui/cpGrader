#include<stdio.h>
#include<stdint.h>

int main()
{
    int32_t a,b,c,sum,x,y,z;
    printf("Please enter the first operand:\n");
    scanf("%dx%d",&a,&b);
    printf("Please enter the second operand:\n");
    scanf("\ny%dz",&c);
    printf("Please enter the sum\n");
    scanf("%d",&sum);
    if(a<0 || b<0 || c<0 || a>9 || b>9 || c>9)
    {
    	printf("error\n");
    }
    else
    {
    	if(a>=10||a<=0||b>=10||b<=0||c>=10||c<=0)
    	{		
    		printf("error\n");
	}
	else
	{
		z=(sum%10)-b;
		if(z<0)
		{
		    z+=10;
		    sum-=10;
		}
		sum=sum/10;
		x=(sum%10)-c;
		if(x<0)
		{
		    x+=10;
		    sum-=10;
		}
		y=sum/10-a;
		printf("x=%d,y=%d,z=%d\n",x,y,z);
	}
    }
    return 0;
}
