#include<stdio.h>
#include<stdint.h>

int main()
{
    int32_t c1,c2,c3,c4,c5,s1=1,s2=1,s3=1,s4=1,m,n;
    printf("Please enter 5 cards: ");
    scanf("%d%d%d%d%d",&c1,&c2,&c3,&c4,&c5);
    if(c1<1 || c2<1 || c3<1 || c4<1 || c5<1 || c1>52 || c2>52 || c3>52 || c4>52 || c5>52)
    {
    	printf("Invalid Input\n");
    }
    else if(c1==c2)
    {
    	printf("Invalid Input\n");
    }
    else if(c1==c3)
    {
    	printf("Invalid Input\n");
    }
    else if(c1==c4)
    {
    	printf("Invalid Input\n");
    }
    else if(c1==c5)
    {
    	printf("Invalid Input\n");
    }
    else if(c2==c3)
    {
    	printf("Invalid Input\n");
    }
    else if(c2==c4)
    {
    	printf("Invalid Input\n");
    }
    else if(c2==c5)
    {
    	printf("Invalid Input\n");
    }
    else if(c3==c4)
    {
    	printf("Invalid Input\n");
    }
    else if(c3==c5)
    {
    	printf("Invalid Input\n");
    }
    else if(c4==c5)
    {
    	printf("Invalid Input\n");
    }
    else
    {
    	if(c1%13==c2%13)
	    {
		s1+=1;
	    }
	    if(c1%13==c3%13)
	    {
		s1+=1;
	    }
	    if(c1%13==c4%13)
	    {
		s1+=1;
	    }
	    if(c1%13==c5%13)
	    {
		s1+=1;
	    }
	    if(c2%13==c3%13)
	    {
		s2+=1;
	    }
	    if(c2%13==c4%13)
	    {
		s2+=1;
	    }
	    if(c2%13==c5%13)
	    {
		s2+=1;
	    }
	    if(c3%13==c4%13)
	    {
		s3+=1;
	    }
	    if(c3%13==c5%13)
	    {
		s3+=1;
	    }
	    if(c4%13==c5%13)
	    {
		s4+=1;
	    }
	    if(s1==4 || s2==4)
	    {
	    	printf("Four of a kind\n");
	    }
	    else if(s1==3 || s2==3 || s3==3)
	    {
	    	if(s3==3)
	    	{
	    		if(c1%13==c2%13)
	    		{
	    			printf("Full house\n");
	    		}
	    		else
	    		{
	    			printf("Three of a kind\n");
	    		}
	    	}
	    	else if(s2==3)
	    	{
	    		if(c1%13==c3%13 || c1%13==c4%13 || c1%13==c5%13)
	    		{
	    			printf("Full house\n");
	    		}
	    		else
	    		{
	    			printf("Three of a kind\n");
	    		}
	    	}
	    	else
	    	{
	    		if(s2==2)
	    		{
	    			if(s3==2 || s4==2)
	    			{
	    				printf("Full house\n");
	    			}
	    			else
	    			{
	    				printf("Three of a kind\n");
	    			}
	    		}
	    		else
	    		{
	    			printf("Three of a kind\n");
	    		}
	    	}
	    }
	    else if(s1==2 || s2==2 || s3==2 || s4==2)
	    {
	    	if(s1==2&&s2==2 || s1==2&&s3==2 || s1==2&&s4==2 || s2==2&&s3==2 || s2==2&&s4==2 || s3==2&&s4==2)
	    	{
	    		printf("Two pair\n");
	    	}
	    	else
	    	{
	    		printf("One pair\n");
	    	}
	    }
	    else
	    {
	    	if(c1<=13 && c2<=13 && c3<=13 && c4<=13 && c5<=13)
	    	{
	    		c1=(c1-1)%13+1;
	    		c2=(c2-1)%13+1;
	    		c3=(c3-1)%13+1;
	    		c4=(c4-1)%13+1;
	    		c5=(c5-1)%13+1;
	    		m=c1;
	    		if(m<c2)
	    			m=c2;
	    		if(m<c3)
	    			m=c3;
	    		if(m<c4)
	    			m=c4;
	    		if(m<c5)
	    			m=c5;
	    		n=c1;
	    		if(n>c2)
	    			n=c2;
	    		if(n>c3)
	    			n=c3;
	    		if(n>c4)
	    			n=c4;
	    		if(n>c5)
	    			n=c5;
	    		if(m-n==4)
	    		{
	    			printf("Straight flush\n");
	    		}
	    		else if(m==13 && n==1)
	    		{
	    			if(c1==12 || c2==12 || c3==12 || c4==12 || c5==12)
	    			{
	    				if(c1==10 || c2==10 || c3==10 || c4==10 || c5==10)
	    				{
	    					if(c1==11 || c2==11 || c3==11 || c4==11 || c5==11)
	    					{
	    						printf("Straight flush\n");
	    					}
	    					else
			    			{
			    				printf("Flush\n");
			    			}
	    				}
	    				else
		    			{
		    				printf("Flush\n");
		    			}
	    			}
	    			else
	    			{
	    				printf("Flush\n");
	    			}
	    		}
	    		else
	    		{
	    			printf("Flush\n");
	    		}
	    	}
	    	else if(c1<=26 && c2<=26 && c3<=26 && c4<=26 && c5<=26 && c1>13 && c2>13 && c3>13 && c4>13 && c5>13)
	    	{
	    		c1=(c1-1)%13+1;
	    		c2=(c2-1)%13+1;
	    		c3=(c3-1)%13+1;
	    		c4=(c4-1)%13+1;
	    		c5=(c5-1)%13+1;
	    		m=c1;
	    		if(m<c2)
	    			m=c2;
	    		if(m<c3)
	    			m=c3;
	    		if(m<c4)
	    			m=c4;
	    		if(m<c5)
	    			m=c5;
	    		n=c1;
	    		if(n>c2)
	    			n=c2;
	    		if(n>c3)
	    			n=c3;
	    		if(n>c4)
	    			n=c4;
	    		if(n>c5)
	    			n=c5;
	    		if(m-n==4)
	    		{
	    			printf("Straight flush\n");
	    		}
	    		else if(m==13 && n==1)
	    		{
	    			if(c1==12 || c2==12 || c3==12 || c4==12 || c5==12)
	    			{
	    				if(c1==10 || c2==10 || c3==10 || c4==10 || c5==10)
	    				{
	    					if(c1==11 || c2==11 || c3==11 || c4==11 || c5==11)
	    					{
	    						printf("Straight flush\n");
	    					}
	    					else
			    			{
			    				printf("Flush\n");
			    			}
	    				}
	    				else
		    			{
		    				printf("Flush\n");
		    			}
	    			}
	    			else
	    			{
	    				printf("Flush\n");
	    			}
	    		}
	    		else
	    		{
	    			printf("Flush\n");
	    		}
	    	}
	    	else if(c1<=39 && c2<=39 && c3<=39 && c4<=39 && c5<=39 && c1>26 && c2>26 && c3>26 && c4>26 && c5>26)
	    	{
	    		c1=(c1-1)%13+1;
	    		c2=(c2-1)%13+1;
	    		c3=(c3-1)%13+1;
	    		c4=(c4-1)%13+1;
	    		c5=(c5-1)%13+1;
	    		m=c1;
	    		if(m<c2)
	    			m=c2;
	    		if(m<c3)
	    			m=c3;
	    		if(m<c4)
	    			m=c4;
	    		if(m<c5)
	    			m=c5;
	    		n=c1;
	    		if(n>c2)
	    			n=c2;
	    		if(n>c3)
	    			n=c3;
	    		if(n>c4)
	    			n=c4;
	    		if(n>c5)
	    			n=c5;
	    		if(m-n==4)
	    		{
	    			printf("Straight flush\n");
	    		}
	    		else if(m==13 && n==1)
	    		{
	    			if(c1==12 || c2==12 || c3==12 || c4==12 || c5==12)
	    			{
	    				if(c1==10 || c2==10 || c3==10 || c4==10 || c5==10)
	    				{
	    					if(c1==11 || c2==11 || c3==11 || c4==11 || c5==11)
	    					{
	    						printf("Straight flush\n");
	    					}
	    					else
			    			{
			    				printf("Flush\n");
			    			}
	    				}
	    				else
		    			{
		    				printf("Flush\n");
		    			}
	    			}
	    			else
	    			{
	    				printf("Flush\n");
	    			}
	    		}
	    		else
	    		{
	    			printf("Flush\n");
	    		}
	    	}
	    	else if(c1<=52 && c2<=52 && c3<=52 && c4<=52 && c5<=52 && c1>39 && c2>39 && c3>39 && c4>39 && c5>39)
	    	{
	    		c1=(c1-1)%13+1;
	    		c2=(c2-1)%13+1;
	    		c3=(c3-1)%13+1;
	    		c4=(c4-1)%13+1;
	    		c5=(c5-1)%13+1;
	    		m=c1;
	    		if(m<c2)
	    			m=c2;
	    		if(m<c3)
	    			m=c3;
	    		if(m<c4)
	    			m=c4;
	    		if(m<c5)
	    			m=c5;
	    		n=c1;
	    		if(n>c2)
	    			n=c2;
	    		if(n>c3)
	    			n=c3;
	    		if(n>c4)
	    			n=c4;
	    		if(n>c5)
	    			n=c5;
	    		if(m-n==4)
	    		{
	    			printf("Straight flush\n");
	    		}
	    		else if(m==13 && n==1)
	    		{
	    			if(c1==12 || c2==12 || c3==12 || c4==12 || c5==12)
	    			{
	    				if(c1==10 || c2==10 || c3==10 || c4==10 || c5==10)
	    				{
	    					if(c1==11 || c2==11 || c3==11 || c4==11 || c5==11)
	    					{
	    						printf("Straight flush\n");
	    					}
	    					else
			    			{
			    				printf("Flush\n");
			    			}
	    				}
	    				else
		    			{
		    				printf("Flush\n");
		    			}
	    			}
	    			else
	    			{
	    				printf("Flush\n");
	    			}
	    		}
	    		else
	    		{
	    			printf("Flush\n");
	    		}
	    	}
	    	else
	    	{
	    		c1=(c1-1)%13+1;
	    		c2=(c2-1)%13+1;
	    		c3=(c3-1)%13+1;
	    		c4=(c4-1)%13+1;
	    		c5=(c5-1)%13+1;
	    		m=c1;
	    		if(m<c2)
	    			m=c2;
	    		if(m<c3)
	    			m=c3;
	    		if(m<c4)
	    			m=c4;
	    		if(m<c5)
	    			m=c5;
	    		n=c1;
	    		if(n>c2)
	    			n=c2;
	    		if(n>c3)
	    			n=c3;
	    		if(n>c4)
	    			n=c4;
	    		if(n>c5)
	    			n=c5;
	    		if(m-n==4)
	    			printf("Straight\n");
	    		else if(m==13 && n==1)
	    		{
	    			if(c1==12 || c2==12 || c3==12 || c4==12 || c5==12)
	    			{
	    				if(c1==10 || c2==10 || c3==10 || c4==10 || c5==10)
	    				{
	    					if(c1==11 || c2==11 || c3==11 || c4==11 || c5==11)
	    					{
	    						printf("Straight\n");
	    					}
	    					else
			    			{
			    				printf("Flush\n");
			    			}
	    				}
	    				else
		    			{
		    				printf("Flush\n");
		    			}
	    			}
	    			else
	    			{
	    				printf("Flush\n");
	    			}
	    		}
	    		else
	    		{
	    			printf("High card\n");
	    		}
	    	}
	    }
    }
    
}
