#include<stdio.h>
#include<stdint.h>

int main()
{
    int32_t n,sn1=0,sn2=0,sn3=0,sn4=0,type,t;
    printf("Please input a hex: ");
    scanf("%X",&n);
    t=n;
    if(n>0)
    {
    	sn1=n%2;
    	n=n/2;
    }
    if(n>0)
    {
    	sn1=(n%2)*10+sn1;
    	n=n/2;
    }
    if(n>0)
    {
    	sn1=(n%2)*100+sn1;
    	n=n/2;
    }
    if(n>0)
    {
    	sn1=(n%2)*1000+sn1;
    	n=n/2;
    }
    if(n>0)
    {
    	sn2=n%2;
    	n=n/2;
    }
    if(n>0)
    {
    	sn2=(n%2)*10+sn2;
    	n=n/2;
    }
    if(n>0)
    {
    	sn2=(n%2)*100+sn2;
    	n=n/2;
    }
    if(n>0)
    {
    	sn2=(n%2)*1000+sn2;
    	n=n/2;
    }
    if(n>0)
    {
    	sn3=n%2;
    	n=n/2;
    }
    if(n>0)
    {
    	sn3=(n%2)*10+sn3;
    	n=n/2;
    }
    if(n>0)
    {
    	sn3=(n%2)*100+sn3;
    	n=n/2;
    }
    if(n>0)
    {
    	sn3=(n%2)*1000+sn3;
    	n=n/2;
    }
    if(n>0)
    {
    	sn4=n%2;
    	n=n/2;
    }
    if(n>0)
    {
    	sn4=(n%2)*10+sn4;
    	n=n/2;
    }
    if(n>0)
    {
    	sn4=(n%2)*100+sn4;
    	n=n/2;
    }
    if(n>0)
    {
    	sn4=(n%2)*1000+sn4;
    	n=n/2;
    }
    printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
    scanf("%d",&type);
    if(sn4==0)
    {
    	printf("Binary of %x is: 0000",t);
    }
    else if(sn4<10)
    {
    	printf("Binary of %x is: 000%d",t,sn4);
    }
    else if(sn4<100)
    {
    	printf("Binary of %x is: 00%d",t,sn4);
    }
    else if(sn4<1000)
    {
    	printf("Binary of %x is: 0%d",t,sn4);
    }
    else
    {
    	printf("Binary of %x is: %d",t,sn4);
    }
    if(sn3==0)
    {
    	printf(" 0000");
    }
    else if(sn3<10)
    {
    	printf(" 000%d",sn3);
    }
    else if(sn3<100)
    {
    	printf(" 00%d",sn3);
    }
    else if(sn3<1000)
    {
    	printf(" 0%d",sn3);
    }
    else
    {
    	printf(" %d",sn3);
    }
    if(sn2==0)
    {
    	printf(" 0000");
    }
    else if(sn2<10)
    {
    	printf(" 000%d",sn2);
    }
    else if(sn2<100)
    {
    	printf(" 00%d",sn2);
    }
    else if(sn2<1000)
    {
    	printf(" 0%d",sn2);
    }
    else
    {
    	printf(" %d",sn2);
    }
    if(sn1==0)
    {
    	printf(" 0000\n");
    }
    else if(sn1<10)
    {
    	printf(" 000%d\n",sn1);
    }
    else if(sn1<100)
    {
    	printf(" 00%d\n",sn1);
    }
    else if(sn1<1000)
    {
    	printf(" 0%d\n",sn1);
    }
    else
    {
    	printf(" %d\n",sn1);
    }
    if(type==1)
    {
    	if(sn4/1000==0)
    	{
    		printf("Converted integer is: %d\n",t);
    	}
    	else
    	{
    		t=t-1;
    		if(t%2==0 && t>0)
    			sn1=1;
    		else
    			sn1=0;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn1=sn1+10;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn1=sn1+100;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn1=sn1+1000;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn2=1;
    		else
    			sn2=0;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn2=sn2+10;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn2=sn2+100;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn2=sn2+1000;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn3=1;
    		else
    			sn3=0;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn3=sn3+10;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn3=sn3+100;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn3=sn3+1000;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn4=1;
    		else
    			sn4=0;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn4=sn4+10;
    		t=t/10;
    		if(t%2==0 && t>0)
    			sn4=sn4+100;
    		t=t/2;
    		if(t%2==0 && t>0)
    			sn4=sn4+1000;
    		printf("%d %d %d %d\n",sn4,sn3,sn2,sn1);
    		t=t/10;
    		t=sn1%10;
    		sn1=sn1/10;
    		t=t+sn1%10*2;
    		sn1=sn1/10;
    		t=t+sn1%10*4;
    		sn1=sn1/10;
    		t=t+sn1%10*8;
    		t=t+sn2%10*16;
    		sn2=sn2/10;
    		t=t+sn2%10*32;
    		sn2=sn2/10;
    		t=t+sn2%10*64;
    		sn2=sn2/10;
    		t=t+sn2%10*128;
    		t=t+sn3%10*256;
    		sn3=sn3/10;
    		t=t+sn3%10*512;
    		sn3=sn3/10;
    		t=t+sn3%10*1024;
    		sn3=sn3/10;
    		t=t+sn3%10*2048;
    		t=t+sn4%10*4096;
    		sn4=sn4/10;
    		t=t+sn4%10*8192;
    		sn4=sn4/10;
    		t=t+sn4%10*16384;
    		sn4=sn4/10;
    		t=t+sn4%10*32768;
    		printf("Converted integer is: -%d\n",t);
    	}
    }
    else if(type==2)
    {
    	printf("Converted unsigned integer is: %d\n",t);
    }
    else
    {
    	float f=1;
    	int32_t s=0,exp=0;
    	s=(sn4%1000)*100+sn3/100;
    	exp=s/10000*16+s%10;
    	s=s/10;
    	exp=s%10*2+exp;
    	s=s/10;
    	exp=s%10*4+exp;
    	s=s/10;
    	exp=s%10*8+exp;
    	s=sn3%100*100000000+sn2*10000+sn1;
    	if(s%10==1)
    		f=f+0.0009765625;
    	s=s/10;
    	if(s%10==1)
    		f=f+0.001953125;
    	s=s/10;
    	if(s%10==1)
    		f=f+0.00390625;
    	s=s/10;
    	if(s%10==1)
    		f=f+0.0078125;
    	s=s/10;
    	if(s%10==1)
    		f=f+0.015625;
    	s=s/10;
    	if(s%10==1)
    		f=f+0.03125;
    	s=s/10;
    	if(s%10==1)
    		f=f+0.0625;
    	s=s/10;
    	if(s%10==1)
    		f=f+0.125;
    	s=s/10;
    	if(s%10==1)
    		f=f+0.25;
    	s=s/10;
    	if(s%10==1)
    		f=f+0.5;
    	if(sn4/1000==0)
    	{
    		printf("Converted float is: %f*2^%d\n",f,exp-15);
    	}
    	else
    	{
    		printf("Converted float is: -%f*2^%d\n",f,exp-15);
    	}
    }
    
}
