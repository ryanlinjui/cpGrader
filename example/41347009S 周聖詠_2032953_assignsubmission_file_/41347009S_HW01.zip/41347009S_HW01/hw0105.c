#include<stdio.h>
#include<stdint.h>

int main(){
	uint32_t hexinput,option,test=0,a=0,b=0,c=0,d=0,e=0,f=0,g=0,h=0,i=0,j=0,k=0,l=0,m=0,n=0,o=0,p=0;
	printf("Please input a hex:");
	scanf("%x",&hexinput);
	int32_t hex = (int)hexinput;
	printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
	scanf("%d",&option);
	if(option!=1 && option!=2 && option!=3){
		printf("please input 1 or 2 or 3");
		return 0;
	}
	printf("Binary of %X is:",hexinput);
	if((hexinput/2)==0){
		a = hexinput%2;
	}
	if((hexinput/2)!=0){
		a = hexinput%2;
		hexinput/=2;
		if((hexinput/2)!=0){
			b = hexinput%2;
			hexinput/=2;
			if((hexinput/2)!=0){
				c = hexinput%2;
				hexinput/=2;
				if((hexinput/2)!=0){
					d = hexinput%2;
					hexinput/=2;
					if((hexinput/2)!=0){
						e = hexinput%2;
						hexinput/=2;
						if((hexinput/2)!=0){
							f = hexinput%2;
							hexinput/=2;
							if((hexinput/2)!=0){
								g = hexinput%2;
								hexinput/=2;
								if((hexinput/2)!=0){
									h = hexinput%2;
									hexinput/=2;
									if((hexinput/2)!=0){
										i = hexinput%2;
										hexinput/=2;
										if((hexinput/2)!=0){
											j = hexinput%2;
											hexinput/=2;
											if((hexinput/2)!=0){
												k = hexinput%2;
												hexinput/=2;
												if((hexinput/2)!=0){
													l = hexinput%2;
													hexinput/=2;
													if((hexinput/2)!=0){
														m = hexinput%2;
														hexinput/=2;
														if((hexinput/2)!=0){
															n = hexinput%2;
															hexinput/=2;
															if((hexinput/2)!=0){
																o = hexinput%2;
																hexinput/=2;
																if((hexinput/2)!=0){
																	p = hexinput%2;
																	hexinput/=2;
																}else p = hexinput%2;
															}else o = hexinput%2;
														}else n = hexinput%2;
													}else m = hexinput%2;
												}else l = hexinput%2;
											}else k = hexinput%2;
										}else j = hexinput%2;
									}else i = hexinput%2;
								}else h = hexinput%2;
							}else g = hexinput%2;
						}else f = hexinput%2;
					}else e = hexinput%2;
				}else d = hexinput%2;
			}else c = hexinput%2;
		}else b = hexinput%2;	
	}
	printf("%d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",p,o,n,m,l,k,j,i,h,h,f,e,d,c,b,a);
	if(option==1){
	//	int32_t hex = (int)hexinput;
		if(p==1){
			if(a) a=0;else a=1;
			if(b) b=0;else b=1;
			if(c) c=0;else c=1;
			if(d) d=0;else d=1;
			if(e) e=0;else e=1;
			if(f) f=0;else f=1;
			if(g) g=0;else g=1;
			if(h) h=0;else h=1;
			if(i) i=0;else i=1;
			if(j) j=0;else j=1;
			if(k) k=0;else k=1;
			if(l) l=0;else l=1;
			if(m) m=0;else m=1;
			if(n) n=0;else n=1;
			if(o) o=0;else o=1;
			if(p) p=0;else p=1;
			a+=1;
			if(a==2){
				a=0;
				b+=1;
				if(b==2){
					b=0;
					c+=1;
					if(c==2){
						c=0;
						d+=1;
						if(d==2){
							d=0;
							e+=1;
							if(e==2){
								e=0;
								f+=1;
								if(f==2){
									f=0;
									g+=1;
									if(g==2){
										g=0;
										h+=1;
										if(h==2){
											h=0;
											i+=1;
											if(i==2){
												i=0;
												j+=1;
												if(j==2){
													j=0;
													k+=1;
													if(k==2){
														k=0;
														l+=1;
														if(l==2){
															l=0;
															m+=1;
															if(m==2){
																m=0;
																n+=1;
																if(n==2){
																	n=0;
																	o+=1;
																	if(o==2){
																		o=0;
																		p+=1;
																		if(p==2){
																			p=0;
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			uint32_t           sum=0;
		        	      if(a==1) sum+=1;
		        	      if(b==1) sum+=2;
		        	     if(c==1) sum+=2*2;
		        	    if(d==1) sum+=2*2*2;
		        	   if(e==1) sum+=2*2*2*2;
		               	  if(f==1) sum+=2*2*2*2*2;
			         if(g==1) sum+=2*2*2*2*2*2;
		         	if(h==1) sum+=2*2*2*2*2*2*2;
			       if(i==1) sum+=2*2*2*2*2*2*2*2;
			      if(j==1) sum+=2*2*2*2*2*2*2*2*2;
			     if(k==1) sum+=2*2*2*2*2*2*2*2*2*2;
			    if(l==1) sum+=2*2*2*2*2*2*2*2*2*2*2;
			   if(m==1) sum+=2*2*2*2*2*2*2*2*2*2*2*2;
			  if(n==1) sum+=2*2*2*2*2*2*2*2*2*2*2*2*2;
			 if(o==1) sum+=2*2*2*2*2*2*2*2*2*2*2*2*2*2;
			if(p==1) sum+=2*2*2*2*2*2*2*2*2*2*2*2*2*2*2;
			printf("Converted integer is: -%d",sum);
		}
		else{
			printf("Converted integer is: %d",hex);
		}
	
	}
	if(option==2){
		uint32_t sum=0;
		if(a==1) sum+=1;
		if(b==1) sum+=2;
		if(c==1) sum+=2*2;
		if(d==1) sum+=2*2*2;
		if(e==1) sum+=2*2*2*2;
		if(f==1) sum+=2*2*2*2*2;
		if(g==1) sum+=2*2*2*2*2*2;
		if(h==1) sum+=2*2*2*2*2*2*2;
		if(i==1) sum+=2*2*2*2*2*2*2*2;
		if(j==1) sum+=2*2*2*2*2*2*2*2*2;
		if(k==1) sum+=2*2*2*2*2*2*2*2*2*2;
		if(l==1) sum+=2*2*2*2*2*2*2*2*2*2*2;
		if(m==1) sum+=2*2*2*2*2*2*2*2*2*2*2*2;
		if(n==1) sum+=2*2*2*2*2*2*2*2*2*2*2*2*2;
		if(o==1) sum+=2*2*2*2*2*2*2*2*2*2*2*2*2*2;
		if(p==1) sum+=2*2*2*2*2*2*2*2*2*2*2*2*2*2*2;
		printf("Converted unsigned integer is: %d",sum);
	}
	if(option==3){
		int32_t exp,flag=0;
		double F=0,pw=0.5;
		if(k==1) exp+=1;
		if(l==1) exp+=2;
		if(m==1) exp+=2*2;
		if(n==1) exp+=2*2*2;
		if(o==1) exp+=2*2*2*2;
		exp-=15;
		if(j==1) F+=0.5;
		pw/=2;
		//printf("%lf\n %d",F,j);
		if(i==1) F+=pw;
		pw/=2;
		//printf("%lf\n %d",F,i);
		if(h==1) F+=pw;
		pw/=2;
		//printf("%lf\n %d",F,h);
		if(g==1) F+=pw;
		pw/=2;
		//printf("%lf\n %d",F,g);
		if(f==1) F+=pw;
		pw/=2;
		//printf("%lf\n %d",F,f);
		if(e==1) F+=pw;
		pw/=2;
		//printf("%lf\n",F);
		if(d==1) F+=pw;
		pw/=2;
		//printf("%lf\n",F);
		if(c==1) F+=pw;
		pw/=2;
		//printf("%lf\n",F);
		if(b==1) F+=pw;
		pw/=2;
		//printf("%lf\n",F);
		if(a==1) F+=pw;
		if(exp==16 && F!=0){printf("Converted float is: NAN");return 0;}
		if(p==0){
			if(exp==-15 && F==0) {printf("Converted float is: +0.0");return 0;}
			if(exp==16 && F==0) {printf("Converted float is: +INF");return 0;}
			if(exp!=-15) F+=1;
			printf("Converted float is: %lf*2^%d",F,exp);
		}
		else if(p==1){
			if(exp==-15 && F==0) {printf("Converted float is: -0.0");return 0;}
			if(exp==16 && F==0) {printf("Converted float is: -INF");return 0;}
			if(exp!=-15) F+=1;
			printf("Converted float is: -%lf*2^%d",F,exp);
		}
	}
	/*test = hexinput%10;
	printf("decimal: %d\n",test);
	printf("hex: %x",test);*/
}
