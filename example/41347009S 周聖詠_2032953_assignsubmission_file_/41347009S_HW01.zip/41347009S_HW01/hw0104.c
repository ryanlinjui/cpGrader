#include<stdio.h>
#include<stdint.h>

int main(){

	int32_t a=0,b=0,c=0,d=0,e=0,flag=0,h=0,a1=0,b1=0,c1=0,d1=0,e1=0;
        printf("Please enter 5 cards: ");
        scanf("%d %d %d %d %d",&a,&b,&c,&d,&e);
        //printf("a: %d,b: %d,c: %d,d: %d,e: %d");
        //printf("%d%d%d%d%d\n",a,b,c,d,e);
	if((a==b||a==c||a==d||a==e||b==c||b==d||b==e||c==d||c==e||d==e)&&(a>52||b>52||c>52||d>52||e>52||a<=0||b<=0||c<=0||d<=0||e<=0)){
		printf("you can't enter the same poker and pleace enter the number between 1~52");
		return 0;
	}
        if(a>52||b>52||c>52||d>52||e>52||a<=0||b<=0||c<=0||d<=0||e<=0){
                printf("pleace enter the number between 1~52");
                return 0;
	}
	if(a==b||a==c||a==d||a==e||b==c||b==d||b==e||c==d||c==e||d==e){
		printf("you can't enter the same poker");
		return 0;
	}

	a--;
	b--;
	c--;
	d--;
	e--;
        a1 = (a)%13;
        b1 = (b)%13;
        c1 = (c)%13;
        d1 = (d)%13;
        e1 = (e)%13;
        if(a1 >= b1){
                flag = a1;
                a1 = b1;
                b1 = flag;
        }

        //printf("ans: %d%d%d%d%d\n",a,b,c,d,e);
        if(b1 >= c1){
                flag = b1;
                b1 = c1;
                c1 = flag;
        }
        //printf("ans: %d%d%d%d%d\n",a,b,c,d,e);
        //printf("ans: %d%d%d%d%d\n",a,b,c,d,e);
        //h = c>d;
        //printf("h: %d\n",h);
        if(c1 >= d1){
        //      printf("\nc: %d,d: %d ",c,d);
                flag = c1;
                c1 = d1;
                d1 = flag;
        }
        //printf("ans: %d%d%d%d%d\n",a,b,c,d,e);
        if(d1 >= e1){
                flag = d1;
                d1 = e1;
                e1 = flag;
        }
        //printf("ans: %d%d%d%d%d\n",a,b,c,d,e);
        if(a1 >= b1){
                flag = a1;
                a1 = b1;
                b1 = flag;
        }
        if(b1 >= c1){
                flag = b1;
                b1 = c1;
                c1 = flag;
        }
        if(c1 >= d1){
                flag = c1;
                c1 = d1;
                d1 = flag;
        }
        //printf("ans: %d%d%d%d%d\n",a,b,c,d,e);
        if(a1 >= b1){
                flag = a1;
                a1 = b1;
                b1 = flag;
        }
        if(b1 >= c1){
                flag = b1;
                b1 = c1;
                c1 = flag;
        }
        //printf("ans: %d%d%d%d%d\n",a,b,c,d,e);
        if(a1 >= b1){
                flag = a1;
                a1 = b1;
                b1 = flag;
        }
	flag=0;
	//printf("a1:%d ,b1:%d ,c1:%d ,d1:%d ,e1:%d\n",a1,b1,c1,d1,e1);
        if(a1==0 && b1==9 && c1==10 && d1==11 && e1==12){
                if(a/13==b/13 && b/13==c/13 && c/13==d/13 && d/13==e/13){
                        printf("Straight flush");
			flag=1;
			return 0;
                }
                else{
                        printf("Straight");
			flag=1;
			return 0;
                }
        }
	if(e1==d1+1 && d1==c1+1 && c1==b1+1 && b1==a1+1 && a/13==b/13 && b/13==c/13 && c/13==d/13 && d/13==e/13){
		printf("Straight flush");
		flag=1;
		return 0;
	}
	else if(a/13==b/13 && b/13==c/13 && c/13==d/13 && d/13==e/13){
		printf("Flush");
		flag=1;
		return 0;
	}
	else if(e1==d1+1 && d1==c1+1 && c1==b1+1 && b1==a1+1){
	       printf("Straight");
	       flag=1;
	       return 0;
	}              
	if((a1==b1 && b1==c1 && c1==d1 && d1!=e1) || (a1==b1 && b1==c1 && c1!=d1 && c1==e1) || (a1==b1 && b1!=c1 && b1==d1 && d1==e1) || (a1!=b1 && a1==c1 && c1==d1 && d1==e1) || (b1==c1 && c1==d1 && d1==e1)){
                printf("Four of a king");//four same
                flag=1;
                return 0;
        }
        if((a1==b1 && b1==c1 && d1==e1) || (a1==b1 && c1==d1 && d1==e1)){
                printf("Full house");//three same two same
                flag=1;
                return 0;
        }
        if((a1==b1 && b1==c1 && c1!=d1 && d1!=e1 && e1!=c1) || (a1!=b1 && b1==c1 && c1==d1 && d1!=e1) || (a1!=b1 && b1!=c1 && a1!=c1 && c1==d1 && d1==e1)){
                printf("Three of a kind");//three same
                flag=1;
                return 0;
        }
        if((a1==b1 && b1!=c1 && c1==d1 && d1!=e1) || (a1!=b1 && b1==c1 && c1!=d1 && d1==e1)){
                printf("Two pair");//two same two same
                flag=1;
                return 0;
        }
        if((a1==b1 && b1!=c1 && c1!=d1 && d1!=e1) || (a1!=b1 && b1==c1 && c1!=d1 && d1!=e1) || (a1!=b1 && b1!=c1 && c1==d1 && d1!=e1) || (a1!=b1 && b1!=c1 && c1!=d1 && d1==e1))	{
                printf("One pair");//one same
                flag=1;
                return 0;
        }
        if(flag==0){
                printf("High card");
                return 0;
        }
}


