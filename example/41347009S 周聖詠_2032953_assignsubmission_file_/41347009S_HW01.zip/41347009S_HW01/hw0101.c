#include<stdio.h>
#include<stdint.h>
#define red "\x1b[31m"
#define green "\x1b[32m"
#define blue "\x1b[34m"

int main(){
	printf(red"[KIM]\nYou are sunlight and I moon\nJoined by the gods of fortune\nMidnight and high noon sharing the sky\nWe have been blessed , you and I\n\n");	
	printf(blue"[CHRIS]\nYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\n\n");
	printf(red"[KIM]\nOutside day starts to dawn\n\n");
	printf(blue"[CHRIS]\nYour moon still floats on high\n\n");
	printf(red"[KIM]\nThe birds awake\n\n");
	printf(blue"[CHRIS]\nThe stars shine too\n\n");
	printf(red"[KIM]\nMy hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n\nYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho’s Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n\n");
	printf(blue"[CHRIS]\nI reach for you\n\n");
	printf(green"[KIM & CHRIS]\nAnd we meet in the sky\n\n");
	printf(red"[KIM]\nYou are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n\n");
	printf(green"[KIM & CHRIS]\nMade of\nSunlight\nMoonlight");

}
