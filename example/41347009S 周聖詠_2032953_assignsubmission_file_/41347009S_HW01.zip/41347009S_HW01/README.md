# Print Colorful Words
利用define red、green、blue定義紅綠藍的ANSI escape code，在每個要變顏色的文字前加上相應的red、green、blue來改變顏色
# A Simple Math Problem
將sum各個位數減去first operand和second operand的各個位數，並且從低位開始計算。遇到sum小於first operand或second operand時代表需要進位，因此將sum減10，(sum%10)加10後減first operand或second operand。

有排除sum<100、sum>1998、21x3、y3zz等特殊情況
# Flip an Octal Number
利用短除法將十進位轉換成八進位，並用fedcba儲存八進位的各個位數。
利用if、else去除掉尾數的0，並將abcdef倒過來印出。
利用各個位數乘以8^n將八進位轉換成十進位。
# Poker Hands
將輸入進來的數字減一後，用a1、b1、c1、d1、e1儲存mode 13的值，並用泡沫排序將a1、b1、c1、d1、e1由小排到大。最後經由if、else判斷是哪種類型的poker hands。

有排除輸入的值為相同牌以及不在1~52中的情況
# Binary Variable
利用短除法將十進位轉換成二進位，並用16個變數儲存二進位的各個位數。
根據作業中提供的資訊進行int、unsigned int、float的轉換

有排除選擇output type時輸入123之外的選項。
