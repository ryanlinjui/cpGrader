#include<stdio.h>
#include<stdint.h>

int main(){
	int32_t first1,first2,first3,second1,second2,second3,sum;
	printf("Please enter the first  operand: ");
	scanf("%d%c%d",&first1,&first2,&first3);
	//fflush(stdin);
	if(first1<10 && first3<10){
		printf("Please enter the second operand: ");
		int64_t a;
		scanf("%d",&a);
		//printf("a: %d",a);
		scanf("%c%d%c",&second1,&second2,&second3);
		if(second2<10){
			printf("Please enter the sum           : ");
			scanf("%d%c",&sum);
			if(sum<=1998 ){
				//calculator
				/*int64_t x,y,z;
				y = (sum/100)-first1;
				sum = sum%100;
				if( second2 <= sum/10 && y<10){
					x = (sum/10) - second2;
					//printf("sum/10 :%d second2 :%d\n",sum/10,second2);
				}	
				else {
					x = (sum/10) + 10 -second2;
					y -= 1;
				}	
				sum = sum%10;
				if( first3 <= sum ){
					z = sum - first3;
				}
				else {
					z = sum + 10 -first3;
					x -= 1;
				}
				printf("Ans: x = %d, y = %d, z = %d",x,y,z);*/
				int64_t x,y,z;				
				if((sum%10)>=first3){
					z = (sum%10)-first3;
				}
				else{
					sum-=10;
					z = (sum%10)+10-first3;
				}
				sum /= 10;
				if((sum%10)>=second2){
					x = (sum%10)-second2;
				}
				else{
					sum-=10;
					x = (sum%10)+10-second2;
				}
				sum/=10;
				if((sum%10)>=first1){
					y = (sum%10)-first1;
				}
				else{
					sum-=10;
					y = (sum%10)+10-first1;
				}
				printf("Ans: x = %d, y = %d, z = %d",x,y,z);
			}
			else{
				printf("please input sum between 100~1998");
			}
		}
		else{
			printf("please input the argument like 1x3 or y5z");
		}
	}
	else{
		printf("please input the argument like 1x3 or y5z");
	}
}
