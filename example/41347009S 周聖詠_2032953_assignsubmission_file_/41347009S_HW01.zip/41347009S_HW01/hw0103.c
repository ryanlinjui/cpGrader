#include<stdio.h>
#include<stdint.h>

int main(){
	uint64_t decimal,de2,flip=0;
	int64_t a,b,c,d,e,f,flip_d=0,length;
	printf("Please enter an unsigned 16-bits number: ");
	scanf("%d", &decimal);
	de2 = decimal;
	
	//printf("decimal: %d\n",decimal);
	a = decimal%8;
	decimal /= 8;
	//printf("a: %d,decimal: %d \n",a,decimal);
 
	b = decimal%8;
	decimal /= 8;
	//printf("b: %d ",b);

	c = decimal%8;
	decimal /= 8;
	//printf("c: %d ",c);

	d = decimal%8;
	decimal /= 8;
	//printf("d: %d ",d);

	e = decimal%8;
	decimal /= 8;
	//printf("e: %d ",e);

	f = decimal%8;
	decimal /= 8;
	//printf("f: %d ",f);
	
	//printf("%d%d%d%d%d%d",a,b,c,d,e,f);
	printf("Before Flip:\n");
	printf("%d_10 = %o_8\n",de2,de2);
	printf("After Flip:\n");
	if(f!=0){
		//printf("%d%d%d%d%d%d",a,b,c,d,e,f);
		flip = 100000*a+10000*b+1000*c+100*d+10*e+f;
		length = 6;
	}
	else if(e!=0){
		//printf("%d%d%d%d%d",a,b,c,d,e);
		flip = 10000*a+1000*b+100*c+10*d+e;
		length = 5;
	}
	else if(d!=0){
		//printf("%d%d%d%d",a,b,c,d);
		flip = 1000*a+100*b+10*c+d;
		length = 4;
	}
	else if(c!=0){
		//printf("%d%d%d",a,b,c);
		flip = 100*a+10*b+c;
		length = 3;
	}
	else if(b!=0){
		//printf("%d%d",a,b);
		flip = 10*a+b;
		length = 2;
	}
	else if(a!=0){
		//printf("%d",a);
		flip = a;
		length = 1;
	}
	printf("%d_8 = ",flip);
	
	if(flip != 0){
		flip_d += flip%10;
		flip /= 10;
		if(flip != 0){
			flip_d += (flip%10)*8;
			flip /= 10;
			if(flip != 0){
				flip_d += (flip%10)*8*8;
				flip /= 10;
				if(flip != 0){
					flip_d += (flip%10)*8*8*8;
					flip /=10;
					if(flip != 0){
						flip_d += (flip%10)*8*8*8*8;
						flip /= 10;
						if(flip != 0){
							flip_d += (flip%10)*8*8*8*8*8;
							flip /= 10;
							if(flip != 0){
								flip_d += (flip%10)*8*8*8*8*8*8;
							}
						}
					}
				}
			}
		}
		printf("%d_10",flip_d);	
	}
	else{
		printf("0_10");}
}
