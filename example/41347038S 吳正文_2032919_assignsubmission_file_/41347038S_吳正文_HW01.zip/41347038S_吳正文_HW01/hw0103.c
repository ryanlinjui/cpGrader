#include <stdio.h>
int main(){
int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,x,y;

printf("Please enter an unsigned 16-bits number:");
scanf(" %d",&a);

//10 to 8
x=a;
b=a/32768;
a=a-b*32768;
c=a/4096;
a=a-c*4096;
d=a/512;
a=a-d*512;
e=a/64;
a=a-e*64;
f=a/8;
a=a-f*8;
g=b*100000+c*10000+d*1000+e*100+f*10+a;

if(b>0)
{
h=a*100000+f*10000+e*1000+d*100+c*10+b;
}
else if(c>0)
{
h=a*10000+f*1000+e*100+d*10+c;
}
else if(d>0)
{
h=a*1000+f*100+e*10+d;
}
else if(e>0)
{
h=a*100+f*10+e;
}
else if(f>0)
{
h=a*10+f;
}
else
{
h=a;
}

//8 to 10
y=h;
i=h/100000;
h=h-i*100000;
j=h/10000;
h=h-j*10000;
k=h/1000;
h=h-k*1000;
l=h/100;
h=h-l*100;
m=h/10;
h=h-m*10;

n=i*32768+j*4096+k*512+l*64+m*8+h;

printf("Before Filp: %d_10=%d_8\n",x,g);
printf("After Filp: %d_8=%d_10\n",y,n);
return 0;
}
