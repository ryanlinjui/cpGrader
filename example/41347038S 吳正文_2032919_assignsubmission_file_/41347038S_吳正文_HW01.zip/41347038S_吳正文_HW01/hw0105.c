#include <stdio.h>
int main(){
int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,type,temperOne,temperTwo,Ans;
float f1,f2,f3,f4;
printf("Please input a hex:");
scanf("%x",&a);
printf("Please choose the output type(1:integer,2:unsigned integer,3:float):");
scanf("%d",&type);
b=("%d",a);
temperOne=b;
c=b/32768;
b-=c*32768;
temperTwo=b;
d=b/16384;
b-=d*16384;
e=b/8192;
b-=e*8192;
f=b/4096;
b-=f*4096;
g=b/2048;
b-=g*2048;
h=b/1024;
b-=h*1024;
i=b/512;
b-=i*512;
j=b/256;
b-=j*256;
k=b/128;
b-=k*128;
l=b/64;
b-=l*64;
m=b/32;
b-=m*32;
n=b/16;
b-=n*16;
o=b/8;
b-=o*8;
p=b/4;
b-=p*4;
q=b/2;
b-=q*2;
Ans=temperTwo-32768;
printf("Binary of %x is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",a,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,b);
f1=d*16+e*8+f*4+g*2+h-15;

//0.5/2/2/2...
float d1,d2,d3,d4,d5,d6,d7,d8;
d1=0.25/2;
d2=0.25/2/2;
d3=0.25/2/2/2;
d4=0.25/2/2/2/2;
d5=0.25/2/2/2/2/2;
d6=0.25/2/2/2/2/2/2;
d7=0.25/2/2/2/2/2/2/2;
d8=0.25/2/2/2/2/2/2/2/2;

f2=i*0.5+j*0.25+k*d1+l*d2+m*d3+n*d4+o*d5+p*d6+q*d7+b*d8;
if(type==1)
{
if(c==1){
printf("Converted integer is: %d",Ans);
}
if(c==0){
printf("Converted integer is: %d",temperTwo);
}
}

if(type==2)
{
printf("Converted unsigned integer is: %d",temperOne);
}

if(type==3)
{
if(c==1){
printf("Converted float is: -%f^%f",f2,f1);
}
if(c==0){
printf("Converted float is: %f^%f",f2,f1);
}
}
return 0;
}
