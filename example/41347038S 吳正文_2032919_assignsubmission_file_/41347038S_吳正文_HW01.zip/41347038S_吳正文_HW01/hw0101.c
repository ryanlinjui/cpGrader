#include<stdio.h>

#define RED	"\033[31m"
#define BLUE	"\033[34m"
#define GREEN	"\033[32m"
#define RESET	"\033[0m"

int main()
{
printf("[KIM]\n");
printf(RED "You are sunlight and I moon\n"RESET);
printf(RED "Joined by the gods of fortune\n"RESET);
printf(RED "Midnight and high noon sharing the sky\n"RESET);
printf(RED "We have been blessed, you and I\n\n"RESET);

printf("[CHRIS]\n");
printf(BLUE "You are here like a mystery\n"RESET);
printf(BLUE"I'm from the world that's so different from all that you are\n"RESET);
printf(BLUE "How in the light of one night did we come so far?\n\n"RESET);

printf("[KIM]\n");
printf(RED "Outside day starts to dawn\n\n"RESET);

printf("[CHRIS]\n");
printf(BLUE"Your moon still floats on high\n\n"RESET);

printf("[KIM]\n");
printf(RED"The birds awake\n\n"RESET);

printf("[CHRIS]\n");
printf(BLUE"The stars shine too\n\n"RESET);

printf("[KIM]\n");
printf(RED"My hands still shake\n"RESET);
printf(RED"See upcoming pop shows\n");
printf(RED"Get tickets for your favorite artists\n\n");
printf(RED"You might also like\n");
printf(RED"My Boy Only Breaks His Favorite Toys\n");
printf(RED"Tayor Swift\n");
printf(RED"Who's Afraid of Little Old Me\n");
printf(RED"Taylor Swift\n");
printf(RED"Guilty as Sin\n");
printf(RED"Tayor Swift\n");

printf("[CHRIS]\n");
printf(BLUE"I reach for you\n\n"RESET);

printf("[KIM & CHRIS]\n");
printf(GREEN"And we meet in the sky\n\n"RESET);

printf("[KIM]\n");
printf(RED"You are sunlight and I moon\n"RESET);
printf(RED"Joined here\n"RESET);
printf(RED"Brightening the sky with the flame of love\n\n"RESET);

printf("[KIM & CHRIS]\n");
printf(GREEN"Made of\nSunlight\n"RESET);
printf(GREEN"Moonlight\n\n"RESET);

return 0;
}
