#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

int main()
{
int a,b,c,d,e,f,x,y,z;

printf("Please enter the first operand:");
scanf(" %dx%d",&a,&b);
printf("Please enter the second operand:");
scanf(" y%dz",&c);
printf("Please enter the sum:");
scanf(" %d",&d);

if(a>10||b>10||a<0||b<0)
{
printf(" %dx%d is not allowed operand",a,b);
exit (0);
}
if(c>10||c<0)
{
printf(" y%dz is not allowed operand",c);
exit (0);
}

y=(d-a*100-c*10-b)/100;
x=(d-a*100-c*10-b-y*100)/10;
z=d-a*100-c*10-b-y*100-x*10;

if((d-a*100-c*10-b)>1000)
{
printf("this is not an allowed operand");
exit(0);
}

printf("Ans:x= %d,y= %d,z= %d\n",x,y,z);

return 0;
}
