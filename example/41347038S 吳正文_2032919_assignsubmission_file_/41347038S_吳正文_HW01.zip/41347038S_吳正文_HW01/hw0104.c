#include <stdio.h>
#include <stdint.h>

int main(){

int32_t  a,b,c,d,e,A,B,C,D,E,f,g,h,i,j,F,G,H,I,J,temp;
int has_output=0;
int not_Straight_flush=0;

printf("Please enter 5 cards:");
scanf(" %d %d %d %d %d",&a,&b,&c,&d,&e);

//bi da shiow
if(a>b){ temp = a; a=b;b=temp;}
if(a>c){ temp = a; a=c;c=temp;}
if(a>d){ temp = a; a=d;d=temp;}
if(a>e){ temp = a; a=e;e=temp;}

if(b>c){ temp = b; b=c;c=temp;}
if(b>d){ temp = b; b=d;d=temp;}
if(b>e){ temp = b; b=e;e=temp;}

if(c>d){ temp = c; c=d;d=temp;}
if(c>e){ temp = c; c=e;e=temp;}

if(d>e){ temp = d; d=e;e=temp;}

//pai lei
A=a,B=b,C=c,D=d,E=e;

//Flush & straight flush

//taohua
if((a-1)/13==0 && (b-1)/13==0 && (c-1)/13==0 && (d-1)/13==0 && (e-1)/13==0)
{
if((A==1||2||3||4||5||6||7||8||9,B==A+1,C==B+1,D==C+1,E==D+1)||(A==1,B==10,C==11,D==12,E==13)){
printf("Straight flush\n");
has_output=1;
not_Straight_flush=1;
}
else{
printf("Flush\n");
has_output=1;
not_Straight_flush=1;

}
}

//<3
if((a-1)/13==1 && (b-1)/13==1 && (c-1)/13==1 && (d-1)/13==1 && (e-1)/13==1)
{
if((A==14||15||16||17||18||19||20||21||22,B==A+1,C==B+1,D==C+1,E==D+1)||(A==14,B==23,C==24,D==25,E==26)){
printf("Straight Flush\n");
has_output=1;
not_Straight_flush=1;
}
else{
printf("Flush\n");
has_output=1;
not_Straight_flush=1;
}
}

//lin shin
if((a-1)/13==2 && (b-1)/13==2 && (c-1)/13==2 && (d-1)/13==2 && (e-1)/13==2)
{
if((A==27||28||29||30||31||32||33||34||35,B==A+1,C==B+1,D==C+1,E==D+1)||(A==27,B==36,C==37,D==38,E==39)){
printf("Straight Flush\n");
has_output=1;
not_Straight_flush=1;
}
else{
printf("Flush\n");
has_output=1;
not_Straight_flush=1;
}
}

//mei hua
if((a-1)/13==3 && (b-1)/13==3 && (c-1)/13==3 && (d-1)/13==3 && (e-1)/13==3)
{
if((A==40||41||42||43||44||45||46||47||48,B==A+1,C==B+1,D==C+1,E==D+1)||(A==40,B==49,C==50,D==51,E==52)){
printf("Straight Flush\n");
has_output=1;
not_Straight_flush=1;
}
else{
printf("Flush\n");
has_output=1;
not_Straight_flush=1;
}
}

f=A%13;
g=B%13;
h=C%13;
i=D%13;
j=E%13;

//bi da shiow
if(f>g){ temp = f; f=g;g=temp;}
if(f>h){ temp = f; f=h;h=temp;}
if(f>i){ temp = f; f=i;i=temp;}
if(f>j){ temp = f; f=j;j=temp;}

if(g>h){ temp = g; g=h;h=temp;}
if(g>i){ temp = g; g=i;i=temp;}
if(g>j){ temp = g; g=j;j=temp;}

if(h>i){ temp = h; h=i;i=temp;}
if(h>j){ temp = h; h=j;j=temp;}

if(i>j){ temp = i; i=j;j=temp;}

//pai lei
F=f,G=g,H=h,I=i,J=j;


//Straight
if((G==F+1 && H==G+1 && I==H+1 && J==I+1 && not_Straight_flush==0)||
(F==1 && G==10 && H==G+1 && I==H+1 && J==I+1 && not_Straight_flush==0)){
printf("Straight\n");
has_output=1;
}

//Four for a kind
if((A%13==B%13) && (A%13==C%13) && (A%13==D%13)||
(A%13==C%13) && (A%13==D%13) && (A%13==E%13)||
(A%13==B%13) && (A%13==D%13) && (A%13==E%13)||
(A%13==B%13) && (A%13==C%13) && (A%13==E%13)||
(B%13==C%13) && (B%13==D%13) && (B%13==E%13)){
printf("Four for a kind\n");
has_output=1;
}

//Full house
if((A%13==B%13)&&(A%13==C%13)&&(A%13!=D%13)&&(D%13==E%13)||
(A%13==B%13)&&(A%13==D%13)&&(A%13!=C%13)&&(C%13==E%13)||
(A%13==B%13)&&(A%13==E%13)&&(A%13!=C%13)&&(C%13==D%13)||
(A%13==C%13)&&(A%13==D%13)&&(A%13!=B%13)&&(B%13==E%13)||
(A%13==C%13)&&(A%13==E%13)&&(A%13!=B%13)&&(B%13==D%13)||
(A%13==D%13)&&(A%13==E%13)&&(A%13!=B%13)&&(B%13==C%13)||
(B%13==C%13)&&(B%13==D%13)&&(B%13!=A%13)&&(A%13==E%13)||
(B%13==C%13)&&(B%13==E%13)&&(B%13!=A%13)&&(A%13==D%13)||
(B%13==D%13)&&(B%13==E%13)&&(B%13!=A%13)&&(A%13==C%13)||
(C%13==D%13)&&(C%13==E%13)&&(C%13!=A%13)&&(A%13==B%13)){
printf("Full house\n");
has_output=1;
}

//Three of a kind
if((A%13==B%13)&&(A%13==C%13)&&(A%13!=D%13)&&(D%13!=E%13)&&(A%13!=E%13)||
(A%13==B%13)&&(A%13==D%13)&&(A%13!=C%13)&&(C%13!=E%13)&&(A%13!=E%13)||
(A%13==B%13)&&(A%13==E%13)&&(A%13!=C%13)&&(C%13!=D%13)&&(A%13!=D%13)||
(A%13==C%13)&&(A%13==D%13)&&(A%13!=B%13)&&(B%13!=E%13)&&(A%13!=E%13)||
(A%13==C%13)&&(A%13==E%13)&&(A%13!=B%13)&&(B%13!=D%13)&&(A%13!=D%13)||
(A%13==D%13)&&(A%13==E%13)&&(A%13!=B%13)&&(B%13!=C%13)&&(A%13!=C%13)||
(B%13==C%13)&&(B%13==D%13)&&(B%13!=A%13)&&(A%13!=E%13)&&(B%13!=E%13)||
(B%13==C%13)&&(B%13==E%13)&&(B%13!=A%13)&&(A%13!=D%13)&&(B%13!=D%13)||
(B%13==D%13)&&(B%13==E%13)&&(B%13!=A%13)&&(A%13!=C%13)&&(B%13!=C%13)||
(C%13==D%13)&&(C%13==E%13)&&(C%13!=A%13)&&(A%13!=B%13)&&(C%13!=B%13)){
printf("Three of a kind\n");
has_output=1;
}

//Two pair
if((A%13==B%13)&&(C%13==D%13)&&(A%13!=E%13)&&(C%13!=E%13)||
(A%13==B%13)&&(D%13==E%13)&&(A%13!=C%13)&&(D%13!=C%13)||
(A%13==B%13)&&(C%13==E%13)&&(A%13!=D%13)&&(C%13!=D%13)||
(A%13==C%13)&&(B%13==D%13)&&(A%13!=E%13)&&(B%13!=E%13)||
(A%13==C%13)&&(B%13==E%13)&&(A%13!=D%13)&&(B%13!=E%13)||
(A%13==C%13)&&(D%13==E%13)&&(A%13!=B%13)&&(D%13!=B%13)||
(A%13==D%13)&&(B%13==C%13)&&(A%13!=E%13)&&(B%13!=E%13)||
(A%13==D%13)&&(B%13==E%13)&&(A%13!=C%13)&&(B%13!=C%13)||
(A%13==D%13)&&(C%13==E%13)&&(A%13!=B%13)&&(C%13!=B%13)||
(A%13==E%13)&&(B%13==C%13)&&(A%13!=D%13)&&(B%13!=D%13)||
(A%13==E%13)&&(B%13==D%13)&&(A%13!=C%13)&&(B%13!=C%13)||
(A%13==E%13)&&(C%13==D%13)&&(A%13!=B%13)&&(C%13!=B%13)||
(B%13==C%13)&&(D%13==E%13)&&(B%13!=A%13)&&(D%13!=A%13)||
(B%13==D%13)&&(C%13==E%13)&&(B%13!=A%13)&&(C%13!=A%13)||
(B%13==E%13)&&(C%13==D%13)&&(B%13!=A%13)&&(C%13!=A%13)){
printf("Two pair\n");
has_output=1;
}

//One pair
if((A%13==B%13)&&(A%13!=C%13)&&(A%13!=D%13)&&(A%13!=E%13)||
(A%13==C%13)&&(A%13!=B%13)&&(A%13!=D%13)&&(A%13!=E%13)||
(A%13==D%13)&&(A%13!=B%13)&&(A%13!=C%13)&&(A%13!=E%13)||
(A%13==E%13)&&(A%13!=B%13)&&(A%13!=C%13)&&(A%13!=D%13)||
(B%13==C%13)&&(B%13!=A%13)&&(B%13!=D%13)&&(B%13!=E%13)||
(B%13==D%13)&&(B%13!=A%13)&&(B%13!=C%13)&&(B%13!=E%13)||
(B%13==E%13)&&(B%13!=A%13)&&(B%13!=C%13)&&(B%13!=D%13)||
(C%13==D%13)&&(C%13!=A%13)&&(C%13!=B%13)&&(C%13!=E%13)||
(C%13==E%13)&&(C%13!=A%13)&&(C%13!=B%13)&&(C%13!=D%13)||
(D%13==E%13)&&(D%13!=A%13)&&(D%13!=B%13)&&(D%13!=C%13)){
printf("One pair\n");
has_output=1;
}

//High card
if(has_output==0){
printf("High card\n");
}

return 0;
}
