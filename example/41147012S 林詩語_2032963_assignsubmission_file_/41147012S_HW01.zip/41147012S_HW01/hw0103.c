#include<stdio.h>
#include<stdint.h>

int main(){
    
    int16_t num=0;
    printf("Please enter an unsigned 16-bits number: ");
    scanf("%hd",&num);
    if( num<0 ){
        printf("error");
        return 0;
    }

    int remainder1 = num % 8;   
    int division1 = num / 8;
    
    int remainder2 = division1 % 8;  
    int division2 = division1 / 8;
    
    int remainder3 = division2 % 8; 
    int division3 = division2 / 8;
    
    int remainder4 = division3 % 8; 
    int division4 = division3 / 8;

    int remainder5 = division4 % 8; 
    int division5 = division4 / 8;

    int remainder6 = division5 % 8;  


    int original_octal = remainder1 
                       + remainder2 * 10
                       + remainder3 * 100
                       + remainder4 * 1000
                       + remainder5 * 10000
                       + remainder6 * 100000;

    printf("Before Flip:\n");
    printf("%hu_10 = %d_8\n", num, original_octal);

    int flipped_octal = 0;
    int decimal_result = 0;

    if(original_octal>100000){
        flipped_octal = remainder6 
                      + remainder5 * 10 
                      + remainder4 * 100 
                      + remainder3 * 1000 
                      + remainder2 * 10000 
                      + remainder1 * 100000;
        decimal_result = (remainder1 * 8 * 8 * 8 * 8 * 8) 
                       + (remainder2 * 8 * 8 * 8 * 8)
                       + (remainder3 * 8 * 8 * 8) 
                       + (remainder4 * 8 * 8) 
                       + (remainder5 * 8) 
                       + remainder6;
    }
    else if(original_octal>10000){
        flipped_octal = remainder5 
                      + remainder4 * 10 
                      + remainder3 * 100 
                      + remainder2 * 1000
                      + remainder1 * 10000;
        decimal_result =(remainder1 * 8 * 8 * 8 * 8)
                       + (remainder2 * 8 * 8 * 8) 
                       + (remainder3 * 8 * 8) 
                       + (remainder4 * 8) 
                       + remainder5;
    }
    else if(original_octal>1000){
        flipped_octal = remainder4 * 1 
                      + remainder3 * 10 
                      + remainder2 * 100 
                      + remainder1 * 1000;
        decimal_result = (remainder1 * 8 * 8 * 8) 
                       + (remainder2 * 8 * 8) 
                       + (remainder3 * 8) 
                       + remainder4;
    }
    else if(original_octal>100){
        flipped_octal = remainder3 * 1 
                      + remainder2 * 10 
                      + remainder1 * 100;
        decimal_result = (remainder1 * 8 * 8) 
                       + (remainder2 * 8) 
                       + remainder3;
    }
    else if(original_octal>10){
        flipped_octal = remainder2 * 1
                      + remainder1 * 10;
        decimal_result =(remainder1 * 8) 
                       + remainder2;
    }
    else if(original_octal>=0){
        flipped_octal = remainder1 ;
        decimal_result = remainder1;
    }



   

    printf("After Flip:\n");
    printf("%d_8 = %d_10\n", flipped_octal, decimal_result);


    return 0;
}