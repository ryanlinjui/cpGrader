#include<stdio.h>
int main(){
    int a,b,c,d,e,f;
    int flower_a,flower_b,flower_c,flower_d,flower_e,flower_f;
    int num_a,num_b,num_c,num_d,num_e,num_f;
    int flower_count = 0 , num_count = 0;
    printf("Please enter 5 cards: ");
    scanf("%d %d %d %d %d",&a,&b,&c,&d,&e);
//確認輸入數字
    if( a < 1 || a > 52 ){
        printf("error\n");
        return 0;
    }
   if( b < 1 || b > 52 ){
        printf("error\n");
        return 0;
    }
    if( c < 1 || c > 52 ){
        printf("error\n");
        return 0;
    }
    if( d < 1 || d > 52 ){
        printf("error\n");
        return 0;
    }
    if( e < 1 || e > 52 ){
        printf("error\n");
        return 0;
    }
    if(a==b){
        printf("error\n");
        return 0;
    }
    if(a==c){
        printf("error\n");
        return 0;
    }
    if(a==d){
        printf("error\n");
        return 0;
    }
    if(a==e){     
        printf("error\n");
        return 0; 
    }
    if(b==c){
        printf("error\n");
        return 0;
    }
    if(b==d){
        printf("error\n");
        return 0;
    }
    if(b==e){
        printf("error\n");
        return 0;
    }
    if(c==d){
        printf("error\n");
        return 0;
    }
    if(c==e){
        printf("error\n");
        return 0;
    }
    if(d==e){
        printf("error\n");
        return 0;
    }

    if (a > b) {
        int temp = a;
        a = b;
        b = temp;
    }

    if (b > c) {
        int temp = b;
        b = c;
        c = temp;
    }

    if (c > d) {
        int temp = c;
        c = d;
        d = temp;
    }

    if (d > e) {
        int temp = d;
        d = e;
        e = temp;
    }
    
    if (a > b) {
        int temp = a;
        a = b;
        b = temp;
    }

    if (b > c) {
        int temp = b;
        b = c;
        c = temp;
    }

    if (c > d) {
        int temp = c;
        c = d;
        d = temp;
    }

    if (a > b) {
        int temp = a;
        a = b;
        b = temp;
    }

    if (b > c) {
        int temp = b;
        b = c;
        c = temp;
    }

//花色
    flower_a = (a-1) /13;
    flower_b = (b-1) /13;
    flower_c = (c-1) /13;
    flower_d = (d-1) /13;
    flower_e = (e-1) /13;
//數字
    num_a = ((a-1) % 13)+1;
    num_b = ((b-1) % 13)+1;
    num_c = ((c-1) % 13)+1;
    num_d = ((d-1) % 13)+1;
    num_e = ((e-1) % 13)+1;


    int count_a = 1;  
    if (flower_a == flower_b) count_a++;
    if (flower_a == flower_c) count_a++;
    if (flower_a == flower_d) count_a++;
    if (flower_a == flower_e) count_a++;

    int count_b = 1; 
    if (flower_b != flower_a) {
        if (flower_b == flower_c) count_b++;
        if (flower_b == flower_d) count_b++;
        if (flower_b == flower_e) count_b++;
    }

    int count_c = 1; 
    if (flower_c != flower_a && flower_c != flower_b) {
        if (flower_c == flower_d) count_c++;
        if (flower_c == flower_e) count_c++;
    }

    int count_d = 1; 
    if (flower_d != flower_a && flower_d != flower_b && flower_d != flower_c) {
        if (flower_d == flower_e) count_d++;
    }

    int count_e = 0;
    if (flower_e != flower_a && flower_e != flower_b && flower_e != flower_c && flower_e != flower_d) {
           int count_e = 1;

    }

    // 找到花色最多的数量
    int flower_max_count = count_a;
    if (count_b > flower_max_count) flower_max_count = count_b;
    if (count_c > flower_max_count) flower_max_count = count_c;
    if (count_d > flower_max_count) flower_max_count = count_d;
    if (count_e > flower_max_count) flower_max_count = count_e;
    
    count_a = 1;  // num_a 自己肯定算1次
    if (num_a == num_b) count_a++;
    if (num_a == num_c) count_a++;
    if (num_a == num_d) count_a++;
    if (num_a == num_e) count_a++;

    count_b = 1;  // 如果 num_b 跟 num_a 不一样，统计 num_b 的出现次数
    if (num_b != num_a) {
        if (num_b == num_c) count_b++;
        if (num_b == num_d) count_b++;
        if (num_b == num_e) count_b++;
    }

    count_c = 1;  // 如果 num_c 跟 num_a, num_b 都不一样，统计 num_c 的出现次数
    if (num_c != num_a && num_c != num_b) {
        if (num_c == num_d) count_c++;
        if (num_c == num_e) count_c++;
    }

    count_d = 1;  // 如果 num_d 跟 num_a, num_b, num_c 都不一样，统计 num_d 的出现次数
    if (num_d != num_a && num_d != num_b && num_d != num_c) {
        if (num_d == num_e) count_d++;
    }

    count_e = 1;  // 如果 num_e 跟 num_a, num_b, num_c, num_d 都不一样，统计 num_e 的出现次数
    if (num_e != num_a && num_e != num_b && num_e != num_c && num_e != num_d) {

    }


    int num_max_count = count_a;
    if (count_b > num_max_count) num_max_count = count_b;
    if (count_c > num_max_count) num_max_count = count_c;
    if (count_d > num_max_count) num_max_count = count_d;
    if (count_e > num_max_count) num_max_count = count_e;

//1&4
    if(flower_max_count==5){
        if( a+1 == b && b+1 == c && c+1 == d && d+1 == e){
            printf("Straight Flush\n");
            return 0;
        }else{
            printf("Flush\n");
            return 0;
        }
    }
//5
    if( a+1 == b && b+1 == c && c+1 == d && d+1 == e){
            printf("Straight\n");
            return 0;
    }
//2
    if(num_max_count==4){
        printf("Four of a kind\n");
        return 0;
    }

//3&6
    
    if(num_max_count==3){
        if(num_c==num_a||num_c==num_e){
            printf("Full House\n");
            return 0;
        }else{
            printf("Three of a kind\n");
            return 0;
        }
    }

//7&8
    if(num_max_count==2){
        int count;
        if(num_a == num_b){
            count = count +1;
        }
        if(num_a == num_c){
            count = count +1;
        }
        if(num_a == num_d){
            count = count +1;
        }
        if(num_a == num_e){
            count = count +1;
        }
        if(num_b == num_c){
            count = count +1;
        }
        if(num_b == num_d){
            count = count +1;
        }
        if(num_b == num_e){
            count = count +1;
        }
        if(num_c == num_d){
            count = count +1;
        }
        if(num_c == num_e){
            count = count +1;
        }
        if(num_d == num_e){
            count = count +1;
        }




        if(count==2){
            printf("Two pair\n");
            return 0;
        }
        if(count==1){
            printf("One pair\n");
            return 0;
        }




    }

    printf("High card\n");
          

    
    return 0;
}