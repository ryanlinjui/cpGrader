#include<stdio.h>
#include<stdint.h>
int main(){
    
    int a=0 , x=0 , c=0;
    int y=0 , e=0 , z=0;
    int sum;
    printf("Please enter the first operand:  ");
    scanf("%dx%d", &a , &c);
    
    printf("Please enter the second operand: ");
    scanf("%*cy %d %*cz", &e);
    
    printf("Please enter the sum           : ");
    scanf("%d",&sum);
    if(a<0||c<0||e<0||sum<0){
        printf("error");
        return 0;
    }
    if(a>9||c>9||e>9||sum>1998){
        printf("error");
        return 0;
    }
    
    int s,u,m;
    s = sum/100;
    u = (sum / 10) % 10;
    m = sum %10;

    if(m<c){
        m = m + 10;
        u = u - 1;
    }

    if(u<e){
        u = u + 10;
        s = s - 1;
    }

    z = m - c;
    x = u - e;
    y = s - a;

    printf("Ans: x = %d, y = %d, z = %d",x,y,z);

    return 0;
}