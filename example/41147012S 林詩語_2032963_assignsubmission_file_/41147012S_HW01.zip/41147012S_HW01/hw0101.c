#include<stdio.h>
int main(){
    
    //\e[;34m \e[m blue
    //\e[;31m \e[m red
    //\e[;32m \e[m green
    //kim red
    //chris blue
    printf("[KIM]\n");
    printf("\e[;31mYou are sunlight and I moon\e[m\n");
    printf("\e[;31mJoined by the gods of fortune\e[m\n");
    printf("\e[;31mMidnight and high noon sharing the sky\e[m\n");
    printf("\e[;31mWe have been blessed , you and I\e[m\n\n");

    printf("[CHRIS]\n");
    printf("\e[;34mYou are here like a mystery\e[m\n");
    printf("\e[;34mI'm from a world that's so different from all that you are\e[m\n");
    printf("\e[;34mHow in the light of one night did we come so far\e[m\n\n");

    printf("[KIM]\n");
    printf("\e[;31mOutside day starts to dawn\e[m\n\n");

    printf("[CHRIS]\n");
    printf("\e[;34mYour moon still floats on high\e[m\n\n");

    printf("[KIM]\n");
    printf("\e[;31mThe birds awake\e[m\n\n");

    printf("[CHRIS]\n");
    printf("\e[;34mThe stars shine too\e[m\n");
    printf("See upcoming pop shows\n");
    printf("Get tickets for your favorite artists\n");
    printf("You might also like\n");
    printf("My Boy Only Breaks His Favorite Toys\n");
    printf("Taylor Swift\n");
    printf("Who’s Afraid of Little Old Me?\n");
    printf("Taylor Swift\n");
    printf("Guilty as Sin?\n");
    printf("STaylor Swift\n\n");

    printf("[KIM & CHRIS]\n");
    printf("\e[;32mAnd we meet in the sky\e[m\n\n");

    printf("[KIM]\n");
    printf("\e[;31mYou are sunlight and I moon\e[m\n");
    printf("\e[;31mJoined here\e[m\n");
    printf("\e[;31mBrightening the sky with the flame of love\e[m\n\n");

    printf("[KIM & CHRIS]\n");
    printf("\e[;32mMade of\e[m\n");
    printf("\e[;32mSunlight\e[m\n");
    printf("\e[;32mMoonlight\e[m\n");



    



    return 0;
}