#include<stdio.h>
#include<stdint.h>


int main(){
    uint16_t num = 0;
    int choice = 0;

    printf("Please input a hex: ");
    scanf("%hx", &num);  

    int num_1 = 0;
    int num_2 = 0;
    int num_3 = 0;
    int num_4 = 0;

    num_1 = (num / 4096) % 16;

    int bit16 = num_1 / 8;
    num_1 %= 8;
    int bit15 = num_1 / 4;
    num_1 %= 4;
    int bit14 = num_1 / 2;
    num_1 %= 2;
    int bit13 = num_1;

    num_2 = (num / 256) % 16;

    int bit12 = num_2 / 8;
    num_2 %= 8;
    int bit11 = num_2 / 4;
    num_2 %= 4;
    int bit10 = num_2 / 2;
    num_2 %= 2;
    int bit9 = num_2;

    num_3 = (num / 16) % 16;

    int bit8 = num_3 / 8;
    num_3 %= 8;
    int bit7 = num_3 / 4;
    num_3 %= 4;
    int bit6 = num_3 / 2;
    num_3 %= 2;
    int bit5 = num_3;

    num_4 = num % 16;

    int bit4 = num_4 / 8;
    num_4 %= 8;
    int bit3 = num_4 / 4;
    num_4 %= 4;
    int bit2 = num_4 / 2;
    num_4 %= 2;
    int bit1 = num_4;


    printf("Please choose the output type(1:integer, 2:unsigned integer, 3:float): ");
    scanf("%d", &choice);

    if(choice != 1 && choice != 2 && choice !=3){
        printf("error");
        return 0;
    }

    printf("Binary of %X is: ", num);
    printf("%d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n", 
        bit16 , bit15, bit14, bit13, bit12, bit11, bit10, bit9, bit8,
        bit7, bit6, bit5, bit4, bit3, bit2, bit1);


    if(choice == 1){
        int uinterger = bit1 * 1
                     + bit2 * 2
                     + bit3 * 4
                     + bit4 * 8
                     + bit5 * 16
                     + bit6 * 32
                     + bit7 * 64
                     + bit8 * 128
                     + bit9 * 256
                     + bit10 * 512
                     + bit11 * 1024
                     + bit12 * 2048
                     + bit13 * 4096
                     + bit14 * 8192
                     + bit15 * 16384
                     + bit16 * 32768;
        if (num > 32767) {
            int interger = num - 65536;  
            printf("Converted integer is: %d", interger);
        } else {
            int interger = num;  
            printf("Converted integer is: %d", interger);
        }
        
        return 0;
    }
    if(choice == 2){
        int uinterger = bit1 * 1
                     + bit2 * 2
                     + bit3 * 4
                     + bit4 * 8
                     + bit5 * 16
                     + bit6 * 32
                     + bit7 * 64
                     + bit8 * 128
                     + bit9 * 256
                     + bit10 * 512
                     + bit11 * 1024
                     + bit12 * 2048
                     + bit13 * 4096
                     + bit14 * 8192
                     + bit15 * 16384
                     + bit16 * 32768;
        printf("Converted unsigned integer is: %d", uinterger);
        return 0;

    }
    if(choice == 3){
        
        printf("The converted float is: ");

        if(num==0){
            if(bit16==0){
                printf("+0.0");
                return 0;
            }
            if(bit16==1){
                printf("-0.0");
                return 0;
            }
        }

        if ( bit16 == 1 && bit15 == 1 && bit14 == 1 && bit13 == 1 && bit12 == 1 && bit11 ==1&&bit10==0&&bit9==0&&bit8==0&&bit7==0&&bit6==0&&bit5==0&&bit4==0&&bit3==0&&bit2==0&&bit1==0){
            printf("-INF");
            return 0;
        }
        if ( bit16 == 0 && bit15 == 1 && bit14 == 1 && bit13 == 1 && bit12 == 1 && bit11 ==1&&bit10==0&&bit9==0&&bit8==0&&bit7==0&&bit6==0&&bit5==0&&bit4==0&&bit3==0&&bit2==0&&bit1==0){
            printf("INF");
            return 0;
        }
        if ( bit15 == 1 && bit14 == 1 && bit13 == 1 && bit12 == 1 && bit11 ==1&&bit10==0&&bit9==0&&bit8==0&&bit7==0&&bit6==0&&bit5==0&&bit4==0&&bit3==0&&bit2==0&&bit1==1){
            printf("NAN");
            return 0;
        }

            int exponent = bit15 * 16
                     + bit14 * 8
                     + bit13 * 4
                     + bit12 * 2
                     + bit11 * 1;    
            int fraction =  bit10 * 512
                     + bit9 * 256
                     + bit8 * 128
                     + bit7 * 64
                     + bit6 * 32
                     + bit5 * 16
                     + bit4 * 8
                     + bit3 * 4
                     + bit2 * 2
                     + bit1 * 1;

            int power_of_two = exponent - 15;
            if (bit16 == 1) {
                printf("-");
            }
            printf("%f*2^%d" ,1+(float)fraction/1024 ,power_of_two);

            return 0;
    }






    return 0;
}