#include <stdio.h>
#include <stdint.h>

int main(){


//1-13: ♠ Ace to King.
//14-26: ♡ Ace to King.
//27-39: ♢ Ace to King.
//40-52: ♣ Ace to King.

int a,b,c,d,e;
int c1,c2,c3,c4,c5; 
int temp;
printf("Please enter 5 cards: \n");
scanf("%d %d %d %d %d",&a ,&b, &c ,&d ,&e);


if (a>=1 && a<=13) c1 = 1;
if (a>=14 && a<=26) c1 = 2;
if (a>=27 && a<=39) c1 = 3;
if (a>=40 && a<=52) c1 = 4;
if (b>=1 && b<=13) c2 = 1;
if (b>=14 && b<=26) c2 = 2;
if (b>=27 && b<=39) c2 = 3;
if (b>=40 && b<=52) c2 = 4;
if (c>=1 && c<=13) c3 = 1;
if (c>=14 && c<=26) c3 = 2;
if (c>=27 && c<=39) c3 = 3;
if (c>=40 && c<=52) c3 = 4;
if (d>=1 && d<=13) c4 = 1;
if (d>=14 && d<=26) c4 = 2;
if (d>=27 && d<=39) c4 = 3;
if (d>=40 && d<=52) c4 = 4;
if (e>=1 && e<=13) c5 = 1;
if (e>=14 && e<=26) c5 = 2;
if (e>=27 && e<=39) c5 = 3;
if (e>=40 && e<=52) c5 = 4;
if (a>b){
	temp = a;
	a=b;
	b=temp;
}
if (a>c){
	temp = a;
	a=c;
	c=temp;
}
if (a>d){
	temp = a;
	a=d;
	d=temp;
}
if (a>e){
	temp = a;
	a=e;
	e=temp;
}


if ((c1==c2)&&(c2==c3)&&(c3==c4)&&(c4==c5) && (a+b+c+d+e-(a*5)==10)&&(a!=b&&b!=c&&c!=d&&d!=e)){
	printf("Straight Flush\n");
}else if (a%13==b%13&&b%13==c%13&&c%13==d%13 || b%13==c%13&&c%13==d%13&&d%13==e%13|| a%13==b%13&&b%13==c%13&&c%13==e%13 || a%13==b%13&&b%13==d%13&&d%13==e%13 || a%13==c%13&&c%13==d%13&&d%13==e%13){
	printf("Four of a kind\n");

}else if ((a%13==b%13&&b%13==c%13&&d%13==e%13)||(a%13==b%13&&b%13==d%13&&c%13==e%13)||(a%13==b%13&&b%13==e%13&&c%13==d%13)||(a%13==c%13&&c%13==d%13&&b%13==e%13)||(a%13==c%13&&c%13==e%13&&b%13==d%13)||(a%13==d%13&&d%13==e%13&&b%13==c%13)||(b%13==c%13&&c%13==d%13&&a%13==e%13)||(b%13==c%13&&c%13==e%13&&a%13==d%13)||(b%13==d%13&&d%13==e%13&&a%13==c%13)||(c%13==d%13&&d%13==e%13&&a%13==c%13)){
	printf("Full House\n");

}else if (c1==c2&&c2==c3&&c3==c4&&c4==c5){
	printf("Flush\n");

}else if ((a%13+b%13+c%13+d%13+e%13-((a%13)*5)==10)&&(a!=b&&b!=c&&c!=d&&d!=e)){
	printf("Straight\n");

}else if ((a%13==b%13&&b%13==c%13&&d%13!=e%13)||(a%13==b%13&&b%13==d%13&&c%13!=e%13)||(a%13==b%13&&b%13==e%13&&c%13!=d%13)||(a%13==c%13&&c%13==d%13&&b%13!=e%13)||(a%13==c%13&&c%13==e%13&&b%13!=d%13)||(a%13==d%13&&d%13==e%13&&b%13!=c%13)||(b%13==c%13&&c%13==d%13&&a%13!=e%13)||(b%13==c%13&&c%13==e%13&&a%13!=d%13)||(b%13==d%13&&d%13==e%13&&a%13!=c%13)||(c%13==d%13&&d%13==e%13&&a%13!=c%13)){
	printf("Three of a kind");

}else if (a%13==b%13&&c%13==d%13 ||a%13==b%13&&c%13==e%13 ||a%13==b%13&&d%13==e%13 ||a%13==c%13&&d%13==e%13 ||b%13==c%13&&d%13==e%13){
	printf("Two pair\n");

}else if (a%13==b%13 || a%13==c%13 ||a%13==d%13 ||a%13==d%13 ||a%13==e%13 ||b%13==c%13 ||b%13==d%13 ||b%13==e%13 ||c%13==d%13 ||c%13==e%13 ||d%13==e%13 ){
	printf("One pair\n");

}else   {
	printf("High card\n");
}

}

