#include <stdio.h>


int main(){


int a,b,c,d,e,f,g;
int reverse;
int before,after;	
printf("Please enter an unsigned 16-bit interger: \n");
scanf("%d",&a);
if (a>=32768){
	before = a/32768*100000+(a%32768)/4096*10000+(a%4096)/512*1000+(a%512)/64*100+(a%64)/8*10+a%8*1;
	}		
else if (a>=4096 && a<32768){
	before = (a/4096)*10000+(a%4096)/512*1000+(a%512)/64*100+(a%64)/8*10+a%8*1;
	}
else if (a>=512 && a<4096){
	before = (a/512)*1000+(a%512)/64*100+(a%64)/8*10+a%8*1;
	}
else if (a>=64 && a<512){
	before = (a/64)*100+(a%64)/8*10+(a%8)*1;
	}
else if (a>=8 && a<64){
	before = (a/8)*10+(a%8)*1;
	}
else if (a>=0 && a<8){
	before = (a%8)*1;
	}
printf("Before Flip:  \n");
printf("%d_10 = %d_8\n",a,before);

	b=before%10;
	c=(before%100)/10;
	d=(before%1000)/100;
	e=(before%10000)/1000;
	f=(before%100000)/10000;
	g=(before%1000000)/100000;
if (before >= 100000){
	reverse = b*100000+c*10000+d*1000+e*100+f*10+g*1;
}
else if (before >= 10000 && before <99999){
	reverse = b*10000+c*1000+d*100+e*10+f*1;
}
else if (before >= 1000 && before <9999){
	reverse = b*1000+c*100+d*10+e*1;
}
else if (before >=100 && before < 999){
	reverse = b*100+c*10+d*1;
}
else if (before >=10 && before <99){
	reverse = b*10+c*1;
}
else if (before >=0 && before <9){
	reverse = b*1;
}

after = (reverse%10)*1+((reverse%100)/10)*8+((reverse%1000)/100)*64+((reverse%10000)/1000)*512+((reverse%100000)/10000)*4096+((reverse%1000000)/100000)*32768;
printf("After Filp:  \n");
printf("%d_8 = %d_10\n",reverse,after);
}
 





