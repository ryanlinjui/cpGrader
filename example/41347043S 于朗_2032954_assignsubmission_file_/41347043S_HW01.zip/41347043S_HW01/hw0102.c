#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
 int main(){
	char x;
	char y;
	char z;
	int a,b,c;
	int d,e,f;
	int sum;
	int one,result;
	
	printf("Please enter the first operand: \n");
	scanf("%d%c%d",&a,&x,&b);
	if ( a>=10 || b>=10 ){
		printf("Error\n");
		return 0;
		}

	printf("Please enter the second operand: \n");
	scanf("\n%c%d%c",&y,&c,&z);
	if ( c>=10){
		printf("Error\n");
		return 0;
		}
	
	printf("Please enter the sum: \n");
	scanf("%d", &sum);

	
	
	one = a*100+c*10+b;
	result = sum - one;
	d=result/100;
	e=result%10;
	f=result/10-(result/100)*10;
	printf("Ans: x = %d, y = %d, z=%d\n",f,d,e);
	return 0;
}
