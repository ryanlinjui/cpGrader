#include <stdio.h>
#include <stdlib.h>
#include <math.h>


void print_binary(int n, int *ptr)
{
    if  (n!= 0) {

	  *ptr = n/8;
	  printf("%d", *ptr++);
	  *ptr =  (n%8)/4;
	  printf("%d", *ptr++);
	  *ptr = (n%4)/2;
	  printf("%d", *ptr++);
	  *ptr = n%2;
	   printf("%d", *ptr);
    }
	else if (n==0) printf("0000");
}

int main(){
	int a,i,j=0,f;
	int bint[16]={0};
	unsigned int rev;
	double exp;
	float p,q;
	double r;
	int temp;
	int k=0;
	int t[16];
	int opt,value;
	char str[4];
	printf("Please input a hex:");
	scanf("%s",&str[0]);
	sscanf(&str[0], "%x", &a);
	
	printf("Binary of %x is:  ", a);
	t[0] = ( a & 0xF000) >> 12;
	t[1] = ( a & 0xF00 ) >> 8;
	t[2] = ( a & 0xF0 ) >> 4;
	t[3] = a & 0xF;
	for (i=0;i<=3;i++){
	print_binary(t[i], &bint[4 * i]);
		printf("  ");
	};


printf("\n");


	printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):   ");
	scanf("%d",&opt);
	if (opt==1){


        if (bint[0]==0){
                         temp = bint[15]*1+bint[14]*2+bint[13]*4+bint[12]*8+bint[11]*16+bint[10]*32+bint[9]*64+bint[8]*128+bint[7]*256+bint[6]*512+bint[5]*1024+bint[4]*2048+bint[3]*4096+bint[2]*8192+bint[1]*16384;
            printf("Converted signed integer: %d\n", temp);
            }
        else if (bint[0]==1){
                for (int x=1;x<16;x++){
                        if (bint[x]==0) {bint[x]=1;}
                        else if (bint[x]==1) {bint[x]=0;}
                }
            temp = bint[15]*1+bint[14]*2+bint[13]*4+bint[12]*8+bint[11]*16+bint[10]*32+bint[9]*64+bint[8]*128+bint[7]*256+bint[6]*512+bint[5]*1024+bint[4]*2048+bint[3]*4096+bint[2]*8192+bint[1]*16384+1;
            printf("Converted signed integer:-%d\n", temp);
            }
	}else if (opt == 2){
		printf("Converted unsigned integer is: %d \n",a);
	}else if (opt == 3){
			exp = bint[1]*16+bint[2]*8+bint[3]*4+bint[4]*2+bint[5]*1;
			p = 1+bint[6]*0.5+bint[7]*0.25+bint[8]*0.125+bint[9]*0.0625+bint[10]*0.03125+bint[11]*0.015625+bint[12]*0.0078125+bint[13]*0.00390625+bint[14]*0.001953125+bint[15]*0.0009765625;
			r=pow(2,exp-15);
			q=p*r;
			if (bint[0]==1)
				printf("Converted float is -%f \n",q);
			else if (bint[0]==0)
				printf("Converted float is %f \n",q);
		}
}
