#include <stdio.h>
 int main(){
	printf("\033[0;31m[KIM]\033[m\n");
	printf("\033[0;31mYou are sunlight and I moon\033[m\n");
	printf("\033[0;31mJoined by the gods of fortune\033[m\n");
	printf("\033[0;31mMidnight and high noon sharing the sky\033[m\n");
	printf("\033[0;31mWe have been blessed , you and I\033[m\n");
	printf("\n");
	printf("\033[0;34m[CHRIS]\n"
 		"You are here like a mystery\n"
	 	"I'm from a world that's so different from all that you are\n"
	 	"How in the light of one night did we come so far?\033[m\n");
	printf("\n");
 	printf("\033[0;31m[KIM]\n"
 		"Outside day starts to dawn\033[m\n");
	printf("\n");
	printf("\033[0;34m[CHRIS]\n"
	       "Your moon still floats on high\033[m\n");
	printf("\n");
	printf("\033[0;31m[KIM]\n"
	       "The birds awake\033[m\n");
	printf("\n");
	printf("\033[0;34m[CHRIS]\n"
	       "The stars shine too\033[m\n");
	printf("\n");
	printf("\033[0;31m[KIM]\n"
 	       "My hands still shake\n"
		"See upcoming pop shows\n"
 		"Get tickets for your favorite artists\n"
		"You might also like\n"
		"My Boy Only Breaks His Favorite Toys\n"
 		"Taylor Swift\n"
 		"Who’s Afraid of Little Old Me?\n"
 		"Taylor Swift\n"
 		"Guilty as Sin?\n"
 		"Taylor Swift\033[m\n");
 	printf("\n");
	printf("\033[0;34m[CHRIS]\n"
		"I reach for you\033[m\n");
	printf("\n");
	printf("\033[0;32m[KIM & CHRIS]\n"
		"And we meet in the sky\033[m\n");
	printf("\n");
	printf("\033[0;31m[KIM]\n"
	"You are sunlight and I moon\n"
 	"Joined here\n"
 	"Brightening the sky with the flame of love\033[m\n");
 	printf("\n");
 	printf("\033[0;32m[KIM & CHRIS]\n"
 	"Made of\n"
	"Sunlight\n"
 	"Moonlight\033[m\n");
}
 
	
 
