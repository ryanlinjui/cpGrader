#include<stdio.h>
#include<stdint.h>
int main(){
    int32_t num16;
    int32_t a,b,c,d;
    int32_t num10;
    int32_t choose;
    int32_t num;
    int32_t e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;
    int32_t EXP,sum;
    printf("Please input a hex:");
    scanf("%X",&num16);
    
    printf("Please choose the output type(1:integer,2:unsigned integer,3:float):");
    scanf("%d",&choose);
    if(choose>3||choose<0){
        printf("Error\n");
        return 0;
    }
    printf("Binary of ");
    printf("%X is: ",num16);
    num10=num16;
    // printf("%d\n",num10);
    // num10==e*1+f*2+g*4+h*8+i*16+j*32+k*64+l*128+m*256+n*512+o*1024+p*2048+q*4096+r*8192+s*16384+t*32768;
    if(num10>=32768){
        t=1;
        num10=num10-32768;
    }
    else {
        t=0;
        num10=num10;
    }
    if(num10>=16384){
        s=1;
        num10=num10-16384;
    }
    else if(num10<16384){
        s=0;
        num10=num10;
    }
    if(num10>=8192){
        r=1;
        num10=num10-8192;
    }
    else if(num10<8192){
        r=0;
        num10=num10;
    }
    if(num10>=4096){
        q=1;
        num10=num10-4096;
    }
    else if(num10<4096){
        q=0;
        num10=num10;
    }
    if(num10>=2048){
        p=1;
        num10=num10-2048;
    }
    else if(num10<2048){
        p=0;
        num10=num10;
    }
    if(num10>=1024){
        o=1;
        num10=num10-1024;
    }
    else if(num10<1024){
        o=0;
        num10=num10;
    }
    if(num10>=512){
        n=1;
        num10=num10-512;
    }
    else if(num10<512){
        n=0;
        num10=num10;
    }
    if(num10>=256){
        m=1;
        num10=num10-256;
    }
    else if(num10<256){
        m=0;
        num10=num10;
    }
    if(num10>=128){
        l=1;
        num10=num10-128;
    }
    else if(num10<128){
        l=0;
        num10=num10;
    }
    if(num10>=64){
        k=1;
        num10=num10-64;
    }
    else if(num10<64){
        k=0;
        num10=num10;
    }
    if(num10>=32){
        j=1;
        num10=num10-32;
    }
    else if(num10<32){
        j=0;
        num10=num10;
    }
    if(num10>=16){
        i=1;
        num10=num10-16;
    }
    else if(num10<16){
        i=0;
        num10=num10;
    }
    if(num10>=8){
        h=1;
        num10=num10-8;
    }
    else if(num10<8){
        h=0;
        num10=num10;
    }
    if(num10>=4){
        g=1;
        num10=num10-4;
    }
    else if(num10<4){
        g=0;
        num10=num10;
    }
    if(num10>=2){
        f=1;
        num10=num10-2;
    }
    else if(num10<2){
        f=0;
        num10=num10;
    }
    if(num10>=1){
        e=1;
        num10=num10-1;
    }
    else if(num10<1){
        e=0;
        num10=num10;
    }
    
    printf("%d%d%d%d ",t,s,r,q);
    printf("%d%d%d%d ",p,o,n,m);
    printf("%d%d%d%d ",l,k,j,i);
    printf("%d%d%d%d\n",h,g,f,e);

    printf("Converted ");
    if(choose==1){
        printf("integer is: ");
    }
    else if(choose==2){
        printf("unsigned integer is: ");
    }
    else if(choose==3){
        printf("float is: ");
    }

    if(choose==2){
        printf("%d\n",num16);
    }
    if(choose==3){
        double x1=0.5;
        double x2=0.25;
        double x3=0.125;
        double x4=0.0625;
        double x5=0.03125;
        double x6=0.015625;
        double x7=0.0078125;
        double x8=0.00390625;
        double x9=0.00195312;
        double x10=0.00097656;
        double F;
        double S;
        F=n*x1+m*x2+l*x3+k*x4+j*x5+i*x6+h*x7+g*x8+f*x9+e*x10;
        S=F+1;
        EXP=s*16+r*8+q*4+p*2+o*1;
        sum=EXP-15;
        if(EXP==0&&F==0&&t==1){
            printf("-0.0\n");
            return 0;
        }
        else if(EXP==0&&F==0&&t==0){
            printf("+0.0\n");
            return 0;
        }
        else if(EXP==31&&F==0&&t==1){
            printf("-INF\n");
            return 0;
        }
        else if(EXP==31&&F==0&&t==0){
            printf("+INF\n");
            return 0;
        }
        else if(EXP==31&&F!=0){
            printf("NAN\n");
            return 0;
        }
        else if(t==1){
            printf("-%lf",S);
            printf("*2^%d\n",sum);
        }
        else if(t==0){
            printf("%lf",S);
            printf("*2^%d\n",sum);
        }
    }
    if(choose==1){
        if(t==0){
            printf("%d\n",num16);
        }
        else if(t==1){
            if(s==1){
                s=0;
            }
            else if(s==0){
                s=1;
            }
            if(r==1){
                r=0;
            }
            else if(r==0){
                r=1;
            }
            if(q==1){
                q=0;
            }
            else if(q==0){
                q=1;
            }
            if(p==1){
                p=0;
            }
            else if(p==0){
                p=1;
            }
            if(o==1){
                o=0;
            }
            else if(o==0){
                o=1;
            }
            if(n==1){
                n=0;
            }
            else if(n==0){
                n=1;
            }
            if(m==1){
                m=0;
            }
            else if(m==0){
                m=1;
            }
            if(l==1){
                l=0;
            }
            else if(l==0){
                l=1;
            }
            if(k==1){
                k=0;
            }
            else if(k==0){
                k=1;
            }
            if(j==1){
                j=0;
            }
            else if(j==0){
                j=1;
            }
            if(i==1){
                i=0;
            }
            else if(i==0){
                i=1;
            }
            if(h==1){
                h=0;
            }
            else if(h==0){
                h=1;
            }
            if(g==1){
                g=0;
            }
            else if(g==0){
                g=1;
            }
            if(f==1){
                f=0;
            }
            else if(f==0){
                f=1;
            }
            if(e==1){
                e=0;
            }
            else if(e==0){
                e=1;
            }
            // printf("%d%d%d%d ",t,s,r,q);
            // printf("%d%d%d%d ",p,o,n,m);
            // printf("%d%d%d%d ",l,k,j,i);
            // printf("%d%d%d%d\n",h,g,f,e);
            num=s*16384+r*8192+q*4096+p*2048+o*1024+n*512+m*256+l*128+k*64+j*32+i*16+h*8+g*4+f*2+e*1+1;
            printf("-%d\n",num);
            }  
    return 0;

    }
}
