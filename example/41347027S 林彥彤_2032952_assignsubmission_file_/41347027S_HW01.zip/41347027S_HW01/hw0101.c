#include<stdio.h>
#include<stdint.h>
#define Red "\e[1;31m"
#define Blue "\e[1;34m"
#define Green "\e[1;32m"
int main(){
    printf(Red "[KIM]\n");
    printf(Red "You are sunlight and I moon\n");
    printf(Red "Joined by the gods of fortune\n");
    printf(Red "Midnight and high noon sharing the sky\n");
    printf(Red "We have been blessed , you and I\n\n");
    printf(Blue "[CHRIS]\n");
    printf(Blue "You are here like a mystery\n");
    printf(Blue "I'm from a world that's so different from all that you are\n");
    printf(Blue "How in the light of one night did we come so far?\n\n");
    printf(Red "[KIM]\n");
    printf(Red "Outside day starts to dawn\n\n");
    printf(Blue "[CHRIS]\n");
    printf(Blue "Your moon still floats on high\n\n");
    printf(Red "[KIM]\n");
    printf(Red "The birds awake\n\n");
    printf(Blue "[CHRIS]\n");
    printf(Blue "The stars shine too\n\n");
    printf(Red "[KIM]\n");
    printf(Red "My hands still shake\n");
    printf(Red "See upcoming pop shows\n");
    printf(Red "Get tickets for your favorite artists\n");
    printf(Red "You might also like\n");
    printf(Red "My Boy Only Breaks His Favorite Toys\n");   
    printf(Red "Taylor Swift\n");
    printf(Red "Who’s Afraid of Little Old Me?\n");
    printf(Red "Taylor Swift\n");
    printf(Red "Guilty as Sin?\n");
    printf(Red "Taylor Swift\n\n");
    printf(Blue "[CHRIS]\n");
    printf(Blue "I reach for you\n\n");
    printf(Green "[KIM&CHRIS]\n");
    printf(Green "And we meet in the sky\n\n");
    printf(Red "[KIM]\n");
    printf(Red "You are sunlight and I moon\n");
    printf(Red "Joined here\n");
    printf(Red "Brightening the sky with the flame of love\n\n");
    printf(Green "[KIM&CHRIS]\n");
    printf(Green "Made of\n");
    printf(Green "Sunlight\n");
    printf(Green "Moonlight\n");
return 0;
}
