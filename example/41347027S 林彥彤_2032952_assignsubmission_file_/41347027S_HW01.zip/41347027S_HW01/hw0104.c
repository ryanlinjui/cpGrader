#include<stdio.h>
#include<stdint.h>
int main(){
    int32_t a,b,c,d,e,f;
    int32_t v,w,x,y,z;
    printf("Please enter 5 cards: ");
    char m,n,o,p,q;
    scanf("%d%c%d%c%d%c%d%c%d",&a,&m,&b,&n,&c,&o,&d,&p,&e);
    scanf("%c",&q);
    if(a<1||a>52){
        printf("Error\n");
        return 0;
    }
    if(b<1||b>52){
        printf("Error\n");
        return 0;
    }
    if(c<1||c>52){
        printf("Error\n");
        return 0;
    }
    if(d<1||d>52){
        printf("Error\n");
        return 0;
    }
    if(e<1||e>52){
        printf("Error\n");
        return 0;
    }
    if(a==b||b==c||c==d||d==e||a==c||a==d||a==e||b==d||b==e||c==e){
        printf("Error\n");
        return 0;
    }
    v=a/13;
    w=b/13;
    x=c/13;
    y=d/13;
    z=e/13;
    a=a%13;
    b=b%13;
    c=c%13;
    d=d%13;
    e=e%13;
    if(a==0){
        v=v-1;
    }
    if(b==0){
        w=w-1;
    }
    if(c==0){
        x=x-1;
    }
    if(d==0){
        y=y-1;
    }
    if(e==0){
        z=z-1;
    }
    if(a>b){
        f=a;
        a=b;
        b=f;
    }
    if(b>c){
        f=b;
        b=c;
        c=f;
    }
    if(c>d){
        f=c;
        c=d;
        d=f;
    }
    if(d>e){
        f=d;
        d=e;
        e=f;
    }
    if(a>b){
        f=a;
        a=b;
        b=f;
    }
    if(b>c){
        f=b;
        b=c;
        c=f;
    }
    if(c>d){
        f=c;
        c=d;
        d=f;
    }
    if(a>b){
        f=a;
        a=b;
        b=f;
    }
    if(b>c){
        f=b;
        b=c;
        c=f;
    }
    if(a>b){
        f=a;
        a=b;
        b=f;
    }
    if(a==b&&b==c&&c==d&&d==e){
        printf("Error\n");
        return 0;
    }
    // printf ("%d, %d, %d, %d, %d\n", a, b, c, d, e);
    // printf ("%d, %d, %d, %d, %d\n", v, w, x, y, z);


    if(a==1&&b==2&&c==3&&d==4&&e==5&&v==w&&w==x&&x==y&&y==z){
        printf("Straight flush\n");
    }
    else if(a==2&&b==3&&c==4&&d==5&&e==6&&v==w&&w==x&&x==y&&y==z){
        printf("Straight flush\n");
    }
    else if(a==3&&b==4&&c==5&&d==6&&e==7&&v==w&&w==x&&x==y&&y==z){
        printf("Straight flush\n");
    }
    else if(a==4&&b==5&&c==6&&d==7&&e==8&&v==w&&w==x&&x==y&&y==z){
        printf("Straight flush\n");
    }
    else if(a==5&&b==6&&c==7&&d==8&&e==9&&v==w&&w==x&&x==y&&y==z){
        printf("Straight flush\n");
    }
    else if(a==6&&b==7&&c==8&&d==9&&e==10&&v==w&&w==x&&x==y&&y==z){
        printf("Straight flush\n");
    }
    else if(a==7&&b==8&&c==9&&d==10&&e==11&&v==w&&w==x&&x==y&&y==z){
        printf("Straight flush\n");
    }
    else if(a==8&&b==9&&c==10&&d==11&&e==12&&v==w&&w==x&&x==y&&y==z){
        printf("Straight flush\n");
    }
    else if(a==0&&b==9&&c==10&&d==11&&e==12&&v==w&&w==x&&x==y&&y==z){
        printf("Straight flush\n");
    }
    else if(a==0&&b==1&&c==10&&d==11&&e==12&&v==w&&w==x&&x==y&&y==z){
        printf("Straight flush\n");
    }
    else if(a==1&&b==2&&c==3&&d==4&&e==5){
        printf("Straight\n");
    }
    else if(a==2&&b==3&&c==4&&d==5&&e==6){
        printf("Straight\n");
    }
    else if(a==3&&b==4&&c==5&&d==6&&e==7){
        printf("Straight\n");
    }
    else if(a==4&&b==5&&c==6&&d==7&&e==8){
        printf("Straight\n");
    }
    else if(a==5&&b==6&&c==7&&d==8&&e==9){
        printf("Straight\n");
    }
    else if(a==6&&b==7&&c==8&&d==9&&e==10){
        printf("Straight\n");
    }
    else if(a==7&&b==8&&c==9&&d==10&&e==11){
        printf("Straight\n");
    }
    else if(a==8&&b==9&&c==10&&d==11&&e==12){
        printf("Straight\n");
    }
    else if(a==9&&b==10&&c==11&&d==12){
        printf("Straight\n");
    }
    else if(a==10&&b==11&&c==12&&d==0&&e==1){
        printf("Straight\n");
    }
    else if(v==w&&w==x&&x==y&&y==z){
        printf("Flush\n");
    }
    else if(a==b&&b==c&&c==d){
        printf("Four of a kind\n");
    }
    else if(b==c&&c==d&&d==e){
        printf("Four of a kind\n");
    }
    else if(a==b&&b==c&&d==e){
        printf("Full house\n");
    }
    else if(a==b&&c==d&&d==e){
        printf("Full house\n");
    }
    else if(a==b&&b==c){
        printf("Three of a kind\n");
    }
    else if(b==c&&c==d){
        printf("Three of a kind\n");
    }
    else if(c==d&&d==e){
        printf("Three of a kind\n");
    }
    else if(a==b&&c==d){
        printf("Two pair\n");
    }
    else if(a==b&&d==e){
        printf("Two pair\n");
    }
    else if(b==c&&d==e){
        printf("Two pair\n");
    }
    else if(a==b){
        printf("One pair\n");
    }
    else if(b==c){
        printf("One pair\n");
    }
    else if(c==d){
        printf("One pair\n");
    }
    else if(d==e){
        printf("One pair\n");
    }
    else{
        printf("High card\n");
    }
return 0;
}