#include<stdio.h>
#include<stdint.h>
int main()
{
    int32_t a=-1;
    int32_t c=-1;
    int32_t e=-1;
    int32_t sum;
    int32_t num1,num2;
    int32_t m,n,o;
    printf("Please enter the first operand:");
    char x;
    char b;
    scanf("%d%c%d",&a,&x,&c);
    scanf("%c",&b);
    printf("Please enter the second operand:");
    char y;
    char z;
    scanf("%c%d%c",&y,&e,&z);
    scanf("%c",&b);
    if(a<0||c<0||e<0||a>9||c>9||e>9){
        printf("Error\n");
        return 0;
    }
    printf("Please enter the sum:");
    scanf("%d",&sum);
    if(sum>1998){
        printf("Error\n");
        return 0;
    }

    //num1=100*a+10*x+c;
    //num2=100*y+10*e+z;

    o=sum%10;
    n=(sum%100-o)/10;
    m=sum/100;
    
    if(o>=c){
        z=o-c;
    }
    else if(o<c){
        z=(o+10)-c;
        n=n-1;
    }
    if(n>=e){
        x=n-e;
    }
    else if(n<e){
        x=(n+10)-e;
        m=m-1;
    }
    y=m-a;
    if(y>9||y<0){
        printf("Error\n");
        return 0;
    }
    printf("Ans:x=%d,y=%d,z=%d\n",x,y,z);
return 0;
}