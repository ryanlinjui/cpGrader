#include<stdio.h>
#include<stdint.h>
int main(){
    int32_t a,b,c,d,e,f;
    int32_t num10;
    int32_t num8;
    printf("Please enter an unsigned 16-bits number:");
    scanf("%d",&num10);
    f=num10%8;
    a=(num10-f)/32798;
    b=(num10-f)%32798/4096;
    c=(num10-f)%4096/512;
    d=(num10-f)%512/64;
    e=(num10-f)%64/8;

    num8=a*100000+b*10000+c*1000+d*100+e*10+f;
    printf("Before Flip:\n");
    printf("%d_10=%d_8\n",num10,num8);
    num8=f*100000+e*10000+d*1000+c*100+b*10+a;
    if(a==0&&b==0&&c==0&&d==0&&e==0&&f==0){
        num8=num8/1000000;
        return 0;
    }
    else if(a==0&&b==0&&c==0&&d==0&&e==0){
        num8=num8/100000;
        a=f;
        b=0;
        c=0;
        d=0;
        e=0;
        f=0;
    }
    else if(a==0&&b==0&&c==0&&d==0){
        num8=num8/10000;
        a=e;
        b=f;
        c=0;
        d=0;
        e=0;
        f=0;
    }
    else if(a==0&&b==0&&c==0){
        num8=num8/1000;
        a=d;
        b=e;
        c=f;
        d=0;
        e=0;
        f=0;
    }
    else if(a==0&&b==0){
        num8=num8/100;
        a=c;
        b=d;
        c=e;
        d=f;
        e=0;
        f=0;
    }
    else if(a=0){
        num8=num8/10;
        a=b;
        b=c;
        c=d;
        d=e;
        e=f;
        f=0;
    }
    
    num10=f*32798+e*4096+d*512+c*64+b*8+a;
    printf("After Flip:\n");
    printf("%d_8=%d_10\n",num8,num10);
return 0;
}
