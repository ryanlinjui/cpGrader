#include <stdio.h>
#include <stdint.h>
#define normal "\e[m"
#define cyan "\x1b[36m"

int main ()//將數字轉成8進位，顛倒過來後再轉成10進位
{
    printf("%s\nhw0103\n%s",cyan,normal);

    unsigned input=65536;
    int one=0,ten=0,hun=0,tho=0,txo=0,tt=0,head=0,count=0,x=1;
    
    printf("please enter an unsigned 16-bits number(0~65535):\n");
    scanf("%u",&input);
    
    if(input>65535||input<0)
    printf("wrong input! please try number between(0~65535)\n");

    else//10進位轉8進位
    {
        if(input>=8)
        {
            one=input%8;
            input=input/8;
            count=count+1;
        }
        if(input>=8)
        {
            ten=input%8;
            input=input/8;
            count=count+1;
        }
        if(input>=8)
        {
            hun=input%8;
            input=input/8;
            count=count+1;
        }
        if(input>=8)
        {
            tho=input%8;
            input=input/8;
            count=count+1;
        }
        if(input>=8)
        {
            txo=input%8;
            input=input/8;
            count=count+1;
        }
        if(input>=0)
        {
            head=input%8;
        }
        
        switch(count)//幫首數程上10的次方
        {
            case 1:
                x=10;
                break;
            case 2:
                x=100;
                break;
            case 3:
                x=1000;
                break;
            case 4:
                x=10000;
                break;
            case 5:
                x=100000;
                break;
        }
        
        tt=one+ten*10+hun*100+tho*1000+txo*10000+head*x;
        printf("input_8=%d\n",tt);
        
        int re;
        printf("flip=");
        switch(count)//印出翻轉數字、轉八進位
        {
            case 0:
                printf("%d",head);
                re=head;
                break;
            case 1:
                printf("%d%d",one,head);
                re=one*8+head;
                break;
            case 2:
                printf("%d%d%d",one,ten,head);
                re=one*64+ten*8+head;
                break;
            case 3:
                printf("%d%d%d%d",one,ten,hun,head);
                re=one*512+ten*64+hun*8+head;
                break;
            case 4:
                printf("%d%d%d%d%d",one,ten,hun,tho,head);
                re=one*4069+ten*512+hun*64+tho*8+head;
                break;
            case 5:
                printf("%d%d%d%d%d%d",one,ten,hun,tho,txo,head);
                re=one*32678+ten*4069+hun*512+tho*64+txo*8+head;
                break;
        }
        printf("\nresult=%d\n",re);



        
        

        



    }
    


    
    

    return 0;
}
