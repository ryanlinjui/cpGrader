#include <stdio.h>

#define red "\033[31m"
#define blue "\x1b[34m"
#define green "\x1b[32m"
#define normal "\e[m"
#define magenta "\x1b[35m"
#define cyan "\x1b[36m"

int main()
{
    //printf("color test:\n");
    //printf("%sThis is red text%s\n",red,normal);

    printf("%s\nhw0101\n",cyan);
    printf("%s[KIM]\n",normal);
    printf("%sYou are sunlight and I moon\nJoined by the gods of fortune\nMidnight and high noon sharing the sky\nWe have been blessed , you and I\n%s",red,normal);
    printf("%s\n[CHRIS]\n",normal);
    printf("%sYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\n%s",blue,normal);
    printf("%s\n[KIM]\n",normal);
    printf("%sOutside day starts to dawn\n",red);
    printf("%s\n[CHRIS]\n",normal);
    printf("%sYour moon still floats on high\n",blue);
    printf("%s\n[KIM]\n",normal);
    printf("%sThe birds awake\n",red);
    printf("%s\n[CHRIS]\n",normal);
    printf("%sThe stars shine too\n",blue);
    printf("%s\n[KIM]\n",normal);
    printf("%sMy hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n\nYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho's Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n",red);
    printf("%s\n[CHRIS]\n",normal);
    printf("%sI reach for you\n",blue);
    printf("%s\n[KIM]&[CHRIS]\n",normal);
    printf("%sAnd we meet in the sky\n",green);
    printf("%s\n[KIM]\n",normal);
    printf("%sYou are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n",red);
    printf("%s\n[KIM]&[CHRIS]\n",normal);
    printf("%sMade of\nSunlight\nMoonlight\n%s",green,normal);


    return 0;
}