#include <stdio.h>
#define cyan "\x1b[36m"
#define normal "\e[m"

int main()//求算式解
{
    printf("%s\nhw0102\n%s",cyan,normal);
    
    int a,b,c,sum,block;
    int st,sh,sd,so;
    
    printf("please enter the first operand:");
    scanf("%dx%d",&a,&b);
    printf("please enter the second operand:");
    scanf(" y%dz",&c);//這行y前面要加個空格不知道為啥下面那行不用
    printf("please enter the sum:");
    scanf("%d",&sum);
    //printf("%dx%d y%dz %d",a,b,c,sum);
    
    if(a<0||b<0||c<0||a>=10||b>=10||c>=10)
    {
        printf("please check your input\n");
        block=1;
    }

if(block!=1)
{
    so=sum%10;
    sd=sum/10%10;
    sh=sum/100;
    //printf("%d %d %d",sh,sd,so);

    int x=-1,y=-1,z=-1;

    if(so>=b)
    {
        z=so-b;
    }
    else
    {
        z=so+10-b;
        sd=sd-1;
    }
    if(sd>=c)
    {
        x=sd-c;
    }
    else
    {
        x=sd+10-c;
        sh=sh-1;
    }
    if(sh>=a)
    {
        y=sh-a;
    }
    else 
    printf("\n\033[31msth is wrong...\n");

    if(x<0||y<0||z<0)
    {
        printf("\033[31mplease check your input\e[m\n");
    }
    
    else
    printf("x=%d y=%d z=%d\n",x,y,z);
}
    
    
  
  
    return 0;
}
