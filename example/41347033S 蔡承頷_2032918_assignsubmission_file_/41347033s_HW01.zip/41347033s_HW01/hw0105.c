#include <stdio.h>
#include <stdint.h> 
#define normal "\e[m"
#define cyan "\x1b[36m"
#define red "\033[31m"

int main()//16進位轉成各項輸出
{
    printf("%s\nhw0105\n%s",cyan,normal);

    int in=0,output;
    int b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,b16;

    printf("please input a hex:");
    scanf("%x",&in);
    //printf("%d\n",scanf("%x",&in));
    //printf("%x\n",in);
    printf("please choose the output type (1:integer,2:unsigned integer,3:float) :");
    scanf("%d",&output);
    //轉2進位
    b1=in%2;
    b2=in/2%2;
    b3=in/4%2;
    b4=in/8%2;
    b5=in/16%2;
    b6=in/32%2;
    b7=in/64%2;
    b8=in/128%2;
    b9=in/256%2;
    b10=in/512%2;
    b11=in/1024%2;
    b12=in/2048%2;
    b13=in/4096%2;
    b14=in/8192%2;
    b15=in/16384%2;
    b16=in/32768%2;

    if(output==1||output==2||output==3)
        printf("binary= %hd%hd%hd%hd %hd%hd%hd%hd %hd%hd%hd%hd %hd%hd%hd%hd\n",b16,b15,b14,b13,b12,b11,b10,b9,b8,b7,b6,b5,b4,b3,b2,b1);

    if(output==1)
    printf("interger= %hd\n",in);

    else if(output==2)
    printf("unsigned interger= %u\n",in);

    else if(output==3)
    {
        //float
        double f=0;
        int exp=0;
        exp=b15*16+b14*8+b13*4+b12*2+b11-15;
        f=1+b10/2.0+b9/4.0+b8/8.0+b7/16.0+b6/32.0+b5/64.0+b4/128.0+b3/256.0+b2/512.0+b1/1024.0;
        //printf("f=%lf exp=%d\n",f,exp);
        if(exp==-15&&f==1)
        {
            if(b16==0)
            {
                printf("float=+0.0\n");
            }
            if(b16==1)
            {
                printf("float=-0.0\n");
            }
        }
        else if(exp==16&&f==1)
        {
            if(b16==0)
            {
                printf("float= +INF\n");
            }
            if(b16==1)
            {
                printf("float= -INF\n");
            }
        }
         else if(exp==16&&f!=1)
        {
           printf("float= NAN");
        }
        else if(b16==1)
        {
            printf("float= -%lf*2^%d",f,exp);
        }
        else if(b16==0)
        {
            printf("float= %lf*2^%d",f,exp);
        }
    }
    else
    {
        printf("%splease check ypur input%s\n",red,normal);
    }
    

    
    

    

    return 0;
}
