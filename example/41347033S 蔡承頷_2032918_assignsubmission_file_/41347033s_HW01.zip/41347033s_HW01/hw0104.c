#include <stdio.h>
#define normal "\e[m"
#define cyan "\x1b[36m"

int main()//判斷卡牌組合
{
    printf("%s\nhw0104\n%s",cyan,normal);

    int a=-1,b=-22,c=-3,d=-4,e=-5,temp=-1,block=0;

    printf("please enter 5 card:\n");
    scanf("%d %d %d %d %d",&a,&b,&c,&d,&e);

    if(a<=0||b<=0||c<=0||d<=0||e<=0||a>52||b>52||c>52||d>52||e>52)
    {
        printf("please enter number between[1~52]\n");
        block=1;
    }
         

    if(a==b||a==c||a==d||a==e||b==c||b==d||b==e||c==d||c==e||d==e)
    {
        printf("please don't enter same number\n");
        block=1;
    }
        
if(block!=1)
{
    //sort 
    if(a>b)
    {
        temp=b;
        b=a;
        a=temp;
    }
    if(b>c)
    {
        temp=c;
        c=b;
        b=temp;
    }
    if(c>d)
    {
        temp=d;
        d=c;
        c=temp;
    }
    if(d>e)
    {
        temp=e;
        e=d;
        d=temp;
    }
    //sort2
        if(a>b)
    {
        temp=b;
        b=a;
        a=temp;
    }
    if(b>c)
    {
        temp=c;
        c=b;
        b=temp;
    }
    if(c>d)
    {
        temp=d;
        d=c;
        c=temp;
    }
    //sort3
        if(a>b)
    {
        temp=b;
        b=a;
        a=temp;
    }
    if(b>c)
    {
        temp=c;
        c=b;
        b=temp;
    }
    //sort4
        if(a>b)
    {
        temp=b;
        b=a;
        a=temp;
    }
    temp=0;//重設來看有沒有湊到牌種
    //printf("%d %d %d %d %d\n",a,b,c,d,e);

    //Flush(同花)
    int straight=0;
    if((a-1)/13==(b-1)/13&&(a-1)/13==(c-1)/13&&(a-1)/13==(d-1)/13&&(a-1)/13==(e-1)/13)
    {
        if(a+1==b&&a+2==c&&a+3==d&&a+4==e)//Straight Flush(同花順)
        {
            printf("Straight Flush\n");
            straight=1;//防止下面又偵測到一次straight
        }
        else if(a%13==1&&b%13==10&&c%13==11&&d%13==12&&e%13==0)//同花順特例10 11 12 13 1
        {
            printf("Straight Flush\n");
            straight=1;
        }
        else
        {
            printf("Flush\n");
            temp=1;
        }
    }

    //接下來只看點數
    a=a%13;
    b=b%13;
    c=c%13;
    d=d%13;
    e=e%13;
    //sort again(取餘數後順序不一定正確)
    if(a>b)
    {
        temp=b;
        b=a;
        a=temp;
    }
    if(b>c)
    {
        temp=c;
        c=b;
        b=temp;
    }
    if(c>d)
    {
        temp=d;
        d=c;
        c=temp;
    }
    if(d>e)
    {
        temp=e;
        e=d;
        d=temp;
    }
    //sort2
        if(a>b)
    {
        temp=b;
        b=a;
        a=temp;
    }
    if(b>c)
    {
        temp=c;
        c=b;
        b=temp;
    }
    if(c>d)
    {
        temp=d;
        d=c;
        c=temp;
    }
    //sort3
        if(a>b)
    {
        temp=b;
        b=a;
        a=temp;
    }
    if(b>c)
    {
        temp=c;
        c=b;
        b=temp;
    }
    //sort4
        if(a>b)
    {
        temp=b;
        b=a;
        a=temp;
    }
    temp=0;

    //Pair(同點)
    int count;
    if(a%13==b%13||a%13==c%13||a%13==d%13||a%13==e%13||b%13==c%13||b%13==d%13||b%13==e%13||c%13==d%13||c%13==e%13||d%13==e%13)
    {
        temp=1;
        count=(a==b)+(a==c)+(a==d)+(a==e)+(b==c)+(b==d)+(b==e)+(c==d)+(c==e)+(d==e);
        switch(count)
        {
            case 1:
                printf("One pair\n");
                break;
            case 2:
                printf("Two pair\n");
                break;
            case 3:
                printf("Three of a kind\n");
                break;
            case 4:
                printf("Full House\n");
                break;
            case 6:
                printf("Four Kind\n");
                break;
        }
    }

    //Straight
    if(straight==0&&temp!=1)
    {
        if(a+1==b&&a+2==c&&a+3==d&&a+4==e)
        {
            printf("Straight\n");
            temp=1;
        }
        if(a==0&&b+1==c&&b+2==d&&b+3==e)
        {
            printf("Straight\n");
            temp=1;
        }
        if(a==0&&b==1&&c+1==d&&c+2==e)
        {
            printf("Straight\n");
            temp=1;
        }
    }

    //High Card
    if(straight==0&&temp==0&&block!=1)
        printf("High Card\n");

    //printf("%d %d %d %d %d\n",a,b,c,d,e);
    //printf("temp=%d straight=%d count=%d\n",temp,straight,count);
}
    

    return 0;
}