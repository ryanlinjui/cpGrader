#include <stdio.h>
#include <stdint.h>

int main()
{
int32_t a=0;
int32_t b=0;
int32_t c=0;
int32_t sum=0;
int32_t num1=0;
int32_t num2=0;
int32_t x=0;
int32_t y=0;
int32_t z=0;

printf("Please enter the first operand:\n");
scanf("%dx%d", &a, &b);
if(a<0||a>9)
{
	printf("wrong format\n");
	return 0;
}
if(b<0||b>9)
{
	printf("wrong format\n");
	return 0;
}
printf("Please enter the second operand:\n");
scanf("\n y%dz", &c);
if(c<0||c>9)
{
	printf("wrong format\n");
	return 0;
}
printf("Please enter the sum:\n");
scanf("\n%d", &sum);
if(sum<110|sum>1998)
{
	printf("wrong format\n");
	return 0;
}

num1=a*100+b+c*10;
num2=x*10+y*100+z;

num2=sum-num1;
z=num2%10;
num2=num2/10;
x=num2%10;
num2=num2/10;
y=num2%10;


printf("Ans: x=%d, y=%d, z=%d\n"  , x, y, z );
return 0;
}
