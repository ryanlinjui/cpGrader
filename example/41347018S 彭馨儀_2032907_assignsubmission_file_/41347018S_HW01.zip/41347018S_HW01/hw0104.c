#include<stdio.h>
#include<stdint.h>

int main()
{
	//輸入的五張牌
	int16_t a1=0;
	int16_t b1=0;
	int16_t c1=0;
	int16_t d1=0;
	int16_t e1=0;
	//
	int16_t not_good=0;
	//交換暫存用
	int16_t t=0;
	//花色
	int16_t spade=0;
	int16_t heart=0;
	int16_t diamond=0;
	int16_t club=0;
	//數字(由大到小排序)
	int16_t A=0;
	int16_t B=0;
	int16_t C=0;
	int16_t D=0;
	int16_t E=0;
	
	//Straight flush
	int16_t X1=0;
	//Four of a kind
	int16_t X2=0;
	//Full house
	int16_t X3=0;
	//Flush
	int16_t X4=0;
	//Straight
	int16_t X5=0;
	//Three of a kind
	int16_t X6=0;
	//Two pair
	int16_t X7=0;
	//One pair
	int16_t X8=0;
	//High card
	int16_t X9=0;
			
	printf("Please enter 5 cards:\n");
	scanf("\n%hd %hd %hd %hd %hd", &a1, &b1, &c1, &d1, &e1);
	if((a1<1 && a1>52) || (b1<1 && b1>52) || (c1<1 && c1>52) || (d1<1 && d1>52) || (e1<1 && e1>52))
	{not_good=1;}
	if((a1==b1)||(a1==c1)||(a1==d1)||(a1==e1)||(b1==c1)||(b1==d1)||(b1==e1)||(c1==d1)||(c1==e1)||(d1==e1)) 
	{not_good=1;}
	
	if(not_good==1)
	{printf("wrong card\n");}
	else
	{
			
		//花色數量判定
		if(1<=a1<=13)
		{spade=spade+1;}
		if(14<=a1<=26)
		{heart=heart+1;}
		if(27<=a1<=39)
		{diamond=diamond+1;}
		if(40<=a1<=52)
		{club=club+1;}
		
		if(1<=b1<=13)
		{spade=spade+1;}
		if(14<=b1<=26)
		{heart=heart+1;}
		if(27<=b1<=39)
		{diamond=diamond+1;}
		if(40<=b1<=52)
		{club=club+1;}
		
		if(1<=c1<=13)
		{spade=spade+1;}
		if(14<=c1<=26)
		{heart=heart+1;}
		if(27<=c1<=39)
		{diamond=diamond+1;}
		if(40<=c1<=52)
		{club=club+1;}
		
		if(1<=d1<=13)
		{spade=spade+1;}
		if(14<=d1<=26)
		{heart=heart+1;}
		if(27<=d1<=39)
		{diamond=diamond+1;}
		if(40<=d1<=52)
		{club=club+1;}
		
		if(1<=e1<=13)
		{spade=spade+1;}
		if(14<=e1<=26)
		{heart=heart+1;}
		if(27<=e1<=39)
		{diamond=diamond+1;}
		if(40<=e1<=52)
		{club=club+1;}
		
		//數字整理
		if(a1%13==0)
		{A=13;}
		else
		{A=a1%13;}
		
		if(b1%13==0)
		{B=13;}
		else
		{B=b1%13;}
		
		if(c1%13==0)
		{C=13;}
		else
		{C=c1%13;}
		
		if(d1%13==0)
		{D=13;}
		else
		{D=d1%13;}
		
		if(e1%13==0)
		{E=13;}
		else
		{E=e1%13;}
		
		//由大到小排序
		if(A>B) {t=A; A=B; B=t;}
		if(A>C) {t=A; A=C; C=t;}
		if(A>D) {t=A; A=D; D=t;}
		if(A>E) {t=A; A=E; E=t;}
		if(B>C) {t=B; B=C; C=t;}
		if(B>D) {t=B; B=D; D=t;}
		if(B>E) {t=B; B=E; E=t;}
		if(C>D) {t=C; C=D; D=t;}
		if(C>E) {t=C; C=E; E=t;}
		if(D>E) {t=D; D=E; E=t;}
		
		
		//Straight flush (X1)
		if(((A+1==B) && (B+1==C) && (C+1==D) && (D+1==E)) && (spade==5))
		X1=1;
		if(((A==1) && (B==10) && (C==11) && (D==12) && (E==13)) && (spade==5))
		X1=1;
		if(((A+1==B) && (B+1==C) && (C+1==D) && (D+1==E)) && (heart==5))
		X1=1;
		if(((A==1) && (B==10) && (C==11) && (D==12) && (E==13)) && (heart==5))
		X1=1;
		if(((A+1==B) && (B+1==C) && (C+1==D) && (D+1==E)) && (diamond==5))
		X1=1;
		if(((A==1) && (B==10) && (C==11) && (D==12) && (E==13)) && (diamond==5))
		X1=1;
		if(((A+1==B) && (B+1==C) && (C+1==D) && (D+1==E)) && (club==5))
		X1=1;
		if(((A==1) && (B==10) && (C==11) && (D==12) && (E==13)) && (club==5))
		X1=1;
		
		//Four of a kind (X2)
		if(A==B && B==C && C==D && D!=E)
		X2=1;
		if(A!=B && B==C && C==D && D==E)
		X2=1;
		
		//Full house (X3)
		if(A==B && B==C && C!=D && D==E)
		X3=1;
		if(A==B && B!=C && C==D && D==E)
		X3=1;
		
		//Flush (X4)
		if((A!=B && B!=C && C!=D && D!=E && E!=A) && (spade!=5))
		X4=1;
		if((A!=B && B!=C && C!=D && D!=E && E!=A) && (heart!=5))
		X4=1;
		if((A!=B && B!=C && C!=D && D!=E && E!=A) && (diamond!=5))
		X4=1;
		if((A!=B && B!=C && C!=D && D!=E && E!=A) && (club!=5))
		X4=1;
		
		//Straight (X5)
		if(((A+1==B) && (B+1==C) && (C+1==D) && (D+1==E)) && (spade!=5))
		X5=1;
		if(((A==1) && (B==10) && (C==11) && (D==12) && (E==13)) && (spade!=5))
		X5=1;
		if(((A+1==B) && (B+1==C) && (C+1==D) && (D+1==E)) && (heart!=5))
		X5=1;
		if(((A==1) && (B==10) && (C==11) && (D==12) && (E==13)) && (heart!=5))
		X5=1;
		if(((A+1==B) && (B+1==C) && (C+1==D) && (D+1==E)) && (diamond!=5))
		X5=1;
		if(((A==1) && (B==10) && (C==11) && (D==12) && (E==13)) && (diamond!=5))
		X5=1;
		if(((A+1==B) && (B+1==C) && (C+1==D) && (D+1==E)) && (club!=5))
		X5=1;
		if(((A==1) && (B==10) && (C==11) && (D==12) && (E==13)) && (club!=5))
		
		//Three of a kind (X6)
		if(A==B && B==C && C!=D && D!=E && C!=E)
		X6=1;
		if(A!=B && B==C && C==D && D!=E && A!=E)
		X6=1;
		if(A!=B && B!=C && C==D && D==E && A!=E)
		X6=1;
		
		//Two pair (X7)
		if(A==B && B!=C && C==D && D!=E && A!=E)
		X7=1;
		if(A==B && B!=C && C!=D && D==E && A!=E)
		X7=1;
		if(A!=B && B==C && C!=D && D==E && A!=E)
		X7=1;
		
		//One pair (X8)
		if(A==B && B!=C && C!=D && D!=E && A!=E)
		X8=1;
		if(A!=B && B==C && C!=D && D!=E && A!=E)
		X8=1;
		if(A!=B && B!=C && C==D && D!=E && A!=E)
		X8=1;
		if(A!=B && B!=C && C!=D && D==E && A!=E)
		X8=1;
		
		//High card (X9)
		if(X1==0 && X2==0 && X3==0 && X4==0 && X5==0 && X6==0 && X7==0 && X8==0)
		X9=1;
		
		//判斷種類
		if(X1==1)
		{printf("Straight flush\n");}
		if(X2==1)
		{printf("Four of a kind\n");}
		if(X3==1)
		{printf("Full house\n");}
		if(X4==1)
		{printf("Flush\n");}
		if(X5==1)
		{printf("Straight\n");}
		if(X6==1)
		{printf("Three of a kind\n");}
		if(X7==1)
		{printf("Two pair\n");}
		if(X8==1)
		{printf("One pair\n");}
		if(X9==1)
		{printf("High card\n");}
	
	}
	
	
	return 0;
	
}
