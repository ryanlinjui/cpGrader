#include<stdio.h>
#include<stdint.h>

int main()
{
	uint16_t num_10=0;
	uint16_t num_8=0;
	uint16_t newnum_8=0;
	uint16_t newnum_10=0;
	uint16_t a=0;
	uint16_t b=0;
	uint16_t c=0;
	uint16_t d=0;
	uint16_t e=0;
	uint16_t f=0;
	uint16_t x=0;
	uint16_t y=0;
	
	printf("Please enter an unsigned 16-bits number:\n");
	scanf("\n%hu", &num_10);
	
	x=num_10;
	
	f=x%8;
	x=x-x%8;
	x=x/8;
	e=x%8;
	x=x-x%8;
	x=x/8;
	d=x%8;
	x=x-x%8;
	x=x/8;
	c=x%8;
	x=x-x%8;
	x=x/8;
	b=x%8;
	x=x-x%8;
	x=x/8;
	a=x%8;
	x=x-x%8;
	x=x/8;
	
	num_8=a*100000+b*10000+c*1000+d*100+e*10+f;
	y=num_8;
	
	if(a>0)
	{
	newnum_8=f*100000+e*10000+d*1000+c*100+b*10+a;
	newnum_10=a*1+b*8+c*64+d*512+e*4096+f*32768;
	}
	else 
	{
		if(a==0 && b>0)
		{
		newnum_8=f*10000+e*1000+d*100+c*10+b;
		newnum_10=b*1+c*8+d*64+e*512+f*4096;
		}
		else
		{
			if (b==0 && c>0)
			{
			newnum_8=f*1000+e*100+d*10+c;
			newnum_10=c*1+d*8+e*64+f*512;
			}
			else
			{
				if(c==0 && d>0)
				{
				newnum_8=f*100+e*10+d;
				newnum_10=d*1+e*8+f*64;
				}
				else
				{
					if(d==0 && e>0)
					{
					newnum_8=f*10+e;
					newnum_10=e*1+f*8;
					}
					else
					{
						if(e==0)
						{
						newnum_8=f;
						newnum_10=f*1;
						}
					}
				}
			}
		}
	}
	
	
	
	printf("Before Flip:\n%hu_10 = %hu_8\nAfter Flip:\n%hu_8 = %hu_10\n",num_10, y, newnum_8, newnum_10);
	
	return 0;
	
}

