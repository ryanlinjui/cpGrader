#include <stdio.h>
#include <stdint.h>

#define RED_BOLD "\x1b[;31;1m"
#define BLU_BOLD "\x1b[;34;1m"
#define GRN_BOLD "\x1b[;32;1m"

int main()
{
printf (RED_BOLD"[KIM]\nYou are sunlight and I moon\nJoined by the gods of fortune\nMidnight and high noon sharing the sky\nWe have been blessed , you and I \n \n");
printf (BLU_BOLD"[CHRIS]\nYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\n \n");
printf (RED_BOLD"[KIM]\nOutside day starts to dawn\n \n");
printf (BLU_BOLD"[CHRIS]\nYour moon still floats on high\n \n");
printf (RED_BOLD"[KIM]\nThe birds awake\n \n");
printf (BLU_BOLD"[CHRIS]\nThe stars shine too\n \n");
printf (RED_BOLD"[KIM]\nMy hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n\nYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho’s Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n \n");
printf (BLU_BOLD"[CHRIS]\nI reach for you \n\n");
printf (GRN_BOLD"[KIM & CHRIS]\nAnd we meet in the sky\n \n");
printf (RED_BOLD"[KIM]\nYou are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n \n");
printf (GRN_BOLD"[KIM & CHRIS]\nMade of\nSunlight\n \n");

return 0;

}
