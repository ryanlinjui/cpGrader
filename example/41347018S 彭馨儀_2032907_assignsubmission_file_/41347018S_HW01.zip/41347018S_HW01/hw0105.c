#include<stdio.h>
#include<stdint.h>

int main()
{
	uint16_t num=0;
	uint16_t type=0;
	uint16_t x=0;
	uint16_t a=0;
	uint16_t b=0;
	uint16_t c=0;
	uint16_t d=0;
	uint16_t e=0;
	uint16_t f=0;
	uint16_t g=0;
	uint16_t h=0;
	uint16_t i=0;
	uint16_t j=0;
	uint16_t k=0;
	uint16_t l=0;
	uint16_t m=0;
	uint16_t n=0;
	uint16_t o=0;
	uint16_t p=0;
	uint16_t S=0;
	uint16_t EXP=0;
	uint16_t F=0;
	float num1=0;
	int16_t num2=0;
	
	printf("Please input a hex:\n");
	scanf("%hx", &num);
	printf("Please choose a output type:(1:integer, 2:unsigned integer, 3:float)\n");
	scanf("%hd", &type);

	x=num;
			
	p=x%2;
	x=x-x%2;
	x=x/2;
	o=x%2;
	x=x-x%2;
	x=x/2;
	n=x%2;
	x=x-x%2;
	x=x/2;
	m=x%2;
	x=x-x%2;
	x=x/2;
	l=x%2;
	x=x-x%2;
	x=x/2;
	k=x%2;
	x=x-x%2;
	x=x/2;
	j=x%2;
	x=x-x%2;
	x=x/2;
	i=x%2;
	x=x-x%2;
	x=x/2;
	h=x%2;
	x=x-x%2;
	x=x/2;
	g=x%2;
	x=x-x%2;
	x=x/2;
	f=x%2;
	x=x-x%2;
	x=x/2;
	e=x%2;
	x=x-x%2;
	x=x/2;
	d=x%2;
	x=x-x%2;
	x=x/2;
	c=x%2;
	x=x-x%2;
	x=x/2;
	b=x%2;
	x=x-x%2;
	x=x/2;
	a=x%2;
	x=x-x%2;
	x=x/2;	
	
	//integer
	if(type==1)
	{		
		printf("Binary of %hx is: %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu\n", num, a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p );
		printf("Converted integer is: %hd\n" ,num);
	}
	
	//unsigned integer
	if(type==2)
	{
		printf("Binary of %hx is: %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu\n",num, a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p );
		printf("Converted unsigned integer is: %hu\n" ,num);
	}
	
	//float
	if(type==3)
	{
		S=num/32768;
		EXP=(num/1024)%32;
		F=num%1024;
		
		num1=num1+(F%2)*1.0/(1024);
		F=F/2;
		num1=num1+(F%2)*1.0/(512);
		F=F/2;
		num1=num1+(F%2)*1.0/(256);
		F=F/2;
		num1=num1+(F%2)*1.0/(128);
		F=F/2;
		num1=num1+(F%2)*1.0/(64);
		F=F/2;
		num1=num1+(F%2)*1.0/(32);
		F=F/2;
		num1=num1+(F%2)*1.0/(16);
		F=F/2;
		num1=num1+(F%2)*1.0/(8);
		F=F/2;
		num1=num1+(F%2)*1.0/(4);
		F=F/2;
		num1=num1+(F%2)*1.0/(2);
		
		num1=num1+1;
		if(S==1)
		{num1=num1*(-1);}
		
		num2=EXP-15;
		
		
		printf("Binary of %hx is: %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu\n",num, a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p );
		printf("Converted float is: %f*2^%hd\n" ,num1, num2);
	}
	


	return 0;
	
}
