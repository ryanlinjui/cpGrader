#include <stdio.h>
#include <stdint.h>

int main(){

    int decimal = 0;

    printf("Please enter an unsigned 16-bits number: ");
    scanf("%d", &decimal);

    if(decimal < 0){
        printf("Please enter a positive integer.\n");
        return 0;
    }

    if(decimal==0){
        printf("Before Flip:\n");
        printf("0_10 = 0_8\n");
        printf("After Flip:\n");
        printf("0_8 = 0_10\n");
        return 0;
    }

    int temp_decimal = 0;
    temp_decimal = decimal;
    int length = 0;
    int octal_digit1 = 0 ,octal_digit2 = 0 ,octal_digit3 = 0 ,octal_digit4 = 0 ,octal_digit5 = 0;
    
    if(temp_decimal!= 0){
        octal_digit1 = temp_decimal % 8;
        temp_decimal = temp_decimal/8;
        length++;

        if(temp_decimal!= 0){
            octal_digit2 = temp_decimal % 8;
            temp_decimal = temp_decimal/8;
            length++;
            
            if(temp_decimal!= 0){
                octal_digit3 = temp_decimal % 8;
                temp_decimal = temp_decimal/8;
                length++;
            
                if(temp_decimal!= 0){
                    octal_digit4 = temp_decimal % 8;
                    temp_decimal = temp_decimal/8;
                    length++;

                    if(temp_decimal!= 0){
                        octal_digit5 = temp_decimal % 8;
                        temp_decimal = temp_decimal/8;
                        length++;
            
                    }
                }
            }
        }
    }
    printf("Before Flip:\n");
    printf("%d_10 = ", decimal);

    if(length == 1){
        printf("%d", octal_digit1);
                
        }else{
            if(length == 2){
                printf("%d%d", octal_digit2, octal_digit1);

            }else{
                if(length == 3){
                    printf("%d%d%d", octal_digit3, octal_digit2, octal_digit1);

                }else{
                    if(length == 4){
                        printf("%d%d%d%d",octal_digit4, octal_digit3, octal_digit2, octal_digit1);

                    }else{
                        if(length == 5){
                            printf("%d%d%d%d%d",octal_digit5,octal_digit4,octal_digit3, octal_digit2, octal_digit1);

                        }
                    }
                }
            }
        }
    

    printf("_8\n");

    int reversed_octal = 0;
    
    if(length == 1){
        reversed_octal = octal_digit1 ;
        
    }
    if(length == 2){
        reversed_octal = octal_digit2 + octal_digit1 *8;
        
    }
    if(length == 3){
        reversed_octal = octal_digit3 + octal_digit2 *8 + octal_digit1 *8*8;
        
    }
    if(length == 4){
        reversed_octal = octal_digit4 + octal_digit3 *8 + octal_digit2 *8*8 + octal_digit1 *8*8*8;
        
    }
    if(length == 5){
        reversed_octal = octal_digit5 + octal_digit4 *8 + octal_digit3 *8*8 + octal_digit2 *8*8*8 + octal_digit1 *8*8*8*8;
        
    }

    printf("After Flip:\n");

    int started = 0;
    if(length == 1){
        printf("%d_8 = %d_10\n", octal_digit1, reversed_octal);
    }
    if(length == 2){
        if(octal_digit1!=0){
            printf("%d", octal_digit1);
            started = 1;
        }else{
            printf("%d_8 = %d_10\n", octal_digit2, reversed_octal);
            return 0;
        }
        if(started != 0 || octal_digit2 != 0){
            printf("%d_8 = %d_10\n", octal_digit2, reversed_octal);
        }
    }
    if(length == 3){
        if(octal_digit1!=0 && octal_digit2 != 0){
            printf("%d%d%d_8 = %d_10\n", octal_digit1, octal_digit2, octal_digit3, reversed_octal);
        }
        if(octal_digit1 == 0){
            if(octal_digit2 == 0){
                printf("%d_8 = %d_10\n", octal_digit3, reversed_octal);
            }else{
                printf("%d%d_8 = %d_10\n", octal_digit2, octal_digit3 ,reversed_octal);
            }
        }
    }
    if(length == 4){
        if(octal_digit1!=0 && octal_digit2 != 0 && octal_digit3 != 0){
            printf("%d%d%d%d_8 = %d_10\n", octal_digit1, octal_digit2, octal_digit3, octal_digit4, reversed_octal);
        }
        if(octal_digit1 == 0){
            if(octal_digit2 == 0){
                if(octal_digit3 == 0){
                    printf("%d_8 = %d_10\n", octal_digit4, reversed_octal);
                }else{
                    printf("%d%d_8 = %d\n", octal_digit3, octal_digit4, reversed_octal);
                }
            }else{
                printf("%d%d%d_8 = %d_10\n", octal_digit2, octal_digit3 ,octal_digit4 ,reversed_octal);
            }
        }
    }
    if(length == 5){
        if(octal_digit1!=0 && octal_digit2 != 0 && octal_digit3 != 0 && octal_digit4 != 0){
            printf("%d%d%d%d%d_8 = %d_10\n", octal_digit1, octal_digit2, octal_digit3, octal_digit4, octal_digit5, reversed_octal);
        }
        if(octal_digit1 == 0){
            if(octal_digit2 == 0){
                if(octal_digit3 == 0){
                    if(octal_digit4 == 0){
                        printf("%d_8 = %d_10\n", octal_digit5, reversed_octal);
                    }else{
                        printf("%d%d_8 = %d_10\n", octal_digit4, octal_digit5, reversed_octal);
                    }
                }else{
                    printf("%d%d%d_8 = %d\n",octal_digit3 , octal_digit4, octal_digit5, reversed_octal);
                }
            }else{
                printf("%d%d%d%d_8 = %d_10\n", octal_digit2, octal_digit3 ,octal_digit4 ,octal_digit5 ,reversed_octal);
            }
        }
    }
 
    return 0;
}