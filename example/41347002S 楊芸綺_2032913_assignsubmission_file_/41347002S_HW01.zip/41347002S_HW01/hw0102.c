#include <stdio.h>
#include <stdint.h>

int main(){
char first_operand[5],second_operand[5];
int32_t x=0;
int32_t y=0;
int32_t z=0;
int32_t sum=0;

printf("Please enter the first  operand: ");
scanf("%s", first_operand);
printf("Please enter the second operand: ");
scanf("%s", second_operand);
printf("Please enter the sum           : ");
scanf("%d",&sum);

int32_t a = first_operand[0] - '0';
int32_t c = first_operand[2] - '0'; 
int32_t b = second_operand[1] - '0';

sum = (sum - a * 100 - b * 10 - c) ; 
y = sum/100; 
x = (sum%100)/10;
z = sum%10;

if (first_operand[1]!= 'x' || second_operand[0] != 'y' || second_operand[2] != 'z'){
    printf("Error: Invalid input.\n"); 
    return 0; 
}

if(sum>100*a+10*b+c){
    printf("Error: Invalid input.\n"); 
    return 0; 
}

if(a < 0 || a > 9 || b < 0 || b > 9 || c > 9 || c < 0){
    printf("Error: Invalid input.\n"); 
    return 0;
}

if(x < 0 || x > 9 || y < 0 || y > 9 || z > 9 || z < 0){
    printf("Error: Invalid input.\n"); 
    return 0;
}

printf("Ans: x = %d, y = %d, z = %d \n", x, y, z);

return 0;

}