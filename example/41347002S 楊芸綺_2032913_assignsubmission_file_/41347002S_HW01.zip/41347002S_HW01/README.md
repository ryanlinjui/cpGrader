# hw01 README       學號：41347002s 姓名：楊芸綺

如何編譯程式：
---

直接執行make來編譯，裡面包含hw0101, hw0102, hw0103, hw0104, hw0105

hw0101
---
直接執行就會出現完整歌詞。


hw0102:
--- 
執行後第一行會出現Please enter the first operand: ，請輸入「數字x數字」，接著第二行會顯示Please enter the second operand: ，請輸入「y數字z」，第三行會顯示Please enter sum: ，請輸入一個數值，若x,y,z改為大寫、x前的數字不為1～9、x後或y後的數字不為0～9、或x,y,z當中至少有一個得出的值小於0，則第四行會顯示Error: Invalid input.，其餘有成功算出x,y,z值時會將算出值顯示出來。

hw0103:
--- 
執行後第一行會顯示Please enter an unsigned 16-bits number: ，請輸入一個無符號的 16 位元整數，接著程式會將此數轉換為八進制表示，然後將這個八進制數字反轉，並將反轉後的八進制數字轉換回十進制並顯示出來，若輸入的數小於0，則會顯示Please enter a positive integer.

hw0104:
--- 
執行後第一行會顯示Please enter 5 cards.，請分別輸入5張牌號，1-13號為同一花色A-K，14-26為另一花色的A-K，以此類推，完成五張牌的輸入後，會顯示相對應的牌型，若輸入相同的牌或牌號不在1～52之間則會顯示Error.

hw0105:
--- 
執行後第一行會顯示Please input a hex，請輸入16進位的數字，接著第二行會顯示Please choose the output type (1: integer, 2: unsigned integer, 3: float): ，根據需要輸出的形式用1、2、3來選擇，選擇後第三行會以二進位表示此數，第四行則會根據選擇的形式輸出，若數值為正負無限，則float會輸出0，若數值不存在，則float會輸出NAN。

