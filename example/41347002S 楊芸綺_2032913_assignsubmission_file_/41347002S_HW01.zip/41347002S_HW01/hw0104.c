#include <stdio.h>
#include <stdint.h>

int main(){
    
    int card1, card2, card3, card4, card5;

    printf("Please enter 5 cards:");
    scanf("%d %d %d %d %d", &card1, &card2, &card3, &card4,&card5);

    if(card1 > 52 || card1 <1 || card2 > 52 || card2 <1 || card3 > 52 || card3 <1 || card4 > 52 || card4 <1 || card5 > 52 || card5 <1){
        printf("Error.\n");
        return 0;
    }
    if(card1 == card2 || card1 == card3 || card1 == card4 || card1 == card5 || card2 == card3 || card2 == card4 || card2 == card5 || card3 == card4 || card3 == card5 ||card4 == card5 ){
        printf("Error.\n");
        return 0;
    }

    int rank1, rank2, rank3, rank4, rank5; //fiower
    int suit1, suit2, suit3, suit4, suit5; //number
    
    rank1 = (card1 - 1) % 13 + 1 ;
    rank2 = (card2 - 1) % 13 + 1 ;
    rank3 = (card3 - 1) % 13 + 1 ;
    rank4 = (card4 - 1) % 13 + 1 ;
    rank5 = (card5 - 1) % 13 + 1 ;

    suit1 = (card1 - 1) / 13 ;
    suit2 = (card2 - 1) / 13 ;
    suit3 = (card3 - 1) / 13 ;
    suit4 = (card4 - 1) / 13 ;
    suit5 = (card5 - 1) / 13 ;

    int temp;

    if(rank1 > rank2){
        temp = rank1;
        rank1 = rank2;
        rank2 = temp;
    }
    if(rank1 > rank3){
        temp = rank1;
        rank1 = rank3;
        rank3 = temp;
    }
    if(rank1 > rank4){
        temp = rank1;
        rank1 = rank4;
        rank4 = temp;
    }
    if(rank1 > rank5){
        temp = rank1;
        rank1 = rank5;
        rank5 = temp;
    }
    if(rank2 > rank3){
        temp = rank2;
        rank2 = rank3;
        rank3 = temp;
    }
    if(rank2 > rank4){
        temp = rank2;
        rank2 = rank4;
        rank4 = temp;
    }
    if(rank2 > rank5){
        temp = rank2;
        rank2 = rank5;
        rank5 = temp;
    }
    if(rank3 > rank4){
        temp = rank3;
        rank3 = rank4;
        rank4 = temp;
    }
    if(rank3 > rank5){
        temp = rank3;
        rank3 = rank5;
        rank5 = temp;
    }
    if(rank4 > rank5){
        temp = rank4;
        rank4 = rank5;
        rank5 = temp;
    }

    int count1 = 1, count2 = 1, count3 = 1, count4 = 1;

    if(rank1 == rank2){
        count1 = count1 + 1;
    }
    if(rank1 == rank3){
        count1 = count1 + 1;
    }
    if(rank1 == rank4){
        count1 = count1 + 1;
    }
    if(rank1 == rank5){
        count1 = count1 + 1;
    }

    if(rank2 == rank3){
        count2 = count2 + 1;
    }
    if(rank2 == rank4){
        count2 = count2 + 1;
    }
    if(rank2 == rank5){
        count2 = count2 + 1;
    }

    if(rank3 == rank4){
        count3 = count3 + 1;
    }
    if(rank3 == rank5){
        count3 = count3 + 1;
    }

    if(rank4 == rank5){
        count4 = count4 + 1;
    }

    int maxcount = 0;
    if(count1 > maxcount){
        maxcount = count1;
    }
    if(count2 > maxcount){
        maxcount = count2;
    }
    if(count3 > maxcount){
        maxcount = count3;
    }
    if(count4 > maxcount){
        maxcount = count4;
    }

    if(suit1 == suit2 && suit2 == suit3 && suit3 == suit4 && suit4 == suit5){
        if((rank1 + 1 == rank2 && rank2 + 1 == rank3 && rank3 +1 == rank4 && rank4 + 1 == rank5)||(rank1 == 10 && rank2 == 11 && rank3 == 12 && rank4 == 13 && rank5 ==1)){
            printf("Straight Flush\n");
            return 0;
        }else{
            printf("Flush\n");
            return 0;
        }
    }else{
        if((rank1 + 1 == rank2 && rank2 + 1 == rank3 && rank3 +1 == rank4 && rank4 + 1 == rank5)||(rank1 == 10 && rank2 == 11 && rank3 == 12 && rank4 == 13 && rank5 ==1)){
            printf("Straight\n");
            return 0;
        }else{
            if((maxcount == 3)&&(count1 == 2 || count2 == 2 || count3 == 2 || count4 == 2 )){
                printf("Full house\n");
                return 0;
            }else{
                if(maxcount == 3){
                    printf("Three of a kind\n");
                    return 0;
                }else{
                    if(maxcount == 4){
                        printf("Four of a kind\n");
                        return 0;
                    }else{
                        if((count1 == 2 && count2 == 2)||(count1 == 2 && count3 == 2)||(count1 == 2 && count4 == 2)||(count2 == 2 && count3 == 2)||(count2 == 2 && count4 == 2)||(count3 == 2 && count4 == 2)){
                            printf("Two pair\n");
                            return 0;
                        }else{
                            if(maxcount == 2){
                                printf("One pair\n");
                                return 0;
                            }else{
                                printf("High card\n");
                                return 0;
                            }
                        }
                    }
                }
            }
        }
    }
    
    return 0;
}