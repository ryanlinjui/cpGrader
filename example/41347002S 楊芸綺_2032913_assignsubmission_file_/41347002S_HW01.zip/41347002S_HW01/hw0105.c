#include <stdio.h>
#include <stdint.h>

int main(){
    unsigned int hexvalue;
    int a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15;
    int sign = 0, exponent = 0;
    float final_fraction = 1.0;

    printf("Please input a hex (4 digits): ");
    scanf("%x", &hexvalue);

    int option;
    printf("Please choose the output type(1:integer,2:unsigned integer,3:float):");
    scanf("%d", &option);
    printf("Binary of %X is: ", hexvalue);

    if(hexvalue & 0x8000){
        printf("1");
        a0 = 1;
    }else{
        printf("0");
        a0 = 0;
    }
    if(hexvalue & 0x4000){
        printf("1");
        a1 = 1;
    }else{
        printf("0");
        a1 = 0;
    }
    if(hexvalue & 0x2000){
        printf("1");
        a2 = 1;
    }else{
        printf("0");
        a2 = 0;
    }
    if(hexvalue & 0x1000){
        printf("1");
        a3 = 1;
    }else{
        printf("0");
        a3 = 0;
    }
    printf(" ");
    if(hexvalue & 0x0800){
        printf("1");
        a4 = 1;
    }else{
        printf("0");
        a4 = 0;
    }
    if(hexvalue & 0x0400){
        printf("1");
        a5 = 1;
    }else{
        printf("0");
        a5 = 0;
    }
    if(hexvalue & 0x0200){
        printf("1");
        a6 = 1;
    }else{
        printf("0");
        a6 = 0;
    }
    if(hexvalue & 0x0100){
        printf("1");
        a7 = 1;
    }else{
        printf("0");
        a7 = 0;
    }
    printf(" ");
    if(hexvalue & 0x0080){
        printf("1");
        a8 = 1;
    }else{
        printf("0");
        a8 = 0;
    }
    if(hexvalue & 0x0040){
        printf("1");
        a9 = 1;   
    }else{
        printf("0");
        a9 = 0;
    }
    if(hexvalue & 0x0020){
        printf("1");
        a10 = 1;
    }else{
        printf("0");
        a10 = 0;
    }
    if(hexvalue & 0x0010){
        printf("1");
        a11 = 1;
    }else{
        printf("0");
        a11 = 0;
    }
    printf(" ");
    if(hexvalue & 0x0008){
        printf("1");
        a12 = 1;
    }else{
        printf("0");
        a12 = 0;
    }
    if(hexvalue & 0x0004){
        printf("1");
        a13 = 1;
    }else{
        printf("0");
        a13 = 0;
    }
    if(hexvalue & 0x0002){
        printf("1");
        a14 = 1;
    }else{
        printf("0");
        a14 = 0;
    }
    if(hexvalue & 0x0001){
        printf("1");
        a15 = 1;
    }else{
        printf("0");
        a15 = 0;
    }
    printf("\n");
    
    int signedint;
    unsigned int unsignedint;

    if(option == 1){
        if(hexvalue & 0x8000){
            signedint = (int)(hexvalue - 0x10000);
        }else{
            signedint = (int)hexvalue;
        }
        printf("Converted integer is: %d\n", signedint);
    }else{
        if(option == 2){
            unsignedint = hexvalue;
            printf("Converted unsigned integer is: %u\n", unsignedint);
        }else{
            if(option == 3){
                if(hexvalue == 0){
                    printf("Converted float is:0\n");
                    return 0;
                }
                if(a1 == 1 && a2 == 1 && a3 == 1 && a4 == 1 && a5 == 1 && a6 == 0 && a7 == 0 && a8 == 0 && a9 == 0 && a10 == 0 && a11 == 0 && a12 == 0 && a13 == 0 && a14 == 0 && a15 == 0 ){
                    printf("Converted float is:0\n");
                    return 0;
                }
                if((a1 == 1 && a2 == 1 && a3 == 1 && a4 == 1 && a5 == 1 )&&(a6 != 0 || a7 != 0 || a8 != 0 || a9 != 0 || a10 != 0 || a11 != 0 || a12 != 0 || a13 != 0 || a14 != 0 || a15 != 0 )){
                    printf("Converted float is:NAN\n");
                    return 0;
                }
                if(a0 == 0){
                    sign = 1;
                }else{
                    sign =-1;
                }
                if(a1 ==1){
                    exponent += 16;
                }
                if(a2 ==1){
                    exponent += 8;
                }
                if(a3 ==1){
                    exponent += 4;
                }
                if(a4 ==1){
                    exponent += 2;
                }
                if(a5 ==1){
                    exponent += 1;
                }
                exponent -= 15;
                if(a6 == 1){
                    final_fraction += 1.0/2;
                }
                if(a7== 1){
                    final_fraction += 1.0/4;
                }
                if(a8 == 1){
                    final_fraction += 1.0/8;
                }
                if(a9 == 1){
                    final_fraction += 1.0/16;
                }
                if(a10 == 1){
                    final_fraction += 1.0/32;
                }
                if(a11 == 1){
                    final_fraction += 1.0/64;
                }
                if(a12 == 1){
                    final_fraction += 1.0/128;
                }
                if(a13 == 1){
                    final_fraction += 1.0/256;
                }
                if(a14 == 1){
                    final_fraction += 1.0/512;
                }
                if(a15 == 1){
                    final_fraction += 1.0/1024;
                }
                printf("Converted float is:%f*2^%d\n", sign * final_fraction, exponent);
            }else{
                printf("Error.\n");
            }
        }
    }
    return 0;
}