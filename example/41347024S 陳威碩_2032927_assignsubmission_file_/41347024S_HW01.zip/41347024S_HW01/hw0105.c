#include <stdio.h>
#include <stdint.h>

int main()
{
  int32_t hex = 0 , type = 0;
  int32_t hex1 = 0 , hex2 = 0 , hex3 = 0 , hex4 = 0;
  int32_t exp = 0 , f = 0;
  float ff = 0;
  
  printf("Please input a hex:");
  scanf("%X",&hex);
  
  if( hex > 0xFFFF || hex < 0x0 )
  {
    printf("wrong input");
    return 0;
  }
  
  printf("Please choose the output type(1:integer,2:unsigned integer,3:float):");
  scanf("%d",&type);
  
  hex1 = hex/16/16/16;
  hex2 = (hex/16/16)-(hex1*0b10000);
  hex3 = (hex/16)-(hex/16/16*0b10000);
  hex4 = hex-(hex/16*0b10000);
  
  printf("Binary of %X is: %04B %04B %04B %04B\n",hex,hex1,hex2,hex3,hex4);
  
  if( type == 1 )
  {
    if( hex < 0b1000000000000000 )
    {
      printf("Converted integer is: %d",hex);
    }
    else if( hex >= 0b1000000000000000 )
    {
      hex = 0b1111111111111111-(hex-0b1);
      printf("Converted integer is: -%d",hex);
    }
  }
  else if( type == 2 )
  {
    printf("Converted unsigned integer is: %d",hex);
  }
  else if( type == 3 )
  {
    if( hex < 0b1000000000000000 )
    {
      exp = hex/0b10000000000;
      f = hex-(exp*0b10000000000);
      exp -= 15;
      ff = f;
      ff /= 1024;
      ff += 1;
      printf("Converted float is: %f*2^%d",ff,exp);
    }
    else if( hex >= 0b1000000000000000 )
    {
      hex = (hex-0b1000000000000000);
      exp = hex/0b10000000000;
      f = hex-(exp*0b10000000000);
      exp -= 15;
      ff = f;
      ff /= 1024;
      ff += 1;
      printf("Converted float is: -%f*2^%d",ff,exp);
    }
  }
  return 0;
}
