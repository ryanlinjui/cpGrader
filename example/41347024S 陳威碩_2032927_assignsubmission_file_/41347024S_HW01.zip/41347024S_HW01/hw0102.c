#include <stdio.h>
#include <stdint.h>

int main()
{
  int32_t x = 0;
  int32_t y = 0;
  int32_t z = 0;
  int32_t num1 = 0 , num2 = 0 , num3 = 0;
  int32_t n1_1 = 0 , n1_2 = 0 , n2_1 = 0;
  int32_t sum = 0;
  
  printf("Please enter the first operand:");
  scanf("%dx%d", &n1_1 , &n1_2 );
  if ( n1_1 >= 10 )
  {
    printf("error,first operand must < 1000");
    return 0;
  }
  printf("Please enter the second operand:");
  scanf("\ny%dz", &n2_1 );
  printf("Please enter the sum:");
  scanf("\n%d", &sum );
  
  num1 = sum / 100;
  num2 = ( sum - ( num1 * 100 ) ) / 10;
  num3 = sum - ( num1 * 100 ) - ( num2 * 10 );
  
  if ( ( num3 - n1_2 ) >= 0 )
  {
    z = ( num3 - n1_2 );
  }
  else 
  {
    z = ( 10 + ( num3 - n1_2 ) );
    num2 -= 1;
  }
  if ( ( num2 - n2_1 ) >= 0 )
  {
    x = ( num2 - n2_1 );
  }
  else
  {
    x = ( 10 + ( num2 - n2_1 ) );
    num1 -= 1;
  }
  y = ( num1 - n1_1 );
  
  printf("Ans: x = %d, y = %d, z = %d",x,y,z);
  
  //printf("\n%d %d %d %d",n1_1,n1_2,n2_1,sum);
  //printf("\n%d %d %d",num1,num2,num3);
  //printf("\n%d %d %d",x,y,z);
  
  return 0;
}
