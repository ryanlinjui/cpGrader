#include <stdio.h>
#include <stdint.h>

int main()
{
  int32_t card1 = 0 , card2 = 0 , card3 = 0 , card4 = 0 , card5 = 0;
  int32_t rank1 = 0 , rank2 = 0 , rank3 = 0 , rank4 = 0 , rank5 = 0;
  int32_t suit1 = 0 , suit2 = 0 , suit3 = 0 , suit4 = 0 , suit5 = 0;
  int32_t str1 = 0 , str2 = 0 , str3 = 0 , str4 = 0 , str5 = 0;
  int32_t flush = 0 , pair = 0 , straight = 0;
  
  printf("Please enter 5 cards: ");
  scanf("%d %d %d %d %d",&card1,&card2,&card3,&card4,&card5);
  
  if( card1 < 1 || card1 > 52 || card2 < 1 || card2 > 52 || card3 < 1 || card3 > 52 || card4 < 1 || card4 > 52 || card5 < 1 || card5 > 52 )
  {
    printf("wrong input,cards from 1 to 52");
    return 0;
  }
  
  rank1 = ( ( card1 - 1 ) % 13 ) + 1;
  rank2 = ( ( card2 - 1 ) % 13 ) + 1;
  rank3 = ( ( card3 - 1 ) % 13 ) + 1;
  rank4 = ( ( card4 - 1 ) % 13 ) + 1;
  rank5 = ( ( card5 - 1 ) % 13 ) + 1;
  
  suit1 = ( ( card1 - 1 ) / 13 ) + 1;
  suit2 = ( ( card2 - 1 ) / 13 ) + 1;
  suit3 = ( ( card3 - 1 ) / 13 ) + 1;
  suit4 = ( ( card4 - 1 ) / 13 ) + 1;
  suit5 = ( ( card5 - 1 ) / 13 ) + 1;
  
    if( suit1 == suit2 && suit2 == suit3 && suit3 == suit4 && suit4 == suit5 )
  {
    flush = 1;
  }
  
  str1 = rank1;
  if ( rank2 > str1 )
  {
    str2 = str1;
    str1 = rank2;
  }
  else 
  {
    str2 = rank2;
  }
  if ( rank3 > str1 )
  {
    str3 = str2;
    str2 = str1;
    str1 = rank3;
  }
  else if( rank3 > str2 )
  {
    str3 = str2;
    str2 = rank3;
  }
  else
  {
    str3 = rank3;
  }
  if ( rank4 > str1 )
  {
    str4 = str3;
    str3 = str2;
    str2 = str1;
    str1 = rank4;
  }
  else if( rank4 > str2 )
  {
    str4 = str3;
    str3 = str2;
    str2 = rank4;
  }
  else if( rank4 > str3 )
  {
    str4 = str3;
    str3 = rank4;
  }
  else
  {
    str4 = rank4;
  }
  if ( rank5 > str1 )
  {
    str5 = str4;
    str4 = str3;
    str3 = str2;
    str2 = str1;
    str1 = rank5;
  }
  else if( rank5 > str2 )
  {
    str5 = str4;
    str4 = str3;
    str3 = str2;
    str2 = rank5;
  }
  else if( rank5 > str3 )
  {
    str5 = str4;
    str4 = str3;
    str3 = rank5;
  }
  else if( rank5 > str4 )
  {
    str5 = str4;
    str4 = rank5;
  }
  else
  {
    str5 = rank5;
  }
  
  pair = ( rank1 == rank2 ) + ( rank1 == rank3 ) + ( rank1 == rank4 ) + ( rank1 == rank5 ) + ( rank2 == rank3 ) + ( rank2 == rank4 ) + ( rank2 == rank5 ) + ( rank3 == rank4 ) + ( rank3 == rank5 ) + ( rank4 == rank5 );
  
  //printf("\n%d %d %d %d %d",card1,card2,card3,card4,card5);
  //printf("\n%d %d %d %d %d",rank1,rank2,rank3,rank4,rank5);
  //printf("\n%d %d %d %d %d",suit1,suit2,suit3,suit4,suit5);
  //printf("\n%d %d %d %d %d",str1,str2,str3,str4,str5);
  //printf("%d",pair);
  
  //if( rank1 == rank2 && rank2 == rank3 && rank3 == rank4 || rank1 == rank2 && rank2 == rank3 && rank3 == rank5 || rank1 == rank2 && rank2 == rank4 && rank4 == rank5 || rank1 == rank3 && rank3 == rank4 && rank4 == rank5 || rank2 == rank3 && rank3 == rank4 && rank4 == rank5 )
  
  if( ( ( str1 - 1 ) == str2 && ( str2 - 1 ) == str3 && ( str3 - 1 ) == str4 && ( str4 - 1 ) == str5 ) || str1 == 13 && str2 == 12 && str3 == 11 && str4 == 10 && str5 == 1 )
  {
    straight = 1;
  }
  
  //printf("\nstr=%d",straight);
  
  if( straight == 1 )
  {
    if( flush == 1 )
    {
      printf("Straight flush");
      return 0;
    }
    else
    {
      printf("Straight");
      return 0;
    }
  }
  
  if( pair == 6 )
  {
    printf("Four of a kind");
    return 0;
  }
  else if( pair == 4 )
  {
    printf("Full house");
    return 0;
  }
  else if( pair == 3 )
  {
    printf("Three of a kind");
    return 0;
  }
  else if( pair == 2 )
  {
    printf("Two pair");
    return 0;
  }
  else if( pair == 1 )
  {
    printf("One pair");
    return 0;
  }
  
  if( flush == 1 )
  {
    printf("Flush");
    return 0;
  }
  else
  {
    printf("High card");
    return 0;
  }
 
 //if( ( rank1 == rank2 && rank2 == rank3 ) || ( rank1 == rank2 && rank2 == rank4 ) || ( rank1 == rank2 && rank2 == rank5 ) || ( rank1 == rank3 && rank3 == rank4 ) || ( rank1 == rank3 && rank3 == rank5 ) || ( rank2 == rank3 && rank3 == rank4 ) ||  ( rank2 == rank3 && rank3 == rank5 ) || ( rank2 == rank4 && rank4 == rank5 ) || ( rank3 == rank4 && rank4 == rank5 ) || ( rank1 == rank4 && rank4 == rank5 ) ) printf("three");
 
  return 0;
}
