#include <stdio.h>

int main()
{
	printf("\x1b[0;39m[KIM]\n");
	printf("\x1b[0;31mYou are sunlight and I moon\nJoined by the gods of fortune\nMidnight and high noon sharing the sky\nWe have been blessed , you and I\n\n");
	printf("\x1b[0;39m[CHRIS]\n");
	printf("\x1b[0;34mYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\n\n");
	printf("\x1b[0;39m[KIM]\n");
	printf("\x1b[0;31mOutside day starts to dawn\n\n");

	printf("\x1b[0;39m[CHRIS]\n");
	printf("\x1b[0;34mYour moon still floats on high\n\n");

	printf("\x1b[0;39m[KIM]\n");
	printf("\x1b[0;31mThe birds awake\n\n");

	printf("\x1b[0;39m[CHRIS]\n");
	printf("\x1b[0;34mThe stars shine too\n\n");

	printf("\x1b[0;39m[KIM]\n");
	printf("\x1b[0;31mMy hands still shake\n");

	printf("\x1b[0;39mSee upcoming pop shows\nGet tickets for your favorite artists\n\nYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho’s Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n\n");

	printf("\x1b[0;39m[CHRIS]\n");
	printf("\x1b[0;34mI reach for you\n\n");
	
	printf("\x1b[0;39m[KIM & CHRIS]\n");
	printf("\x1b[0;32mAnd we meet in the sky\n\n");

	printf("\x1b[0;39m[KIM]\n");
	printf("\x1b[0;31mYou are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n\n");

	printf("\x1b[0;39m[KIM & CHRIS]\n");
	printf("\x1b[0;32mMade of\nSunlight\nMoonlight\n");

	return 0;
}
