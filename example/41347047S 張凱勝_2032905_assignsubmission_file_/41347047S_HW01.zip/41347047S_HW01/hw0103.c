#include <stdio.h>
#include <stdint.h>

int32_t main() {
    uint32_t number, reversed_number = 0;
    int32_t octal_digit1, octal_digit2, octal_digit3, octal_digit4, octal_digit5, octal_digit6;

    // 輸入無符號 16 位元數字
    printf("Please enter an unsigned 16-bits number: ");
    scanf("%u", &number);

    // 輸出原始數字的十進位和八進位形式
    printf("Before Flip:\n");
    printf("%u_10 = %o_8\n", number, number);

    // 將數字轉換為八進位並手動提取每一位
    uint32_t temp_number = number; // 使用臨時變數保存原始數字
    octal_digit1 = temp_number % 8;       // 最低位
    temp_number /= 8;
    octal_digit2 = temp_number % 8;       // 第二位
    temp_number /= 8;
    octal_digit3 = temp_number % 8;       // 第三位
    temp_number /= 8;
    octal_digit4 = temp_number % 8;       // 第四位
    temp_number /= 8;
    octal_digit5 = temp_number % 8;       // 第五位
    temp_number /= 8;
    octal_digit6 = temp_number % 8;       // 第六位

    // 反轉八進位的位數
    reversed_number = octal_digit1 * 8 * 8 * 8 * 8 * 8 +
                      octal_digit2 * 8 * 8 * 8 * 8 +
                      octal_digit3 * 8 * 8 * 8 +
                      octal_digit4 * 8 * 8 +
                      octal_digit5 * 8 +
                      octal_digit6;

    // 輸出反轉後的八進位和十進位形式
    printf("After Flip:\n");
    printf("%o_8 = %u_10\n", reversed_number, reversed_number);

    return 0;
}
