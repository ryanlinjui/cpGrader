#include <stdio.h>
#include <stdint.h>

int32_t main() {
    int32_t c1, c2, c3, c4, c5;

    // 讀取五張牌
    printf("Please enter the numbers of five cards: ");
    int32_t result = scanf("%d %d %d %d %d", &c1, &c2, &c3, &c4, &c5);

    // 檢查是否成功讀取了五個整數
    if (result != 5) {
        printf("Invalid input. Program will exit.\n");
        return 0;
    }
    
    // 檢查每張牌是否在有效範圍內
    if (c1 < 1 || c1 > 52 || c2 < 1 || c2 > 52 || c3 < 1 || c3 > 52 || c4 < 1 || c4 > 52 || c5 < 1 || c5 > 52) {
    printf("Card numbers must be between 1 and 52. Program will exit.\n");
    return 0;
    }

    // 以下是您的原始程式碼
    // 計算每張牌的點數和花色
    int32_t rank1 = (c1 - 1) % 13 + 1;
    int32_t rank2 = (c2 - 1) % 13 + 1;
    int32_t rank3 = (c3 - 1) % 13 + 1;
    int32_t rank4 = (c4 - 1) % 13 + 1;
    int32_t rank5 = (c5 - 1) % 13 + 1;

    int32_t suit1 = (c1 - 1) / 13;
    int32_t suit2 = (c2 - 1) / 13;
    int32_t suit3 = (c3 - 1) / 13;
    int32_t suit4 = (c4 - 1) / 13;
    int32_t suit5 = (c5 - 1) / 13;

    // 計算最小和最大點數
    int32_t minRank = rank1;
    if (rank2 < minRank) minRank = rank2;
    if (rank3 < minRank) minRank = rank3;
    if (rank4 < minRank) minRank = rank4;
    if (rank5 < minRank) minRank = rank5;

    int32_t maxRank = rank1;
    if (rank2 > maxRank) maxRank = rank2;
    if (rank3 > maxRank) maxRank = rank3;
    if (rank4 > maxRank) maxRank = rank4;
    if (rank5 > maxRank) maxRank = rank5;

    // 判斷是否同花順
    if (suit1 == suit2 && suit2 == suit3 && suit3 == suit4 && suit4 == suit5) {
        // 花色相同
        if (maxRank - minRank == 4) {
            // 檢查點數是否連續且不重複
            printf("Straight Flush\n");
            return 0;}
        // 不是同花順，但仍是同花
        printf("Flush\n");
        return 0;
    }

    // 計算每個點數的出現次數
    int32_t count1 = 1;
    if (rank2 == rank1) { count1++; rank2 = -1; }
    if (rank3 == rank1) { count1++; rank3 = -1; }
    if (rank4 == rank1) { count1++; rank4 = -1; }
    if (rank5 == rank1) { count1++; rank5 = -1; }

    int32_t count2 = 0;
    if (rank2 != -1) {
        count2 = 1;
        if (rank3 == rank2) { count2++; rank3 = -1; }
        if (rank4 == rank2) { count2++; rank4 = -1; }
        if (rank5 == rank2) { count2++; rank5 = -1; }
    }

    int32_t count3 = 0;
    if (rank3 != -1) {
        count3 = 1;
        if (rank4 == rank3) { count3++; rank4 = -1; }
        if (rank5 == rank3) { count3++; rank5 = -1; }
    }

    int32_t count4 = 0;
    if (rank4 != -1) {
        count4 = 1;
        if (rank5 == rank4) { count4++; rank5 = -1; }
    }

    int32_t count5 = 0;
    if (rank5 != -1) {
        count5 = 1;
    }

    // 判斷鐵支
    if (count1 == 4 || count2 == 4 || count3 == 4 || count4 == 4 || count5 == 4) {
        printf("Four of a Kind\n");
        return 0;
    }

    // 判斷葫蘆
    int32_t hasThree = 0, hasTwo = 0;
    if (count1 == 3) hasThree = 1;
    if (count2 == 3) hasThree = 1;
    if (count3 == 3) hasThree = 1;
    if (count4 == 3) hasThree = 1;
    if (count5 == 3) hasThree = 1;

    if (count1 == 2) hasTwo = 1;
    if (count2 == 2) hasTwo = 1;
    if (count3 == 2) hasTwo = 1;
    if (count4 == 2) hasTwo = 1;
    if (count5 == 2) hasTwo = 1;

    if (hasThree && hasTwo) {
        printf("Full House\n");
        return 0;
    }

    // 判斷順子
    if (maxRank - minRank == 4) {
        if (rank1 != rank2 && rank1 != rank3 && rank1 != rank4 && rank1 != rank5 &&
            rank2 != rank3 && rank2 != rank4 && rank2 != rank5 &&
            rank3 != rank4 && rank3 != rank5 &&
            rank4 != rank5) {
            printf("Straight\n");
            return 0;
        }
    }

    // 判斷三條
    if (count1 == 3 || count2 == 3 || count3 == 3 || count4 == 3 || count5 == 3) {
        printf("Three of a Kind\n");
        return 0;
    }

    // 判斷兩對
    int32_t pairCount = 0;
    if (count1 == 2) pairCount++;
    if (count2 == 2) pairCount++;
    if (count3 == 2) pairCount++;
    if (count4 == 2) pairCount++;
    if (count5 == 2) pairCount++;

    if (pairCount == 2) {
        printf("Two Pair\n");
        return 0;
    }

    // 判斷一對
    if (pairCount == 1) {
        printf("One Pair\n");
        return 0;
    }

    // 其他情況為高牌
    printf("High Card\n");
    return 0;
}
