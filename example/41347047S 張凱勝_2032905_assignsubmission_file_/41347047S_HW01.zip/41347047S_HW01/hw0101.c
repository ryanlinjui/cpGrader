#include <stdio.h>
#include <stdint.h>

int32_t main() {
    // Kim 歌詞 (紅色)
    printf("\033[0;31m[KIM]\n");
    printf("You are sunlight and I moon\n");
    printf("Joined by the gods of fortune\n");
    printf("Midnight and high noon sharing the sky\n");
    printf("We have been blessed, you and I\n");

    // Reset color 
    printf("\033[0m");

    // Chris 歌詞 (藍色)
    printf("\033[0;34m[CHRIS]\n");
    printf("You are here like a mystery\n");
    printf("I'm from a world that's so different from all that you are\n");
    printf("How in the light of one night did we come so far?\n");

    // Reset color
    printf("\033[0m");

    // Kim 歌詞 (紅色)
    printf("\033[0;31m[KIM]\n");
    printf("Outside day starts to dawn\n");

    // Reset color
    printf("\033[0m");

    // Chris 歌詞 (藍色)
    printf("\033[0;34m[CHRIS]\n");
    printf("Your moon still floats on high\n");

    // Reset color
    printf("\033[0m");

    // Kim 的歌詞 (紅色)
    printf("\033[0;31m[KIM]\n");
    printf("The birds awake\n");

    // Reset color
    printf("\033[0m");

    // Chris 歌詞 (藍色)
    printf("\033[0;34m[CHRIS]\n");
    printf("The stars shine too\n");

    // Rest color
    printf("\033[0m");

    // Kim 歌詞 (紅色)
    printf("\033[0;31m[KIM]\n");
    printf("My hands still shake\n");
    printf("See upcoming pop shows\n");
    printf("Get tickets for your favorite artists\n");

    // Reset color
    printf("\033[0m");

    // Chris 歌詞 (藍色)
    printf("\033[0;34m[CHRIS]\n");
    printf("I reach for you\n");

    // Reset color
    printf("\033[0m");

    // 合唱部分 (綠色)
    printf("\033[0;32m[KIM & CHRIS]\n");
    printf("And we meet in the sky\n");

    // Reset color
    printf("\033[0m");

    // Kim 歌詞 (紅色)
    printf("\033[0;31m[KIM]\n");
    printf("You are sunlight and I moon\n");
    printf("Joined here\n");
    printf("Brightening the sky with the flame of love\n");

    // Reset color
    printf("\033[0m");

    // 合唱部分 (綠色)
    printf("\033[0;32m[KIM & CHRIS]\n");
    printf("Made of\n");
    printf("Sunlight\n");
    printf("Moonlight\n");

    // Reset collor
    printf("\033[0m");

    return 0;
}
