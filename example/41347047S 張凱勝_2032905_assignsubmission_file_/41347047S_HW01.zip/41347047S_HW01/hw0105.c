#include <stdio.h>
#include <stdint.h>

int32_t main() {
    uint32_t hexInput;
    printf("Please input a hex:");
    scanf("%x", &hexInput);

    int32_t choice;
    printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
    scanf("%d", &choice);

    // 打印二進制表示，不使用迴圈
    printf("Binary of %X is:", hexInput);

    // 手動提取並打印每一位，每4位後添加一個空格
    printf("%d", (hexInput >> 15) & 1);
    printf("%d", (hexInput >> 14) & 1);
    printf("%d", (hexInput >> 13) & 1);
    printf("%d ", (hexInput >> 12) & 1);

    printf("%d", (hexInput >> 11) & 1);
    printf("%d", (hexInput >> 10) & 1);
    printf("%d", (hexInput >> 9) & 1);
    printf("%d ", (hexInput >> 8) & 1);

    printf("%d", (hexInput >> 7) & 1);
    printf("%d", (hexInput >> 6) & 1);
    printf("%d", (hexInput >> 5) & 1);
    printf("%d ", (hexInput >> 4) & 1);

    printf("%d", (hexInput >> 3) & 1);
    printf("%d", (hexInput >> 2) & 1);
    printf("%d", (hexInput >> 1) & 1);
    printf("%d\n", (hexInput >> 0) & 1);

    if (choice == 1) {
        // 轉換為有符號整數
        int32_t signedIntValue;
        if ((hexInput >> 15) & 1) {
            // 負數，進行符號擴展
            signedIntValue = (int32_t)(hexInput | 0xFFFF0000);
        } else {
            // 正數
            signedIntValue = (int32_t)hexInput;
        }
        printf("Converted signed integer is: %d\n", signedIntValue);
    } else if (choice == 2) {
        // 轉換為無符號整數
        uint32_t unsignedIntValue = hexInput;
        printf("Converted unsigned integer is: %u\n", unsignedIntValue);
    } else if (choice == 3) {
        // 轉換為浮點數（IEEE 754 半精度浮點數）
        int32_t sign = (hexInput >> 15) & 1;
        int32_t exponent = (hexInput >> 10) & 0x1F; // 5位指數
        int32_t mantissa = hexInput & 0x3FF; // 10位尾數

        float fraction;
        int32_t actualExponent;
        if (exponent == 0) {
            if (mantissa == 0) {
                // 零
                fraction = 0.0f;
                actualExponent = 0;
            } else {
                // 次正規數
                fraction = mantissa / (float)(1 << 10);
                actualExponent = -14;
            }
        } else if (exponent == 31) {
            // 特殊值（NaN或無窮大）
            if (mantissa == 0) {
                // 無窮大
                if (sign)
                    printf("Converted float is: -infinity\n");
                else
                    printf("Converted float is: +infinity\n");
                return 0;
            } else {
                // NaN
                printf("Converted float is: NaN\n");
                return 0;
            }
        } else {
            // 正規數
            fraction = 1 + mantissa / (float)(1 << 10);
            actualExponent = exponent - 15;
        }

        if (sign)
            printf("Converted float is: -%.6f*2^%d\n", fraction, actualExponent);
        else
            printf("Converted float is: %.6f*2^%d\n", fraction, actualExponent);
    } else {
        printf("Invalid choice.\n");
    }

    return 0;
}
