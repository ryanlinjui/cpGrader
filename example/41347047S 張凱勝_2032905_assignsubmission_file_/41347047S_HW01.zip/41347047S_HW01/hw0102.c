#include <stdio.h>
#include <stdint.h>

int32_t main() {
    int32_t num1, num3; // 第一和第三位数字的第一操作数
    int32_t num2;         // 第二操作数的中间数字
    int32_t sum;
    int32_t x, y, z;
    int32_t temp;

    printf("Please enter the first operand: ");
    if (scanf(" %1d%*1[x]%1d", &num1, &num3) != 2) {
        printf("Error: Invalid input for the first operand.\n");
        return 1;
    }

    printf("Please enter the second operand: ");
    if (scanf(" %*1[y]%1d%*1[z]", &num2) != 1) {
        printf("Error: Invalid input for the second operand.\n");
        return 1;
    }

    printf("Please enter the sum : ");
    if (scanf("%d", &sum) != 1) {
        printf("Error: Invalid input for sum.\n");
        return 1;
    }

    // 计算固定部分的值
    temp = num1 * 100 + num3 + num2 * 10;

    // 计算变量部分的总和
    temp = sum - temp;

    // 直接计算 x、y、z 的值
    y = temp / 100;
    if (y < 0 || y > 9) {
        printf("No solution found.\n");
        return 1;
    }
    temp -= y * 100;

    x = temp / 10;
    if (x < 0 || x > 9) {
        printf("No solution found.\n");
        return 1;
    }
    temp -= x * 10;

    z = temp;
    if (z < 0 || z > 9) {
        printf("No solution found.\n");
        return 1;
    }

    printf("Ans: x = %d, y = %d, z = %d\n", x, y, z);

    return 0;
}
