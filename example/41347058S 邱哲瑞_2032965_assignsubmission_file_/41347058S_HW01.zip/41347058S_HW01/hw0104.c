#include <stdio.h>
#include <stdint.h>
int main(){
  int32_t a,b,c,d,e,A,B,C,D,E ;  
  printf("Please enter 5 cards: ");
  scanf("%d %d %d %d %d",&a,&b,&c,&d,&e);

  if(a<1 || a>52 || b<1 || b>52 || c<1 || c>52 || d<1 || d>52 || e<1 || e>52){
    printf("ERROR\n");
  }
  else{

    if(1<=a && a<=13){
      A = 1;
    }
    else if(14<=a && a<=26){
      A = 2;
    }
    else if(27<=a && a<=39){
      A = 3;
    }
    else if(40<=a && a<=52){
      A = 4;
    }
    
    if(1<=b && b<=13){
      B = 1;
    }
    else if(14<=b && b<=26){
      B = 2;
    }
    else if(27<=b && b<=39){
      B = 3;
    }
    else if(40<=b && b<=52){
      B = 4;
    } 
    
    if(1<=c && c<=13){
      C = 1;
    }
    else if(14<=c && c<=26){
      C = 2;
    }
    else if(27<=c && c<=39){
      C = 3;
    }
    else if(40<=c && c<=52){
      C = 4;
    }
    
    if(1<=d && d<=13){
      D = 1;
    }
    else if(14<=d && d<=26){
      D = 2;
    }
    else if(27<=d && d<=39){
      D = 3;
    }
    else if(40<=d && d<=52){
      D = 4;
    }
    
    if(1<=e && e<=13){
      E = 1;
    }
    else if(14<=e && e<=26){
      E = 2;
    }
    else if(27<=e && e<=39){
      E = 3;
    }
    else if(40<=e && e<=52){
      E = 4;
    }
    
    a = ((a-1)%13)+1;
    b = ((b-1)%13)+1;
    c = ((c-1)%13)+1;
    d = ((d-1)%13)+1;
    e = ((e-1)%13)+1;
    
    if(a<=b){
      int32_t t=0;
      t = a;
      a = b;
      b = t;
    }
    if(a<=c){
      int32_t t=0;
      t = a;
      a = c;
      c = t;
    }
    if(a<=d){
      int32_t t=0;
      t = a;
      a = d;
      d = t;
    }
    if(a<=e){
      int32_t t=0;
      t = a;
      a = e;
      e = t;
    }
    if(b<=c){
      int32_t t=0;
      t = b;
      b = c;
      c = t;
    }
    if(b<=d){
      int32_t t=0;
      t = b;
      b = d;
      d = t;
    }
    if(b<=e){
      int32_t t=0;
      t = b;
      b = e;
      e = t;
    }
    if(c<=d){
      int32_t t=0;
      t = c;
      c = d;
      d = t;
    }
    if(c<=e){
      int32_t t=0;
      t = c;
      c = e;
      e = t;
    }
    if(d<=e){
      int32_t t=0;
      t = d;
      d = e;
      e = t;
    }
    
    if(A == B && B == C && C == D && D == E){
      if((a-b)==(b-c) && (b-c)==(c-d) && (c-d)==(d-e) && (a-b)==1){
        printf("Straight Flush\n");
      }
      else if (a == 13 && b == 12 && c == 11 && d == 10 && e == 9){
        printf("Straight Flush\n");
      }
      else{
        printf("Flush\n");
      }
    }
    else if((a-b)==(b-c) && (b-c)==(c-d) && (c-d)==(d-e) && (a-b)==1){
      printf("Straight\n");
    }
    else if(a == b && b == c && c == d && d != e){
      printf("Four of a kind\n");
    }
    else if(a != b && b == c && c == d && d == e){
      printf("Four of a kind\n");
    }
    else if(a == b && b == c && c != d && d == e){
      printf("Full house\n");
    }
    else if(a != b && b == c && c == d && a == e){
      printf("Full house\n");
    }
    else if(a == b && b != c && c == d && d == e){
      printf("Full house\n");
    }
    else if(a == b && b == c && c != d && d != e && a != e){
      printf("Three of a kind\n");
    }
    else if(a != b && b == c && c == d && d != e && a != e){
      printf("Three of a kind\n");
    }
    else if(a != b && b != c && c == d && d == e && a != e){
      printf("Three of a kind\n");
    }
    else if(a == b && b != c && c == d && d != e && a != e){
      printf("Two pair\n");
    }
    else if(a == b && b != c && c != d && d == e){
      printf("Two pair\n");
    }
    else if(a != b && b == c && c != d && d == e){
      printf("Two pair\n");
    }
    else if(a == b && b != c && c != d && d != e && a != d && a != e && c != e){
      printf("One pair\n");
    }
    else if(a != b && b == c && c != d && d != e && e != a && b != e && a != d){
      printf("One pair\n");
    }
    else if(a != b && b != c && c == d && d != e && e != a && e != b && a != b){
      printf("One pair\n");
    }
    else if(a != b && b != c && c != d && d == e && e != a && b != e && a != c){
      printf("One pair\n");
    }
    else{
      printf("High card\n");
    }  
  }
  return 0;
}
