#include <stdio.h>
#include <stdint.h>

int main(){
  int32_t a, b, c, sum ;
  printf("Please enter the first operand: \n");
  scanf("%dx%d",&a,&b);
  if(a<0 || a>=10 || b<0 || b>= 10){
    printf("ERROR\n");
  }
  else{
    printf("Please enter the second operand: \n");
    scanf(" y%dz",&c);
    if(c<0 || c>=10){
      printf("ERROR\n");
    }
    else{
      printf("Please enter the sum           : \n");
      scanf(" %d",&sum);
      int32_t s = sum%10, t = ((sum%100)-(sum%10))/10, h = (sum-sum%100)/100;
      int32_t x=0, y=0, z=0;

      if (s>=b){
        z += s - b;
      }
      else if(s<b){
        z = (s+10)-b;
        x -= 1;  
      }
      if(t>=c){
        x += t - c;
      }
      else if(t<c){
        x += (t+10)-c;
        y -= 1;
      }
      y += h - a;

      printf("Ans: x = %d, y = %d, z = %d  \n",x,y,z);
    }
  }
  
  return 0;
}
