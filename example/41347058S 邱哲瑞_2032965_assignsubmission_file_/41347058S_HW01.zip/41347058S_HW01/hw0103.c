#include <stdio.h>
#include <stdint.h>

int main(){
  uint32_t num;
  int s=0,t=0,h=0,d=0,w=0,u=0,n,m,v;
  printf("Please enter an unsigned 16-bit number: ");
  scanf("%d",&num);
  w = num/32768;
  d = (num%32768)/4096;
  h = (num%4096)/512;
  t = (num%512)/64;
  u = (num%64)/8;
  s = num%8;
  n = w*100000+d*10000+h*1000+t*100+u*10+s;
  printf("Before Flip:\n");
  printf("%d_10 = %d_8\n",num,n);
  if(w>0){
    m = w+d*10+h*100+t*1000+u*10000+s*100000;
    v = w+d*8+h*64+t*512+u*4096+s*32768;
  }
  else if (d>0){
    m = d+h*10+t*100+u*1000+s*10000;
    v = d+h*8+t*64+u*512+s*4096;
  }
  else if (h>0){
    m = h+t*10+u*100+s*1000;
    v = h+t*8+u*64+s*512;
  }
  else if (t>0){
    m = t+u*10+s*100;
    v = t+u*8+s*64;
  }
  else if (u>0){
    m = u+s*10;
    v = u+s*8;
  }
  else{
    m = s;
    v = s;
  }
  printf("After Flip:\n");
  printf("%d_8 = %d_10\n",m,v);
  
  return 0;
}
