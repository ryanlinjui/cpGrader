#include <stdio.h>

int main(){
  printf("\x1b[;31;1m""\n[KIM]\nYou are sunlight and I moon\nJoined by the gods of fortune\nMidnight and high noon sharing the sky\nWe have been blessed , you and I\n\n""\x1b[0;m");
  
  printf("\x1b[;34;1m""[CHRIS]\nYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\n\n""\x1b[0;m");
  
  printf("\x1b[;31;1m""[KIM]\nOutside day starts to dawn\n\n""\x1b[0;m");
  
  printf("\x1b[;34;1m""[CHRIS]\nYour moon still floats on high\n\n""\x1b[0;m");
  
  printf("\x1b[;31;1m""[KIM]\nThe birds awake\n\n""\x1b[0;m");
  
  printf("\x1b[;34;1m""[CHRIS]\nThe stars shine too\n\n""\x1b[0;m");
  
  printf("\x1b[;31;1m""[KIM]\nMy hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n\nYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho’s Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n\n""\x1b[0;m");
  
  printf("\x1b[;34;1m""[CHRIS]\nI reach for you\n\n""\x1b[0;m");
  
  printf("\x1b[;32;1m""[KIM & CHRIS]\nAnd we meet in the sky\n\n""\x1b[0;m");
  
  printf("\x1b[;31;1m""[KIM]\nYou are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n\n""\x1b[0;m");
  
  printf("\x1b[;32;1m""[KIM & CHRIS]\nMade of\nSunlight\nMoonlight\n\n""\x1b[0;m");
  
  return 0;
}

/*
[CHRIS]\nYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\n
12
13 [KIM]\nOutside day starts to dawn\n\n
15
16 [CHRIS]\nYour moon still floats on high\n\n
18
19 [KIM]\nThe birds awake\n\n
21
22 [CHRIS]\nThe stars shine too\n\n
24
25 [KIM]\nMy hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n\n
29
30 You might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho’s Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n\n
37
38 [CHRIS]\nI reach for you\n\n
40
41 [KIM & CHRIS]\nAnd we meet in the sky\n\n
43
44 [KIM]\nYou are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n\n
48
49 [KIM & CHRIS]\nMade of\nSunlight\nMoonlight\n
*/
