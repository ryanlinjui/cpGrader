#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
  char hundreds_1, tens_1, units_1, hundreds_2, tens_2, units_2, temp, sum_1, sum_2, sum_3, sum_4;
  int nhundreds_1, nunits_1, ntens_2, nsum_1, nsum_2, nsum_3, nsum_4, x, y, z, carry;
  
  //Read in the two operand
  printf("Please enter the first operand: ");
  scanf("%c", &hundreds_1);
  scanf("%c", &tens_1);
  scanf("%c", &units_1);
  //Block invalid 
  if (hundreds_1 > '9' || hundreds_1 < '0' || units_1 < '0' || units_1 > '9' || tens_1 != 'x')
  {
    printf("Invalid input.");
    return 0;
  }
  
  scanf("%c", &temp);
  if (temp != '\n')
  {
    printf("Invalid input.");
    return -1;
  }
  
  printf("Please enter the second operand: ");
  scanf("%c", &hundreds_2);
  scanf("%c", &tens_2);
  scanf("%c", &units_2);
  if (tens_2 < '0' || tens_2 > '9' || hundreds_2 != 'y' || units_2 != 'z')
  {
    printf("Invalid input.");
    return -1;
  }
  
  scanf("%c", &temp);
  if (temp != '\n')
  {
    printf("Invalid inout.");
    return -1;
  }
  
  printf("Please enter the sum: ");
  scanf("%c", &sum_1);
  scanf("%c", &sum_2);
  scanf("%c", &sum_3);
  scanf("%c", &sum_4);
  if (sum_4 == '\n')
  {
    sum_4 = sum_3;
    sum_3 = sum_2;
    sum_2 = sum_1;
    sum_1 = '0';
  }
  #ifdef DEBUG
  printf("The first operand: %c%c%c\n", hundreds_1, tens_1, units_1);
  printf("The second operand: %c%c%c\n", hundreds_2, tens_2, units_2);
  printf("The given sum: %c%c%c%c\n", sum_1, sum_2, sum_3, sum_4);
  #endif
  
  nhundreds_1 = hundreds_1 - 0x30;
  nunits_1 = units_1 - 0x30;
  ntens_2 = tens_2 - 0x30;
  nsum_1 = sum_1 - 0x30;
  nsum_2 = sum_2 - 0x30;
  nsum_3 = sum_3 - 0x30;
  nsum_4 = sum_4 - 0x30;
  int min = nhundreds_1 * 100 + nunits_1 + ntens_2 * 10;
  int max = min + 999;
  int nsum = nsum_1 * 1000 + nsum_2 * 100 + nsum_3 * 10 + nsum_4;
  
  if (nsum > max || nsum < min)
  {
    printf("Invalid sum input.\n");
    return -1;
  }
  
  if (nunits_1 > nsum_4) //carry = 1
  {
    z = nsum_4 + 10 - nunits_1;
    carry = 1;
  }
  else
  {
    z = nsum_4 - nunits_1;
    carry = 0;
  }

#ifdef DEBUG
  printf("nunits_1:%d nsum_4:%d z:%d next_carry:%d\n", nunits_1, nsum_4, z, carry);
#endif

  if (ntens_2 + carry > nsum_3) //carry = 1
  {
    x = nsum_3 + 10 - (ntens_2 + carry);
    carry = 1;
  }
  else
  {
    x = nsum_3 - (ntens_2 + carry);
    carry = 0;
  }
  
#ifdef DEBUG
  printf("ntens_2:%d nsum_3:%d x:%d next_carry:%d\n", ntens_2, nsum_3, x, carry);
#endif

  if (nhundreds_1 + carry > nsum_2) //carry = 1
  {
    y = nsum_2 + 10 - (nhundreds_1 + carry);
    carry = 1;
  }
  else
  {
    y = nsum_2 - (nhundreds_1 + carry);
    carry = 0;
  }

#ifdef DEBUG
  printf("nhundreds_1:%d nsum_2:%d y:%d next_carry:%d\n", nhundreds_1, nsum_2, y, carry);
#endif

  if (carry != nsum_1)
  {
    printf("Error\n");
  }
  else
  {
    printf("Ans: x = %d, y = %d, z = %d\n", x, y, z);
  }
  //Converting characters into numbers; character - 0x30 = number
}
