#include <stdio.h>
#include <stdint.h>

int main()
{
    int8_t card1, card2, card3, card4, card5;
    int8_t suit1, suit2, suit3, suit4, suit5;
    int8_t rank1, rank2, rank3, rank4, rank5;
    int8_t flush;
    
    printf("Please enter 5 cards: ");
    scanf("%hhd %hhd %hhd %hhd %hhd", &card1, &card2, &card3, &card4, &card5);
    if (card1 < 1 || card1 > 52 || card2 < 1 || card2 > 52 || card3 < 1 || card3 > 52 || card4 < 1 || card4 > 52 || card5 < 1 || card5 > 52)
    {
        printf("Error!");
        return -1;
    }
    //Step 1: find out the suit and rank of each card.
    suit1 = ((card1 - 1) / 13) + 1;
    suit2 = ((card2 - 1) / 13) + 1;
    suit3 = ((card3 - 1) / 13) + 1;
    suit4 = ((card4 - 1) / 13) + 1;
    suit5 = ((card5 - 1) / 13) + 1;
    rank1 = ((card1 - 1) % 13) + 1;
    rank2 = ((card2 - 1) % 13) + 1;
    rank3 = ((card3 - 1) % 13) + 1;
    rank4 = ((card4 - 1) % 13) + 1;
    rank5 = ((card5 - 1) % 13) + 1;
    
    //Step 2: determine if the five cards are flush (in the same suit).
    //compare only two variables at once
    if (suit1 == suit2)
    {
        if (suit2 == suit3)
        {
            if (suit3 == suit4)
            {
                if (suit4 == suit5)
                {
                    flush = 1;
                    goto label1;
                }
            }
        }
    }
    
    flush = 0;
    //Step 3: determine the cluster number of the cards, and how many cards are there in a cluster. 
    label1: 
    int8_t cluster;
    int8_t count1, count2, count3, count4, count5, point1, point2, point3, point4, point5;
    point1 = rank1;
    count1 = 1;
    cluster = 1;
    if (point1 == rank2)
    {
        count1++;
    }
    else
    {
        cluster++;
        count2 = 1;
        point2 = rank2;
    }
    // start to read the third card
    if (point1 == rank3)
    {
        count1++;
        
    }
    else if (cluster >= 2 && point2 == rank3)
    {
        count2++;
    }
    else
    {
        cluster++;
        if (cluster == 2)
        {
            count2 = 1;
            point2 = rank3;
        }
        else
        {
            count3 = 1;
            point3 = rank3;
        }
    }
    //start to read the forth card
    if (point1 == rank4)
    {
        count1++;
    }
    else if (cluster >= 2 && point2 == rank4)
    {
        count2++;
    }
    else if (cluster >= 3 && point3 == rank4)
    {
        count3++;
    }
    else
    {
        cluster++;
        //To determine the right cluster to add a new card
        if (cluster == 2)
        {
            count2 = 1;
            point2 = rank4;
        }
        else if (cluster == 3)
        {
            count3 = 1;
            point3 = rank4;
        }
        else
        {
            count4 = 1;
            point4 = rank4;
        }
    }
    //start to read the fifth card
    if (point1 == rank5)
    {
        count1++;
    }
    else if (cluster >= 2 && point2 == rank5)
    {
        count2++;
    }
    else if (cluster >= 3 && point3 == rank5)
    {
        count3++;
    }
    else if (cluster >= 4 && point4 == rank5)
    {
        count4++;
    }
    else
    {
        cluster++;
        if (cluster == 2)
        {
            count2 = 1;
            point2 = rank5;
        }
        else if (cluster == 3)
        {
            count3 = 1;
            point3 = rank5;
        }
        else if (cluster == 4)
        {
            count4 = 1;
            point4 = rank5;
        }
        else
        {
            count5 = 1;
            point5 = rank5;
        }
    }
    #ifdef DEBUG
    printf("rank: %hhu %hhu %hhu %hhu %hhu\n", rank1, rank2, rank3, rank4, rank5);
    printf("flush: %hhu\ncluster: %hhu\ncount: %hhu %hhu %hhu %hhu %hhu\npoint: %hhu %hhu %hhu %hhu %hhu\n", flush, cluster, count1, count2, count3, count4, count5, point1, point2, point3, point4, point5);
    #endif
    //calculate the maximum and minimum to determine if the five cards are straight
    int8_t max, min;
    max = rank1;
    min = rank1;
    //max and min are the variables, so use max, min to compare with other ranks 
    if (max < rank2)
    {
        max = rank2;
    }
    if (max < rank3)
    {
        max = rank3;
    }
    if (max < rank4)
    {
        max = rank4;
    }
    if (max < rank5)
    {
    max = rank5;
    }
   
    if (min > rank2)
    {
        min = rank2;
    }
    if (min > rank3)
    {
        min = rank3;
    }
    if (min > rank4)
    {
        min = rank4;
    }
    if (min > rank5)
    {
        min = rank5;
    }
    
    //prepare for the "flush" part 
    int8_t has10 = 0, has11 = 0, has12 = 0;
    
    if (rank1 == 10)
    {
        has10 = 1;
    }
    if (rank1 == 11)
    {
        has11 = 1;
    }
    if (rank1 == 12)
    {
        has12 = 1;
    }
    if (rank2 == 10)
    {
        has10 = 1;
    }
    if (rank2 == 11)
    {
        has11 = 1;
    }
    if (rank2 == 12)
    {
        has12 = 1;
    }
    if (rank3 == 10)
    {
        has10 = 1;
    }
    if (rank3 == 11)
    {
        has11 = 1;
    }
    if (rank3 == 12)
    {
        has12 = 1;
    }
    if (rank4 == 10)
    {
        has10 = 1;
    }
    if (rank4 == 11)
    {
        has11 = 1;
    }
    if (rank4 == 12)
    {
        has12 = 1;
    }
    if (rank5 == 10)
    {
        has10 = 1;
    }
    if (rank5 == 11)
    {
        has11 = 1;
    }
    if (rank5 == 12)
    {
        has12 = 1;
    }
    
    #ifdef DEBUG
    printf("Max: %hhu min: %hhu\n", max, min);
    #endif
    
    //start to determine the hand of cards
    if (cluster == 2)
    {
        if (count1 > count2)
        {
            if (count1 == 4)
            {
                printf("Four of a kind\n");
            }
            else
            {
                printf("Full House\n");
            }
        }
        else
        {
            if (count2 == 4)
            {
                printf("Four of a kind\n");
            }
            else 
            {
                printf("Full House\n");
            }
        }
    }
    
    else if (cluster == 3)
    {
        if (count1 >= count2)
        {
              if (count1 >= count3)
              {
                  if (count1 == 3)
                  {
                      printf("Three of a kind\n");
                  }
                  else
                  {
                      printf("Two Pair\n");
                  }
              }
              else
              {
                  if (count3 == 3)
                  {
                      printf("Three of a kind\n");
                  }
                  else
                  {
                      printf("Two Pair\n");
                  }
              }
        }
        else
        {
            if (count2 == 3)
            {
                printf("Three of a kind\n");
            }
            else
            {
                printf("Two Pair\n");
            }
        }
    }
    
    else if (cluster == 4)
    {
        printf("One Pair\n");
    }
    
    else if (cluster == 5)
    {   
        if (flush == 1)
        {
            if (max - min == 4 || (max - min == 12 && has10 && has11 && has12))
            {
                printf("Straight Flush\n");
            }
            else
            {
                printf("Flush\n");
            }
        }
        else
        {
            if (max - min == 4 || (max - min == 12 && has10 && has11 && has12))
            {
                printf("Straight\n");
            }
            else
            {
                printf("High Card\n");
            }
        }
    }
    
    else
    {
        printf("Error!");
    }
}
