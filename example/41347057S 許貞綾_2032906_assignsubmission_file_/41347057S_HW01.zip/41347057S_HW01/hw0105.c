#include <stdio.h>
#include <stdint.h>

#define bit_9 0.5
#define bit_8 (0.5*bit_9)
#define bit_7 (0.5*bit_8)
#define bit_6 (0.5*bit_7)
#define bit_5 (0.5*bit_6)
#define bit_4 (0.5*bit_5)
#define bit_3 (0.5*bit_4)
#define bit_2 (0.5*bit_3)
#define bit_1 (0.5*bit_2)
#define bit_0 (0.5*bit_1)

int main()
{
    int8_t hex3 = 0, hex2 = 0, hex1 = 0, hex0 = 0;
    int16_t dec3, dec2, dec1, dec0;
    int num, ret;
    
    printf("Please input a hex: \n");
    
    if ((scanf("%c", &hex3) == 0 ) || ! ((hex3 >= '0' && hex3 <= '9') || (hex3 >= 'A' && hex3 <= 'F') || (hex3 >= 'a' && hex3 <= 'f')))
    {
        printf("Invalid input.\n");
        return -1;
    }
    
    
    ret = scanf("%c", &hex2);
    
    if (hex2 == '\n')
    {
        hex0 = hex3;
        hex1 = hex2 = hex3 = '0';
        goto label1; 
    }
    
    else if (ret == 0 || 
        ! ((hex2 >= '0' && hex2 <= '9') || (hex2 >= 'A' && hex2 <= 'F') || (hex2 >= 'a' && hex2 <= 'f')) )
    {
        printf("Invalid input.\n");
        return -1;
    }
    
    
    ret = scanf("%c", &hex1);
    
    if (hex1 == '\n')
    {
        hex1 = hex3;
        hex0 = hex2;
        hex2 = hex3 = '0';
        goto label1;
    }
    
    else if (ret == 0 || 
        ! ((hex1 >= '0' && hex1 <= '9') || (hex1 >= 'A' && hex1 <= 'F') || (hex1 >= 'a' && hex1 <= 'f')) )
    {
        printf("Invalid input.\n");
        return -1;
    }
    
    
    ret = scanf("%c", &hex0);
    
    if (hex0 == '\n')
    {
          hex0 = hex1;
          hex1 = hex2;
          hex2 = hex3;
          hex3 = '0';
          goto label1;
    }
    
    else if (ret == 0 || 
        ! ((hex0 >= '0' && hex0 <= '9') || (hex0 >= 'A' && hex0 <= 'F') || (hex0 >= 'a' && hex0 <= 'f')) )
    {
        printf("Invalid input.\n");
        return -1;
    }

label1:
    // convert the hex numbers to decimal
    //decs are still hexadecimal numbers, while hexs are actually characters
    if (hex3 >= '0' && hex3 <= '9')
        dec3 = hex3 - 0x30;
    else if (hex3 >= 'A' && hex3 <= 'F')
        dec3 = hex3 - 0x37;
    else
        dec3 = hex3 - 0x57;
    if (hex2 >= '0' && hex2 <= '9')
        dec2 = hex2 - 0x30;
    else if (hex2 >= 'A' && hex2 <= 'F')
        dec2 = hex2 - 0x37;
    else
        dec2 = hex2 - 0x57;
    if (hex1 >= '0' && hex1 <= '9')
        dec1 = hex1 - 0x30;
    else if (hex1 >= 'A' && hex1 <= 'F')
        dec1 = hex1 - 0x37;
    else
        dec1 = hex1 - 0x57;
    if (hex0 >= '0' && hex0 <= '9')
        dec0 = hex0 - 0x30;
    else if (hex0 >= 'A' && hex0 <= 'F')
        dec0 = hex0 - 0x37;
    else
        dec0 = hex0 - 0x57;
        
    printf("Please choose the output type(1: integer, 2: unsigned integer, 3: float): \n");
    
    scanf("%d", &num);
    
    if (num < 1 || num > 4)
    {
        printf("Error!\n");
    }
    
    printf("Binary of %c%c%c%c is: %04b %04b %04b %04b\n", hex3, hex2, hex1, hex0, dec3, dec2, dec1, dec0);
    
    int output = dec3 * 16 * 16 * 16 + dec2 * 16 * 16 + dec1 * 16 + dec0;
    if (num == 1)
    {
        printf("Converted integer is: %hd\n", output);
    }
    
    else if (num == 2)
    {
        printf("Converted unsigned integer is: %hu\n", output);
    }
    else if (num == 3)
    {
        // First, check whether the binary number is positive or negative
        int signbit = output & 0x8000;
        char sign_c;
        if (signbit == 0)
        {
            sign_c = '+';
        }
        else
        {
            sign_c = '-';
        }
        
        //Then, calculate EXP and F
        uint32_t exp = (output & 0x7C00) >> 10;
        uint32_t F = output & 0x03FF, tmp;
        double sum_F = 0;
        uint8_t bit;
        //to get each bit of the F
        tmp = F;
        if (tmp > 0)
        {
            bit = tmp % 2;
            sum_F += bit * bit_0;
            tmp /= 2;
        }
        if (tmp > 0)
        {
            bit = tmp % 2;
            sum_F += bit * bit_1;
            tmp /= 2;
        }
        if (tmp > 0)
        {
            bit = tmp % 2;
            sum_F += bit * bit_2;
            tmp /= 2;
        }
        if (tmp > 0)
        {
            bit = tmp % 2;
            sum_F += bit * bit_3;
            tmp /= 2;
        }
        if (tmp > 0)
        {
            bit = tmp % 2;
            sum_F += bit * bit_4;
            tmp /= 2;
        }
        if (tmp > 0)
        {
            bit = tmp % 2;
            sum_F += bit * bit_5;
            tmp /= 2;
        }
        if (tmp > 0)
        {
            bit = tmp % 2;
            sum_F += bit * bit_6;
            tmp /= 2;
        }
        if (tmp > 0)
        {
            bit = tmp % 2;
            sum_F += bit * bit_7;
            tmp /= 2;
        }
        if (tmp > 0)
        {
            bit = tmp % 2;
            sum_F += bit * bit_8;
            tmp /= 2;
        }
        if (tmp > 0)
        {
            bit = tmp % 2;
            sum_F += bit * bit_9;
            tmp /= 2;
        }
        sum_F = sum_F + 1;
        if (exp == 0 && F == 0)
        {
            printf("Converted float is: %c0.0\n", sign_c);
        }
        else if (exp == 0x1F && F == 0)
        {
            printf("Converted float is: %cINF\n", sign_c);
        }
        else if (exp == 0x1F && F != 0)
        {
            printf("Converted float is: NAN\n");
        }
        else
        {
            printf("Converted float is : %c%1.10f * 2^%d\n", sign_c, sum_F, exp - 15);
        }
    }
}
