#include <stdio.h>

#define KIM_CLR "\e[0;31m"
#define DUET_CLR "\e[0;32m"
#define CHRIS_CLR "\e[0;34m"
#define COLOR_RESET "\e[0m"

int main()
{
  printf("%s[KIM]\nYou are sunlight and I moon\nJoined by the gods of fortune\nMidnight and high noon sharing the sky\nWe have    been blessed, you and I\n\n", KIM_CLR);
  printf("%s[CHRIS]\nYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\n\n", CHRIS_CLR);
  printf("%s[KIM]\nOutside day starts to dawn\n\n", KIM_CLR);
  printf("%s[CHRIS]\nYour moon still floats on high\n\n", CHRIS_CLR);
  printf("%s[KIM]\nThe birds awake\n\n", KIM_CLR);
  printf("%s[CHRIS]\nThe stars shine too\n\n", CHRIS_CLR);
  printf("%s[KIM]\nMy hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n\nYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho’s Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n\n", KIM_CLR);
  printf("%s[CHRIS]\nI reach for you\n\n", CHRIS_CLR);
  printf("%s[KIM & CHRIS]\nAnd we meet in the sky\n\n", DUET_CLR);
  printf("%s[KIM]\n You are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n\n", KIM_CLR);
  printf("%s[KIM & CHRIS]\nMade of\nSunlight\nMoonlight\n", DUET_CLR);
  return 0;
}
