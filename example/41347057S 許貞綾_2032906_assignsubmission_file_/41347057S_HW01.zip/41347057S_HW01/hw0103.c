#include <stdio.h>
#include <stdint.h>

#define EIGHT_1   8
#define EIGHT_2   (EIGHT_1*8)
#define EIGHT_3   (EIGHT_2*8)
#define EIGHT_4   (EIGHT_3*8)
#define EIGHT_5   (EIGHT_4*8)

int main(){
  int i, num_10F;
  uint16_t num_10 = 0, temp;
  char oc1, oc2, oc3, oc4, oc5, oc6;
  uint16_t re1, re2, re3, re4, re5, re6; // re1 is the least significant digit
  printf("Please enter an unsigned 16-bits number: ");
  scanf("%hu", &num_10);
  
  printf("Before Flip: \n%hu_10 = %o_8\n", num_10, num_10);
  
  re1 = num_10 % 8;
  temp = num_10 / 8;
  if (temp == 0)
  {
    re2 = re3 = re4 = re5 = re6 = 0;
    i = 1;
    goto label1;
  }
  re2 = temp % 8;
  temp = temp / 8;
  if (temp == 0)
  {
    re3 = re4 = re5 = re6 = 0;
    i = 2;
    goto label1;
  }
  re3 = temp % 8;
  temp /= 8;
  if (temp == 0)
  {
    re4 = re5 = re6 = 0;
    i = 3;
    goto label1;
  }
  re4 = temp % 8;
  temp /= 8;
  if (temp == 0)
  {
    re5 = re6 = 0;
    i = 4;
    goto label1;
  }
  re5 = temp % 8;
  temp /= 8;
  if (temp == 0)
  {
    re6 = 0;
    i = 5;
    goto label1;
  }
  re6 = temp % 8;
  if (re6 != 0)
  {
    i = 6;
  }
  
  label1:
  #ifdef DEBUG
  printf("%hu %hu %hu %hu %hu %hu %d\n", re1, re2, re3, re4, re5, re6, i);
  #endif 
  
  //After flip: re1...re6
  if (i == 1)
  {
    num_10F = re1 * 1;
    printf("After Flip: \n%o_8 = %d_10\n", re1, num_10F);
  }
  else if (i == 2)
  {
    num_10F = re1 * EIGHT_1 + re2;
    printf("After Flip: \n%o%o_8 = %d_10\n", re1, re2, num_10F);
  }
  else if (i == 3)
  {
    num_10F = re1 * EIGHT_2 + re2 * EIGHT_1 + re3;
    printf("After Flip: \n%o%o%o_8 = %d_10\n", re1, re2, re3, num_10F);
  }
  else if (i == 4)
  {
    num_10F = re1 * EIGHT_3 + re2 * EIGHT_2 + re3 * EIGHT_1 + re4;
    printf("After Flip: \n%o%o%o%o_8 = %d_10\n", re1, re2, re3, re4, num_10F);
  }
  else if (i == 5)
  {
    num_10F = re1 * EIGHT_4 + re2 * EIGHT_3 + re3 * EIGHT_2 + re4 * EIGHT_1 + re5;
    printf("After Flip: \n%o%o%o%o%o_8 = %d_10\n", re1, re2, re3, re4, re5, num_10F);
  }
  else if (i == 6)
  {
    num_10F = re1 * EIGHT_5 + re2 * EIGHT_4 + re3 * EIGHT_3 + re4 * EIGHT_2 + re5 * EIGHT_1 + re6;
    printf("After Flip: \n%o%o%o%o%o%o_8 = %d_10\n", re1, re2, re3, re4, re5, re6, num_10F);
  }
}
