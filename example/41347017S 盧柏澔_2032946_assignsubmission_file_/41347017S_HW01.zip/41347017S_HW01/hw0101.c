#include <stdio.h>

int main()
{
    /**
    [KIM]
    You are sunlight and I moon
    Joined by the gods of fortune
    Midnight and high noon sharing the sky
    We have been blessed , you and I
    
    [CHRIS]
    You are here like a mystery
    I'm from a world that's so different from all that you are
    How in the light of one night did we come so far?
    
    [KIM]
    Outside day starts to dawn
    
    [CHRIS]
    Your moon still floats on high
    
    [KIM]
    The birds awake
    
    [CHRIS]
    The stars shine too
    
    [KIM]
    My hands still shake
    See upcoming pop shows
    Get tickets for your favorite artists
    
    You might also like
    My Boy Only Breaks His Favorite Toys
    Taylor Swift
    Who’s Afraid of Little Old Me?
    Taylor Swift
    Guilty as Sin?
    Taylor Swift
    
    [CHRIS]
    I reach for you
    
    [KIM & CHRIS]
    And we meet in the sky
    
    [KIM]
    You are sunlight and I moon
    Joined here
    Brightening the sky with the flame of love
    
    [KIM & CHRIS]
    Made of
    Sunlight
    Moonlight
     */
    printf("\x1b[1;31m[KIM]\n");
    printf("\x1b[1;31mYou are sunlight and I moon\n");
    printf("\x1b[1;31mJoined by the gods of fortune\n");
    printf("\x1b[1;31mMidnight and high noon sharing the sky\n");
    printf("\x1b[1;31mWe have been blessed , you and I\n");

    printf("\n");

    printf("\x1b[1;34m[Chris]\n"); 
    printf("\x1b[1;34mYou are here like a mystery\n");
    printf("\x1b[1;34mI'm from a world that's so different from all that you are\n");
    printf("\x1b[1;34mHow in the light of one night did we come so far?\n");

    printf("\n");

    printf("\x1b[1;31m[KIM]\n");
    printf("\x1b[1;31mOutside day starts to dawn\n");

    printf("\n");

    printf("\x1b[1;34m[Chris]\n"); 
    printf("\x1b[1;34mYour moon still floats on high\n");

    printf("\n");

    printf("\x1b[1;31m[KIM]\n");
    printf("\x1b[1;31mThe birds awake\n");

    printf("\n");

    printf("\x1b[1;34m[Chris]\n"); 
    printf("\x1b[1;34mThe stars shine too\n");

    printf("\n");

    printf("\x1b[1;31m[KIM]\n");
    printf("\x1b[1;31mMy hands still shake\n");
    printf("\x1b[1;31mSee upcoming pop shows\n");
    printf("\x1b[1;31mGet tickets for your favorite artists\n");

    printf("\n");

    printf("\x1b[1;31mYou might also like\n");
    printf("\x1b[1;31mMy Boy Only Breaks His Favorite Toys\n");
    printf("\x1b[1;31mTaylor Swift\n");
    printf("\x1b[1;31mWho’ s Afraid of Little Old Me?\n");
    printf("\x1b[1;31mTaylor Swift\n");
    printf("\x1b[1;31mGuilty as Sin?\n");
    printf("\x1b[1;31mTaylor Swift\n");
    
    printf("\n");

    printf("\x1b[1;34m[Chris]\n"); 
    printf("\x1b[1;34mI reach for you\n");

    printf("\x1b[1;32m[KIM & Chris]\n");
    printf("\x1b[1;32mAnd we meet in the sky\n");

    printf("\n");

    printf("\x1b[1;31m[KIM]\n");
    printf("\x1b[1;31mYou are sunlight and I moon\n");
    printf("\x1b[1;31mJoined here\n");
    printf("\x1b[1;31mBrightening the sky with the flame of love\n");

    printf("\n");

    printf("\x1b[1;32m[KIM & Chris]\n");
    printf("\x1b[1;32mMade of\n");
    printf("\x1b[1;32mSunlight\n");
    printf("\x1b[1;32mMoonlight\n");

    return 0;
}