#include <stdio.h>
#include <stdint.h>

int main()
{
    uint64_t dec = 0;
    uint64_t oct = 0;
    printf("Please enter an unsigned 16-bits number: ");
    scanf("%ld", &dec);
    uint64_t dec_ori = dec;
    uint16_t oct_8 = 0;
    uint16_t oct_88 = 0;
    uint16_t oct_888 = 0;
    uint16_t oct_8888 = 0;
    uint16_t oct_88888 = 0;
    uint16_t oct_888888 = 0;

    // 16/3=5...1
    oct_8 = dec%8;
    dec /= 8;
    oct_88 = dec%8;
    dec /= 8;
    oct_888 = dec%8;
    dec /= 8;
    oct_8888 = dec%8;
    dec /= 8;
    oct_88888 = dec%8;
    oct_888888 = dec/8;
    oct = oct_888888*100000 + oct_88888*10000 + oct_8888*1000 + oct_888*100 + oct_88*10 + oct_8;
    printf("Before Flip: \n");
    printf("%ld_10 = %ld_8\n", dec_ori, oct);
    if (oct_888888)
    {
        oct = oct_8*100000 + oct_88*10000 + oct_888*1000 + oct_8888*100 + oct_88888*10 + oct_888888;
    }
    else if (oct_88888)
    {
        oct = oct_8*10000 + oct_88*1000 + oct_888*100 + oct_8888*10 + oct_88888;
    }
    else if (oct_8888)
    {
        oct = oct_8*1000 + oct_88*100 + oct_888*10 + oct_8888;
    }
    else if (oct_888)
    {
        oct = oct_8*100 + oct_88*10 + oct_888;
    }
    else if (oct_88)
    {
        oct = oct_8*10 + oct_88;
    }
    else if (oct_8)
    {
        oct = oct_8;
    }
    uint64_t oct_flip = oct;
    dec += oct % 10;
    oct /= 10;
    dec += oct % 10*8;
    oct /= 10;
    dec += oct % 10*8*8;
    oct /= 10;
    dec += oct % 10*8*8*8;
    oct /= 10;
    dec += oct % 10*8*8*8*8;
    oct /= 10;
    dec += oct % 10*8*8*8*8*8;
    oct /= 10;
    dec += oct % 10*8*8*8*8*8*8;
    oct /= 10;
    printf("After Flip: \n");
    printf("%ld_8 = %ld_10\n", oct_flip, dec);
    return 0;
}
