#include <stdio.h>
#include <stdint.h>
#include <math.h>

int main()
{
    char hex_1000 = '0';
    char hex_100 = '0';
    char hex_10 = '0';
    char hex_1 = '0';
    printf("Please input a hex:\n");
    scanf("\n%c%c%c%c", &hex_1000, &hex_100, &hex_10, &hex_1);

    int16_t dec_1000 = 0;
    int16_t dec_100 = 0;
    int16_t dec_10 = 0;
    int16_t dec_1 = 0;
    if (hex_1000 == 'A' || hex_1000 == 'a')
    {
        dec_1000 = 10;
    }
    else if (hex_1000 == 'B' || hex_1000 == 'b')
    {
        dec_1000 = 11;
    }
    else if (hex_1000 == 'C' || hex_1000 == 'c')
    {
        dec_1000 = 12;
    }
    else if (hex_1000 == 'D' || hex_1000 == 'd')
    {
        dec_1000 = 13;
    }
    else if (hex_1000 == 'E' || hex_1000 == 'e')
    {
        dec_1000 = 14;
    }
    else if (hex_1000 == 'F' || hex_1000 == 'f')
    {
        dec_1000 = 15;
    }
    else
    {
        dec_1000 = hex_1000 - '0';
    }

    if (hex_100 == 'A' || hex_100 == 'a')
    {
        dec_100 = 10;
    }
    else if (hex_100 == 'B' || hex_100 == 'b')
    {
        dec_100 = 11;
    }
    else if (hex_100 == 'C' || hex_100 == 'c')
    {
        dec_100 = 12;
    }
    else if (hex_100 == 'D' || hex_100 == 'd')
    {
        dec_100 = 13;
    }
    else if (hex_100 == 'E' || hex_100 == 'e')
    {
        dec_100 = 14;
    }
    else if (hex_100 == 'F' || hex_100 == 'f')
    {
        dec_100 = 15;
    }
    else
    {
        dec_100 = hex_100 - '0';
    }
    
    if (hex_10 == 'A' || hex_10 == 'a')
    {
        dec_10 = 10;
    }
    else if (hex_10 == 'B' || hex_10 == 'b')
    {
        dec_10 = 11;
    }
    else if (hex_10 == 'C' || hex_10 == 'c')
    {
        dec_10 = 12;
    }
    else if (hex_10 == 'D' || hex_10 == 'd')
    {
        dec_10 = 13;
    }
    else if (hex_10 == 'E' || hex_10 == 'e')
    {
        dec_100 = 14;
    }
    else if (hex_10 == 'F' || hex_10 == 'f')
    {
        dec_10 = 15;
    }
    else
    {
        dec_10 = hex_10 - '0';
    }
    
    if (hex_1 == 'A' || hex_1 == 'a')
    {
        dec_10 = 10;
    }
    else if (hex_1 == 'B' || hex_1 == 'b')
    {
        dec_10 = 11;
    }
    else if (hex_1 == 'C' || hex_1 == 'c')
    {
        dec_10 = 12;
    }
    else if (hex_1 == 'D' || hex_1 == 'd')
    {
        dec_10 = 13;
    }
    else if (hex_1 == 'E' || hex_1 == 'e')
    {
        dec_100 = 14;
    }
    else if (hex_1 == 'F' || hex_1 == 'f')
    {
        dec_1 = 15;
    }
    else
    {
        dec_1 = hex_1 - '0';
    }
    
    if (dec_1000 > 15 || 0 > dec_1000 || dec_100 > 15 || 0 > dec_100 || dec_10 > 15 || 0 > dec_10 || dec_1 > 15 || 0 > dec_1)
    {
        printf("False input!\n");
        return 0;
    }

    int32_t otype = 0;
    printf("Please choose the output type(1:integar,2:unsigned integar,3:float)");
    scanf("%d", &otype);
    if (otype > 3 || 1 > otype)
    {
        printf("False input!\n");
        return 0;
    }

    int32_t bin_1000 = 0;
    int32_t bin_100 = 0;
    int32_t bin_10 = 0;
    int32_t bin_1 = 0;
    int16_t space = 0;

    space = dec_1000;
    bin_1000 = bin_1000 + dec_1000%2;
    dec_1000 = dec_1000/2;
    bin_1000 = bin_1000 + dec_1000%2*10;
    dec_1000 = dec_1000/2;
    bin_1000 = bin_1000 + dec_1000%2*100;
    dec_1000 = dec_1000/2;
    bin_1000 = bin_1000 + dec_1000%2*1000;
    dec_1000 = space;

    space = dec_100;
    bin_100 = bin_100 + dec_100%2;
    dec_100 = dec_100/2;
    bin_100 = bin_100 + dec_100%2*10;
    dec_100 = dec_100/2;
    bin_100 = bin_100 + dec_100%2*100;
    dec_100 = dec_100/2;
    bin_100 = bin_100 + dec_100%2*1000;
    dec_100 = space;

    space = dec_10;
    bin_10 = bin_10 + dec_10%2;
    dec_10 = dec_10/2;
    bin_10 = bin_10 + dec_10%2*10;
    dec_10 = dec_10/2;
    bin_10 = bin_10 + dec_10%2*100;
    dec_10 = dec_10/2;
    bin_10 = bin_10 + dec_10%2*1000;
    dec_10 = space;

    space = dec_1;
    bin_1 = bin_1 + dec_1%2;
    dec_1 = dec_1/2;
    bin_1 = bin_1 + dec_1%2*10;
    dec_1 = dec_1/2;
    bin_1 = bin_1 + dec_1%2*100;
    dec_1 = dec_1/2;
    bin_1 = bin_1 + dec_1%2*1000;
    dec_1 = space;

    printf("Binary of %c%c%c%c is: %d %d %d %d\n", hex_1000, hex_100, hex_10, hex_1, bin_1000, bin_100, bin_10, bin_1);
    int32_t num16 = 0;
    int32_t maxnum16 = -32768;
    int32_t unum16 = 0;
    double exp = 0;
    int32_t f = 0;
    double dou = 0;
    if (otype == 1)
    {
        if (dec_1000/8) //-
        {
            dec_1000 = dec_1000%8;
            num16 = maxnum16 + dec_1*1 + dec_10*16 + dec_100*16*16 + dec_1000*16*16*16;
        }
        else //+
        {
            num16 = dec_1*1 + dec_10*16 + dec_100*16*16 + dec_1000*16*16*16;
        }
        printf("Converted integer is: %d\n", num16);
        return 0;
    }
    else if(otype == 2)
    {
        unum16 = dec_1*1 + dec_10*16 + dec_100*16*16 + dec_1000*16*16*16;
        printf("Converted unsigned integer is: %d\n", unum16);
        return 0;
    }
    else
    {
       if (dec_1000/8) // -
       {
            exp = dec_1000%8*2*2 + dec_100/4;
            f = (dec_100%4)*16*16 + dec_10*16 + dec_1;
            if (exp == 0 && f == 0)
            {
                printf("Converted float is: -0.0\n");
                return 0;
            }
            else if (exp == 31 && f == 0)
            {
                printf("Converted float is: -INF\n");
                return 0;
            }
            else if (exp == 31 && f != 0)
            {
                printf("Converted float is: NAN\n");
                return 0;
            }
            /**dou = dou + (f%2)/1024;
            f = f/2;
            dou = dou + (f%2)/512;
            f = f/2;
            dou = dou + (f%2)/256;
            f = f/2;
            dou = dou + (f%2)/128;
            f = f/2;
            dou = dou + (f%2)/64;
            f = f/2;

            dou = dou + (f%2)/32;
            f = f/2;
            dou = dou + (f%2)/16;
            f = f/2;
            dou = dou + (f%2)/8;
            f = f/2;
            dou = dou + (f%2)/4;
            f = f/2;
            dou = dou + (f%2)/2;
            f = f/2;
            dou = dou + 1;
            exp = exp - 15;
            double p = pow(2,exp);
            dou = dou*p;
            printf("Converted float is: -%lf\n", dou);**/
       }
       else //+
       {
            exp = dec_1000%8*2*2 + dec_100/4;
            f = (dec_100%4)*16*16 + dec_10*16 + dec_1;
            if (exp == 0 && f == 0)
            {
                printf("Converted float is: +0.0\n");
                return 0;
            }
            else if (exp == 31 && f == 0)
            {
                printf("Converted float is: +INF\n");
                return 0;
            }
            else if (exp == 31 && f != 0)
            {
                printf("Converted float is: NAN\n");
                return 0;
            }
            /**dou = dou + (f%2)/1024;
            f = f/2;
            dou = dou + (f%2)/512;
            f = f/2;
            dou = dou + (f%2)/256;
            f = f/2;
            dou = dou + (f%2)/128;
            f = f/2;
            dou = dou + (f%2)/64;
            f = f/2;

            dou = dou + (f%2)/32;
            f = f/2;
            dou = dou + (f%2)/16;
            f = f/2;
            dou = dou + (f%2)/8;
            f = f/2;
            dou = dou + (f%2)/4;
            f = f/2;
            dou = dou + (f%2)/2;
            f = f/2;
            dou = dou + 1;
            exp = exp - 15;
            double p = pow(2,exp);
            dou = dou*p;
            printf("Converted float is: +%lf\n", dou);**/
       }
    }
    return 0;
}