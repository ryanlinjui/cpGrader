41347017S 盧柏澔
hw0101:
    use ansi escape codes to change the output color of the lyrics
hw0102:
    translate the tpye of char and int, then I can completely catch each of the number
hw0103:
    the unsighed-16bit-integer have to divided by eight, and we could get the maxium number of "oct"
    have six digits, by this imformation we could translate the "dec" to the "oct" without loop.
    Flip part just do it by inverse way.
hw0104:
    First, we should check the input number is in the range or not.
    Second, I tried to sort the 5 cards one by one, and get an increasing sequences.
    Then, we could begin to determine which kind of the card type it is.
hw0105:
    get the hex and if it outof range, shutdown the code.
    turn it to binary type but decimal.
    according to the type which user want, convert the hex to binary type and the type user need.

    I tried to include math.h and use pow(),but it refused