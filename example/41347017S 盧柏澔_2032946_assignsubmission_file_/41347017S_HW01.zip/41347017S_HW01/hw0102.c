#include <stdio.h>
#include <stdint.h>

int main()
{
    char fir_100 = '0';
    char fir_1 = '0';
    char sec_10 = '0';
    int32_t sum = 0;
    char x = '0';
    char y = '0';
    char z = '0';
    int32_t st_100 = 0;
    int32_t ond_10 = 0;
    int32_t st_1 = 0;
    printf("Please enter the first operand: ");
    scanf("\n%c%c%c", &fir_100, &x, &fir_1);
    st_100 = fir_100 - '0';
    st_1 = fir_1 - '0';
    if (st_100 >= 10 || 0 > st_100 || st_1 >= 10 || 0 > st_1 || x != 'x')
    {
        printf("False input!!!\n");
        return 0;
    }
    else
    {
        printf("Please enter the secand operand: ");
        scanf("\n%c%c%c", &y, &sec_10, &z);
        ond_10 = sec_10 - '0';
        if (ond_10 >= 10 || 0 > ond_10 || y != 'y' || z != 'z')
        {
            printf("False input!!!\n");
            return 0;
        }
        else
        {
            printf("Please enter the sum: ");
            scanf("\n%d", &sum);
        }
    }

    sum -= 100*st_100 + 10*ond_10 + 1*st_1;
    st_1 = sum % 10;
    sum /= 10;
    ond_10 = sum % 10;
    sum /= 10;
    st_100 = sum % 10;
    printf("Ans: x = %d, y = %d, z = %d\n", ond_10, st_100, st_1);
    return 0;
}