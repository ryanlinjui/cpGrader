#include <stdio.h>
#include <stdint.h>

int main()
{
    int64_t first = 0; 
    int64_t second = 0;
    int64_t third = 0;
    int64_t fourth = 0;
    int64_t fifth = 0;  
    int32_t first_f = 0;
    int32_t second_f = 0;
    int32_t third_f = 0;
    int32_t fourth_f = 0;
    int32_t fifth_f = 0;
    int64_t space = 0;
    int32_t space_f = 0;
    printf("Please enter five cards: ");
    scanf("%ld %ld %ld %ld %ld", &first, &second, &third, &fourth, &fifth);
    if (first > 52 || first < 0 || second > 52 || second < 0 || third > 52 || third < 0 || fourth > 52 || fourth < 0 || fifth > 52 || fifth < 0)
    {
        printf("False input!!!\n");
        return 0;
    }
    first--;
    second--;
    third--;
    fourth--;
    fifth--;
    first_f = first / 13;
    first %= 13;
    second_f = second / 13;
    second %= 13;
    third_f = third / 13;
    third %= 13;
    fourth_f = fourth / 13;
    fourth %= 13;
    fifth_f = fifth / 13;
    fifth %= 13;

    if (first <= second)
    {
        space = first;
        first = second;
        second = space;
        space_f = first_f;
        first_f = second_f;
        second_f = space_f;
    }
    if (second <= third)
    {
        space = second;
        second = third;
        third = space;
        space_f = second_f;
        second_f = third_f;
        third_f = space_f;
    }
    if (third <= fourth)
    {
        space = third;
        third = fourth;
        fourth = space;
        space_f = third_f;
        third_f = fourth_f;
        fourth_f = space_f;
    }
    if (fourth <= fifth)
    {
        space = fourth;
        fourth = fifth;
        fifth = space;
        space_f = fourth_f;
        fourth_f = fifth_f;
        fifth_f = space_f;
    }
    if (first <= second)
    {
        space = first;
        first = second;
        second = space;
        space_f = first_f;
        first_f = second_f;
        second_f = space_f;
    }
    if (second <= third)
    {
        space = second;
        second = third;
        third = space;
        space_f = second_f;
        second_f = third_f;
        third_f = space_f;
    }
    if (third <= fourth)
    {
        space = third;
        third = fourth;
        fourth = space;
        space_f = third_f;
        third_f = fourth_f;
        fourth_f = space_f;
    }
    if (first <= second)
    {
        space = first;
        first = second;
        second = space;
        space_f = first_f;
        first_f = second_f;
        second_f = space_f;
    }
    if (second <= third)
    {
        space = second;
        second = third;
        third = space;
        space_f = second_f;
        second_f = third_f;
        third_f = space_f;
    }
    if (first <= second)
    {
        space = first;
        first = second;
        second = space;
        space_f = first_f;
        first_f = second_f;
        second_f = space_f;
    }
    if (first_f == second_f && second_f == third_f && third_f == fourth_f && fourth_f == fifth_f)
    {
        if (first == second + 1 && second == third + 1 && third == fourth + 1 && fourth == fifth + 1)
        {
            printf("Straight Flush\n");
            return 0;
        }
        else if (first == 12 && second == 11 && third == 10 && fourth == 9 && fifth == 0)
        {
            printf("Straight Flush\n");
            return 0;
        }
        else
        {
            printf("Flush\n");
            return 0;   
        }
    }
    else
    {
        if (first == second + 1 && second == third + 1 && third == fourth + 1 && fourth == fifth + 1)
        {
            printf("Straight\n");
            return 0;
        }
        else if (first == 12 && second == 11 && third == 10 && fourth == 9 && fifth == 0)
        {
            printf("Straight\n");
            return 0;
        }
        else if (first == second && second == third && third == fourth)
        {
            printf("Four Of A Kind\n");
            return 0;
        }
        else if (second == third && third == fourth && fourth == fifth)
        {
            printf("Four Of A Kind\n");
            return 0;
        }
        else if (first == second && second == third)
        {
            if (fourth == fifth)
            {
                printf("Full House\n");
                return 0;
            }
            printf("Three Of A Kind\n");
            return 0;
        }
        else if (second == third && third == fourth)
        {
            printf("Three Of A Kind\n");
            return 0;
        }
        else if (third == fourth && fourth == fifth)
        {
            if (first == second)
            {
                printf("Full House\n");
                return 0;
            }
            printf("Three Of A Kind\n");
            return 0;
        }
        else if (first == second && third == fourth)
        {
            printf("Two Pair\n");
            return 0;
        }
        else if (first == second && fourth == fifth)
        {
            printf("Two Pair\n");
            return 0;
        }
        else if (second == third && fourth == fifth)
        {
            printf("Two Pair\n");
            return 0;
        }
        else if (first == second)
        {
            printf("One Pair\n");
            return 0;
        }
        else if (second == third)
        {
            printf("One Pair\n");
            return 0;
        }
        else if (third == fourth)
        {
            printf("One Pair\n");
            return 0;
        }
        else if (fourth == fifth)
        {
            printf("One Pair\n");
            return 0;
        }
    }

    printf("High Card\n");
    return 0;
}