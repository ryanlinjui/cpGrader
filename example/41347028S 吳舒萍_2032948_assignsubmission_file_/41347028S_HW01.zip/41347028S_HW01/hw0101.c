#include<stdio.h>

int main(){
  printf("\033[0m\033[91m[KIM]\n\033[0m");
  printf("\033[0m\033[91mYou are sunlight and I moon\nJoined by the gods of fortune\nMidnight and high noon sharing the sky\nWe have been blessed, you and I\n\033[0m");
  printf("\n");
  printf("\033[0m\033[94m[CHRIS]\n\033[0m");
  printf("\033[0m\033[94mYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\n\033[0m");
  printf("\n");
  printf("\033[0m\033[91m[KIM]\nOutside day starts to dawn\n\033[0m");
  printf("\n");
  printf("\033[0m\033[94m[CHRIS]\nYour moon still floats on high\n\033[0m");
  printf("\n");
  printf("\033[0m\033[91m[KIM]\nThe birds awake\n\033[0m");
  printf("\n");
  printf("\033[0m\033[94m[CHRIS]\nThe stars shine too\n\033[0m");
  printf("\n");
  printf("\033[0m\033[91m[KIM]\nMY hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n\nYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho’s Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n");
  printf("\n");
  printf("\033[0m\033[94m[CHRIS]\nI reach for you\n\033[0m");
  printf("\n");
  printf("\033[0m\033[92m[KIM & CHRIS]\n\033[0m");
  printf("\033[0m\033[92mAnd we meet in the sky\n\033[0m");
  printf("\n");
  printf("\033[0m\033[91m[KIM]\nYou are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n\033[0m");
  printf("\n");
  printf("\033[0m\033[92m[KIM & CHRIS]\nMade of\nSunlight\nMoonlight\n\033[0m");
  
  return 0;
}
