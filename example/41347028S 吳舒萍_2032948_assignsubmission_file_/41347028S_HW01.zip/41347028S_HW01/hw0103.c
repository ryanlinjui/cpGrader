#include<stdio.h>
#include<stdint.h>

int main(){
  uint16_t num1_10=0,num2_10=0;
  uint16_t num_8=0,numf_8=0;
  int16_t temp=0;
  
  printf("Please enter an unsigned 16-bits number: ");
  scanf("%hu",&num1_10);
  
  if(num1_10<8){
    num_8=num1_10;
  }
  else{
    num_8+=num1_10%8;
    temp=num1_10/8;
  }
  
  if(temp<8){
    num_8+=temp*10;
    temp=0;
  }
  else{
    num_8+=(temp%8)*10;
    temp/=8;
  }
  
  if(temp<8){
    num_8+=temp*100;
    temp=0;
  }
  else{
    num_8+=(temp%8)*100;
    temp/=8;
  }
  
  if(temp<8){
    num_8+=temp*1000;
    temp=0;
  }
  else{
    num_8+=(temp%8)*1000;
    temp/=8;
  }
  
  if(temp<8){
    num_8+=temp*10000;
    temp=0;
  }
  else{
    num_8+=(temp%8)*10000;
    temp/=8;
  }
  
  if(temp<8){
    num_8+=temp*100000;
    temp=0;
  }
  else{
    num_8+=(temp%8)*100000;
    temp/=8;
  }
  
  
  if(num_8/10==0){
    numf_8=num_8;
  }
  else if(num_8/100==0){
    numf_8=(num_8%10)*10+num_8/10;
  }
  else if(num_8/1000==0){
    numf_8=(num_8%10)*100+(num_8%100-num_8%10)*10+num_8/100;
  }
  else if(num_8/10000==0){
    numf_8=(num_8%10)*1000+((num_8%100)/10)*100+((num_8%1000)/100)*10+num_8/1000;
  }
  else if(num_8/100000==0){
    numf_8=(num_8%10)*10000+((num_8%100)/10)*1000+((num_8%1000)/100)*100+((num_8%10000)/1000)*10+num_8/10000;
  }
  else if(num_8/1000000==0){
    numf_8=(num_8%10)*100000+((num_8%100)/10)*10000+((num_8%1000)/100)*1000+((num_8%10000)/1000)*100+((num_8%100000)/10000)*10+num_8/100000;
  }
  
  
  num2_10=numf_8%10+((numf_8%100)/10)*8+((numf_8%1000)/100)*64+((numf_8%10000)/1000)*512+((numf_8%100000)/10000)*4096+((numf_8%1000000)/100000)*32768;
  
  printf("Before Flip:\n");
  printf("%u_10 = %o_8\n",num1_10,num1_10);
  printf("After Flip:\n");
  printf("%hu_8 = %hu_10\n",numf_8,num2_10);
  
  return 0;
}
