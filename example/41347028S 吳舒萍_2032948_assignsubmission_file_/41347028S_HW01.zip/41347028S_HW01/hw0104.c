#include<stdio.h>
#include<stdint.h>

int main(){
  int32_t num1=0,num2=0,num3=0,num4=0,num5=0;
  int32_t card1=0,card2=0,card3=0,card4=0,card5=0;
  int32_t pattern1=0,pattern2=0,pattern3=0,pattern4=0,pattern5=0;
  int32_t suit1=0,suit2=0;
  
  printf("Please enter 5 cards: ");
  scanf("%d %d %d %d %d",&num1,&num2,&num3,&num4,&num5);
  
  if(num1<1 || num1>52){
    printf("Wrong Input\n");
    return 0;
  }
  if(num2<1 || num2>52){
    printf("Wrong Input\n");
    return 0;
  }
  if(num3<1 || num3>52){
    printf("Wrong Input\n");
    return 0;
  }
  if(num4<1 || num4>52){
    printf("Wrong Input\n");
    return 0;
  }
  if(num5<1 || num5>52){
    printf("Wrong Input\n");
    return 0;
  }
  
  card1=num1;
  card2=13;
  card3=num3;
  card4=0;
  card5=num5;
  
  if((card1-1)%13>(num2-1)%13){
    card1=num2;
  }
  if((card1-1)%13>(num3-1)%13){
    card1=num3;
  }
  if((card1-1)%13>(num4-1)%13){
    card1=num4;
  }
  if((card1-1)%13>(num5-1)%13){
    card1=num5;
  }
  
  if((card2-1)%13>(num1-1)%13 && num1!=card1){
    card2=num1;
  }
  if((card2-1)%13>(num2-1)%13 && num2!=card1){
    card2=num2;
  }
  if((card2-1)%13>(num3-1)%13 && num3!=card1){
    card2=num3;
  }
  if((card2-1)%13>(num4-1)%13 && num4!=card1){
    card2=num4;
  }
  if((card2-1)%13>(num5-1)%13 && num5!=card1){
    card2=num5;
  }
  
  if((card5-1)%13<(num1-1)%13){
    card5=num1;
  }
  if((card5-1)%13<(num2-1)%13){
    card5=num2;
  }
  if((card5-1)%13<(num3-1)%13){
    card5=num3;
  }
  if((card5-1)%13<(num4-1)%13){
    card5=num4;
  }
  
  if((card4-1)%13<(num1-1)%13 && num1!=card5){
    card4=num1;
  }
  if((card4-1)%13<(num2-1)%13 && num2!=card5){
    card4=num2;
  }
  if((card4-1)%13<(num3-1)%13 && num3!=card5){
    card4=num3;
  }
  if((card4-1)%13<(num4-1)%13 && num4!=card5){
    card4=num4;
  }
  if((card4-1)%13<(num5-1)%13 && num5!=card5){
    card4=num5;
  }
  
  if(num1!=card1 && num1!=card2 && num1!=card4 && num1!=card5){
    card3=num1;
  }
  if(num2!=card1 && num2!=card2 && num2!=card4 && num2!=card5){
    card3=num2;
  }
  if(num3!=card1 && num3!=card2 && num3!=card4 && num3!=card5){
    card3=num3;
  }
  if(num4!=card1 && num4!=card2 && num4!=card4 && num4!=card5){
    card3=num4;
  }
  if(num5!=card1 && num5!=card2 && num5!=card4 && num5!=card5){
    card3=num5;
  }
  
  pattern1=(card1-1)/13;
  pattern2=(card2-1)/13;
  pattern3=(card3-1)/13;
  pattern4=(card4-1)/13;
  pattern5=(card5-1)/13;
  
  num1=(card1-1)%13;
  num2=(card2-1)%13;
  num3=(card3-1)%13;
  num4=(card4-1)%13;
  num5=(card5-1)%13;
  
  suit1=(pattern1==pattern2 && pattern2==pattern3 && pattern3==pattern4 && pattern4==pattern5);
  switch(suit1)
  {
    case 1:
      if((card5-card4)==(card4-card3) && (card4-card3)==(card3-card2) && (card3-card2)==(card2-card1) && (card2-card1)==1){
        printf("Straight Flush\n");
        return 0;
      }
      else{
        printf("Flush\n");
        return 0;
      }
      case 0:
        suit2=(num1==num2)+(num2==num3)+(num3==num4)+(num4==num5);
        switch(suit2)
        {
          case 1:
            printf("One Pair\n");
            return 0;
          case 2:
            if(((num1==num2)+(num2==num3))==2 || ((num2==num3)+(num3==num4))==2 || ((num3==num4)+(num4==num5))==2){
              printf("Three A Kind\n");
              return 0;
            }
            else{
              printf("Two Pair\n");
              return 0;
            }
          case 3:
            if(((num1==num2)+(num2==num3)+(num3==num4))==3 || ((num2==num3)+(num3==num4)+(num4==num5))==3){
              printf("Four A Kind\n");
              return 0;
            }
            else{
              printf("Full House\n");
              return 0;
            }
          case 0:
            if((num5-num4)==(num4-num3) && (num4-num3)==(num3-num2) && (num3-num2)==(num2-num1) && (num2-num1)==1){
              printf("Straight\n");
              return 0;
            }
            else{
              printf("High Card\n");
              return 0;
            }
        }
      
  }
  
}
  
  
  // (((card1-1)%13)==((card2-1)%13))+(((card2-1)%13)==((card3-1)%13))+(((card3-1)%13)==((card4-1)%13))+(((card4-1)%13)==((card5-1)%13))
  /*
  four a kind=3
  full house=3
  three a kind=2
  two pair=2
  one pair=1
  straight=0
  high card=0
  */


