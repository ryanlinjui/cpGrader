#include<stdio.h>
#include<stdint.h>

int main(){
  uint16_t numhex=0,numhex1=0,numhex2=0,numhex3=0,numhex4=0;
  int32_t type=0;
  uint16_t numb1=0,numb2=0,numb3=0,numb4=0;
  float numf=0;
  int16_t s=0,exp=0;
  
  printf("Please input a hex:");
  scanf("%hX",&numhex);
  printf("Please choose the output type(1:integer,2:unsigned integer,3:float):");
  scanf("%d",&type);
  
  numhex1=numhex/(16*16*16);
  numhex2=numhex/(16*16)-numhex1*16;
  numhex3=numhex/16-(numhex1*16*16)-(numhex2*16);
  numhex4=numhex%16;
  
  numb1=numhex1/8*1000+(numhex1%8)/4*100+(numhex1%4)/2*10+numhex1%2;
  numb2=numhex2/8*1000+(numhex2%8)/4*100+(numhex2%4)/2*10+numhex2%2;
  numb3=numhex3/8*1000+(numhex3%8)/4*100+(numhex3%4)/2*10+numhex3%2;
  numb4=numhex4/8*1000+(numhex4%8)/4*100+(numhex4%4)/2*10+numhex4%2;
  
  printf("Binary of %hX is: %04hu %04hu %04hu %04hu\n",numhex,numb1,numb2,numb3,numb4);
  
  switch(type)
  {
    case 1:
      printf("Converted integer is: %hd\n",numhex);
      break;
    case 2:
      printf("Converted unsigned integer is: %hu\n",numhex);
      break;
    case 3:
      s=numb1/1000;
      exp=(numb1%1000)/100*16+(numb1%100)/10*8+numb1%10*4+numb2/1000*2+(numb2%1000)/100;
      numf=(numb2%100)/10*(0.5)+(numb2%10)*(0.25)+(numb3/1000)*(0.125)+(numb3%1000)/100*(0.0625)+(numb3%100)/10*(0.03125)+(numb3%10)*(0.015625)+(numb4/1000)*(0.0078125)+(numb4%1000)/100*(0.00390625)+(numb4%100)/10*(0.00195312)+(numb4%10)*(0.00097656);
      
      if(exp==0 && numf==0){
        if(s==0){
          printf("Converted float is: +0.0\n");
          break;
        }
        else{
          printf("Converted float is: -0.0\n");
          break;
        }
      }
      else if(exp==31 && numf==0){
        if(s==0){
          printf("Converted float is: +INF\n");
          break;
        }
        else{
          printf("Converted float is: -INF\n");
          break;
        }
      }
      else if(exp==31 && numf!=0){
        printf("Converted float is: NAN\n");
        break;
      }
      numf+=1;
      exp-=15;
      if(s==0){
        printf("Converted float is: %f*2^%hd\n",numf,exp);
        break;
      }
      else{
        printf("Converted float is: -%f*2^%hd\n",numf,exp);
        break;
      }
  }
  
  return 0;
  
}
