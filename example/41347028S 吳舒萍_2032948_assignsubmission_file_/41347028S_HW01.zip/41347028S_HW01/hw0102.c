#include<stdio.h>
#include<stdint.h>

int main(){
  int32_t num1_1=0,x=0,num1_3=0;
  int32_t y=0,num2_2=0,z=0;
  int32_t sum=0;
  
  printf("Please enter the first  operand: ");
  scanf("%dx%d",&num1_1,&num1_3);
  printf("Please enter the second operand: ");
  scanf(" y%dz",&num2_2);
  printf("Please enter the sum           : ");
  scanf("%d",&sum);
  
  if(sum%10>=num1_3){
    z=sum%10-num1_3;
  }
  else{
    z=sum%10+10-num1_3;
    sum-=10;
  }
  
  if((sum%100)/10>=num2_2){
    x=(sum%100)/10-num2_2;
  }
  else{
    x=(sum%100)/10+10-num2_2;
    sum-=100;
  }
  
  y=sum/100-num1_1;
  
  printf("Ans: x = %d, y = %d, z = %d\n",x,y,z); 
  
  return 0;
}
