#include <stdio.h>
#include <stdint.h>

int32_t a, c, e, result, sum;
int32_t x_value, y_value, z_value, x, y, z;
int32_t error1, error2, error3;

int main(){
    //input
    printf("Please enter the first operand\t: ");
    error1 = scanf("%dx%d", &a, &c);
    if(a < 0 || a > 9 || c < 0 || c > 9 || error1 != 2){
        printf("Invalid Input!\n");
        return 1;
    }

    printf("Please enter the second operand\t: ");
    error2 = scanf(" y%dz", &e);
    if(e < 0 || e > 9 || error2 != 1){
        printf("Invalid Input!\n");
        return 1;
    }

    printf("Please enter the sum\t\t: ");
    error3 = scanf("%d", &sum);
    if(sum < 0 || error3 != 1 ){
        printf("Invalid Input!\n");
        return 1;
    }
    //substract > assign digit
    result = sum - a*100 - e*10 - c;
    x_value = (result / 10) % 10;
    y_value = result / 100;
    z_value = result % 10;
    if(x_value < 0 || x_value > 9 || y_value < 0 || y_value > 9 || z_value < 0 || z_value > 9){
        printf("no possible value for x, y, z\n");
        return 1;
    }
    else{
        x = x_value;
        y = y_value;
        z = z_value;
        printf("Ans: x = %d, y = %d, z = %d\n", x, y, z);
    }
    return 0;
}