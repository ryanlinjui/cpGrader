#include <stdio.h>
#include <stdint.h>
uint32_t hexinput, choice;
uint32_t value, bit1, bit2, bit3, bit4, bit5, bit6, bit7, bit8;
uint32_t bit9, bit10, bit11, bit12, bit13, bit14, bit15, bit16;
int32_t trueexp;
int main(){
    //input
    printf("Please input a hex:");
    scanf("%x", &hexinput);
    printf("Please choose the output type(1:integer,2:unsigned integer,3:float):");
    scanf("%d", &choice);

    //binary bit extractor
    value = hexinput;
    bit1 = (value / 32768) % 2;
    bit2 = (value / 16384) % 2;
    bit3 = (value / 8192) % 2;
    bit4 = (value / 4096) % 2;

    bit5 = (value / 2048) % 2;
    bit6 = (value / 1024) % 2;
    bit7 = (value / 512) % 2;
    bit8 = (value / 256) % 2;

    bit9 = (value / 128) % 2;
    bit10 = (value / 64) % 2;
    bit11 = (value / 32) % 2;
    bit12 = (value / 16) % 2;

    bit13 = (value / 8) % 2;
    bit14 = (value / 4) % 2;
    bit15 = (value / 2) % 2;
    bit16 = value % 2;

    printf("Binary of %X is %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n", hexinput, 
    bit1, bit2, bit3, bit4, bit5, bit6, bit7, bit8, bit9, bit10, bit11, bit12, bit13, bit14, bit15, bit16);
    
    if(choice == 1){
        if(bit1 == 1){
            //complement method
            uint32_t negnum = -(65536 - hexinput);
            printf("Converted integer is: %d\n", negnum);
        }else printf("Converted integer is: %d\n", hexinput);
    }else if(choice == 2){
        printf("Converted unsigned integer is: %u\n", hexinput);
    }
    else if(choice == 3){
        uint32_t exp, sign, frac;
        float result;
        
        sign = bit1;
        exp = 16*bit2 + 8*bit3 + 4*bit4 + 2*bit5 + bit6;
        frac = 512*bit7 + 256*bit8 + 128*bit9 + 64*bit10 + 32*bit11 + 
        16*bit12 + 8*bit13 + 4*bit14 + 2*bit15 + bit16;

        if(exp == 0){
            result = frac * 1.0 / 1024;
            if(frac == 0){
                if(sign == 1){
                    printf("Converted float is: -0.0\n");
                }else{
                    printf("Converted float is: +0.0\n");
                }
            }else{
                trueexp = -15;
                result = frac * 1.0 / 1024;
                //make sure leading number isn't zero, lowest poaaible starting value is 2^-10
                if(result < 1){result *= 2; trueexp --;}
                if(result < 1){result *= 2; trueexp --;}
                if(result < 1){result *= 2; trueexp --;}
                if(result < 1){result *= 2; trueexp --;}
                if(result < 1){result *= 2; trueexp --;}
                if(result < 1){result *= 2; trueexp --;}
                if(result < 1){result *= 2; trueexp --;}
                if(result < 1){result *= 2; trueexp --;}
                if(result < 1){result *= 2; trueexp --;}
                if(result < 1){result *= 2; trueexp --;}

                if(sign == 1){
                    result = -result;
                }
                printf("Converted float is: %.6f*2^%d\n", result, trueexp);

            }
        } 
        else if(exp == 31){
            if(frac == 0){
                if (sign == 1){
                    printf("Converted float is: -INF\n");
                }
                else{
                    printf("Converted float is: +INF\n");
                }
            }else{
                printf("Converted float is: NAN\n");
            }
        }else{
            trueexp = (exp - 15);
            result = 1 + (frac*1.0 / 1024);
            if(sign == 1){
                result = -result;
            }
             printf("Converted float is: %.6f*2^%d\n", result, trueexp);
            
        }
    }
    else{
    printf("Invalid Choice\n");
    }
    
    return 0;
}





