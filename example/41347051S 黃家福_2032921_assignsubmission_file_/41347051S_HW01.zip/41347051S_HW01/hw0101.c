#include <stdio.h>
//RED "\e[0;31m" kim
//BLU "\e[0;34m" chris
//GRN "\e[0;32m" both
//WHITE "\e[0;37m"
int main(){
    //color change
    printf("\e[0;31m");
    printf("[KIM]\n");
    printf("You are sunlight and I moon\n");
    printf("Joined by the gods of fortune\n");
    printf("Midnight and high noon sharing the sky\n");
    printf("We have been blessed , you and I");
    //color reset just in case and 2 line
    printf("\e[0;37m\n\n");


    //change
    printf("\e[0;34m");
    printf("[CHRIS]\n");
    printf("You are here like a mystery\n");
    printf("I'm from a world that's so different from all that you are\n");
    printf("How in the light of one night did we come so far?");
    //color reset and line
    printf("\e[0;37m\n\n");


    //change
    printf("\e[0;31m");
    printf("[KIM]\n");
    printf("Outside day starts to dawn");
    //reset and line
    printf("\e[0;37m\n\n");


    //change
    printf("\e[0;34m");
    printf("[CHRIS]\n");
    printf("Your moon still floats on high");
    // reset n line
    printf("\e[0;37m\n\n");


    //change
    printf("\e[0;31m");
    printf("[KIM]\n");
    printf("The birds awake");
    // reset n line
    printf("\e[0;37m\n\n");
    

    //change
    printf("\e[0;34m");
    printf("[CHRIS]\n");
    printf("The stars shine too");
    //reset n line
    printf("\e[0;37m\n\n");


    //change
    printf("\e[0;31m");
    printf("[KIM]\n");
    printf("My hands still shake\n");
    printf("See upcoming pop shows\n");
    printf("Get tickets for your favorite artists\n\n");
    printf("You might also like\n");
    printf("My Boy Only Breaks His Favorite Toys\n");
    printf("Taylor Swift\n");
    printf("Who’s Afraid of Little Old Me?\n");
    printf("Taylor Swift\n");
    printf("Guilty as Sin?\n");
    printf("Taylor Swift");
    // reset n line
    printf("\e[0;37m\n\n");


    //change
    printf("\e[0;34m");
    printf("[CHRIS]\n");
    printf("I reach for you");
    // reset n line
    printf("\e[0;37m\n\n");


    //change
    printf("\e[0;32m\n");
    printf("[KIM & CHRIS]\n");
    printf("And we meet in the sky");
    // reset n line
    printf("\e[0;37m\n\n");


    //change
    printf("\e[0;31m");
    printf("[KIM]\n");
    printf("You are sunlight and I moon\n");
    printf("Joined here\n");
    printf("Brightening the sky with the flame of love");
    // reset n line
    printf("\e[0;37m\n\n");


    //change
    printf("\e[0;32m\n");
    printf("[KIM & CHRIS]\n");
    printf("Made of\n");
    printf("Sunlight\n");
    printf("Moonlight");
    //reset
    printf("\e[0;37m\n");
    return 0;
}