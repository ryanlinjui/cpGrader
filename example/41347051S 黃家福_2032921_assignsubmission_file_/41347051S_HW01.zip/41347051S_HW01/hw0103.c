#include <stdio.h>
#include <stdint.h>

uint32_t before, after;
uint32_t oct_a, oct_b;
uint32_t d1, d2, d3, d4, d5, d6;
uint32_t dd1, dd2, dd3, dd4, dd5, dd6;
uint32_t fd1, fd2, fd3, fd4, fd5, fd6;


int main(){
    //input
    printf("Please enter an unsigned 16-bits number: ");
    scanf("%u", &before);

    //extract digit, highest is 8^5
    d1 = before / (8*8*8*8*8);
    d2 = (before / (8*8*8*8)) % 8;
    d3 = (before / (8*8*8)) % 8;
    d4 = (before / (8*8)) % 8;
    d5 = (before / 8) % 8;
    d6 = before % 8;
    oct_a = 100000*d1 + 10000*d2 + 1000*d3 + 100*d4 + 10*d5 + d6;
    //
    dd6 = (oct_a / 100000);
    dd5 = (oct_a / 10000) % 10;
    dd4 = (oct_a / 1000) % 10;
    dd3 = (oct_a / 100) % 10;
    dd2 = (oct_a / 10) % 10;
    dd1 = oct_a % 10;
    oct_b = 100000*dd1 + 10000*dd2 + 1000*dd3 + 100*dd4 + 10*dd5 + dd6;
    //make sure the digit doesn't replace an unwanted zero place
    if(oct_a < 100000 && oct_a >= 10000){
        oct_b = oct_b / 10;
    }
    if(oct_a < 10000 && oct_a >= 1000){
        oct_b = oct_b / 100;
    }
    if(oct_a < 1000 && oct_a >= 100){
        oct_b = oct_b / 1000;
    }
    if(oct_a < 100 && oct_a >= 10){
        oct_b = oct_b / 10000;
    }
    if(oct_a < 10 && oct_a >= 0){
        oct_b = oct_a;
    }
    //extract digit from oct_b
    fd1 = oct_b / 100000;
    fd2 = (oct_b / 10000) % 10;
    fd3 = (oct_b / 1000) % 10;
    fd4 = (oct_b / 100) % 10;
    fd5 = (oct_b / 10) % 10;
    fd6 = oct_b % 10;
    after = 8*8*8*8*8*fd1+ 8*8*8*8*fd2 + 8*8*8*fd3 + 8*8*fd4 + 8*fd5 + fd6;
    printf("Before Flip:\n");
    printf("%d_10 = %d_8\n", before, oct_a);

    printf("After Flip:\n");
    printf("%d_8 = %d_10\n", oct_b, after);
    return 0;
}