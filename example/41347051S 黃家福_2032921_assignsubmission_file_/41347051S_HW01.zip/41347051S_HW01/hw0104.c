#include <stdio.h>
#include <stdint.h>
//raw number
uint32_t a, b, c, d, e;
//value
uint32_t aa, bb, cc, dd, ee;
//rank
uint32_t aa1, bb1 ,cc1, dd1, ee1;
uint32_t input, similarity;
int main(){
    printf("Please enter 5 cards: ");
    input = scanf("%d %d %d %d %d", &a, &b, &c, &d, &e);
    if(input != 5){
        printf("Invalid input! Inputs have to be an integer\n");
        return 1;
    }
    if(a < 1 || a > 52 || b < 1 || b > 52 || c < 1 || c > 52 || d < 1 || d > 52 || e < 1 || e > 52 ||
    a == b || a == c || a == d || a == e || b == c || b == d || b == e || c == d || c == e || d == e){
        printf("Input must be within 1-52 and should not have the same encoded number\n");
        return 1;
    }
    
    //card value
    aa = a % 13;
    if(aa == 0){
        aa += 13;
    }
    bb = b % 13;
    if(bb == 0){
        bb += 13;
    }
    cc = c % 13;
    if(cc == 0){
        cc += 13;
    }
    dd = d % 13;
    if(dd == 0){
        dd += 13;
    }
    ee = e % 13;
    if(ee == 0){
        ee += 13;
    }
    //card type
    aa1 = (a - 1)/13;
    bb1 = (b - 1)/13;
    cc1 = (c - 1)/13;
    dd1 = (d - 1)/13;
    ee1 = (e - 1)/13;
    //flush / straight flush checker, all same rank, consequetive number sum cant exceed any of the number times 5 plus 11
    if(aa1 == bb1 && aa1 == cc1 && aa1 == dd1 && aa1 == ee1){
        if((aa + bb + cc + dd + ee) < (5*aa + 11) && (aa + bb + cc + dd + ee) < (5*bb + 11) &&
         (aa + bb + cc + dd + ee) < (5*cc + 11) && (aa + bb + cc + dd + ee) < (5*dd + 11) && (aa + bb + cc + dd + ee) < (5*ee + 11)){
            printf("Straight Flush\n");
         }
         else printf("Flush\n");
    }
    // straight checker, make sure no overlapping value
    else if((aa + bb + cc + dd + ee) < (5*aa + 11) && (aa + bb + cc + dd + ee) < (5*bb + 11) &&
         (aa + bb + cc + dd + ee) < (5*cc + 11) && (aa + bb + cc + dd + ee) < (5*dd + 11) && (aa + bb + cc + dd + ee) < (5*ee + 11) &&
         (aa != bb && aa != cc && aa != dd && aa != ee && bb != cc && bb != dd &&
             bb != ee && cc != dd && cc != ee && dd != ee)
         ){
            if(aa1 != bb1 || aa1 != cc1 || aa1 != dd1 || aa1 != ee1 || bb1 != cc1 || bb1 != dd1 ||
             bb1 != ee1 || cc1 != dd1 || cc1 != ee1 || dd1 != ee1){
                printf("Straight\n");
            }
         }
    // same value categorizer, using mathematical combinnation we can categorize each "amount of same value"
    else if(aa == bb || aa == cc || aa == dd || aa == ee || bb == cc || bb == dd ||
             bb == ee || cc == dd || cc == ee || dd == ee){
        similarity = (aa == bb) + (aa == cc) + (aa == dd) + (aa == ee) + (bb == cc) + (bb == dd) + (bb == ee) + (cc == dd) + (cc == ee) + (dd == ee);
        if(similarity == 6){
            printf("Four of a Kind\n");
        }else if(similarity == 4){
            printf("Full House\n");
        }else if(similarity == 3){
            printf("Three of a Kind\n");
        }else if(similarity == 2){
            printf("Two Pair\n");
        }else if(similarity == 1){
            printf("One Pair\n");
        }
        }
    else{
        printf("High Card\n");
    }
    return 0;
}