# include <stdio.h>
# include <stdint.h>

int main(){
    int32_t num= -1;
    int32_t a= -1;
    int32_t mode= -1;
    int32_t num_2_0= 0;
    int32_t num_2_1= 0;
    int32_t num_2_2= 0;
    int32_t num_2_3= 0;
    int32_t num_2_4= 0;
    int32_t num_2_5= 0;
    int32_t num_2_6= 0;
    int32_t num_2_7= 0;
    int32_t num_2_8= 0;
    int32_t num_2_9= 0;
    int32_t num_2_10= 0;
    int32_t num_2_11= 0;
    int32_t num_2_12= 0;
    int32_t num_2_13= 0;
    int32_t num_2_14= 0;
    int32_t num_2_15= 0;
    char c;
    printf("Please input a hex:");
    scanf("%X", &num);
    scanf("%c", &c);
    printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
    scanf("%d", &mode);
    if (num==-1 || mode>3 || mode <1){
        printf ("Wrong input!");
        return 0;
    }
    a= num;
    if (a){
        num_2_0= a%2;
        a/= 2;
    }
    if (a){
        num_2_1= a%2;
        a/= 2;
    }
    if (a){
        num_2_2= a%2;
        a/= 2;
    }
    if (a){
        num_2_3= a%2;
        a/= 2;
    }
    if (a){
        num_2_4= a%2;
        a/= 2;
    }
    if (a){
        num_2_5= a%2;
        a/= 2;
    }
    if (a){
        num_2_6= a%2;
        a/= 2;
    }
    if (a){
        num_2_7= a%2;
        a/= 2;
    }
    if (a){
        num_2_8= a%2;
        a/= 2;
    }
    if (a){
        num_2_9= a%2;
        a/= 2;
    }
    if (a){
        num_2_10= a%2;
        a/= 2;
    }
    if (a){
        num_2_11= a%2;
        a/= 2;
    }
    if (a){
        num_2_12= a%2;
        a/= 2;
    }
    if (a){
        num_2_13= a%2;
        a/= 2;
    }
    if (a){
        num_2_14= a%2;
        a/= 2;
    }
    if (a){
        num_2_15= a%2;
        a/= 2;
    }
    printf ("Binary of %X is: ", num);
    printf ("%d", num_2_15);
    printf ("%d", num_2_14);
    printf ("%d", num_2_13);
    printf ("%d", num_2_12);
    printf (" ");
    printf ("%d", num_2_11);
    printf ("%d", num_2_10);
    printf ("%d", num_2_9);
    printf ("%d", num_2_8);
    printf (" ");
    printf ("%d", num_2_7);
    printf ("%d", num_2_6);
    printf ("%d", num_2_5);
    printf ("%d", num_2_4);
    printf (" ");
    printf ("%d", num_2_3);
    printf ("%d", num_2_2);
    printf ("%d", num_2_1);
    printf ("%d", num_2_0);
    printf ("\n");

    if (mode==1){
        printf ("Converted integer is: ");
        num%= 32768;
        
        if (num_2_15){
            printf ("-");
            num= 32768-num;
            printf ("%d\n", num);
        }else{
            printf ("%d\n", num);
        }
        
    }else if (mode==2){
        printf ("Converted unsigned integer is: ");
        printf ("%d\n", num);
    }else{
        printf ("Converted float is: ");
        if (num_2_15) printf ("-");

        int32_t EXP= num_2_14*16 + num_2_13*8 + num_2_12*4 + num_2_11*2 + num_2_10;
        double F= num_2_9*0.5 + num_2_8*0.25 + num_2_7*0.125 + num_2_6*0.0625 + num_2_5*0.03125 + num_2_4*0.015625 + num_2_3*0.0078125 + num_2_2*0.00390625 + num_2_1*0.001953125 + num_2_0*0.0009765625;
        if (F==0){
            if (EXP==31){
                if (!num_2_15) printf ("+");
                printf ("INF\n");
            }else{
                if (!num_2_15) printf ("+");
                printf ("0.0\n");
            }
        }else if (EXP==31){
            printf ("NAN\n");
        }else{
            EXP-= 15;
            printf ("%lf*2^%d\n", 1+F, EXP);
        }
    }
}