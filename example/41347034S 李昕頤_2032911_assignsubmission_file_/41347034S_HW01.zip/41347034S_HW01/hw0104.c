# include <stdio.h>
# include <stdint.h>

int main(){
    int32_t c1= -1;
    int32_t c2= -1;
    int32_t c3= -1;
    int32_t c4= -1;
    int32_t c5= -1;
    int32_t cards_1= 5;
    int32_t cards_2= 0;
    int32_t cards_3= 0;
    int32_t cards_4= 0;
    int32_t num_1= 0;
    int32_t num_2= 0;
    int32_t num_3= 0;
    int32_t num_4= 0;
    int32_t num_5= 0;
    int32_t num_6= 0;
    int32_t num_7= 0;
    int32_t num_8= 0;
    int32_t num_9= 0;
    int32_t num_10= 0;
    int32_t num_11= 0;
    int32_t num_12= 0;
    int32_t num_13= 0;
    int32_t color_0= 0;
    int32_t color_1= 0;
    int32_t color_2= 0;
    int32_t color_3= 0;
    int32_t a= 0;
    printf ("Please enter 5 cards: ");
    scanf ("%d %d %d %d %d", &c1, &c2, &c3, &c4, &c5);

    if (c1<1 || c1>52){
        printf ("Wrong input!\n");
        return 0;
    }else if (c2<1 || c2>52){
        printf ("Wrong input!\n");
        return 0;
    }else if (c3<1 || c3>52){
        printf ("Wrong input!\n");
        return 0;
    }else if (c4<1 || c4>52){
        printf ("Wrong input!\n");
        return 0;
    }else if (c5<1 || c5>52){
        printf ("Wrong input!\n");
        return 0;
    }else if (c1==c2 || c1==c2 || c1==c3 || c1==c4 || c1==c5 || c2==c3 || c2==c4 || c2==c5 || c3==c4 || c3==c5 || c4==c5){
        printf ("Wrong input!\n");
        return 0;
    }
    // num
    switch ((c1-1)%13){
        case 0:
            num_1++;
            break;
        case 1:
            num_2++;
            break;
        case 2:
            num_3++;
            break;
        case 3:
            num_4++;
            break;
        case 4:
            num_5++;
            break;
        case 5:
            num_6++;
            break;
        case 6:
            num_7++;
            break;
        case 7:
            num_8++;
            break;
        case 8:
            num_9++;
            break;
        case 9:
            num_10++;
            break;
        case 10:
            num_11++;
            break;
        case 11:
            num_12++;
            break;
        case 12:
            num_13++;
            break;
    }
    switch ((c2-1)%13){
        case 0:
            num_1++;
            if (num_1==2){
                cards_1--;
                cards_2++;
            }
            break;
        case 1:
            num_2++;
            if (num_2==2){
                cards_1--;
                cards_2++;
            }
            break;
        case 2:
            num_3++;
            if (num_3==2){
                cards_1--;
                cards_2++;
            }
            break;
        case 3:
            num_4++;
            if (num_4==2){
                cards_1--;
                cards_2++;
            }
            break;
        case 4:
            num_5++;
            if (num_5==2){
                cards_1--;
                cards_2++;
            }
            break;
        case 5:
            num_6++;
            if (num_6==2){
                cards_1--;
                cards_2++;
            }
            break;
        case 6:
            num_7++;
            if (num_7==2){
                cards_1--;
                cards_2++;
            }
            break;
        case 7:
            num_8++;
            if (num_8==2){
                cards_1--;
                cards_2++;
            }
            break;
        case 8:
            num_9++;
            if (num_9==2){
                cards_1--;
                cards_2++;
            }
            break;
        case 9:
            num_10++;
            if (num_10==2){
                cards_1--;
                cards_2++;
            }
            break;
        case 10:
            num_11++;
            if (num_11==2){
                cards_1--;
                cards_2++;
            }
            break;
        case 11:
            num_12++;
            if (num_12==2){
                cards_1--;
                cards_2++;
            }
            break;
        case 12:
            num_13++;
            if (num_13==2){
                cards_1--;
                cards_2++;
            }
            break;
    }
    switch ((c3-1)%13){
        case 0:
            num_1++;
            if (num_1==2){
                cards_1--;
                cards_2++;
            }else if (num_1==3){
                cards_2--;
                cards_3++;
            }
            break;
        case 1:
            num_2++;
            if (num_2==2){
                cards_1--;
                cards_2++;
            }else if (num_2==3){
                cards_2--;
                cards_3++;
            }
            break;
        case 2:
            num_3++;
            if (num_3==2){
                cards_1--;
                cards_2++;
            }else if (num_3==3){
                cards_2--;
                cards_3++;
            }
            break;
        case 3:
            num_4++;
            if (num_4==2){
                cards_1--;
                cards_2++;
            }else if (num_4==3){
                cards_2--;
                cards_3++;
            }
            break;
        case 4:
            num_5++;
            if (num_5==2){
                cards_1--;
                cards_2++;
            }else if (num_5==3){
                cards_2--;
                cards_3++;
            }
            break;
        case 5:
            num_6++;
            if (num_6==2){
                cards_1--;
                cards_2++;
            }else if (num_6==3){
                cards_2--;
                cards_3++;
            }
            break;
        case 6:
            num_7++;
            if (num_7==2){
                cards_1--;
                cards_2++;
            }else if (num_7==3){
                cards_2--;
                cards_3++;
            }
            break;
        case 7:
            num_8++;
            if (num_8==2){
                cards_1--;
                cards_2++;
            }else if (num_8==3){
                cards_2--;
                cards_3++;
            }
            break;
        case 8:
            num_9++;
            if (num_9==2){
                cards_1--;
                cards_2++;
            }else if (num_9==3){
                cards_2--;
                cards_3++;
            }
            break;
        case 9:
            num_10++;
            if (num_10==2){
                cards_1--;
                cards_2++;
            }else if (num_10==3){
                cards_2--;
                cards_3++;
            }
            break;
        case 10:
            num_11++;
            if (num_11==2){
                cards_1--;
                cards_2++;
            }else if (num_11==3){
                cards_2--;
                cards_3++;
            }
            break;
        case 11:
            num_12++;
            if (num_12==2){
                cards_1--;
                cards_2++;
            }else if (num_12==3){
                cards_2--;
                cards_3++;
            }
            break;
        case 12:
            num_13++;
            if (num_13==2){
                cards_1--;
                cards_2++;
            }else if (num_13==3){
                cards_2--;
                cards_3++;
            }
            break;
    }
    switch ((c4-1)%13){
        case 0:
            num_1++;
            if (num_1==2){
                cards_1--;
                cards_2++;
            }else if (num_1==3){
                cards_2--;
                cards_3++;
            }else if (num_1==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 1:
            num_2++;
            if (num_2==2){
                cards_1--;
                cards_2++;
            }else if (num_2==3){
                cards_2--;
                cards_3++;
            }else if (num_2==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 2:
            num_3++;
            if (num_3==2){
                cards_1--;
                cards_2++;
            }else if (num_3==3){
                cards_2--;
                cards_3++;
            }else if (num_3==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 3:
            num_4++;
            if (num_4==2){
                cards_1--;
                cards_2++;
            }else if (num_4==3){
                cards_2--;
                cards_3++;
            }else if (num_4==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 4:
            num_5++;
            if (num_5==2){
                cards_1--;
                cards_2++;
            }else if (num_5==3){
                cards_2--;
                cards_3++;
            }else if (num_5==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 5:
            num_6++;
            if (num_6==2){
                cards_1--;
                cards_2++;
            }else if (num_6==3){
                cards_2--;
                cards_3++;
            }else if (num_6==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 6:
            num_7++;
            if (num_7==2){
                cards_1--;
                cards_2++;
            }else if (num_7==3){
                cards_2--;
                cards_3++;
            }else if (num_7==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 7:
            num_8++;
            if (num_8==2){
                cards_1--;
                cards_2++;
            }else if (num_8==3){
                cards_2--;
                cards_3++;
            }else if (num_8==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 8:
            num_9++;
            if (num_9==2){
                cards_1--;
                cards_2++;
            }else if (num_9==3){
                cards_2--;
                cards_3++;
            }else if (num_9==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 9:
            num_10++;
            if (num_10==2){
                cards_1--;
                cards_2++;
            }else if (num_10==3){
                cards_2--;
                cards_3++;
            }else if (num_10==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 10:
            num_11++;
            if (num_11==2){
                cards_1--;
                cards_2++;
            }else if (num_11==3){
                cards_2--;
                cards_3++;
            }else if (num_11==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 11:
            num_12++;
            if (num_12==2){
                cards_1--;
                cards_2++;
            }else if (num_12==3){
                cards_2--;
                cards_3++;
            }else if (num_12==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 12:
            num_13++;
            if (num_13==2){
                cards_1--;
                cards_2++;
            }else if (num_13==3){
                cards_2--;
                cards_3++;
            }else if (num_13==4){
                cards_3--;
                cards_4++;
            }
            break;
    }
    switch ((c5-1)%13){
        case 0:
            num_1++;
            if (num_1==2){
                cards_1--;
                cards_2++;
            }else if (num_1==3){
                cards_2--;
                cards_3++;
            }else if (num_1==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 1:
            num_2++;
            if (num_2==2){
                cards_1--;
                cards_2++;
            }else if (num_2==3){
                cards_2--;
                cards_3++;
            }else if (num_2==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 2:
            num_3++;
            if (num_3==2){
                cards_1--;
                cards_2++;
            }else if (num_3==3){
                cards_2--;
                cards_3++;
            }else if (num_3==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 3:
            num_4++;
            if (num_4==2){
                cards_1--;
                cards_2++;
            }else if (num_4==3){
                cards_2--;
                cards_3++;
            }else if (num_4==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 4:
            num_5++;
            if (num_5==2){
                cards_1--;
                cards_2++;
            }else if (num_5==3){
                cards_2--;
                cards_3++;
            }else if (num_5==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 5:
            num_6++;
            if (num_6==2){
                cards_1--;
                cards_2++;
            }else if (num_6==3){
                cards_2--;
                cards_3++;
            }else if (num_6==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 6:
            num_7++;
            if (num_7==2){
                cards_1--;
                cards_2++;
            }else if (num_7==3){
                cards_2--;
                cards_3++;
            }else if (num_7==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 7:
            num_8++;
            if (num_8==2){
                cards_1--;
                cards_2++;
            }else if (num_8==3){
                cards_2--;
                cards_3++;
            }else if (num_8==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 8:
            num_9++;
            if (num_9==2){
                cards_1--;
                cards_2++;
            }else if (num_9==3){
                cards_2--;
                cards_3++;
            }else if (num_9==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 9:
            num_10++;
            if (num_10==2){
                cards_1--;
                cards_2++;
            }else if (num_10==3){
                cards_2--;
                cards_3++;
            }else if (num_10==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 10:
            num_11++;
            if (num_11==2){
                cards_1--;
                cards_2++;
            }else if (num_11==3){
                cards_2--;
                cards_3++;
            }else if (num_11==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 11:
            num_12++;
            if (num_12==2){
                cards_1--;
                cards_2++;
            }else if (num_12==3){
                cards_2--;
                cards_3++;
            }else if (num_12==4){
                cards_3--;
                cards_4++;
            }
            break;
        case 12:
            num_13++;
            if (num_13==2){
                cards_1--;
                cards_2++;
            }else if (num_13==3){
                cards_2--;
                cards_3++;
            }else if (num_13==4){
                cards_3--;
                cards_4++;
            }
            break;
    }
    // color
    switch ((c1-1)/13){
        case 0:
            color_0++;
            break;
        case 1:
            color_1++;
            break;
        case 2:
            color_2++;
            break;
        case 3:
            color_3++;
            break;
    }
    switch ((c2-1)/13){
        case 0:
            color_0++;
            break;
        case 1:
            color_1++;
            break;
        case 2:
            color_2++;
            break;
        case 3:
            color_3++;
            break;
    }
    switch ((c3-1)/13){
        case 0:
            color_0++;
            break;
        case 1:
            color_1++;
            break;
        case 2:
            color_2++;
            break;
        case 3:
            color_3++;
            break;
    }
    switch ((c4-1)/13){
        case 0:
            color_0++;
            break;
        case 1:
            color_1++;
            break;
        case 2:
            color_2++;
            break;
        case 3:
            color_3++;
            break;
    }
    switch ((c5-1)/13){
        case 0:
            color_0++;
            break;
        case 1:
            color_1++;
            break;
        case 2:
            color_2++;
            break;
        case 3:
            color_3++;
            break;
    }

    if (cards_4){
        printf ("Four of a kind");
    }else if (cards_3){
        if (cards_2){
            printf ("Full house");
        }else{
            printf ("Three of a kind");
        }
    }else if (cards_2){
        if (cards_2==1){
            printf ("One pair");
        }else{
            printf ("Two pair");
        }
    }else{
        a= 0;
        if (num_1==1 && num_2==1 && num_3==1 && num_4==1 && num_5==1) a= 1;
        if (num_2==1 && num_3==1 && num_4==1 && num_5==1 && num_6==1) a= 1;
        if (num_3==1 && num_4==1 && num_5==1 && num_6==1 && num_7==1) a= 1;
        if (num_4==1 && num_5==1 && num_6==1 && num_7==1 && num_8==1) a= 1;
        if (num_5==1 && num_6==1 && num_7==1 && num_8==1 && num_9==1) a= 1;
        if (num_6==1 && num_7==1 && num_8==1 && num_9==1 && num_10==1) a= 1;
        if (num_7==1 && num_8==1 && num_9==1 && num_10==1 && num_11==1) a= 1;
        if (num_8==1 && num_9==1 && num_10==1 && num_11==1 && num_12==1) a= 1;
        if (num_9==1 && num_10==1 && num_11==1 && num_12==1 && num_13==1) a= 1;
        if (num_10==1 && num_11==1 && num_12==1 && num_13==1 && num_1==1) a= 1;
        if (a){
            if (color_0==5 || color_1==5 || color_2==5 || color_3==5){
                printf ("Straight Flush");
            }else{
                printf ("Straight");
            }
        }else{
            if (color_0==5 || color_1==5 || color_2==5 || color_3==5){
                printf ("Flush");
            }else{
                printf ("High card");
            }
        }
    }
    printf ("\n");

}