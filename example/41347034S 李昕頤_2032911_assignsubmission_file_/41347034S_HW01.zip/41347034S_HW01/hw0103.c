# include <stdio.h>
# include <stdint.h>

int main(){
    int32_t num_10= 0;
    int32_t num;

    printf ("Please enter an unsigned 16-bits number: ");
    scanf ("%d", &num_10);

    // 8
    int32_t num_8_0= 0;
    int32_t num_8_1= 0;
    int32_t num_8_2= 0;
    int32_t num_8_3= 0;
    int32_t num_8_4= 0;
    int32_t num_8_5= 0;
    int32_t l_8= 0;
    num= num_10;

    if (num>0){
        num_8_0= num%8;
        num/= 8;
    }
    if (num>0){
        l_8++;
        num_8_1= num%8;
        num/= 8;
    }
    if (num>0){
        l_8++;
        num_8_2= num%8;
        num/= 8;
    }
    if (num>0){
        l_8++;
        num_8_3= num%8;
        num/= 8;
    }
    if (num>0){
        l_8++;
        num_8_4= num%8;
        num/= 8;
    }
    if (num>0){
        l_8++;
        num_8_5= num%8;
        num/= 8;
    }
    printf ("Before Flip:\n");
    printf ("%d_10 = ", num_10);
    switch (l_8){
        case 5:
            printf ("%d", num_8_5);
        case 4:
            printf ("%d", num_8_4);
        case 3:
            printf ("%d", num_8_3);
        case 2:
            printf ("%d", num_8_2);
        case 1:
            printf ("%d", num_8_1);
        default:
            printf ("%d", num_8_0);
    }
    printf ("_8\n");

    // flip
    printf ("After Flip:\n");
    num= 0;
    switch (l_8){
        case 5:
            printf ("%d%d%d%d%d%d_8 = ", num_8_0, num_8_1, num_8_2, num_8_3, num_8_4, num_8_5);
            num+= num_8_0;
            num*= 8;
            num+= num_8_1;
            num*= 8;
            num+= num_8_2;
            num*= 8;
            num+= num_8_3;
            num*= 8;
            num+= num_8_4;
            num*= 8;
            num+= num_8_5;
            break;
        case 4:
            printf ("%d%d%d%d%d_8 = ", num_8_0, num_8_1, num_8_2, num_8_3, num_8_4);
            num+= num_8_0;
            num*= 8;
            num+= num_8_1;
            num*= 8;
            num+= num_8_2;
            num*= 8;
            num+= num_8_3;
            num*= 8;
            num+= num_8_4;
            break;
        case 3:
            printf ("%d%d%d%d_8 = ", num_8_0, num_8_1, num_8_2, num_8_3);
            num+= num_8_0;
            num*= 8;
            num+= num_8_1;
            num*= 8;
            num+= num_8_2;
            num*= 8;
            num+= num_8_3;
            break;
        case 2:
            printf ("%d%d%d_8 = ", num_8_0, num_8_1, num_8_2);
            num+= num_8_0;
            num*= 8;
            num+= num_8_1;
            num*= 8;
            num+= num_8_2;
            break;
        case 1:
            printf ("%d%d_8 = ", num_8_0, num_8_1);
            num+= num_8_0;
            num*= 8;
            num+= num_8_1;
            break;
        default:
            printf ("%d_8", num_8_0);
            num+= num_8_0;
            break;
    }

    printf ("%d_10\n", num);
}