# include <stdio.h>
# include <stdint.h>

int main(){
    char c= ' ';
    char c1, c2, c3;
    int32_t num1_1= -1;
    int32_t num1_3= -1;
    int32_t num2_2= -1;
    int32_t ans= -1;
    int32_t ansmin= -1;
    int32_t ansmax= -1;
    int32_t x= 0;
    int32_t y= 0;
    int32_t z= 0;

    printf ("Please enter the first  operand: ");
    scanf ("%d%c%d" ,&num1_1, &c1, &num1_3);
    // fflush(stdin);
// printf ("%d , %c , %d\n", num1_1, c1, num1_3);
    printf ("Please enter the second operand: ");
    scanf ("%c" ,&c);
    scanf ("%c%d%c" ,&c2, &num2_2, &c3);
    // fflush(stdin);
// printf ("%c , %d , %c\n", c2, num2_2, c3);
    printf ("Please enter the sum           : ");
    scanf ("%c" ,&c);
    scanf ("%d", &ans);
    scanf ("%c" ,&c);
    fflush(stdin);
    ansmin= num1_1*100 + num2_2*10 + num1_3;
    ansmax= ansmin + 999;
// printf ("%d\n", ans);
    
    if (num1_1==-1 || num1_3==-1 || num2_2==-1 || ans==-1){
        printf ("Wrong input!\n");
        return 0;
    }
    if (num1_1>9 || num1_3>9 || num2_2>9){
        printf ("Wrong input!\n");
        return 0;
    }
    if (ans<ansmin || ans>ansmax){
        printf ("It's not a legal calculation!\n");
        return 0;
    }

    y= ans/100 - num1_1;
    x= (ans/10)%10 - num2_2;
    z= ans%10 - num1_3;
    if (z<0){
        x--;
        z+= 10;
    }
    if (x<0){
        y--;
        x+= 10;
    }
    printf ("Ans: x = %d, y = %d, z = %d\n", x, y, z);
}