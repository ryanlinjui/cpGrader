# HW01_README

> 系級：資工117
> 學號：41347034S
> 姓名：李昕頤

## Makefile
執行```make```後，會將程式都處理成可執行檔案

## hw01
- 執行程式後，無須輸入，會直接輸出
- 人名會跟著歌詞一起變色
- 最後一行歌詞末，會換行

## hw02
- 執行程式後，將輸出提示，每行最後都有一個空格：
    ```
    Please enter the first  operand: 
    Please enter the second operand: 
    Please enter the sum           : 
    ```
- 輸入格式：直接輸入數值或文字，請不要輸入無意義空格
- 若輸入含有非正整數或非個位數，將輸出「Wrong input!」並結束程式
- 若輸入不合法運算，將輸出「It's not a legal calculation!」並結束程式

## hw03
- 執行程式後，將輸出提示，每行最後都有一個空格：
    ```
    Please enter an unsigned 16-bits number: 
    ```
- 輸入格式：直接輸入數值或文字，請不要輸入無意義空格

## hw04
- 執行程式後，將輸出提示，每行最後都有一個空格：
    ```
    Please enter 5 cards: 
    ```
- 輸入格式：直接輸入數值，數字間以空白隔開
- 若輸入不符合一副牌的規則，將輸出「Wrong input!」並結束程式

## hw05
- 執行程式後，將輸出提示，每行最後都沒有空格（因為題目範例中沒有）：
    ```
    Please input a hex:
    Please choose the output type(1:integer ,2:unsigned integer ,3:float):
    ```
- 輸入格式：直接輸入數值或文字
- 輸入 outout type 時，若輸入非1、2、3，將輸出「Wrong input!」並結束程式

## hw06
- 為一個PDF檔