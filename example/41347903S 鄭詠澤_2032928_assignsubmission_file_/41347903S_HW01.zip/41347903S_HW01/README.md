# Student ID & Name

- student ID: 41347903S
- Name: 鄭詠澤

# How to build the code

```
make
```

# How to execute the code

```
./hw0101
./hw0102
./hw0103
./hw0104
./hw0105
```

然後照著題目內給的格式輸入就可以了