#include <stdio.h>

int main()
{
    unsigned short hex_input;
    int choice, i, temp;
    int sign_bit, exponent, mantissa;
    int integer_result;
    unsigned int unsigned_result;
    float float_result;

    // Input hex number
    printf("Please input a hex:");
    scanf("%hx", &hex_input);

    // Input conversion choice
    printf("Please choose the output type(1:integer, 2:unsigned integer, 3:float):");
    scanf("%d", &choice);

    // Print binary representation
    printf("Binary of %04X is: ", hex_input);
    temp = hex_input;
    i = 15;
    while (i >= 0) {
        // Extract each bit using division by 2^15 (32768)
        printf("%d", temp / 32768);
        temp = temp % 32768;
        temp *= 2;
        // Add space every 4 bits for readability
        if (i % 4 == 0 && i != 0) {
            printf(" ");
        }
        i--;
    }
    printf("\n");

    // Convert based on user's choice
    if (choice == 1) {
        // Signed integer conversion
        if (hex_input >= 32768) {
            // If the number is negative (first bit is 1)
            integer_result = (int) hex_input - 65536;
        } else {
            // If the number is positive
            integer_result = hex_input;
        }
        printf("Converted integer is: %d\n", integer_result);
    } else if (choice == 2) {
        // Unsigned integer conversion (no change needed)
        unsigned_result = hex_input;
        printf("Converted unsigned integer is: %u\n", unsigned_result);
    } else if (choice == 3) {
        // Float conversion
        // Extract sign bit (first bit)
        sign_bit = hex_input / 32768;
        // Extract exponent (next 5 bits)
        exponent = (hex_input % 32768) / 1024 - 15;
        // Extract mantissa (last 10 bits)
        mantissa = hex_input % 1024;

        // Handle special cases
        if (exponent == -15 && mantissa == 0) {
            // +0 or -0
            printf("Converted float is: %c0.0\n", sign_bit ? '-' : '+');
        } else if (exponent == 16 && mantissa == 0) {
            // +INF or -INF
            printf("Converted float is: %cINF\n", sign_bit ? '-' : '+');
        } else if (exponent == 16 && mantissa != 0) {
            // NAN
            printf("Converted float is: NAN\n");
        } else {
            // Normal float
            float_result = 1.0 + (float) mantissa / 1024.0;
            if (sign_bit) {
                float_result = -float_result;
            }
            // Print float in scientific notation
            printf("Converted float is: %f*2^%d\n", float_result, exponent);
        }
    }

    return 0;
}