#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char operand1[10], operand2[10];
    int sum;

    // Take input
    printf("Please enter the first  operand: ");
    scanf("%s", operand1);

    // Validate the first operand
    if (!(strlen(operand1) == 3 && isdigit(operand1[0]) && operand1[1] == 'x' &&
          isdigit(operand1[2]))) {
        printf("Invalid input format for the first operand.\n");
        return 1;
    }

    printf("Please enter the second operand: ");
    scanf("%s", operand2);
    // Validate the second operand
    if (!(strlen(operand2) == 3 && operand2[0] == 'y' && isdigit(operand2[1]) &&
          operand2[2] == 'z')) {
        printf("Invalid input format for the second operand.\n");
        return 1;
    }

    printf("Please enter the sum           : ");
    scanf("%d", &sum);

    // Extract integers from characters
    int a = operand1[0] - '0';  // First digit of first operand
    int c = operand1[2] - '0';  // Third digit of first operand
    int b = operand2[1] - '0';  // Middle digit of second operand

    // Solve for x, y, z
    int x, y, z;
    bool solution_found = false;

    x = 0;
    while (x <= 9 && !solution_found) {
        y = 0;
        while (y <= 9 && !solution_found) {
            z = 0;
            while (z <= 9 && !solution_found) {
                int num1 = a * 100 + x * 10 + c;
                int num2 = y * 100 + b * 10 + z;
                if (num1 + num2 == sum) {
                    printf("Ans: x = %d, y = %d, z = %d\n", x, y, z);
                    solution_found = true;
                } else {
                    z++;
                }
            }
            if (!solution_found) {
                y++;
            }
        }
        if (!solution_found) {
            x++;
        }
    }

    if (!solution_found) {
        printf("No solution found.\n");
    }

    return 0;
}