#include <stdio.h>

#define MAX_OCTAL_DIGITS 6  // Maximum number of octal digits for a 16-bit number

int main()
{
    unsigned short input;

    printf("Please enter an unsigned 16-bits number: ");
    scanf("%hu", &input);

    printf("Before Flip:\n");
    printf("%u_10 = %o_8\n", input, input);

    // Convert to octal string
    int i = 0;
    char octal[MAX_OCTAL_DIGITS + 1];
    unsigned short temp = input;
    octal[i++] = (temp % 8) + '0';
    temp /= 8;

    while (temp > 0) {
        octal[i++] = (temp % 8) + '0';
        temp /= 8;
    }

    // convert it back to unsigned short
    const int len = i;
    i = 0;
    unsigned short flipped = 0;
    while (i < len) {
        flipped = flipped * 8 + (octal[i] - '0');
        i++;
    }

    printf("After  Flip:\n");
    printf("%o_8 = %u_10\n", flipped, flipped);

    return 0;
}