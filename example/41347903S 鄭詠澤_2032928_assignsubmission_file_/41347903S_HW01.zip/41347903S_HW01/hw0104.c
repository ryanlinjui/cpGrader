/**
 * |    | Ace | 2  | 3  | 4  | 5  | 6  | 7  | 8  | 9  | 10 | Jack | Queen | King |
 * |----|-----|----|----|----|----|----|----|----|----|----|------|-------|------|
 * | ♠  |  1  |  2 |  3 |  4 |  5 |  6 |  7 |  8 |  9 | 10 |  11  |   12  |  13  |
 * | ♡  |  14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 |  24  |   25  |  26  |
 * | ♢  |  27 | 28 | 29 | 30 | 31 | 32 | 33 | 34 | 35 | 36 |  37  |   38  |  39  |
 * | ♣  |  40 | 41 | 42 | 43 | 44 | 45 | 46 | 47 | 48 | 49 |  50  |   51  |  52  |
 */

#include <stdio.h>

// Define constants and macros
#define HAND_SIZE 5
#define GET_RANK(card) (((card) - 1) % 13 + 1)
#define GET_SUIT(card) (((card) - 1) / 13)

int main()
{
    int hand[HAND_SIZE];
    int i = 0, j, temp;
    int is_flush = 1, is_straight = 0, is_four_of_a_kind = 0, is_full_house = 0;
    int is_three_of_a_kind = 0, is_two_pair = 0, is_one_pair = 0;

    // Input the hand
    printf("Enter 5 card values (1-52): ");
    while (i < HAND_SIZE) {
        scanf("%d", &hand[i]);
        i++;
    }

    // Sort the hand in descending order of rank
    i = 0;
    while (i < HAND_SIZE - 1) {
        j = 0;
        while (j < HAND_SIZE - i - 1) {
            if (GET_RANK(hand[j]) < GET_RANK(hand[j + 1])) {
                temp = hand[j];
                hand[j] = hand[j + 1];
                hand[j + 1] = temp;
            }
            j++;
        }
        i++;
    }

    // Check for flush (all cards of the same suit)
    int suit = GET_SUIT(hand[0]);
    i = 1;
    while (i < HAND_SIZE && is_flush) {
        if (GET_SUIT(hand[i]) != suit) {
            is_flush = 0;
        }
        i++;
    }

    // Check for straight
    is_straight = 1;
    i = 1;
    // Check for regular straight
    while (i < HAND_SIZE && is_straight) {
        if (GET_RANK(hand[i - 1]) != GET_RANK(hand[i]) + 1) {
            is_straight = 0;
        }
        i++;
    }

    // Check for Ace-high straight (10, J, Q, K, A)
    if (!is_straight && GET_RANK(hand[0]) == 13 && GET_RANK(hand[1]) == 12 &&
        GET_RANK(hand[2]) == 11 && GET_RANK(hand[3]) == 10 &&
        GET_RANK(hand[4]) == 1) {
        is_straight = 1;
    }

    // Check for four of a kind, full house, three of a kind, two pair, and one
    // pair
    if (GET_RANK(hand[0]) == GET_RANK(hand[3]) ||
        GET_RANK(hand[1]) == GET_RANK(hand[4])) {
        is_four_of_a_kind = 1;
    } else if ((GET_RANK(hand[0]) == GET_RANK(hand[2]) &&
                GET_RANK(hand[3]) == GET_RANK(hand[4])) ||
               (GET_RANK(hand[0]) == GET_RANK(hand[1]) &&
                GET_RANK(hand[2]) == GET_RANK(hand[4]))) {
        is_full_house = 1;
    } else if (GET_RANK(hand[0]) == GET_RANK(hand[2]) ||
               GET_RANK(hand[1]) == GET_RANK(hand[3]) ||
               GET_RANK(hand[2]) == GET_RANK(hand[4])) {
        is_three_of_a_kind = 1;
    } else if ((GET_RANK(hand[0]) == GET_RANK(hand[1]) &&
                GET_RANK(hand[2]) == GET_RANK(hand[3])) ||
               (GET_RANK(hand[0]) == GET_RANK(hand[1]) &&
                GET_RANK(hand[3]) == GET_RANK(hand[4])) ||
               (GET_RANK(hand[1]) == GET_RANK(hand[2]) &&
                GET_RANK(hand[3]) == GET_RANK(hand[4]))) {
        is_two_pair = 1;
    } else {
        // Check for one pair
        i = 0;
        while (i < HAND_SIZE - 1 && !is_one_pair) {
            if (GET_RANK(hand[i]) == GET_RANK(hand[i + 1])) {
                is_one_pair = 1;
            }
            i++;
        }
    }

    // Determine and print the hand ranking
    if (is_flush && is_straight)
        printf("Straight flush\n");
    else if (is_four_of_a_kind)
        printf("Four of a kind\n");
    else if (is_full_house)
        printf("Full house\n");
    else if (is_flush)
        printf("Flush\n");
    else if (is_straight)
        printf("Straight\n");
    else if (is_three_of_a_kind)
        printf("Three of a kind\n");
    else if (is_two_pair)
        printf("Two pair\n");
    else if (is_one_pair)
        printf("One pair\n");
    else
        printf("High card\n");

    return 0;
}