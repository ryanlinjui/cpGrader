#include <stdio.h>
#include <stdint.h>

int main(){
    int32_t decimal;

    printf("Please enter an unsigned 16-bits number: ");
    scanf("%d", &decimal);

//============================== Decimal To Octal Begin ==============================//
    int32_t _decimal = decimal;
    int32_t _octal = 0;

    _octal += _decimal % 8;
    _decimal /= 8;

    _octal += 10 * (_decimal % 8);
    _decimal /= 8;

    _octal += 100 * (_decimal % 8);
    _decimal /= 8;

    _octal += 1000 * (_decimal % 8);
    _decimal /= 8;

    _octal += 10000 * (_decimal % 8);
    _decimal /= 8;

    _octal += 100000 * (_decimal % 8);
    _decimal /= 8;

    int32_t returnOctal = _octal;
//============================== Decimal To Octal End ==============================//

    int32_t beforeFlipOctal = returnOctal;

//============================== Flip Number Begin ==============================//
    int32_t _number = beforeFlipOctal;
    int32_t _flipNumber = 0;

    int32_t returnFlipNumber;
    int8_t hasReturnFlipNumber = 0;
        
    if ( !hasReturnFlipNumber ) {
        _flipNumber += _number % 10;
        _number /= 10;
        if ( !_number ) {
            returnFlipNumber = _flipNumber;
            hasReturnFlipNumber = 1;
        }
        _flipNumber *= 10;
    }
    
    if ( !hasReturnFlipNumber ) {
        _flipNumber += _number % 10;
        _number /= 10;
        if ( !_number ) {
            returnFlipNumber = _flipNumber;
            hasReturnFlipNumber = 1;
        }
        _flipNumber *= 10;
    }
    
    if ( !hasReturnFlipNumber ) {
        _flipNumber += _number % 10;
        _number /= 10;
        if ( !_number ) {
            returnFlipNumber = _flipNumber;
            hasReturnFlipNumber = 1;
        }
        _flipNumber *= 10;
    }
    
    if ( !hasReturnFlipNumber ) {
        _flipNumber += _number % 10;
        _number /= 10;
        if ( !_number ) {
            returnFlipNumber = _flipNumber;
            hasReturnFlipNumber = 1;
        }
        _flipNumber *= 10;
    }
    
    if ( !hasReturnFlipNumber ) {
        _flipNumber += _number % 10;
        _number /= 10;
        if ( !_number ) {
            returnFlipNumber = _flipNumber;
            hasReturnFlipNumber = 1;
        }
        _flipNumber *= 10;
    }
    
    if ( !hasReturnFlipNumber ) {
        _flipNumber += _number % 10;
        _number /= 10;

        returnFlipNumber = _flipNumber;
    }
//============================== Flip Number End ==============================//

    int32_t afterFlipOctal = returnFlipNumber;

//============================== Before Flip Octal To Decimal Begin ==============================//
    _octal = beforeFlipOctal;
    _decimal = 0;

    int32_t returnDecimal;
    int8_t hasReturnDecimal = 0;

    if ( !hasReturnDecimal ) {
        _decimal += _octal % 10;
        _octal /= 10;
        if ( !_octal ) {
            returnDecimal = _decimal;
            hasReturnDecimal = 1;
        }
        _decimal *= 8;
    }

    if ( !hasReturnDecimal ) {
        _decimal += _octal % 10;
        _octal /= 10;
        if ( !_octal ) {
            returnDecimal = _decimal;
            hasReturnDecimal = 1;
        }
        _decimal *= 8;
    }

    if ( !hasReturnDecimal ) {
        _decimal += _octal % 10;
        _octal /= 10;
        if ( !_octal ) {
            returnDecimal = _decimal;
            hasReturnDecimal = 1;
        }
        _decimal *= 8;
    }

    if ( !hasReturnDecimal ) {
        _decimal += _octal % 10;
        _octal /= 10;
        if ( !_octal ) {
            returnDecimal = _decimal;
            hasReturnDecimal = 1;
        }
        _decimal *= 8;
    }

    if ( !hasReturnDecimal ) {
        _decimal += _octal % 10;
        _octal /= 10;
        if ( !_octal ) {
            returnDecimal = _decimal;
            hasReturnDecimal = 1;
        }
        _decimal *= 8;
    }

    if ( !hasReturnDecimal ) {
        _decimal += _octal % 10;
        _octal /= 10;
        
        returnDecimal = _decimal;
    }

//============================== Before Flip Octal To Decimal End ==============================//

    int32_t flipOctalToDecimal = returnDecimal;

    printf("Before Flip:\n");
    printf("%d_10 = %d_8\n", decimal, beforeFlipOctal);

    printf("After Flip:\n");
    printf("%d_8 = %d_10\n", afterFlipOctal, flipOctalToDecimal);

    return 0;
}
