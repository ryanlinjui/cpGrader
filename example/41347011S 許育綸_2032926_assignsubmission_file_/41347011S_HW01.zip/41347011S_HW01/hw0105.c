#include<stdio.h>
#include<stdint.h>

int main(){
    int32_t _decimal;
    int32_t _number;
    int32_t convertToSignedInteger;
    int32_t convertToUnsignedInteger;

    int32_t hex;

    printf("Please input a hex: ");
    scanf("%x", &hex);

    int32_t type;

    printf("Please choose the output type ( 1: integer, 2: unsigned integer, 3: float ): ");
    scanf("%d", &type);

    printf("Binary of %X is: ", hex);

    //================= Print Binary By Decimal =================//
    _decimal = hex;

    printf("%d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n", 
        (_decimal / 32768) % 2,
        (_decimal / 16384) % 2,
        (_decimal / 8192) % 2,
        (_decimal / 4096) % 2,
        (_decimal / 2048) % 2,
        (_decimal / 1024) % 2,
        (_decimal / 512) % 2,
        (_decimal / 256) % 2,
        (_decimal / 128) % 2,
        (_decimal / 64) % 2,
        (_decimal / 32) % 2,
        (_decimal / 16) % 2,
        (_decimal / 8) % 2,
        (_decimal / 4) % 2,
        (_decimal / 2) % 2,
        (_decimal / 1) % 2
    );
    //===========================================================//

    if ( type  == 1 ) {     
        printf("Converted integer is: ");

        //============== Convert To Signed Integer ==============//
        _number = hex;
        int32_t sign = (_number / 32768) % 2 ? -1 : 1;
        if ( sign == -1 ) _number = 65536 - _number;
        convertToSignedInteger =  _number * sign;
        //=======================================================//

        int32_t integer = convertToSignedInteger;
        printf("%d\n", integer);
    }
    else if ( type == 2 ) {
        printf("Converted unsigned integer is: ");
        //============== Convert To Unsigned Integer ==============//
        _number = hex;

        convertToUnsignedInteger = _number;
        //=======================================================//
        int32_t unsignedInteger = convertToUnsignedInteger;
        printf("%d\n", unsignedInteger);
    }
    else if ( type == 3 ) {
        printf("Converted float is: ");
        //============== Convert To Float EXP ==============//
        _number = hex;

        _number %= 32768;
        int32_t hexExpPart = _number / 1024;

        int32_t convertToFloatEXP = hexExpPart - 15;
        //==================================================//

        //============== Convert To Float F ==============//
        _number = hex;
        
        int32_t sign = (_number / 32768) % 2 ? -1 : 1;
        int32_t hexFPart = _number % 1024;

        double _F = 0;
        _F += ( hexFPart / 1 ) % 2;
        _F /= 2;
        _F += ( hexFPart / 2 ) % 2;
        _F /= 2;
        _F += ( hexFPart / 4 ) % 2;
        _F /= 2;
        _F += ( hexFPart / 8 ) % 2;
        _F /= 2;
        _F += ( hexFPart / 16 ) % 2;
        _F /= 2;
        _F += ( hexFPart / 32 ) % 2;
        _F /= 2;
        _F += ( hexFPart / 64 ) % 2;
        _F /= 2;
        _F += ( hexFPart / 128 ) % 2;
        _F /= 2;
        _F += ( hexFPart / 256 ) % 2;
        _F /= 2;
        _F += ( hexFPart / 512 ) % 2;
        _F /= 2;

        _F += 1;

        double convertToFloatF = sign * _F;
        //================================================//
        int32_t EXP = convertToFloatEXP;
        double F = convertToFloatF;
        int32_t isNegativwSign = (hex / 32768) % 2 ? 1 : 0;
        if ( EXP == -15 && F == -1 ) printf("-0.0");
        else if ( EXP == -15 && F == 1 ) printf("+0.0");
        else if ( EXP == 16 && F == -1 ) printf("-INF");
        else if ( EXP == 16 && F == 1 ) printf("+INF");
        else if ( EXP == 16 && (F != 1 || F != -1) ) printf("NAN");
        else printf("%f*2^%d", F, EXP);
        printf("\n");
    }
    
    return 0;
}
