#  程式設計(一) HW01
[題目連結](https://drive.google.com/file/d/1M1knr4kZqzCvRlv7VaW-grhDAkN8s9gL/view)
## Print Colorful Words
把相對的 ANSI Escape Code 填在字串前面就能改變 console 中的顏色。<br>
另外 `<br>x1b[0m` 可恢復預設顏色及字體 <br>
![ANSI Escape Code Color](img/image.png) <br>
[圖片來源](https://blog.darkthread.net/blog/ansi-escape-code/)
## A Simple Math Problem
巧妙的調換一下直式十位數的位置， <br>
不難發現`yxz`就是 `sum - userInput`。
## Flip an Octal Number
對一個數字 除`n`取餘數 的操作，<br>
其實就相當於取這個數的 `n 進位表示法` 的第一個數 。 <br>
加上題目有提示會給一個 `16-bits` 的數， <br>
因此就乖乖用手把他敲出來就能轉換了。
## Poker Hands
- 用六進制數模擬陣列：
> 我維護了一個六進制的數字，每個位數相當於該`index`號牌出現了幾次。 <br>
> (花色也是一樣做法)

- 重複號碼牌處理方式
> 數字重複要用兩個變數來存重複最多次的號碼， <br>
> 當出現次數大於 1、且該數字還沒存過才儲存。 <br>
> 由於 5 張牌最多只會出現兩個大於一的重複，所以只需兩個變數儲存即可。

- 重複花色牌處理方式
> 維護一個相同花色牌的數量最大值，當處理 `card` 時做更新。

- 順子處理方式
> 維護一個數字最小值，當處理 card 時做更新， <br>
> 最後檢查 六進制數 從最小數字位數開始往前五格是否都為 `1`，就能知道是否出現順子。 <br>
> 另外特判當 最小數字 為 `1` 時，若 `10、11、12、13、1` 位數皆為 1 則一樣視為(皇家)同花順。

小結論：感覺還是排序更方便，這種方式比較麻煩但滿有趣的(ゝ∀･)b
## Binary Variable
讀入值時使用`%x`就能讀取`hex` <br>
輸出時`%x`代表若有英文則為小寫；`%X`代表若有英文則為大寫。 <br>
其餘照著指示乖乖手打轉換，舒服。 <br>
另外特判`float`的特殊情況即可。
## Bonus: Makefile for Multiple files
在指令前加上`-`即可在錯誤後繼續執行後面指令。 <br>
[參考資料原文](https://stackoverflow.com/questions/2670130/make-how-to-continue-after-a-command-fails)擷取：
> To ignore errors in a command line, 
> write a - at the beginning of the 
> line's text (after the initial tab). 
> The - is discarded before the command 
> is passed to the shell for execution.
> 
> For example,
> 
> ```make
> clean:
>    -rm -f *.o
> ```
