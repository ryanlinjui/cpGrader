#include <stdio.h>
#include <stdint.h>

int main(){
    int8_t isDebug = 0;

    int8_t isInputNumber = 1;
    int64_t card1, card2, card3, card4, card5;

    printf("Please enter 5 cards: ");
    isInputNumber = scanf("%ld %ld %ld %ld %ld", &card1, &card2, &card3, &card4, &card5);

    if ( !isInputNumber ) {
        printf("Error: Please input correct format (int int int int int) instead of other input. O-O\n");
        return 0;
    }
    if (card1 == card2 || 
        card1 == card3 ||
        card1 == card4 ||
        card1 == card5 ||
        card2 == card3 ||
        card2 == card4 ||
        card2 == card5 ||
        card3 == card4 ||
        card3 == card5 ||
        card4 == card5
    ) {
        printf("Error: You're cheating! There can't be the same card in a deck of cards =-=\n");
        return 0;
    }

    card1 -= 1; card2 -= 1; card3 -= 1; card4 -= 1; card5 -= 1;

    int64_t minCard = 53;
    int64_t maxCard = -1;

    int64_t maxSameNumberCardNumber_1 = -1;
    int64_t maxSameNumberCardNumber_2 = -1;
    int64_t sameNumberCardList_5 = 0;

    int64_t sameSuitCardList_5 = 0;
    int64_t maxSameSuitCardAmount = 0;
    
    int64_t minCardNumber = 14;

    int64_t currentCard;
    int64_t currentCardNumber;
    int64_t currentCardSuit;
    int64_t cardNumberIndex;
    int64_t cardSuitIndex;
    int64_t currentSameNumberCardAmount;
    int64_t currentSameSuitCardAmount;

    int64_t _number;
    int64_t returnSixPowValue;
    int64_t _returnValue;

//============================== Card1 Process Begin ==============================//
    currentCard = card1;
    
    if (currentCard > maxCard) maxCard = currentCard;
    if (currentCard < minCard) minCard = currentCard;
    if ( maxCard >= 52 || minCard < 0) {
        printf("Error: Did you draw your hand yourself ?(X)\nPlease enter a number between 1 and 52 to represent your hand.=m=\n");
        return 0;
    }
    
    currentCardNumber = currentCard % 13;
    if ( isDebug ) printf("currentCardNumber = %ld\n", currentCardNumber);
    currentCardSuit = currentCard / 13;
    if ( isDebug ) printf("currentCardSuit = %ld\n", currentCardSuit);

    //============= Six Pow Process Begin =============//
    _number = currentCardNumber;
    _returnValue;
    switch (_number)
    {
        case 0:
            _returnValue = 1;
            break;
        case 1:
            _returnValue = 6;
            break;
        case 2:
            _returnValue = 36;
            break;
        case 3:
            _returnValue = 216;
            break;
        case 4:
            _returnValue = 216 * 6;
            break;
        case 5:
            _returnValue = 216 * 36;
            break;
        case 6:
            _returnValue = 216 * 216;
            break;
        case 7:
            _returnValue = 216 * 216 * 6;
            break;
        case 8:
            _returnValue = 216 * 216 * 36;
            break;
        case 9:
            _returnValue = 216 * 216 * 216;
            break;
        case 10:
            _returnValue = 216 * 216 * 216 * 6;
            break;
        case 11:
            _returnValue = 216 * 216 * 216 * 36;
            break;
        case 12:
            _returnValue = 216 * 216;
            _returnValue *= 216 * 216;
            break;
        default:
            printf("Error: Unknown BUG!!! `3ˊ\n");
            return 0;
    }
    returnSixPowValue = _returnValue;
    //============= Six Pow Process End =============//

    cardNumberIndex = returnSixPowValue;
    sameNumberCardList_5 += cardNumberIndex;
    currentSameNumberCardAmount = (sameNumberCardList_5 / cardNumberIndex) % 6;
    if ( isDebug ) printf("currentSameNumberCardAmount = %ld\n", currentSameNumberCardAmount);
    if ( currentSameNumberCardAmount > 1 && (maxSameNumberCardNumber_1 == currentCardNumber || maxSameNumberCardNumber_1 == -1)) {
        maxSameNumberCardNumber_1 = currentCardNumber;
    }
    else if ( currentSameNumberCardAmount > 1 && (maxSameNumberCardNumber_2 == currentCardNumber || maxSameNumberCardNumber_2 == -1)) {
        maxSameNumberCardNumber_2 = currentCardNumber;
    }

    //============= Six Pow Process Begin =============//
    _number = currentCardSuit;
    _returnValue;
    switch (_number)
    {
        case 0:
            _returnValue = 1;
            break;
        case 1:
            _returnValue = 6;
            break;
        case 2:
            _returnValue = 36;
            break;
        case 3:
            _returnValue = 216;
            break;
        case 4:
            _returnValue = 216 * 6;
            break;
        case 5:
            _returnValue = 216 * 36;
            break;
        case 6:
            _returnValue = 216 * 216;
            break;
        case 7:
            _returnValue = 216 * 216 * 6;
            break;
        case 8:
            _returnValue = 216 * 216 * 36;
            break;
        case 9:
            _returnValue = 216 * 216 * 216;
            break;
        case 10:
            _returnValue = 216 * 216 * 216 * 6;
            break;
        case 11:
            _returnValue = 216 * 216 * 216 * 36;
            break;
        case 12:
            _returnValue = 216 * 216;
            _returnValue *= 216 * 216;
            break;
        default:
            printf("Error: Unknown BUG!!! `Hˊ\n");
            return 0;
    }
    returnSixPowValue = _returnValue;
    //============= Six Pow Process End =============//

    cardSuitIndex = returnSixPowValue;
    sameSuitCardList_5 += cardSuitIndex;
    currentSameSuitCardAmount = (sameSuitCardList_5 / cardSuitIndex) % 6;
    if ( isDebug ) printf("currentSameSuitCardAmount = %ld\n", currentSameSuitCardAmount);
    if ( currentSameSuitCardAmount > maxSameSuitCardAmount ) maxSameSuitCardAmount = currentSameSuitCardAmount;

    minCardNumber = minCardNumber < currentCardNumber ? minCardNumber : currentCardNumber;
    if ( isDebug ) printf("minCardNumber = %ld\n", minCardNumber);
    if ( isDebug ) printf("\n");
    
//============================== Card2 Process Begin ==============================//
    currentCard = card2;

    if (currentCard > maxCard) maxCard = currentCard;
    if (currentCard < minCard) minCard = currentCard;
    if ( maxCard >= 52 || minCard < 0) {
        printf("Error: Did you draw your hand yourself ?(X)\nPlease enter a number between 1 and 52 to represent your hand.=v=\n");
        return 0;
    }
    
    currentCardNumber = currentCard % 13;
    if ( isDebug ) printf("currentCardNumber = %ld\n", currentCardNumber);
    currentCardSuit = currentCard / 13;
    if ( isDebug ) printf("currentCardSuit = %ld\n", currentCardSuit);

    //============= Six Pow Process Begin =============//
    _number = currentCardNumber;
    _returnValue;
    switch (_number)
    {
        case 0:
            _returnValue = 1;
            break;
        case 1:
            _returnValue = 6;
            break;
        case 2:
            _returnValue = 36;
            break;
        case 3:
            _returnValue = 216;
            break;
        case 4:
            _returnValue = 216 * 6;
            break;
        case 5:
            _returnValue = 216 * 36;
            break;
        case 6:
            _returnValue = 216 * 216;
            break;
        case 7:
            _returnValue = 216 * 216 * 6;
            break;
        case 8:
            _returnValue = 216 * 216 * 36;
            break;
        case 9:
            _returnValue = 216 * 216 * 216;
            break;
        case 10:
            _returnValue = 216 * 216 * 216 * 6;
            break;
        case 11:
            _returnValue = 216 * 216 * 216 * 36;
            break;
        case 12:
            _returnValue = 216 * 216;
            _returnValue *= 216 * 216;
            break;
        default:
            printf("Error: Unknown BUG!!! `~ˊ\n");
            return 0;
    }
    returnSixPowValue = _returnValue;
    //============= Six Pow Process End =============//

    cardNumberIndex = returnSixPowValue;
    sameNumberCardList_5 += cardNumberIndex;
    currentSameNumberCardAmount = (sameNumberCardList_5 / cardNumberIndex) % 6;
    if ( isDebug ) printf("currentSameNumberCardAmount = %ld\n", currentSameNumberCardAmount);
    if ( currentSameNumberCardAmount > 1 && (maxSameNumberCardNumber_1 == currentCardNumber || maxSameNumberCardNumber_1 == -1)) {
        maxSameNumberCardNumber_1 = currentCardNumber;
    }
    else if ( currentSameNumberCardAmount > 1 && (maxSameNumberCardNumber_2 == currentCardNumber || maxSameNumberCardNumber_2 == -1)) {
        maxSameNumberCardNumber_2 = currentCardNumber;
    }

    //============= Six Pow Process Begin =============//
    _number = currentCardSuit;
    _returnValue;
    switch (_number)
    {
        case 0:
            _returnValue = 1;
            break;
        case 1:
            _returnValue = 6;
            break;
        case 2:
            _returnValue = 36;
            break;
        case 3:
            _returnValue = 216;
            break;
        case 4:
            _returnValue = 216 * 6;
            break;
        case 5:
            _returnValue = 216 * 36;
            break;
        case 6:
            _returnValue = 216 * 216;
            break;
        case 7:
            _returnValue = 216 * 216 * 6;
            break;
        case 8:
            _returnValue = 216 * 216 * 36;
            break;
        case 9:
            _returnValue = 216 * 216 * 216;
            break;
        case 10:
            _returnValue = 216 * 216 * 216 * 6;
            break;
        case 11:
            _returnValue = 216 * 216 * 216 * 36;
            break;
        case 12:
            _returnValue = 216 * 216;
            _returnValue *= 216 * 216;
            break;
        default:
            printf("Error: Unknown BUG!!! `oˊ\n");
            return 0;
    }
    returnSixPowValue = _returnValue;
    //============= Six Pow Process End =============//

    cardSuitIndex = returnSixPowValue;
    sameSuitCardList_5 += cardSuitIndex;
    currentSameSuitCardAmount = (sameSuitCardList_5 / cardSuitIndex) % 6;
    if ( isDebug ) printf("currentSameSuitCardAmount = %ld\n", currentSameSuitCardAmount);
    if ( currentSameSuitCardAmount > maxSameSuitCardAmount ) maxSameSuitCardAmount = currentSameSuitCardAmount;

    minCardNumber = minCardNumber < currentCardNumber ? minCardNumber : currentCardNumber;
    if ( isDebug ) printf("minCardNumber = %ld\n", minCardNumber);
    if ( isDebug ) printf("\n");
    
//============================== Card3 Process Begin ==============================//
    currentCard = card3;

    if (currentCard > maxCard) maxCard = currentCard;
    if (currentCard < minCard) minCard = currentCard;
    if ( maxCard >= 52 || minCard < 0) {
        printf("Error: Did you draw your hand yourself ?(X)\nPlease enter a number between 1 and 52 to represent your hand.(=o=;)\n");
        return 0;
    }
    
    currentCardNumber = currentCard % 13;
    if ( isDebug ) printf("currentCardNumber = %ld\n", currentCardNumber);
    currentCardSuit = currentCard / 13;
    if ( isDebug ) printf("currentCardSuit = %ld\n", currentCardSuit);

    //============= Six Pow Process Begin =============//
    _number = currentCardNumber;
    _returnValue;
    switch (_number)
    {
        case 0:
            _returnValue = 1;
            break;
        case 1:
            _returnValue = 6;
            break;
        case 2:
            _returnValue = 36;
            break;
        case 3:
            _returnValue = 216;
            break;
        case 4:
            _returnValue = 216 * 6;
            break;
        case 5:
            _returnValue = 216 * 36;
            break;
        case 6:
            _returnValue = 216 * 216;
            break;
        case 7:
            _returnValue = 216 * 216 * 6;
            break;
        case 8:
            _returnValue = 216 * 216 * 36;
            break;
        case 9:
            _returnValue = 216 * 216 * 216;
            break;
        case 10:
            _returnValue = 216 * 216 * 216 * 6;
            break;
        case 11:
            _returnValue = 216 * 216 * 216 * 36;
            break;
        case 12:
            _returnValue = 216 * 216;
            _returnValue *= 216 * 216;
            break;
        default:
            printf("Error: Unknown BUG!!! `^ˊ\n");
            return 0;
    }
    returnSixPowValue = _returnValue;
    //============= Six Pow Process End =============//

    cardNumberIndex = returnSixPowValue;
    sameNumberCardList_5 += cardNumberIndex;
    currentSameNumberCardAmount = (sameNumberCardList_5 / cardNumberIndex) % 6;
    if ( isDebug ) printf("currentSameNumberCardAmount = %ld\n", currentSameNumberCardAmount);
    if ( currentSameNumberCardAmount > 1 && (maxSameNumberCardNumber_1 == currentCardNumber || maxSameNumberCardNumber_1 == -1)) {
        maxSameNumberCardNumber_1 = currentCardNumber;
    }
    else if ( currentSameNumberCardAmount > 1 && (maxSameNumberCardNumber_2 == currentCardNumber || maxSameNumberCardNumber_2 == -1)) {
        maxSameNumberCardNumber_2 = currentCardNumber;
    }

    //============= Six Pow Process Begin =============//
    _number = currentCardSuit;
    _returnValue;
    switch (_number)
    {
        case 0:
            _returnValue = 1;
            break;
        case 1:
            _returnValue = 6;
            break;
        case 2:
            _returnValue = 36;
            break;
        case 3:
            _returnValue = 216;
            break;
        case 4:
            _returnValue = 216 * 6;
            break;
        case 5:
            _returnValue = 216 * 36;
            break;
        case 6:
            _returnValue = 216 * 216;
            break;
        case 7:
            _returnValue = 216 * 216 * 6;
            break;
        case 8:
            _returnValue = 216 * 216 * 36;
            break;
        case 9:
            _returnValue = 216 * 216 * 216;
            break;
        case 10:
            _returnValue = 216 * 216 * 216 * 6;
            break;
        case 11:
            _returnValue = 216 * 216 * 216 * 36;
            break;
        case 12:
            _returnValue = 216 * 216;
            _returnValue *= 216 * 216;
            break;
        default:
            printf("Error: Unknown BUG!!! `Wˊ\n");
            return 0;
    }
    returnSixPowValue = _returnValue;
    //============= Six Pow Process End =============//

    cardSuitIndex = returnSixPowValue;
    sameSuitCardList_5 += cardSuitIndex;
    currentSameSuitCardAmount = (sameSuitCardList_5 / cardSuitIndex) % 6;
    if ( isDebug ) printf("currentSameSuitCardAmount = %ld\n", currentSameSuitCardAmount);
    if ( currentSameSuitCardAmount > maxSameSuitCardAmount ) maxSameSuitCardAmount = currentSameSuitCardAmount;

    minCardNumber = minCardNumber < currentCardNumber ? minCardNumber : currentCardNumber;
    if ( isDebug ) printf("minCardNumber = %ld\n", minCardNumber);
    if ( isDebug ) printf("\n");
    
//============================== Card4 Process Begin ==============================//
    currentCard = card4;

    if (currentCard > maxCard) maxCard = currentCard;
    if (currentCard < minCard) minCard = currentCard;
    if ( maxCard >= 52 || minCard < 0) {
        printf("Error: Did you draw your hand yourself ?(X)\nPlease enter a number between 1 and 52 to represent your hand.=ㄒ=\n");
        return 0;
    }
    
    currentCardNumber = currentCard % 13;
    if ( isDebug ) printf("currentCardNumber = %ld\n", currentCardNumber);
    currentCardSuit = currentCard / 13;
    if ( isDebug ) printf("currentCardSuit = %ld\n", currentCardSuit);

    //============= Six Pow Process Begin =============//
    _number = currentCardNumber;
    _returnValue;
    switch (_number)
    {
        case 0:
            _returnValue = 1;
            break;
        case 1:
            _returnValue = 6;
            break;
        case 2:
            _returnValue = 36;
            break;
        case 3:
            _returnValue = 216;
            break;
        case 4:
            _returnValue = 216 * 6;
            break;
        case 5:
            _returnValue = 216 * 36;
            break;
        case 6:
            _returnValue = 216 * 216;
            break;
        case 7:
            _returnValue = 216 * 216 * 6;
            break;
        case 8:
            _returnValue = 216 * 216 * 36;
            break;
        case 9:
            _returnValue = 216 * 216 * 216;
            break;
        case 10:
            _returnValue = 216 * 216 * 216 * 6;
            break;
        case 11:
            _returnValue = 216 * 216 * 216 * 36;
            break;
        case 12:
            _returnValue = 216 * 216;
            _returnValue *= 216 * 216;
            break;
        default:
            printf("Error: Unknown BUG!!! `Mˊ\n");
            return 0;
    }
    returnSixPowValue = _returnValue;
    //============= Six Pow Process End =============//

    cardNumberIndex = returnSixPowValue;
    sameNumberCardList_5 += cardNumberIndex;
    currentSameNumberCardAmount = (sameNumberCardList_5 / cardNumberIndex) % 6;
    if ( isDebug ) printf("currentSameNumberCardAmount = %ld\n", currentSameNumberCardAmount);
    if ( currentSameNumberCardAmount > 1 && (maxSameNumberCardNumber_1 == currentCardNumber || maxSameNumberCardNumber_1 == -1)) {
        maxSameNumberCardNumber_1 = currentCardNumber;
    }
    else if ( currentSameNumberCardAmount > 1 && (maxSameNumberCardNumber_2 == currentCardNumber || maxSameNumberCardNumber_2 == -1)) {
        maxSameNumberCardNumber_2 = currentCardNumber;
    }

    //============= Six Pow Process Begin =============//
    _number = currentCardSuit;
    _returnValue;
    switch (_number)
    {
        case 0:
            _returnValue = 1;
            break;
        case 1:
            _returnValue = 6;
            break;
        case 2:
            _returnValue = 36;
            break;
        case 3:
            _returnValue = 216;
            break;
        case 4:
            _returnValue = 216 * 6;
            break;
        case 5:
            _returnValue = 216 * 36;
            break;
        case 6:
            _returnValue = 216 * 216;
            break;
        case 7:
            _returnValue = 216 * 216 * 6;
            break;
        case 8:
            _returnValue = 216 * 216 * 36;
            break;
        case 9:
            _returnValue = 216 * 216 * 216;
            break;
        case 10:
            _returnValue = 216 * 216 * 216 * 6;
            break;
        case 11:
            _returnValue = 216 * 216 * 216 * 36;
            break;
        case 12:
            _returnValue = 216 * 216;
            _returnValue *= 216 * 216;
            break;
        default:
            printf("Error: Unknown BUG!!! `一ˊ\n");
            return 0;
    }
    returnSixPowValue = _returnValue;
    //============= Six Pow Process End =============//

    cardSuitIndex = returnSixPowValue;
    sameSuitCardList_5 += cardSuitIndex;
    currentSameSuitCardAmount = (sameSuitCardList_5 / cardSuitIndex) % 6;
    if ( isDebug ) printf("currentSameSuitCardAmount = %ld\n", currentSameSuitCardAmount);
    if ( currentSameSuitCardAmount > maxSameSuitCardAmount ) maxSameSuitCardAmount = currentSameSuitCardAmount;

    minCardNumber = minCardNumber < currentCardNumber ? minCardNumber : currentCardNumber;
    if ( isDebug ) printf("minCardNumber = %ld\n", minCardNumber);
    if ( isDebug ) printf("\n");
    
//============================== Card5 Process Begin ==============================//
    currentCard = card5;

    if (currentCard > maxCard) maxCard = currentCard;
    if (currentCard < minCard) minCard = currentCard;
    if ( maxCard >= 52 || minCard < 0) {
        printf("Error: Did you draw your hand yourself ?(X)\nPlease enter a number between 1 and 52 to represent your hand.=^=\n");
        return 0;
    }
    
    currentCardNumber = currentCard % 13;
    if ( isDebug ) printf("currentCardNumber = %ld\n", currentCardNumber);
    currentCardSuit = currentCard / 13;
    if ( isDebug ) printf("currentCardSuit = %ld\n", currentCardSuit);

    //============= Six Pow Process Begin =============//
    _number = currentCardNumber;
    _returnValue;
    switch (_number)
    {
        case 0:
            _returnValue = 1;
            break;
        case 1:
            _returnValue = 6;
            break;
        case 2:
            _returnValue = 36;
            break;
        case 3:
            _returnValue = 216;
            break;
        case 4:
            _returnValue = 216 * 6;
            break;
        case 5:
            _returnValue = 216 * 36;
            break;
        case 6:
            _returnValue = 216 * 216;
            break;
        case 7:
            _returnValue = 216 * 216 * 6;
            break;
        case 8:
            _returnValue = 216 * 216 * 36;
            break;
        case 9:
            _returnValue = 216 * 216 * 216;
            break;
        case 10:
            _returnValue = 216 * 216 * 216 * 6;
            break;
        case 11:
            _returnValue = 216 * 216 * 216 * 36;
            break;
        case 12:
            _returnValue = 216 * 216;
            _returnValue *= 216 * 216;
            break;
        default:
            printf("Error: Unknown BUG!!!`oˊ\n");
            return 0;
    }
    returnSixPowValue = _returnValue;
    //============= Six Pow Process End =============//

    cardNumberIndex = returnSixPowValue;
    sameNumberCardList_5 += cardNumberIndex;
    currentSameNumberCardAmount = (sameNumberCardList_5 / cardNumberIndex) % 6;
    if ( isDebug ) printf("currentSameNumberCardAmount = %ld\n", currentSameNumberCardAmount);
    if ( currentSameNumberCardAmount > 1 && (maxSameNumberCardNumber_1 == currentCardNumber || maxSameNumberCardNumber_1 == -1)) {
        maxSameNumberCardNumber_1 = currentCardNumber;
    }
    else if ( currentSameNumberCardAmount > 1 && (maxSameNumberCardNumber_2 == currentCardNumber || maxSameNumberCardNumber_2 == -1)) {
        maxSameNumberCardNumber_2 = currentCardNumber;
    }

    //============= Six Pow Process Begin =============//
    _number = currentCardSuit;
    _returnValue;
    switch (_number)
    {
        case 0:
            _returnValue = 1;
            break;
        case 1:
            _returnValue = 6;
            break;
        case 2:
            _returnValue = 36;
            break;
        case 3:
            _returnValue = 216;
            break;
        case 4:
            _returnValue = 216 * 6;
            break;
        case 5:
            _returnValue = 216 * 36;
            break;
        case 6:
            _returnValue = 216 * 216;
            break;
        case 7:
            _returnValue = 216 * 216 * 6;
            break;
        case 8:
            _returnValue = 216 * 216 * 36;
            break;
        case 9:
            _returnValue = 216 * 216 * 216;
            break;
        case 10:
            _returnValue = 216 * 216 * 216 * 6;
            break;
        case 11:
            _returnValue = 216 * 216 * 216 * 36;
            break;
        case 12:
            _returnValue = 216 * 216;
            _returnValue *= 216 * 216;
            break;
        default:
            printf("Error: Unknown BUG!!! `oˊ\n");
            return 0;
    }
    returnSixPowValue = _returnValue;
    //============= Six Pow Process End =============//

    cardSuitIndex = returnSixPowValue;
    sameSuitCardList_5 += cardSuitIndex;
    currentSameSuitCardAmount = (sameSuitCardList_5 / cardSuitIndex) % 6;
    if ( isDebug ) printf("currentSameSuitCardAmount = %ld\n", currentSameSuitCardAmount);
    if ( currentSameSuitCardAmount > maxSameSuitCardAmount ) maxSameSuitCardAmount = currentSameSuitCardAmount;

    minCardNumber = minCardNumber < currentCardNumber ? minCardNumber : currentCardNumber;
    if ( isDebug ) printf("minCardNumber = %ld\n", minCardNumber);
    if ( isDebug ) printf("\n");

//============================== Find Result ==============================//
    if ( maxCard >= 52 || minCard < 0) {
        printf("Error: Did you draw your hand yourself ?(X)\nPlease enter a number between 1 and 52 to represent your hand.=n=\n");
        return 0;
    }
    
    int64_t maxSameNumberCardAmount_1 = 0;
    int64_t maxSameNumberCardAmount_2 = 0;

    //============= Six Pow Process Begin =============//
    if ( maxSameNumberCardNumber_1 != -1) {
        _number = maxSameNumberCardNumber_1;
        _returnValue;
        switch (_number)
        {
            case 0:
                _returnValue = 1;
                break;
            case 1:
                _returnValue = 6;
                break;
            case 2:
                _returnValue = 36;
                break;
            case 3:
                _returnValue = 216;
                break;
            case 4:
                _returnValue = 216 * 6;
                break;
            case 5:
                _returnValue = 216 * 36;
                break;
            case 6:
                _returnValue = 216 * 216;
                break;
            case 7:
                _returnValue = 216 * 216 * 6;
                break;
            case 8:
                _returnValue = 216 * 216 * 36;
                break;
            case 9:
                _returnValue = 216 * 216 * 216;
                break;
            case 10:
                _returnValue = 216 * 216 * 216 * 6;
                break;
            case 11:
                _returnValue = 216 * 216 * 216 * 36;
                break;
            case 12:
                _returnValue = 216 * 216;
                _returnValue *= 216 * 216;
                break;
            default:
                printf("\n\nBUG!!!\n\n");
                break;
        }
        returnSixPowValue = _returnValue;
    }
    //============= Six Pow Process End =============//

    if ( maxSameNumberCardNumber_1 != -1 ) maxSameNumberCardAmount_1 = (sameNumberCardList_5 / returnSixPowValue) % 6;
    
    //============= Six Pow Process Begin =============//
    if ( maxSameNumberCardNumber_2 != -1 ) {
        _number = maxSameNumberCardNumber_2;
        _returnValue;
        switch (_number)
        {
            case 0:
                _returnValue = 1;
                break;
            case 1:
                _returnValue = 6;
                break;
            case 2:
                _returnValue = 36;
                break;
            case 3:
                _returnValue = 216;
                break;
            case 4:
                _returnValue = 216 * 6;
                break;
            case 5:
                _returnValue = 216 * 36;
                break;
            case 6:
                _returnValue = 216 * 216;
                break;
            case 7:
                _returnValue = 216 * 216 * 6;
                break;
            case 8:
                _returnValue = 216 * 216 * 36;
                break;
            case 9:
                _returnValue = 216 * 216 * 216;
                break;
            case 10:
                _returnValue = 216 * 216 * 216 * 6;
                break;
            case 11:
                _returnValue = 216 * 216 * 216 * 36;
                break;
            case 12:
                _returnValue = 216 * 216;
                _returnValue *= 216 * 216;
                break;
            default:
                printf("\n\nBUG!!!\n\n");
                break;
        }
        returnSixPowValue = _returnValue;
    }
    //============= Six Pow Process End =============//
    
    if ( maxSameNumberCardNumber_2 != -1 ) maxSameNumberCardAmount_2 = (sameNumberCardList_5 / returnSixPowValue) % 6;
    if ( isDebug ) printf("maxSameNumberCardAmount_1 = %ld\n", maxSameNumberCardAmount_1);
    if ( isDebug ) printf("maxSameNumberCardAmount_2 = %ld\n", maxSameNumberCardAmount_2);
    
    //============= Six Pow Process Begin =============//
    _number = minCardNumber;
    if ( isDebug ) printf("minCardNumber = %ld\n", minCardNumber);
    switch (_number)
    {
        case 0:
            _returnValue = 1;
            break;
        case 1:
            _returnValue = 6;
            break;
        case 2:
            _returnValue = 36;
            break;
        case 3:
            _returnValue = 216;
            break;
        case 4:
            _returnValue = 216 * 6;
            break;
        case 5:
            _returnValue = 216 * 36;
            break;
        case 6:
            _returnValue = 216 * 216;
            break;
        case 7:
            _returnValue = 216 * 216 * 6;
            break;
        case 8:
            _returnValue = 216 * 216 * 36;
            break;
        case 9:
            _returnValue = 216 * 216 * 216;
            break;
        case 10:
            _returnValue = 216 * 216 * 216 * 6;
            break;
        case 11:
            _returnValue = 216 * 216 * 216 * 36;
            break;
        case 12:
            _returnValue = 216 * 216;
            _returnValue *= 216 * 216;
            break;
        default:
            printf("Error: Unknown BUG!!! `oˊ\n");
            return 0;
    }
    returnSixPowValue = _returnValue;
    //============= Six Pow Process End =============//

    int8_t isStraight = ( sameNumberCardList_5 / returnSixPowValue == 1+6+36+216+1296);
    if ( minCardNumber == 0 && !isStraight ) {
        isStraight = ( (sameNumberCardList_5 / (216 * 216 * 216) == 1+6+36+216) && sameNumberCardList_5 % 6 == 1 );
    }

    if ( isStraight && maxSameSuitCardAmount == 5 ) printf("Straight flush\n");
    else if ( maxSameNumberCardAmount_1 == 4 || maxSameNumberCardAmount_2 == 4 ) printf("Four of a kind\n");
    else if ( (maxSameNumberCardAmount_1 == 2 && maxSameNumberCardAmount_2 == 3) || (maxSameNumberCardAmount_1 == 3 && maxSameNumberCardAmount_2 == 2) ) printf("Full house\n");
    else if ( maxSameSuitCardAmount == 5 ) printf("Flush\n");
    else if ( isStraight ) printf("Straight\n");
    else if ( maxSameNumberCardAmount_1 == 3 || maxSameNumberCardAmount_2 == 3 ) printf("Three of a kind\n");
    else if ( maxSameNumberCardAmount_1 == 2 && maxSameNumberCardAmount_2 == 2 ) printf("Two pair\n");
    else if ( maxSameNumberCardAmount_1 == 2 || maxSameNumberCardAmount_2 == 2 ) printf("One pair\n");
    else printf("High card\n");

    return 0;
}
