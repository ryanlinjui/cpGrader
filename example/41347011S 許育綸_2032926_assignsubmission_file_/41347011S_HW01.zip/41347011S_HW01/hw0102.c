#include<stdio.h>
#include<stdint.h>
#include<stdbool.h>

int main(){
    bool isDubug = false;

    int32_t unitsDigit;
    int32_t tensDigit;
    int32_t hundredsDigit;
    
    int8_t isInputNumber = 1;
    int8_t isInputCorrect = 1;
    
//============================== int-x-int Input Process Begin ==============================//
    printf("Please enter the first operand: ");
    isInputNumber = scanf("%dx%d", &hundredsDigit, &unitsDigit);
    if ( !isInputNumber ) {
        printf("Error: Please input correct format (int-x-int) instead of other input. (>_<)\n");
        return 0;
    }

    if ( isDubug ) printf("hundredsDigit = %d\nunitsDigit = %d\n", hundredsDigit, unitsDigit);
    if ( hundredsDigit > 9 || hundredsDigit < 0 ) {
        printf("Error: please input hundreds digit from 0 ~ 9. o口o\n");
        isInputCorrect = 0;
    }
    if ( unitsDigit > 9 || unitsDigit < 0 ) {
        printf("Error: please input units digit from 0 ~ 9. (°￢。)\n");
        isInputCorrect = 0;
    }
    if ( !isInputCorrect ) return 0;
//============================== int-x-int Input Process End ==============================//

//============================== y-int-z Input Process Begin ==============================//
    printf("Please enter the second operand: ");
    isInputNumber = scanf("%*cy%dz", &tensDigit);
    if ( !isInputNumber ) {
        printf("Error: Please input correct format (y-int-z) instead of other input. (ToT)\n");
        return 0;
    }

    if ( isDubug ) printf("tensDigit = %d\n", tensDigit);
    if ( tensDigit > 9 || tensDigit < 0 ) {
        printf("Error: please input units digit from 0 ~ 9. (｡í _ ì｡)\n");
        isInputCorrect = 0;
    }
    if ( !isInputCorrect ) return 0;

    #pragma endregion y-int-z Input Process
    
    int32_t userInputNumber = hundredsDigit * 100 + tensDigit * 10 + unitsDigit;
    if ( isDubug ) printf("userInputNumber = %d\n", userInputNumber);
//============================== y-int-z Input Process End ==============================//

//============================== Sum Input Process Begin ==============================//
    int32_t sum;

    printf("Please enter the sum: ");
    isInputNumber = scanf("%d", &sum);
    if ( !isInputNumber ) {
        printf("Error: Please input correct format (int-x-int) instead of other input. >~<\n");
        return 0;
    }
    if ( isDubug ) printf("userInputNumber = %d\n", userInputNumber);
    if ( sum > 1998 ) {
        printf("Error: Cannot find a set of x, y, z that satisfies the conditions. Σ(o D o; )/\n");
        isInputCorrect = 0;
    }
    if ( !isInputCorrect ) return 0;
//============================== Sum Input Process End ==============================//

//============================== Ans Process Begin ==============================//
    int32_t ans = sum - userInputNumber;
    if ( ans > 999 || ans < 0 ) {
        printf("Error: Cannot find a set of x, y, z that satisfies the conditions. (O x O)\n");
        isInputCorrect = 0;
    }
    if ( !isInputCorrect ) return 0;
    
    int32_t z = ans % 10;
    ans /= 10;
    int32_t x = ans % 10;
    ans /= 10;
    int32_t y = ans % 10;
    ans /= 10;
//============================== Ans Process End ==============================//

    printf("Ans: x = %d, y = %d, z = %d\n", x, y, z);

    return 0;
}
