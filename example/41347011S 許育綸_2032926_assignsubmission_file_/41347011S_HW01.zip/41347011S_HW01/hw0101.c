#include<stdio.h>

#define RED "\x1b[31m"
#define BLUE "\x1b[34m"
#define GREEN "\x1b[32m"
#define ORIGIN "\x1b[0m"

int main(){
    printf( RED"[KIM]\nYou are sunlight and I moon\nJoined by the gods of fortune\nMidnight and high noon sharing the sky\nWe have been blessed , you and I\n\n"ORIGIN BLUE"[CHRIS]\nYou are here like a mystery\nI'm from a world that's so different from all that you are\nHow in the light of one night did we come so far?\n\n"ORIGIN RED"[KIM]\nOutside day starts to dawn\n\n"ORIGIN BLUE"[CHRIS]\nYour moon still floats on high\n\n"ORIGIN RED"[KIM]\nThe birds awake\n\n"ORIGIN BLUE"[CHRIS]\nThe stars shine too\n\n"ORIGIN RED"[KIM]\nMy hands still shake\nSee upcoming pop shows\nGet tickets for your favorite artists\n\nYou might also like\nMy Boy Only Breaks His Favorite Toys\nTaylor Swift\nWho’s Afraid of Little Old Me?\nTaylor Swift\nGuilty as Sin?\nTaylor Swift\n\n"ORIGIN BLUE"[CHRIS]\nI reach for you\n\n"ORIGIN GREEN"[KIM & CHRIS]\nAnd we meet in the sky\n\n"ORIGIN RED"[KIM]\nYou are sunlight and I moon\nJoined here\nBrightening the sky with the flame of love\n\n"ORIGIN GREEN"[KIM & CHRIS]\nMade of\nSunlight\nMoonlight\n");
    return 0;
}