#include<stdio.h>
#include<stdint.h>
int main(){
    int32_t num=-1,mod=-1;
    printf("Please input a hex:");
    scanf("%x",&num);
    printf("Please choose the output type(1:integer,2:unsigned integer,3:float):");
    scanf("%d",&mod);
    if(num>65535||mod<1||mod>3)
        printf("Wrong input\n");
    else{
        int32_t p1=-1,p2=-1,p3=-1,p4=-1,p5=-1,p6=-1,p7=-1,p8=-1,p9=-1,p10=-1,p11=-1,p12=-1,p13=-1,p14=-1,p15=-1,p16=-1;    
        p16=num/2/2/2/2/2/2/2/2/2/2/2/2/2/2/2%2;
        p15=num/2/2/2/2/2/2/2/2/2/2/2/2/2/2%2;
        p14=num/2/2/2/2/2/2/2/2/2/2/2/2/2%2;
        p13=num/2/2/2/2/2/2/2/2/2/2/2/2%2;
        p12=num/2/2/2/2/2/2/2/2/2/2/2%2;
        p11=num/2/2/2/2/2/2/2/2/2/2%2;
        p10=num/2/2/2/2/2/2/2/2/2%2;
        p9=num/2/2/2/2/2/2/2/2%2;
        p8=num/2/2/2/2/2/2/2%2;
        p7=num/2/2/2/2/2/2%2;
        p6=num/2/2/2/2/2%2;
        p5=num/2/2/2/2%2;
        p4=num/2/2/2%2;
        p3=num/2/2%2;
        p2=num/2%2;
        p1=num%2;
        printf("Binary of %X is:%d%d%d%d %d%d%d%d% d%d%d%d %d%d%d%d\n",num,p16,p15,p14,p13,p12,p11,p10,p9,p8,p7,p6,p5,p4,p3,p2,p1);
        switch(mod){
        case 1://int
            if(p16==0)
                printf("Converted integer is:%d\n",num);
            else{
                int16_t i=0;
                i=~num;
                i+=1;
                printf("Converted integer is:-%d\n",i);
            }    
            break;
        case 2://uint
            printf("Converted unsigned integer is:%u\n",num);
            break;
        case 3://float
            printf("Converted float is:");
            int32_t EXP=0;
            double F=0;
            EXP=p15*16+p14*8+p13*4+p12*2+p11-15;
            F=1+p1*1.0/1024+p2*1.0/512+p3*1.0/256+p4*1.0/128+p5*1.0/64+p6*1.0/32+p7*1.0/16+p8*1.0/8+p9*1.0/4+p10*1.0/2;
            if(F==1&&EXP==-15){
                if(p16==1)
                    printf("-");
                else
                    printf("+");
                printf("0.0\n");
            }
            else if(F==1&&EXP==16){
                if(p16==1)
                    printf("-");
                else
                    printf("+");
                printf("INF\n");
            }
            else if(EXP==16)
                printf("NAN\n");
            else
            {    
                if(p16==1)
                    printf("-");
                else
                    printf("+");
                printf("%f*2^%d\n",F,EXP);
            }
            break;            
        }
    }
    //printf("%X_16=%d_10\n",num,num);
    return 0;
}