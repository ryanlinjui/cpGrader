#include<stdio.h>
#include<stdint.h>
int main(){
    int32_t id=0,i=0,c1=-1,c2=-1,c3=-1,c4=-1,c5=-1;
    int32_t cd1=-1,cd2=-1,cd3=-1,cd4=-1,cd5=-1;
    double f=0.0,c=0.0;
    printf("Please enter 5 cards:");
    scanf("%d %d %d %d %lf",&c1,&c2,&c3,&c4,&f);
    c5=f/1;
    c=f-c5;
    if(c!=0||c1<1||c1>52||c2<1||c2>52||c3<1||c3>52||c4<1||c4>52||c5<1||c5>52||c1==c2||c1==c3||c1==c4||c1==c5||c2==c3||c2==c4||c2==c5||c3==c4||c3==c5||c4==c5)
        printf("Wrong input\n");
    else{
        c1-=1;
        c2-=1;
        c3-=1;
        c4-=1;
        c5-=1;
        cd1=c1/13;
        cd2=c2/13;
        cd3=c3/13;
        cd4=c4/13;
        cd5=c5/13;
        c1=c1%13+1;
        c2=c2%13+1;
        c3=c3%13+1;
        c4=c4%13+1;
        c5=c5%13+1;
        if(c1==c2&&c2==c3&&c3==c4&&c4==c5)
            printf("Wrong input\n");
        else{
            if(c1<c2){
                i=c2;
                c2=c1;
                c1=i;
                id=cd2;
                cd2=cd1;
                cd1=id;}
            if(c2<c3){
                i=c3;
                c3=c2;
                c2=i;
                id=cd3;
                cd3=cd2;
                cd2=id;}
            if(c3<c4){
                i=c4;
                c4=c3;
                c3=i;
                id=cd4;
                cd4=cd3;
                cd3=id;}
            if(c4<c5){
                i=c5;
                c5=c4;
                c4=i;
                id=cd5;
                cd5=cd4;
                cd4=id;}
            if(c1<c2){
                i=c2;
                c2=c1;
                c1=i;
                id=cd2;
                cd2=cd1;
                cd1=id;}
            if(c2<c3){
                i=c3;
                c3=c2;
                c2=i;
                id=cd3;
                cd3=cd2;
                cd2=id;}
            if(c3<c4){
                i=c4;
                c4=c3;
                c3=i;
                id=cd4;
                cd4=cd3;
                cd3=id;}
            if(c1<c2){
                i=c2;
                c2=c1;
                c1=i;
                id=cd2;
                cd2=cd1;
                cd1=id;}
            if(c2<c3){
                i=c3;
                c3=c2;
                c2=i;
                id=cd3;
                cd3=cd2;
                cd2=id;}
            if(c1<c2){
                i=c2;
                c2=c1;
                c1=i;
                id=cd2;
                cd2=cd1;
                cd1=id;}
            //判斷
            if(c1-c2==1&&c2-c3==1&&c3-c4==1&&c4-c5==1){
                if(cd1==cd2&&cd2==cd3&&cd3==cd4&&cd4==cd5)
                    printf("Straight flush\n");
                else
                    printf("Straight\n");
            }
            else if(c1-c2==1&&c2-c3==1&&c3-c4==1&&c1-c5==12){
                if(cd1==cd2&&cd2==cd3&&cd3==cd4&&cd4==cd5)
                    printf("Straight flush\n");
                else
                    printf("Straight\n");
            }
            else if(cd1==cd2&&cd2==cd3&&cd3==cd4&&cd4==cd5)
                printf("Flush\n");
            else if(c1==c2&&c2==c3&&c3==c4)
                printf("Four of a kind\n");
            else if(c5==c2&&c2==c3&&c3==c4)
                printf("Four of a kind\n");
            else if(c1==c2&&c2==c3){
                if(c4==c5)
                    printf("Full house\n");
                else
                    printf("Three of a kind\n");
            }
            else if(c5==c4&&c4==c3){
                if(c1==c2)
                    printf("Full house\n");
                else
                    printf("Three of a kind\n");
            }
           else if(c1==c2){
               if(c3==c4||c4==c5)
                   printf("Two pair\n");
               else
                   printf("One pair\n");
           }
           else if(c2==c3){
               if(c4==c5)
                   printf("Two pair\n");
               else
                   printf("One pair\n");
           }
           else if(c3==c4)
                   printf("One pair\n");
           else if(c4==c5)
                   printf("One pair\n");
          else
           printf("High card\n");
        }            
    }
    return 0;
}