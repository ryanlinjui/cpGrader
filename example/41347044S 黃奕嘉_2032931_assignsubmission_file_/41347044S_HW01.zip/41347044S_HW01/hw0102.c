#include<stdio.h>
#include<stdint.h>
int main(){
    int64_t x1=0;
    int8_t x2=0;
    int64_t x3=0;
    int8_t y1=0;
    int64_t y2=0;
    int8_t y3=0;
    int64_t sum=0;
    printf("Please enter the first operand : ");
    scanf(" %ld%c%ld",&x1,&x2,&x3); 
    printf("Please enter the second operand: ");
    scanf(" %c%ld%c",&y1,&y2,&y3);
    printf("Please enter the sum           : ");
    scanf(" %ld",&sum);   
    int32_t x=0,y=0,z=0;
    int32_t summax=0;
    int32_t summin=0;
    summin=x1*100+x3+10*y2;
    summax=x1*100+90+x3+900+10*y2+9;
    if(sum<summin||sum>summax||x1>=10||x1<0||x3>=10||x3<0||y2>=10||y2<0)
        printf("Wrong input\n");
    else{
        z=(sum-x3)%10;
        sum=sum-x3-z;
        x=(sum/10-y2)%10;
        sum=sum-10*(y2+x);
        y=(sum/100-x1)%10;
        printf("Ans:x=%d,y=%d,z=%d\n",x,y,z);            
    }
    return 0;
}