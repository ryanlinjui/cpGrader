#include<stdio.h>
#include<stdint.h>
int main(){
    uint16_t number=0;
    printf("Please enter an unsigned 16-bits number: ");
    scanf("%hd",&number);
    printf("Before Filp:\n");
    printf("%d_10=%o_8\n",number,number);
    int8_t six=number/8/8/8/8/8/8%8;
    int8_t five=number/8/8/8/8/8%8;
    int8_t four=number/8/8/8/8%8;
    int8_t three=number/8/8/8%8;
    int8_t two=number/8/8%8;
    int8_t one=number/8%8;
    int8_t zero=number%8;
    int8_t times=6;
    if(number/8/8/8/8/8/8==0)
        times-=1;
    if(number/8/8/8/8/8==0)
        times-=1;
    if(number/8/8/8/8==0)
        times-=1;
    if(number/8/8/8==0)
        times-=1;
    if(number/8/8==0)
        times-=1;
    if(number/8==0)
        times-=1;
    printf("After filp:\n");
    //printf("zero=%d,one=%d,%d,%d,%d,%d,%d,",zero,one,two,three,four,five,six);    
    uint32_t nwnum=0;
    if(times==6)
        nwnum=zero*8*8*8*8*8*8+one*8*8*8*8*8+two*8*8*8*8+three*8*8*8+four*8*8+five*8+six;
    if(times==5)
        nwnum=zero*8*8*8*8*8+one*8*8*8*8+two*8*8*8+three*8*8+four*8+five;
    if(times==4)
        nwnum=zero*8*8*8*8+one*8*8*8+two*8*8+three*8+four;
    if(times==3)
        nwnum=zero*8*8*8+one*8*8+two*8+three;
    if(times==2)
        nwnum=zero*8*8+one*8+two;
    if(times==1)
        nwnum=zero*8+one;
    if(times==0)
        nwnum=zero;
    printf("%o_8=%d_10\n",nwnum,nwnum);        
    return 0;
}