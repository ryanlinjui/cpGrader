#include <stdio.h>
#include <stdint.h>

int main()
{
    int32_t a;
    int32_t b;
    int32_t c;
    int32_t d;
    int32_t e;
    int32_t f;
    int32_t x;
    int32_t y;
    int32_t z;
    int32_t sum;
    char n;
    printf ("Please enter the first  operand: ");
    scanf ("%d%c%d%c",&d,&n,&f,&n);
    if( 0 < d && d < 10 && 0 < f && f < 10)
    {
        printf ("Please enter the second operand: ");
        scanf ("%c%d%c%c",&n,&e,&n,&n);
        if( 0 < e && e < 10)
        {
            printf ("Please enter sum               : ");
            scanf ("%d",&sum);
            if( sum > 1998|| sum < 0 )
            {
                printf("error\n");
            }
            else
            {
                a = sum %10;
                b = ( sum % 100)/10;
                c = sum/100;

                if(a<f)
                {
                    e = e+1;
                    z = a+10-f;
                }
                else
                {
                    z = a - f;
                }

                if(b<e)
                {
                    d = d+1;
                    x = b+10-e;
                }
                else
                {
                    x = b - e;
                }

                y = c-d;

                printf ("Ans: x = %d, y = %d, z = %d\n",x,y,z);
            }
        }
        else
        {
            printf("error\n");
        }
       
    }
    else
    {
        printf("error\n");
    }

    
    
    
    return 0;



}