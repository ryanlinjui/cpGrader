#include <stdio.h>
#include <stdint.h>

int main()
{
    int32_t n;
    int32_t a=0;
    int32_t b=0;
    int32_t c=0;
    int32_t d=0;
    int32_t e=0;
    int32_t f=0;
    int32_t i=0;

    printf ("Please enter an unsigned 16-bits:");
    scanf ("%d", &n);

    printf ("Before Flip:\n");
    printf ("%d_10 = ",n);
    if( n != 0 )
    {
        i=i+1;
        a = (n % 8);
        n=n/8;
        if( n != 0 )
        {
            i=i+1;
            b = (n % 8);
            n=n/8;
            if( n != 0 )
            {
                i=i+1;
                c = (n % 8);
                n=n/8;
                if( n != 0 )
                {
                    i=i+1;
                    d = (n % 8);
                    n=n/8;
                    if( n != 0 )
                    {
                        i=i+1;
                        e = (n % 8);
                        n=n/8;  
                        if( n != 0 )
                    
                        {
                            i=i+1;
                            f = (n % 8);
                            n=n/8;
                        }
                    }
                }
            }
        }
        
    }
    
    

    switch (i)
    {
        case 6:
            printf ("%d", f);
        case 5:
            printf ("%d", e);
        case 4:
            printf ("%d", d);
        case 3:
            printf ("%d", c);
        case 2:
            printf ("%d", b);
        case 1:
            printf ("%d", a);
    }

    printf ("_8\n");
    printf ("After Flip:\n");

    switch (i)
    {
        case 6:
            printf ("%d%d%d%d%d%d",a,b,c,d,e,f);
            break;
        case 5:
            printf ("%d%d%d%d%d",a,b,c,d,e );
            break;
        case 4:
            printf ("%d%d%d%d",a,b,c,d);
            break;
        case 3:
            printf ("%d%d%d",a,b,c );
            break;
        case 2:
            printf ("%d%d",a,b );
            break;
        case 1:
            printf ("%d",a );
    }
    printf ("_8 = ");

    switch (i)
    {
        case 6:
            n=(((((a*8)+b)*8+c)*8+d)*8)+f;
            printf ("%d",n);
            break;
        case 5:
            n=((((a*8)+b)*8+c)*8+d)*8;
            printf ("%d",n );
            break;
        case 4:
            n=(((a*8)+b)*8+c)*8+d;
            printf ("%d",n);
            break;
        case 3:
            n=((a*8)+b)*8+c;
            printf ("%d",n);
            break;
        case 2:
            n=(a*8)+b;
            printf ("%d",n);
            break;
        case 1:
            n=a*8;
            printf ("%d",n );
    }

    printf ("_10\n");
    //printf ("After Flip:\n%d_8 = %d_10\n",b,e);

    return 0 ;


}
