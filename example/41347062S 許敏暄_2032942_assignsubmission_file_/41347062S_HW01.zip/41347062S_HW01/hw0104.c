#include <stdio.h>
#include <stdint.h>

int main()
{
    int32_t a ;
    int32_t b ;
    int32_t c ;
    int32_t d ;
    int32_t e ;
    int32_t k ;
    char x ;
    int32_t num1 ;
    int32_t num2 ;
    int32_t num3 ;
    int32_t num4 ;
    int32_t num5 ;
    int32_t cl1 ;
    int32_t cl2 ;
    int32_t cl3 ;
    int32_t cl4 ;
    int32_t cl5 ;

    printf("Please enter 5 cards: ");
    scanf("%d%c%d%c%d%c%d%c%d",&a,&x,&b,&x,&c,&x,&d,&x,&e);


    //error
    if(a == b || a == c || a == d || a == e )
    {
        printf("error\n");
        return 0 ;
    }
    else
    {
        if( b == c || b == d || b == e )
        {
        printf("error\n");
        return 0 ;
        }
        else
        {
            if(c == d || c == e )
            {
                printf("errorn\n");
                return 0 ;
            }  
            else
            {
                if(d == e )
                {
                printf("error\n");
                return 0 ;
                }
            }
        }
    }

    


    //ckeck
    //printf("original:%d,%d,%d,%d,%d\n",a,b,c,d,e);////
     

    num1 = a;
    num2 = b;
    num3 = c;
    num4 = d;
    num5 = e;

    


    switch (a)
    {
        case 1: case 2: case 3: case 4: case 5:
        case 6: case 7: case 8: case 9: case 10:
        case 11: case 12: case 13:
            cl1 = 1;
            break;
        
        case 14: case 15: case 16: case 17: case 18:
        case 19: case 20: case 21: case 22: case 23:
        case 24: case 25: case 26:
            cl1 = 2;
            break;

        case 27: case 28: case 29: case 30: case 31:
        case 32: case 33: case 34: case 35: case 36:
        case 37: case 38: case 39:
            cl1 = 3;
            break;

        case 40: case 41: case 42: case 43: case 44:
        case 45: case 46: case 47: case 48: case 49:
        case 50: case 51: case 52:
            cl1 = 4;
            break;

    }

    switch (b)
    {
        case 1: case 2: case 3: case 4: case 5:
        case 6: case 7: case 8: case 9: case 10:
        case 11: case 12: case 13:
            cl2 = 1;
            break;
        
        case 14: case 15: case 16: case 17: case 18:
        case 19: case 20: case 21: case 22: case 23:
        case 24: case 25: case 26:
            cl2 = 2;
            break;

        case 27: case 28: case 29: case 30: case 31:
        case 32: case 33: case 34: case 35: case 36:
        case 37: case 38: case 39:
            cl2 = 3;
            break;

        case 40: case 41: case 42: case 43: case 44:
        case 45: case 46: case 47: case 48: case 49:
        case 50: case 51: case 52:
            cl2 = 4;
            break;

    }

    switch (c)
    {
        case 1: case 2: case 3: case 4: case 5:
        case 6: case 7: case 8: case 9: case 10:
        case 11: case 12: case 13:
            cl3 = 1;
            break;
        
        case 14: case 15: case 16: case 17: case 18:
        case 19: case 20: case 21: case 22: case 23:
        case 24: case 25: case 26:
            cl3 = 2;
            break;

        case 27: case 28: case 29: case 30: case 31:
        case 32: case 33: case 34: case 35: case 36:
        case 37: case 38: case 39:
            cl3 = 3;
            break;

        case 40: case 41: case 42: case 43: case 44:
        case 45: case 46: case 47: case 48: case 49:
        case 50: case 51: case 52:
            cl3 = 4;
            break;

    }
    switch (d)
    {
        case 1: case 2: case 3: case 4: case 5:
        case 6: case 7: case 8: case 9: case 10:
        case 11: case 12: case 13:
            cl4 = 1;
            break;
        
        case 14: case 15: case 16: case 17: case 18:
        case 19: case 20: case 21: case 22: case 23:
        case 24: case 25: case 26:
            cl4 = 2;
            break;

        case 27: case 28: case 29: case 30: case 31:
        case 32: case 33: case 34: case 35: case 36:
        case 37: case 38: case 39:
            cl4 = 3;
            break;

        case 40: case 41: case 42: case 43: case 44:
        case 45: case 46: case 47: case 48: case 49:
        case 50: case 51: case 52:
            cl4 = 4;
            break;

    }
    switch (e)
    {
        case 1: case 2: case 3: case 4: case 5:
        case 6: case 7: case 8: case 9: case 10:
        case 11: case 12: case 13:
            cl5 = 1;
            break;
        
        case 14: case 15: case 16: case 17: case 18:
        case 19: case 20: case 21: case 22: case 23:
        case 24: case 25: case 26:
            cl5 = 2;
            break;

        case 27: case 28: case 29: case 30: case 31:
        case 32: case 33: case 34: case 35: case 36:
        case 37: case 38: case 39:
            cl5 = 3;
            break;

        case 40: case 41: case 42: case 43: case 44:
        case 45: case 46: case 47: case 48: case 49:
        case 50: case 51: case 52:
            cl5 = 4;
            break;

    }



    //check
    //printf("sort color:%d,%d,%d,%d,%d\n",cl1,cl2,cl3,cl4,cl5);/////////
    



    a = a%13;
    b = b%13;
    c = c%13;
    d = d%13;
    e = e%13;

    //printf("The persent:%d,%d,%d,%d,%d\n",a,b,c,d,e);


    if(a==0)
    {
        a=a+13;
    }
    if(b==0)
    {
        b=b+13;
    }
    if(c==0)
    {
        c=c+13;
    }
    if(d==0)
    {
        d=d+13;
    }
    if(e==0)
    {
        e=e+13;
    }


    //check
    //printf("The after persent:%d,%d,%d,%d,%d\n",a,b,c,d,e);




    if(a > b)
    {
        switch(1)
        {
            case 1:
                k = a; a = b; b = k;
                k = cl1; cl1 = cl2; cl2 = k;
                break;
        }
    }

    if(a > c)
    {
        switch(1)
        {
            case 1:
                k = a; a = c; c = k;
                k = cl1; cl1 = cl3; cl3 = k;
                break;
        }
    }

    if(a > d)
    {
        switch(1)
        {
            case 1:
                k = a; a = d; d = k;
                k = cl1; cl1 = cl4; cl4 = k;
                break;
        }
    }

    if(a > e)
    {
        switch(1)
        {
            case 1:
                k = a; a = e; e = k;
                k = cl1; cl1 = cl5; cl5 = k;
                break;
        }
    }
    //
    if(b > c)
    {
        switch(1)
        {
            case 1:
                k = b; b = c; c = k;
                k = cl2; cl2 = cl3; cl3 = k;
                break;
        }
    }

    if(b > d)
    {
        switch(1)
        {
            case 1:
                k = b; b = d; d = k;
                k = cl2; cl2 = cl4; cl4 = k;
                break;
        }
    }

    if(b > e)
    {
        switch(1)
        {
            case 1:
                k = b; b = e; e = k;
                k = cl2; cl2 = cl5; cl5 = k;
                break;
        }
    }

    //
    if(c > d)
    {
        switch(1)
        {
            case 1:
                k = c; c = d; d = k;
                k = cl3; cl3 = cl4; cl4 = k;
                break;
        }
    }

    if(c > e)
    {
        switch(1)
        {
            case 1:
                k = c; c = e; e = k;
                k = cl3; cl3 = cl5; cl5 = k;
                break;
        }
    }
    //
    if(d > e)
    {
        switch(1)
        {
            case 1:
                k = d; d = e; e = k;
                k = cl4; cl4 = cl5; cl5 = k;
                break;
        }
    }


    //check
    //printf("sequence ans:%d,%d,%d,%d,%d\n",a,b,c,d,e);//////
    //printf("fellow color:%d,%d,%d,%d,%d\n",cl1,cl2,cl3,cl4,cl5);/////////






    
    if( a==1 && b==2 && c==11 && d==12 && e==13 )
    {
        if(cl1==cl2 && cl2==cl3 && cl3==cl4 && cl4==cl5)
        {
            printf("Flush\n");
            return 0;
        }
        else
        {
            printf("High card\n");
            return 0;
        }
    }
    else
    {
        if( a==1 && b==2 && c==3 && d==12 && e==13 )
        {
            if(cl1==cl2 && cl2==cl3 && cl3==cl4 && cl4==cl5)
            {
                printf("Flush\n");
                return 0;
            }
            else
            {
                printf("High card\n");
                return 0;
            }
        }
        else
        {
            if( a==1 && b==2 && c==3 && d==4 && e==13 )
            {
                if(cl1==cl2 && cl2==cl3 && cl3==cl4 && cl4==cl5)
                {
                    printf("Flush\n");
                    return 0;
                }
                else
                {
                    printf("High card\n");
                    return 0;
                }
            }
        }
    }




    if( cl1==cl2 && cl2==cl3 && cl3==cl4 && cl4==cl5 )
    {
        if( a==1 && b==10 && c==11 && d==12 && e==13 )
        {
            printf("Straigh Flash\n");
        }
        else
        {
            if(b-a==c-b==d-c==e-d==1)
            {
                printf("Straight Flash\n");
            }
            else
            {
                printf("Flash\n");
            }
        }
    }
    else
    {
        if( a==1 && b==10 && c==11 && d==12 && e==13 )
        {
            printf("Straigh\n");
        }
        else
        {
            if(b-a==1&&c-b==1&&d-c==1&&e-d==1)
            {
                printf("Straigh\n");
                printf("yes\n");
            }
            else
            {
                if( (a==b==c==d )||(b==c==d==e))
                {
                    printf("Four of a kind\n");

                }
                else
                {
                    if(a==b&&b==c&&a==c&&d==e ||a==b && c==d&&d==e&&c==e)
                    {
                        printf("Full house \n");
                    }
                    else
                    {
                        if((a==b&&b==c&&a==c&&d!=e)||(d==b&&b==c&&d==c&&a!=e)||(d==e&&e==c&&d==c&&a!=b))
                        {
                            printf("Three of a kind\n");
                        }
                        else
                        {
                            if((a==b&&d==c&&a!=e&&d!=e)||(a==b&&d==e&&d!=e&&a!=e)||(d==e&&b==c&&d!=a&&a!=b))
                            {
                                printf("Two pair\n");
                            }
                            else
                            {
                                if((a==b&&c!=d&&d!=e&&c!=a&&d!=a&&e!=a)||(c==b&&a!=d&&d!=e&&a!=c&&d!=c&&e!=c)||(c==d&&a!=b&&b!=e&&a!=c&&b!=c&&e!=c)||(e==d&&a!=b&&b!=c&&a!=e&&b!=e&&c!=e))
                                {
                                    printf("One pair\n");
                                }
                                else
                                {
                                    printf("High card");
                                }
                            }
                        }
                    }
                }

            }
        }
    }

    





    return 0;

}
