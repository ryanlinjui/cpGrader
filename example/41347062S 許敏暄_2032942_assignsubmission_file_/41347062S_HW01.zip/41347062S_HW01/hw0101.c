#include<stdio.h>

int main()
{
    printf("\e[1;31m[KIM]\n\
You are sunlight and I moon\n\
Joined by the gods of fortune\n\
Midnight and high noon sharing the sky\n\
We have been blessed , you and I\n\n\e[m");
//31red[KIM];32green;34blue[CHRIS];
    printf("\e[1;34m[CHRIS]\n\
You are here like a mystery\n\
I'm from a world that's so different from all that you are\n\
How in the light of one night did we come so far?\n\n\e[m");

    printf("\e[1;31m[KIM]\n\
Outside day starts to dawn\n\n\e[m");

    printf("\e[1;34m[CHRIS]\n\
Your moon still floats on high\n\n\e[m");

    printf("\e[1;31m[KIM]\n\
The birds awake\n\n\e[m");

    printf("\e[1;34m[CHRIS]\n\
The stars shine too\n\n\e[m");

    printf("\e[1;31m[KIM]\n\
My hands still shake\n\
See upcoming pop shows\n\
Get tickets for your favorite artists\n\n\
You might also like\n\
My Boy Only Breaks His Favorite Toys\n\
Taylor Swift\n\
Who’s Afraid of Little Old Me?\n\
Taylor Swift\n\
Guilty as Sin?\n\
Taylor Swift\n\n\e[m");
//31red[KIM];32green;34blue[CHRIS];
    printf("\e[1;34m[CHRIS]\n\
I reach for you\n\n\e[m");

    printf("\e[1;32m[KIM & CHRIS]\n\
And we meet in the sky\n\n\e[m");

    printf("\e[1;31m[KIM]\n\
You are sunlight and I moon\n\
Joined heren\n\
Brightening the sky with the flame of love\n\n\e[m");

    printf("\e[1;32m[KIM & CHRIS]\n\
Made of\n\
Sunlight\n\
Moonlight\n\n\e[m");


    return 0;
}