#include <stdio.h>
#include<stdint.h>

int main()
{
    int32_t a;
    int32_t a1;
    int32_t b;
    int32_t c;
    int32_t d;
    int32_t e;
    int32_t f;
    int32_t g;
    int32_t h;
    int32_t i;
    int32_t j;
    int32_t k;
    int32_t l;
    int32_t m;
    int32_t n;
    int32_t o;
    int32_t p;
    int32_t q;

    int32_t ui;
    int32_t exp;
    double F;

    int32_t x;

    
    int32_t hexn;

    
    printf("Please input a hex:");
    scanf("%X",&a);
    //printf("%d\n",a);
    printf("Please choose the output type(1:intiger,2:unsigned intiger,3:float):");
    scanf("%d",&x);

    //////
    if(x !=1&& x!=2 && x!=3)
    {
        printf ("error\n");
        return 0;
    }
    
    //////

    a1=a;
    

    b=a1%2;
    a1=a1/2;

    c=a1%2;
    a1=a1/2;

    d=a1%2;
    a1=a1/2;

    e=a1%2;
    a1=a1/2;

    f=a1%2;///////
    a1=a1/2;

    g=a1%2;
    a1=a1/2;

    h=a1%2;
    a1=a1/2;

    i=a1%2;
    a1=a1/2;

    j=a1%2;////////
    a1=a1/2;

    k=a1%2;
    a1=a1/2;

    l=a1%2;
    a1=a1/2;

    m=a1%2;
    a1=a1/2;

    n=a1%2;///////
    a1=a1/2;

    o=a1%2;
    a1=a1/2;

    p=a1%2;
    a1=a1/2;

    q=a1%2;
    a1=a1/2;

    printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",a,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b);

    if(x==2)
    {
        ui=((((((((((((((q*2+p)*2+o)*2+n)*2+m)*2+l)*2+k)*2+j)*2+i)*2+h)*2+g)*2+f)*2+e)*2+d)*2+c)*2+b;
        printf("Converted unsigned integer is: %d",ui);
    }
    else if(x==1)
    {
        if(q==1)
        {
            if (b==1)
            {
                b=0;
            }
            else
            {
                b=1;
            }
            if (c==1)
            {
                c=0;
            }
            else
            {
                c=1;
            }
            if (d==1)
            {
                d=0;
            }
            else
            {
                d=1;
            }
            if (e==1)
            {
                e=0;
            }
            else
            {
                e=1;
            }
            if (f==1)
            {
                f=0;
            }
            else
            {
                f=1;
            }
            if (g==1)
            {
                g=0;
            }
            else
            {
                g=1;
            }
            if (h==1)
            {
                h=0;
            }
            else
            {
                h=1;
            }
            if (i==1)
            {
                i=0;
            }
            else
            {
                i=1;
            }
            if (j==1)
            {
                j=0;
            }
            else
            {
                j=1;
            }
            if (k==1)
            {
                k=0;
            }
            else
            {
                k=1;
            }
            if (l==1)
            {
                l=0;
            }
            else
            {
                l=1;
            }
            if (m==1)
            {
                m=0;
            }
            else
            {
                m=1;
            }
            if (n==1)
            {
                n=0;
            }
            else
            {
                n=1;
            }
            if (o==1)
            {
                o=0;
            }
            else
            {
                o=1;
            }
            if (p==1)
            {
                p=0;
            }
            else
            {
                p=1;
            }
            if (q==1)
            {
                q=0;
            }
            else
            {
                q=1;
            }
        
            //printf("check1: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b);
            b+=1;


            if(b==2)
            {
                b=0;
                c+=1;
                if(c==2)
                {
                    c=0;
                    d+=1;
                    if(d==2)
                    {
                        d=0;
                        e+=1;
                        if(e==2)
                        {
                            e=0;
                            f+=1;
                            if(f==2)
                            {
                                f=0;
                                g+=1;
                                if(g==2)
                                {
                                    g=0;
                                    h+=1;
                                    if(h==2)
                                    {
                                        h=0;
                                        i+=1;
                                        if(i==2)
                                        {
                                            i=0;
                                            j+=1;
                                            if(j==2)
                                            {
                                                j=0;
                                                k+=1;
                                                if(k==2)
                                                {
                                                    k=0;
                                                    l+=1;
                                                    if(l==2)
                                                    {
                                                        l=0;
                                                        m+=1;
                                                        if(m==2)
                                                        {
                                                            m=0;
                                                            n+=1;
                                                            if(n==2)
                                                            {
                                                                n=0;
                                                                o+=1;
                                                                if(o==2)
                                                                {
                                                                    o=0;
                                                                    p+=1;
                                                                    if(p==2)
                                                                    {
                                                                        p=0;
                                                                        q+=1;
                                                                        if(q==2)
                                                                        {
                                                                            q=0;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            //printf("check2: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n",q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b);
            ui=((((((((((((((q*2+p)*2+o)*2+n)*2+m)*2+l)*2+k)*2+j)*2+i)*2+h)*2+g)*2+f)*2+e)*2+d)*2+c)*2+b;
            printf("Converted signed integer is: -%d\n",ui);


        }
        else
        {
            ui=((((((((((((((q*2+p)*2+o)*2+n)*2+m)*2+l)*2+k)*2+j)*2+i)*2+h)*2+g)*2+f)*2+e)*2+d)*2+c)*2+b;
            printf("Converted signed integer is: %d\n",ui); 
        }




    }
    else if(x=3)
    {
        exp=((((p*2+o)*2+n)*2+m)*2+l)-15;
        F=(((((((((b* 0.5 +c)* 0.5+d)* 0.5 +e)* 0.5 +f)* 0.5 +g)* 0.5 +h)* 0.5 +i)*0.5+j)*0.5+k)*0.5+1;
        //printf("check3: %d %d %d %d %d %d %d %d %d %d\n",k,j,i,h,g,f,e,d,c,b);
        //printf("test:%f\n",F);
        if(exp==0&&F==0)
        {
            if(q==1)
            {
                printf("Converted float is:-0.0\n");
            }
            else
            {
                printf("Converted float is:+0.0\n");
            }
        }
        else if(exp==31&&F==0)
        {
            if(q==1)
            {
                printf("Converted float is:-INF\n");
            }
            else
            {
                printf("Converted float is:+INF\n");
            }
        }
        else if(exp==31&&F!=0)
        {
            printf("Converted float is:NAN\n");
        }

        else if(q==1)
        {
            printf("Converted float is: -%f*2^%d\n",F,exp);
        }
        else
        {
            printf("Converted float is: %f*2^%d\n",F,exp);
        }
    }

    
    











    return 0;
}