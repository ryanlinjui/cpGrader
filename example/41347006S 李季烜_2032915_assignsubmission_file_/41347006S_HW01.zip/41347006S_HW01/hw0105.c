#include <stdio.h>
#include <stdint.h>

int main()
{
	uint16_t input = 0;
	uint16_t type = 0;
	printf("Please input a hex: ");
	if (!scanf("%hx", &input))
		{ printf("\e[38;5;9mInvalid Input (for the hex value)\n"); return 0; }
	printf("Please choose the output type(1:interger,2:unsigned integer,3:float): ");
	if (scanf("%hu", &type))
	{
		if (type > 3 || type == 0)
			{ printf("\e[38;5;9mINvalid Input (for type is not 1, 2, or 3)\n"); return 0; }
	}
	else
		{ printf("\e[38;5;9mInvalid Input (for the type value = %hu)\n", type); return 0; }
	uint16_t binary1 = 0, binary2 = 0, binary3 = 0, binary4 = 0;
	if (input >= 32768)
		{ binary1 += 1000 * (input / 32768); }
	if (input >= 16384)
		{ binary1 += 100 * ((input / 16384) % 2); }
	if (input >= 8192)
		{ binary1 += 10 * ((input / 8192) % 2); }
	if (input >= 4096)
		{ binary1 += 1 * ((input / 4096) % 2); }
	if (input >= 2048)
		{ binary2 += 1000 * ((input / 2048) % 2); }
	if (input >= 1024)
		{ binary2 += 100 * ((input / 1024) % 2); }
	if (input >= 512)
		{ binary2 += 10 * ((input / 512) % 2); }
	if (input >= 256)
		{ binary2 += 1 * ((input / 256) % 2); }
	if (input >= 128)
		{ binary3 += 1000 * ((input / 128) % 2); }
	if (input >= 64)
		{ binary3 += 100 * ((input / 64) % 2); }
	if (input >= 32)
		{ binary3 += 10 * ((input / 32) % 2); }
	if (input >= 16)
		{ binary3 += 1 * ((input / 16) % 2); }
	if (input >= 8)
		{ binary4 += 1000 * ((input / 8) % 2); }
	if (input >= 4)
		{ binary4 += 100 * ((input / 4) % 2); }
	if (input >= 2)
		{ binary4 += 10 * ((input / 2) % 2); }
	if (input >= 1)
		{ binary4 += 1 * (input % 2); }
	printf("Binary of %hx is: %.4hu %.4hu %.4hu %.4hu\n", input, binary1, binary2, binary3, binary4);
	if (type == 1)
		{ printf("Converted integer is: %hd\n", input); return 0; }
	if (type == 2)
		{ printf("Converted unsigned integer is: %hu\n", input); return 0; }
	uint16_t S = 0, F = 0;
	int16_t EXP = 0;
	S = input / 32748;
	EXP = input / 1024 % 32;
	F = input % 1024 + 1024;
	float FValue = F / 1024.0;
	//printf("S = %hu, EXP = %hd, F = %hu\n", S, EXP, F);
	if (S) // negative
	{
		if (EXP == 0 && F == 1024)
			printf("Converted float is: -0\n");
		else if (EXP == 31)
		{
			if (F == 1024)
				printf("Converted float is: -INF\n");
			else
				printf("Converted flaot is: NAN\n");
		}
		else
			printf("Converted float is: -%f*2^%hd\n", FValue, EXP - 15);
	}
	else // positive
	{
		if (EXP == 0 && F == 1024)
			printf("Converted float is: +0\n");
		else if (EXP == 31)
		{
			if (F == 1024)
				printf("Converted float is +INF\n");
			else
				printf("Converted float is NAN\n");
		}
		else
			printf("Converted float is +%f*2^%hd\n", FValue, EXP - 15);
	}
	return 0;
}