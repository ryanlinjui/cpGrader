#include <stdio.h>
#include <stdint.h>

int main()
{
	printf("\e[38;5;9m");
	printf("[KIM]\nYou are sumlight and I moon\n");
	printf("Joined by the gods of fortune\n");
	printf("Midnight and high noon sharing the sky\n");
	printf("We have been blessed, you and I\n");
	printf("\n\e[38;5;12m"); 
	printf("[CHRIS]\nYou are here like a mystery\n");
	printf("I'm from a world that's so different from all that youare\n");
	printf("How in the light of one night did we come so far?\n");
	printf("\n\e[38;5;9m");
	printf("[KIM]\nOutside day starts to dawn\n");
	printf("\n\e[38;5;12m");
	printf("[CHRIS]\nYour moon still floats on high\n");
	printf("\n\e[38;5;9m");
	printf("[KIM]\nThe birds awake\n");
	printf("\n\e[38;5;12m");
	printf("[CHRIS]\nThe stars shine too\n");
	printf("\n\e[38;5;9m");
	printf("[KIM]\nMy hands still shake\nSee upcoming pop shows\n");
	printf("Get tickets for your favorite artists\n\n");
	printf("You might also like\nMy Boy Only Breaks His Favorite Toys\n");
	printf("Taylor Swift\nWho's Afraid of Little Old Me?\n");
	printf("Taylor Swift\nGuilty as Sin?\nTaylor Swift\n");
	printf("\n\e[38;5;12m");
	printf("[CHRIS]\nI reach for you\n");
	printf("\n\e[38;5;10m");
	printf("[KIM & CHRIS]\nAnd we meet in the sky\n");
	printf("\n\e[38;5;9m");
	printf("[KIM]\nYou are sunlight and I moon\nJoined here\n");
	printf("Brightening the sky with the flame of love\n");
	printf("\n\e[38;5;10m");
	printf("[KIM & CHRIS]\nMade of\nSunlight\nMoonlight\n");
	return 0;
}