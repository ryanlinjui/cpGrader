#include <stdio.h>
#include <stdint.h>

int main()
{
	uint8_t invalid = 0;
	int32_t hundreds = 0, tens = 0, ones = 0, sum = 0;
	printf("Please enter the first  operand: ");
	if (scanf("%dx%d", &hundreds, &ones) == 2)
	{
		if (hundreds < 0 || hundreds > 9)
			{ printf("\e[38;5;9mInvalid Input! (for hundreds)\n"); return 0; }
		else if (ones < 0 || ones > 9)
			{ printf("\e[38;5;9mInvalid Input! (for ones)\n"); return 0; }
	}
	else
		{ printf("\e[38;5;9mInvalid Input! (for first operand)\n"); return 0; }
	printf("Please enter the second operand: ");
	if (scanf("\ny%dz", &tens))
	{
		if (tens < 0 || tens > 9)
			{ printf("\e[38;5;9mInvalid Input! (for tens)\n"); return 0; }
	}
	else
		{ printf("\e[38;5;9mInvalid Input! (for second operand)\n"); return 0; }
	printf("Please enter the sum           : ");
	if (scanf("\n%d", &sum))
	{
		if (sum > 1998 || sum < 0)
			{ printf("\e[38;5;9mInvalid Input! (for value of sum)\n"); return 0; }
	}
	else
		{ printf("\e[38;5;9mInvalid Input! (for sum)\n"); return 0; }
	
	sum = sum - hundreds * 100 - tens * 10 - ones;
	if (sum > 999 || sum < 0)
		{ printf("\e[38;5;9mInvalid Input! (for answers are not 0-9)\n"); return 0; }
	ones = sum % 10;
	sum /= 10;
	tens = sum % 10;
	hundreds = sum / 10;
	printf("Ans: x = %d, y = %d, z = %d\n", tens, hundreds, ones);
	return 0;
}