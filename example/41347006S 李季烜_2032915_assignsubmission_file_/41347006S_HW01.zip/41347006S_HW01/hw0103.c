#include <stdio.h>
#include <stdint.h>

int main()
{
	uint16_t input = 0;
	printf("Please enter an unsigned 16-bits number: ");
	if (!scanf("%hu", &input))
		{ printf("\e[38;5;9mInvaild Input (format not allowed)\n"); return 0; }
	printf("Before Flip:\n%u_10 = ", input);
	uint32_t octal = 0;
	octal += input % 8; input /= 8;
	octal += 10 * (input % 8); input /= 8;
	octal += 100 * (input % 8); input /= 8;
	octal += 1000 * (input % 8); input /= 8;
	octal += 10000 * (input % 8); input /= 8;
	octal += 100000 * input;
	printf("%d_8\n", octal);
	int32_t flipOctal = 0;
	if (octal != 0)
		{ flipOctal = flipOctal * 10 + octal % 10; octal /= 10; }
	if (octal != 0)
		{ flipOctal = flipOctal * 10 + octal % 10; octal /= 10; }
	if (octal != 0)
		{ flipOctal = flipOctal * 10 + octal % 10; octal /= 10; }
	if (octal != 0)
		{ flipOctal = flipOctal * 10 + octal % 10; octal /= 10; }
	if (octal != 0)
		{ flipOctal = flipOctal * 10 + octal % 10; octal /= 10; }
	if (octal != 0)
		{ flipOctal = flipOctal * 10 + octal % 10; octal /= 10; }
	printf("After  Flip:\n%d_8 = ", flipOctal);
	int32_t flip = 0;
	flip += flipOctal % 10; flipOctal /= 10;
	flip += 8 * (flipOctal % 10); flipOctal /= 10;
	flip += 64 * (flipOctal % 10); flipOctal /= 10;
	flip += 512 * (flipOctal % 10); flipOctal /= 10;
	flip += 4096 * (flipOctal % 10); flipOctal /= 10;
	flip += 32768 * (flipOctal % 10); flipOctal /= 10;
	flip += 262144 * flipOctal;
	printf("%d_10\n", flip);
	return 0;
}