#include <stdio.h>
#include <stdint.h>

int main()
{
	uint8_t cardA = 0;
	uint8_t cardB = 0;
	uint8_t cardC = 0;
	uint8_t cardD = 0;
	uint8_t cardE = 0;
	printf("Please enter 5 cards: ");
	if (scanf("%hhu %hhu %hhu %hhu %hhu", &cardA, &cardB, &cardC, &cardD, &cardE) == 5)
	{
		if (cardA == 0 || cardA > 52)
			{ printf("\e[38;5;9mInvalid Input! (1-st card unknown)\n"); return 0; }
		else if (cardB == 0 || cardB > 52)
			{ printf("\e[38;5;9mInvalid Input! (2-nd card unknown)\n"); return 0; }
		else if (cardC == 0 || cardC > 52)
			{ printf("\e[38;5;9mInvalid Input! (3-rd card unknown)\n"); return 0; }
		else if (cardD == 0 || cardD > 52)
			{ printf("\e[38;5;9mInvalid Input! (4-th card unknown)\n"); return 0; }
		else if (cardE == 0 || cardE > 52)
			{ printf("\e[38;5;9mInvalid Input! (5-th card unknown)\n"); return 0; }
	}
	else
		{ printf("\e[38;5;9mInvalid Input! (format not allowed)\n"); return 0; }
	if (cardA == cardB || cardA == cardC || cardA == cardD || cardA == cardE ||
		cardB == cardC || cardB == cardD || cardB == cardE ||
		cardC == cardD || cardC == cardE || cardD == cardE)
		{ printf("\e[38;5;9mInvalid Input! (same cards detected)\n"); return 0; }
	cardA -= 1;
	cardB -= 1;
	cardC -= 1;
	cardD -= 1;
	cardE -= 1;
	// Arrange
	uint8_t numA = cardA % 13;
	uint8_t numB = cardB % 13;
	uint8_t numC = cardC % 13;
	uint8_t numD = cardD % 13;
	uint8_t numE = cardE % 13;
	uint8_t temp = 0;
	//printf("Card Num: %d %d %d %d %d\n", numA, numB, numC, numD, numE);
	if (numB > numA && numB > numC && numB > numD && numB > numE)
		{ temp = cardB; cardB = cardA; cardA = temp; }
	else if (numC > numA && numC > numD && numC > numE)
		{ temp = cardC; cardC = cardA; cardA = temp; }
	else if (numD > numA && numD > numE)
		{ temp = cardD; cardD = cardA; cardA = temp; }
	else if (numE > numA)
		{ temp = cardE; cardE = cardA; cardA = temp; }
	numB = cardB % 13;
	numC = cardC % 13;
	numD = cardD % 13;
	numE = cardE % 13;	
	if (numC > numB && numC > numD && numC > numE)
		{ temp = cardC; cardC = cardB; cardB = temp; }
	else if (numD > numB && numD > numE)
		{ temp = cardD; cardD = cardB; cardB = temp; }
	else if (numE > numB)
		{ temp = cardE; cardE = cardB; cardB = temp; }
	numC = cardC % 13;
	numD = cardD % 13;
	numE = cardE % 13;
	if (numD > numC && numD > numE)
		{ temp = cardD; cardD = cardC; cardC = temp; }
	else if (numE > numC)
		{ temp = cardE; cardE = cardC; cardC = temp; }
	numD = cardD % 13;
	numE = cardE % 13;
	if (numE > numD)
		{ temp = cardE; cardE = cardD; cardD = temp; }
	numA = cardA % 13; uint8_t kindA = cardA / 13;
	numB = cardB % 13; uint8_t kindB = cardB / 13;
	numC = cardC % 13; uint8_t kindC = cardC / 13;
	numD = cardD % 13; uint8_t kindD = cardD / 13;
	numE = cardE % 13; uint8_t kindE = cardE / 13;
	//printf("Card Num: %d %d %d %d %d\n", numA, numB, numC, numD, numE);
	uint8_t pairs = (numA == numB) + (numB == numC) + (numC == numD) + (numD == numE);
	// Stright Flush
	if (kindA == kindE && cardA == cardB + 1 && cardA == cardC + 2 && cardA == cardD + 3 && (cardA == cardE + 4 || cardA == cardE + 12))
		{ printf("Stright Flush\n"); return 0; }
	// Four of a Kind
	//if (numB == numC && numB == numD &&	( numB == numA || numB == numE))
	if (pairs == 3)
		if (numB == numD)
			{ printf("Four of a Kind\n"); return 0; }
	// Full House
	//if ((numA == numB && numA == numC && numD == numE) || (numA == numB && numC == numD && numC == numE))
		else
			{ printf("Full House\n"); return 0; }
	// Flush
	if (kindA == kindB && kindA == kindC && kindA == kindD && kindA == kindE)
		{ printf("Flush\n"); return 0; }
	// Stright
	if (numA == numB + 1 && numA == numC + 2 && numA == numD + 3 && (numA == numE + 4 || numA == numE + 12))
		{ printf("Stright\n"); return 0; }
	// Three of a Kind
	//if ((numA == numB && numA == numC) || (numB == numC && numC == numD) || (numC == numE && numC == numD))
	if (pairs == 2)
		if (numA == numC || numB == numD || numC == numE)
			{ printf("Three of a Kind\n"); return 0; }
	// Two Pair
		else
			{ printf("Two Pair\n"); return 0; }
	if (pairs == 1)
		{ printf("One Pair\n"); return 0; }
	printf("High Card\n");
	return 0;
}