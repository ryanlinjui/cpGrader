# README for my first homework
## Student Information
- student id - 41347006S
- student name - Li, Ji Syuan (I can't type chinese on Ubuntu)
## Makefile
- use `make` to make all the files
- use `make clean` to clean the files made
## Problem 1
- there is nothing special
- use `./hw0101` to execute the program
- it will print lyrics of the song *Sun and Moon* from the musical *Miss Saigon*
- lyrics for [KIM] will be red, while those for [CHRIS] will be blue
- lyrics for [KIM & CHRIS] will be green
- Enjoy it!
## Problem 2
- it will calculate the value for the equation given, and output the solution for x, y, and z
- use `./hw0102` to execute the program
- for input, follow the following step
	- <int> can be any interger from 0 to 9
	- please enter `<int>x<int>` first
	- please then enter `y<int>z`
	- please enter `<int><int><int>` at the end
- there are several conditions that could cause an invalid input
	- <int> is not from 0 to 9
	- the pattern provided is not allowed
	- the answers for y * 100 + x * 10 + z is less than 0
## Problem 3
- use `./hw0103` to execute the program
- what will this program do?
	- it will tell you the octal form of the number you enter
	- it will tell you the exact number after flip the octal form of the number
- how to input?
	- input a number from 0 to 65535 and press enter
	- that it!
## Problem 4
- use `./hw0104` to execute the program
- what will this program do?
	- it will recognize what pattern do the entered 5 cards form
	- aviliable patterns are (regarding the rank)
		- Straight Flush
		- Four of a Kind
		- Full House
		- Flush
		- Straight
		- Three of a Kind
		- Two Pair
		- One Pair
		- High Card
- how to input?
	- enter 5 cards in a line
	-  1 to 13 stands for spade   A to K
	- 14 to 26 stands for heart   A to K
	- 27 to 39 stands for diamond A to K
	- 40 to 52 stands for club    A to K
	- example like `1 2 3 4 5`
## Problem 5
- use `./hw0105` to execute the program
- what will this program do?
	- it will convert the 16-bits hex value inputed 
		- into binary value repersented by 0 and 1 only
		- into three different types
			- type 1: 16-bits integer
			- type 2: 16-bits unsigned integer
			- type 2: float
- how to input?
	- enter 4 characters from 0-9 or A-F
	- then enter the type you want to convert: 1, 2, or 3
## Problem 6
- to make the `Makefile` work even encounter an error
	- just add a `; true` suffix at the end of the command line
- for example
	- `gcc codeWithError.c -o ohNo; true`
