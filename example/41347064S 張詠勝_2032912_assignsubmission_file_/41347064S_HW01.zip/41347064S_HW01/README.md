---
title: README

---

-My Student ID :
    41347064S

-How to build my code :
    Make the makefile and my homework will be compiled

-How to execute my built programs :
    Open it in terminal after making the makefile

-Anything I want to notify TAs :
    None