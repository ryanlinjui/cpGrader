#include<stdio.h>
#include<stdint.h>

int main()
{
uint16_t a=0;
printf("Please enter an unsigned 16-bits number:\n");
scanf("%hu",&a);
if(a<0||a>65535)
{printf("ERROR\n");}
else{
printf("Before Flip:\n%hu_10 = %ho_8\n",a,a);
uint16_t b=0,a6=a/32768,a5=(a%32768)/4096,a4=(a%32768%4096)/512,a3=(a%32768%4096%512)/64,a2=(a%32768%4096%512%64)/8,a1=(a%32768%4096%512%64%8);
if((a/32768)>=1)
{b=a1*100000+a2*10000+a3*1000+a4*100+a5*10+a6;}
else if((a/4096)>=1)
{b=a1*10000+a2*1000+a3*100+a4*10+a5;}
else if((a/512)>=1)
{b=a1*1000+a2*100+a3*10+a4;}
else if((a/64)>=1)
{b=a1*100+a2*10+a3;}
else if((a/8)>=1)
{b=a1*10+a2;}
else if((a/1)>=1)
{b=a1;}
uint16_t c=0;
uint32_t b6=b/100000,b5=b%100000/10000,b4=b%10000/1000,b3=b%1000/100,b2=b%100/10,b1=b%10;
if(b>=100000)
{c=b6*32768+b5*4096+b4*512+b3*64+b2*8+b1;}
else if(b>=10000)
{c=b5*4096+b4*512+b3*64+b2*8+b1;}
else if(b>=1000)
{c=b4*512+b3*64+b2*8+b1;}
else if(b>=100)
{c=b3*64+b2*8+b1;}
else if(b>=10)
{c=b2*8+b1;}
else if(b>=0)
{c=b1;}
printf("After Flip:\n%hu_8 = %hu_10\n",b,c);  
} 
   return 0;
}