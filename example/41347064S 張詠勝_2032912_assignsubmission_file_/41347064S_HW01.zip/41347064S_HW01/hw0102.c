#include<stdio.h>
#include<stdint.h>

int main()
{
int32_t x=-1,y=-1,z=-1;
int32_t a=-1,b=-1,c=-1;
int32_t sum=-1;
printf("Please enter the first operand :\n");
scanf("%dx%d",&a,&b);
printf("Please enter the second operand:\n");
scanf(" y%dz",&c);
printf("Please enter the sum           :\n");
scanf(" %d",&sum);
if(a<0||b<0||c<0||sum<352||a>=10||b>=10||c>=10)
{printf("ERROR\n");}
else{
int32_t suma=a*100+x*10+b;
int32_t sumb=y*100+c*10+z;
int32_t unisa=suma/1%10;
int32_t hunsa=suma/100%10;
int32_t tensb=sumb/10%10;
int32_t unis=sum/1%10;
int32_t tens=sum/10%10;
int32_t huns=sum/100%10;
int32_t ths=sum/1000%10;
int32_t summ=100*hunsa+10*tensb+unisa;
if(sum>summ+999)
{printf("ERROR\n");}
if(unis>=unisa)
{z=unis-unisa;
if(tens>=tensb)
{x=tens-tensb;
if(huns>=hunsa)
{y=huns-hunsa;
printf("Ans: x=%d,y=%d,z=%d\n",x,y,z);}
else
{y=(10+huns)-hunsa;
 printf("Ans: x=%d,y=%d,z=%d\n",x,y,z);}
}
else
{x=(10+tens)-tensb;
if(huns>=hunsa)
{y=huns-(hunsa+1);
printf("Ans: x=%d,y=%d,z=%d\n",x,y,z);}
else
{y=(10+huns)-(hunsa+1);
 printf("Ans: x=%d,y=%d,z=%d\n",x,y,z);}
}
}//
else
{z=(10+unis)-unisa;
if(tens>=tensb)
{x=tens-tensb-1;
if(huns>=hunsa)
{y=huns-hunsa;
 printf("Ans: x=%d,y=%d,z=%d\n",x,y,z);}
else
{y=(10+huns)-hunsa;
 printf("Ans: x=%d,y=%d,z=%d\n",x,y,z);}
}
else
{x=(tens+10)-(tensb+1);
if(huns>=hunsa)
{y=huns-(hunsa+1);
 printf("Ans: x=%d,y=%d,z=%d\n",x,y,z);}
else
{y=(huns+10)-(hunsa+1);
 printf("Ans: x=%d,y=%d,z=%d\n",x,y,z);}
}
}
}
    return 0;
}