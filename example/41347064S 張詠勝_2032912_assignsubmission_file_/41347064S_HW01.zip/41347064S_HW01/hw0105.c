#include<stdio.h>
#include<stdint.h>

int main()
{
uint16_t a=0,b=0,c=0;
printf("Please input a hex:");
scanf("%hx",&a);
printf("Please choose the output type(1:integer,2:unsigned integer,3:float)");
scanf("%hd",&b);
uint16_t a1=a%4096%256%16,a2=a%4096%256/16,a3=a%4096/256,a4=a/4096;
if(a/4096>=1)
{c=4096*a4+256*a3+16*a2+a1;}
else if(a/256>=1)
{c=256*a3+16*a2+a1;}
else if(a/16>=1)
{c=16*a2+a1;}
else
{c=a1;}
uint16_t c16=c/32768,c15=c%32768/16384,c14=c%16384/8192,c13=c%8192/4096,c12=c%4096/2048,c11=c%2048/1024,c10=c%1024/512,c9=c%512/256,c8=c%256/128,c7=c%128/64,c6=c%64/32,c5=c%32/16,c4=c%16/8,c3=c%8/4,c2=c%4/2,c1=c%2;
printf("Binary of %hx is:%hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu %hu%hu%hu%hu\n",a,c16,c15,c14,c13,c12,c11,c10,c9,c8,c7,c6,c5,c4,c3,c2,c1);
uint16_t g=c;
float e=c;
if(b==1)
{printf("Converted integer is: %hd\n",c);}
if(b==2)
{printf("Converted unsigned integer is:  %hu\n",g);}
int16_t exp=c15*16+c14*8+c13*4+c12*2+c11;
int16_t EXP=exp-15;
float F=1+c10*(0.5)+c9*(0.25)+c8*(0.125)+c7*(0.0625)+c6*(0.03125)+c5*(0.015625)+c4*(0.0078125)+c3*(0.00390625)+c2*(0.001953125)+c1*(0.000976562);
if(b==3)
{if(exp==0&&F==1&&c16==1)
{printf("-0.0\n");}
else if(exp==0&&F==1&&c16==0)
{printf("+0.0\n");}
else if(exp==31&&F==1&&c16==1)
{printf("-INF\n");}
else if(exp==31&&F==1&&c16==0)
{printf("+INF\n");}
else if(exp==31)
{printf("NAN\n");}
else if(c16==1)
{printf("Converted float is:-%f*2^%hd\n",F,EXP);} 
else if(c16==0)    
{printf("Converted float is:%f*2^%hd\n",F,EXP);}
}
 return 0;
}