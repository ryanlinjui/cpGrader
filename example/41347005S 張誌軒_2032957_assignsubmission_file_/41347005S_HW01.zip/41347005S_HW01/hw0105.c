#include <stdio.h>
#include <stdint.h>

int main ()
{

	int32_t input1 = 0; // for only 16bits (4 digits for hex)

	printf("Please input a hex: \n");
	scanf("%x", &input1);
	
	if ( input1 > 65535 )
	{
		printf("I can't code more than 4 digits for hex\n");
	}
	
	else
	{	
		int8_t input2 = 0;
	
		printf("Please choose the output type:\n(1: integer, 2: unsigned integer, 3: float)\n");
		scanf("\n%hhd", &input2);
		
		int8_t n15, n14, n13, n12, n11, n10, n9, n8, n7, n6, n5, n4, n3, n2, n1, n0 = 0;
		
		/*
		if ( input1 & 32768 ) { n15 = 1; } else { n15 = 0; }
		if ( input1 & 16384 ) { n14 = 1; } else { n14 = 0; }
		if ( input1 & 8192 ) { n13 = 1; } else { n13 = 0; }
		if ( input1 & 4096 ) { n12 = 1; } else { n12 = 0; }
		if ( input1 & 2048 ) { n11 = 1; } else { n11 = 0; }
		if ( input1 & 1024 ) { n10 = 1; } else { n10 = 0; }
		if ( input1 & 512 ) { n9 = 1; } else { n9 = 0; }
		if ( input1 & 256 ) { n8 = 1; } else { n8 = 0; }
		if ( input1 & 128 ) { n7 = 1; } else { n7 = 0; }
		if ( input1 & 64 ) { n6 = 1; } else { n6 = 0; }
		if ( input1 & 32 ) { n5 = 1; } else { n5 = 0; }
		if ( input1 & 16 ) { n4 = 1; } else { n4 = 0; }
		if ( input1 & 8 ) { n3 = 1; } else { n3 = 0; }
		if ( input1 & 4 ) { n2 = 1; } else { n2 = 0; }
		if ( input1 & 2 ) { n1 = 1; } else { n1 = 0; }
		if ( input1 & 1 ) { n0 = 1; } else { n0 = 0; }
		*/
		
		n0 = input1 % 2;
		n1 = ( ( input1 - n0 ) % 4 ) / 2;
		n2 = ( ( input1 - n0 - 2*n1 ) % 8 ) / 4;
		n3 = ( ( input1 - n0 - 2*n1 - 4*n2 ) % 16 ) / 8;
		n4 = ( ( input1 - n0 - 2*n1 - 4*n2 - 8*n3 ) % 32 ) / 16;
		n5 = ( ( input1 - n0 - 2*n1 - 4*n2 - 8*n3 - 16*n4 ) % 64 ) / 32;
		n6 = ( ( input1 - n0 - 2*n1 - 4*n2 - 8*n3 - 16*n4 - 32*n5 ) % 128 ) / 64;
		n7 = ( ( input1 - n0 - 2*n1 - 4*n2 - 8*n3 - 16*n4 - 32*n5 - 64*n6 ) % 256 ) / 128;
		n8 = ( ( input1 - n0 - 2*n1 - 4*n2 - 8*n3 - 16*n4 - 32*n5 - 64*n6 - 128*n7 ) % 512 ) / 256;
		n9 = ( ( input1 - n0 - 2*n1 - 4*n2 - 8*n3 - 16*n4 - 32*n5 - 64*n6 - 128*n7 - 256*n8 ) % 1024 ) / 512;
		n10 = ( ( input1 - n0 - 2*n1 - 4*n2 - 8*n3 - 16*n4 - 32*n5 - 64*n6 - 128*n7 - 256*n8 - 512*n9 ) % 2048 ) / 1024;
		n11 = ( ( input1 - n0 - 2*n1 - 4*n2 - 8*n3 - 16*n4 - 32*n5 - 64*n6 - 128*n7 - 256*n8 - 512*n9 - 1024*n10 ) % 4096 ) / 2048;
		n12 = ( ( input1 - n0 - 2*n1 - 4*n2 - 8*n3 - 16*n4 - 32*n5 - 64*n6 - 128*n7 - 256*n8 - 512*n9 - 1024*n10 - 2048*n11 ) % 8192 ) / 4096;
		n13 = ( ( input1 - n0 - 2*n1 - 4*n2 - 8*n3 - 16*n4 - 32*n5 - 64*n6 - 128*n7 - 256*n8 - 512*n9 - 1024*n10 - 2048*n11 - 4096*n12 ) % 16384 ) / 8192;
		n14 = ( ( input1 - n0 - 2*n1 - 4*n2 - 8*n3 - 16*n4 - 32*n5 - 64*n6 - 128*n7 - 256*n8 - 512*n9 - 1024*n10 - 2048*n11 - 4096*n12 - 8192*n13 ) % 32768 ) / 16384;
		n15 = ( ( input1 - n0 - 2*n1 - 4*n2 - 8*n3 - 16*n4 - 32*n5 - 64*n6 - 128*n7 - 256*n8 - 512*n9 - 1024*n10 - 2048*n11 - 4096*n12 - 8192*n13 - 16384*n14 ) % 65536 ) / 32768;
		
		
		if ( input2 < 1 || input2 > 3 )
		{
			printf("\033[91mWrong Input!\n");
		}
	
		else
		{
			if ( input2 == 1 )
			{
				
				printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n", input1, n15, n14, n13, n12, n11, n10, n9, n8, n7, n6, n5, n4, n3, n2, n1, n0);
				
				if ( n15 == 0 )
				{
					printf("Converted integer is: %d\n", input1);
				}
			
				if ( n15 == 1 )
				{
					printf("Converted integer is: -%d\n", (65536 - input1));
				}
			
			}
		
			else if ( input2 == 2 )
			{
				printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n", input1, n15, n14, n13, n12, n11, n10, n9, n8, n7, n6, n5, n4, n3, n2, n1, n0);
				
				printf("Converted unsigned integer is: %d\n", input1);
			}
			
			else if ( input2 == 3 )
			{
				int16_t exp = 0;
				float output_3 = 0;
				
				exp = 16*n14 + 8*n13 + 4*n12+ 2*n11 + 1*n10;
				
				output_3 = n9*0.5 + n8*0.25 + n7*0.125 + n6*0.0625 + n5*0.03125 + n4*0.015625 + n3*0.0078125 + n2*0.00390625 + n1*0.001953125 + n0*0.0009765625; 
				
				printf("Binary of %X is: %d%d%d%d %d%d%d%d %d%d%d%d %d%d%d%d\n", input1, n15, n14, n13, n12, n11, n10, n9, n8, n7, n6, n5, n4, n3, n2, n1, n0);
				
				if ( n15 == 0 )
				{
					if ( exp == 0 && output_3 == 0 )
					{
						printf("Converted float is +0.0 \n");
					}
					
					else if ( exp == 31 )
					{
						if ( output_3 == 0 )
						{
							printf("Converted float is +INF \n");
						}
						
						else
						{
							printf("Converted float is NAN \n");
						}
					}
					
					else
					{
						printf("Converted float is %.10f * 2^(%d)\n", (1 + output_3), (exp - 15));
					}
				}
				
				if ( n15 == 1 )
				{
					if ( exp == 0 && output_3 == 0 )
					{
						printf("Converted float is -0.0 \n");
					}
					
					else if ( exp == 31 )
					{
						if ( output_3 == 0 )
						{
							printf("Converted float is -INF \n");
						}
						
						else
						{
							printf("Converted float is NAN \n");
						}
					}
					
					else
					{
						printf("Converted float is -%.10f * 2^(%d)\n", (1 + output_3), (exp - 15));
					}
				}
			}	
				else
				{
					printf("\033[91mWrong Input!!!\n");
				}
		}
	}
	return 0;
}
