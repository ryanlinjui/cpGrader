#include <stdio.h>
#include <stdint.h>

int main ()
{
	uint16_t num1, num2, num3, num4, num5 = 0;
	
	printf("Please enter 5 cards: \n");
	scanf("%hu %hu %hu %hu %hu", &num1, &num2, &num3, &num4, &num5);
	
	if ( num1 < 1 || num1 > 52 || num2 < 1 || num2 > 52 || num3 < 1 || num3 > 52 || num4 < 1 || num4 > 52 || num5 < 1 || num5 > 52 || num1 == num2 || num1 == num3 || num1 == num4 || num1 == num5 || num2 == num3 || num2 == num4 || num2 == num5 || num3 == num4 || num3 == num5 || num4 == num5 )
	{
		printf("\033[91mWrong Input!!!\n");
	}
	
	else
	{
		uint8_t n1, n2, n3, n4, n5 = 0;
		uint8_t c1, c2, c3, c4, c5 = 0;
		
		n1 = (num1 - 1) % 13 + 1;
		n2 = (num2 - 1) % 13 + 1;
		n3 = (num3 - 1) % 13 + 1;
		n4 = (num4 - 1) % 13 + 1;
		n5 = (num5 - 1) % 13 + 1;
		
		c1 = (num1 - 1) / 13;
		c2 = (num2 - 1) / 13;
		c3 = (num3 - 1) / 13;
		c4 = (num4 - 1) / 13;
		c5 = (num5 - 1) / 13;
		
		if ( n1 > n2 ) { uint8_t temp = n1; n1 = n2; n2 = temp; }
		if ( n1 > n3 ) { uint8_t temp = n1; n1 = n3; n3 = temp; }
		if ( n1 > n4 ) { uint8_t temp = n1; n1 = n4; n4 = temp; }
		if ( n1 > n5 ) { uint8_t temp = n1; n1 = n5; n5 = temp; }
		
		if ( n2 > n3 ) { uint8_t temp = n2; n2 = n3; n3 = temp; }
		if ( n2 > n4 ) { uint8_t temp = n2; n2 = n4; n4 = temp; }
		if ( n2 > n5 ) { uint8_t temp = n2; n2 = n5; n5 = temp; }
		
		if ( n3 > n4 ) { uint8_t temp = n3; n3 = n4; n4 = temp; }
		if ( n3 > n5 ) { uint8_t temp = n3; n3 = n5; n5 = temp; }
		
		if ( n4 > n5 ) { uint8_t temp = n4; n4 = n5; n5 = temp; }
		
		//printf("%d %d %d %d %d \n", n1, n2, n3, n4, n5); // small to big
		
		//Flush, Straight flush
		if ( c1 == c2 && c1 == c3 && c1 == c4 && c1 == c5 && c2 == c3 && c2 == c4 && c2 == c5 && c3 == c4 && c3 == c5 && c4 == c5 ) 
		{
			if ( n1 + 1 == n2 && n2 + 1 == n3 && n3 + 1 == n4 && n4 + 1 == n5 )
			{
				printf("Straight flush \n");
			}
			
			else if ( n1 == 1 && n2 == 10 && n3 == 11 && n4 == 12 && n5 == 13 )
			{
				printf("Straight flush \n");
			}
			
			else
			{
				printf("Flush \n");
			}
		}
		
		// Straight
		else if ( n1 + 1 == n2 && n2 + 1 == n3 && n3 + 1 == n4 && n4 + 1 == n5 )
		{
			printf("Straight\n");
		}
		
		else if ( n1 == 1 && n2 == 10 && n3 == 11 && n4 == 12 && n5 == 13 )
		{
			printf("Straight\n");
		}
	
		//Four of a kind
		else if ( n1 == n2 && n1 == n3 && n1 == n4 )
		{ 
			printf("Four of a kind\n");
		}
		
		else if ( n2 == n3 && n2 == n4 && n2 == n5 )
		{
			printf("Four of a kind\n");
		}
		
		//Full house, Three of a kind
		else if ( n1 == n2 && n1 == n3 )
		{
			if ( n4 == n5 )
			{
				printf("Full house\n");
			}
			
			else
			{
				printf("Three of a kind\n");
			}
		}

		else if ( n3 == n4 && n3 == n5 )
		{
			if ( n1 == n2 )
			{
				printf("Full house\n");
			}
			
			else
			{
				printf("Three of a kind\n");
			}
		}
	
		else if ( n2 == n3 && n2 == n4 )
		{
			printf("Three of a kind\n");
		}
		
		
		//Two pairs, One pairs
		else if ( n1 == n2 )
		{
			if ( n3 == n4 || n4 == n5 )
			{
				printf("Two pairs\n");
			}
			
			else
			{
				printf("One pair\n");
			}
		}
		
		else if ( n2 == n3 )
		{
			if ( n4 == n5 )
			{
				printf("Two pairs\n");
			}
			
			else
			{
				printf("One pair\n");
			}
		}
		
		else if ( n3 == n4 )
		{
			if ( n1 == n2 )
			{
				printf("Two pairs\n");
			}
			
			else
			{
				printf("One pair\n");
			}
		}
		
		else if ( n4 == n5 )
		{
			if ( n1 == n2 || n2 == n3 )
			{
				printf("Two pairs\n");
			}
			
			else
			{
				printf("One pair\n");
			}
		}
		
		else
		{
			printf("High card\n");
		}
	}
	
	return 0;
}
