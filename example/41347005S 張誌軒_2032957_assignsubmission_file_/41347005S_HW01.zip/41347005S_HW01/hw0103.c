#include <stdio.h>
#include <stdint.h>

int main ()
{
	uint32_t input = -1;

	printf("Please enter an unsigned 16-bits number: \n");
	scanf("%u", &input);
	
	if (input > 65535)
	{
		printf("\033[91mWrong Input!!! \n");
		
		return 0;
	}
	
	else
	{	
		printf("Before Flip: \n");
		printf("%d_10 = %o_8 \n", input, input);
		
		int8_t a = 0;
		int8_t b = 0;
		int8_t c = 0;
		int8_t d = 0;
		int8_t e = 0;
		int8_t f = 0;
	
		a = input % 8;
		b = ( input - a ) % 64 / 8;
		c = ( input - a - (8*b) ) % 512 / 64;
		d = ( input - a - (8*b) - (64*c) ) % 4096 / 512;
		e = ( input - a - (8*b) - (64*c) - (512*d) ) % 32768 /4096;
		f = ( input - a - (8*b) - (64*c) - (512*d) - (4096*e) ) % 262144 /32768;
		
		int32_t output = 0;
				
		output = (a*32768) + (b*4096) + (c*512) + (d*64) + (e*8) + f;
		
		if ( input < 8 )
		{
			printf("After Flip: \n");
			printf("%o_8 = %d_10 \n", output/32768, output/32768);
		}
		else if ( input < 64 )
		{
			printf("After Flip: \n");
			printf("%o_8 = %d_10 \n", output/4096, output/4096);	
		}
		else if ( input < 512 )
		{
			printf("After Flip: \n");
			printf("%o_8 = %d_10 \n", output/512, output/512);		
		}
		else if ( input < 4096 )
		{
			printf("After Flip: \n");
			printf("%o_8 = %d_10 \n", output/64, output/64);
		}
		else if ( input < 32768 )
		{
			printf("After Flip: \n");
			printf("%o_8 = %d_10 \n", output/8, output/8);	
		}
		else
		{
			printf("After Flip: \n");
			printf("%o_8 = %d_10 \n", output, output);
		}
	}
	
	return 0;
}
