#include <stdio.h>
#include <stdint.h>

int main ()
{
	int32_t a = -1;
	int32_t b = -1;
	int32_t c = -1;
	int32_t sum = 0;
	
	printf("Please enter the first operand: \n");
	scanf("%dx%d", &a, &b);
	
	if ( a < 0 || a > 9 || b < 0 || b > 9 )
	{
		printf("\033[91mWrong Input!!!\n");
		
		return 0;
	}
	
	printf("Please enter the second operand: \n");
	scanf("\ny%dz", &c); //scanf \n change line to scan
	
	if ( c < 0 || c > 9 )
	{
		printf("\033[91mWrong Input!!!\n");
		
		return 0;
	}
	
	printf("Please enter the sum: \n");
	scanf("\n%d", &sum);	
	
	if ( sum > 1998 )	
	{
		printf("\033[91mIt can not be calculated!\n");
	}
		
	else
	{
		int8_t x = -1;
		int8_t y = -1;
		int8_t z = -1;
		
		int16_t outcome = 0;
		
		outcome = sum - (100*a) - (10*c) - b;
		
		z = outcome % 10;
		x = ( ( outcome - z ) % 100 ) / 10;
		y = ( ( outcome - (10*x) - z ) % 1000 ) / 100;
		
		if ( x < 0 || y < 0 || z < 0 || (100*(a+y)+10*(x+c)+(b+z)) < sum )
		{
			printf("\033[91mIt can not be calculated! \n");
		}
	
		else 
		{
			printf("x = %d, y = %d, z = %d \n", x, y, z);
		}	
	}
	
	return 0;
}


