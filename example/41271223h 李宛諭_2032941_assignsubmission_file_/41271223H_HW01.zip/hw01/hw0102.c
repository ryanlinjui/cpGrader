#include <stdio.h>

int main() {
    int num1, num2, num3, num4, num5, num6, sum; 
    char x1, y1, z1; 
    int x, y, z;  

   
    printf("Please enter the first operand (format: 1x3): ");
    if (scanf("%d %c %d", &num1, &x1, &num2) != 3 || x1 != 'x') {
        printf("Invalid input! Please enter the first operand in the correct format (e.g., 1x3).\n");
        return 1;  
    }

if(num1 > 10){
printf("Invalid input! Please enter the first operand in the correct format (e.g., 1x3).\n");
        return 1;  
}
    
    printf("Please enter the second operand (format: y5z): ");
    if (scanf(" %c %d %c", &y1, &num3, &z1) != 3 || y1 != 'y' || z1 != 'z') {
        printf("Invalid input! Please enter the second operand in the correct format (e.g., y5z).\n");
        return 1; 
    }

   
    printf("Please enter the sum (format: ddd): ");
    scanf("%d", &sum) ; 
    
    num4 = sum/100;
    num5 = (sum/10)%10;
    num6 = sum%10;
  
    if (num6 >= num2) {
        z = num6 - num2;
    } else {
        z = 10 + num6 - num2;  
        num5 -= 1;  
    }

    
    if (num5 >= num3) {
        x = num5 - num3;
    } else {
        x = 10 + num5 - num3;  
        num4 -= 1;
    }

  
    if (num4 >= num1) {
        y = num4 - num1;
    } else {
        y = 10 + num4 - num1;  
    }

  
    printf("Ans: x = %d, y = %d, z = %d\n", x, y, z);

    return 0;
}

