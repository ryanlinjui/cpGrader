#include <stdio.h>

// ANSI escape codes for text colors
#define RED "\033[0;31m"
#define BLUE "\033[0;34m"
#define GREEN "\033[0;32m"
#define RESET "\033[0m"  // Reset to default color

int main() {
    // Print the lyrics with appropriate colors
    printf(RED "[KIM]\n" RESET);
    printf(RED "You are sunlight and I moon\n" RESET);
    printf(RED "Joined by the gods of fortune\n" RESET);
    printf(RED "Midnight and high noon sharing the sky\n" RESET);
    printf(RED "We have been blessed, you and I\n\n" RESET);
    
    printf(BLUE "[CHRIS]\n" RESET);
    printf(BLUE "You are here like a mystery\n" RESET);
    printf(BLUE "I'm from a world that's so different from all that you are\n" RESET);
    printf(BLUE "How in the light of one night did we come so far?\n\n" RESET);
    
    printf(RED "[KIM]\n" RESET);
    printf(RED "Outside day starts to dawn\n\n" RESET);
    
    printf(BLUE "[CHRIS]\n" RESET);
    printf(BLUE "Your moon still floats on high\n\n" RESET);
    
    printf(RED "[KIM]\n" RESET);
    printf(RED "The birds awake\n\n" RESET);
    
    printf(BLUE "[CHRIS]\n" RESET);
    printf(BLUE "The stars shine too\n\n" RESET);
    
    printf(RED "[KIM]\n" RESET);
    printf(RED "My hands still shake\n" RESET);
    printf(RED "See upcoming pop shows\n" RESET);
    printf(RED "Get tickets for your favorite artists\n\n" RESET);
    
    printf(GREEN "[KIM & CHRIS]\n" RESET);
    printf(GREEN "I reach for you\n\n" RESET);
    
    printf(GREEN "[KIM & CHRIS]\n" RESET);
    printf(GREEN "And we meet in the sky\n\n" RESET);
    
    printf(RED "[KIM]\n" RESET);
    printf(RED "You are sunlight and I moon\n" RESET);
    printf(RED "Joined here\n" RESET);
    printf(RED "Brightening the sky with the flame of love\n\n" RESET);
    
    printf(GREEN "[KIM & CHRIS]\n" RESET);
    printf(GREEN "Made of\n" RESET);
    printf(GREEN "Sunlight\n" RESET);
    printf(GREEN "Moonlight\n" RESET);

    return 0;
}
