#include <stdio.h>


void convertToOctal(int decimal, int place, int *octal) {
    if (decimal == 0) {
        return;
    }
    
    int remainder = decimal % 8;
    *octal += remainder * place; 
    
  
    if (decimal >= 8) {
        convertToOctal(decimal / 8, place * 10, octal);
    }
}

int main() {
    int decimal, octal = 0;
    int th , hun,ten,one;

    // Get input from user
    printf("Please enter an unsigned 16-bits number: ");
    scanf("%d", &decimal);

    // Check if the number is within the valid range
    if (decimal < 0 || decimal > 9999) {
        printf("Invalid input!\n");
        return 1;  // Exit the program if input is invalid
    }

    // Start conversion using recursion
    if (decimal != 0) {
        convertToOctal(decimal, 1, &octal);
    }

    // Output the result
    printf("Before Flip:\n");
    printf("%d_10 = %d_8\n",decimal ,octal);
    
    th = octal/1000;
    hun = (octal%1000)/100;
    ten = (octal%100)/10;
    one = octal%10;
    int flip = one*1000+ten*100+hun*10+th;
    int aft = one*512+ten*64+hun*8+th;
    printf("After Flip:\n");
    printf("%d_8 = %d_10\n",flip ,aft);
    
    return 0;
}
