README

1: Print Colorful Words

Description:
This problem focuses on changing the output text color in the terminal using ANSI escape codes in C. The program will prompt the user to choose a color, and then display a message in that color.
Explanation:
1. By adding the `-` symbol before `gcc -c a.c -o a.o`, you are allowing the command to fail without stopping the entire build process.
2. The build order remains unchanged: `a.o` is built before `b.o`, but now `b.o` will be built even if `a.o` fails.

This solution ensures that `b.c` is compiled even when `a.c` encounters an error.

How it works:

The program utilizes ANSI escape codes to change the text color.
The user is asked to select a color from a predefined list.
Based on the user's selection, the program will output a message in the chosen color.
ANSI escape sequences are used to manipulate the color of the text in the terminal.

 Problem 2: A Simple Math Problem

Description:  
This problem involves manipulating individual digits from input expressions of the form `1x3` and `y5z`. Given a sum, the program calculates unknown digits `x`, `y`, and `z`.

How it works:
- The program parses the first operand in the format `1x3` and the second operand in the format `y5z`.
- Based on the provided sum, it computes `x`, `y`, and `z` using arithmetic rules for digit positioning.
- The calculated values are printed out.

 Problem 3: Flip an Octal Number

Description:  
This program converts a decimal number (up to 9999) to its octal representation using recursion. It asks the user to input a valid decimal number within the specified range, and then recursively calculates the octal value of that number.

How it works:
- The user is prompted to input a decimal number between 0 and 9999.
- The program uses a recursive function, convertToOctal(), to repeatedly divide the decimal number by 8.
- In each recursive step, the remainder is calculated, which represents the current octal digit.
- These digits are collected and combined to form the final octal number.
- Once the recursion completes, the final octal number is printed.

Problem 4: Poker Hand 

Description:  
This program determines the ranking of a poker hand from five cards, provided as input by the user. It identifies whether the hand is a Straight Flush, Four of a Kind, Full House, Flush, Straight, Three of a Kind, Two Pair, One Pair, or High Card based on standard poker rules.

How it works:
- The program asks the user to input five poker cards represented by integers from 1 to 52.
- The program analyzes the hand by checking:
- Based on the analysis, it outputs the corresponding hand ranking

 Problem 5: Binary Variable

Description:  
This problem is focused on converting a hexadecimal input (16-bit) to its binary, signed integer, unsigned integer, and IEEE 754 floating-point representation.

How it works:
- The program prompts the user to input a hexadecimal value (up to 16 bits).
- Based on the user's selection, it converts the input into one of the following:
  - Signed integer (two's complement for negatives)
  - Unsigned integer
  - IEEE 754 floating-point format (binary representation)
- The program prints the corresponding result in binary and other formats.


