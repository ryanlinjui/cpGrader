#include <stdio.h>

void print_single_bit(int num, int bit_position) {
    int bit = (num >> bit_position) & 1;
    printf("%d", bit);
}

void print_binary(int num) {
    print_single_bit(num, 15); print_single_bit(num, 14); print_single_bit(num, 13); print_single_bit(num, 12);
    printf(" ");
    print_single_bit(num, 11); print_single_bit(num, 10); print_single_bit(num, 9); print_single_bit(num, 8);
    printf(" ");
    print_single_bit(num, 7); print_single_bit(num, 6); print_single_bit(num, 5); print_single_bit(num, 4);
    printf(" ");
    print_single_bit(num, 3); print_single_bit(num, 2); print_single_bit(num, 1); print_single_bit(num, 0);
    printf("\n");
}

void print_float_conversion(int num) {
    int sign = (num >> 15) & 1;
    int exponent = (num >> 10) & 0x1F;
    int fraction = num & 0x3FF;
    int actual_exponent = exponent - 15;

    float mantissa = 1.0;
    if (fraction & 0x200) mantissa += 1.0 / 2;
    if (fraction & 0x100) mantissa += 1.0 / 4;
    if (fraction & 0x080) mantissa += 1.0 / 8;
    if (fraction & 0x040) mantissa += 1.0 / 16;
    if (fraction & 0x020) mantissa += 1.0 / 32;
    if (fraction & 0x010) mantissa += 1.0 / 64;
    if (fraction & 0x008) mantissa += 1.0 / 128;
    if (fraction & 0x004) mantissa += 1.0 / 256;
    if (fraction & 0x002) mantissa += 1.0 / 512;
    if (fraction & 0x001) mantissa += 1.0 / 1024;

    if (sign == 1) {
        mantissa = -mantissa;
    }

    printf("Converted float is: %.6f*2^%d\n", mantissa, actual_exponent);
}

void print_signed_integer(int num) {
    if ((num >> 15) & 1) {
        num = num - (1 << 16);
    }
    printf("Converted signed integer: %d\n", num);
}

void print_type_conversion(int num, int type) {
    if (type == 1) {
        print_signed_integer(num);
    } else if (type == 2) {
        printf("Converted integer: %u\n", (unsigned short)num);
    } else if (type == 3) {
        print_float_conversion(num);
        
    }
}

int main() {
    unsigned int hex;
    int type;
    int input_status;

    printf("Please input a hex (16-bit): ");
    input_status = scanf("%x", &hex);

    if (input_status != 1 || hex > 0xFFFF) {
        printf("error please try again.\n");
        return 1;
    }

    printf("Please choose the output type (1: integer, 2: unsigned integer, 3: float): ");
    input_status = scanf("%d", &type);

    if (input_status != 1 || type < 1 || type > 3) {
        printf("error please try again.\n");
        return 1;
    }

    printf("Binary of %X is: ", hex);
    print_binary(hex);
    print_type_conversion(hex, type);

    return 0;
}


