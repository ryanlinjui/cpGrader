#include <stdio.h>

void print_hand_rank(int rank) {
    if (rank == 1) {
        printf("Straight Flush\n");
    } else if (rank == 2) {
        printf("Four of a Kind\n");
    } else if (rank == 3) {
        printf("Full House\n");
    } else if (rank == 4) {
        printf("Flush\n");
    } else if (rank == 5) {
        printf("Straight\n");
    } else if (rank == 6) {
        printf("Three of a Kind\n");
    } else if (rank == 7) {
        printf("Two Pair\n");
    } else if (rank == 8) {
        printf("One Pair\n");
    } else if (rank == 9) {
        printf("High Card\n");
    }
}

int card_value(int card) {
    return (card - 1) % 13 + 1;
}

int card_suit(int card) {
    return (card - 1) / 13;
}

int same_suit(int suit1, int suit2, int suit3, int suit4, int suit5) {
    return suit1 == suit2 && suit2 == suit3 && suit3 == suit4 && suit4 == suit5;
}

int is_straight(int v1, int v2, int v3, int v4, int v5) {
    if ((v1 + 1 == v2) && (v2 + 1 == v3) && (v3 + 1 == v4) && (v4 + 1 == v5)) {
        return 1;
    }
    return 0;
}

int count_pairs(int v1, int v2, int v3, int v4, int v5) {
    int pairs = 0, threes = 0, fours = 0;
    if (v1 == v2) {
        if (v2 == v3) {
            if (v3 == v4) {
                fours++;
            } else {
                threes++;
            }
        } else {
            pairs++;
        }
    }
    if (v3 == v4 && v4 == v5) {
        if (v3 == v1) {
            fours++;
        } else {
            threes++;
        }
    } else if (v4 == v5) {
        pairs++;
    }
    if (v2 == v3) {
        if (v1 != v2 && v4 != v2) {
            threes++;
        }
    }
    if (fours == 1) {
        return 2;
    } else if (threes == 1 && pairs == 1) {
        return 3;
    } else if (threes == 1) {
        return 6;
    } else if (pairs == 2) {
        return 7;
    } else if (pairs == 1) {
        return 8;
    }
    return 9;
}

int main() {
    int card1, card2, card3, card4, card5;
    int rank;

    printf("Please enter 5 cards (1-52): ");
    scanf("%d %d %d %d %d", &card1, &card2, &card3, &card4, &card5);

    if (card1 < 1 || card1 > 52 || card2 < 1 || card2 > 52 || card3 < 1 || card3 > 52 || card4 < 1 || card4 > 52 || card5 < 1 || card5 > 52) {
        printf("Invalid input! Cards must be between 1 and 52.\n");
        return 1;
    }

    if (card1 == card2 || card1 == card3 || card1 == card4 || card1 == card5 ||
        card2 == card3 || card2 == card4 || card2 == card5 ||
        card3 == card4 || card3 == card5 ||
        card4 == card5) {
        printf("Invalid input! Cards must be unique.\n");
        return 1;
    }

    int v1 = card_value(card1), v2 = card_value(card2), v3 = card_value(card3), v4 = card_value(card4), v5 = card_value(card5);
    int s1 = card_suit(card1), s2 = card_suit(card2), s3 = card_suit(card3), s4 = card_suit(card4), s5 = card_suit(card5);

    if (same_suit(s1, s2, s3, s4, s5) && is_straight(v1, v2, v3, v4, v5)) {
        rank = 1; // Straight Flush
    } else if (same_suit(s1, s2, s3, s4, s5)) {
        rank = 4; // Flush
    } else if (is_straight(v1, v2, v3, v4, v5)) {
        rank = 5; // Straight
    } else {
        rank = count_pairs(v1, v2, v3, v4, v5); // Other hand rankings
    }

    print_hand_rank(rank);

    return 0;
}
