#include<stdio.h>
#include<stdint.h>

int32_t main(){

	int32_t num;
	scanf("%d", &num);
	printf("%o", num);

	return 0;
}

