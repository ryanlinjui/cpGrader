// a.c
#include <stdio.h>

int main()
{
	printf( "Hello Kitty" )
	return 0;
}

