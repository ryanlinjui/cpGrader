1. 41347008s 温博舟
2. use $ make              to compile my code.
3. use $ ./hw0101          to execute homework01.
4. use $ ./hw0102          to execute homework02.
5. use $ ./hw0103          to execute homework03.
6. use $ ./hw0104          to execute homework04.
7. use $ ./hw0105          to execute homework05.
8. use $ cd hw0106 ; make  to check homework06
9. I really miss Loop and Array.
