#include <stdio.h>

int main() {
    char expr1[100], expr2[100];
    int sum;
    int a = 0, b = 0, c = 0;
    int x, y, z;

    printf("Please enter the first operand: ");
    scanf("%s", expr1); 

  
    sscanf(expr1, "%dx%d", &a, &b);

    if ((a < 0) || (a > 9) || (b < 0) || (b > 9) ){
        printf("Error : It's an invalid input\n ");
        return 1;
    }

    printf("Please enter the second operand: ");
    scanf("%s", expr2); 


    sscanf(expr2, "y%dz", &c );

    if ( (c < 0) || (c > 9)){
        printf("Error : It's an invalid input\n ");
        return 1;
    }

    printf("Please enter the sum : ");
    scanf("%d", &sum); 


    if(((sum % 10)- b) < 0 ){// 個進位
        z = 10 + (sum % 10) - b;
    } else {
        z = (sum % 10) - b ; 
    }

    if (((sum % 10)- b) < 0) { // 個進位
        if ((((sum / 10) % 10 ) - (c+1)) < 0){ // 十進位
            x = 10 + ((sum / 10) % 10 ) - (c+1);
            y = (sum/100) - (a+1) ;
        }else { // 十 不進位
            x = ((sum / 10) % 10 ) - (c+1);
            y = (sum/100) - a ;
        }
    } else { // 個 不進位
        if ((((sum / 10) % 10 ) - c) < 0){ // 十進位
            x = 10 + ((sum / 10) % 10 ) - c;
            y = (sum/100) - (a+1) ;
        }else { // 十 不進位
            x = ((sum / 10) % 10 ) - c;
            y = (sum/100) - a ;
        }
    }

    printf("Ans:");
    printf("x = %d ,", x);
    printf("y = %d ,", y);
    printf("z = %d\n", z);

    return 0;
}
