#include <stdio.h>
#include <stdint.h>

int main(){
    int16_t a, b, c, d, e ;
    char  extra ;
    int16_t temp = 0 ;
    printf("Please enter 5 cards:");

    // scanf("%hd %hd %hd %hd %hd" , &a, &b, &c, &d, &e);

    if (scanf("%hd %hd %hd %hd %hd", &a, &b, &c, &d, &e) != 5) {
        printf("Error: Please enter exactly 5 numbers.\n");
        return 1;
    }

    // 檢查多餘的輸入
    if (scanf("%c", &extra) == 1) {  
        if (extra != '\n') { // 如果下一個是換行，表示輸入結束
            printf("Error: You entered too many numbers.\n");
            return 1;
        }
    }

/* ??

    // 讀取第六個輸入，檢查是否有多餘的輸入
    if (scanf("%hd", &extra) == 1) {
        printf("Error: You entered too many numbers.\n");
        return 1;
    }
    
*/

    if((a <= 0 || a > 52) || (b <= 0 || b > 52 )|| (c <= 0 || c > 52) || (d <= 0 || d > 52) || (e <= 0 || e >52)){
        printf("Error: All numbers must be between 1 and 52.\n ");
        return 1 ;
    } else if ((a == b) || (a == c) || (a == d) || (a == e) || (b ==c) || (b == d) || (b == e) ||
        (c == d) || (c == e) || (d == e)){
        printf("Error: None of the numbers will be the same. \n");
        return 1 ;

    }

    //由大到小排序，
    if (a > b) { temp = a; a = b; b = temp; }
    if (a > c) { temp = a; a = c; c = temp; }
    if (a > d) { temp = a; a = d; d = temp; }
    if (a > e) { temp = a; a = e; e = temp; }

    if (b > c) { temp = b; b = c; c = temp; }
    if (b > d) { temp = b; b = d; d = temp; }
    if (b > e) { temp = b; b = e; e = temp; }

    if (c > d) { temp = c; c = d; d = temp; }
    if (c > e) { temp = c; c = e; e = temp; }

    if (d > e) { temp = d; d = e; e = temp; }

    if( (((a-1)/13 == (b-1)/13) && ((a-1)/13 == (c-1)/13) && ((a-1)/13 == (d-1)/13) && ((a-1)/13 == (e-1)/13)) && 
        (b == a + 1 && c == b + 1 && d == c + 1 && e == d + 1))  {
        printf("Straight Flush\n");
    } else if (((a%13) == (b%13) && (a%13) == (c%13) && (a%13) == (d%13)) || ((a%13) == (b%13) && (a%13) == (c%13) && (a%13) == (e%13)) || 
        ((a%13) == (b%13) && (a%13) == (d%13) && (a%13) == (e%13)) || ((a%13) == (c%13) && (a%13) == (d%13) && (a%13) == (e%13)) || 
        ((b%13) == (c%13) && (b%13) == (d%13) && (b%13) == (e%13)) ) { 
        printf(" Four of a Kind\n");
    } else if (((a%13) == (b%13) && (a%13) == (c%13) && (d%13) == (e%13)) || ((a%13) == (b%13) && (a%13) == (d%13) && (c%13) == (e%13)) || 
        ((a%13) == (b%13) && (a%13) == (e%13) && (c%13) == (d%13)) || ((a%13) == (c%13) && (a%13) == (d%13) && (b%13) == (e%13)) || 
        ((a%13) == (c%13) && (a%13) == (e%13) && (b%13) == (d%13)) || ((a%13) == (d%13) && (a%13) == (e%13) && (b%13) == (c%13)) || 
        ((b%13) == (c%13) && (b%13) == (d%13) && (a%13) == (e%13)) || ((b%13) == (c%13) && (b%13) == (e%13) && (a%13) == (d%13)) || 
        ((b%13) == (d%13) && (b%13) == (e%13) && (a%13) == (c%13)) || ((c%13) == (d%13) && (c%13) == (e%13) && (a%13) == (b%13)) ) {
        printf("Full house\n");
    } else if ( ((a-1)/13 == (b-1)/13) && ((a-1)/13 == (c-1)/13) && ((a-1)/13 == (d-1)/13) && ((a-1)/13 == (e-1)/13)) {
        printf("Flush\n");
    } else if ((b == a + 1 && c == b + 1 && d == c + 1 && e == d + 1) && ((b%13) != 1 && (c%13) != 1 && (d%13) != 1 )) {
        printf("Straight\n");
    } else if (((a%13) == (b%13) && (a%13) == (c%13)) || ((a%13) == (b%13) && (a%13) == (d%13)) || ((a%13) == (b%13) && (a%13) == (e%13)) ||
        ((a%13) == (c%13) && (a%13) == (d%13)) || ((a%13) == (c%13) && (a%13) == (e%13)) || ((a%13) == (d%13) && (a%13) == (e%13)) ||
        ((b%13) == (c%13) && (b%13) == (d%13)) || ((b%13) == (c%13) && (b%13) == (e%13)) || ((b%13) == (d%13) && (b%13) == (e%13)) ||
        ((c%13) == (d%13) && (c%13) == (e%13))) {
        printf("Three of a kind\n");
    } else if ((((a%13) == (b%13) && (c%13) == (d%13)) || ((a%13) == (b%13) && (c%13) == (e%13)) || ((a%13) == (b%13) && (d%13) == (e%13)) || 
         ((a%13) == (c%13) && (b%13) == (d%13)) || ((a%13) == (c%13) && (b%13) == (e%13)) || ((a%13) == (c%13) && (d%13) == (e%13)) || 
         ((a%13) == (d%13) && (b%13) == (c%13)) || ((a%13) == (d%13) && (b%13) == (e%13)) || ((a%13) == (d%13) && (c%13) == (e%13)) || 
         ((a%13) == (e%13) && (b%13) == (c%13)) || ((a%13) == (e%13) && (b%13) == (d%13)) || ((a%13) == (e%13) && (c%13) == (d%13)) ||
         ((b%13) == (c%13) && (d%13) == (e%13)) || ((b%13) == (d%13) && (c%13) == (e%13)) || ((b%13) == (e%13) && (c%13) == (d%13)))) {
        printf("Two Pairs\n");
    } else if((a%13) == (b%13) || (a%13) == (c%13) || (a%13) == (d%13) || (a%13) == (e%13) ||
        (b%13) == (c%13) || (b%13) == (d%13) || (b%13) == (e%13) ||
        (c%13) == (d%13) || (c%13) == (e%13) ||
        (d%13) == (e%13)) {
        printf("One Pair\n");
    } else {
        printf("High card\n");
    }

    /*
    Straight Flush：五張同花色、順號
    Four of a Kind：四張點數相同
    Full house：三張同點數，加一對其他點數
    Flush：同一花色
    Straight：五張順號。A不能在中間
    Three of a kind：有三張相同點數
    Two Pairs：兩張相同點數的牌，加另外兩張相同點數的牌。
    One Pair：兩張相同點數
    High card：不能排成以上組合的牌
    */
    
    return 0;

}