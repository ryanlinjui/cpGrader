#include <stdio.h>
#include <stdint.h>

int main() {
    char ch1, ch2, ch3, ch4; // 儲存四個16進制字符
    int16_t typ ;
    
    printf("Please input a hex: ");
    scanf(" %c %c %c %c", &ch1, &ch2, &ch3, &ch4);

    printf("Please choose the output type(1:integer ,2:unsigned integer ,3:float):");
    scanf("%hd", &typ);
    
    // 輸出對應的二進制
    printf("Binary of %c%c%c%c is:" , ch1,ch2,ch3,ch4 );
    
    // 第一個字符
    if (ch1 >= '0' && ch1 <= '9') {
        switch (ch1) {
            case '0': printf("0000 "); break;
            case '1': printf("0001 "); break;
            case '2': printf("0010 "); break;
            case '3': printf("0011 "); break;
            case '4': printf("0100 "); break;
            case '5': printf("0101 "); break;
            case '6': printf("0110 "); break;
            case '7': printf("0111 "); break;
            case '8': printf("1000 "); break;
            case '9': printf("1001 "); break;
        }
    } else if (ch1 >= 'A' && ch1 <= 'F') {
        switch (ch1) {
            case 'A': printf("1010 "); break;
            case 'B': printf("1011 "); break;
            case 'C': printf("1100 "); break;
            case 'D': printf("1101 "); break;
            case 'E': printf("1110 "); break;
            case 'F': printf("1111 "); break;
        }
    } else if (ch1 >= 'a' && ch1 <= 'f') {
        switch (ch1) {
            case 'a': printf("1010 "); break;
            case 'b': printf("1011 "); break;
            case 'c': printf("1100 "); break;
            case 'd': printf("1101 "); break;
            case 'e': printf("1110 "); break;
            case 'f': printf("1111 "); break;
        }
    }

    // 第二個字符
    if (ch2 >= '0' && ch2 <= '9') {
        switch (ch2) {
            case '0': printf("0000 "); break;
            case '1': printf("0001 "); break;
            case '2': printf("0010 "); break;
            case '3': printf("0011 "); break;
            case '4': printf("0100 "); break;
            case '5': printf("0101 "); break;
            case '6': printf("0110 "); break;
            case '7': printf("0111 "); break;
            case '8': printf("1000 "); break;
            case '9': printf("1001 "); break;
        }
    } else if (ch2 >= 'A' && ch2 <= 'F') {
        switch (ch2) {
            case 'A': printf("1010 "); break;
            case 'B': printf("1011 "); break;
            case 'C': printf("1100 "); break;
            case 'D': printf("1101 "); break;
            case 'E': printf("1110 "); break;
            case 'F': printf("1111 "); break;
        }
    } else if (ch2 >= 'a' && ch2 <= 'f') {
        switch (ch2) {
            case 'a': printf("1010 "); break;
            case 'b': printf("1011 "); break;
            case 'c': printf("1100 "); break;
            case 'd': printf("1101 "); break;
            case 'e': printf("1110 "); break;
            case 'f': printf("1111 "); break;
        }
    }

    // 第三個字符
    if (ch3 >= '0' && ch3 <= '9') {
        switch (ch3) {
            case '0': printf("0000 "); break;
            case '1': printf("0001 "); break;
            case '2': printf("0010 "); break;
            case '3': printf("0011 "); break;
            case '4': printf("0100 "); break;
            case '5': printf("0101 "); break;
            case '6': printf("0110 "); break;
            case '7': printf("0111 "); break;
            case '8': printf("1000 "); break;
            case '9': printf("1001 "); break;
        }
    } else if (ch3 >= 'A' && ch3 <= 'F') {
        switch (ch3) {
            case 'A': printf("1010 "); break;
            case 'B': printf("1011 "); break;
            case 'C': printf("1100 "); break;
            case 'D': printf("1101 "); break;
            case 'E': printf("1110 "); break;
            case 'F': printf("1111 "); break;
        }
    } else if (ch3 >= 'a' && ch3 <= 'f') {
        switch (ch3) {
            case 'a': printf("1010 "); break;
            case 'b': printf("1011 "); break;
            case 'c': printf("1100 "); break;
            case 'd': printf("1101 "); break;
            case 'e': printf("1110 "); break;
            case 'f': printf("1111 "); break;
        }
    }

    // 第四個字符
    if (ch4 >= '0' && ch4 <= '9') {
        switch (ch4) {
            case '0': printf("0000 "); break;
            case '1': printf("0001 "); break;
            case '2': printf("0010 "); break;
            case '3': printf("0011 "); break;
            case '4': printf("0100 "); break;
            case '5': printf("0101 "); break;
            case '6': printf("0110 "); break;
            case '7': printf("0111 "); break;
            case '8': printf("1000 "); break;
            case '9': printf("1001 "); break;
        }
    } else if (ch4 >= 'A' && ch4 <= 'F') {
        switch (ch4) {
            case 'A': printf("1010 "); break;
            case 'B': printf("1011 "); break;
            case 'C': printf("1100 "); break;
            case 'D': printf("1101 "); break;
            case 'E': printf("1110 "); break;
            case 'F': printf("1111 "); break;
        }
    } else if (ch4 >= 'a' && ch4 <= 'f') {
        switch (ch4) {
            case 'a': printf("1010 "); break;
            case 'b': printf("1011 "); break;
            case 'c': printf("1100 "); break;
            case 'd': printf("1101 "); break;
            case 'e': printf("1110 "); break;
            case 'f': printf("1111 "); break;
        }
    }

    printf("\n");

   
    if (typ == 1) { //Signed Integer
        int decimal = 0 , value ;

        if (ch1 >= '0' && ch1 <= '9') {
            value = ch1 - '0';
        } else if (ch1 >= 'A' && ch1 <= 'F') {
            value = ch1 - 'A' + 10;
        } else if (ch1 >= 'a' && ch1 <= 'f') {
            value = ch1 - 'a' + 10;
        }
        decimal += value * 4096; // 16^3

        // 將十六進制字符 ch2 轉換成十進制
        if (ch2 >= '0' && ch2 <= '9') {
        value = ch2 - '0';
        } else if (ch2 >= 'A' && ch2 <= 'F') {
            value = ch2 - 'A' + 10;
        } else if (ch2 >= 'a' && ch2 <= 'f') {
            value = ch2 - 'a' + 10;
        }
        decimal += value * 256; // 16^2

        // 將十六進制字符 ch3 轉換成十進制
        if (ch3 >= '0' && ch3 <= '9') {
            value = ch3 - '0';
        } else if (ch3 >= 'A' && ch3 <= 'F') {
            value = ch3 - 'A' + 10;
        } else if (ch3 >= 'a' && ch3 <= 'f') {
            value = ch3 - 'a' + 10;
        }
        decimal += value * 16; // 16^1

        // 將十六進制字符 ch4 轉換成十進制
        if (ch4 >= '0' && ch4 <= '9') {
            value = ch4 - '0';
        } else if (ch4 >= 'A' && ch4 <= 'F') {
            value = ch4 - 'A' + 10;
        } else if (ch4 >= 'a' && ch4 <= 'f') {
            value = ch4 - 'a' + 10;
        }
        decimal += value * 1; // 16^0

        // 如果最高位是負數符號位（16進制範圍8到F），需要轉換為二補數形式
        if (ch1 >= '8') {
        decimal -= 65536; // 減去 2^16，表示負數
        }

        printf("Converted signed integer is: %d\n", decimal);

    } else if (typ == 2){ // Unsigned Integer 
        int decimal = 0 , value ;

        if (ch1 >= '0' && ch1 <= '9') {
            value = ch1 - '0';
        } else if (ch1 >= 'A' && ch1 <= 'F') {
        value = ch1 - 'A' + 10;
        } else if (ch1 >= 'a' && ch1 <= 'f') {
            value = ch1 - 'a' + 10;
        }
        decimal += value * 4096; // 16^3

        // 將十六進制字符 ch2 轉換成十進制
        if (ch2 >= '0' && ch2 <= '9') {
        value = ch2 - '0';
        } else if (ch2 >= 'A' && ch2 <= 'F') {
            value = ch2 - 'A' + 10;
        } else if (ch2 >= 'a' && ch2 <= 'f') {
            value = ch2 - 'a' + 10;
        }
        decimal += value * 256; // 16^2

        // 將十六進制字符 ch3 轉換成十進制
        if (ch3 >= '0' && ch3 <= '9') {
            value = ch3 - '0';
        } else if (ch3 >= 'A' && ch3 <= 'F') {
            value = ch3 - 'A' + 10;
        } else if (ch3 >= 'a' && ch3 <= 'f') {
            value = ch3 - 'a' + 10;
        }
        decimal += value * 16; // 16^1

        // 將十六進制字符 ch4 轉換成十進制
        if (ch4 >= '0' && ch4 <= '9') {
            value = ch4 - '0';
        } else if (ch4 >= 'A' && ch4 <= 'F') {
            value = ch4 - 'A' + 10;
        } else if (ch4 >= 'a' && ch4 <= 'f') {
            value = ch4 - 'a' + 10;
        }
        decimal += value * 1; // 16^0

        printf("Converted unsigned integer is: %d\n", decimal);

    }else { // Float
        printf("Converted float is: \n");
        printf("Error: Sorry, I tried but I really don't know how to code this part. \n");
    }

    return 0;
}

