#include <stdio.h>
#include <stdint.h>

int main()
{
    //十進位轉八進位
    uint16_t a1, b1, c1, d1, e1, f1;
    printf("Please enter an unsigned 16-bits number: ");
    scanf("%hd", &a1);

    // 計算八進位
    b1 = a1 % 8;        // 第1位八進位
    c1 = (a1 / 8) % 8;  // 第2位八進位
    d1 = (a1 / 64) % 8; // 第3位八進位
    e1 = (a1 / 512) % 8; //第四位八進位
    f1 = (a1 / 4096) % 8;

    uint16_t num = f1*10000 + e1*1000 + d1*100 + c1*10 + b1 ;

    printf("Before Flip:\n");
    printf("%d_10 = %d_8\n", a1, num );
    

    //數字反轉
    uint16_t rev ;

    if(num >= 10000){
        rev = (num % 10) * 10000 + ((num / 10) % 10) * 1000 + ((num / 100) % 10) * 100 + ((num / 1000) % 10) * 10 + (num / 10000);  // 五位數
    } else if (num >= 1000) { 
        rev = (num % 10) * 1000 + ((num / 10) % 10) * 100 + ((num / 100) % 10) * 10 + (num / 1000);  // 四位數
    }else if (num >= 100) { 
        rev = (num % 10) * 100 + ((num / 10) % 10) * 10 + (num / 100);  // 三位數
    } else if (num >= 10) { 
        rev = (num % 10) * 10 + (num / 10);  // 二位數
    } else { 
        rev = num;  // 一位數
    }

    //八進位轉十進位
    uint16_t b2, c2, d2, e2, f2 ;

	b2 = rev % 10;  //取出個位數 
	c2 = (rev - b2) % 100 / 10;  //取出十位數 
	d2 = (rev / 100) % 10;  //取出百位數 
	e2 = (rev / 1000) % 10; //取千位數
    f2 = rev / 10000 ;

    uint16_t num2 = f2*4096 + e2*512 + d2*64 + c2*8 + b2 ; 
	
    printf("After Flip:\n");
    printf("%d_8 = %d_10\n", rev, num2 );


    return 0;
}
