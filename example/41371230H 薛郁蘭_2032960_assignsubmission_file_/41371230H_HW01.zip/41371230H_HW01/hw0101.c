#include <stdio.h>

int main() {
    // 直接使用 ANSI 顏色代碼進行顏色設定
    printf("\033[0;31m[KIM]\n\033[0m");  // Kim's lyrics in red
    printf("\033[0;31m You are sunlight and I moon\n\033[0m");
    printf("\033[0;31m Joined by the gods of fortune\n\033[0m");
    printf("\033[0;31m Midnight and high noon sharing the sky\n\033[0m");
    printf("\033[0;31m We have been blessed, you and I\n\n\033[0m");

    printf("\033[0;34m[CHRIS]\n\033[0m");  // Chris's lyrics in blue
    printf("\033[0;34m You are here like a mystery\n\033[0m");
    printf("\033[0;34m I'm from a world that's so different from all that you are\n\033[0m");
    printf("\033[0;34m How in the light of one night did we come so far?\n\n\033[0m");

    printf("\033[0;31m[KIM]\n\033[0m");  
    printf("\033[0;31m Outside day starts to dawn\n\n\033[0m");

    printf("\033[0;34m[CHRIS]\n\033[0m");  
    printf("\033[0;34m Your moon still floats on high\n\n\033[0m");

    printf("\033[0;31m[KIM]\n\033[0m"); 
    printf("\033[0;31m The birds awake\n\n\033[0m");
    printf("\033[0;34m[CHRIS]\n The stars shine too\n\n\033[0m");

    printf("\033[0;31m[KIM]\n\033[0m");  
    printf("\033[0;31m My hands still shake\n\033[0m"); 
    printf("\033[0;31m See upcoming pop shows\n\033[0m");
    printf("\033[0;31m Get tickets for your favorite artists\n\n\033[0m");
   
    printf("\033[0;31m You might also like\n\033[0m");
    printf("\033[0;31m My Boy Only Breaks His Favorite Toys\n\033[0m");
    printf("\033[0;31m Taylor Swift\n\033[0m");
    printf("\033[0;31m Who’s Afraid of Little Old Me?\n\033[0m");
    printf("\033[0;31m Taylor Swift\n\033[0m");
    printf("\033[0;31m Guilty as Sin?\n\033[0m");
    printf("\033[0;31m Taylor Swift\n\n\033[0m");
    

    printf("\033[0;34m[CHRIS]\n\033[0m");  
    printf("\033[0;34m I reach for you\n\n\033[0m");

    printf("\033[0;32m[KIM & CHRIS]\n\033[0m");  
    printf("\033[0;32m And we meet in the sky\n\n\033[0m");

    printf("\033[0;31m[KIM]\n\033[0m");  
    printf("\033[0;31m You are sunlight and I moon\n\033[0m");
    printf("\033[0;31m Joined here\n\033[0m");
    printf("\033[0;31m Brightening the sky with the flame of love\n\n\033[0m");

    printf("\033[0;32m[KIM & CHRIS]\n\033[0m"); 
    printf("\033[0;32m Made of\n\033[0m");
    printf("\033[0;32m Sunlight\n\033[0m");
    printf("\033[0;32m Moonlight\n\033[0m");

    return 0;
}

