#include<stdio.h>

int main()
{
printf("\033[1;31m [KIM]\n You are sunlight and I moon\n Joined by the gods of fortune\n Midnight and high noon sharing the sky\n We have been blessed , you and I\n\033[m");
printf(" \n");
printf("\033[1;34m [CHRIS]\n You are here like a mystery\n I'm from a world that's so different from all that you are\n How in the light of one night did we come so far?\n\033[m");
printf(" \n");
printf("\033[1;31m [KIM]\n Outside day starts to dawn\n\033[m");
printf(" \n");
printf("\033[1;34m [CHRIS]\n Your moon still floats on high\n\033[m");
printf(" \n");
printf("\033[1;31m [KIM]\n The birds awake\n\033[m");
printf(" \n");
printf("\033[1;34m [CHRIS]\n The stars shine too\n\033[m");
printf(" \n");
printf("\033[1;31m [KIM]\n My hands still shake\n See upcoming pop shows\n Get tickets for your favorite artists\n\033[m");
printf(" \n");
printf("\033[1;31m You might also like\n My Boy Only Breaks His Favorite Toys\n Taylor Swift\n Who’s Afraid of Little Old Me?\n Taylor Swift\n Guilty as Sin?\n Taylor Swift\n\033(m");
printf(" \n");
printf("\033[1;34m [CHRIS]\n I reach for you\n\033(m");
printf(" \n");
printf("\033[1;32m [KIM & CHRIS]\n And we meet in the sky\n\033(m");
printf(" \n");
printf("\033[1;31m [KIM]\n You are sunlight and I moon\n Joined here\n Brightening the sky with the flame of love\n\033(m");
printf(" \n");
printf("\033[1;32m [KIM & CHRIS]\n Made of\n Sunlight\n Moonlight\n\033(m");

return 0;
}
