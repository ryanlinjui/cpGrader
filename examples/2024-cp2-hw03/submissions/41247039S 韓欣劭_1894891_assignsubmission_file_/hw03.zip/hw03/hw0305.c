#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>

#include "myfile.h"
#include "mybmp.h"
#include "mychart.h"

const char *g_shortOpts = "i:o:w:h:l:H";
const struct option g_longOpts[] = {
    {"input",  required_argument, NULL, 'i'},
    {"output", required_argument, NULL, 'o'},
    {"width",  required_argument, NULL, 'w'},
    {"height", required_argument, NULL, 'h'},
    {"line",   required_argument, NULL, 'l'},
    {"help",   no_argument,       NULL, 'H'},
    {0, 0, 0, 0},
};

const char *g_helpUsage = "Usage: ./hw0305 [option]...\n";
const char *g_helpInfo  = "Try ./hw0305 --help for more information.\n";
const char *g_helpMsg   = "\
Generate an image RGB histogram.\n\
\n\
Options:\n\
  -i, --input=FILE      mandatory, the input bmp file\n\
  -o, --output=FILE     mandatory, the output bmp file\n\
  -w, --width=NUM       mandatory, the output bmp width\n\
  -h, --height=NUM      mandatory, the output bmp height\n\
  -l, --line=NUM        mandatory, the radius of line\n\
  -H, --help            display this message and exit\n\
";

int main(int argc, char *argv[]) {
    // Check arguments

    char c = 0;

    int32_t width  = 0;
    int32_t height = 0;
    int32_t radius = 0;

    char srcName[F_SIZE] = {0};
    char dstName[F_SIZE] = {0};
    FILE *srcFile = NULL;
    FILE *dstFile = NULL;

    while ((c = getopt_long(argc, argv, g_shortOpts, g_longOpts, NULL)) != -1) {
        if (c == '?' || c == 'H') {
            printf("%s%s", g_helpUsage, g_helpMsg);
            return (c == '?');
        }
        else if (c == 'w' || c == 'h' || c == 'l') {
            char *endptr  = NULL;
            int32_t *temp = NULL;

            if (c == 'w') {
                temp = &width;
            }
            else if (c == 'h') {
                temp = &height;
            }
            else {
                temp = &radius;
            }

            *temp = (int32_t) strtol(optarg, &endptr, 10);

            if (strlen(endptr) != 0) {
                printf("hw0305: error argument '%s': invalid argument\n", optarg);
                printf("%s%s", g_helpUsage, g_helpInfo);
                return 1;
            }
            else if (*temp <= 0) {
                printf("hw0305: error argument '%s': should be larger than 0\n", optarg);
                printf("%s%s", g_helpUsage, g_helpInfo);
                return 1;
            }
        }
        else if (c == 'i' || c == 'o') {
            if (c == 'i') {
                strncpy(srcName, optarg, F_SIZE);
            }
            else {
                strncpy(dstName, optarg, F_SIZE);
            }

            if (strcmp(srcName, dstName) == 0) {
                printf("hw0305: error: input file is same as output file.\n");
                printf("%s%s", g_helpUsage, g_helpInfo);
                return 1;
            }
        }
    }

    if (width == 0 || height == 0 || radius == 0 ||
        strlen(srcName) == 0 || strlen(dstName) == 0) {
        printf("hw0305: error: mandatory options are not enough\n");
        printf("%s%s", g_helpUsage, g_helpInfo);
        return 1;
    }

    if (optind < argc) {
        printf("hw0305: warning: extra arguments are given and will be ignored\n");
    }

    // Open files and generate chart

    if (openFile(&srcFile, srcName, "rb") || openFile(&dstFile, dstName, "wb")) {
        return 1;
    }

    RgbData data = {
        srcFile, dstFile, width, height, radius
    };

    int32_t ret = generateRgbChart(&data);

    closeFile(srcFile);
    closeFile(dstFile);

    return ret;
}
