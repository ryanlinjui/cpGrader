#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include "myfile.h"

typedef struct _TraceCode {
    char code[F_SIZE];
    int32_t line;
} TraceCode;

typedef struct _TraceFile {
    char name[F_SIZE];
    TraceCode *tCode;
    int32_t tCodeSize;
} TraceFile;

typedef struct _TraceFunc {
    char name[F_SIZE];
    TraceFile *tFile;
    int32_t tFileSize;
} TraceFunc;

typedef struct _TraceHead {
    TraceFunc *tFunc;
    int32_t tFuncSize;
} TraceHead;

/**
 * Trace all the functions within the header from the given file.
 * @param tFunc TraceFunc struct
 * @param fileName the file to be traced
 * @return 0 if success, non-zero otherwise
 */
int32_t traceHeader (TraceHead *tHead, char *fileName);

/**
 * Trace the function from the given file.
 * @param tFunc TraceFunc struct
 * @param fileName the file to be traced
 * @return 0 if success, non-zero otherwise
 */
int32_t traceFunction(TraceFunc *tFunc, char *fileName);

/**
 * Process the header file and store the function names.
 * @param tHead TraceHead struct
 * @param fileName the file to be processed
 * @return 0 if success, non-zero otherwise
 */
int32_t processHeader(TraceHead *tHead, char *fileName);

/**
 * Remove the comment from the code.
 * @param code the code string
 * @param flag the flag to indicate if the code is in comment
 * @return 0 if success, non-zero otherwise
 */
int32_t removeComment(char *code, int32_t *flag);

/**
 * Find the function in the code and store the function name.
 * @param code the code string
 * @param funcName the function name to be stored
 * @param flag the flag to indicate if the code is in comment
 * @return 1 if the code has the function, 0 otherwise
 */
int32_t findFunction(char *code, char *funcName, int32_t flag);

/**
 * Check if the code has the trace function code.
 * @param code the code string
 * @param funcName the function name
 * @param flag the flag to indicate if the code is in comment
 * @return 1 if the code has the trace function code, 0 otherwise
 */
int32_t hasTraceFunctionCode(char *code, char *funcName, int32_t flag);

/**
 * Add new trace function.
 * @param tHead TraceHead struct
 * @param funcName the function name
 * @return the index of TraceFunc in TraceHead if success, -1 otherwise
 */
int32_t addTraceFunc(TraceHead *tHead, char *funcName);

/**
 * Add new trace file.
 * @param tHead TraceHead struct
 * @param funcName the file name
 * @return the index of TraceFile in TraceFunc if success, -1 otherwise
 */
int32_t addTraceFile(TraceFunc *tFunc, char *fileName);

/**
 * Add new trace code.
 * @param tHead TraceHead struct
 * @param funcName the code string
 * @param line the line number
 * @return the index of TraceCode in TraceFile if success, -1 otherwise
 */
int32_t addTraceCode(TraceFile *tFile, char *code, int32_t line);

/**
 * Print the trace header functions, with optional line and code
 * @param tHead TraceHead struct
 * @param lineFlag the flag to print line
 * @param codeFlag the flag to print code
 */
void printTraceHeader(TraceHead *tHead, uint8_t lineFlag, uint8_t codeFlag);

/**
 * Print the trace function, with optional line and code
 * @param tFunc TraceFunc struct
 * @param lineFlag the flag to print line
 * @param codeFlag the flag to print code
 */
void printTraceFunction(TraceFunc *tFunc, uint8_t lineFlag, uint8_t codeFlag);

/**
 * Free the TraceHead and its content.
 * @param tHead TraceHead struct
 */
void freeTraceHead(TraceHead *tHead);
