#include "mybible.h"

int32_t searchText(FILE *file, char *search) {
    if (file == NULL || search == NULL) {
        printf("mybible: Error input\n");
        return 1;
    }

    Bible bible = {NULL, 0};
    BibleText temp = { 0, 0, {0}, {0} };

    while (readBibleText(file, &temp) == 0) {
        if (hasSearchText(temp.text, search)) {
            addBibleText(&bible, &temp);
        }
    }

    printBibleText(&bible);

    freeBible(&bible);
    return 0;
}

int32_t readBibleText(FILE *file, BibleText *text) {
    if (feof(file)) {
        return 0;
    }

    text->chapter = 0;
    text->verse   = 0;

    text->text[0] = 0;
    text->id[0]   = 0;

    char format[] = "{\"chapter\":%d,\"verse\":%d,\"text\":\"%[^\"]\",\"translation_id\":\"%*[^\"]\",\"book_id\":\"%[^\"]\",\"book_name\":\"%*[^\"]\"}";

    int32_t fs = fscanf(file, format, &(text->chapter), &(text->verse), &(text->text), &(text->id));

    if (fs != 4) {
        return 1;
    }

    fgetc(file);

    return 0;
}

int32_t addBibleText(Bible *bible, BibleText *text) {
    int32_t idx = bible->size;
    bible->size++;

    if (idx == 0) {
        bible->text = (BibleText *) calloc(bible->size, sizeof(BibleText));
    } else {
        bible->text = (BibleText *) reallocarray(bible->text, bible->size, sizeof(BibleText));
    }

    bible->text[idx].verse   = text->verse;
    bible->text[idx].chapter = text->chapter;

    strcpy(bible->text[idx].text, text->text);
    strcpy(bible->text[idx].id,   text->id);

    return 1;
}

bool hasSearchText(char *text, char *search) {
    size_t i = 0;

    while (i < strlen(text)) {
        if (!isSameChar(text[i], search[0])) {
            i++;
            continue;
        }

        size_t k = 0;

        while (k < strlen(search)) {
            if (i + k >= strlen(text) || !isSameChar(text[i+k], search[k])) {
                break;
            }

            k++;
        }

        if (k == strlen(search)) {
            return true;
        }

        i += k;
    }

    return false;
}

bool isSameChar(char a, char b) {
    if (a >= 'A' && a <= 'Z') {
        a += 'a' - 'A';
    }

    if (b >= 'A' && b <= 'Z') {
        b += 'a' - 'A';
    }

    return (a == b);
}

void printBibleText(Bible *bible) {
    printf("Found %d time(s)\n", bible->size);

    if (bible->size == 0) {
        return;
    }

    for (int32_t i = 0; i < bible->size; i++) {
        BibleText *tmp = &(bible->text[i]);
        printf("%d. %s %d:%d %s\n", i+1, tmp->id, tmp->chapter, tmp->verse, tmp->text);
    }
}

void freeBible(Bible *bible) {
    if (bible->size == 0) {
        return;
    }

    free(bible->text);
    bible->text = NULL;

    return;
}
