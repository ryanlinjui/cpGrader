#include "mycheat.h"

int32_t createCharacter(Character *chr, uint8_t *buffer, ssize_t size, ssize_t offset) {
    if (buffer + offset >= buffer + size) {
        fprintf(stderr, "Invalid offset\n");
        return 1;
    }

    chr->positionX = *(buffer + offset);
    chr->positionY = *(buffer + offset + 1);

    chr->image[0] = *(buffer + offset + 2);
    chr->image[1] = *(buffer + offset + 3);
    chr->image[2] = *(buffer + offset + 4);

    chr->action = *(buffer + offset + 5);
    chr->side = *(buffer + offset + 6);

    chr->portraitID = *(buffer + offset + 7);
    chr->name = *(uint16_t *) (buffer + offset + 8);

    for (int32_t i = 0; i < 8; i++) {
        chr->items[i][0] = *(buffer + offset + 10 + i * 2);
        chr->items[i][1] = *(buffer + offset + 11 + i * 2);
    }

    for (int32_t i = 0; i < 5; i++) {
        chr->spells[i] = *(buffer + offset + 26 + i);
    }

    chr->raceID = *(buffer + offset + 31);
    chr->classID = *(buffer + offset + 32);

    chr->LV = *(buffer + offset + 33);

    for (int32_t i = 0; i < 3; i++) {
        chr->buffs[i] = *(buffer + offset + 34 + i);
    }

    for (int32_t i = 0; i < 3; i++) {
        chr->debuffs[i] = *(buffer + offset + 37 + i);
    }

    for (int32_t i = 0; i < 15; i++) {
        chr->padding[i] = *(buffer + offset + 40 + i);
    }

    chr->MT = *(uint16_t *) (buffer + offset + 55);
    chr->DF = *(uint16_t *) (buffer + offset + 57);
    chr->MV = *(buffer + offset + 59);
    chr->EX = *(buffer + offset + 60);
    chr->pd = *(buffer + offset + 61);
    chr->DX = *(uint16_t *) (buffer + offset + 62);

    chr->curHP = *(uint16_t *) (buffer + offset + 64);
    chr->maxHP = *(uint16_t *) (buffer + offset + 66);
    chr->curMP = *(uint16_t *) (buffer + offset + 68);
    chr->maxMP = *(uint16_t *) (buffer + offset + 70);

    chr->AP  = *(uint16_t *) (buffer + offset + 72);
    chr->DP  = *(uint16_t *) (buffer + offset + 74);
    chr->HIT = *(uint16_t *) (buffer + offset + 76);
    chr->EV  = *(uint16_t *) (buffer + offset + 78);

    return 0;
}

void printCharacters(Character *chr, int32_t count) {
    for (int32_t i = 0; i < count; i++) {
        printf("Character %d\n", i + 1);
        printCharacter(&(chr[i]));
        printf("\n");
    }
}

void printCharacter(Character *chr) {
    if (chr == NULL) {
        fprintf(stderr, "Invalid character\n");
        return;
    }

    printf("Position: %d, %d\n", chr->positionX, chr->positionY);

    printf("Character: ");
    printPortrait(chr->portraitID);
    printf(", Class: ");
    printClass(chr->classID);
    printf("\n");

    printf("+-----+ LV: %02d HP: %d/%d\n", chr->LV, chr->curHP, chr->maxHP);
    printf("|     |\n");
    printf("+-----+ EX: %02d MP: %d/%d\n", chr->EX, chr->curMP, chr->maxMP);
    printf("DX: %03d MV: %02d\n", chr->DX, chr->MV);
    printf("HIT:%03d AP: %03d\n", chr->HIT, chr->AP);
    printf("EV: %03d DP: %03d\n", chr->EV, chr->DP);

    printItems(chr->items);

    printf("spells: ");

    for (int32_t i = 0; i < 5; i++) {
        printf("%d", chr->spells[i]);

        if (i < 4) {
            printf(", ");
        }
        else {
            printf("\n");
        }
    }
}

void printPortrait(uint8_t portraitID) {
    for (int32_t i = 0; i < PORTRAIT_SIZE; i++) {
        if (PORTRAIT[i].id == portraitID) {
            printf("%s", PORTRAIT[i].name);
            return;
        }
    }

    fprintf(stderr, "Invalid portrait ID\n");
}

void printClass(uint8_t classID) {
    for (int32_t i = 0; i < CLASS_SIZE; i++) {
        if (CLASS[i].id == classID) {
            printf("%s", CLASS[i].name);
            return;
        }
    }

    fprintf(stderr, "Invalid class ID\n");
}

void printItems(uint8_t items[][2]) {
    for (int32_t i = 0; i < 8; i++) {
        printf("Item %d: ", i + 1);

        if (items[i][0] == ITEM_STATUS_EMPTY) {
            printf("empty\n");
            continue;
        }

        for (int32_t j = 0; j < ITEM_SIZE; j++) {
            if (ITEM[j].id == items[i][1]) {
                printf("%s", ITEM[j].name);

                if (items[i][0] == ITEM_STATUS_EQUIPPED) {
                    printf(" (equipped)");
                }

                printf("\n");
            }
        }
    }
}
