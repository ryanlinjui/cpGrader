#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>

#include "mybmp.h"

typedef struct _RgbData {
    FILE *srcFile;
    FILE *dstFile;
    int32_t width;
    int32_t height;
    int32_t radius;
} RgbData;

typedef struct _RgbFreq {
    uint64_t r[256];
    uint64_t g[256];
    uint64_t b[256];
    uint64_t maxFreq;
} RgbFreq;

typedef enum _RgbColor {
    RED, GREEN, BLUE
} RgbColor;

/**
 * Generate RGB histogram from source BMP file.
 * @param data the RgbData struct
 * @return 1 if success, otherwise non-zero value
 */
int32_t generateRgbChart(RgbData *data);

/**
 * Calculate the frequency of each intensity for each pixels of bmp file.
 * @param bmp the BMP struct
 * @param freq the RgbFreq struct
 * @return 1 if success, otherwise non-zero value
 */
int32_t calculateRgbFreq(BMP *bmp, RgbFreq *freq);

/**
 * Draw the RGB histogram using the frequency data.
 * @param bmp the BMP struct
 * @param freq the RgbFreq struct
 * @param data the RgbData struct
 * @return 1 if success, otherwise non-zero value
 */
int32_t plotRgbChart(BMP *bmp, RgbFreq *freq, RgbData *data);

int32_t findYPos(int32_t x, int32_t x1, int32_t x2, int32_t y1, int32_t y2);

void plotGradientDot(BmpPixel **pixels, int32_t x, int32_t y, RgbColor color, RgbData *data);
