#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>

#include "mybmp.h"

/**
 * Write secret data into BMP file.
 * @param bmpFile the bmp file stream
 * @param secFile the secret file stream
 * @param bit the number of bits for each byte to be written in bmp file
 * @return 0 if success, otherwise non-zero value
 */
int32_t writeSecretData(FILE *bmpFile, FILE *secFile, int32_t bit);

/**
 * Extract secret data from BMP file and write into secret file.
 * @param bmpFile the bmp file stream
 * @param secFile the secret file stream
 * @param bit the number of bits for each byte to be extracted from bmp file
 * @return 0 if success, otherwise non-zero value
 */
int32_t extractSecretData(FILE *bmpFile, FILE *secFile, int32_t bit);
