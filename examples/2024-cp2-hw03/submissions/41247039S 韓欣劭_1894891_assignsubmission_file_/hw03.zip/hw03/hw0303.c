#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>

#include "myfile.h"
#include "mybmp.h"
#include "mystego.h"

const char *g_shortOpts = "web:h";
const struct option g_longOpts[] = {
    {"write",   0, NULL, 'w'},
    {"extract", 0, NULL, 'e'},
    {"bits",    1, NULL, 'b'},
    {"help",    0, NULL, 'h'},
    {0, 0, 0, 0},
};

const char *g_helpUsage = "Usage: ./hw0303 [option]... [cover_bmp] [secret_data]\n";
const char *g_helpInfo  = "Try ./hw0303 --help for more information.\n";
const char *g_helpMsg   = "\
Embed the data to BMP image, or extract the data from the BMP image.\n\
\n\
Options:\n\
  -w, --write       write [secret_data] to [cover_bmp]\n\
  -e, --extract     extract the data from [cover_bmp] to [secret_data]\n\
  -b, --bits=NUM    embed LSB NUM(1-8) bits in each byte, default is 1\n\
  -h, --help        display this message and exit\n\
\n\
-w and -e are exclusive and must be at least one.\n\
";

int main(int argc, char *argv[]) {
    // Check arguments

    char c = 0, flag = 0;
    int32_t bit = 1;

    while ((c = getopt_long(argc, argv, g_shortOpts, g_longOpts, NULL)) != -1) {
        if (c == '?' || c == 'h') {
            printf("%s%s", g_helpUsage, g_helpMsg);
            return (c == '?');
        }
        else if (c == 'b') {
            char *endptr = NULL;
            bit = (int32_t) strtol(optarg, &endptr, 10);

            if (strlen(endptr) != 0 || bit < 0 || bit > 8) {
                printf("hw0303: error argument '%s'\n", optarg);
                printf("%s%s", g_helpUsage, g_helpInfo);
                return 1;
            }
        }
        else if (c == 'w' || c == 'e') {
            if (flag) {
                printf("hw0303: error option '%c'\n", c);
                printf("%s%s", g_helpUsage, g_helpInfo);
                return 1;
            }

            flag = c;
        }
    }

    if (flag == 0) {
        printf("hw0303: invalid argument: require -e or -w\n");
        printf("%s%s", g_helpUsage, g_helpInfo);
        return 1;
    }

    if (argc - optind != 2) {
        printf("%s%s", g_helpUsage, g_helpInfo);
        return 1;
    }

    // Check and open files

    char bmpName[F_SIZE] = {0};
    char secName[F_SIZE] = {0};
    char secMode[F_SIZE] = {0};
    FILE *bmpFile = NULL;
    FILE *secFile = NULL;

    strncpy(bmpName, argv[optind], F_SIZE);
    strncpy(secName, argv[optind + 1], F_SIZE);

    if (strcmp(bmpName, secName) == 0) {
        printf("hw0303: error: cover_bmp is same as secret_data.\n");
        return 1;
    }

    if (flag == 'w') {
        strncpy(secMode, "rb", F_SIZE);
    }
    else if (flag == 'e') {
        strncpy(secMode, "wb", F_SIZE);
    }
    else {
        printf("hw0303: error: unknown error\n");
        return 1;
    }

    if (openFile(&bmpFile, bmpName, "r+") || openFile(&secFile, secName, secMode)) {
        return 1;
    }

    // Write or extract secret data

    int32_t ret = 0;

    if (flag == 'w') {
        ret = writeSecretData(bmpFile, secFile, bit);
    }
    else if (flag == 'e') {
        ret = extractSecretData(bmpFile, secFile, bit);
    }
    else {
        printf("hw0303: error: unknown error\n");
        return 1;
    }

    closeFile(bmpFile);
    closeFile(secFile);

    return ret;
}
