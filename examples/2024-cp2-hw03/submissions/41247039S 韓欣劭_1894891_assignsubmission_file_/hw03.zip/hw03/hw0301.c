#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "myfile.h"
#include "mybible.h"

int main() {
    FILE *file = NULL;
    char fileName[] = "bible.txt";
    char search[F_SIZE] = {0};

    if (openFile(&file, fileName, "r")) {
        return 1;
    }

    printf("Please enter the search target: ");

    if (inputString(search)) {
        return 1;
    }

    if (searchText(file, search)) {
        printf("Search text error\n");
        return 1;
    }

    return 0;
}
