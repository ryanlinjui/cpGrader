#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>

#include "myfd2.h"

int32_t createCharacter(Character *chr, uint8_t *buffer, ssize_t size, ssize_t offset);

void printCharacters(Character *chr, int32_t count);

void printCharacter(Character *chr);

void printPortrait(uint8_t portraitID);

void printClass(uint8_t classID);

void printItems(uint8_t items[][2]);
