#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define F_SIZE 4096

/**
 * Input a string.
 * @param str the input string.
 * @return 0 if the input is successful, 1 otherwise.
 */
int32_t inputString(char *str);

/**
 * Open a file.
 * @param file the file stream pointer.
 * @param fileName the file name.
 * @param mode the open mode.
 * @return 0 if the file is opened successfully, 1 otherwise.
 */
int32_t openFile(FILE **file, char *fileName, char *mode);

/**
 * Close a file.
 * @param file the file stream pointer.
 */
void closeFile(FILE *file);
