#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>

#include "myfile.h"
#include "mytrace.h"

const char *g_shortOpts = "f:i:lch";
const struct option g_longOpts[] = {
    {"function", required_argument, NULL, 'f'},
    {"include",  required_argument, NULL, 'i'},
    {"linum",    no_argument,       NULL, 'l'},
    {"code",     no_argument,       NULL, 'c'},
    {"help",     no_argument,       NULL, 'h'},
    {0, 0, 0, 0},
};

const char *g_helpUsage = "Usage: hw0302 [options] ... [files] ...\n";
const char *g_helpInfo  = "Try ./hw0302 --help for more information.\n";
const char *g_helpMsg   = "\
  -f, --function=func Trace the func usage in [Files].\n\
  -i, --include=File  Trace all functions listed in the header file in [Files].\n\
  -l, --linum       Display the line number.\n\
  -c, --code        Display the code.\n\
  -h, --help        Display this infomation and exit\n\
\n\
-f and -i are exclusive and must be at least one.\n\
";

int main(int argc, char *argv[]) {
    // Check arguments

    char c = 0;
    uint8_t lineFlag = 0;
    uint8_t codeFlag = 0;
    uint8_t fileFlag = 0;
    uint8_t funcFlag = 0;

    char str[F_SIZE] = {0};

    while ((c = getopt_long(argc, argv, g_shortOpts, g_longOpts, NULL)) != -1) {
        if (c == '?' || c == 'h') {
            printf("%s%s", g_helpUsage, g_helpMsg);
            return (c == '?');
        }
        else if (c == 'c') {
            codeFlag = 1;
        }
        else if (c == 'l') {
            lineFlag = 1;
        }
        else if (c == 'f' || c == 'i') {
            if (fileFlag || funcFlag) {
                printf("hw0302: option 'f' and 'i' are exclusive\n");
                printf("%s%s", g_helpUsage, g_helpInfo);

                return EXIT_FAILURE;
            }

            strncpy(str, optarg, F_SIZE);

            funcFlag = (c == 'f');
            fileFlag = (c == 'i');
        }
    }

    if (funcFlag == 0 && fileFlag == 0) {
        printf("hw0302: require option 'f' or 'i'\n");
        printf("%s%s", g_helpUsage, g_helpInfo);

        return EXIT_FAILURE;
    }

    if (optind == argc) {
        printf("hw0302: no trace file is given\n");
        printf("%s%s", g_helpUsage, g_helpInfo);

        return EXIT_FAILURE;
    }

    TraceHead tHead = {NULL, 0};

    if (funcFlag) {
        if (addTraceFunc(&tHead, str) == -1) {
            printf("hw0302: error adding trace function\n");
            freeTraceHead(&tHead);
            return EXIT_FAILURE;
        }
    }
    else if (fileFlag) {
        if (processHeader(&tHead, str)) {
            printf("hw0302: error processing header file\n");
            freeTraceHead(&tHead);
            return EXIT_FAILURE;
        }
    }
    else {
        printf("hw0302: unknown error\n");
        return EXIT_FAILURE;
    }

    while (optind < argc) {
        if (traceHeader(&tHead, argv[optind])) {
            freeTraceHead(&tHead);
            return EXIT_FAILURE;
        }

        optind++;
    }

    printTraceHeader(&tHead, lineFlag, codeFlag);

    freeTraceHead(&tHead);

    return EXIT_SUCCESS;
}
