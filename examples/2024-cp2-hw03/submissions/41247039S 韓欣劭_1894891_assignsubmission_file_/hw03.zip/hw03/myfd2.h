#pragma once

#include <stdint.h>

typedef struct _Portrait {
    uint8_t id;
    char name[64];
} Portrait;

extern const int32_t PORTRAIT_SIZE;
extern const Portrait PORTRAIT[];

typedef enum _ItemStatus {
    ITEM_STATUS_NORMAL   = 0x00,
    ITEM_STATUS_EQUIPPED = 0x40,
    ITEM_STATUS_EMPTY    = 0x80
} ItemStatus;

typedef struct _Item {
    uint8_t id;
    char name[64];
} Item;

extern const int32_t ITEM_SIZE;
extern const Item ITEM[];

typedef struct _Class {
    uint8_t id;
    char name[64];
} Class;

extern const int32_t CLASS_SIZE;
extern const Class CLASS[];

typedef struct __attribute__ ((__packed__)) _Character {
    uint8_t positionX;
    uint8_t positionY;
    uint8_t image[3];
    uint8_t action;
    uint8_t side;
    uint8_t portraitID;
    uint16_t name;
    uint8_t items[8][2];
    uint8_t spells[5];
    uint8_t raceID;
    uint8_t classID;
    uint8_t LV;
    uint8_t buffs[3];
    uint8_t debuffs[3];
    uint8_t padding[15];
    uint16_t MT;
    uint16_t DF;
    uint8_t MV;
    uint8_t EX;
    uint8_t pd;
    uint16_t DX;
    uint16_t curHP;
    uint16_t maxHP;
    uint16_t curMP;
    uint16_t maxMP;
    uint16_t AP;
    uint16_t DP;
    uint16_t HIT;
    uint16_t EV;
} Character;
