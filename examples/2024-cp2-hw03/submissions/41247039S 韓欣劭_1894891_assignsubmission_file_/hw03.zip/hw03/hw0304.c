#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <getopt.h>

#include "mycheat.h"

#define GAME_MEM_SIZE 1024 * 1024 * 16

int32_t update(int32_t fd, off_t offset, Character *chr);
void cheat(int32_t fd, off_t offset, uint8_t *buffer, ssize_t bufferSize);

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: sudo %s <pid> <offset>\n", argv[0]);
        return 1;
    }

    char *endptr = NULL;

    pid_t pid = strtol(argv[1], &endptr, 10);

    if (pid == 0) {
        fprintf(stderr, "Invalid pid\n");
        return 1;
    }
    else if (endptr != NULL && *endptr != '\0') {
        fprintf(stderr, "Invalid pid\n");
        return 1;
    }

    off_t offset = strtol(argv[2], NULL, 16);

    // printf("pid: %d\n", pid);
    // printf("offset: %ld\n", offset);

    if (offset == 0) {
        fprintf(stderr, "Invalid offset\n");
        return 1;
    }
    else if (endptr != NULL && *endptr != '\0') {
        fprintf(stderr, "Invalid offset\n");
        return 1;
    }

    char path[256] = {0};
    snprintf(path, sizeof(path), "/proc/%d/mem", pid);

    int32_t fd = open(path, O_RDWR);
    if (fd == -1) {
        perror("Failed to open mem");
        return 1;
    }

    if (lseek(fd, offset, SEEK_SET) == -1) {
        perror("Failed to seek mem");
        close(fd);
        return 1;
    }

    uint8_t *buffer = malloc(GAME_MEM_SIZE);
    ssize_t readBytes = read(fd, buffer, GAME_MEM_SIZE);

    if (readBytes == -1) {
        perror("Failed to read mem");
        close(fd);
        free(buffer);
        return 1;
    }

    cheat(fd, offset, buffer, readBytes);

    close(fd);
    free(buffer);

    return 0;
}

void cheat(int32_t fd, off_t offset, uint8_t *buffer, ssize_t bufferSize) {
    uint16_t currHP = 0;
    uint16_t maxHP  = 0;

    printf("Enter 索爾's current HP and max HP: ");
    scanf("%hu %hu", &currHP, &maxHP);

    int32_t count = 0, select = 0;
    int32_t chrMem[10] = {0};

    for (ssize_t i = 0; i < bufferSize; i += 4) {
        uint16_t *pCurrHP = (uint16_t *) (buffer + i);
        uint16_t *pMaxHP  = (uint16_t *) (buffer + i + 2);

        if (*pCurrHP == currHP && *pMaxHP == maxHP) {
            // createCharacter(&chr[count], buffer, bufferSize, i - 64);
            Character *temp = (Character *) (buffer + i - 64);

            printf("Character %d\n", count + 1);
            printCharacter(temp);
            printf("\n");

            chrMem[count] = i - 64;

            count++;
        }
    }

    if (count == 0) {
        fprintf(stderr, "No character found\n");
        return;
    }
    else if (count == 1) {
        select = 1;
    }
    else {
        printf("Select the most likely character: ");
        scanf("%d", &select);
    }

    if (select < 1 || select > count) {
        printf("Invalid selection\n");
        return;
    }

    Character chr[10] = {0};

    if (createCharacter(&(chr[0]), buffer, bufferSize, chrMem[select - 1]) == 1) {
        return;
    }

    uint16_t numOfChr = 0;

    printf("Enter the number of characters in the party: ");
    scanf("%hu", &numOfChr);

    if (numOfChr < 1 || numOfChr > 10) {
        printf("Invalid number of characters\n");
        return;
    }

    for (int32_t i = 1; i < numOfChr; i++) {
        // Add characters to the party
        int32_t offset = chrMem[select - 1] + i * sizeof(Character);

        if (createCharacter(&chr[i], buffer, bufferSize, offset) == 1) {
            return;
        }
    }

    printf("Cheat activated!\n");

    while (1) {
        printf("=============================\n");
        printf("0. Print characters' status\n");
        printf("1. Modify characters' status\n");
        printf("2. Modify characters' items\n");
        printf("3. Exit\n");

        int32_t option = 0, chr_idx = 0;
        printf("Select an option: ");
        scanf("%d", &option);
        printf("-----------------------------\n");

        if (option == 3) {
            break;
        }
        else if (option == 0) {
            printCharacters(chr, numOfChr);
        }
        else if (option == 1) {
            for (int32_t i = 0; i < numOfChr; i++) {
                printf("%d. ", i + 1);
                printPortrait(chr[i].portraitID);
                printf("\n");
            }

            printf("Select a character: ");
            scanf("%d", &chr_idx);

            if (chr_idx < 1 || chr_idx > numOfChr) {
                printf("Invalid selection\n");
                continue;
            }

            chr_idx--;

            enum Status {
                HP = 1, MP, MT, DF, MV, EX, DX
            };

            int32_t status = 0;

            printf("1. HP\n");
            printf("2. MP\n");
            printf("3. MT\n");
            printf("4. DF\n");
            printf("5. MV\n");
            printf("6. EX\n");
            printf("7. DX\n");

            printf("Select a status to modify (1-7): ");
            scanf("%d", &status);

            if (status < 1 || status > 7) {
                printf("Invalid selection\n");
                continue;
            }
            else if (status == HP) {
                printf("Enter the new HP: ");
                scanf("%hu", &(chr[chr_idx].curHP));
                chr[chr_idx].maxHP = chr[chr_idx].curHP;
            }
            else if (status == MP) {
                printf("Enter the new MP: ");
                scanf("%hu", &(chr[chr_idx].curMP));
                chr[chr_idx].maxMP = chr[chr_idx].curMP;
            }
            else if (status == MT) {
                printf("Enter the new MT: ");
                scanf("%hu", &(chr[chr_idx].MT));
            }
            else if (status == DF) {
                printf("Enter the new DF: ");
                scanf("%hu", &(chr[chr_idx].DF));
            }
            else if (status == MV) {
                printf("Enter the new MV: ");
                scanf("%hhu", &(chr[chr_idx].MV));
            }
            else if (status == EX) {
                printf("Enter the new EX: ");
                scanf("%hhu", &(chr[chr_idx].EX));
            }
            else if (status == DX) {
                printf("Enter the new DX: ");
                scanf("%hu", &(chr[chr_idx].DX));
            }

            // Write back to the game memory
            off_t chr_offset = offset + chrMem[select - 1] + sizeof(Character) * chr_idx;

            if (update(fd, chr_offset, &chr[chr_idx]) == 1) {
                return;
            }

            printf("\nCharacter status updated!\n");
        }
        else if (option == 2) {
            for (int32_t i = 0; i < numOfChr; i++) {
                printf("%d. ", i + 1);
                printPortrait(chr[i].portraitID);
                printf("\n");
            }

            printf("Select a character: ");
            scanf("%d", &chr_idx);

            if (chr_idx < 1 || chr_idx > numOfChr) {
                printf("Invalid selection\n");
                continue;
            }

            chr_idx--;

            printItems(chr[chr_idx].items);

            int32_t item_idx = 0;

            printf("Select an item to modify (1-8): ");
            scanf("%d", &item_idx);

            if (item_idx < 1 || item_idx > 8) {
                printf("Invalid selection\n");
                continue;
            }

            item_idx--;

            int32_t item_id = 0;

            printf("Enter the item ID (HEX, 0xff to remove the item): ");
            scanf("%x", &item_id);

            if (item_id == 0xff) {
                chr[chr_idx].items[item_idx][0] = ITEM_STATUS_EMPTY;
                chr[chr_idx].items[item_idx][1] = 0x00;
            }
            else if (item_id < 0x00 || item_id > 0xd6) {
                chr[chr_idx].items[item_idx][0] = ITEM_STATUS_NORMAL;
                chr[chr_idx].items[item_idx][1] = item_id;
            }
            else {
                printf("Invalid item ID\n");
                continue;
            }

            // Write back to the game memory
            off_t chr_offset = offset + chrMem[select - 1] + sizeof(Character) * chr_idx;

            if (update(fd, chr_offset, &chr[chr_idx]) == 1) {
                return;
            }

            printf("\nCharacter items updated!\n");
        }
        else {
            printf("Invalid option\n");
        }
    }
}

int32_t update(int32_t fd, off_t offset, Character *chr) {
    if (lseek(fd, offset, SEEK_SET) == -1) {
        perror("Failed to seek mem");
        return 1;
    }

    if (write(fd, chr, sizeof(Character)) == -1) {
        perror("Failed to write mem");
        return 1;
    }

    fsync(fd);

    return 0;
}
