#include "mystego.h"

int32_t writeSecretData(FILE *bmpFile, FILE *secFile, int32_t bit) {
    BMP bmp = {NULL, NULL};

    if (initBMP(&bmp, bmpFile)) {
        return 1;
    }

    fseek(secFile, 0, SEEK_END);

    int32_t bmpByte = bmp.header->bitmap_size;
    int32_t secByte = ftell(secFile);

    if (bmpByte * bit < secByte * 8) {
        printf("mystego: error: secret data is too large\n");
        freeBMP(&bmp);
        return 1;
    }

    rewind(bmpFile);
    rewind(secFile);

    bmp.header->reserve = secByte;

    int32_t length = 0;
    int32_t x = 0, y = 0, c = 0;

    uint8_t buffer = 0;
    uint8_t lsbBit = (1 << bit) - 1;
    uint8_t *color = NULL;
    uint8_t temp   = 0;

    for (int32_t i = 0; i < secByte; i++) {
        temp = fgetc(secFile);

        for (int32_t j = 7; j >= 0; j--) {
            buffer = (buffer << 1) | ((temp >> j) & 1);
            length++;

            if (length != bit) {
                continue;
            }

            if (c % 3 == 0) {
                color = &(bmp.pixels[x][y].b);
            } else if (c % 3 == 1) {
                color = &(bmp.pixels[x][y].g);
            } else {
                color = &(bmp.pixels[x][y].r);
                y++;
            }

            *color = (*color & ~lsbBit) | buffer;

            c++;

            if (y == bmp.header->width) {
                x++;
                y = 0;
            }

            buffer = 0;
            length = 0;
        }
    }

    if (length > 0) {
        while (length < bit) {
            buffer <<= 1;
            length++;
        }

        if (c % 3 == 0) {
            color = &(bmp.pixels[x][y].b);
        } else if (c % 3 == 1) {
            color = &(bmp.pixels[x][y].g);
        } else {
            color = &(bmp.pixels[x][y].r);
        }

        *color = (*color & ~lsbBit) | buffer;
    }

    if (writeBMP(&bmp, bmpFile)) {
        return 1;
    }

    freeBMP(&bmp);

    return 0;
}

int32_t extractSecretData(FILE *bmpFile, FILE *secFile, int32_t bit) {
    BMP bmp = {NULL, NULL};

    if (initBMP(&bmp, bmpFile)) {
        return 1;
    }

    int32_t secByte  = bmp.header->reserve;
    int32_t readByte = secByte * 8 / bit;

    if ((secByte * 8) % bit) {
        readByte++;
    }

    int32_t length = 0;
    int32_t x = 0, y = 0, c = 0;

    uint8_t buffer = 0;
    uint8_t lsbBit = (1 << bit) - 1;
    uint8_t color  = 0;
    uint8_t temp   = 0;

    for (int32_t i = 0; i < readByte; i++) {
        if (c % 3 == 0) {
            color = bmp.pixels[x][y].b;
        } else if (c % 3 == 1) {
            color = bmp.pixels[x][y].g;
        } else {
            color = bmp.pixels[x][y].r;
            y++;
        }

        temp = color & lsbBit;

        c++;

        if (y == bmp.header->width) {
            x++;
            y = 0;
        }

        for (int32_t j = bit - 1; j >= 0; j--) {
            buffer = (buffer << 1) | ((temp >> j) & 1);
            length++;

            if (length != 8) {
                continue;
            }

            fputc(buffer, secFile);

            buffer = 0;
            length = 0;
        }
    }

    freeBMP(&bmp);

    return 0;
}
