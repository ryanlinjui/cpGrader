# hw03

Name: 41247039S 韓欣劭

Course: Computer Programming II

Link:

- [Question link](https://drive.google.com/file/d/1VGbyenKpI_BVqmt5Jtx8H7o06OtwbqOe/view)
- [Additional information](https://hackmd.io/@cp2023/cp2-hw3-info)

## Table of Contents

- [p1 Bible](#p1-bible)
- [p2 Function Tracer](#p2-function-tracer)
- [p3 Image Steganography](#p3-image-steganography)
- [p4 Game Cheater](#p4-game-cheater)
- [p5 RGB Line Chart](#p5-rgb-line-chart)

## p1 Bible

This program will find the given text from [bible.txt](bible.txt). User is required to input a search query and the program will output the search result.

## p2 Function Tracer

This program will find the usage of functions from given function or header file. Usage:

```console
hw0302 [options]... [files]...
```

Avaliable options:

- `-f` or `--function=FUNC`: the function used to search in files
- `-i` or `--include=FILE`: the header file, all functions inside this header file will be searched in given files
- `-l` or `--linum`: display the line number for the searched function
- `-c` or `--code`: display the line of code for the searched function
- `-h` or `--help`: display the help message and exit

The option `-f` and `-i` are exclusive and must be at least one. At least one file must be given to be searched.

## p3 Image Steganography

This program will embed the secret data file into a BMP file, or extract the secret data from BMP file. Usage:

```console
hw0303 [options]... [cover_bmp] [secret_data]
```

Available options:

- `-w` or `--write`: write the secret data into BMP file
- `-e` or `--extract`: extract the data from BMP file and save into given secret data file
- `-b` or `--bits=N`: save the data into N LSB bits of a byte, default is 1
- `-h` or `--help`: display the help message and exit

The option `-w` and `-e` are exclusive and must be at least one. If the data is too large to store in the BMP file, an error message will be given and the program will terminate without writing data into it.

## p4 Game Cheater

This program will cheat the game "炎龍騎士團2" when playing in dosbox-staging. Usage:

```console
sudo hw0304 [pid] [address]
```

The address can be found when dosbox-staging is opened. The pid can be found after opening dosbox-staging, by entering the following command:

```console
ps aux | grep dosbox
```

Steps after executing the program:

1. Input 索爾's current HP and max HP.
2. Select the most likely character if there're multiple results.
3. Input the number of characters in the party.

After these steps, the user will get the following result, which means the cheat is activated:

```console
Cheat activated!
=============================
0. Print characters' status
1. Modify characters' status
2. Modify characters' items
3. Exit
Select an option:
```

This cheat can modify two main things, which are status and items. If selecting "1. Modify characters' status", follow these steps:

1. Select a character to be modified.
2. Select a status to be modified, which includes HP, MP, MT, DF, MV, EX, DX.
3. Input the new value of the status.

If selecting "2. Modify characters' items", follow these steps:

1. Select a character to be modified.
2. The program will show the current character's items. Select the position of item to be modified.
3. Input the HEX ID of the item.

After modifying status or items, the program will update the result to the game and cheat the game.

[This website](https://chiuinan.github.io/game/game/intro/ch/c31/fd2/) provides a lot of information about this game. You can find the item's HEX ID from this page too.

## p5 RGB Line Chart

This program will draw the histogram about the frequencies of RGB color depths of a BMP file. Usage:

```console
hw0303 [options]...
```

Available options:

- `-i` or `--input=FILE`: MANDATORY, the input BMP file
- `-o` or `--output=FILE`: MANDATORY, the output histogram, stored in BMP
- `-w` or `--width=NUM`: MANDATORY, the output BMP width
- `-h` or `--height=NUM`: MANDATORY, the output BMP height
- `-l` or `--line=NUM`: MANDATORY, the radius of line of histogram
- `-H` or `--help`: display the help message and exit
