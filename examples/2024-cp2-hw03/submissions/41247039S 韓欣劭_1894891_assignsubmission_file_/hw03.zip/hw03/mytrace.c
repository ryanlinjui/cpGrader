#include "mytrace.h"

int32_t traceHeader(TraceHead *tHead, char *fileName) {
    if (tHead == NULL) {
        printf("mytrace: unknown error\n");
        return EXIT_FAILURE;
    }

    for (int32_t i = 0; i < tHead->tFuncSize; i++) {
        if (traceFunction(&(tHead->tFunc[i]), fileName)) {
            printf("mytrace: unknown error\n");
            return EXIT_FAILURE;
        }
    }

    return EXIT_SUCCESS;
}

int32_t traceFunction(TraceFunc *tFunc, char *fileName) {
    if (tFunc == NULL || fileName == NULL) {
        printf("mytrace: unknown error\n");
        return EXIT_FAILURE;
    }

    FILE *file = NULL;

    if (openFile(&file, fileName, "r")) {
        return EXIT_FAILURE;
    }

    int32_t idx = addTraceFile(tFunc, fileName);

    if (idx == -1) {
        printf ("mytrace: unknown error\n");
        closeFile(file);
        return EXIT_FAILURE;
    }

    char buffer[F_SIZE] = {0};
    int32_t line = 0;
    int32_t flag = 0;

    while (fgets(buffer, F_SIZE, file) != NULL) {
        line++;

        char temp[F_SIZE] = {0};

        strncpy(temp, buffer, F_SIZE);

        if (removeComment(temp, &flag) == -1) {
            printf("mytrace: unknown error\n");
            closeFile(file);
            return EXIT_FAILURE;
        }

        if (!hasTraceFunctionCode(temp, tFunc->name, flag)) {
            continue;
        }

        if (addTraceCode(&(tFunc->tFile[idx]), buffer, line) == -1) {
            printf("mytrace: unknown error\n");
            closeFile(file);
            return EXIT_FAILURE;
        }
    }

    closeFile(file);

    return EXIT_SUCCESS;
}

int32_t processHeader(TraceHead *tHead, char *fileName) {
    if (tHead == NULL || fileName == NULL) {
        return 1;
    }

    // Chcek if the file is header file

    if (fileName[strlen(fileName) - 2] != '.' || fileName[strlen(fileName) - 1] != 'h') {
        return 1;
    }

    FILE *file = NULL;

    if (openFile(&file, fileName, "r")) {
        return 1;
    }

    char buffer[F_SIZE] = {0};
    int32_t line = 0;
    int32_t flag = 0;

    while (fgets(buffer, F_SIZE, file) != NULL) {
        line++;

        char temp[F_SIZE] = {0};

        strncpy(temp, buffer, F_SIZE);

        if (removeComment(temp, &flag) == -1) {
            printf("mytrace: unknown error\n");
            closeFile(file);
            return EXIT_FAILURE;
        }

        char funcName[F_SIZE] = {0};

        if (!findFunction(temp, funcName, flag)) {
            continue;
        }

        if (addTraceFunc(tHead, funcName) == -1) {
            printf("mytrace: unknown error\n");
            closeFile(file);
            return EXIT_FAILURE;
        }
    }

    closeFile(file);

    return 0;
}

int32_t removeComment(char *code, int32_t *flag) {
    if (code == NULL || flag == NULL) {
        return 1;
    }

    while (*code != '\0') {
        if (*code == '\n') {
            *flag = (*flag == 2) ? 2 : 0;
            break;
        }

        if (*code == '/' && *(code + 1) == '/') {
            *flag = 1;
        }

        if (*code == '/' && *(code + 1) == '*') {
            *flag = 2;
        }

        if (*code == '*' && *(code + 1) == '/') {
            *flag = 0;
        }

        if (*flag) {
            *code = ' ';
        }

        code++;
    }

    return 0;
}

int32_t findFunction(char *code, char *funcName, int32_t flag) {
    if (code == NULL || funcName == NULL || flag) {
        return 0;
    }

    if (code[0] == '#' || strlen(code) < 2 || strstr(code, "typedef") != NULL) {
        return 0;
    }

    char *tail = strchr(code, '(');
    char *head = NULL;
    char *accept = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_";

    if (tail == NULL) {
        return 0;
    }

    while (strspn(tail, accept) == 0) {
        tail--;
    }

    head = tail;

    while (strspn(head, accept) != 0) {
        head--;
    }

    strncpy(funcName, head + 1, tail - head);

    return 1;
}

int32_t hasTraceFunctionCode(char *code, char *funcName, int32_t flag) {
    if (code == NULL || funcName == NULL || flag) {
        return 0;
    }

    char *temp   = strstr(code, funcName);
    char *accept = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_";

    if (temp == NULL) {
        return 0;
    }

    // Check if the function name is in the middle of the word

    if (strspn(temp - 1, accept) != 0 || strspn(temp + strlen(funcName), accept) != 0) {
        return 0;
    }

    return 1;
}

int32_t addTraceFunc(TraceHead *tHead, char *funcName) {
    if (tHead == NULL) {
        return -1;
    }

    int32_t idx = tHead->tFuncSize;
    tHead->tFuncSize++;

    if (idx == 0) {
        tHead->tFunc = (TraceFunc *) calloc(1, sizeof(TraceFunc));
    }
    else {
        tHead->tFunc = (TraceFunc *) reallocarray(tHead->tFunc, tHead->tFuncSize, sizeof(TraceFunc));
    }

    strncpy(tHead->tFunc[idx].name, funcName, F_SIZE);

    tHead->tFunc[idx].tFile = NULL;
    tHead->tFunc[idx].tFileSize = 0;

    return idx;
}

int32_t addTraceFile(TraceFunc *tFunc, char *fileName) {
    if (tFunc == NULL) {
        return -1;
    }

    int32_t idx = tFunc->tFileSize;
    tFunc->tFileSize++;

    if (idx == 0) {
        tFunc->tFile = (TraceFile *) calloc(1, sizeof(TraceFile));
    }
    else {
        tFunc->tFile = (TraceFile *) reallocarray(tFunc->tFile, tFunc->tFileSize, sizeof(TraceFile));
    }

    strncpy(tFunc->tFile[idx].name, fileName, F_SIZE);

    tFunc->tFile[idx].tCode = NULL;
    tFunc->tFile[idx].tCodeSize = 0;

    return idx;
}

int32_t addTraceCode(TraceFile *tFile, char *code, int32_t line) {
    if (tFile == NULL || code == NULL) {
        return -1;
    }

    int32_t idx = tFile->tCodeSize;
    tFile->tCodeSize++;

    if (idx == 0) {
        tFile->tCode = (TraceCode *) calloc(1, sizeof(TraceCode));
    }
    else {
        tFile->tCode = (TraceCode *) reallocarray(tFile->tCode, tFile->tCodeSize, sizeof(TraceCode));
    }

    // strncpy(tFile->tCode[idx].code, code, F_SIZE);

    // Remove leading and trailing spaces

    char *start = code;
    char *end   = code + strlen(code) - 1;

    while (*start == ' ') {
        start++;
    }

    while (*end == ' ') {
        end--;
    }

    // Remove trailing newline

    if (*end == '\n') {
        end--;
    }

    strncpy(tFile->tCode[idx].code, start, end - start + 1);

    tFile->tCode[idx].line = line;

    return idx;
}

void printTraceHeader(TraceHead *tHead, uint8_t lineFlag, uint8_t codeFlag) {
    if (tHead == NULL) {
        return;
    }

    for (int32_t i = 0; i < tHead->tFuncSize; i++) {
        printTraceFunction(&(tHead->tFunc[i]), lineFlag, codeFlag);
    }
}

void printTraceFunction(TraceFunc *tFunc, uint8_t lineFlag, uint8_t codeFlag) {
    if (tFunc->tFile == NULL) {
        return;
    }

    printf("%s:\n", tFunc->name);

    for (int32_t i = 0; i < tFunc->tFileSize; i++) {
        TraceFile *tf = &(tFunc->tFile[i]);

        printf("  %s (count: %d)\n", tf->name, tf->tCodeSize);

        if (!lineFlag && !codeFlag) {
            continue;
        }

        for (int32_t j = 0; j < tf->tCodeSize; j++) {
            TraceCode *tc = &(tf->tCode[j]);

            printf("    ");

            if (lineFlag) {
                printf("line %d", tc->line);
            }

            if (lineFlag && codeFlag) {
                printf(": ");
            }

            if (codeFlag) {
                printf("%s", tc->code);
            }

            printf("\n");
        }
    }
}

void freeTraceHead(TraceHead *tHead) {
    if (tHead == NULL) {
        return;
    }

    for (int32_t i = 0; i < tHead->tFuncSize; i++) {
        TraceFunc *tmpFunc = &(tHead->tFunc[i]);

        if (tmpFunc->tFile == NULL) {
            continue;
        }

        for (int32_t j = 0; j < tmpFunc->tFileSize; j++) {
            if (tmpFunc->tFile[j].tCode) {
                free(tmpFunc->tFile[j].tCode);
            }
        }

        free(tmpFunc->tFile);
    }

    free(tHead->tFunc);
}
