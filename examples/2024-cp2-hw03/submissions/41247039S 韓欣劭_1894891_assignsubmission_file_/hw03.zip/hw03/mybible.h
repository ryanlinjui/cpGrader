#pragma once

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#define SIZE 4096

typedef struct _BibleText {
    int32_t chapter;
    int32_t verse;
    char text[SIZE];
    char id[10];
} BibleText;

typedef struct _Bible {
    BibleText *text;
    int32_t size;
} Bible;

/**
 * Search the given keyword from file.
 * @param file the file stream.
 * @param serach the keyword.
 * @return 0 if success, otherwise non-zero
 */
int32_t searchText(FILE *file, char *search);

/**
 * Read the text from Bible, saved in bible.txt.
 * @param file the file stream.
 * @param text the Bible text struct.
 * @return 0 if success, otherwise non-zero
 */
int32_t readBibleText(FILE *file, BibleText *text);

/**
 * Add the text from Bible to Bible text.
 * @param bible the Bible struct.
 * @param text the Bible text struct.
 * @return 0 if success, otherwise non-zero
 */
int32_t addBibleText(Bible *bible, BibleText *text);

/**
 * Check if the given text has search text.
 * @param text the given text.
 * @param search the search text.
 * @return true if text includes search text, false otherwise.
 */
bool hasSearchText(char *text, char *search);

/**
 * Check if the characters are the same character. Same alphabet but different case are considered as same.
 * @param a character a.
 * @param b character b.
 * @return true if same character, false otherwise.
 */
bool isSameChar(char a, char b);

/**
 * Print the Bible text.
 * @param bible the bible struct.
 */
void printBibleText(Bible *bible);

/**
 * Free the Bible struct.
 * @param bible the bible struct.
 */
void freeBible(Bible *bible);
