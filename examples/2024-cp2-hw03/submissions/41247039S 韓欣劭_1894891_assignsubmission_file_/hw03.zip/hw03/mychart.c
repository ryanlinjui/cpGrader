#include "mychart.h"

int32_t generateRgbChart(RgbData *data) {
    BMP srcBMP = {NULL, NULL};
    BMP dstBMP = {NULL, NULL};

    if (initBMP(&srcBMP, data->srcFile) || createEmptyBMP(&dstBMP, data->width, data->height)) {
        freeBMP(&srcBMP);
        freeBMP(&dstBMP);
        return 1;
    }

    int32_t ret = 0;

    RgbFreq freq = { {0}, {0}, {0}, 0 };

    ret = calculateRgbFreq(&srcBMP, &freq);
    ret = plotRgbChart(&dstBMP, &freq, data);

    ret = writeBMP(&dstBMP, data->dstFile);

    freeBMP(&srcBMP);
    freeBMP(&dstBMP);

    return ret;
}

int32_t calculateRgbFreq(BMP *bmp, RgbFreq *freq) {
    if (bmp == NULL || freq == NULL) {
        return 1;
    }

    int32_t width  = bmp->header->width;
    int32_t height = bmp->header->height;

    if (height < 0) {
        height = -height;
    }

    for (int32_t i = 0; i < height; i++) {
        for (int32_t j = 0; j < width; j++) {
            uint8_t rIdx = bmp->pixels[i][j].r;
            uint8_t gIdx = bmp->pixels[i][j].g;
            uint8_t bIdx = bmp->pixels[i][j].b;

            freq->r[rIdx]++;
            freq->g[gIdx]++;
            freq->b[bIdx]++;
        }
    }

    for (int32_t i = 0; i < 256; i++) {
        if (freq->maxFreq < freq->r[i]) {
            freq->maxFreq = freq->r[i];
        }

        if (freq->maxFreq < freq->g[i]) {
            freq->maxFreq = freq->g[i];
        }

        if (freq->maxFreq < freq->b[i]) {
            freq->maxFreq = freq->b[i];
        }
    }

    return 0;
}

int32_t plotRgbChart(BMP *bmp, RgbFreq *freq, RgbData *data) {
    if (bmp == NULL || freq == NULL) {
        return 1;
    }

    int32_t width  = bmp->header->width;
    int32_t height = bmp->header->height;

    if (height < 0) {
        height = -height;
    }

    int32_t r_x1 = 0, g_x1 = 0, b_x1 = 0, y1 = 0;
    int32_t r_x0 = 0, g_x0 = 0, b_x0 = 0, y0 = 0;

    for (int32_t i = 0; i < 256; i++) {
        y1   = (int32_t) ((double) i / 255 * (width - 1));
        r_x1 = (int32_t) ((double) freq->r[i] / freq->maxFreq * (height - 1));
        g_x1 = (int32_t) ((double) freq->g[i] / freq->maxFreq * (height - 1));
        b_x1 = (int32_t) ((double) freq->b[i] / freq->maxFreq * (height - 1));

        plotGradientDot(bmp->pixels, r_x1, y1, RED,   data);
        plotGradientDot(bmp->pixels, g_x1, y1, GREEN, data);
        plotGradientDot(bmp->pixels, b_x1, y1, BLUE,  data);

        if (i > 0) {
            for (int32_t y = y0; y < y1; y++) {
                int32_t xR = findYPos(y, y0, y1, r_x0, r_x1);
                int32_t xG = findYPos(y, y0, y1, g_x0, g_x1);
                int32_t xB = findYPos(y, y0, y1, b_x0, b_x1);

                plotGradientDot(bmp->pixels, xR, y, RED,   data);
                plotGradientDot(bmp->pixels, xG, y, GREEN, data);
                plotGradientDot(bmp->pixels, xB, y, BLUE,  data);
            }

            int32_t x0 = (r_x0 < r_x1) ? r_x0 : r_x1;
            int32_t x1 = (r_x0 > r_x1) ? r_x0 : r_x1;

            for (int32_t x = x0; x < x1; x++) {
                int32_t y = findYPos(x, r_x0, r_x1, y0, y1);

                plotGradientDot(bmp->pixels, x, y, RED, data);
            }

            x0 = (g_x0 < g_x1) ? g_x0 : g_x1;
            x1 = (g_x0 > g_x1) ? g_x0 : g_x1;

            for (int32_t x = x0; x < x1; x++) {
                int32_t y = findYPos(x, g_x0, g_x1, y0, y1);

                plotGradientDot(bmp->pixels, x, y, GREEN, data);
            }

            x0 = (b_x0 < b_x1) ? b_x0 : b_x1;
            x1 = (b_x0 > b_x1) ? b_x0 : b_x1;

            for (int32_t x = x0; x < x1; x++) {
                int32_t y = findYPos(x, b_x0, b_x1, y0, y1);

                plotGradientDot(bmp->pixels, x, y, BLUE, data);
            }
        }

        r_x0 = r_x1;
        g_x0 = g_x1;
        b_x0 = b_x1;
        y0   = y1;
    }

    return 0;
}

int32_t findYPos(int32_t x, int32_t x1, int32_t x2, int32_t y1, int32_t y2) {
    if (x1 == x2) {
        return (y2 - y1) / 2;
    }

    double grad   = (double) (y2 - y1) / (x2 - x1);
    double height = (double) y1 + grad * (x - x1);

    return (int32_t) height;
}

void plotGradientDot(BmpPixel **pixels, int32_t x, int32_t y, RgbColor color, RgbData *data) {
    if (pixels == NULL) {
        return;
    }

    int32_t r = data->radius;

    for (int32_t i = x - r + 1; i < x + r; i++) {
        if (i < 0 || i >= data->height) {
            continue;
        }

        for (int32_t j = y - r + 1; j < y + r; j++) {
            if (j < 0 || j >= data->width) {
                continue;
            }

            int64_t dstSquare = (i - x) * (i - x) + (j - y) * (j - y);
            int64_t radSquare = r * r;

            if (dstSquare > radSquare) {
                continue;
            }

            uint8_t intensity = (uint8_t) (255.0 * ((double) (r - sqrt(dstSquare)) / r));

            if (color == RED && pixels[i][j].r < intensity) {
                pixels[i][j].r = intensity;
            }
            else if (color == GREEN && pixels[i][j].g < intensity) {
                pixels[i][j].g = intensity;
            }
            else if (color == BLUE && pixels[i][j].b < intensity) {
                pixels[i][j].b = intensity;
            }
        }
    }
}
