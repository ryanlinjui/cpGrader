#include "mybmp.h"

int32_t initBMP(BMP *bmp, FILE *file) {
    if (initBMPHeader(bmp) != 0) {
        return 1;
    }

    if (parseBMPHeader(bmp, file) != 0) {
        freeBMP(bmp);
        return 1;
    }

    if (initBMPPixels(bmp) != 0) {
        freeBMP(bmp);
        return 1;
    }

    if (parseBMPPixels(bmp, file) != 0) {
        freeBMP(bmp);
        return 1;
    }

    return 0;
}

int32_t initBMPHeader(BMP *bmp) {
    bmp->header = (BmpHeader *) calloc(1, sizeof(BmpHeader));

    if (bmp->header == NULL) {
        printf("mybmp: initBMPHeader error");
        return 1;
    }

    return 0;
}

int32_t initBMPPixels(BMP *bmp) {
    int32_t height = bmp->header->height;
    int32_t width  = bmp->header->width;

    if (height < 0) {
        height = -height;
    }

    bmp->pixels = (BmpPixel **) calloc(height, sizeof(BmpPixel *));

    if (bmp->pixels == NULL) {
        printf("mybmp: initBMPPixels height error");
        return 1;
    }

    for (int32_t i = 0; i < height; i++) {
        bmp->pixels[i] = (BmpPixel *) calloc(width, sizeof(BmpPixel));

        if (bmp->pixels[i] == NULL) {
            printf("mybmp: initBMPPixels width error");
            return 1;
        }
    }

    return 0;
}

int32_t createEmptyBMP(BMP *bmp, int32_t width, int32_t height) {
    if (initBMPHeader(bmp) != 0) {
        return 1;
    }

    bmp->header->bm[0]       = 'B';
    bmp->header->bm[1]       = 'M';
    bmp->header->size        = 54 + width * height * 3;
    bmp->header->reserve     = 0;
    bmp->header->offset      = 54;
    bmp->header->header_size = 40;
    bmp->header->width       = width;
    bmp->header->height      = height;
    bmp->header->planes      = 1;
    bmp->header->bpp         = 24;
    bmp->header->compression = 0;
    bmp->header->bitmap_size = width * height * 3;
    bmp->header->hres        = 0;
    bmp->header->vres        = 0;
    bmp->header->used        = 0;
    bmp->header->important   = 0;

    if (initBMPPixels(bmp) != 0) {
        return 1;
    }

    return 0;
}

int32_t parseBMPHeader(BMP *bmp, FILE *file) {
    if (fread(bmp->header, sizeof(BmpHeader), 1, file) != 1) {
        printf("mybmp: parseBMPHeader error");
        return 1;
    }

    // Check if the file is a BMP file

    if (bmp->header->bm[0] != 'B' || bmp->header->bm[1] != 'M') {
        printf("mybmp: parseBMPHeader file error");
        return 1;
    }

    return 0;
}

int32_t parseBMPPixels(BMP *bmp, FILE *file) {
    int32_t width  = bmp->header->width;
    int32_t height = bmp->header->height;

    if (height < 0) {
        height = -height;
    }

    int32_t padding = (4 - (width * 3) % 4) % 4;

    for (int32_t i = 0; i < height; i++) {
        size_t read = fread(bmp->pixels[i], sizeof(BmpPixel), width, file);

        if (read != (size_t) width) {
            printf("mybmp: parseBMPPixels width error");
            return 1;
        }

        if (padding > 0) {
            fseek(file, padding, SEEK_CUR);
        }
    }

    return 0;
}

int32_t writeBMP(BMP *bmp, FILE *file) {
    // Write BMP header

    if (fwrite(bmp->header, sizeof(BmpHeader), 1, file) != 1) {
        printf("mybmp: writeBMP error");
        return 1;
    }

    // Write BMP pixels

    int32_t width  = bmp->header->width;
    int32_t height = bmp->header->height;

    if (height < 0) {
        height = -height;
    }

    int32_t padding = (4 - (width * 3) % 4) % 4;

    // printf("padding: %d\n", padding);

    for (int32_t i = 0; i < height; i++) {
        if (fwrite(bmp->pixels[i], sizeof(BmpPixel), width, file) != (size_t) width) {
            printf("mybmp: writeBMP error");
            return 1;
        }

        uint8_t zero = 0;

        for (int32_t j = 0; j < padding; j++) {
            if (fwrite(&zero, sizeof(uint8_t), 1, file) != 1) {
                printf("mybmp: writeBMP error");
                return 1;
            }
        }
    }

    return 0;
}

int32_t freeBMP(BMP *bmp) {
    if (bmp == NULL || bmp->header == NULL) {
        return 0;
    }

    int32_t height = bmp->header->height;

    freeBMPHeader(bmp->header);
    freeBMPPixels(bmp->pixels, height);

    return 0;
}

void freeBMPHeader(BmpHeader *header) {
    if (header == NULL) {
        return;
    }

    free(header);
}

void freeBMPPixels(BmpPixel **pixels, int32_t height) {
    if (pixels == NULL) {
        return;
    }

    if (height < 0) {
        height = -height;
    }

    for (int32_t i = 0; i < height; i++) {
        free(pixels[i]);
    }

    free(pixels);
}
