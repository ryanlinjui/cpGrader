#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

int main(){
    FILE *bible = fopen("bible.txt", "r");
    char target[100] = {0};
    printf("Please enter the search target: ");
    scanf("%[^\n]", target);
    for (int32_t i = 0; i < strlen(target); i++){
        if (target[i] >= 65 && target[i] <= 90){
            target[i] += 32;
        }
    }
    char buffer[2000] = {0};
    char **text = calloc(35000, sizeof(char*));
    char **bookID = calloc(35000, sizeof(char*));
    char **chapter = calloc(35000, sizeof(char*));
    char **verse = calloc(35000, sizeof(char*));
    for (int i = 0; i < 35000; i++) {
        text[i] = calloc(2000, sizeof(char));
        bookID[i] = calloc(20, sizeof(char));
        chapter[i] = calloc(5, sizeof(char));
        verse[i] = calloc(5, sizeof(char));
    }

    int32_t count = 0;
    while(fgets(buffer, 2000, bible) != 0){
        char temp[2000] = {0};
        strcpy(temp, buffer);
        char *address = strstr(buffer, "text")+7;
        char *new = strstr(address, "\"");
        *new = '\0';
        char compare[2000] = {0};
        strcpy(compare, address);
        for (int32_t i = 0; i < strlen(compare); i++){
            if (compare[i] >= 65 && compare[i] <= 90){
                compare[i] += 32;
            }
        }
        if (strstr(compare, target) != NULL){
            char *first1 = strstr(temp, "book_id")+10;
            char *end1 = strstr(first1, "\"");
            *end1 = '\0';
            strcpy(bookID[count], first1);
            char *first2 = strstr(temp, "verse")+7;
            char *end2 = strstr(first2, ",");
            *end2 = '\0';
            strcpy(verse[count], first2);
            char *first3 = strstr(temp, "chapter")+9;
            char *end3 = strstr(first3, ",");
            *end3 = '\0';
            strcpy(chapter[count], first3);
            strcpy(text[count], address);
            count++;
        }
    }
    printf("Found %d time(s)\n", count);
    for (int32_t i = 0; i < count; i++){
        printf("%d. %s %s:%s %s\n", i+1, bookID[i], chapter[i], verse[i], text[i]);
    }
}