#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include "mybmp.h"

int main(int32_t argc, char *argv[]){
    int32_t INPUT = 0;
    int32_t OUTPUT = 0;
    int32_t WIDTH = 0;
    int32_t HEIGHT = 0;
    int32_t LINE = 0;
    for (int32_t i = 0; i < argc; i++){
        if (strcmp(argv[i], "-H") == 0 || strcmp(argv[i], "--help") == 0){
            printf("• -i, --input, mandatory: input file path\n");
            printf("• -o, --output, mandatory: output file path\n");
            printf("• -w, --width, mandatory: output bmp file widths\n");
            printf("• -h, --height, mandatory: output bmp file height\n");
            printf("• -l, --line, mandatory: the radius of line\n");
            printf("• -H, --help, option: show help message\n");
            return 0;
        }
        else if (strcmp(argv[i], "-i") == 0 || strstr(argv[i], "--input") != 0){
            INPUT = 1;
        }
        else if (strcmp(argv[i], "-o") == 0 || strstr(argv[i], "--output") != 0){
            OUTPUT = 1;
        }
        else if (strcmp(argv[i], "-w") == 0 || strstr(argv[i], "--width") != 0){
            WIDTH = 1;
        }
        else if (strcmp(argv[i], "-h") == 0 || strstr(argv[i], "--height") != 0){
            HEIGHT = 1;
        }
        else if (strcmp(argv[i], "-l") == 0 || strstr(argv[i], "--line") != 0){
            LINE = 1;
        }
    }
    if (INPUT == 0 || OUTPUT == 0 || WIDTH == 0 || HEIGHT == 0 || LINE == 0){
        printf("wrong input\n");
        return 0;
    }
    FILE *input = NULL;
    FILE *output = NULL;
    int32_t width = 0;
    int32_t height = 0;
    int32_t line = 0;
    for (int32_t i = 0; i < argc; i++){
        if (strcmp(argv[i], "-i") == 0 || strstr(argv[i], "--input") != 0){
            if (strcmp(argv[i], "-i") == 0){
                i++;
                input = fopen(argv[i], "rb");
                if (input == NULL){
                    printf("wrong input\n");
                    return 0;
                }
            }
            else if (strstr(argv[i], "--input") != 0){
                char *start = strstr(argv[i], "=")+1;
                input = fopen(start, "rb");
                if (input == NULL){
                    printf("wrong input\n");
                    return 0;
                }
            }
        }
        else if (strcmp(argv[i], "-o") == 0 || strstr(argv[i], "--output") != 0){
            if (strcmp(argv[i], "-o") == 0){
                i++;
                output = fopen(argv[i], "wb");
                if (output == NULL){
                    printf("wrong input\n");
                    return 0;
                }
            }
            else if (strstr(argv[i], "--output") != 0){
                char *start = strstr(argv[i], "=")+1;
                output = fopen(argv[i], "wb");
                if (output == NULL){
                    printf("wrong input\n");
                    return 0;
                }
            }
        }
        else if (strcmp(argv[i], "-w") == 0 || strstr(argv[i], "--width") != 0){
            if (strcmp(argv[i], "-w") == 0){
                i++;
                for (int32_t j = 0; j < strlen(argv[i]); j++){
                    width += (argv[i][j]-'0') * pow(10, (strlen(argv[i])-j-1));
                }
            }
            else if (strstr(argv[i], "--width") != 0){
                char *start = strstr(argv[i], "=")+1;
                int32_t START = start-argv[i];
                for (int32_t j = START; j < strlen(argv[i]); j++){
                    width += (argv[i][j]-'0') * pow(10, (strlen(argv[i])-j-1));
                }
            }
        }
        else if (strcmp(argv[i], "-h") == 0 || strstr(argv[i], "--height") != 0){
            if (strcmp(argv[i], "-h") == 0){
                i++;
                for (int32_t j = 0; j < strlen(argv[i]); j++){
                    height += (argv[i][j]-'0') * pow(10, (strlen(argv[i])-j-1));
                }
            }
            else if (strstr(argv[i], "--height") != 0){
                char *start = strstr(argv[i], "=")+1;
                int32_t START = start-argv[i];
                for (int32_t j = START; j < strlen(argv[i]); j++){
                    height += (argv[i][j]-'0') * pow(10, (strlen(argv[i])-j-1));
                }
            }
        }
        else if (strcmp(argv[i], "-l") == 0 || strstr(argv[i], "--line") != 0){
            if (strcmp(argv[i], "-l") == 0){
                i++;
                for (int32_t j = 0; j < strlen(argv[i]); j++){
                    line += (argv[i][j]-'0') * pow(10, (strlen(argv[i])-j-1));
                }
            }
            else if (strstr(argv[i], "--line") != 0){
                char *start = strstr(argv[i], "=")+1;
                int32_t START = start-argv[i];
                for (int32_t j = START; j < strlen(argv[i]); j++){
                    line += (argv[i][j]-'0') * pow(10, (strlen(argv[i])-j-1));
                }
            }
        }
    }
    BMPHeader myheader;
    read_header(input, &myheader);
    uint8_t **BGR = calloc(myheader.height * myheader.width * sizeof(uint8_t *), sizeof(uint8_t *));
    for (int32_t i = 0; i < myheader.height*myheader.width; i++){
        BGR[i] = calloc(3, sizeof(uint8_t));
    }
    read_array(input, BGR, &myheader);
    uint8_t *blue, *red, *green;
    blue = calloc(myheader.height*myheader.width, sizeof(uint8_t));
    red = calloc(myheader.height*myheader.width, sizeof(uint8_t));
    green = calloc(myheader.height*myheader.width, sizeof(uint8_t));
    for (int32_t i = 0; i < myheader.height*myheader.width; i++){
        blue[i] = BGR[i][0];
        green[i] = BGR[i][1];
        red[i] = BGR[i][2];
        // printf("%d %d %d\n", BGR[i][0], BGR[i][1], BGR[i][2]);
    }
    free(BGR);
    int32_t blue_number[255] = {0};
    int32_t green_number[255] = {0};
    int32_t red_number[255] = {0};
    for (int32_t i = 0; i < myheader.height*myheader.width; i++){
        blue_number[blue[i]]++;
        red_number[red[i]]++;
        green_number[green[i]]++;
    }
    int32_t blue_max = 0;
    int32_t red_max = 0;
    int32_t green_max = 0;
    for (int32_t i = 0; i < 255; i++){
        if (blue_number[i] > blue_max){
            blue_max = blue_number[i];
        }
        if (green_number[i] > green_max){
            green_max = green_number[i];
        }
        if (red_number[i] > red_max){
            red_max = red_number[i];
        }
    }
    int32_t max_number = 0;
    if (blue_max > max_number){
        max_number = blue_max;
    }
    if (green_max > max_number){
        max_number = green_max;
    }
    if (red_max > max_number){
        max_number = red_max;
    }
    BMPHeader NewHeader;
    read_header(input, &NewHeader);
    fclose(input);
    NewHeader.width = width;
    NewHeader.height = height;
    uint8_t **pixel = calloc(height*width*sizeof(uint8_t *), sizeof(uint8_t *));
    for (int32_t i = 0; i < height*width; i++){
        pixel[i] = calloc(3, sizeof(uint8_t));
    }
    int32_t blue_y[255] = {0};
    int32_t green_y[255] = {0};
    int32_t red_y[255] = {0};
    int32_t x_point[255] = {0};
    for (int32_t i = 0; i < 255; i++){
        int32_t x = i * ((double)width/(double)255);
        x_point[i] = x;
        blue_y[i] = blue_number[i] * ((double)(height-1)/(double)max_number);
        green_y[i] = green_number[i] * ((double)(height-1)/(double)max_number);
        red_y[i] = red_number[i] * ((double)(height-1)/(double)max_number);
        for (int32_t j = 0; j < line; j++){
            if (x+blue_y[i]*width+j*width < width*height && x+blue_y[i]*width+j*width >= 0){
                pixel[x+blue_y[i]*width+j*width][0] = 255;
            }
            for (int32_t k = 0; k < line; k++){
                if (x+blue_y[i]*width+j*width+k < width*height && x+blue_y[i]*width+j*width+k >= 0){
                    pixel[x+blue_y[i]*width+j*width+k][0] = 255;
                }
                if (x+blue_y[i]*width+j*width > k && x+blue_y[i]*width+j*width < width*height){
                    pixel[x+blue_y[i]*width+j*width-k][0] = 255;
                }
            }
            if (x+blue_y[i]*width > j*width){
                if (x+blue_y[i]*width-j*width < width*height && x+blue_y[i]*width-j*width >= 0){
                    pixel[x+blue_y[i]*width-j*width][0] = 255;
                }
                for (int32_t k = 0; k < line; k++){
                    if (x+blue_y[i]*width-j*width+k >= 0 && x+blue_y[i]*width-j*width+k < width*height){
                        pixel[x+blue_y[i]*width-j*width+k][0] = 255;
                    }
                    if (x+blue_y[i]*width-j*width > k){
                        pixel[x+blue_y[i]*width-j*width-k][0] = 255;
                    }
                }
            }
            for (int32_t k = 0; k < line; k++){
                if (x+blue_y[i]*width+k < width*height && x+blue_y[i]*width+k >= 0){
                    pixel[x+blue_y[i]*width+k][0] = 255;
                }
                if (x+blue_y[i]*width > k && x+blue_y[i]*width < width*height){
                    pixel[x+blue_y[i]*width-k][0] = 255;
                }
            }
        }
        for (int32_t j = 0; j < line; j++){
            if (x+green_y[i]*width+j*width < width*height && x+green_y[i]*width+j*width >= 0){
                pixel[x+green_y[i]*width+j*width][1] = 255;
            }
            for (int32_t k = 0; k < line; k++){
                if (x+green_y[i]*width+j*width+k < width*height && x+green_y[i]*width+j*width+k >= 0){
                    pixel[x+green_y[i]*width+j*width+k][1] = 255;
                }
                if (x+green_y[i]*width+j*width > k && x+green_y[i]*width+j*width < width*height){
                    pixel[x+green_y[i]*width+j*width-k][1] = 255;
                }
            }
            if (x+green_y[i]*width > j*width){
                if (x+green_y[i]*width-j*width < width*height && x+green_y[i]*width-j*width >= 0){
                    pixel[x+green_y[i]*width-j*width][1] = 255;
                }
                for (int32_t k = 0; k < line; k++){
                    if (x+green_y[i]*width-j*width+k >= 0 && x+green_y[i]*width-j*width+k < width*height){
                        pixel[x+green_y[i]*width-j*width+k][1] = 255;
                    }
                    if (x+green_y[i]*width-j*width > k && x+green_y[i]*width-j*width < width*height){
                        pixel[x+green_y[i]*width-j*width-k][1] = 255;
                    }
                }
            }
            for (int32_t k = 0; k < line; k++){
                if (x+green_y[i]*width+k < width*height && x+green_y[i]*width+k >= 0){
                    pixel[x+green_y[i]*width+k][1] = 255;
                }
                if (x+green_y[i]*width > k && x+green_y[i]*width < width*height){
                    pixel[x+green_y[i]*width-k][1] = 255;
                }
            }
        }
        for (int32_t j = 0; j < line; j++){
            if (x+red_y[i]*width+j*width < width*height && x+red_y[i]*width+j*width >= 0){
                pixel[x+red_y[i]*width+j*width][2] = 255;
            }
            for (int32_t k = 0; k < line; k++){
                if (x+red_y[i]*width+j*width+k < width*height && x+red_y[i]*width+j*width+k >= 0){
                    pixel[x+red_y[i]*width+j*width+k][2] = 255;
                }
                if (x+red_y[i]*width+j*width-k >= 0 && x+red_y[i]*width+j*width-k < width*height){
                    pixel[x+red_y[i]*width+j*width-k][2] = 255;
                }
            }
            if (x+red_y[i]*width > j*width){
                if (x+red_y[i]*width-j*width < width*height && x+red_y[i]*width-j*width >= 0){
                    pixel[x+red_y[i]*width-j*width][2] = 255;
                }
                for (int32_t k = 0; k < line; k++){
                    if (x+red_y[i]*width-j*width+k < width*height && x+red_y[i]*width-j*width+k >= 0){
                        pixel[x+red_y[i]*width-j*width+k][2] = 255;
                    }
                    if (x+red_y[i]*width-j*width-k >= 0 && x+red_y[i]*width-j*width-k < width*height){
                        pixel[x+red_y[i]*width-j*width-k][2] = 255;
                    }
                }
            }
            for (int32_t k = 0; k < line; k++){
                if (x+red_y[i]*width+k < width*height && x+red_y[i]*width+k >= 0){
                    pixel[x+red_y[i]*width+k][2] = 255;
                }
                if (x+red_y[i]*width > k && x+red_y[i]*width < width*height){
                    pixel[x+red_y[i]*width-k][2] = 255;
                }
            }
        }
    }
    
    int32_t index = 1;
    for (int32_t i = 0; i < width; i++){
        if (index == 255){
            break;
        }
        if (i == x_point[index]){
            index++;
            continue;
        }
        int32_t dx = x_point[index] - x_point[index-1];
        int32_t dy = blue_y[index] - blue_y[index-1];
        int32_t y = blue_y[index-1]+dy*((double)(i-x_point[index-1])/(double)dx);
        for (int32_t j = 0; j < line; j++){
            if (i+y*width+j*width >= 0 && i+y*width+j*width < width*height){
                pixel[i+y*width+j*width][0] = 255;
            }
            for (int32_t k = 0; k < line; k++){
                if (i+y*width+j*width+k >= 0 && i+y*width+j*width+k < width*height){
                    pixel[i+y*width+j*width+k][0] = 255;
                }
                if (i+y*width+j*width > k && i+y*width+j*width-k < width*height){
                    pixel[i+y*width+j*width-k][0] = 255;
                }
            }
            if (i+y*width > j*width){
                if (i+y*width-j*width >= 0 && i+y*width-j*width < width*height){
                    pixel[i+y*width-j*width][0] = 255;
                }
                for (int32_t k = 0; k < line; k++){
                    if (i+y*width-j*width+k >= 0 && i+y*width-j*width+k < width*height){
                        pixel[i+y*width-j*width+k][0] = 255;
                    }
                    if (i+y*width-j*width > k && i+y*width-j*width-k < width*height){
                        pixel[i+y*width-j*width-k][0] = 255;
                    }
                }
            }
            for (int32_t k = 0; k < line; k++){
                if (i+y*width+k >= 0 && i+y*width+k < height*width){
                    pixel[i+y*width+k][0] = 255;
                }
                if (i+y*width > k && i+y*width-k < width*height){
                    pixel[i+y*width-k][0] = 255;
                }
            }
        }
        dy = green_y[index] - green_y[index-1];
        y = green_y[index-1]+dy*((double)(i-x_point[index-1])/(double)dx);
        for (int32_t j = 0; j < line; j++){
            if (i+y*width+j*width >= 0 && i+y*width+j*width < width*height){
                pixel[i+y*width+j*width][1] = 255;
            }
            for (int32_t k = 0; k < line; k++){
                if (i+y*width+j*width+k >= 0 && i+y*width+j*width+k < width*height){
                    pixel[i+y*width+j*width+k][1] = 255;
                }
                if (i+y*width+j*width > k && i+y*width+j*width-k < width*height){
                    pixel[i+y*width+j*width-k][1] = 255;
                }
            }
            if (i+y*width > j*width){
                if (i+y*width-j*width >= 0 && i+y*width-j*width < width*height){
                    pixel[i+y*width-j*width][1] = 255;
                }
                for (int32_t k = 0; k < line; k++){
                    if (i+y*width-j*width+k >= 0 && i+y*width-j*width+k < width*height){
                        pixel[i+y*width-j*width+k][1] = 255;
                    }
                    if (i+y*width-j*width > k && i+y*width-j*width-k < width*height){
                        pixel[i+y*width-j*width-k][1] = 255;
                    }
                }
            }
            for (int32_t k = 0; k < line; k++){
                if (i+y*width+k >= 0 && i+y*width+k < height*width){
                    pixel[i+y*width+k][1] = 255;
                }
                if (i+y*width > k && i+y*width-k < width*height){
                    pixel[i+y*width-k][1] = 255;
                }
            }
        }
        dy = red_y[index] - red_y[index-1];
        y = red_y[index-1]+dy*((double)(i-x_point[index-1])/(double)dx);
        for (int32_t j = 0; j < line; j++){
            if (i+y*width+j*width >= 0 && i+y*width+j*width < width*height){
                pixel[i+y*width+j*width][2] = 255;
            }
            for (int32_t k = 0; k < line; k++){
                if (i+y*width+j*width+k >= 0 && i+y*width+j*width+k < width*height){
                    pixel[i+y*width+j*width+k][2] = 255;
                }
                if (i+y*width+j*width > k && i+y*width+j*width-k < width*height){
                    pixel[i+y*width+j*width-k][2] = 255;
                }
            }
            if (i+y*width > j*width){
                if (i+y*width-j*width >= 0 && i+y*width-j*width < width*height){
                    pixel[i+y*width-j*width][2] = 255;
                }
                for (int32_t k = 0; k < line; k++){
                    if (i+y*width-j*width+k >= 0 && i+y*width-j*width+k < width*height){
                        pixel[i+y*width-j*width+k][2] = 255;
                    }
                    if (i+y*width-j*width > k && i+y*width-j*width-k < width*height){
                        pixel[i+y*width-j*width-k][2] = 255;
                    }
                }
            }
            for (int32_t k = 0; k < line; k++){
                if (i+y*width+k >= 0 && i+y*width+k < height*width){
                    pixel[i+y*width+k][2] = 255;
                }
                if (i+y*width > k && i+y*width-k < width*height){
                    pixel[i+y*width-k][2] = 255;
                }
            }
        }
        // printf("%d %d %d\n", dy, i, y);
    }
    write_array(pixel, &NewHeader, output);
    // line r = 3 -> 有5個pixel 要填色
}