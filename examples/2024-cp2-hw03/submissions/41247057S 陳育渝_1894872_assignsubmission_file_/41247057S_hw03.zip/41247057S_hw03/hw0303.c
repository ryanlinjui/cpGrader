#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "mybmp.h"

int main(int32_t argc, char *argv[]){
    int32_t write = 0;
    int32_t extract = 0;
    int32_t bits = 1;
    int32_t start_index = 0;
    for (int32_t i = 1; i < argc; i++){
        if (strcmp(argv[i], "-w") == 0 || strcmp(argv[i], "--write") == 0){
            if (extract > 0){
                printf("wrong input\n");
                return 0;
            }
            write = 1;
        }
        else if (strcmp(argv[i], "-e") == 0 || strcmp(argv[i], "--extract") == 0){
            if (write > 0){
                printf("wrong input\n");
                return 0;
            }
            extract = 1;
        }
        else if (strcmp(argv[i], "-b") == 0 || strstr(argv[i], "--bits") != 0){
            if (strstr(argv[i], "--bits") != 0){
                char *start = strstr(argv[i], "=")+1;
                bits = *start-48;
            }
            else if (strcmp(argv[i], "-b") == 0){
                i++;
                bits = argv[i][0]-48;
            }
            // printf("%d\n", bits);
            if (bits < 1 || bits > 8){
                printf("wrong input\n");
                return 0;
            }
        }
        else if (strstr(argv[i], "-") != 0){
            printf("wrong input\n");
            return 0;
        }
        else{
            start_index = i;
            break;
        }
    }
    if ((write == 0 && extract == 0)){
        printf("wrong input\n");
        return 0;
    }
    if (start_index == argc-1){
        printf("wrong input\n");
        return 0;
    }
    char *buffer;
    buffer = calloc(100, sizeof(char));
    strcpy(buffer, argv[start_index]);
    FILE *bmp = fopen(buffer, "rb+wb");
    if (bmp == NULL){
        printf("wrong input\n");
        return 0;
    }
    free(buffer);
    fseek(bmp, 0, SEEK_END);
    int32_t bmp_size = ftell(bmp);
    fseek(bmp, 0, SEEK_SET);
    BMPHeader myheader;
    if (write == 1){
        buffer = calloc(100, sizeof(char));
        strcpy(buffer, argv[start_index+1]);
        if (strcmp(buffer, argv[start_index]) == 0){
            printf("wrong input\n");
            return 0;
        }
        FILE *secret = fopen(buffer, "rb");
        if (secret == NULL){
            printf("wrong input\n");
            return 0;
        }
        fseek(secret, 0, SEEK_END);
        int32_t secret_size = ftell(secret);
        fseek(secret, 0, SEEK_SET);
        if (bmp_size < secret_size){
            printf("wrong input\n");
            return 0;
        }
        free(buffer);
        read_header(bmp, &myheader);
        uint8_t **BGR = calloc(myheader.height * myheader.width * sizeof(uint8_t *), sizeof(uint8_t *));
        for (int32_t i = 0; i < myheader.height*myheader.width; i++){
            BGR[i] = calloc(3, sizeof(uint8_t));
        }
        read_array(bmp, BGR, &myheader);
        int32_t bits_index = bits;
        uint8_t secret_data = 0;
        uint8_t number = 0;
        int32_t bmp_index = 0;
        int32_t pixel_index = 0;
        uint8_t mask = 0;
        for (int32_t i = 7; i >= bits; i--){
            mask += pow(2, i);
        }
        while(fread(&secret_data, sizeof(uint8_t), 1, secret) != 0){
            if (BGR[bmp_index] == NULL){
                printf("wrong input\n");
                return 0;
            }
            for (int32_t i = 0; i < 8; i++){
                if (bits_index > 0){
                    number += ((secret_data>>(7-i)) & 1) * pow(2, bits_index-1);
                    bits_index--;
                }
                if (pixel_index == 3){
                    bmp_index++;
                    pixel_index = 0;
                }
                if (bits_index == 0){
                    // printf("%d %d\n", bmp_index, pixel_index);
                    // printf("old = %u\n", BGR[bmp_index][pixel_index]);
                    BGR[bmp_index][pixel_index] &= mask;
                    BGR[bmp_index][pixel_index] |= number;
                    // printf("new = %u\n", BGR[bmp_index][pixel_index]);
                    number = 0;
                    bits_index = bits;
                    pixel_index++;
                }
            }
        }
        fseek(bmp, 0, SEEK_SET);
        write_array(BGR, &myheader, bmp);
        free(BGR);
    }
    else if (extract == 1){
        buffer = calloc(100, sizeof(char));
        strcpy(buffer, argv[start_index+1]);
        if (strcmp(buffer, argv[start_index]) == 0){
            printf("wrong input\n");
            return 0;
        }
        FILE *secret = fopen(buffer, "wb");
        if (secret == NULL){
            printf("wrong input\n");
            return 0;
        }
        free(buffer);
        read_header(bmp, &myheader);
        uint8_t **BGR = calloc(myheader.height * myheader.width * sizeof(uint8_t *), sizeof(uint8_t *));
        for (int32_t i = 0; i < myheader.height*myheader.width; i++){
            BGR[i] = calloc(3, sizeof(uint8_t));
        }
        read_array(bmp, BGR, &myheader);
        uint8_t mask = 0;
        for (int32_t i = bits-1; i >= 0; i--){
            mask += pow(2, i);
        }
        if (bits == 8){
            uint8_t new = 0;
            for (int32_t i = 0; i < myheader.height*myheader.width; i++){
                for (int32_t j = 0; j < 3; j++){
                    new = BGR[i][j] & mask;
                    fwrite(&new, sizeof(uint8_t), 1, secret);
                }
            }
        }
        else if (bits == 4){
            uint8_t new[2] = {0};
            int32_t BitIndex = 0;
            for (int32_t i = 0; i < myheader.height*myheader.width; i++){
                for (int32_t j = 0; j < 3; j++){
                    new[BitIndex] = BGR[i][j] & mask;
                    BitIndex++;
                    if (BitIndex == 2){
                        uint8_t number = (new[0]<<4) | new[1];
                        fwrite(&number, sizeof(uint8_t), 1, secret);
                        BitIndex = 0;
                    }
                }
            }
        }
        else if (bits == 2){
            uint8_t new[4] = {0};
            int32_t BitIndex = 0;
            for (int32_t i = 0; i < myheader.height*myheader.width; i++){
                for (int32_t j = 0; j < 3; j++){
                    new[BitIndex] = BGR[i][j] & mask;
                    BitIndex++;
                    if (BitIndex == 4){
                        uint8_t number = (new[0]<<6) | (new[1]<<4) | (new[2]<<2) | new[3];
                        fwrite(&number, sizeof(uint8_t), 1, secret);
                        BitIndex = 0;
                    }
                }
            }
        }
        else if (bits == 1){
            uint8_t new[8] = {0};
            int32_t BitIndex = 0;
            for (int32_t i = 0; i < myheader.height*myheader.width; i++){
                for (int32_t j = 0; j < 3; j++){
                    new[BitIndex] = BGR[i][j] & mask;
                    BitIndex++;
                    if (BitIndex == 8){
                        uint8_t number = (new[0]<<7) | (new[1]<<6) | (new[2]<<5) | (new[3]<<4) | (new[4]<<3) | (new[5]<<2) | (new[6]<<1) | new[7];
                        fwrite(&number, sizeof(uint8_t), 1, secret);
                        BitIndex = 0;
                    }
                }
            }
        }
        else if (bits == 3 || bits == 5 || bits == 6 || bits == 7){
            int32_t bit_index = 0;
            uint8_t number = 0;
            for (int32_t i = 0; i < myheader.height*myheader.width; i++){
                for (int32_t j = 0; j < 3; j++){
                    uint8_t temp = BGR[i][j] & mask;
                    bit_index += bits;
                    if (bit_index > 8){
                        uint8_t bit_temp = 0;
                        bit_temp = (temp>>(bit_index-8)) & 0xFF;
                        number |= bit_temp;
                        fwrite(&number, sizeof(uint8_t), 1, secret);
                        number = 0;
                        bit_temp = (temp<<(16-bit_index)) & 0xFF;
                        number |= bit_temp;
                        bit_index -= 8;
                    }
                    else if (bit_index == 8){
                        number |= temp;
                        fwrite(&number, sizeof(uint8_t), 1, secret);
                        number = 0;
                        bit_index = 0;
                    }
                    else{
                        number |= (temp << (8-bit_index));
                    }
                }
            }
        }
        free(BGR);
    }
}
