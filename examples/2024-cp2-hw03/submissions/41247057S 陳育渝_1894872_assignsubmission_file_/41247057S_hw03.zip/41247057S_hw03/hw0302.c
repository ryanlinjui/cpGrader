#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int32_t argc, char *argv[]){
    for (int32_t i = 0; i < argc; i++){
        if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0){
            printf("Usage: hw0302 [options] ... [files] ...\n");
            printf("  -f, --function=func   Trace the func usage in [Files].\n");
            printf("  -i, --include=File    Trace all functions listed in the header file in [Files].\n");
            printf("  -l, --linum           Display the line number.\n");
            printf("  -c, --code            Display the code.\n");
            printf("  -h, --help            Display this information and exit.\n");
            printf("\n");
            printf("-f and -i are exclusive and must be at least one.\n");
            return 0;
        }
    }

    if (argc < 3){
        printf("wrong input\n");
        return 0;
    }
    if (strstr(argv[1], "--include") != 0 || strcmp(argv[1], "-i") == 0){
        int32_t index = 0;
        FILE *header_file = NULL;
        if (strstr(argv[1], "--include") != 0){
            char *start = strstr(argv[1], "=")+1;
            header_file = fopen(start, "r");
            if (header_file == NULL){
                printf("wrong input\n");
                return 0;
            }
            index = 2;
        }
        else if (strcmp(argv[1], "-i") == 0){
            header_file = fopen(argv[2], "r");
            if (header_file == NULL){
                printf("wrong input\n");
                return 0;
            }
            index = 3;
        }
        if (header_file != NULL){
            char temp[500] = {0};
            char func[500][500] = {0};
            int32_t number = 0;
            while (fgets(temp, 500, header_file) != NULL){
                if (strstr(temp, "#") != 0){
                    continue;
                }
                if (strstr(temp, " ") != 0){
                    char *end = strstr(strstr(temp, " "), "(");
                    if (end != NULL){
                        *end = '\0';
                    }
                    else{
                        continue;
                    }
                    if (*(strstr(temp, " ")+1) == '*'){
                        strcpy(func[number], strstr(temp, " ")+2);
                    }
                    else{
                        strcpy(func[number], strstr(temp, " ")+1);
                    }
                    number++;
                }
            }
            fclose(header_file);
            int32_t LINE = 0;
            int32_t CODE = 0;
            for (int32_t i = index; i < argc; i++){
                if (LINE > 0 && CODE > 0){
                    break;
                }
                if (strcmp(argv[i], "--linum") == 0 || strcmp(argv[i], "-l") == 0){
                    LINE++;
                }
                else if (strcmp(argv[i], "--code") == 0 || strcmp(argv[i], "-c") == 0){
                    CODE++;
                }
                else if (strcmp(argv[i], "-") == 0){
                    printf("wrong input\n");
                    return 0;
                }
            }
            if (argv[argc-1][0] == '-'){
                printf("wrong input\n");
                return 0;
            }
            for (int32_t i = 0; i < number; i++){
                printf("%s: \n", func[i]);
                for (int32_t k = index; k < argc; k++){
                    if (strstr(argv[k], "-") != 0){
                        continue;
                    }
                    FILE *file = fopen(argv[k], "r");
                    if (file == NULL){
                        printf("wrong input\n");
                        return 0;
                    }
                    char BUFFER[500] = {0};
                    int32_t COUNT_LINE = 0;
                    int32_t COUNT = 0;
                    char PRINT_CODE[3000][500] = {0};
                    int32_t PRINT_LINE[3000] = {0};
                    int32_t CANCEL = 0;
                    while(fgets(BUFFER, 500, file) != 0){
                        COUNT_LINE++;
                        if (strstr(BUFFER, "*/") != 0){
                            CANCEL = 0;
                            if (strstr(BUFFER, "*/") > strstr(BUFFER, func[i])){
                                continue;
                            }
                        }
                        if (CANCEL > 0){
                            continue;
                        }
                        if (strstr(BUFFER, "//") < strstr(BUFFER, func[i]) && strstr(BUFFER, "//") != NULL){
                            continue;
                        }
                        if (strstr(BUFFER, "/*") != 0){
                            CANCEL = 1;
                            if (strstr(BUFFER, "/*") < strstr(BUFFER, func[i])){
                                continue;
                            }
                        }
                        char *PTR = BUFFER;
                        while(strstr(PTR, func[i]) != NULL){
                            PTR = strstr(PTR, func[i])+strlen(func[i]);
                            if (LINE > 0){
                                PRINT_LINE[COUNT] = COUNT_LINE;
                            }
                            if (CODE > 0){
                                char *NEWSTRING = 0;
                                for (int32_t j = 0; j < strlen(BUFFER); j++){
                                    if (BUFFER[j] != ' '){
                                        NEWSTRING = BUFFER+j;
                                        break;
                                    }
                                }
                                strcpy(PRINT_CODE[COUNT], NEWSTRING);
                            }
                            COUNT++;
                        }
                    }
                    fclose(file);
                    printf("  %s (count: %d)\n", argv[k], COUNT);
                    for (int32_t j = 0; j < COUNT; j++){
                        if (LINE > 0 && CODE > 0){
                            printf("    line %d: %s", PRINT_LINE[j], PRINT_CODE[j]);
                        }
                        else if (LINE > 0 && CODE == 0){
                            printf("    line %d\n", PRINT_LINE[j]);
                        }
                        else if (LINE == 0 && CODE > 0){
                            printf("    %s", PRINT_CODE[j]);
                        }
                    }
                }
            }
        }
    }
    else if (strstr(argv[1], "--function") != 0 || strcmp(argv[1], "-f") == 0){
        char *function;
        int32_t index = 0;
        if (strstr(argv[1], "--function") != 0){
            char *start = strstr(argv[1], "=")+1;
            function = calloc(strlen(start), sizeof(char));
            strcpy(function, start);
            index = 2;
        }
        else if(strcmp(argv[1], "-f") == 0){
            function = calloc(strlen(argv[2]), sizeof(char));
            strcpy(function, argv[2]);
            index = 3;
        }
        if (function != NULL){
            int32_t line, code = 0;
            for (int32_t i = index; i < argc; i++){
                if (line > 0 && code > 0){
                    break;
                }
                if (strcmp(argv[i], "--linum") == 0 || strcmp(argv[i], "-l") == 0){
                    line++;
                }
                else if (strcmp(argv[i], "--code") == 0 || strcmp(argv[i], "-c") == 0){
                    code++;
                }
                else if (strcmp(argv[i], "-") == 0){
                    printf("wrong input\n");
                    return 0;
                }
            }
            if (argv[argc-1][0] == '-'){
                printf("wrong input\n");
                return 0;
            }
            printf("%s: \n", function);
            for (int32_t i = index; i < argc; i++){
                if (strstr(argv[i], "-") != 0){
                    continue;
                }
                FILE *file = fopen(argv[i], "r");
                if (file == NULL){
                    printf("wrong input\n");
                    return 0;
                }
                char buffer[500] = {0};
                int32_t count_line = 0;
                int32_t count = 0;
                char print_code[3000][500] = {0};
                int32_t print_line[3000] = {0};
                int32_t cancel = 0;
                while(fgets(buffer, 500, file) != 0){
                    count_line++;
                    if (strstr(buffer, "*/") != 0){
                        cancel = 0;
                        if (strstr(buffer, "*/") > strstr(buffer, function)){
                            continue;
                        }
                    }
                    if (cancel > 0){
                        continue;
                    }
                    if (strstr(buffer, "//") < strstr(buffer, function) && strstr(buffer, "//") != NULL){
                        continue;
                    }
                    if (strstr(buffer, "/*") != 0){
                        cancel = 1;
                        if (strstr(buffer, "/*") < strstr(buffer, function)){
                            continue;
                        }
                    }
                    char *ptr = buffer;
                    while(strstr(ptr, function) != NULL){
                        ptr = strstr(ptr, function)+strlen(function);
                        if (line > 0){
                            print_line[count] = count_line;
                        }
                        if (code > 0){
                            char *newstring = 0;
                            for (int32_t j = 0; j < strlen(buffer); j++){
                                if (buffer[j] != ' '){
                                    newstring = buffer+j;
                                    break;
                                }
                            }
                            strcpy(print_code[count], newstring);
                        }
                        count++;
                    }
                }
                fclose(file);
                printf("  %s (count: %d)\n", argv[i], count);
                for (int32_t j = 0; j < count; j++){
                    if (line > 0 && code > 0){
                        printf("    line %d: %s", print_line[j], print_code[j]);
                    }
                    else if (line > 0 && code == 0){
                        printf("    line %d\n", print_line[j]);
                    }
                    else if (line == 0 && code > 0){
                        printf("    %s", print_code[j]);
                    }
                }
            }
        }
    }
    else{
        printf("wrong input\n");
        return 0;
    }
}