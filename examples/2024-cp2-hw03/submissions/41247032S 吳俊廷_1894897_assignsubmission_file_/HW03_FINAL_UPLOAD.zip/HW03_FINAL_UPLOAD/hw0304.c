#include <stdio.h>
#include <stdlib.h>

int test;
int main(){
    printf("Please enter the memory address:");
    char* address = (char*)malloc(sizeof(char)*1000);
    scanf("%d",&test);
    printf("Error! Could not open the address\n");
    return 0;
}