#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

char* target;

void toLowerCase(char* str) {
    for(int i = 0; str[i]; i++){
        str[i] = tolower(str[i]);
    }
}

void searchInBible(char* target) {
    FILE* file = fopen("bible.txt", "r");
    char line[1000];
    int count = 0;

    // First pass: count the matches
    while(fgets(line, sizeof(line), file)) {
        char text[1000], book_id[10];
        int chapter, verse;
        sscanf(line, "{\"chapter\":%d,\"verse\":%d,\"text\":\"%[^\"]\",\"translation_id\":\"ASV\",\"book_id\":\"%[^\"]\",\"book_name\":\"Genesis\"}", &chapter, &verse, text, book_id);
        char* temp = strdup(text);
        toLowerCase(temp);
        if(strstr(temp, target) != NULL) {
            count++;
        }
        free(temp);
    }
    printf("Found %d item(s)\n", count);

    // Reset the file pointer to the beginning of the file
    rewind(file);

    // Second pass: print the matches
    count = 0;
    while(fgets(line, sizeof(line), file)) {
        char text[1000], book_id[10];
        int chapter, verse;
        sscanf(line, "{\"chapter\":%d,\"verse\":%d,\"text\":\"%[^\"]\",\"translation_id\":\"ASV\",\"book_id\":\"%[^\"]\",\"book_name\":\"Genesis\"}", &chapter, &verse, text, book_id);
        char* temp = strdup(text);
        toLowerCase(temp);
        if(strstr(temp, target) != NULL) {
            printf("%d. %s %d:%d %s\n", count+1, book_id, chapter, verse, text);
            count++;
        }
        free(temp);
    }

    fclose(file);
}

int main(){
    target = (char*)malloc(sizeof(char)*1000);
    printf("Please enter the search target: ");
    fgets(target, 1000, stdin);
    target[strcspn(target, "\n")] = 0; // remove newline character
    toLowerCase(target);
    searchInBible(target);
    free(target);
    return 0;
}