#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>

#define MAX_LINE_LENGTH 10000

void trace_function_usage(char* function_name, char* file_name, int display_linum, int display_code) {
    FILE* file = fopen(file_name, "r");
    if(file == NULL) {
        printf("Error: Cannot open file %s\n", file_name);
        return;
    }

    char line[MAX_LINE_LENGTH];

    int line_number = 0;
    int count = 0;

    while(fgets(line, sizeof(line), file)) {
        if(strstr(line, function_name) != NULL) {
            count++;
        }
    }

    printf("  %s (count: %d)\n", file_name, count);
    rewind(file);
    while(fgets(line, sizeof(line), file)) {
        line_number++;
        if(strstr(line, function_name) != NULL) {
            count++;
            if(display_code&&display_linum==0) {
                // 找到該行的第一個非空白字元
                char* start = line;
                while(*start == ' ' || *start == '\t') {
                    start++;
                }
                // 從第一個非空白字元開始輸出
                printf("    %s", start);
            }else if(display_code==0&&display_linum){
                printf("    line %d\n", line_number);
            }else if(display_code&&display_linum){
                printf("    line %d", line_number);
                // 找到該行的第一個非空白字元
                char* start = line;
                while(*start == ' ' || *start == '\t') {
                    start++;
                }
                // 從第一個非空白字元開始輸出
                printf("    %s", start);   
            }
        }
    }

    fclose(file);
}

void trace_function_in_header_usage(char* include_file_name, char** file_names, int num_files, int display_linum, int display_code){
    FILE *header_file, *source_file;
    char line[256];
    char function_name[256]; //-1表示沒找到
    function_name[0]='\0';

    // 打開標頭檔案並讀取函數名稱
    header_file = fopen(include_file_name, "r");
    if(header_file == NULL) {
        printf("Cannot open header file: %s\n", include_file_name);
        return;
    }

    while(fgets(line, sizeof(line), header_file)) {
        // 檢查該行是否可能包含函數定義
        if(strchr(line, '(') && strchr(line, ')')) {
            // 從該行讀取函數名稱
            char* start = line;
            while(*start == ' ' || *start == '\t') {
                start++;
            }
            char* end = strchr(start, '(');
            if(end) {
                strncpy(function_name, start, end - start);
                function_name[end - start] = '\0';
            }
        }
        if(function_name[0]!='\0'){
            //parse function_name
            char* real_function_name = malloc(strlen(function_name) + 1);
            strcpy(real_function_name, function_name);
            char* current = real_function_name;
            while (*current != '*' && *current != ' ') {
                current++;
            }
            while(current[0]=='*'||current[0]==' '){
                current++;
            }
            printf("%s\n",current);
            
            // Trace function usage in each file
            for(int i = 0; i < num_files; i++) {
                trace_function_usage(current, file_names[i], display_linum, display_code);
            }

            // Don't forget to free the memory when you're done with it
            free(real_function_name);
        }
        
    }
    

    fclose(header_file);
}

int main(int argc, char** argv) {

    // 0 = -f Trace the func usage in [Files].,
    // 1 = -i Trace all functions listed in the header file in [Files].
    int mode=0;
    int display_linum = 0;
    int display_code = 0;
    char* function_name = NULL;
    char* file_name = NULL;
    char* include_file_name = NULL;

    struct option long_options[] = {
        {"function", required_argument, 0, 'f'},
        {"include", required_argument, 0, 'i'},
        {"linum", no_argument, 0, 'l'},
        {"code", no_argument, 0, 'c'},
        {"help", no_argument, 0, 'h'},
        {0, 0, 0, 0}
    };

    int option_index = 0;
    int c;
    while((c = getopt_long(argc, argv, "f:i:lch", long_options, &option_index)) != -1) {
        switch(c) {
            case 'f':
                function_name = optarg;
                //printf("DEBUG: function_name = %s\n",function_name);
                break;
            case 'i':
                include_file_name = optarg;
                //printf("DEBUG: include_file_name = %s\n",include_file_name);
                break;
            case 'l':
                display_linum = 1;
                break;
            case 'c':
                display_code = 1;
                break;
            case 'h':
                printf("Usage: hw0302 [options] ... [files] ...\n");
                printf("  -f, --function=func    Trace the func usage in [Files].\n");
                printf("  -i, --include=File     Trace all functions listed in the header file in [Files].\n");
                printf("  -l, --linum            Display the line number.\n");
                printf("  -c, --code             Display the code.\n");
                printf("  -h, --help             Display this information and exit.\n\n");
                printf("-f and -i are exclusive and must be at least one.\n");
                break;
            case '?':
                printf("Operation failed\n");
                return 1;
            default:
                return 1;
        }
    }

    //printf("DEBUG: argc: %d\n",argc);
    //printf("DEBUG: optind: %d\n",optind);

    //判斷-f和-i是否只存在一個
    if(function_name == NULL && include_file_name == NULL) {
        printf("Error: Must provide either -f or -i option.\n");
        return 1;
    }else if(function_name != NULL && include_file_name != NULL){
        printf("Error: -f and -i are exclusive.\n");
        return 1;
    }

    //判斷mode
    if(function_name != NULL) {
        mode = 0;
    }else if(include_file_name != NULL) {
        mode = 1;
    }

    if(mode==0){
        printf("%s:\n",function_name);
        for(int i=optind;i<argc;i++){
            char* file_name = argv[i];
            trace_function_usage(function_name, file_name, display_linum, display_code);
        }
        
    }else if(mode==1){
        
        char* file_names[MAX_LINE_LENGTH];
        int file_count = 0;
        for(int i = optind; i < argc; i++) {
            file_names[file_count] = argv[i];
            file_count++;
        }
        
        for(int i = 0; i < file_count; i++) {
            char* file_name = file_names[i];
            //printf("File name: %s\n", file_name);
        }

        trace_function_in_header_usage(include_file_name,file_names,file_count,display_linum,display_code);
    }


    // for(int i = optind; i < argc; i++) {
    //     char* file_name = argv[i];
    //     //printf("DEBUG: file_name = %s\n",file_name);
    //     if(mode==0){
    //         printf("%s:\n",function_name);
    //         trace_function_usage(function_name, file_name, display_linum, display_code);
    //     }else if(mode==1){
    //         trace_function_in_header_usage(include_file_name,file_name,display_linum,display_code);
    //     }
    // }


    return 0;
}