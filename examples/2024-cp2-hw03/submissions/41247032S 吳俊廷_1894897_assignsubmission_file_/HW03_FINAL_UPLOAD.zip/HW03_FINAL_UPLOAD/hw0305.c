#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>


int main(int argc, char** argv) {
    char* input_file_name = NULL;
    char* output_file_name = NULL;
    int width = 0;
    int height = 0;
    int line_width = 0;

    struct option long_options[] = {
        {"input", required_argument, 0, 'i'},
        {"output", required_argument, 0, 'o'},
        {"width", required_argument, 0, 'w'},
        {"height", required_argument, 0, 'h'},
        {"line", required_argument, 0, 'l'},
        {"help", no_argument, 0, 'H'},
        {0, 0, 0, 0}
    };

    int option_index = 0;
    int c;
    while((c = getopt_long(argc, argv, "i:o:w:h:l:H", long_options, &option_index)) != -1) {
        switch(c) {
            case 'i':
                input_file_name = optarg;
                //printf("DEBUG: Input:%s\n",input_file_name);
                break;
            case 'o':
                output_file_name = optarg;
                break;
            case 'w':
                width = atoi(optarg);
                //printf("DEBUG: Width:%d\n",width);
                break;
            case 'h':
                height = atoi(optarg);
                break;
            case 'l':
                line_width = atoi(optarg);
                break;
            case 'H':
                printf("-i, --input, mandatory: input file path\n");
                printf("-o, --output, mandatory: output file path\n");
                printf("-w, --width, mandatory: output bmp file widths\n");
                printf("-h, --height, mandatory: output bmp file height\n");
                printf("-l, --line, mandatory: the radius of line\n");
                printf("-H, --help, option: show help message\n");
                break;
            case '?':
                printf("Unknow option\n");
                break;
            default:
                break;
        }
    }

    // TODO: Continue with your program
    if(input_file_name == NULL || output_file_name == NULL || width == 0 || height == 0 || line_width == 0) {
        printf("Please input all the mandatory options\n");
        return 1;
    }else{
        FILE* input_file = fopen(input_file_name, "r");
        if(input_file == NULL) {
            printf("Cannot open input file\n");
            return 1;
        }
        FILE* output_file = fopen(output_file_name, "w");
        if(output_file == NULL) {
            printf("Cannot open output file\n");
            return 1;
        }
    }

    return 0;
}