#include "mystring.h"


char *mystrchr(const char *s, int c){
    char *ptr=NULL;
    for(unsigned int i=0;i<strlen(s);i++){
        if(s[i] == c){
            ptr = (char*)&s[i];
            break;
        }
    }
    return ptr;
}
char *mystrrchr(const char *s, int c){
    char *ptr=NULL;
    for(int i=strlen(s)-1; i>=0; i--){
        if(s[i] == c){
            ptr = (char*)&s[i];
            break;
        }
    }
    return ptr;
}
size_t mystrspn(const char *s, const char *accept){
    size_t i;
    for (i = 0; s[i]; i++) {
        bool found = false;
        for (size_t j = 0; accept[j]; j++) {
            if (s[i] == accept[j]) {
                found = true;
                break;
            }
        }
        if (!found) {
            break;
        }
    }
    return i;
}
size_t mystrcspn(const char *s, const char *reject){
    size_t i;
    for (i = 0; s[i]; i++) {
        bool found = false;
        for (size_t j = 0; reject[j]; j++) {
            if (s[i] == reject[j]) {
                found = true;
                break;
            }
        }
        if (found) {
            break;
        }
    }
    return i;
}
char *mystrpbrk(const char *s, const char *accept){
    for (size_t i = 0; s[i]; i++) {
        for (size_t j = 0; accept[j]; j++) {
            if (s[i] == accept[j]) {
                return (char*)&s[i];
            }
        }
    }
    return NULL;
}
char *mystrstr(const char *haystack , const char *needle){
    if (!*needle) {
        return (char *)haystack;
    }
    for (size_t i = 0; haystack[i]; i++) {
        if (haystack[i] == needle[0]) {
            size_t j;
            for (j = 0; needle[j]; j++) {
                if (haystack[i + j] != needle[j]) {
                    break;
                }
            }
            if (!needle[j]) {
                return (char *)&haystack[i];
            }
        }
    }
    return NULL;
}
char *mystrtok(char *str, const char *delim){
    static char *p = 0;
    if(str) p = str;
    else if(!p) return 0;
    str = p + strspn(p, delim);
    p = str + strcspn(str, delim);
    if(p == str) return p = 0;
    p = *p ? *p = 0, p + 1 : 0;
    return str;
}