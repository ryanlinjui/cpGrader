/*Steganography is the practice of concealing a file, message, image, or video within another
file, message, image, or video. In this problem, I want you to implement a simple image data
hiding program.
The concept is simple. Given a BMP image file, where R, G, B are presented in 8 bits.
To embed a secret data in the cover BMP file, you just replace the last significant bits with the secret data bit. If you want more capacity, you can use the last two
significant bits. Since we do not want to affect the original image file
too much, the embedding order is from LSB to MSB.
Now I want you to embed and extract a secret data in/from the cover bmp image file.

1 ./hw0303 [option] [cover_bmp] [secret_data]
2 -w, --write: Write the secret data to the cover_bmp.
3 -e, --extract: Extract the secret data from the cover_bmp to the secret_data.
4 -b, --bits=N: use last N bits. N is from 1 to 8. The default N is 1.

There are some notes here.
1. The secret data size should be recorded in the BMP header reserved field which is 4 bytes long.
2. If the secret data is larger than the cover BMP’s hiding capacity, print an error message.
3. For your simplicity, I guarantee that the DPP is 24-bits.
*/
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>


typedef struct __attribute__((packed)) {
    unsigned char blue;
    unsigned char green;
    unsigned char red;
} Pixel;

// BMP header structure
typedef struct __attribute__((packed)){
    unsigned short type;
    unsigned int size;
    unsigned int reserved;
    unsigned int offset;
} BMPHeader ;

// BMP info header structure
typedef struct __attribute__((packed)){
    unsigned int size;
    int width;
    int height;
    unsigned short planes;
    unsigned short bits;
    unsigned int compression;
    unsigned int imagesize;
    int xresolution;
    int yresolution;
    unsigned int ncolours;
    unsigned int importantcolours;
} BMPInfoHeader;


// Function to print BMP header data
void printBMPHeader(BMPHeader header) {
    printf("BMP Header:\n");
    printf("Type: %hu\n", header.type);
    printf("Size: %u\n", header.size);
    printf("Reserved1: %d\n", header.reserved);
    printf("Offset: %u\n", header.offset);
}

void printBMPInfoHeader(BMPInfoHeader infoHeader) {
    printf("BMP Info Header:\n");
    printf("Size: %u\n", infoHeader.size);
    printf("Width: %d\n", infoHeader.width);
    printf("Height: %d\n", infoHeader.height);
    printf("Planes: %hu\n", infoHeader.planes);
    printf("Bits: %hu\n", infoHeader.bits);
    printf("Compression: %u\n", infoHeader.compression);
    printf("Image Size: %u\n", infoHeader.imagesize);
    printf("X Resolution: %d\n", infoHeader.xresolution);
    printf("Y Resolution: %d\n", infoHeader.yresolution);
    printf("Number of Colours: %u\n", infoHeader.ncolours);
    printf("Important Colours: %u\n", infoHeader.importantcolours);
}


// Function to read BMP file
void readBMP(char* filename) {
    FILE* f = fopen(filename, "rb");
    if(f == NULL) {
        printf("Error opening file!\n");
        return;
    }

    BMPHeader header;
    BMPInfoHeader infoHeader;

    // Read the BMP header
    fread(&header, sizeof(BMPHeader), 1, f);

    // Read the BMP info header
    fread(&infoHeader, sizeof(BMPInfoHeader), 1, f);

    // Read the image data
    Pixel* data = malloc(infoHeader.imagesize);
    fread(data, 1, infoHeader.imagesize, f);

    // Print the BMP header data
   //printBMPHeader(header);

    // Print the BMP info header data
    //printBMPInfoHeader(infoHeader);
    

    // Print the data
    printf("%d %d %d",data[0].blue,data[0].green,data[0].red);
    fclose(f);
}

// Assumes little endian
void printBits(size_t const size, void const * const ptr)
{
    unsigned char *b = (unsigned char*) ptr;
    unsigned char byte;
    int i, j;
    
    for (i = size-1; i >= 0; i--) {
        for (j = 7; j >= 0; j--) {
            byte = (b[i] >> j) & 1;
            printf("%u", byte);
        }
    }
    puts("");
}

// Function to write secret data to BMP file
void writeSecretData(char* filename, char* secretDataFile, int n) {
    long long int capacity = 0;

    // Open the BMP file
    FILE* f = fopen(filename, "rb+");
    if (f == NULL) {
        printf("Failed to open %s\n", filename);
        return;
    }

    // Read BMP header
    BMPHeader header;
    fread(&header, sizeof(BMPHeader), 1, f);

    // Read the BMP info header
    BMPInfoHeader infoHeader;
    fread(&infoHeader, sizeof(BMPInfoHeader), 1, f);

    // Calculate the padding
    int padding = (4 - (infoHeader.width * sizeof(Pixel)) % 4) % 4;

    // Allocate memory for the image data
    Pixel* data = malloc(infoHeader.width * infoHeader.height * sizeof(Pixel));

    // Read the image data
    for (int i = 0; i < infoHeader.height; i++) {
        fread(&data[i * infoHeader.width], sizeof(Pixel), infoHeader.width, f);
        fseek(f, padding, SEEK_CUR);
    }

    // Open the secret data file
    FILE* sf = fopen(secretDataFile, "rb");
    if (sf == NULL) {
        printf("Failed to open %s\n", secretDataFile);
        return;
    }

    // Check the size of the secret data
    fseek(sf, 0, SEEK_END);
    long secretSize = ftell(sf);
    secretSize *= 8; // Convert to bits
    fseek(sf, 0, SEEK_SET);

    // Calculate the hiding capacity
    capacity = infoHeader.width * infoHeader.height * 3 * n;
    printf("DEBUG: capacity = %lld\n",capacity);

    // Check if the secret data is larger than the BMP's hiding capacity
    if (secretSize > capacity) {
        //printf("DEBUG: secretSize(bits) = %ld\n",secretSize);
        printf("Error: The secret data is larger than the BMP's hiding capacity (width * height * 3 * bits).\n");
        return;
    }

    // Record the secret data size in the BMP header reserved field
    header.reserved = secretSize;
    printf("DEBUG: secretSize(bits) = %ld\n",secretSize);

    // Write the secret data to the image data
    int i = 0;
    unsigned char secretByte;
    int bitIndex = 0; // 用于跟踪当前处理的位
    unsigned char nBitsValue = 0; // 用于存储n位的值
    int bitsRead = 0; // 已读取的位数

    // 读取一个字节
    while (fread(&secretByte, 1, 1, sf) == 1) {
        // 对于当前字节的每个位
        printf("DEBUG: secretData = ");
        printBits(sizeof(secretByte), &secretByte);
        for (bitIndex = 7; bitIndex >= 0 && i < capacity; bitIndex--) {
            // 提取当前位
            unsigned char bit = (secretByte >> bitIndex) & 0x01;
            // 将当前位添加到nBitsValue中
            nBitsValue = (nBitsValue << 1) | bit;
            bitsRead++;
            printf("DEBUG: bitsRead = %d\n",bitsRead);
            // 检查是否已读取n位
            if (bitsRead == n) {
                printf("DEBUG: bit = %d\n",bit);
                printf("DEBUG: nBitsValue = ");
                printBits(sizeof(nBitsValue), &nBitsValue);

                unsigned char nbitArray[8] = {0}; // 初始化为全0
                int now=0;
                for (int j = 7; j >= 0; j--) {
                    nbitArray[now] = (nBitsValue >> j) & 0x01;
                    now++;
                }
                printf("DEBUG: nbitArray = ");
                for(int j = 0; j < 8; j++) {
                    printf("%d",nbitArray[j]);
                }
                printf("\n");

                // 将n位数据依序放入BGR中
                unsigned char valueToWrite = 0;
                unsigned char temp;
                unsigned char writeArray[8] = {0}; // 初始化为全0

                switch (i % 3) {
                    case 0: // 蓝色分量
                        printf("DEBUG: Color blue\n");
                        printf("DEBUG: before write data[i / 3].blue = ");
                        printBits(sizeof(data[i / 3].blue), &data[i / 3].blue);
                        // 使用nBitsValueArray的数据写入data[i / 3].blue
                        temp = data[i / 3].blue;
                        now=0;
                        for (int j = 7; j >= 0; j--) {
                            writeArray[now] = (temp >> j) & 0x01;
                            now++;
                        }
                        printf("DEBUG: before writeArray = ");
                        for(int j = 0; j < 8; j++) {
                            printf("%d",writeArray[j]);
                        }
                        printf("\n");

                        for(int j=0;j<8;j++){
                            if(j>=8-n){
                                writeArray[j] = nbitArray[j];
                            }
                        }

                        printf("DEBUG: after writeArray = ");
                        for(int j = 0; j < 8; j++) {
                            printf("%d",writeArray[j]);
                        }
                        printf("\n");
                        for(int j = 0; j < 8; j++) {
                            valueToWrite |= (writeArray[7 - j] << j);
                        }
                        data[i / 3].blue = valueToWrite;
                        printf("DEBUG: after write data[i / 3].blue = ");
                        printBits(sizeof(data[i / 3].blue), &data[i / 3].blue);
                        break;
                    case 1: // 绿色分量
                        printf("DEBUG: Color green\n");
                        printf("DEBUG: before data[i / 3].green = ");
                        printBits(sizeof(data[i / 3].green), &data[i / 3].green);
                        // 使用nBitsValueArray的数据写入data[i / 3].green

                        temp = data[i / 3].green;
                        now=0;
                        for (int j = 7; j >= 0; j--) {
                            writeArray[now] = (temp >> j) & 0x01;
                            now++;
                        }
                        printf("DEBUG: before writeArray = ");
                        for(int j = 0; j < 8; j++) {
                            printf("%d",writeArray[j]);
                        }
                        printf("\n");

                        for(int j=0;j<8;j++){
                            if(j>=8-n){
                                writeArray[j] = nbitArray[j];
                            }
                        }

                        printf("DEBUG: after writeArray = ");
                        for(int j = 0; j < 8; j++) {
                            printf("%d",writeArray[j]);
                        }
                        printf("\n");
                        for(int j = 0; j < 8; j++) {
                            valueToWrite |= (writeArray[7 - j] << j);
                        }
                        data[i / 3].green = valueToWrite;
                        printf("DEBUG: after write data[i / 3].green = ");
                        printBits(sizeof(data[i / 3].green), &data[i / 3].green);
                        break;
                    case 2: // 红色分量
                        printf("DEBUG: Color red\n");
                        printf("DEBUG: before data[i / 3].red = ");
                        printBits(sizeof(data[i / 3].red), &data[i / 3].red);
                        // 使用nBitsValueArray的数据写入data[i / 3].red
                        temp = data[i / 3].red;
                        now=0;
                        for (int j = 7; j >= 0; j--) {
                            writeArray[now] = (temp >> j) & 0x01;
                            now++;
                        }
                        printf("DEBUG: before writeArray = ");
                        for(int j = 0; j < 8; j++) {
                            printf("%d",writeArray[j]);
                        }
                        printf("\n");

                        for(int j=0;j<8;j++){
                            if(j>=8-n){
                                writeArray[j] = nbitArray[j];
                            }
                        }

                        printf("DEBUG: after writeArray = ");
                        for(int j = 0; j < 8; j++) {
                            printf("%d",writeArray[j]);
                        }
                        printf("\n");
                        for(int j = 0; j < 8; j++) {
                            valueToWrite |= (writeArray[7 - j] << j);
                        }
                        data[i / 3].red = valueToWrite;
                        printf("DEBUG: after write data[i / 3].red = ");
                        printBits(sizeof(data[i / 3].red), &data[i / 3].red);
                        break;
                }
                printf("\n");
                i++;
                // 重置nBitsValue和bitsRead为下一次读取做准备
                nBitsValue = 0;
                bitsRead = 0;
            }
        }
        // if(bitsRead != 0) {
        // }

        if (i >= capacity) break; // 检查是否达到容量限制
    }
    if(bitsRead!=0){
        printf("DEBUG: not complete!\n");
        //printf("DEBUG: bitsRead = %d\n",bitsRead);
        // 如果读取的位数不是n的倍数，将剩余的位数放入BGR中
        nBitsValue = nBitsValue << (n - bitsRead);
        printf("DEBUG: nBitsValue = ");
        printBits(sizeof(nBitsValue), &nBitsValue);
        printf("\n");

        unsigned char nbitArray[8] = {0}; // 初始化为全0
        int now=0;
        for (int j = 7; j >= 0; j--) {
            nbitArray[now] = (nBitsValue >> j) & 0x01;
            now++;
        }
        printf("DEBUG: nbitArray = ");
        for(int j = 0; j < 8; j++) {
            printf("%d",nbitArray[j]);
        }
        printf("\n");

        // 将n位数据依序放入BGR中
        unsigned char valueToWrite = 0;
        unsigned char temp;
        unsigned char writeArray[8] = {0}; // 初始化为全0
        int alreadyWriteBit = 0;

        switch (i % 3) {
            case 0: // 蓝色分量
                // 使用nBitsValueArray的数据写入data[i / 3].blue
                temp = data[i / 3].blue;
                now=0;
                for (int j = 7; j >= 0; j--) {
                    writeArray[now] = (temp >> j) & 0x01;
                    now++;
                }
                printf("DEBUG: before writeArray = ");
                for(int j = 0; j < 8; j++) {
                    printf("%d",writeArray[j]);
                }
                printf("\n");

                alreadyWriteBit = 0;
                for(int j=0;j<8;j++){
                    if(j>=8-n&&alreadyWriteBit<bitsRead){
                        writeArray[j] = nbitArray[j];
                        alreadyWriteBit++;
                    }
                }

                printf("DEBUG: after writeArray = ");
                for(int j = 0; j < 8; j++) {
                    printf("%d",writeArray[j]);
                }
                printf("\n");
                for(int j = 0; j < 8; j++) {
                    valueToWrite |= (writeArray[7 - j] << j);
                }
                data[i / 3].blue = valueToWrite;
                break;
            case 1: // 绿色分量
                // 使用nBitsValueArray的数据写入data[i / 3].blue
                temp = data[i / 3].green;
                now=0;
                for (int j = 7; j >= 0; j--) {
                    writeArray[now] = (temp >> j) & 0x01;
                    now++;
                }
                printf("DEBUG: before writeArray = ");
                for(int j = 0; j < 8; j++) {
                    printf("%d",writeArray[j]);
                }
                printf("\n");

                alreadyWriteBit = 0;
                for(int j=0;j<8;j++){
                    if(j>=8-n&&alreadyWriteBit<bitsRead){
                        writeArray[j] = nbitArray[j];
                        alreadyWriteBit++;
                    }
                }

                printf("DEBUG: after writeArray = ");
                for(int j = 0; j < 8; j++) {
                    printf("%d",writeArray[j]);
                }
                printf("\n");
                for(int j = 0; j < 8; j++) {
                    valueToWrite |= (writeArray[7 - j] << j);
                }
                data[i / 3].green = valueToWrite;
                break;
            case 2: // 红色分量
                // 使用nBitsValueArray的数据写入data[i / 3].blue
                temp = data[i / 3].red;
                now=0;
                for (int j = 7; j >= 0; j--) {
                    writeArray[now] = (temp >> j) & 0x01;
                    now++;
                }
                printf("DEBUG: before writeArray = ");
                for(int j = 0; j < 8; j++) {
                    printf("%d",writeArray[j]);
                }
                printf("\n");

                alreadyWriteBit = 0;
                for(int j=0;j<8;j++){
                    if(j>=8-n&&alreadyWriteBit<bitsRead){
                        writeArray[j] = nbitArray[j];
                        alreadyWriteBit++;
                    }
                }

                printf("DEBUG: after writeArray = ");
                for(int j = 0; j < 8; j++) {
                    printf("%d",writeArray[j]);
                }
                printf("\n");
                for(int j = 0; j < 8; j++) {
                    valueToWrite |= (writeArray[7 - j] << j);
                }
                data[i / 3].red = valueToWrite;
                break;
        }
        i++;
    }

    // Close the secret data file
    fclose(sf);

    // Write the BMP header back to the BMP file
    fseek(f, 0, SEEK_SET);
    fwrite(&header, sizeof(BMPHeader), 1, f);

    // Write the image data back to the BMP file
    fseek(f, sizeof(BMPHeader) + sizeof(BMPInfoHeader), SEEK_SET);
    for (int i = 0; i < infoHeader.height; i++) {
        fwrite(&data[i * infoHeader.width], sizeof(Pixel), infoHeader.width, f);
        fseek(f, padding, SEEK_CUR);
    }

    // Free the image data
    free(data);

    // Close the BMP file
    fclose(f);
}

// Function to extract secret data from BMP file
void extractSecretData(char* filename, char* secretDataFile, int n) {
    // Open the BMP file
    FILE* f = fopen(filename, "rb");
    if (f == NULL) {
        printf("Failed to open %s\n", filename);
        return;
    }

    // Read the BMP header
    BMPHeader header;
    fread(&header, sizeof(BMPHeader), 1, f);

    // Read the BMP info header
    BMPInfoHeader infoHeader;
    fread(&infoHeader, sizeof(BMPInfoHeader), 1, f);

    // Calculate the padding
    int padding = (4 - (infoHeader.width * sizeof(Pixel)) % 4) % 4;

    // Allocate memory for the image data
    Pixel* data = malloc(infoHeader.width * infoHeader.height * sizeof(Pixel));

    // Read the image data
    for (int i = 0; i < infoHeader.height; i++) {
        fread(&data[i * infoHeader.width], sizeof(Pixel), infoHeader.width, f);
        fseek(f, padding, SEEK_CUR);
    }

    // Open the secret data file for writing
    FILE* sf = fopen(secretDataFile, "wb");
    if (sf == NULL) {
        printf("Failed to open %s\n", secretDataFile);
        free(data);
        fclose(f);
        return;
    }

    // Calculate the number of pixels needed to extract the secret data
    long secretSize = header.reserved;
    printf("DEBUG: secretSize = %ld\n",secretSize);
    long round = secretSize / n;
    long left = secretSize % n;
    printf("DEBUG: round = %ld\n",round);
    printf("DEBUG: left = %ld\n",left);
    //long totalBitsNeeded = secretSize * 8; // Total bits needed
    //long totalPixelsNeeded = totalBitsNeeded / (3 * n); // Total pixels needed

    // Extract the secret data from the image data
    int nowColor = 0;//0=b,1=g,2=r
    int bitsRead = 0;//目前讀到的位數
    unsigned char nBitsArray[8] = {0};//存放n位的值
    unsigned char colorBitsArray[8] = {0};//存放bgr的值
    unsigned char value;
    unsigned char byteBuffer = 0; // 暫存字節
    unsigned char byteBufferArray[8] = {0}; // 暫存字節
    int bitCount = 0; // 已存儲位數
    int nowBit=0;
    
    
    
    for(int i=0;i<round;i++){
        printf("DEBUG: i = %d\n",i);
        printf("DEBUG: data[%d].blue = %d\n",i,data[i].blue);
        printf("DEBUG: data[%d].green = %d\n",i,data[i].green);
        printf("DEBUG: data[%d].red = %d\n",i,data[i].red);
        for(int k=0;k<3;k++){
            unsigned char secretByte = 0;
            unsigned char bit = 0;

            switch(nowColor){
                case 0:
                    value = data[i].blue; // 從data[i].blue獲取藍色通道的值
                    break;
                case 1:
                    value = data[i].green; // 從data[i].green獲取綠色通道的值
                    break;
                case 2:
                    value = data[i].red; // 從data[i].red獲取紅色通道的值
                    break;
            }
            for(int j=0;j<8;j++){
                colorBitsArray[j]=0;
            }
            

            for(int bitIndex = 0; bitIndex < 8; bitIndex++) {
                // 從最高位到最低位檢查每一位
                colorBitsArray[bitIndex] = (value & (1 << (7 - bitIndex))) ? 1 : 0;
            }

            printf("DEBUG: value = %d\n",value);
            printf("DEBUG: colorBitsArray = ");
            for(int j = 0; j < 8; j++) {
                printf("%d",colorBitsArray[j]);
            }
            printf("\n");

            unsigned char mask = (1 << n) - 1; // 計算掩碼
            unsigned char result = value & mask; // 保留最低n位

            printf("DEBUG Result = ");
            printBits(sizeof(result), &result);

            // 將result的最低n位左移bitCount位後與byteBuffer進行位或操作
            //byteBuffer |= (result << bitCount);
            for(int k=0;k<n;k++){
                //printf("DEBUG: nowBit = %d\n",nowBit);
                //printf("DEBUG 8-n+1+k=%d\n",8-n+k);
                byteBufferArray[nowBit] = colorBitsArray[8-n+k];
                
                printf("DEBUG byteBufferArray = ");
                for(int j = 0; j < 8; j++) {
                    printf("%d",byteBufferArray[j]);
                }
                printf("\n");
                nowBit++;

                if(nowBit>=8){
                    nowBit = 0;
                    for(int j = 0; j < 8; j++) {
                        printf("%d",byteBufferArray[j]);
                    }
                    printf("\n");
                    byteBuffer = 0; // 初始化byteBuffer
                    for(int j = 0; j < 8; j++) {
                        byteBuffer |= (byteBufferArray[j] << (7 - j));
                    }
                    printf("DEBUG byteBuffer = ");
                    printBits(sizeof(byteBuffer), &byteBuffer);
                    fwrite(&byteBuffer, 1, 1, sf); // 寫入組合後的字節
                    byteBuffer = 0; // 重置暫存字節
                }

            }
            
            nowColor++;
            if(nowColor==3){
                nowColor = 0;
            }
            //fwrite(&secretByte, 1, 1, sf);
        }
    }

    // Close the secret data file
    fclose(sf);

    // Free the image data
    free(data);

    // Close the BMP file
    fclose(f);
}

int main(int argc, char** argv) {
    int option;
    int bits = 1; // Default bits
    char* cover_bmp = NULL;
    char* secret_data = NULL;
    char operation = 0; // No operation by default

    struct option long_options[] = {
        {"write", required_argument, NULL, 'w'},
        {"extract", required_argument, NULL, 'e'},
        {"bits", required_argument, NULL, 'b'},
        {0, 0, 0, 0}
    };

    while ((option = getopt_long(argc, argv, "w:e:b:", long_options, NULL)) != -1) {
        switch (option) {
            case 'w':
                if (operation) {
                    printf("Error: -w and -e cannot be used together.\n");
                    return 1;
                }
                operation = 'w';
                cover_bmp = optarg;
                break;
            case 'e':
                if (operation) {
                    printf("Error: -w and -e cannot be used together.\n");
                    return 1;
                }
                operation = 'e';
                cover_bmp = optarg;
                break;
            case 'b':
                bits = atoi(optarg);
                if (bits < 1 || bits > 8) {
                    printf("Error: bits should be from 1 to 8.\n");
                    return 1;
                }
                break;
            default:
                printf("Usage: %s [-w cover_bmp] [-e cover_bmp] [-b bits] secret_data\n", argv[0]);
                return 1;
        }
    }

    if (optind < argc) {
        secret_data = argv[optind];
    }
    printf("DEBUG: cover_bmp = %s\n",cover_bmp);
    printf("DEBUG: secret_data = %s\n",secret_data);
    readBMP(cover_bmp);
    if (operation == 'w') {
        writeSecretData(cover_bmp, secret_data, bits);
    } else if (operation == 'e') {
        extractSecretData(cover_bmp, secret_data, bits);
    }

    return 0;
}