#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
int main(){
    

    return 0;
}