#ifndef _UTILITY_H_
#define _UTILITY_H_
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <unistd.h>
int32_t trace(int8_t , int8_t , char *, char*);
int32_t func(int8_t , int8_t , char *, char*);
void help();
void remove_asterisks(char *str);

#endif