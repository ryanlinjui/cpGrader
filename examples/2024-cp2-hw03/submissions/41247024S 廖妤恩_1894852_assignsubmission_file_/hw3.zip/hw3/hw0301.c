#include<stdio.h>
#include<stdint.h>
#include<string.h>

int main()
{
    FILE *file = fopen( "bible.txt", "r" );
    char input[1025];
    if ( file == NULL )
    {
        printf("No such file, please check your file again.\n");
        return 0;
    }
    char compare[1025];
    printf("Please enter the search target: ");
    fgets( compare, 1025, stdin );
    if ( compare[strlen(compare)-1] == '\n' ) compare[strlen(compare)-1] = '\0';
    //printf("%d\n",strlen(compare));
    int32_t target = strlen(compare);
    int32_t time = 0;
    //first time
    while ( fgets ( input, 1025, file ) != NULL )
    {
        int32_t count = 0;
        int32_t skip = 0;
        int32_t site = 0;
        int32_t k = 0;
        while ( skip < 7 )
        {
            if ( input[k] == '\"' ) skip++;
            k++;
            site++;
        }
        for ( int32_t i = site ; i < strlen(input) ; i ++ )
        {
            count = 0;
            if ( input[i] == '\"' ) break;
            for ( int32_t j = 0 ; j < target ; j ++ )
            {
                if ( input[i+j] == compare[j] ) count++;
                else if ( input[i+j] + 32 == compare[j] ) count++;
                else if ( input[i+j] - 32 == compare[j] ) count++;
            }
            if ( count == target )
            {
                time++;
                break;
            }
        }
    }
    fclose(file);
    printf("Found %d time(s)\n",time);
    file = fopen( "bible.txt", "r" );
    //second
    int32_t no = 0;
    while ( fgets ( input, 1025, file ) != NULL )
    {
        int32_t count = 0;
        int32_t skip = 0;
        int32_t site = 0;
        int32_t k = 0;
        int32_t found = 0;
        while ( skip < 7 )
        {
            if ( input[k] == '\"' ) skip++;
            k++;
            site++;
        }
        for ( int32_t i = site ; i < strlen(input) ; i ++ )
        {
            count = 0;
            if ( input[i] == '\"' ) break;
            for ( int32_t j = 0 ; j < target ; j ++ )
            {
                if ( input[i+j] == compare[j] ) count++;
                else if ( input[i+j] + 32 == compare[j] ) count++;
                else if ( input[i+j] - 32 == compare[j] ) count++;
            }
            if ( count == target )
            {
                time++;
                found++;
                break;
            }
        }
        if ( found == 1 )
        {
            char output[1025];
            char name[1025];
            no++;
            int32_t chapter = 0;
            int32_t verse = 0;
            int32_t c1 = 0;
            int32_t c2 = 0;
            int32_t k = 0;
            int32_t have = 0;
            while (1)
            {
                if ( input[k] == ':') c1++;
                if ( input[k] == '\"' ) c2++;
                if ( c1 == 1 && have == 0 )
                {
                    k++;
                    while( input[k]!=',' )
                    {
                        chapter = chapter*10 + input[k] - 48;
                        k++;
                    }
                    have++;
                }
                if ( c1 == 2 && have == 1 )
                {
                    k++;
                    while( input[k]!=',' )
                    {
                        verse = verse*10 + input[k] - 48;
                        k++;
                    }
                    have++;
                }
                if ( c2 == 7 && have == 2 )
                {
                    k++;
                    for ( int32_t i = k ; input[i] != '\"' ; i ++ )
                    {
                        output[i-k] = input[i];
                        output[i-k+1] = '\0';
                    }
                    have++;
                }
                if ( c2 == 15 && have == 3 )
                {
                    k++;
                    for ( int32_t i = k ; input[i] != '\"' ; i ++ )
                    {
                        name[i-k] = input[i];
                        name[i-k+1] = '\0';
                    }
                    break;
                }
                k++;
            }
            printf("%d. %s %d.%d %s\n", no, name, chapter, verse, output );
        }
    }
    fclose(file);
}