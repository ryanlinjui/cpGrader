#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<getopt.h>

void drawline( int32_t *color, int32_t ***a, int32_t height, int32_t width, int32_t highest, int32_t site, int32_t line )
{
    for ( int32_t i = 0 ; i < 255 ; i ++ )
    {
        double y;
        y = (double)(((double)color[i]*(height-1))/highest);
        double m = (double)((((double)color[i+1]*(height-1))/highest)-(((double)color[i]*(height-1))/highest))/(double)((((double)(i+1)*(width-1))/256.0)-(((double)i*(width-1))/256.0));
        for ( double j = (double)(((double)i*(width-1))/256.0) ; j < (double)(((double)(i+1)*(width-1))/256.0) && j >=0 && j < width ; j += 0.01 )
        {
            //printf("%lf %lf\n",j,y);
            y+=m*0.01;
            if ( y >=0 && y < height ) 
            {
                a[(uint32_t)y][(uint32_t)j][site] = 255;
                int32_t count = 1;
                while ( count != line )
                {
                    int32_t minus = (double)(255/line);
                    for ( int32_t t = -count ; t <= count ; t ++ )
                    {
                        for ( int32_t u = -count ; u <= count ; u ++ )
                        {
                            if ( abs(t) + abs(u) == count && (uint32_t)y+u >= 0 && (uint32_t)y+u < height && (uint32_t)j+t >= 0 && (uint32_t)j+t < width )
                            {
                                if ( a[(uint32_t)y+u][(uint32_t)j+t][site] < 255-minus*count ) a[(uint32_t)y+u][(uint32_t)j+t][site] = 255-minus*count;
                            }
                        }
                    }
                    count++;
                }
            }
        }
    }
}

struct option opts[] =
{
    {"input",1,NULL,'i'},
    {"output",1,NULL,'o'},
    {"width",1,NULL,'w'},
    {"height",1,NULL,'h'},
    {"line",1,NULL,'l'},
    {"help",0,NULL,'H'}
};

int main(int argc, char *argv[])
{
    char *optstring = "i:o:w:h:l:H";
    char c;
    int32_t icount = 0;
    int32_t ocount = 0;
    int32_t wcount = 0;
    int32_t hcount = 0;
    int32_t lcount = 0;
    int32_t help = 0;
    char input[1025];
    char output[1025];
    char cwidth[1025];
    char cheight[1025];
    char cline[1025];
    while ( ( c = getopt_long( argc, argv , optstring, opts , NULL) ) != -1 )
    {
        switch(c)
        {
            case'i':
                icount++;
                strcpy(input,optarg);
                break;

            case'o':
                ocount++;
                strcpy(output,optarg);
                break;

            case'w':
                wcount++;
                strcpy(cwidth,optarg);
                break;

            case'h':
                hcount++;
                strcpy(cheight,optarg);
                break;

            case'l':
                lcount++;
                strcpy(cline,optarg);
                break;

            case'H':
                help++;
                break;
        }
    }

    if ( help >= 1 )
    {
        printf("-i, --input, mandatory: input file path\n");
        printf("-o, --output, mandatory: output file path\n");
        printf("-w, --width, mandatory: output bmp file widths\n");
        printf("-h, --height, mandatory: output bmp file height\n");
        printf("-l, --line, mandatory: the radius of line\n");
        printf("-H, --help, option: show help message\n");
        return 0;
    }

    if ( icount != 1 || ocount != 1 || wcount != 1 || hcount != 1 || lcount != 1 )
    {
        printf("Wrong input.\n");
        return 0;
    }

    //input file
    if ( input[strlen(input)-1] == 10 ) input[strlen(input)-1] = 0;
    if ( output[strlen(output)-1] == 10 ) output[strlen(output)-1] = 0;
    int32_t red[256] = {0};
    int32_t blue[256] = {0};
    int32_t green[256] = {0};
    FILE *file = fopen(input,"rb");
    if ( file == NULL )
    {
        printf("No such file.\n");
        return 0;
    }
    int32_t bmpheight = 0;
    int32_t bmpwidth = 0;
    char bm[2];
    fread( &bm, 2, 1, file );
    uint32_t size;
    fread( &size, 4, 1, file );
    uint32_t reserve;
    fread( &reserve, 4, 1, file );
    uint32_t offset;
    fread( &offset, 4, 1, file );
    uint32_t infoheader;
    fread( &infoheader, 4, 1, file );
    fread( &bmpwidth, 4, 1, file );
    fread( &bmpheight, 4, 1, file );
    uint16_t plane;
    fread( &plane, 2, 1, file );
    uint16_t bpp;
    fread( &bpp, 2, 1, file );
    uint32_t compress;
    fread( &compress, 4, 1, file );
    uint32_t bmpsize;
    fread( &bmpsize, 4, 1, file );
    uint32_t xpi;
    fread( &xpi, 4, 1, file );
    uint32_t ypi;
    fread( &ypi, 4, 1, file );
    uint32_t used;
    fread( &used, 4, 1, file );
    uint32_t import;
    fread( &import, 4, 1, file );
    int32_t heighest = 0;
    for ( int32_t i = 0 ; i < bmpheight ; i ++ )
    {
        for ( int32_t j = 0 ; j < bmpwidth ; j ++ )
        {
            for ( int32_t k = 0 ; k < 3 ; k ++ )
            {
                uint8_t save;
                fread(&save,1,1,file);
                if ( k == 0 ) 
                {
                    blue[save]++;
                    if ( blue[save] > heighest ) heighest = blue[save];
                }
                else if ( k == 1 )
                {
                    green[save]++;
                    if ( green[save] > heighest ) heighest = green[save];
                }
                else
                {
                    red[save]++;
                    if ( red[save] > heighest ) heighest = red[save];
                }
                
            }
        }
        for ( int32_t j = 0 ; j < ( 4 - ( bmpwidth*3%4 ) ) % 4 ; j ++ )
        {
            char temp;
            fread( &temp, 1, 1, file );
        }
    }
    /*for ( int32_t i = 0 ; i < 256 ; i ++ )
    {
        printf("%d: %d %d %d\n",i,blue[i],green[i],red[i]);
    }*/
    fclose(file);
    //height: heighest width: 255
    //calculate height and width
    int32_t newwidth = atoi(cwidth);
    int32_t newheight = atoi(cheight);
    int32_t newline = atoi(cline);
    if ( newline < 1 )
    {
        printf("Wrong input.\n");
        return 0;
    }
    //printf("%d %d %d\n",newheight,newline,newwidth);
    //calloc
    int32_t *** a = calloc(newheight,sizeof(int32_t **));
    for ( int32_t i = 0 ; i < newheight ; i ++ )
    {
        a[i] = calloc(newwidth,sizeof(int32_t *));
        for ( int32_t j = 0 ; j < newwidth ; j ++ )
        {
            a[i][j] = calloc(3,sizeof(int32_t));
        }
    }
    //printf("hi\n");
    for ( int32_t i = 0 ; i < 256 ; i ++ )
    {
        int32_t x, y;
        //blue
        x = (double)(((double)i*(newwidth-1))/256.0);
        y = (double)(((double)blue[i]*(newheight-1))/heighest);
        //printf("%d %d ",x,y);
        a[(uint32_t)y][(uint32_t)x][0] = 255;

        //green
        y = (double)(((double)green[i]*(newheight-1))/heighest);
        //printf("%d %d ",x,y);
        a[(uint32_t)y][(uint32_t)x][1] = 255;
        
        //red
        y = (double)(((double)red[i]*(newheight-1))/heighest);
        //printf("%d %d\n",x,y);
        a[(uint32_t)y][(uint32_t)x][2] = 255;
    }
    drawline( blue, a, newheight, newwidth, heighest, 0, newline );
    drawline( green, a, newheight, newwidth, heighest, 1, newline );
    drawline( red, a, newheight, newwidth, heighest, 2, newline );

    //new picture
    FILE *outputfile = fopen(output,"wb");
    bmpsize = newwidth*newheight;
    while ( newwidth%4 != 0 ) newwidth++;
    size = newwidth*newheight;
    //header
    fwrite( &bm[0], 1, 1, outputfile );
    fwrite( &bm[1], 1, 1, outputfile );
    fwrite( &size, 4, 1, outputfile );
    fwrite( &reserve, 4, 1, outputfile );
    fwrite( &offset, 4, 1, outputfile );
    fwrite( &infoheader, 4, 1, outputfile );
    fwrite( &newwidth, 4, 1, outputfile );
    fwrite( &newheight, 4, 1, outputfile );
    fwrite( &plane, 2, 1, outputfile );
    fwrite( &bpp, 2, 1, outputfile );
    fwrite( &compress, 4, 1, outputfile );
    fwrite( &bmpsize, 4, 1, outputfile );
    fwrite( &xpi, 4, 1, outputfile );
    fwrite( &ypi, 4, 1, outputfile );
    fwrite( &used, 4, 1, outputfile );
    fwrite( &import, 4, 1, outputfile );
    //printf("hi\n");
    //color
    for ( int32_t i = 0 ; i < newheight ; i ++ )
    {
        for ( int32_t j = 0 ; j < newwidth ; j ++ )
        {
            for ( int32_t k = 0 ; k < 3 ; k ++ )
            {
                fwrite(&a[i][j][k],1,1,outputfile);
            }
        }
        for ( int32_t j = 0 ; j < ( 4 - ( newwidth*3%4 ) ) % 4 ; j ++ )
        {
            fwrite( "00", 1, 1, outputfile );
        }
    }
    fclose(outputfile);
    free(a);
}