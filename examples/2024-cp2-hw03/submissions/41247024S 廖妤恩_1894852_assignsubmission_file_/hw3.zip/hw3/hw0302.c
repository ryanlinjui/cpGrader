#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<unistd.h>
#include<getopt.h>

int32_t check_ans ( int mode, char *original, FILE *check_file )
{
    int32_t line = 0;
    int32_t find = 0;
    int32_t total = 0;
    int32_t length = strlen(original);
    int32_t delete = 0;
    int32_t mark = 0;
    char input[1025];
    while ( fgets ( input, 1025, check_file ) != NULL )
    {
        if ( mark == -1 ) mark++;
        for ( int32_t j = 0 ; input[j] != '\0' ; j ++ )
        {
            if ( input[j] == '/' && input[j+1] == '/' ) 
            {
                delete++;
                continue;
            }
            if ( input[j] == '/' && input[j+1] == '*' ) 
            {
                mark++;
                continue;
            }
        } 
        for ( int32_t j = 0 ; input[j] != '\0' ; j ++ )
        {
            total = 0;
            for ( int32_t k = 0 ; k < length ; k ++ )
            {
                if ( input[j+k] == original[k] ) total++;
            }
            if ( total == length )
            {
                int32_t gua = 0;
                for ( int32_t k = j ; input[k] != '\0' ; k ++ )
                {
                    if ( input[k] == '(' ) gua++;    
                }
                int32_t count = 0;
                for ( int32_t k = j ; k >= 0 ; k -- )
                {
                    if ( input[k] == '"' )
                    {
                        count++;    
                    }
                }
                if ( count % 2 == 1 ) gua = 0;
                if ( gua >= 1 )
                {
                    if ( delete > 0 ) 
                    {
                        delete = 0;
                        break;
                    }
                    else if ( mark > 0 )
                    {
                        delete = 0;
                        break;
                    }
                    if( mode == 1 )
                    {
                        printf("    line %d:",line+1);
                        printf("  ");
                        int32_t start = 0;
                        for ( int32_t m = 0 ; input[m] != '\0' ; m++ )
                        {
                            if ( input[m] != ' ' ) 
                            {
                                start = m;
                                break;
                            }
                        }
                        for ( int32_t m = start ; input[m] != '\0' ; m++ ) printf("%c",input[m]);
                    }
                    else if ( mode == 2 )
                    {
                        printf("    line %d\n",line+1);
                    }
                    else if ( mode == 3 )
                    {
                        printf("    ");
                        int32_t start = 0;
                        for ( int32_t m = 0 ; input[m] != '\0' ; m++ )
                        {
                            if ( input[m] != ' ' ) 
                            {
                                start = m;
                                break;
                            }
                        }
                        for ( int32_t m = start ; input[m] != '\0' ; m++ ) printf("%c",input[m]);
                    }
                    find++;
                    break;
                }
                else break;
            }
        }
        for ( int32_t j = 0 ; input[j] != '\0' ; j ++ )
        {
            if ( input[j] == '*' && input[j+1] == '/' ) 
            {
                mark = -1;
                continue;
            }
        }
        delete = 0;
        line++;
    }
    fclose(check_file);    
    return find;       
}

struct option opts[] =
{
    {"help",0,NULL,'h'},
    {"function",1,NULL,'f'},
    {"include",1,NULL,'i'},
    {"linum",0,NULL,'l'},
    {"code",0,NULL,'c'}
};

int main ( int argc, char *argv[] )
{
    FILE *check_file;
    int32_t icount = 0;
    int32_t fcount = 0;
    int32_t ccount = 0;
    int32_t lcount = 0;

    for ( int32_t i = 0 ; i < argc ; i ++ )
    {
        //help
        if ( strcmp ( argv[i], "--help" ) == 0 || strcmp ( argv[i], "-h" ) == 0 )
        {
            printf("Usage: hw0302 [options] ... [files] ...\n");
            printf("-f, --function=func Trace the func usage in [Files].\n");
            printf("-i, --include=File Trace all functions listed in the header file in [Files].\n");
            printf("-l, --linum Display the line number.\n");
            printf("-c, --code Display the code.\n");
            printf("-h, --help Display this information and exit.\n\n");
            printf("-f and -i are exclusive and must be at least one.\n");
            return 0;
        }
    }
    //printf("%d %d\n",icount,fcount);
    char *optstring = "lchf:i:";
    char c;
    int32_t site = -1;
    char original[1025];
    char header[1025];
    while( ( c = getopt_long(argc, argv , optstring, opts , NULL) ) != -1 )
    {
        switch (c)
        {
            case'i':
                //printf("i: %s\n",optarg);
                strcpy(header,optarg);
                icount++;
                break;

            case'f':
                //printf("f\n");
                strcpy(original,optarg);
                fcount++;
                break;

            case'l':
                lcount++;
                break;

            case'c':
                ccount++;
                break;

            default:
                printf("Invalid command, please input again.\n");
                return 0;
        }
    } 

    if ( icount == 0 && fcount == 0 ) return 0;
    if ( icount >= 1 && fcount >= 1 )
    {
        printf("Wrong input, -f & -i are exclusive.\n");
        return 0;
    }
    
    if ( fcount >= 1 )
    {
        printf("%s:\n",original);
        for ( int32_t i = optind ; i < argc ; i ++ )
        {
            char input[1025];
            //printf("time: %d\n",i);
            check_file = fopen(argv[i],"r");
            //printf("%s",argv[i]);
            if ( check_file == NULL )
            {
                printf("No such file.\n");
                return 0;
            }
            
            printf("  %s (count: %d)\n",argv[i],check_ans(0,original,check_file));
            check_file = fopen(argv[i],"r");
            
            char inpu[1025];
            if ( lcount >= 1 && ccount >= 1 ) 
            {
                int32_t r = check_ans ( 1, original, check_file );
            }
            else if ( lcount >= 1 ) 
            {
                int32_t r = check_ans ( 2, original, check_file );
            }
            else if ( ccount >= 1 ) 
            {
                int32_t r = check_ans ( 3, original, check_file );
            }
        }
    }
    if ( icount >= 1 )
    {
        FILE *header_file = fopen( header, "r" );
        if ( header_file == NULL )
        {
            printf("No such file.\n");
            return 0;
        }
        char in[1025];
        while ( fgets ( in, 1025, header_file ) != NULL )
        {
            int32_t end = 0;
            for ( int32_t i = 0 ; in[i] != '\0' ; i ++ )
            {
                if ( in[i] == '#' )
                {
                    end = -1;
                    break;
                }
                end = i;
            }
            if ( end == -1 ) continue; 
            int32_t count = 0;
            for ( int32_t i = end ; i >= 0 ; i -- )
            {
                if ( in[i] != '\n' && in[i] != '\0' && in[i] != ' ' ) count++;
            }
            //printf("%d\n",count);
            if ( count == 1 ) continue;
            //printf("hi\n");
            int32_t start = 0;
            for ( int32_t i = 0 ; in[i] != '\0' ; i ++ )
            {
                if ( ( in[i] == ' ' || in[i] == '*' ) && ( ( in[i+1] >= 'A') && (in[i+1] <= 'Z') || ( in[i+1] >= 'a') && (in[i+1] <= 'z') ) )
                {
                    start = i;
                    break;
                }
                //printf("%c",in[i]);
            }
            //for ( int32_t i = start+1 ; in[i] != '\0' ; i ++ ) printf("%c",in[i]);
            char target[1025];
            for ( int32_t i = start+1 ; in[i] != '\0' ; i ++ )
            {
                if ( in[i] == '(' )
                {
                    target[i-start-1] = '\0';
                    break;
                }
                target[i-start-1] = in[i];
            }
            printf("%s:\n",target);
            for ( int32_t i = optind ; i < argc ; i ++ )
            {
                char input[1025];
                //printf("time: %d\n",i);
                check_file = fopen(argv[i],"r");
                //printf("%s",argv[i]);
                if ( check_file == NULL )
                {
                    printf("No such file.\n");
                    return 0;
                }
                printf("  %s (count: %d)\n",argv[i],check_ans(0,target,check_file));
                check_file = fopen(argv[i],"r");
                char inpu[1025];
                if ( lcount >= 1 && ccount >= 1 ) 
                {
                    int32_t r = check_ans ( 1, target, check_file );
                }
                else if ( lcount >= 1 ) 
                {
                    int32_t r = check_ans ( 2, target, check_file );
                }
                else if ( ccount >= 1 ) 
                {
                    int32_t r = check_ans ( 3, target, check_file );
                }
            }
        }
    }
}