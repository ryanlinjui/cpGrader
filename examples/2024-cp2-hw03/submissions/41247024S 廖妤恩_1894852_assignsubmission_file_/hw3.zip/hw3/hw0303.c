#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<getopt.h>

int32_t reduction( int32_t *array )
{
    int32_t total = 0;
    for ( int32_t i = 7 ; i >= 0 ; i -- )
    {
        total = total*2 + array[i];
    }
    return total;
}

void binary( int32_t n, int32_t *array )
{
    int32_t i = 0;
    for ( int32_t j = 0 ; j < 8 ; j ++ ) array[j] = 0;
    while ( n > 0 )
    {
        array[i] = n % 2;
        n /= 2; 
        i++;
    }
}

struct option opts[] =
{
    {"write",0,NULL,'w'},
    {"extract",0,NULL,'e'},
    {"bits",1,NULL,'b'}
};

int main ( int argc, char *argv[] )
{
    char *optstring = "web:";
    char c;
    int32_t wcount = 0;
    int32_t ecount = 0;
    int32_t bcount = 0;
    int32_t bits = 1;
    while ( ( c = getopt_long(argc, argv , optstring, opts , NULL) ) != -1 )
    {
        switch(c)
        {
            case'w':
                wcount++;
                break;

            case'e':
                ecount++;
                break;

            case'b':
                bcount++;
                if ( strlen(optarg) != 1 )
                {
                    printf("Wrong input.\n");
                    return 0;
                }
                bits = (int)*optarg-48;
                if ( bits < 1 || bits > 8 )
                {
                    printf("Wrong input.\n");
                    return 0;
                }
                //printf("%d\n",bits);
                break;

            default:
                break;
        }
    }

    if ( wcount >= 1 && ecount >= 1 )
    {
        printf("Wrong input.\n");
        return 0;
    }
    char filename[1025];
    char key[1025];
    int32_t pan = 0;
    for ( int32_t i = optind ; i < argc ; i ++ )
    {
        pan++;
        if ( pan == 1 ) strcpy( filename, argv[i] );
        if ( pan == 2 ) strcpy( key, argv[i] );
        //printf("%s\n",argv[i]);
    }
    if ( pan != 2 ) 
    {
        printf("Wrong input.\n");
        return 0;
    }
    //printf("%s %s\n",filename,key);
    if ( filename[strlen(filename)-1] == 10 ) filename[strlen(filename)-1] = 0;
    if ( key[strlen(key)-1] == 10 ) key[strlen(key)-1] = 0;
    FILE *bmpfile;
    FILE *datafile;
    int32_t datasize = 0;
    datafile = fopen( key,"r");
    if ( datafile == NULL )
    {
        printf("File doesn't exist.\n");
        return 0;
    }
    while ( !feof(datafile) ) 
    {
        int32_t a;
        fread(&a,1,1,datafile);
        datasize++;
    }
    datasize--;
    //printf("size: %d\n",datasize);
    fclose(datafile);
    bmpfile = fopen(filename,"rb");
    if ( bmpfile == NULL )
    {
        printf("File doesn't exist.\n");
        return 0;
    }
    int32_t width = 0;
    int32_t height = 0;
    char bm[2];
    fread( &bm, 2, 1, bmpfile );
    uint32_t size;
    fread( &size, 4, 1, bmpfile );
    uint32_t reserve;
    fread( &reserve, 4, 1, bmpfile );
    uint32_t offset;
    fread( &offset, 4, 1, bmpfile );
    uint32_t infoheader;
    fread( &infoheader, 4, 1, bmpfile );
    fread( &width, 4, 1, bmpfile );
    fread( &height, 4, 1, bmpfile );
    uint16_t plane;
    fread( &plane, 2, 1, bmpfile );
    uint16_t bpp;
    fread( &bpp, 2, 1, bmpfile );
    uint32_t compress;
    fread( &compress, 4, 1, bmpfile );
    uint32_t bmpsize;
    fread( &bmpsize, 4, 1, bmpfile );
    uint32_t xpi;
    fread( &xpi, 4, 1, bmpfile );
    uint32_t ypi;
    fread( &ypi, 4, 1, bmpfile );
    uint32_t used;
    fread( &used, 4, 1, bmpfile );
    uint32_t import;
    fread( &import, 4, 1, bmpfile );
    int32_t *** a = calloc(height,sizeof(int32_t **));
    for ( int32_t i = 0 ; i < height ; i ++ )
    {
        a[i] = calloc(width,sizeof(int32_t *));
        for ( int32_t j = 0 ; j < width ; j ++ )
        {
            a[i][j] = calloc(3,sizeof(int32_t));
            for ( int32_t k = 0 ; k < 3 ; k ++ )
            {
                fread( &a[i][j][k], 1, 1, bmpfile );
                //printf("%d ",a[i][j][k]);
            }
            //printf("\n");
        }
        for ( int32_t j = 0 ; j < ( 4 - ( width*3%4 ) ) % 4 ; j ++ )
        {
            char temp;
            fread( &temp, 1, 1, bmpfile );
        }
    }
    fclose(bmpfile);
    if ( wcount >= 1 )
    {
        //printf("width: %d height: %d\n",width,height);
        if ( width * height * 3 * bits < datasize * 8 )
        {
            printf("Secret data is larger than the cover BMP’s hiding capacity.\n");
            return 0;
        }
        //change
        bmpfile = fopen(filename,"wb");
        fwrite( &bm[0], 1, 1, bmpfile );
        fwrite( &bm[1], 1, 1, bmpfile );
        fwrite( &size, 4, 1, bmpfile );
        fwrite( &datasize, 4, 1, bmpfile );
        fwrite( &offset, 4, 1, bmpfile );
        fwrite( &infoheader, 4, 1, bmpfile );
        fwrite( &width, 4, 1, bmpfile );
        fwrite( &height, 4, 1, bmpfile );
        fwrite( &plane, 2, 1, bmpfile );
        fwrite( &bpp, 2, 1, bmpfile );
        fwrite( &compress, 4, 1, bmpfile );
        fwrite( &bmpsize, 4, 1, bmpfile );
        fwrite( &xpi, 4, 1, bmpfile );
        fwrite( &ypi, 4, 1, bmpfile );
        fwrite( &used, 4, 1, bmpfile );
        fwrite( &import, 4, 1, bmpfile );
        datafile = fopen( key,"rb");
        int32_t now = 0;
        fread( &now, 1, 1, datafile );
        int32_t num = 8;
        int32_t bi[8] = {0};
        binary( now, bi );
        //for ( int i = 7 ; i >= 0 ; i -- ) printf("%d",bi[i]);
        for ( int32_t i = 0 ; i < height ; i ++ )
        {
            for ( int32_t j = 0 ; j < width ; j ++ )
            {
                for ( int32_t k = 0 ; k < 3 ; k ++ )
                {
                    int32_t b = a[i][j][k];
                    if ( datasize == 0 )
                    {
                        fwrite( &b, 1, 1, bmpfile );
                        continue;
                    }
                    //printf(" %d \n",b);
                    int32_t g[8];
                    binary(b,g);
                    //for ( int32_t m = 7 ; m >= 0 ; m -- ) printf("%d",g[m]);
                    //printf("\n");
                    for ( int32_t h = 0 ; h < bits ; h ++ )
                    {
                        g[bits-1-h] = bi[num-1];
                        num--;
                        if ( num == 0 )
                        {
                            num = 8;
                            fread(&now,1,1,datafile);
                            binary(now,bi);
                            //for ( int i = 7 ; i >= 0 ; i -- ) printf("%d",bi[i]);
                        }
                    }
                    //for ( int32_t m = 7 ; m >= 0 ; m -- ) printf("%d",g[m]);
                    //printf("\n");
                    b = reduction(g);
                    //printf("b : %d\n",b);
                    fwrite ( &b, 1, 1, bmpfile );
                    datasize--;
                }
            }
            for ( int32_t j = 0 ; j < ( 4 - ( width*3%4 ) ) % 4 ; j ++ )
            {
                fwrite( "00", 1, 1, bmpfile );
            }
        }
    }
    if ( ecount >= 1 )
    {
        datafile = fopen(key,"wb");
        int32_t count = 0;
        int32_t bi[8] = {0};
        int32_t now = 7;
        for ( int32_t i = 0 ; i < height ; i ++ )
        {
            for ( int32_t j = 0 ; j < width ; j ++ )
            {
                for ( int32_t k = 0 ; k < 3 ; k ++ )
                {
                    uint8_t c = a[i][j][k];
                    int32_t di[8];
                    binary(c,di);
                    for ( int32_t l = 0 ; l < bits ; l ++ )
                    {
                        bi[now] = di[bits-l-1];
                        now--;
                        if ( now == -1 )
                        {
                            now = 7;
                            int32_t f = reduction(bi);
                            fwrite(&f,1,1,datafile);
                            count++;
                            if ( count == reserve )
                            {
                                free(a);
                                fclose(datafile);
                                return 0;
                            }
                        }
                    }
                }
            }
        }
    }
    free(a);
    fclose(datafile);
    fclose(bmpfile);
}