#include <stdio.h>
#include <math.h>
#include <stdint.h>
int32_t L;//the length
int32_t N;//the number of layer
int32_t max_width=0;
int32_t single_hexagon_height_line;
int32_t single_hexagon_width_line;
int32_t max_width_line;
int main(){
    printf("Please input the length: ");
    scanf("%d",&L);
    printf("Please input the number of layer: ");
    scanf("%d",&N);

    //Count max width
    if(N%2==0){
        max_width=N*L+(N-1)*2*L;
    }else{
        max_width=N*2*L+(N-1)*L;
    }

    //Check if the input is valid
    if(N<1){
        printf("Error: N is too small.\n");
        return 0;
    }else if(L<3){
        printf("Error: L is too small.\n");
        return 0;
    }else if(max_width>80){
        printf("Error: The width is larger than 80.\n");
        return 0;
    }
    //printf("max_width=%d\n",max_width);


    //Process init data
    single_hexagon_width_line=5+(L-2-1)*3+2;
    single_hexagon_height_line=2*L-1;
    max_width_line=single_hexagon_width_line*N+(N-1)*L-2*(N-1);


    //printf("DEBUG: single_hexagon_width_line=%d\n",single_hexagon_width_line);
    //printf("DEBUG: single_hexagon_height_line=%d\n",single_hexagon_height_line);
    //printf("DEBUG: max_width_line=%d\n",max_width_line);

    //Start draw
    int32_t L_counter=1;
    int32_t space_counter=0;
    int32_t slash_pair_in_hexagon_counter=1;
    int32_t space_pair_in_hexagon_counter=0;

    int32_t now_space=(max_width_line-L)/2;
    int32_t space_in_hexagon=L;
    int32_t space_outside_hexagon=single_hexagon_width_line-4;


    //First part
    for(int i=0;i<N;i++){

        /*1/2*/
        int32_t temp_L_counter=L_counter;
        int32_t temp_space_counter=space_counter;
        int32_t space_in_hexagon=L;

        for(int j=0;j<now_space;j++){
            printf(" ");
        }
        //printf("temp_space_counter=%d\n",temp_space_counter);
        //printf("temp_L_counter=%d\n",temp_L_counter);
        while(temp_space_counter>0||temp_L_counter>0){
            
            if(temp_L_counter>0){
                temp_L_counter--;
                printf("*");
                for(int k=0;k<L-2;k++){
                    printf("-");
                }
                printf("*");
            }
            if(temp_space_counter>0){
                temp_space_counter--;
                for(int k=0;k<single_hexagon_width_line-2;k++){
                    printf(" ");
                }
            }
        }
        L_counter+=1;
        space_counter+=1;
        
        printf("\n");


        /*2/2*/
        space_outside_hexagon=single_hexagon_width_line-4;
        //printf("DEBUG: now_space=%d\n",now_space);
        //printf("space_pair_in:%d\n",space_pair_in_hexagon_counter);
        //printf("slash_pair_in:%d\n",slash_pair_in_hexagon_counter);
        for(int j=0;j<L-2;j++){
            //printf("j=%d\n",j);
            int32_t temp_slash_pair_in_hexagon_counter=slash_pair_in_hexagon_counter;
            int32_t temp_space_pair_in_hexagon=space_pair_in_hexagon_counter;
            now_space--;
            for(int k=0;k<now_space;k++){
                printf(" ");
            }
            
            while(temp_space_pair_in_hexagon>0||temp_slash_pair_in_hexagon_counter>0){
                //printf("\ntemp_space_pair_in_hexagon=%d\n",temp_space_pair_in_hexagon);
                //printf("\ntemp_slash_pair_in_hexagon_counter=%d\n",temp_slash_pair_in_hexagon_counter);
                if(temp_slash_pair_in_hexagon_counter>0){
                    temp_slash_pair_in_hexagon_counter--;
                    printf("/");
                    for(int k=0;k<space_in_hexagon;k++){
                        printf(" ");
                    }
                    printf("\\");
                }
                if(temp_space_pair_in_hexagon>0){
                    temp_space_pair_in_hexagon--;
                    for(int k=0;k<space_outside_hexagon;k++){
                        printf(" ");
                    }
                }
            }
            printf("\n");
            space_in_hexagon+=2;
            space_outside_hexagon-=2;
        }
        now_space-=L;
        slash_pair_in_hexagon_counter++;
        space_pair_in_hexagon_counter++;
    }

    //Second part
    for(int i=0;i<N-1;i++){
        int32_t temp_L_counter=(N-1);
        int32_t temp_space_counter=N;

        /*1/4*/
        printf("*");
        while(temp_space_counter>0||temp_L_counter>0){
            if(temp_space_counter>0){
                temp_space_counter--;
                for(int k=0;k<single_hexagon_width_line-2;k++){
                    printf(" ");
                }
            }
            if(temp_L_counter>0){
                temp_L_counter--;
                printf("*");
                for(int k=0;k<L-2;k++){
                    printf("-");
                }
                printf("*");
            }
            
        }
        printf("*\n");

        /*2/4*/
        now_space=1;
        space_in_hexagon=single_hexagon_width_line-4;
        space_outside_hexagon=L;
        for(int j=0;j<L-2;j++){
            //printf("j=%d\n",j);
            int32_t temp_slash_pair_in_hexagon_counter=N;
            int32_t temp_space_pair_in_hexagon=N-1;
            
            for(int k=0;k<now_space;k++){
                printf(" ");
            }
            
            while(temp_space_pair_in_hexagon>0||temp_slash_pair_in_hexagon_counter>0){
                //printf("\ntemp_space_pair_in_hexagon=%d\n",temp_space_pair_in_hexagon);
                //printf("\ntemp_slash_pair_in_hexagon_counter=%d\n",temp_slash_pair_in_hexagon_counter);
                if(temp_slash_pair_in_hexagon_counter>0){
                    temp_slash_pair_in_hexagon_counter--;
                    printf("\\");
                    for(int k=0;k<space_in_hexagon;k++){
                        printf(" ");
                    }
                    printf("/");
                }
                if(temp_space_pair_in_hexagon>0){
                    temp_space_pair_in_hexagon--;
                    for(int k=0;k<space_outside_hexagon;k++){
                        printf(" ");
                    }
                }
            }
            printf("\n");
            space_in_hexagon-=2;
            space_outside_hexagon+=2;
            now_space++;
        }

        /*3/4*/
        for(int j=0;j<L-1;j++){
            printf(" ");
        }
        temp_L_counter=N;
        temp_space_counter=N-1;
        while(temp_space_counter>0||temp_L_counter>0){
            if(temp_L_counter>0){
                temp_L_counter--;
                printf("*");
                for(int k=0;k<L-2;k++){
                    printf("-");
                }
                printf("*");
            }
            if(temp_space_counter>0){
                temp_space_counter--;
                for(int k=0;k<single_hexagon_width_line-2;k++){
                    printf(" ");
                }
            }
        }
        printf("\n");


        /*4/4*/
        now_space--;
        space_in_hexagon=L;
        space_outside_hexagon=single_hexagon_width_line-4;
        for(int j=0;j<L-2;j++){
            //printf("j=%d\n",j);
            int32_t temp_slash_pair_in_hexagon_counter=N;
            int32_t temp_space_pair_in_hexagon=N-1;
            
            for(int k=0;k<now_space;k++){
                printf(" ");
            }
            
            while(temp_space_pair_in_hexagon>0||temp_slash_pair_in_hexagon_counter>0){
                //printf("\ntemp_space_pair_in_hexagon=%d\n",temp_space_pair_in_hexagon);
                //printf("\ntemp_slash_pair_in_hexagon_counter=%d\n",temp_slash_pair_in_hexagon_counter);
                if(temp_slash_pair_in_hexagon_counter>0){
                    temp_slash_pair_in_hexagon_counter--;
                    printf("/");
                    for(int k=0;k<space_in_hexagon;k++){
                        printf(" ");
                    }
                    printf("\\");
                }
                if(temp_space_pair_in_hexagon>0){
                    temp_space_pair_in_hexagon--;
                    for(int k=0;k<space_outside_hexagon;k++){
                        printf(" ");
                    }
                }
            }
            printf("\n");
            space_in_hexagon+=2;
            space_outside_hexagon-=2;
            now_space--;
        }
    }
    int32_t temp_L_counter=(N-1);
    int32_t temp_space_counter=N;

    /*4/4*/
    printf("*");
    while(temp_space_counter>0||temp_L_counter>0){
        if(temp_space_counter>0){
            temp_space_counter--;
            for(int k=0;k<single_hexagon_width_line-2;k++){
                printf(" ");
            }
        }
        if(temp_L_counter>0){
            temp_L_counter--;
            printf("*");
            for(int k=0;k<L-2;k++){
                printf("-");
            }
            printf("*");
        }
        
    }
    printf("*\n");

    //Third part

    L_counter=N; //
    space_counter=N-1;//
    slash_pair_in_hexagon_counter=N;
    space_pair_in_hexagon_counter=N-1;

    now_space=0;
    space_in_hexagon=single_hexagon_width_line-4;
    space_outside_hexagon=L;
    
    for(int i=0;i<N;i++){
        /*1/2*/
        space_in_hexagon=single_hexagon_width_line-4;
        space_outside_hexagon=L;
        //printf("DEBUG: now_space=%d\n",now_space);
        //printf("space_pair_in:%d\n",space_pair_in_hexagon_counter);
        //printf("slash_pair_in:%d\n",slash_pair_in_hexagon_counter);
        for(int j=0;j<L-2;j++){
            //printf("j=%d\n",j);
            int32_t temp_slash_pair_in_hexagon_counter=slash_pair_in_hexagon_counter;
            int32_t temp_space_pair_in_hexagon=space_pair_in_hexagon_counter;
            now_space++;
            for(int k=0;k<now_space;k++){
                printf(" ");
            }
            
            while(temp_space_pair_in_hexagon>0||temp_slash_pair_in_hexagon_counter>0){
                //printf("\ntemp_space_pair_in_hexagon=%d\n",temp_space_pair_in_hexagon);
                //printf("\ntemp_slash_pair_in_hexagon_counter=%d\n",temp_slash_pair_in_hexagon_counter);
                if(temp_slash_pair_in_hexagon_counter>0){
                    temp_slash_pair_in_hexagon_counter--;
                    printf("\\");
                    for(int k=0;k<space_in_hexagon;k++){
                        printf(" ");
                    }
                    printf("/");
                }
                if(temp_space_pair_in_hexagon>0){
                    temp_space_pair_in_hexagon--;
                    for(int k=0;k<space_outside_hexagon;k++){
                        printf(" ");
                    }
                }
            }
            printf("\n");
            space_in_hexagon-=2;
            space_outside_hexagon+=2;
        }
        now_space++;
        slash_pair_in_hexagon_counter--;
        space_pair_in_hexagon_counter--;



        /*2/2*/
        temp_L_counter=L_counter;
        temp_space_counter=space_counter;

        space_in_hexagon=L;

        for(int j=0;j<now_space;j++){
            printf(" ");
        }
        //printf("temp_space_counter=%d\n",temp_space_counter);
        //printf("temp_L_counter=%d\n",temp_L_counter);
        while(temp_space_counter>0||temp_L_counter>0){
            
            if(temp_L_counter>0){
                temp_L_counter--;
                printf("*");
                for(int k=0;k<L-2;k++){
                    printf("-");
                }
                printf("*");
            }
            if(temp_space_counter>0){
                temp_space_counter--;
                for(int k=0;k<single_hexagon_width_line-2;k++){
                    printf(" ");
                }
            }
        }
        L_counter-=1;
        space_counter-=1;
        now_space+=L-1;
        printf("\n");

    }
    return 0;
}