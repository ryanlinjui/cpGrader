#include <stdio.h>
#include <stdint.h>
#include <math.h>

int is_end_date_late(int start_year, int start_month, int end_year, int end_month) {
    if (end_year > start_year || (end_year == start_year && end_month >= start_month + 1)) {
        return 1;
    } else {
        return 0;
    }
}

int main(){
    int32_t Initial_Investment;
    int32_t Recurring_Monthly_Investment;
    int32_t Start_Month;
    int32_t Start_Year;
    int32_t End_Month;
    int32_t End_Year;
    int32_t Annual_Rate_of_Return;

    printf("Initial Investment:           ");
    scanf("%d", &Initial_Investment);
    if(Initial_Investment<1||Initial_Investment>10000000){
        printf("Invalid Input.\n");
        return 0;
    }
    printf("Recurring Monthly Investment: ");
    scanf("%d", &Recurring_Monthly_Investment);
    if(Recurring_Monthly_Investment<0||Recurring_Monthly_Investment>10000000){
        printf("Invalid Input.\n");
        return 0;
    }
    printf("Start Month:                  ");
    scanf("%d", &Start_Month);
    if(Start_Month<1||Start_Month>12){
        printf("Invalid Input.\n");
        return 0;
    }
    printf("Start Year:                   ");
    scanf("%d", &Start_Year);
    if(Start_Year<1||Start_Year>10000){
        printf("Invalid Input.\n");
        return 0;
    }
    printf("End Month:                    ");
    scanf("%d", &End_Month);
    if(End_Month<1||End_Month>12){
        printf("Invalid Input.\n");
        return 0;
    }
    printf("End Year:                     ");
    scanf("%d", &End_Year);
    if(End_Year<1||End_Year>10000){
        printf("Invalid Input.\n");
        return 0;
    }
    printf("Annual Rate of Return (%%):    ");
    scanf("%d", &Annual_Rate_of_Return);
    if(Annual_Rate_of_Return<1||Annual_Rate_of_Return>100){
        printf("Invalid Input.\n");
        return 0;
    }
    if(is_end_date_late(Start_Year, Start_Month, End_Year, End_Month)==0){
        printf("The date is invalid\n");
        return 0;
    }

    printf("--- Output ---\n");

    long double total_invested = Initial_Investment;
    long double total_value = Initial_Investment;
    int32_t net_income;
    int32_t current_month = Start_Month;
    int32_t current_year = Start_Year;
    

    while (current_year < End_Year || (current_year == End_Year && current_month <= End_Month-1)) {

        net_income=total_value-total_invested;
        long double net_income_double = (double)net_income;
        long double total_value_double = (double)total_value;
        long double rate_of_return = net_income_double/total_value_double;
        rate_of_return*=100;
        //rate_of_return = 2.59000001;
        if(current_month < 10){
            if (rate_of_return == 0.0) {
                printf("%d.0%d) %d/%d/%d/0%%\n", current_year, current_month, (int)total_invested, (int)total_value, net_income);
            } else {
                printf("%d.0%d) %d/%d/%d/%g%%\n", current_year, current_month, (int)total_invested, (int)total_value, net_income, round(rate_of_return * 100) / 100.0);
            }
        } else {
            if (rate_of_return == 0.0) {
                printf("%d.%d) %d/%d/%d/0%%\n", current_year, current_month, (int)total_invested, (int)total_value, net_income);
            } else {
                printf("%d.%d) %d/%d/%d/%g%%\n", current_year, current_month, (int)total_invested, (int)total_value, net_income, round(rate_of_return * 100) / 100.0);
            }
        }
        total_invested += (double)Recurring_Monthly_Investment;
        total_value += total_value * (double)Annual_Rate_of_Return / 1200;
        total_value+=(double)Recurring_Monthly_Investment;
        //printf("DEBUG: %Lf\n", rate_of_return);

        current_month++;
        if (current_month > 12) {
            current_month = 1;
            current_year++;
        }
    }

    return 0;
}