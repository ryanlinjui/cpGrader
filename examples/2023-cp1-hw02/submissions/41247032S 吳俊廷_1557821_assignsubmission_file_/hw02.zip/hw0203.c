#include <stdio.h>
#include <stdint.h>
int64_t input=-1;
int64_t S0=1;
int64_t S1=0;
int64_t S2=0;
int64_t S3=0;
int64_t S4=0;
int64_t S5=0;
int64_t S6=0;

int64_t S0_temp=0;
int64_t S1_temp=0;
int64_t S2_temp=0;
int64_t S3_temp=0;
int64_t S4_temp=0;
int64_t S5_temp=0;
int64_t S6_temp=0;

void debug(){
    printf("S0: %ld\n",S0);
    printf("S1: %ld\n",S1);
    printf("S2: %ld\n",S2);
    printf("S3: %ld\n",S3);
    printf("S4: %ld\n",S4);
    printf("S5: %ld\n",S5);
    printf("S6: %ld\n",S6);
    printf("S0_temp: %ld\n",S0_temp);
    printf("S1_temp: %ld\n",S1_temp);
    printf("S2_temp: %ld\n",S2_temp);
    printf("S3_temp: %ld\n",S3_temp);
    printf("S4_temp: %ld\n",S4_temp);
    printf("S5_temp: %ld\n",S5_temp);
    printf("S6_temp: %ld\n",S6_temp);

}

void check(int64_t input_number){
    int64_t number_status=input_number%2; //0->even 1->odd
    if(S0>0){
        S0-=1;
        if(number_status==1){
            S1_temp=1;
            S2_temp=1;
        }else{
            S3_temp=1;
        }
    }
    if(S1>0){
        S1-=1;
        if(number_status==1){
            S2_temp=1; 
        }else{
            S4_temp=1;
        }
    }
    if(S2>0){
        S2-=1;
        if(number_status==1){
            S3_temp=1;
        }else{
            S5_temp=1;
        }
    }
    if(S3>0){
        S3-=1;
        if(number_status==1){
            S5_temp=1;
        }else{
            S0_temp=1;
        }
    }
    if(S4>0){
        S4-=1;
        if(number_status==1){
            S5_temp=1;
        }else{
            S6_temp=1;
            S2_temp=1;
        }
    }
    if(S5>0){
        S5-=1;
        if(number_status==1){
            S6_temp=1;
        }else{
            S0_temp=1;
        }
    }
    if(S6>0){
        S6-=1;
        if(number_status==0){
            S1_temp=1;
        }else{
            S6_temp=1;
        }
    }

    //migrate
    S0+=S0_temp;
    S0_temp=0;
    S1+=S1_temp;
    S1_temp=0;
    S2+=S2_temp;
    S2_temp=0;
    S3+=S3_temp;
    S3_temp=0;
    S4+=S4_temp;
    S4_temp=0;
    S5+=S5_temp;
    S5_temp=0;
    S6+=S6_temp;
    S6_temp=0;

}

void ans(){
    //count total;
    int total=0;
    if(S0>0){
        total+=1;
    }
    if(S1>0){
        total+=1;
    }
    if(S2>0){
        total+=1;
    }
    if(S3>0){
        total+=1;
    }
    if(S4>0){
        total+=1;
    }
    if(S5>0){
        total+=1;
    }
    if(S6>0){
        total+=1;
    }
    printf("Possible States: ");
    if(S0>0){
        printf("S0");
        if(total>1){
            printf(", ");
            total--;
        }
    }
    

    if(S1>0){
        printf("S1");
        if(total>1){
            printf(", ");
            total--;
        }
    }

    if(S2>0){
        printf("S2");
        if(total>1){
            printf(", ");
            total--;
        }
    }

    if(S3>0){
        printf("S3");
        if(total>1){
            printf(", ");
            total--;
        }
    }

    if(S4>0){
        printf("S4");
        if(total>1){
            printf(", ");
            total--;
        }
    }

    if(S5>0){
        printf("S5");
        if(total>1){
            printf(", ");
            total--;
        }
    }

    if(S6>0){
        printf("S6");
    }
    printf("\n");
    
}

int main(){
    while(input!=0){
        printf("Please enter an integer: ");
        scanf("%ld",&input);
        if(input==0){
            break;
        }

        check(input);
        
	    //ans();
        //debug();
    }
    ans();
    
    return 0;
}
