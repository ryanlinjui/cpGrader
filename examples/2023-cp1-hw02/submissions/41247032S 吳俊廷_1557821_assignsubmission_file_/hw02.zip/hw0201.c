#include <stdio.h>
#include <math.h>
#include <stdint.h>

unsigned long long input;
long double ans = 1;
long double sqrt_2=1.414213562373095048801;
int main() {
    printf("Please enter n (16-bits unsigned): ");
    scanf("%lld", &input);
    for (unsigned long long i = 1; i <= input; i++) {
        if(i != 1){
            ans = 1 + 1 / (1 + ans);
        }
        
        printf("n = %lld: %.15Lf (%.15Lf)\n", i, ans,ans-sqrt_2);
    }

    return 0;
}