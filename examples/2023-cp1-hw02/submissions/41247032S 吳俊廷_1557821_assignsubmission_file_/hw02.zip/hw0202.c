#include <stdio.h>
#include <stdint.h>
#include <math.h>
int32_t count_digit(uint64_t num){
    int32_t count = 0;
    do {
        ++count;
    } while (num /= 10);
    return count;
}
void print_digits(uint64_t num){
    if(num == 0){
        printf("0");
        return;
    }
    int32_t count = 0;
    uint64_t temp = num;
    while(temp != 0){
        temp /= 10;
        ++count;
    }
    while(count != 0){
        uint64_t divisor = pow(10, count - 1);
        uint64_t digit = num / divisor;
        printf("%lu", digit);
        if(count!=1){
            printf(" ");
        }
        num %= divisor;
        --count;
    }
}
void printline(int32_t max_digits){
    for(int i=0;i<max_digits*2+1;i++){
        printf("-");
    }
    printf("\n");
}
uint32_t get_ith_digit(uint32_t num, int32_t i){
    uint32_t divisor = 1;
    for(int32_t j = 0; j < i; ++j){
        divisor *= 10;
    }
    return (num / divisor) % 10;
}


uint64_t final_ans;
int32_t max_digits=-1;
int main() {
    int64_t a, b;
    printf("Please enter the first  number: ");
    scanf("%lu", &a);
    if(a<0||a>2147483647){
        printf("Wrong input, your input must between 0 ~ 2147483647.\n");
        return 0;
    }
    printf("Please enter the second number: ");
    scanf("%lu", &b);
    if(b<0||b>2147483647){
        printf("Wrong input, your input must between 0 ~ 2147483647.\n");
        return 0;
    }

    final_ans=a*b;
    max_digits=fmax(max_digits,count_digit(a));
    max_digits=fmax(max_digits,count_digit(b));
    max_digits=fmax(max_digits,count_digit(final_ans));
    //printf("DEBUG: max_digits: %d\n",max_digits);
    //printf("DEBUG: count_digit(a): %d\n",count_digit(a));
    //printf("DEBUG: count_digit(b): %d\n",count_digit(b));

    /*Upper part*/
    int32_t left_space=(max_digits-count_digit(a))*2;
    //printf("DEBUG: left space: %d\n",left_space);
    printf("  ");
    
    for(int32_t i=0;i<left_space;i++){
        printf(" ");
    }
    print_digits(a);
    printf("\n");
    printf("*)");

    left_space=(max_digits-count_digit(b))*2;
    for(int32_t i=0;i<left_space;i++){
        printf(" ");
    }
    print_digits(b);
    printf("\n");
    printline(max_digits);

    /*Middle part*/
    if(a!=0&&b!=0&&count_digit(b)!=1){
        int32_t shift=0;
        for(int i=0;i<count_digit(b);i++){
            printf("  ");
            uint64_t layer_ans=get_ith_digit(b,i)*a;
            left_space=(max_digits-count_digit(layer_ans))*2;
            for(int32_t i=0;i<left_space-shift;i++){
                printf(" ");
            }
            print_digits(layer_ans);
            printf("\n");
            shift+=2;
        }
        printline(max_digits);
    }
    /*Final part*/
    left_space=(max_digits-count_digit(final_ans))*2;
    //printf("DEBUG: left space: %d\n",left_space);
    printf("  ");
    
    for(int32_t i=0;i<left_space;i++){
        printf(" ");
    }
    //printf("%lu",final_ans);
    print_digits(final_ans);
    printf("\n");

    return 0;
}