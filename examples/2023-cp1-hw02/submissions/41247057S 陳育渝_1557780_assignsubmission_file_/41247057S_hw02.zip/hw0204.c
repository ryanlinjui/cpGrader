#include <stdio.h>
#include <stdint.h>
#include <math.h>

int main ()
{
	int64_t ii = 0;
	int64_t rmi = 0;
	int64_t sm = 0;
	int64_t sy = 0;
	int64_t em = 0;
	int64_t ey = 0;
	int64_t totomoney = 0;
	int64_t aror = 0;
	double rate = 0; //月利率
	double back = 0; //利息
	printf("Initial Investment:           ");
	scanf("%lld", &ii);
	if (ii >= 1 && ii <= 10000000){
	}
	else{
		printf("error\n");
		return 0;
	}
	printf("Recurring Monthly Investment: ");
	scanf("%lld", &rmi);
	if (rmi >= 0 && rmi <= 10000000){
	}
	else{
		printf("error\n");
		return 0;
	}
	printf("Start Month:                  ");
	scanf("%lld", &sm);
	if (sm >= 1 && sm <= 12){
	}
	else{
		printf("not found this month:(\n");
		return 0;
	}
	printf("Start Year:                   ");
	scanf("%lld", &sy);
	if (sy >= 1 && sy <= 10000){
	}
	else{
		printf("not found this year:(\n");
		return 0;
	}
	printf("End Month:                    ");
	scanf("%lld", &em);
	if (em >= 1 && em <= 12){
	}
	else{
		printf("not found this month:(\n");
		return 0;
	}
	printf("End Year:                     ");
	scanf("%lld", &ey);
	if (ey >= 1 && ey <= 10000){
	}
	else{
		printf("not found this year:(\n");
		return 0;
	}
	if ( ey == sy && em == sm ){
                printf("you should invest at least 1 month = =\n");
		return 0;
	}
	printf("Annual Rate of Return (%%):    ");
	scanf("%lld", &aror);
	if (aror >= 1 && aror <= 100){
	}
	else{
		printf("please input ""percentage""!\n");
		return 0;
	}

	int64_t totomo = 0;
	totomo = 12 * ( ey - sy ) + ( em - sm );
	rate = aror / 1200.0; // 先算月利率
	totomoney = ii;
	
	printf("--- Output ---\n");

	if ( sm >= 10 ){
		printf("%lld.%lld) %lld/%lld/0/0%%\n", sy, sm, ii, ii);
	}
	else if (sm < 10 ){
		printf("%lld.0%lld) %lld/%lld/0/0%%\n", sy, sm, ii, ii);
	}

	for (int64_t i = 1; i < totomo; i++){
		if ( (sm + i) % 12 == 0){
			printf("%lld.", sy + (sm + i) / 12 - 1);
		}
		else{
			printf("%lld.", sy + (sm + i) / 12);
		}
		if ( (sm + i ) % 12 == 0 ){
			printf("12) ");
		}
		else if ( (sm + i ) % 12 == 11 || (sm + i ) % 12 == 10){
			printf("%lld) ", (sm + i) % 12);
		}
		else{
			printf("0%lld) ", (sm + i) % 12 );
		}

		ii = ii + rmi;
		back = totomoney * rate;
		back = floor (back); // 無條件捨去
		int64_t totoback = totoback + back; //累積淨收入
		totomoney = ii + totoback;
		//累積本金
		if ( totomoney >= 1000000000000000 || totomoney < 0){
			printf("*/*/*/*%%\n");
			continue;
		}
		else{
			printf("%lld/", ii);
		}
		//累積總金額
		printf("%lld/", totomoney);
		//累積淨收入
		printf("%lld/", totoback );
		//投資報酬率
		if ( (int) ( round ( (double) totoback / (double) totomoney * 1000000 / 100 ) ) % 100 == 0){
			printf("%.0lf%%", (double) totoback / (double) totomoney * 100);
		}
		else if ( (int) ( round ( (double) totoback / (double) totomoney * 1000000 / 100 ) ) % 10 == 0 ){
			printf("%.1lf%%", (double) totoback / (double) totomoney * 100);
		}
		else{
		printf("%.2lf%%", ( (double) totoback / (double) totomoney ) * 100);
		}
		printf("\n");
	}
	return 0;
}
