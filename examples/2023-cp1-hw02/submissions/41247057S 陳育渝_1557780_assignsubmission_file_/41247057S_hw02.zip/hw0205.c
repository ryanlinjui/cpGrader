#include <stdio.h>
#include <stdint.h>

int main()
{
	int32_t n = 0;
	int32_t l = 0;

	printf("Please input the length: ");
	scanf("%d", &l);
	if (l < 3){
		printf("Length can't less than 3 :(\n");
		return 0;
	}
	printf("Please input the number of layer: ");
	scanf("%d", &n);
	if (n < 1){
		printf("Layer can't less than 1 :(\n");
		return 0;
	}
	if (n % 2 == 0 && 2 * n * l - l - 2 * n + 4 > 80){
		printf("The width of the map can't be larger than 80 :(\n");
		return 0;
	}
	else if (n % 2 == 1 && 2 * n * l - 4 * n - l + 2 > 80){
		printf("The width of the map can't be larger than 80 :(\n");
		return 0;
	}

	//一個六邊形
	if (n == 1){
		//直線
		printf(" ");
		for (int32_t i = 0; i < l - 2; i++){
			printf(" ");	
		}
		printf("*");
		for (int32_t i = 0; i < l - 2; i++){
			printf("-");
		}
		printf("*");
		printf("\n");
		//斜線
		for (int32_t i = 0; i < l - 2; i++){
			for (int32_t j = 1; j < l - 1 - i; j++){
				printf(" ");
			}
			printf("/");
			for (int32_t j = 0; j < l + i * 2; j++){
				printf(" ");
			}
			printf("\\");
			printf("\n");
		}
		//中間
		printf("*");
		for (int32_t i = 0; i < l + ( l - 2 ) * 2; i++){
			printf(" ");
		}
		printf("*");
		printf("\n");
		//下面
		for (int32_t i = l - 2; i >= 1; i--){
			for (int32_t j = 0; j < l - 1 - i; j++){
				printf(" ");
			}
			printf("\\");
			for (int32_t j = 0; j < l + ( i - 1 ) * 2; j++){
				printf(" ");
			}
			printf("/");
			printf("\n");
		}
		printf(" ");
		for (int32_t i = 0; i < l - 2; i++){
			printf(" ");
		}
		printf("*");
		for (int32_t i = 0; i < l - 2; i++){
			printf("-");
		}
		printf("*");
		printf("\n");
		return 0;
	}

	//上半部
	for (int32_t i = 0; i < n; i++){
		//直線
		for (int32_t j = l - 2; j > 0; j--){
			printf(" ");
		}
		for (int32_t j = n - 1; j > i; j--){
			for (int32_t k = 0; k < l - 2; k++){
				printf(" ");
			}
			for (int32_t k = l ; k >= l - 2; k--){
				printf(" ");
			}
		}
		printf(" ");
		for (int32_t k = 0; k <= i; k++){
			printf("*");
			for (int32_t j = 0; j < l - 2; j++){
				printf("-");
			}
			printf("*");
			for (int32_t j = 0; j < 3 * l - 4; j++){
				printf(" ");
			}
		}
		printf("\n");

		//斜線
		for (int32_t m = 0; m < l - 2; m++){
			printf(" ");
			for ( int32_t j = n - 1; j > i; j--){
				for (int32_t k = l - 2; k >= 1; k--){
					printf(" ");
				}
				for (int32_t k = l; k >= l - 2; k--){
					printf(" ");
				}
			}
			for (int32_t k = 0; k <= i; k++){
				printf("/");
				for (int32_t j = 0; j < l; j++){					
					printf(" ");
				}
				printf("\\");
				for (int32_t j = 0; j < l; j++){
					printf(" ");
				}
			}
			printf("\n");
		}
	}

	//中間的部分
	for (int32_t s = 0; s < n - 1; s++){
		printf("*");
		for (int32_t i = 0; i < n - 1; i++){
			for (int32_t j = 0; j < 3 * l - 4; j++){
				printf(" ");
			}
			printf("*");
			for (int32_t k = 0; k < l - 2; k++){
				printf("-");
			}
			printf("*");
		}
		for (int32_t j = 0; j < 3 * l - 4; j++){
			printf(" ");
		}
		printf("*");
		printf("\n");
		printf(" ");
		for (int32_t j = 0; j < n; j++){
			for (int32_t i = 0; i < l - 2; i++){
				printf("\\");
			}
			for (int32_t i = 0; i < l; i++){
				printf(" ");
			}
			for (int32_t i = 0; i < l - 2; i++){
				printf("/");
			}
			for (int32_t i = 0; i < l; i++){
				printf(" ");
			}
		}
		printf("\n");
		printf(" ");
                for (int32_t j = 0; j < l - 2; j++){
                        printf(" ");
                }
                for (int32_t i = 0; i <= n - 1; i++){
                        printf("*");
                        for (int32_t k = 0; k < l - 2; k++){
                                printf("-");
                        }
                        printf("*");
                        for (int32_t j = 0; j < 3 * l - 4; j++){
                                printf(" ");
                        }
                }
                for (int32_t j = 0; j < l - 2; j++){
                        printf(" ");
                }
                printf(" ");
                printf("\n");
		printf(" ");
                for (int32_t j = 0; j < n; j++){
                        for (int32_t i = 0; i < l - 2; i++){
                                printf("/");
                        }
                        for (int32_t i = 0; i < l; i++){
                                printf(" ");
                        }
                        for (int32_t i = 0; i < l - 2; i++){
                                printf("\\");
                        }
                        for (int32_t i = 0; i < l; i++){
                                printf(" ");
                        }
                }
                printf("\n");
	}
		printf("*");
                for (int32_t i = 0; i < n - 1; i++){
                        for (int32_t j = 0; j < 3 * l - 4; j++){
                                printf(" ");
                        }
                        printf("*");
                        for (int32_t k = 0; k < l - 2; k++){
                                printf("-");
                        }
                        printf("*");
                }
                for (int32_t j = 0; j < 3 * l - 4; j++){
                        printf(" ");
                }
                printf("*");
                printf("\n");


	//下半部
        for (int32_t i = n; i > 0; i--){
		//斜線
                for (int32_t j = 0; j < l - 2; j++){
                        printf(" ");
                }
                for ( int32_t j = i; j <= n - 1; j++){
                        printf(" ");
                        for (int32_t k = l; k >= l - 2; k--){
                                printf(" ");
                        }
                }
                //for (int32_t m = 0; m <
                        for (int32_t k = 0; k < i; k++){
                                printf("\\");
                                for (int32_t j = 0; j < l; j++){
                                        printf(" ");
                                }
                                printf("/");
                                for (int32_t j = 0; j < l; j++){
                                        printf(" ");
                                }
                        }
                printf("\n");
                //直線
                for (int32_t j = 0; j < l - 2; j++){
                        printf(" ");
                }
                for (int32_t j = n - 1; j >= i; j--){
                        for (int32_t k = 0; k < l - 2; k++){
                                printf(" ");
                        }
                        for (int32_t k = l ; k >= l - 2; k--){
                                printf(" ");
                        }
                }
                printf(" ");
                for (int32_t k = 0; k < i; k++){
                        printf("*");
                        for (int32_t j = 0; j < l - 2; j++){
                                printf("-");
                        }
                        printf("*");
                        for (int32_t j = 0; j < 3 * l - 4; j++){
                                printf(" ");
                        }
                }
                printf("\n");
	}

	return 0;
}
