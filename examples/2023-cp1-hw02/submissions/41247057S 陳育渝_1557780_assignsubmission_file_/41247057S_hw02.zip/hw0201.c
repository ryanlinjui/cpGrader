#include <stdio.h>
#include <stdint.h>

int main()
{
	int32_t n = 0;
	double number = 0;
	double sum = 0;
	double dif = 0;

	printf("Please enter n (16-bits unsigned): ");
	scanf( "%d", &n);

	printf(" n = 1: 1.000000000000000 (-0.414213562373095)\n");
	for (int32_t i = 2; i <= n; i++){
		number = 1.0 / (2 + number);
		sum = 1 + number;
		dif = sum - 1.414213562373095;
		printf(" n = %d: %.15lf (%.15lf) \n", i, sum, dif);
	}
	
	return 0;	
}
