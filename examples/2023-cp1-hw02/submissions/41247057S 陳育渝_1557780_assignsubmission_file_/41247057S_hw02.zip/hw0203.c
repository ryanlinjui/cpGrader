#include <stdio.h>
#include <stdint.h>

int main ()
{
	int32_t number = 1;
	int32_t s0 = 1;
	int32_t s1 = 0;
	int32_t s2 = 0;
	int32_t s3 = 0;
	int32_t s4 = 0;
	int32_t s5 = 0;
	int32_t s6 = 0;
	while (number != 0){
		printf("Please enter an integer: ");
		scanf("%d", &number);
		if (s0 == 1 && s1 == 0 && (number % 2 == 1 || number % 2 == -1) ){
			s1 = 1;
			s2 = 1;
			s0 = 0;
			continue;
		}
		else if (s0 == 1 && number % 2 == 0 && number != 0){
			s3 = 1;
			s0 = 0;
			continue;
		}
		else if (number == 0){
			break;
		}
		if (s1 == 1 && s2 == 1 && (number % 2 == 1 || number % 2 == -1) ){
			s3 = 1;
			s1 = 0;
			continue;
		}
		else if (s1 == 1 && (number % 2 == 1 || number % 2 == -1) ){
			s2 = 1;
			s1 = 0;
			continue;
		}
		else if (s1 == 1 && s2 == 0 && number % 2 == 0){
			s4 = 1;
			s1 = 0;
			continue;
		}
		else if (s1 == 1 && s2 == 1 && number % 2 == 0){
			s4 = 1;
			s5 = 1;
			s1 = 0;
			s2 = 0;
			continue;
		}
		else if (number == 0){
			break;
		}
		if (s2 == 1 && (number % 2 == 1 || number % 2 == -1) ){
			s3 = 1;
			s2 = 0;
			continue;
		}
		else if (s2 == 1 && number % 2 == 0){
			s5 = 1;
			s2 = 0;
			continue;
		}
		else if (number == 0){
			break;
		}
		if (s3 == 1 && (number % 2 == 1 || number % 2 == -1) ){
			s5 = 1;
			s3 = 0;
			continue;
		}
		else if (s3 == 1 && number % 2 == 0){
			s0 = 1;
			s3 = 0;
			continue;
		}
		else if (number == 0){
			break;
		}
		if (s4 == 1 && (number % 2 == 1 || number % 2 == -1) ){
			s5 = 1;
			s4 = 0;
			continue;
		}
		else if (s4 == 1 && number % 2 == 0){
			s2 = 1;
			s6 = 1;
			s4 = 0;
			continue;
		}
		else if (number == 0){
			break;
		}
		if (s5 == 1 && (number % 2 == 1 || number % 2 == -1) ){
			s6 = 1;
			s5 = 0;
			continue;
		}
		else if (s5 == 1 && number % 2 == 0){
			s0 = 1;
			s5 = 0;
			continue;
		}
		else if (number == 0){
			break;
		}
		if (s6 == 1 && (number % 2 == 1 || number % 2 == -1) ){
			s6 = 1;
			continue;
		}
		else if (s6 == 1 && number % 2 == 0){
			s1 = 1;
			s6 = 0;
			continue;
		}
		else if (number == 0){
			break;
		}
	}

	printf("Possible States: ");
	if (s0 == 1 && (s1 == 1 || s2 == 1 || s3 == 1 || s4 == 1 || s5 == 1 || s6 == 1)){
		printf("S0, ");
	}
	else if (s0 == 1){
		printf("S0");
	}
	if (s1 == 1 && (s2 == 1 || s3 == 1 || s4 == 1 || s5 == 1 || s6 == 1)){
		printf("S1, ");
	}
	else if (s1 == 1){
		printf("S1");
	}
	if (s2 == 1 && (s3 == 1 || s4 == 1 || s5 == 1 || s6 == 1)){	
		printf("S2, ");
	}
	else if (s2 == 1){
		printf("S2");
	}
	if (s3 == 1 && ( s4 == 1 || s5 == 1 || s6 == 1)){
		printf("S3, ");
	}
	else if (s3 == 1){
		printf("S3");
	}
	if (s4 == 1 && (s5 == 1 || s6 == 1)){
		printf("S4, ");
	}
	else if (s4 == 1){
		printf("S4");
	}
	if (s5 == 1 && s6 == 1){
		printf("S5, ");
	}
	else if (s5 == 1){
		printf("S5");
	}
	if (s6 == 1){
		printf("S6");
	}
	printf("\n");

	return 0;
}
