#include <stdio.h>
#include <stdint.h>

int main()
{
	int64_t a = -1;
	int64_t an = 0;
	int64_t b = -1;
	int64_t bn = 0;
	int64_t ans1 = 0;
	int64_t ans1n = 0;
	int64_t ans2 = 0;
	int64_t ans2n = 0;
	int64_t ans3 = 0;
	int64_t ans3n = 0;
	int64_t ans4 = 0;
	int64_t ans4n = 0;
	int64_t ans5 = 0;
	int64_t ans5n = 0;
	int64_t ans6 = 0;
	int64_t ans6n = 0;
	int64_t ans7 = 0;
	int64_t ans7n = 0;
	int64_t ans8 = 0;
	int64_t ans8n = 0;
	int64_t ans9 = 0;
	int64_t ans9n = 0;
	int64_t ans10 = 0;
	int64_t ans10n = 0;
	int64_t ansn = 0;
	int64_t ansnn = 0;
	while( a < 0 || a > 2147483648){
		printf("Please enter the first  number: ");
		scanf( "%lld", &a );
	}
	while( b < 0 || b > 2147483648){
		printf("Please enter the second number: ");
		scanf( "%lld", &b );
	}

	ans1 = a * (b % 10);
	ans2 = a * ( (b % 100) / 10);
	ans3 = a * ( (b % 1000) / 100 );
	ans4 = a * ( (b % 10000) / 1000 );
	ans5 = a * ( (b % 100000) / 10000 );
	ans6 = a * ( (b % 1000000) / 100000);
	ans7 = a * ( (b % 10000000) / 1000000);
	ans8 = a * ( (b % 100000000) / 10000000);
	ans9 = a * ( (b % 1000000000) / 100000000);
	ans10 = a * ( (b % 10000000000) / 1000000000);
	ansn = a * b;

	//找出有幾位數
	for (int64_t i = a; i != 0; an++){
		i = i / 10;
	}
	for (int64_t i = b; i != 0; bn++){
		i = i / 10;
	}
	for (int64_t i = ans1; i != 0; ans1n++){
		i = i / 10;
	}
	for (int64_t i = ans2; i != 0; ans2n++){
		i = i / 10;
	}
	for (int64_t i = ans3; i != 0; ans3n++){
		i = i / 10;
	}
	for (int64_t i = ans4; i != 0; ans4n++){
		i = i / 10;
	}
	for (int64_t i = ans5; i != 0; ans5n++){
		i = i / 10;
	}
	for (int64_t i = ans6; i != 0; ans6n++){
		i = i / 10;
	}
	for (int64_t i = ans7; i != 0; ans7n++){
		i = i / 10;
	}
	for (int64_t i = ans8; i != 0; ans8n++){
		i = i / 10;
	}
	for (int64_t i = ans9; i != 0; ans9n++){
		i = i / 10;
	}
	for (int64_t i = ans10; i != 0; ans10n++){
		i = i / 10;
	}
	for (int64_t i = ansn; i != 0; ansnn++){
		i = i / 10;
	}

	int64_t j = 10;

	//second number < 10
	if ( b < 10 && b != 0 ){
		printf("   ");
		for (int64_t i = ansnn - an; i > 0; i--){
			printf("  ");
		}
		j = 10;
		for (int64_t i = an - 1; i >= 1; i--){
			j = j * 10;
		}
		for (int64_t i = an - 1; i >= 1; i--){
			j = j / 10;
			printf("%lld ", (a % ( 10 * j )) / j);
		}
		printf("%lld", a % 10);
		printf("\n");
		printf("*) ");
		for (int64_t i = ansnn - bn; i > 0; i--){
			printf("  ");
		}
		printf("%lld", b);
		printf("\n");
		printf("--");
		for (int64_t i = 0; i < ansnn; i++){
			printf("--");
		}
		printf("\n");
		printf("   ");
		j = 10;
		for (int64_t i = ansnn - 1; i >= 1; i--){
			j = j * 10;
		}
		for (int64_t i = ansnn - 1; i >= 1; i--){
			j = j / 10;
			printf("%lld ", (ansn % (10 * j )) / j);
		}
		printf("%lld\n", ansn % 10);
		return 0;
	}

	//輸出有空格的數字
	if ( a == 0 ){
		printf("   ");
        	for (int64_t i = bn - an; i > 1; i--){
                printf("  ");
		}
		printf("0");
	}
	else{
		printf("   ");
		for (int64_t i = ansnn - an; i > 0; i--){
			printf("  ");
		}
		j = 10;
		for (int64_t i = an - 1; i >= 1; i--){
			j = j * 10;
		}
		for (int64_t i = an - 1; i >= 1; i--){
			j = j / 10;
			printf("%lld ", (a % (10 * j))/ j);
		}
		printf("%lld", a % 10);
	}

	//b
	printf("\n");
	printf("*) ");

	if ( b == 0 ){
                printf("  ");
                for (int64_t i = an - bn; i > 2; i--){
                printf("  ");
                }
                printf("0");
        }
	else{
		for (int64_t i = ansnn - bn; i > 0; i--){
			printf("  ");
		}

		j = 10;
		for (int64_t i = bn - 1; i >= 1; i--){
			j = j * 10;
		}
		for (int64_t i = bn - 1; i >= 1; i--){
			j = j / 10;
			printf("%lld ", (b % (10 * j )) / j);
		}
		printf("%lld", b % 10);
	}
	printf("\n");

	// if ansn = 0
	if ( an == 0 ){
		printf("--");
		for (int64_t i = 0; i < bn; i++){
			printf("--");
		}
		printf("\n");

		printf("   ");
                for (int64_t i = bn - ansnn; i > 1; i--){
                        printf("  ");
                }
		printf("0\n");
		return 0;
	}
	else if ( bn == 0 ){
		printf("--");
		for (int64_t i = 0; i < an; i++){
			printf("--");
		}
		printf("\n");

		printf("   ");
		for (int64_t i = an - ansnn; i > 1; i--){
			printf("  ");
		}
		printf("0\n");
		return 0;
	}

	//---
	printf("--");
	for (int64_t i = 0; i < ansnn; i++){
		printf("--");
	}
	printf("\n");

	//ans1
	printf("   ");
	if (ans1 == 0){
		for (int64_t i = ansnn - ans1n; i > 1; i--){
		printf("  ");
		}
	}
	else{
		for (int64_t i = ansnn - ans1n; i > 0; i--){
		printf("  ");
		}
	}
	j = 10;
	for (int64_t i = ans1n - 1; i >= 1; i--){
		j = j * 10;
	}
	for (int64_t i = ans1n - 1; i >= 1; i--){
		j = j / 10;
		printf("%lld ", (ans1 % (10 * j )) / j);
	}
	printf("%lld", ans1 % 10);
	printf("\n");

	//ans2
	if (ans2 == 0 && ( ans3 != 0 ||ans4 != 0 || ans5 != 0 || ans6 != 0 || ans7 != 0 || ans8 != 0 || ans9 != 0 || ans10 != 0)){
                printf("   ");
                for (int64_t i = ansnn - ans2n; i > 2; i--){
                        printf("  ");
                }
                printf("0\n");
        }
	else{
		printf("   ");
		for (int64_t i = ansnn - ans2n; i > 1; i--){
			printf("  ");
		}
		j = 10;
		for (int64_t i = ans2n - 1; i >= 1; i--){
			j = j * 10;
		}
		for (int64_t i = ans2n - 1; i >= 1; i--){
			j = j / 10;
			printf("%lld ", (ans2 % (10 * j )) / j);
		}
		printf("%lld", ans2 % 10);
		printf("\n");
	}

	//ans3
	if (ans3 != 0){
		printf("   ");
		for (int64_t i = ansnn - ans3n; i > 2; i--){
			printf("  ");
		}
		j = 10;
		for (int64_t i = ans3n - 1; i >= 1; i--){
			j = j * 10;
		}
		for (int64_t i = ans3n - 1; i >= 1; i--){
			j = j / 10;
			printf("%lld ", (ans3 % (10 * j )) / j);
		}
		printf("%lld", ans3 % 10);
		printf("\n");
	}
	else if ( ans4 != 0 || ans5 != 0 || ans6 != 0 || ans7 != 0 || ans8 != 0 || ans9 != 0){
		printf("   ");
                for (int64_t i = ansnn - ans3n; i > 3; i--){
                        printf("  ");
                }
		printf("0\n");
	}

	//ans4
        if (ans4 != 0){
                printf("   ");
                for (int64_t i = ansnn - ans4n; i > 3; i--){
                        printf("  ");
                }
                j = 10;
                for (int64_t i = ans4n - 1; i >= 1; i--){
                        j = j * 10;
                }
                for (int64_t i = ans4n - 1; i >= 1; i--){
                        j = j / 10;
                        printf("%lld ", (ans4 % (10 * j )) / j);
                }
                printf("%lld", ans4 % 10);
                printf("\n");
        }
	else if ( ans5 != 0 || ans6 != 0 || ans7 != 0 || ans8 != 0 || ans9 != 0){
                printf("   ");
                for (int64_t i = ansnn - ans4n; i > 4; i--){
                        printf("  ");
                }
                printf("0\n");
        }

	//ans5
        if (ans5 != 0){
                printf("   ");
                for (int64_t i = ansnn - ans5n; i > 4; i--){
                        printf("  ");
                }
                j = 10;
                for (int64_t i = ans5n - 1; i >= 1; i--){
                        j = j * 10;
                }
                for (int64_t i = ans5n - 1; i >= 1; i--){
                        j = j / 10;
                        printf("%lld ", (ans5 % (10 * j )) / j);
                }
                printf("%lld", ans5 % 10);
                printf("\n");
        }
	else if ( ans6 != 0 || ans7 != 0 || ans8 != 0 || ans9 != 0){
                printf("   ");
                for (int64_t i = ansnn - ans5n; i > 5; i--){
                        printf("  ");
                }
                printf("0\n");
        }

	//ans6
        if (ans6 != 0){
                printf("   ");
                for (int64_t i = ansnn - ans6n; i > 5; i--){
                        printf("  ");
                }
                j = 10;
                for (int64_t i = ans6n - 1; i >= 1; i--){
                        j = j * 10;
                }
                for (int64_t i = ans6n - 1; i >= 1; i--){
                        j = j / 10;
                        printf("%lld ", (ans6 % (10 * j )) / j);
                }
                printf("%lld", ans6 % 10);
                printf("\n");
        }
	else if ( ans7 != 0 || ans8 != 0 || ans9 != 0){
                printf("   ");
                for (int64_t i = ansnn - ans6n; i > 6; i--){
                        printf("  ");
                }
                printf("0\n");
        }

	//ans7
        if (ans7 != 0){
                printf("   ");
                for (int64_t i = ansnn - ans7n; i > 6; i--){
                        printf("  ");
                }
                j = 10;
                for (int64_t i = ans7n - 1; i >= 1; i--){
                        j = j * 10;
                }
                for (int64_t i = ans7n - 1; i >= 1; i--){
                        j = j / 10;
                        printf("%lld ", (ans7 % (10 * j )) / j);
                }
                printf("%lld", ans7 % 10);
                printf("\n");
        }
	else if ( ans8 != 0 || ans9 != 0){
                printf("   ");
                for (int64_t i = ansnn - ans7n; i > 7; i--){
                        printf("  ");
                }
                printf("0\n");
        }

	//ans8
        if (ans8 != 0){
                printf("   ");
                for (int64_t i = ansnn - ans8n; i > 7; i--){
                        printf("  ");
                }
                j = 10;
                for (int64_t i = ans8n - 1; i >= 1; i--){
                        j = j * 10;
                }
                for (int64_t i = ans8n - 1; i >= 1; i--){
                        j = j / 10;
                        printf("%lld ", (ans8 % (10 * j )) / j);
                }
                printf("%lld", ans8 % 10);
                printf("\n");
        }
	else if ( ans9 != 0){
                printf("   ");
                for (int64_t i = ansnn - ans8n; i > 8; i--){
                        printf("  ");
                }
                printf("0\n");
        }

	//ans9
        if (ans9 != 0){
                printf("   ");
                for (int64_t i = ansnn - ans9n; i > 8; i--){
                        printf("  ");
                }
                j = 10;
                for (int64_t i = ans9n - 1; i >= 1; i--){
                        j = j * 10;
                }
                for (int64_t i = ans9n - 1; i >= 1; i--){
                        j = j / 10;
                        printf("%lld ", (ans9 % (10 * j )) / j);
                }
                printf("%lld", ans9 % 10);
                printf("\n");
        }
	else if ( ans10 != 0){
                printf("   ");
                for (int64_t i = ansnn - ans9n; i > 9; i--){
                        printf("  ");
                }
                printf("0\n");
        }

	//ans10
        if (ans10 != 0){
                printf("   ");
                for (int64_t i = ansnn - ans10n; i > 9; i--){
                        printf("  ");
                }
                j = 10;
                for (int64_t i = ans10n - 1; i >= 1; i--){
                        j = j * 10;
                }
                for (int64_t i = ans10n - 1; i >= 1; i--){
                        j = j / 10;
                        printf("%lld ", (ans10 % (10 * j )) / j);
                }
                printf("%lld", ans10 % 10);
                printf("\n");
        }

	//---
	printf("--");
	for (int64_t i = 0; i < ansnn; i++){
		printf("--");
	}
	printf("\n");

	//ansn
	printf("   ");
	j = 10;
	for (int64_t i = ansnn - 1; i >= 1; i--){
		j = j * 10;
	}
	for (int64_t i = ansnn - 1; i >= 1; i--){
		j = j / 10;
		printf("%lld ", (ansn % (10 * j )) / j);
	}
	printf("%lld", ansn % 10);
	printf("\n");

	return 0;
}
