#include<stdio.h>
#include<stdint.h>

int main()
{
    int32_t a = 1;
    int32_t s0 = 1;
    int32_t s1 = 0;
    int32_t s2 = 0;
    int32_t s3 = 0;
    int32_t s4 = 0;
    int32_t s5 = 0;
    int32_t s6 = 0;
    int32_t t0 = 0;
    int32_t t1 = 0;
    int32_t t2 = 0;
    int32_t t3 = 0;
    int32_t t4 = 0;
    int32_t t5 = 0;
    int32_t t6 = 0;
    int32_t ans = 0;
    
    while ( a != 0 )
    {
        printf ("Please enter a integer: ");
        scanf ( "%d", &a );
        
        if ( a == 0 )
        {
            break;
        }
        
        if ( a < 0 )
        {
            a = -a;
        }
        
        int32_t b = 0;
        b = a%2 ;
        
        //calculate members
            
        //s0
        if ( s0 == 1 && b == 1 )
        {
            t1 = 1;
            t2 = 1;
            
            if ( t0 == 1 )
            {
                t0 = 1;
            }
            else
            {
                t0 = 0;
            }
                
        }
        else if ( s0 == 1 && b == 0 )
        {
            t3 = 1;
            
            if ( t0 == 1 )
            {
                t0 = 1;
            }
            else
            {
                t0 = 0;
            }
            
        }
            
        //s1
        if ( s1 == 1 && b == 1 )
        {
            t2 = 1;
            
            if ( t1 == 1 )
            {
                t1 = 1;
            }
            else
            {
                t1 = 0;
            }
            
        }
        else if ( s1 == 1 && b == 0 )
        {
            t4 = 1;
            
            if ( t1 == 1 )
            {
                t1 = 1;
            }
            else
            {
                t1 = 0;
            }
            
        }
            
        //s4
        if ( s4 == 1 && b == 1 )
        {
            t5 = 1;
            
            if ( t4 == 1 )
            {
                t4 = 1;
            }
            else
            {
                t4 = 0;
            }
            
        }
        else if ( s4 == 1 && b == 0 )
        {
            t2 = 1;
            t6 = 1;
            
            if ( t4 == 1 )
            {
                t4 = 1;
            }
            else
            {
                t4 = 0;
            }
            
        }
            
        //s2
        if ( s2 == 1 && b == 1 )
        {
            t3 = 1;
            
            if ( t2 == 1 )
            {
                t2 = 1;
            }
            else
            {
                t2 = 0;
            }
        
        }
        else if ( s2 == 1 && b == 0 )
        {
            t5 = 1;
            
            if ( t2 == 1 )
            {
                t2 = 1;
            }
            else
            {
                t2 = 0;
            }
            
        }
            
        //s3
        if ( s3 == 1 && b == 1 )
        {
            t5 = 1;
            
            if ( t3 == 1 )
            {
                t3 = 1;
            }
            else
            {
                t3 = 0;
            }
            
        }
        else if ( s3 == 1 && b == 0 )
        {
            t0 = 1;
            
            if ( t3 == 1 )
            {
                t3 = 1;
            }
            else
            {
                t3 = 0;
            }
            
        }
            
        //s5
        if ( s5 == 1 && b == 1 )
        {
            t6 = 1;
            
            if ( t5 == 1 )
            {
                t5 = 1;
            }
            else
            {
                t5 = 0;
            }
            
        }
        else if ( s5 == 1 && b == 0 )
        {
            t0 = 1;
            
            if ( t5 == 1 )
            {
                t5 = 1;
            }
            else
            {
                t5 = 0;
            }
            
        }
            
        //s6
        if ( s6 == 1 && b == 1 )
        {
            t6 = 1;
        }
        else if ( s6 == 1 && b == 0 )
        {
            t1 = 1;
            
            if ( t6 == 1 )
            {
                t6 = 1;
            }
            else
            {
                t6 = 0;
            }
            
        }
            
        //transmit value
        s0 = t0;
        s1 = t1;
        s2 = t2;
        s3 = t3;
        s4 = t4;
        s5 = t5;
        s6 = t6;
        
        //reset
        t0 = 0;
        t1 = 0;
        t2 = 0;
        t3 = 0;
        t4 = 0;
        t5 = 0;
        t6 = 0;
        
    }
    
    //print
    
    printf("Possible States:");
    
    if ( s0 == 1 )
    {
        if ( s1 == 1 || s2 == 1 || s3 == 1 || s4 == 1 || s5 == 1 || s6 == 1 )
        {
            printf (" S0,");
        }
        else
        {
            printf (" S0\n");
            return 0;
        }
    }
    if ( s1 == 1 )
    {
        if ( s2 == 1 || s3 == 1 || s4 == 1 || s5 == 1 || s6 == 1 )
        {
            printf (" S1,");
        }
        else
        {
            printf (" S1\n");
            return 0;
        }
    }
    if ( s2 == 1 )
    {
        if ( s3 == 1 || s4 == 1 || s5 == 1 || s6 == 1 )
        {
            printf (" S2,");
        }
        else
        {
            printf (" S2\n");
            return 0;
        }
    }
    if ( s3 == 1 )
    {
        if ( s4 == 1 || s5 == 1 || s6 == 1 )
        {
            printf (" S3,");
        }
        else
        {
            printf (" S3\n");
            return 0;
        }
    }
    if ( s4 == 1 )
    {
        if ( s5 == 1 || s6 == 1 )
        {
            printf (" S4,");
        }
        else
        {
            printf (" S4\n");
            return 0;
        }
    }
    if ( s5 == 1 )
    {
        if ( s6 == 1 )
        {
            printf (" S5, S6\n");
            return 0;
        }
        else
        {
            printf (" S5\n");
            return 0;
        }
    }
    if ( s6 == 1 )
    {
        printf (" S6\n");
        return 0;
    }   
}