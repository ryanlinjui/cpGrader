#include<stdio.h>
#include<stdint.h>
#include<math.h>

int main()
{
    int64_t scanfinitial = 0;
    double initial = 0;
    int64_t scanfrecurring = 0;
    double recurring = 0;
    int64_t startm = 0;
    int64_t starty = 0;
    int64_t endm = 0;
    int64_t endy = 0;
    int64_t ratey = 0;
    long double ratem = 0;
    int64_t total = 0;
    int64_t totalm = 0;
    int64_t printm = 0;
    long double returni = 0;
        
    //input
    printf("Initial Investment:           ");
    scanf( "%ld", &scanfinitial );
    printf("Recurring Monthly Investment: ");
    scanf( "%ld", &scanfrecurring );
    printf("Start Month:                  ");
    scanf( "%ld", &startm );
    printf("Start Year:                   ");
    scanf( "%ld", &starty );
    printf("End Month:                    ");
    scanf( "%ld", &endm );
    printf("End Year:                     ");
    scanf( "%ld", &endy );
    printf("Annual Rate of Return (%%):    ");
    scanf( "%ld", &ratey );
    
    initial = scanfinitial;
    recurring = scanfrecurring;
    
    long double totalmoney = initial; 
    
    //avoid idiot
    if ( initial < 1 || initial > 10000000 )
    {
        printf("Your input is out of range.\n");
        return 0;
    }  
    if ( recurring < 0 || recurring > 10000000 )
    {
        printf("Your input is out of range.\n");
        return 0;
    }
    if ( startm < 1 || startm > 12 )
    {
        printf("Your input is out of range.\n");
        return 0;
    }
    if ( starty < 1 || starty > 10000 )
    {
        printf("Your input is out of range.\n");
        return 0;
    }
    if ( endm < 1 || endm > 12 )
    {
        printf("Your input is out of range.\n");
        return 0;
    }
    if ( endy < 1 || endy > 10000 )
    {
        printf("Your input is out of range.\n");
        return 0;
    }
    if ( ratey < 1 || ratey > 100 )
    {
        printf("Your input is out of range.\n");
        return 0;
    }
    if ( endy < starty )
    {
        printf("Your input is wrong.\n");
        return 0;
    }
    if ( endy == starty && endm == startm )
    {
        printf("Your input is wrong.\n");
        return 0;
    }

     
    //output
    printf("--- Output ---\n");
    
    //total month
    if ( starty == endy )
    {
        totalm = endm-startm;
    }
    else if ( endm == startm )
    {
        totalm = (endy-starty)*12;    
    }
    else
    {
        totalm = (endy-starty)*12 + endm - startm;
    }
    
    int64_t minus = 0;
    int64_t returncount = 0; 
    returncount = returni*10000;
    long double returnprint = returni*100;
    double roundedPercentage = 0;
        
    //output
    for ( int i = 0 ; i <= totalm-1 ; i++ )
    {   
        if ( startm > 12 )
        {
            startm = 1;
            starty = starty+1;
        }
        
        if ( startm < 10 )
        {
            printf ("%ld.0%ld)", starty, startm);
        }
        else
        {
            printf ("%ld.%ld)", starty, startm);
        }
        
        startm = startm + 1;
        
        //except
        if ( initial >= 1000000000000000 || totalmoney >= 1000000000000000 || minus >= 1000000000000000 || initial < 0 || totalmoney < 0 || minus < 0 )
        {
            printf ("*/*/*/*/%%\n");
            continue;
        }

        
        //initial
        printf (" %ld", (int64_t)initial);
        initial = initial + recurring;
        
        //month rate
        ratem = ((double)ratey/12)*0.01;
        
        //totalmoney
        printf ("/%ld", (int64_t)totalmoney);
        totalmoney = totalmoney*ratem+recurring+totalmoney;
        
        //minus
        printf ("/%ld", (int64_t)minus);
        minus = totalmoney-initial;
        
        //return
        if ( returncount%100 == 0 )
        {
            printf ( "/%.0lf%%", (double) returni*100 );
        }
        else if ( returncount%10 == 0 )
        {
            printf ( "/%.1lf%%", (double) returni*100 );
        }
        else
        {
            printf ("/%.2lf%%", (double) returni*100 );
        }
        returni = (double) minus / (double) totalmoney;
        returncount = (double) returni*10000;
        returncount = round ( returncount );
        //double roundedPercentage = round(returni * 100.0 * 100.0) *0.01 ;
        //printf("/%.2lf%%", roundedPercentage);

        // returnprint = returni*100;
        
        
        printf ("\n");
        
        
        
        
    }





}