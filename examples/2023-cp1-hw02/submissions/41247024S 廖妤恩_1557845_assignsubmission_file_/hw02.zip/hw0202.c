#include<stdio.h>
#include<stdint.h>
#include<math.h>

int main()
{
    int64_t a = 0;
    int64_t b = 0;
    
    //power
    int64_t c = 0;
    
    //ans
    int64_t ans = 0;
    
    //space
    int64_t space = 0;
    
    //digits
    int64_t digitsa = 0;
    int64_t digitsb = 0;
    int64_t digitsans = 0;
    
    //input
    printf("Please enter the first number:");
    scanf("%ld", &a );
    printf("Please enter the second number:");
    scanf("%ld", &b );
    
    //avoid idiot
    if ( a<0 || b<0 || a>=pow(2,31) || b>=pow(2,31) )
    {
        printf("Wrong input, your input must between 0~2^31.\n");
        return 0;
    }
    
    ans = a*b;
    
    int64_t numa = a;
    int64_t numb = b;
    int64_t numans = ans;
    
    //calculate digits
    while ( numa != 0 )
    {
        numa = numa/10;
        digitsa++;
    }
    while ( numb != 0 )
    {
        numb = numb/10;
        digitsb++;
    }
    while ( numans != 0 )
    {
        numans = numans/10;
        digitsans++;
    } 
    
    //if0
    if ( ans==0 )
    {
        if ( a==0 && b==0 )
        {
            printf("  0\n");
            printf("*)0\n");
            printf("---\n");
            printf("  0\n");

            return 0;
        }
        else if ( a==0 )
        {
            int64_t totalspace = digitsb*2+2;
            
            //a
            for ( int i = 0 ; i < totalspace-2 ; i++ )
            {
                printf(" ");
            }
            printf (" 0\n");
            
            //b
            printf("*)");
            //take apart b      
            for ( int64_t powerb = digitsb-1 ; powerb >= 0 ; powerb-- )
            {
                int64_t divisor = 1;

                for ( int j = 0 ; j < powerb ; j++ )
                {
                    divisor = divisor*10;
                }

                printf (" %ld", (b/divisor)%10 );
            }
            printf("\n");
            
            //---
            for ( int i = 0 ; i < totalspace ; i++ )
            {
                printf("-");
            }
            printf("\n");
            
            //ans
            for ( int i = 0 ; i < totalspace-2 ; i++ )
            {
                printf(" ");
            }
            printf(" 0\n");
            
            return 0;
        }
        else
        {
            int64_t totalspace = digitsa*2+2;
            
            //a
            //space a 
            for ( int i = 0 ; i < totalspace-digitsa*2 ; i++ )
            {
                printf(" ");
            }

            //take apart a      
            for ( int64_t powera = digitsa-1 ; powera >= 0 ; powera-- )
            {
                int64_t divisor = 1;

                for ( int j = 0 ; j < powera ; j++ )
                {
                    divisor = divisor*10;
                }

                printf (" %ld", (a/divisor)%10 );
            }
            printf("\n");


            //b
            printf("*)");
            
            for ( int i = 0 ; i < totalspace-4 ; i++ )
            {
                printf(" ");
            }
            printf (" 0\n");

            //---
            for ( int i = 0 ; i < totalspace ; i++ )
            {
                printf("-");
            }
            printf("\n");
            
            //ans
            for ( int i = 0 ; i < totalspace-2 ; i++ )
            {
                printf(" ");
            }
            printf(" 0\n");

            return 0;

        }
    }
 
    //total space
    int64_t totalspace = digitsans*2+2;
    
    //space a 
    for ( int i = 0 ; i < totalspace-digitsa*2 ; i++ )
    {
        printf(" ");
    }
    
    //take apart a	
    for ( int64_t powera = digitsa-1 ; powera >= 0 ; powera-- )
    {
        int64_t divisor = 1;
        
        for ( int j = 0 ; j < powera ; j++ )
        {
            divisor = divisor*10;
        }
        
        printf (" %ld", (a/divisor)%10 );
    }
    printf("\n");
    
    //*)
    printf("*)");
    
    //space b 
    for ( int i = 0 ; i < totalspace-digitsb*2-2 ; i++ )
    {
        printf(" ");
    }
    
    //take apart b      
    for ( int64_t powerb = digitsb-1 ; powerb >= 0 ; powerb-- )
    {
        int64_t divisor = 1;
        
        for ( int j = 0 ; j < powerb ; j++ )
        {
            divisor = divisor*10;
        }
        
        printf (" %ld", (b/divisor)%10 );
    }
    printf("\n");
    
    //---
    for ( int i = 0 ; i < totalspace ; i++ )
    {
        printf("-");
    }
    printf("\n");
    
    if ( b<10 )
    {
        printf ("  ");
        
        for ( int64_t powerans = digitsans-1 ; powerans >= 0 ; powerans-- )
        {
            int64_t divisor = 1;
        
            for ( int j = 0 ; j < powerans ; j++ )
            {
                divisor = divisor*10;
            }
        
            printf (" %ld", (ans/divisor)%10 );
        }
        printf("\n");
    }
    else
    {
        int64_t multiplier = 0;
        
        multiplier = (b%10)*a;
        
        int64_t minusspace = 0;
    
            
        for ( int m = 0 ; m < digitsb ; m++ )
        {
            multiplier = (b%10)*a;
            b = b/10;
            
            int64_t nummulti = multiplier;
            int64_t digitsmulti = 0;

            //count multiplier's digits
            while ( nummulti != 0 )
            {
                nummulti = nummulti/10;
                digitsmulti++;
            }

            if ( multiplier == 0 )
            {
                int64_t multispace = 0;
            
                multispace = (digitsans-digitsmulti)*2-minusspace;
                minusspace = minusspace+2;
                           
                for ( int l = 0 ; l <= multispace-1 ; l++ )
                {
                    printf(" ");
                }
                
                printf(" 0\n");
            }
            else
            {
                //space
                int64_t multispace = 0;
            
                multispace = (digitsans-digitsmulti)*2-minusspace;
                minusspace = minusspace+2;
                           
                for ( int l = 0 ; l <= multispace+1 ; l++ )
                {
                    printf(" ");
                }	 
        
            
                //print multipiler
                for ( int k = digitsmulti-1 ; k >= 0 ; k-- )
                {
                    int64_t divisor = 1; 
                    
                    for ( int j = 0 ; j < k ; j++ )
                    {
                        divisor = divisor*10;
                    }	 	      

                    printf (" %ld", (multiplier/divisor)%10 );
                
                }
                
                printf("\n");
                
            }    
        }
        
        //---
        for ( int i = 0 ; i < totalspace ; i++ )
        {	
            printf("-");
        }
        printf("\n");
        
        //ans
        printf ("  ");

        for ( int64_t powerans = digitsans-1 ; powerans >= 0 ; powerans-- )
        {
            int64_t divisor = 1;
        
            for ( int j = 0 ; j < powerans ; j++ )
            {
                divisor = divisor*10;
            }
        
            printf (" %ld", (ans/divisor)%10 );
        }
        printf("\n");
    }  
    
}