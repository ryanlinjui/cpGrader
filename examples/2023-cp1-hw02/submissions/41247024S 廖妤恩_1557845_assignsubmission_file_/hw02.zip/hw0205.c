#include<stdio.h>
#include<stdint.h>

int main()
{
    int32_t length = 0;
    int32_t layer = 0;
    
    //input
    printf ("Please input the length: ");
    scanf ("%d", &length);
    printf ("Please input the number of layer: ");
    scanf ("%d", &layer);
    
    int32_t lengthcheck = length; 
    
    //avoid idiot
    if ( length < 3 )
    {
        printf("Wrong input, the number of length should be at least 3.\n");
        return 0;
    }
    if ( layer < 1 )
    {
        printf("Wrong input, the number of layer should be at least 1.\n");
        return 0;
    }
    if ( length*layer*2+(2*layer-1)*(length-2) > 80 )
    {
        printf("Wrong input, the width of the map must smaller than 80.\n");
        return 0;
    }
    
    //upper
    for ( int i = 0 ; i < layer ; i++ )
    {
        //space
        //int64_t space = ( layer*length ) + ( length-2 ) - i+1;
        int64_t space = ( layer*length ) + ( length-2 )*( layer-2 ) + ( length-3 );
        //space-i*(length+length-2)
        
        for ( int j = 0 ; j < space-i*(2*length-2) ; j++ )
        {
            printf (" ");
        }
        
        //line
        for ( int j = 0 ; j < i+1 ; j++ )
        {
            printf ("*");
            
            for ( int i = 0 ; i < length-2 ; i++ )
            {
                printf ("-");
            }
            
            printf ("*");
            
            for ( int i = 0 ; i < length+(length-2)*2 ; i++ )
            {
                printf (" ");
            }
        }
        
        printf ("\n");
        
        
        //divisor
        int64_t divisor = 0;
        
        //slash
        for ( int j = 0 ; j < length-2 ; j++ )
        {
            
            int64_t slashspace = ( layer*length ) + ( length-2 )*( layer-2 ) + ( length-3 );
            
            //space
            for ( int k = 0 ; k < slashspace-1-j-i*(2*length-2) ; k++ )
            {
                printf (" ");
            }
            
            //slash
            for ( int x = 0 ; x < 2*i+2 ; x++ )
            {
                if ( divisor%2 == 0 )
                {
                    printf ("/");
                    
                    for ( int i = 0 ; i < length+2*j ; i++)
                    {
                        printf (" ");
                    }
                
                }
                if ( divisor%2 == 1 )
                {
                    printf ("\\");

                    for ( int i = 0 ; i < 3*length-6-2*j ; i++)
                    {
                        printf (" ");
                    }
                    
                 }
                divisor = divisor+1;
            }
            printf("\n");
        }
    
    }

    //printf ("*");
    
    //mid
    int64_t divisor = 0;
    
    for ( int i = 0 ; i < layer-1 ; i++ )
    {
        //*-*
        
        printf ("*");
                
        //printf ("*");
        
        for ( int k = 0 ; k < layer-1 ; k++ )
        {
            //space
            for ( int j = 0 ; j < 3*length-4 ; j++ )
            {
                printf (" ");
            }
            
            printf ("*");
            
            for ( int j = 0 ; j < length-2 ; j++ )
            
            {
                printf ("-");
            }
            
            printf ("*");
            
        }
    
        for ( int j = 0 ; j < 3*length-4 ; j++ )
        {
            printf (" ");
        }
    
        printf ("*");
    
        printf ("\n");
    
        //slash
        for ( int j = length-2 ; j > 0 ; j-- )
        {
            
            int64_t slashspace = ( layer*length ) + ( length-2 )*( layer-2 ) + ( length-3 );
            
            //space
            for ( int k = slashspace-1-j-(layer-1)*(2*length-2)+1 ; k > 0 ; k-- )
            {
                printf (" ");
            }
            
            //slash
            for ( int x = 0 ; x < 2*layer ; x++ )
            {
                if ( divisor%2 == 0 )
                 {
                    printf ("\\");
                    
                    for ( int i = 0 ; i < length+2*j-2 ; i++ )
                    {
                        printf (" ");
                    }
                
                  }
                if ( divisor%2 == 1 )
                {
                    printf ("/");

                    for ( int i = 0 ; i < 3*length-4-2*j ; i++)
                    {
                        printf (" ");
                    }
                    
                 }
                divisor = divisor+1;
            }
            printf("\n");
         }   
            
            for ( int j = 0 ; j < length-1 ; j++ )
            {
                printf (" ");
            }
            
            //*-*
            for ( int k = 0 ; k < layer ; k++ )
            {
                printf ("*");

                for ( int q = 0 ; q < length-2 ; q++ )

                {
                    printf ("-");
                }

                printf ("*");
                
                for ( int q = 0 ; q < 3*length-4 ; q++ )
                {
                    printf (" ");
                }
                
            }
            
            printf ("\n");
            
            //slash
            for ( int j = 0 ; j < length-2 ; j++ )
            {

                int64_t slashspace = ( layer*length ) + ( length-2 )*( layer-2 ) + ( length-3 );

                //space
                for ( int k = 0 ; k < slashspace-1-j-(layer-1)*(2*length-2) ; k++ )
                {
                    printf (" ");
                }

                //slash
                for ( int x = 0 ; x < 2*layer ; x++ )
                {
                    if ( divisor%2 == 0 )
                    {
                        printf ("/");

                        for ( int i = length+2*j ; i > 0 ; i--)
                        {
                            printf (" ");
                        }

                    }
                    if ( divisor%2 == 1 )
                    {
                        printf ("\\");

                        for ( int i = 3*length-6-2*j ; i > 0 ; i--)
                        {
                            printf (" ");
                        }

                    }
                    divisor = divisor+1;
                }
                printf("\n");
            }
    }
    
    //*-*
    printf ("*");

    for ( int k = 0 ; k < layer-1 ; k++ )
    {
        //space
        for ( int j = 0 ; j < 3*length-4 ; j++ )
        {
            printf (" ");
        }

        printf ("*");

        for ( int j = 0 ; j < length-2 ; j++ )
        {
            printf ("-");
        }

        printf ("*");
    }
    
    for ( int j = 0 ; j < 3*length-4 ; j++ )
    {
        printf (" ");
    }

    printf ("*");
    printf ("\n");    
    
    //lower
    for ( int i = layer-1 ; i >= 0 ; i-- )
    {
        //space
        //int64_t space = ( layer*length ) + ( length-2 ) - i+1;
        int64_t space = ( layer*length ) + ( length-2 )*( layer-2 ) + ( length-3 );
        //space-i*(length+length-2)
        
        //divisor
        int64_t divisor = 0;

        //slash
        for ( int j = length-2 ; j > 0 ; j-- )
        {

            int64_t slashspace = ( layer*length ) + ( length-2 )*( layer-2 ) + ( length-3 );

            //space
            for ( int k = 0 ; k < slashspace-j-i*(2*length-2) ; k++ )
            {
                printf (" ");
            }

            //slash
            for ( int x = 0 ; x < 2*i+2 ; x++ )
            {
                if ( divisor%2 == 0 )
                {
                    printf ("\\");

                    for ( int i = 0 ; i < length+2*j-2 ; i++)
                    {
                        printf (" ");
                    }

                }
                if ( divisor%2 == 1 )
                {
                    printf ("/");

                    for ( int i = 0 ; i < 3*length-4-2*j ; i++)
                    {
                        printf (" ");
                    }

                 }
                divisor = divisor+1;
            }
            
            printf ("\n");
        
        }
        
        for ( int j = 0 ; j < space-i*(2*length-2) ; j++ )
        {
            printf (" ");
        }

        //line
        for ( int j = 0 ; j < i+1 ; j++ )
        {
            printf ("*");

            for ( int i = 0 ; i < length-2 ; i++ )
            {
                printf ("-");
            }

            printf ("*");

            for ( int i = 0 ; i < length+(length-2)*2 ; i++ )
            {
                printf (" ");
            }
        }

        printf ("\n");
    
    }







    
    
}

   
    



