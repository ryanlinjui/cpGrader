#include<stdio.h>
#include<stdint.h>
#include<math.h>

int main()
{
    int32_t n = 0;
    double ans = 1/2;
    double minus = 0;
    
    //input
    printf("please enter n (16-bits unsigned): ");
    scanf("%d", &n);
    
    //avoid idiot
    if ( n<1 )
    {
    	printf("Wrong input, please input again.\n");
    	return 0;
    }
    
    //n=1
    printf ("n = 1: 1.000000000000000 (-0.414213562373095)\n");
     
    //calculate
    for ( int32_t i = n ; i > 2 ; i-- )
    {
         for ( int32_t j = 2 ; j <= n ; j++ )
         {
         	ans = 1 / ( ans + 2 );
         	minus = ans-sqrt(2.0);
         	printf( "n = %d: %.15lf (%.15lf) \n", j, ans+1, minus+1 );
         }
         
         break;
          
    }
}