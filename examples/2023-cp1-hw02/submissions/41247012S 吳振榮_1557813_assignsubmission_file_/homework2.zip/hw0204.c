#include <stdio.h>
#include <stdint.h>
int main(){
    int32_t sm, sy, em, ey;
    int64_t init_inves, month_inves;
    double rate;
    printf("Initial Investment:           ");
    scanf("%lld", &init_inves);
    printf("Recurring Monthly Investment: ");
    scanf("%lld", &month_inves);
    printf("Start Month:                  ");
    scanf("%d", &sm);
    printf("Start Year:                   ");
    scanf("%d", &sy);
    printf("End Month:                    ");
    scanf("%d", &em);
    printf("End Year:                     ");
    scanf("%d", &ey);
    printf("Annual Rate of Return (%%):    ");
    scanf("%lf", &rate);
    printf("--- Output ---\n");
    if(init_inves < 1 || init_inves > 1e7){
        printf("Invalid Inputs. Invalid Initial Investment.\n");
        return 0;
    }
    else if(month_inves < 1 || month_inves > 1e7){
        printf("Invalid Inputs. Invalid Recurring Monthly Investment.\n");
        return 0;
    }
    else if(sm <= 0 || sm > 12){
        printf("Invalid Inputs. Invalid Start Month.\n");
        return 0;
    }
    else if(em <= 0 || em > 12){
        printf("Invalid Inputs. Invalid End Month.\n");
        return 0;
    }
    else if(sy < 1 || sy > 1e4){
        printf("Invalid Inputs. Invalid Start Year.\n");
        return 0;
    }
    else if(ey < 1 || ey > 1e4){
        printf("Invalid Inputs. Invalid End Year.\n");
        return 0;
    }
    else if(rate < 1 || rate > 100){
        printf("Invalid Inputs. Invalid Rate.\n");
        return 0;
    }
    else if(sy > ey){
        printf("Invalid Inputs. Invalid End Year.\n");
        return 0;
    }
    else if(sy == ey && sm > em){
        printf("Invalid Inputs. Invalid End Month.\n");
        return 0;
    }
    rate /= 12;
    rate /= 100;
    int32_t judge = 0;
    int64_t principal = init_inves;
    double total = init_inves;
    if(sy == ey){
        for(int32_t year = sy;year <= ey;year++){
            for(int32_t month = sm;month <= em;month++){
                double tmp = ((double)(total - principal) / (double)total) * 10000;
                if(((int64_t)(tmp * 10)) % 10 >= 5) tmp += (double)1.0;
                if(month < 10){
                    if(judge){
                        printf("%d.0%d) */*/*/*%%\n", year, month);
                    }
                    else if(principal >= (int64_t)1e15 || total >= (int64_t)1e15){
                        printf("%d.0%d) */*/*/*%%\n", year, month);
                        judge = 1;
                    }
                    else if((int64_t)tmp % 100 == 0)
                        printf("%d.0%d) %lld/%lld/%lld/%.0lf%%\n", year, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                    else if((int64_t)tmp % 10 == 0 || ((int64_t)(tmp * 10) % 10 >= 5 && (int64_t)tmp % 10 == 9))
                        printf("%d.0%d) %lld/%lld/%lld/%.1lf%%\n", year, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                    else
                        printf("%d.0%d) %lld/%lld/%lld/%.2lf%%\n", year, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                } 
                else{
                    if(judge){
                        printf("%d.%d) */*/*/*%%\n", year, month);
                    }
                    else if(principal >= (int64_t)1e15 || total >= (int64_t)1e15){
                        printf("%d.%d) */*/*/*%%\n", year, month);
                        judge = 1;
                    }
                    else if((int64_t)tmp % 100 == 0)
                        printf("%d.%d) %lld/%lld/%lld/%.0lf%%\n", year, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                    else if((int64_t)tmp % 10 == 0 || ((int64_t)(tmp * 10) % 10 >= 5 && (int64_t)tmp % 10 == 9))
                        printf("%d.%d) %lld/%lld/%lld/%.1lf%%\n", year, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);    
                    else
                        printf("%d.%d) %lld/%lld/%lld/%.2lf%%\n", year, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                }
                total = ((rate * total) + total);
                total += month_inves;
                principal += month_inves;
            }
        }
    }
    else{
        for(int32_t month = sm;month <= 12;month++){
            double tmp = ((double)(total - principal) / (double)total) * 10000;
            if(((int64_t)(tmp * 10)) % 10 >= 5) tmp += (double)1.0;
            if(month < 10){
                if(judge){
                    printf("%d.0%d) */*/*/*%%\n", sy, month);
                }
                else if(principal >= (int64_t)1e15 || total >= (int64_t)1e15){
                    printf("%d.0%d) */*/*/*%%\n", sy, month);
                    judge = 1;
                }
                else if((int64_t)tmp % 100 == 0)
                    printf("%d.0%d) %lld/%lld/%lld/%.0lf%%\n", sy, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                else if((int64_t)tmp % 10 == 0 || ((int64_t)(tmp * 10) % 10 >= 5 && (int64_t)tmp % 10 == 9))
                    printf("%d.0%d) %lld/%lld/%lld/%.1lf%%\n", sy, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                else
                    printf("%d.0%d) %lld/%lld/%lld/%.2lf%%\n", sy, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
            }
            else{
                if(judge){
                    printf("%d.%d) */*/*/*%%\n", sy, month);
                }
                else if(principal >= (int64_t)1e15 || total >= (int64_t)1e15){
                    printf("%d.%d) */*/*/*%%\n", sy, month);
                    judge = 1;
                }
                else if((int64_t)tmp % 100 == 0)
                    printf("%d.%d) %lld/%lld/%lld/%.0lf%%\n", sy, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                else if((int64_t)tmp % 10 == 0 || ((int64_t)(tmp * 10) % 10 >= 5 && (int64_t)tmp % 10 == 9))
                    printf("%d.%d) %lld/%lld/%lld/%.1lf%%\n", sy, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                else
                    printf("%d.%d) %lld/%lld/%lld/%.2lf%%\n", sy, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
            }
            double temp = ((rate * total) + total);
            total = temp;
            total += month_inves;
            principal += month_inves;
        }
        for(int32_t year = sy + 1;year < ey;year++){
            for(int32_t month = 1;month <= 12;month++){
                double tmp = ((double)(total - principal) / (double)total) * 10000;
                if(((int64_t)(tmp * 10)) % 10 >= 5) tmp += (double)1.0;
                if(month < 10){
                    if(judge){
                        printf("%d.0%d) */*/*/*%%\n", year, month);
                    }
                    else if(principal >= 1e15 || total >= 1e15){
                        printf("%d.0%d) */*/*/*%%\n", year, month);
                        judge = 1;
                    }
                    else if((int64_t)tmp % 100 == 0)
                        printf("%d.0%d) %lld/%lld/%lld/%.0lf%%\n", year, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                    else if((int64_t)tmp % 10 == 0 || ((int64_t)(tmp * 10) % 10 >= 5 && (int64_t)tmp % 10 == 9))
                        printf("%d.0%d) %lld/%lld/%lld/%.1lf%%\n", year, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                    else
                        printf("%d.0%d) %lld/%lld/%lld/%.2lf%%\n", year, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                }
                else{
                    if(judge){
                        printf("%d.%d) */*/*/*%%\n", year, month);
                    }
                    else if(principal >= (int64_t)1e15 || total >= (int64_t)1e15){
                        printf("%d.%d) */*/*/*%%\n", year, month);
                        judge = 1;
                    }
                    else if((int64_t)tmp % 100 == 0)
                        printf("%d.%d) %lld/%lld/%lld/%.0lf%%\n", year, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                    else if((int64_t)tmp % 10 == 0 || ((int64_t)(tmp * 10) % 10 >= 5 && (int64_t)tmp % 10 == 9))
                        printf("%d.%d) %lld/%lld/%lld/%.1lf%%\n", year, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                    else
                        printf("%d.%d) %lld/%lld/%lld/%.2lf%%\n", year, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                }
                total = ((rate * total) + total);
                total += month_inves;
                principal += month_inves;
            }
        }
        for(int32_t month = 1;month < em;month++){
            double tmp = ((double)(total - principal) / (double)total) * 10000;
            if(((int64_t)(tmp * 10)) % 10 >= 5) tmp += (double)1.0;
            if(month < 10){
                if(judge){
                    printf("%d.0%d) */*/*/*%%\n", ey, month);
                }
                else if(principal >= (int64_t)1e15 || total >= (int64_t)1e15){
                    printf("%d.0%d) */*/*/*%%\n", ey, month);
                    judge = 1;
                }
                else if((int64_t)tmp % 100 == 0)
                    printf("%d.0%d) %lld/%lld/%lld/%.0lf%%\n", ey, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                else if((int64_t)tmp % 10 == 0 || ((int64_t)(tmp * 10) % 10 >= 5 && (int64_t)tmp % 10 == 9))
                    printf("%d.0%d) %lld/%lld/%lld/%.1lf%%\n", ey, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                else
                    printf("%d.0%d) %lld/%lld/%lld/%.2lf%%\n", ey, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
            }
            else{
                if(judge){
                    printf("%d.%d) */*/*/*%%\n", ey, month);
                }
                else if(principal >= (int64_t)1e15 || total >= (int64_t)1e15){
                    printf("%d.%d) */*/*/*%%\n", ey, month);
                    judge = 1;
                }
                else if((int64_t)tmp % 100 == 0)
                    printf("%d.%d) %lld/%lld/%lld/%.0lf%%\n", ey, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                else if((int64_t)tmp % 10 == 0 || ((int64_t)(tmp * 10) % 10 >= 5 && (int64_t)tmp % 10 == 9))
                    printf("%d.%d) %lld/%lld/%lld/%.1lf%%\n", ey, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
                else
                    printf("%d.%d) %lld/%lld/%lld/%.2lf%%\n", ey, month, principal, (int64_t)total, (int64_t)total - principal, ((double)(total - principal) / (double)total) * 100);
            }
            total = ((rate * total) + total);
            total += month_inves;
            principal += month_inves;
        }
    }

    return 0;
}