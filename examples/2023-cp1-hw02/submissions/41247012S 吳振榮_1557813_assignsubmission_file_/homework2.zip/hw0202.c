#include <stdio.h>
#include <stdint.h>
int32_t digit(int64_t num){
    if(num == 0) return 1;
    int32_t cnt = 0;
    while(1){
        if(num / 10 != 0){
            cnt++;
            num /= 10;
        }
        else break;
    }
    cnt++;
    return cnt;
}
void print_space(int32_t dit, int32_t state, int32_t foundation){
    foundation = 3 + ((foundation - 1) * 2);
    state *= 2;
    for(int i = 0;i < foundation - (dit * 2) + 1 - state;i++){
        printf(" ");
    }
}
void print_dash(int32_t dit){
    printf("---");
    for(int i = 0;i < 2 * (dit - 1);i++){
        printf("-");
    }
    printf("\n");
}
void print_number(int64_t num){
    int64_t reverse_tmp = 0;
    int32_t dit = digit(num), judge = 1, cnt = 0;
    if(num == 0){
        printf("0\n");
        return;
    }
    while(num != 0){
        int64_t tmp = num % 10;
        if(tmp == 0 && judge) cnt++;
        else judge = 0;
        for(int i = 0;i < dit - 1;i++){
            tmp *= 10;
        }
        reverse_tmp += tmp;
        num /= 10;
        dit--;
    }
    while(reverse_tmp != 0){
        printf("%lld ", reverse_tmp % 10);
        reverse_tmp /= 10;
    }
    for(int i = 0;i < cnt;i++) printf("0 ");
    printf("\n");
}
int main(){
    int64_t a, b;
    printf("Please enter the first  number: ");
    scanf("%lld", &a);
    printf("Please enter the second number: ");
    scanf("%lld", &b);
    if(a >= 2147483648 || b >= 2147483648 || a < 0 || b < 0){
        printf("Invalid Inputs. Your input must be between 0 and 2^31.\n");
        return 0;
    }
    int64_t mul = a * b;
    int32_t cur = b % 10, cnt = 0, mul_digit = digit(mul);
    if(mul == 0){
        int32_t tmp_a = digit(a), tmp_b = digit(b);
        if(tmp_a >= tmp_b) mul_digit = tmp_a;
        else mul_digit = tmp_b;
    }
    print_space(digit(a), 0, mul_digit);
    print_number(a);
    printf("*)");
    print_space(digit(b), 1, mul_digit);
    print_number(b);
    int32_t digit_b = digit(b);
    print_dash(mul_digit);
    int64_t tmp_a = a;
    if(b == 0 || mul == 0){
        print_space(1, 0, mul_digit);
        print_number(0);
        return 0;
    }
    while(b != 0){
        int64_t product = a * cur;
        int32_t leng = digit(product);
        print_space(leng, cnt, mul_digit);
        print_number(product);
        b /= 10;
        cur = b % 10;
        cnt++;
    }
    if(digit_b == 1) return 0;
    if(a == 0){
        print_dash(mul_digit);
        print_space(1, 0, mul_digit);
        print_number(0);
        return 0;
    }
    print_dash(mul_digit);
    print_space(mul_digit, 0, mul_digit);
    print_number(mul);

    return 0;
}