#include <stdio.h>
#include <stdint.h>
void print_side(int32_t length, int32_t layer){
    printf("*");
    for(int32_t i = 1;i <= (length - 2);i++)
        printf("-");
    printf("*");
}
void print_upside(int32_t length, int32_t layer, int32_t increase){
    printf("/");
    for(int32_t i = 1;i <= length + increase;i++)
        printf(" ");
    printf("\\");
}
void print_space(int32_t length){
    for(int i = 1;i <= length;i++)
        printf(" ");
}
void print_downside(int32_t length, int32_t layer, int32_t decrease){
    printf("\\");
    for(int32_t i = 1;i <= decrease;i++)
        printf(" ");
    printf("/");
}
int main(){
    int32_t length, layer;
    printf("Please input the length: ");
    scanf("%d", &length);
    printf("Please input the number of layer: ");
    scanf("%d", &layer);
    if(length < 3){
        printf("Invalid Input. The length must greater than 3.\n");
        return 0;
    }
    else if(layer < 1){
        printf("Invalid Input. The layer must greater than 1.\n");
        return 0;
    }
    else if(((length * 3) - 2) * layer + ((layer - 1) * (length - 2)) > 80){
        printf("Invalid Input. The width of the map must be less than 80.\n");
        return 0;
    }
    int32_t origin = (length * layer) - 1 + ((length - 2) * (layer - 1)), minus = 0;
    for(int32_t i = 1;i <= layer;i++){
        print_space(origin - minus);
        for(int32_t j = 1;j <= i;j++){
            print_side(length, layer);
            print_space(length + ((length - 2) * 2));
        }
        printf("\n");
        int32_t first = (length * 3) - 4 - 2;
        for(int32_t k = 1;k <= length - 2;k++){
            print_space(origin - k - minus);
            for(int32_t j = 1;j <= i;j++){
                print_upside(length, layer, (k - 1) * 2);
                print_space(first);
            }
            first -= 2;
            printf("\n");
        }
        minus += ((length - 2) + length);
    }
    minus = 0;
    for(int32_t i = 1;i <= layer;i++){
        for(int32_t a = 1;a <= layer;a++){
            printf("*");
            print_space((length * 3) - 4);
            printf("*");
            if(a != layer){
                for(int32_t j = 1;j <= length - 2;j++)
                    printf("-");
            }
        }
        printf("\n");
        int32_t first = (length * 3) - 4;
        int32_t cnt = 1, level = 0;
        for(int32_t k = 1;k <= length - 2;k++){
            if(1 <= layer)
                print_space(cnt);
            for(int32_t j = 1;j <= layer;j++){
                print_downside(length, layer, first - cnt - 1 - level);
                print_space(length + cnt - 1 + level);
            }
            cnt++;
            level++;
            printf("\n");
        }
        print_space(length - 1);
        for(int k = 1;k <= layer;k++){
            print_side(length, layer);
            print_space(length + ((length - 2) * 2));
        }
        printf("\n");
        if(i == layer) continue;
        first = (length * 3) - 4 - 2;
        for(int32_t k = 1;k <= length - 2;k++){
            if(1 <= layer)
                print_space(length - 2 - k + 1);
            for(int32_t j = 1;j <= layer;j++){
                print_upside(length, layer, (k - 1) * 2);
                print_space(first);
            }
            first -= 2;
            printf("\n");
        }
        minus += ((length - 2) + length);
    }
    int32_t last = (2 * length) - 2;
    int32_t beg = (length * 3) - 4, cnt = 1, lev = 0, poi = 0, cur = 0, one = 0, judge = 0;
    for(int32_t out = layer;out >= 1;out--){
        judge = 0;
        cnt = 1;
        beg = (length * 3) - 4;
        lev = 0;
        for(int32_t i = 1;i <= length - 2;i++){
            if(0 < out - 1)
                print_space(last + cnt - (length - 1) * one);
            for(int32_t j = 0;j < out - 1;j++){
                judge = 1;
                print_downside(length, layer, beg - cnt - 1 - lev);
                print_space(length + cnt - 1 + lev);
            }
            cnt++;
            lev++;
            if(judge) printf("\n");
        }
        last = (length * 3) - 3;
        judge = 0;
        // printf("4");
        if(out != 1)
            print_space(last + length * poi + (length - 2) * poi);
        for(int32_t i = 0;i < out - 1;i++){
            print_side(length, layer);
            print_space(length + ((length - 2) * 2));
            judge = 1;
        }
        if(judge && out > 2) printf("\n");
        poi++;
        cur += ((length - 2) + length);
        last += cur;
        one = 1;
    }
    if(layer > 1) printf("\n");

    return 0;
}