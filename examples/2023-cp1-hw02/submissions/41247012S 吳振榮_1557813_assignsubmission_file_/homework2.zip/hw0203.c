#include <stdio.h>
#include <stdint.h>
int main(){
    printf("Please enter an integer: ");
    int64_t num;
    int32_t s0 = 1, s1 = 0, s2 = 0, s3 = 0, s4 = 0, s5 = 0, s6 = 0, tmp0 = 0, tmp1 = 0, tmp2 = 0, tmp3 = 0, tmp4 = 0, tmp5 = 0, tmp6 = 0;
    int32_t m0 = 0, m1 = 0, m2 = 0, m3 = 0, m4 = 0, m5 = 0, m6 = 0;
    while(scanf("%lld", &num) && num != 0){
        if(num > 2147483647){
            printf("Invalid Inputs. Your input must be a 32-bit integer.\n");
            return 0;
        }
        if(s0 && tmp0 == 0){
            if(!m0) s0 = 0;
            m0 = 0;
            if(num & 1){
                if(s1 == 0) tmp1 = 1;
                else m1 = 1;
                if(s2 == 0) tmp2 = 1;
                else m2 = 1;
                s1 = 1;
                s2 = 1;
            }
            else{
                if(s3 == 0) tmp3 = 1;
                else m3 = 1;
                s3 = 1;
            }
        }
        if(tmp0) tmp0 = 0;
        if(s1 && tmp1 == 0){
            if(!m1) s1 = 0;
            m1 = 0;
            if(num & 1){
                if(s2 == 0) tmp2 = 1;
                else m2 = 1;
                s2 = 1;
            }
            else{
                if(s4 == 0) tmp4 = 1;
                else m4 = 1;
                s4 = 1;
            }
        }
        if(tmp1) tmp1 = 0;
        if(s2 && tmp2 == 0){
            if(!m2) s2 = 0;
            m2 = 0;
            if(num & 1){
                if(s3 == 0) tmp3 = 1;
                else m3 = 1;
                s3 = 1;
            }
            else{
                if(s5 == 0) tmp5 = 1;
                else m5 = 1;
                s5 = 1;
            }
        }
        if(tmp2) tmp2 = 0;
        if(s3 && tmp3 == 0){
            if(!m3) s3 = 0;
            m3 = 0;
            if(num & 1){
                if(s5 == 0) tmp5 = 1;
                else m5 = 1;
                s5 = 1;
            }
            else{
                s0 = 1;
            }
        }
        if(tmp3) tmp3 = 0;
        if(s4 && tmp4 == 0){
            if(!m4) s4 = 0;
            m4 = 0;
            if(num & 1){
                if(s5 == 0) tmp5 = 1;
                else m5 = 1;
                s5 = 1;
            }
            else{
                if(s6 == 0) tmp6 = 1;
                s2 = 1;
                s6 = 1;
            }
        }
        if(tmp4) tmp4 = 0;
        if(s5 && tmp5 == 0){
            if(!m5) s5 = 0;
            m5 = 0;
            if(num & 1){
                if(s6 == 0) tmp6 = 1;
                else m6 = 1;
                s6 = 1;
            }
            else{
                s0 = 1;
            }
        }
        if(tmp5) tmp5 = 0;
        if(s6 && tmp6 == 0){
            if(!m6) s6 = 0;
            m6 = 0;
            if(num & 1){
                if(s6 == 0) tmp6 = 1;
                s6 = 1;
            }
            else{
                s1 = 1;
            }
        }
        if(tmp6) tmp6 = 0;
        m0 = 0, m1 = 0, m2 = 0, m3 = 0, m4 = 0, m5 = 0, m6 = 0;
        printf("Please enter an integer: ");
    }
    printf("Possible States: ");
    int32_t cnt = 0;
    if(s0){
        printf("S0");
        cnt = 1;
    }
    if(s1){
        if(cnt) printf(", ");
        printf("S1");
        cnt = 1;
    }
    if(s2){
        if(cnt) printf(", ");
        printf("S2");
        cnt = 1;
    }
    if(s3){
        if(cnt) printf(", ");
        printf("S3");
        cnt = 1;
    }
    if(s4){
        if(cnt) printf(", ");
        printf("S4");
        cnt = 1;
    }
    if(s5){
        if(cnt) printf(", ");
        printf("S5");
        cnt = 1;
    }
    if(s6){
        if(cnt) printf(", ");
        printf("S6");
        cnt = 1;
    }
    printf("\n");

    return 0;
}