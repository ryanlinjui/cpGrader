#include <stdio.h>
#include <stdint.h>
#include <math.h>
int main(){
    int32_t n = 0;
    printf("Please enter n (16-bits unsigned): ");
    scanf("%d", &n);
    if(n >= 65536 || n <= 0){
        printf("Invalid Input. Your input must be between 0 and 2^16.\n");
        return 0;
    }
    printf("n = %d: %.15lf (%.15lf)\n", 1, (double)1.0, ((double)1.0 - M_SQRT2));
    for(int32_t i = 2;i <= n;i++){
        long double cur = 0.0;
        for(int j = 2;j <= i;j++){
            cur += (long double)2.0;
            cur = (long double)1.0 / cur;
        }
        cur += (long double)1.0;
        printf("n = %d: %.15Lf (%.15Lf)\n", i, cur, (cur - M_SQRT2));
    }

    return 0;
}