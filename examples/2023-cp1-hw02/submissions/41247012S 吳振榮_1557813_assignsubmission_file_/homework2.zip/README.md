# Computer Programming I homework 2
## Author
- 我是資工系116級的吳振榮，學號是41247012S。

## Overview
台師大資工程式設計(一)第二次作業，共6道題目。

## Build and Run
Run `make` to compile my code.
```shell
$ make
```
After compiling the program, you can execute hw0201 code by entering `./hw0201` in the terminal, and the remaining programs follow the same pattern.
```shell
$ ./hw0201
$ ./hw0202
$ ./hw0203
$ ./hw0204
$ ./hw0205
```

## Errror Message in my homework
### hw0201
The user is asked to input a 16-bit positive integer. If the input is not within the range of 0 to $2^{16}$, an error message 'Invalid Input. Your input must be between 0 and $2^{16}$.' will be displayed.
### hw0202
The user is asked to input a 32-bit positive integer. If the input is not within the range of 0 to $2^{31}$, an error message <span style="color:red"><strong>Invalid Inputs. Your input must be between 0 and 2^31.</strong></span> will be displayed.
### hw0203
The user can input several 32-bit integers until they input 0 to stop. If the input is not within the range of 32-bit integers, an error message <span style="color:red"><strong>Invalid Inputs. Your input must be a 32-bit integer.</strong></span> will be displayed.
### hw0204
- The use is asked to input several number.
- If the numerical value of the input for Initial Investment is not within the range of 1 to $10^7$, an error message <span style="color:red"><strong>Invalid Inputs. Invalid Initial Investment.</strong></span> will be displayed.
- If the numerical value of the input for Month Investment is not within the range of 1 to $10^7$, an error message <span style="color:red"><strong>Invalid Inputs. Invalid Recurring Monthly Investment.</strong></span> will be displayed.
- If the numerical value of the input for Start Month is not within the range of 1 to 12, an error message <span style="color:red"><strong>Invalid Inputs. Invalid Start Month.</strong></span> will be displayed.
- If the numerical value of the input for Start Year is not within the range of 1 to $10^4$, an error message <span style="color:red"><strong>Invalid Inputs. Invalid Start Year.</strong></span> will be displayed.
- If the numerical value of the input for End Month is not within the range of 1 to 12, an error message <span style="color:red"><strong>Invalid Inputs. Invalid End Month.</strong></span> will be displayed.
- If the numerical value of the input for End Year is not within the range of 1 to $10^4$, an error message <span style="color:red"><strong>Invalid Inputs. Invalid End Year.</strong></span> will be displayed.
- If the numerical value of the input for Rate is not within the range of 1 to 100, an error message <span style="color:red"><strong>Invalid Inputs. Invalid Rate.</strong></span> will be displayed.
- If the input for End Year is greater than Start Year, an error message <span style="color:red"><strong>Invalid Inputs. Invalid End Year.</strong></span> will be displayed.
- If the input for End Month is equal to Start Month and End Month is greater than Start Month, an error message <span style="color:red"><strong>Invalid Inputs. Invalid End Month.</strong></span> will be displayed.
### hw0205
- The user is prompted to input two integers, length and layer. If the value of length is less than 3, an error message <span style="color:red"><strong>Invalid Input. The length must be greater than 3.</strong></span> will be displayed. If the value of layer is less than 1, an error message <span style="color:red"><strong>Invalid Input. The layer must be greater than 1.</strong></span> will be displayed.
## Something to notify TAs
None