#include <stdio.h>
#include <stdint.h>
int calculate_parity(int32_t value) {
    int parity = 0;
    while (value != 0) {
        parity ^= (value & 1);
        value >>= 1;
    }
    return parity;
}

uint64_t parity_2d(int32_t a, int32_t b, int32_t c, int32_t d, int32_t e){
    int parity_a = calculate_parity(a);
    int parity_b = calculate_parity(b);
    int parity_c = calculate_parity(c);
    int parity_d = calculate_parity(d);
    int parity_e = calculate_parity(e);
    int parity_combined = (parity_e << 4) | (parity_d << 3) | (parity_c << 2) | (parity_b << 1) | parity_a;
    uint64_t result = (uint64_t)parity_combined;
    result <<= 31;

    return result;
}