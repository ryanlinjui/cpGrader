#include <stdio.h>
#include <stdint.h>
// 平年1:2月28天        閏年0:2月29天
int32_t leap(int64_t y){
    if(y % 4 != 0) return 1;
    else{
        if(y % 100 != 0) return 0;
        else{
            if(y % 400 != 0) return 1;
            else return 0;
        }
    }
}
int main(){
    uint64_t syear, smonth, sday, shour, sminute, ssecond;
    uint64_t eyear, emonth, eday, ehour, eminute, esecond;
    printf("Start Time: ");
    scanf("%llu-%llu-%llu %llu:%llu:%llu", &syear, &smonth, &sday, &shour, &sminute, &ssecond);
    printf("End Time:   ");
    scanf("%llu-%llu-%llu %llu:%llu:%llu", &eyear, &emonth, &eday, &ehour, &eminute, &esecond);
    // printf("%lld %lld %lld %lld %lld %lld\n", syear, smonth, sday, shour, sminute, ssecond);
    uint64_t duration = 0;

    for (uint64_t year = syear; year <= eyear; year++){
        uint64_t sm = (year == syear) ? smonth : 1;
        uint64_t em = (year == eyear) ? emonth : 12;
        for(uint64_t month = sm;month <= em;month++){
            uint64_t sd = (year == syear && month == smonth) ? sday : 1;
            uint64_t ed = (year == eyear && month == emonth) ? eday : ((leap(year) ? 28 : 29));
            for(uint64_t day = sd;day <= ed;day++){
                uint64_t sh = (year == syear && month == smonth && day == sday) ? shour : 0;
                uint64_t eh = (year == eyear && month == emonth && day == eday) ? ehour : 23;
                for(uint64_t hour = sh;hour <= eh;hour++){
                    uint64_t smin = (year == syear && month == smonth && day == sday && hour == shour) ? sminute : 0;
                    uint64_t emin = (year == eyear && month == emonth && day == eday && hour == ehour) ? eminute : 59;
                    for(uint64_t minute = smin;minute <= emin;minute++){
                        uint64_t ss = (year == syear && month == smonth && day == sday && hour == shour && minute == sminute) ? ssecond : 0;
                        uint64_t es = (year == eyear && month == emonth && day == eday && hour == ehour && minute == eminute) ? esecond : 59;
                        for(uint64_t second = ss;second <= es;second++){
                            duration++;
                        }
                    }
                }
            }
        }
    }
    printf("Duration:   %llu sec\n", duration - 1);

    return 0;
}