#include <stdio.h>
#include <stdint.h>
static uint32_t girl_weight = 0;
static uint32_t boy_weight = 0;
static uint32_t girl_inp = 0, boy_inp = 0;
static int64_t first = 0;
void setup_girl_weight(uint32_t kg){
    girl_weight = kg;
    girl_inp = 1;
}
void setup_boy_weight(uint32_t kg){
    boy_weight = kg;
    boy_inp = 1;
}
int64_t afford_weight(int32_t x, int32_t y){
    if(x < 0 || y < 0 || !girl_inp || !boy_inp) return -1;
    if(x == 0) return 0;
    else if(x % 2){
        if(y == 0) 
            return ((afford_weight(x - 1, y) + girl_weight) / 2);
        else if(y == x)
            return ((afford_weight(x - 1, y - 1) + girl_weight) / 2);
        else 
            return ((afford_weight(x - 1, y - 1) + girl_weight) / 2) + ((afford_weight(x - 1, y) + girl_weight) / 2);
    }
    else{
        if(y == 0) 
            return ((afford_weight(x - 1, y) + boy_weight) / 2);
        else if(y == x)
            return ((afford_weight(x - 1, y - 1) + boy_weight) / 2);
        else 
            return ((afford_weight(x - 1, y - 1) + boy_weight) / 2) + ((afford_weight(x - 1, y) + boy_weight) / 2);
    }
}