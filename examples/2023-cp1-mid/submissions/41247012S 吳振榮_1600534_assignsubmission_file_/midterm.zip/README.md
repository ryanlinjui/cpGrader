# Computer Programming I Midterm
## Author
- 我是資工系116級的吳振榮，學號是41247012S。

## Overview
台師大資工程式設計(一)期中考，共5+1道題目。

## Build and Run
Run `make` to compile my code.
```shell
$ make
```
After compiling the program, you can execute mid01 code by entering `./mid01` in the terminal, and the remaining programs follow the same pattern.
```shell
$ ./mid01
$ ./mid02
$ ./mid03
$ ./mid04
$ ./mid05
```