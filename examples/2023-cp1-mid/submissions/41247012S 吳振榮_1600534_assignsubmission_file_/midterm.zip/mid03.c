#include <stdio.h>
#include <stdint.h>

int main() {
    int64_t input;
    int64_t state = 0;
    int64_t rule1 = 0;
    int64_t rule2 = 0;
    int64_t rule3 = 0;
    
    while (1) {
        printf("Please input the digit: ");
        scanf("%lld", &input);
        
        if (input == -1) {
            if(rule1 == 3 && rule2 == 1 && rule3 == 1){
                printf("SUCCESS!\n");
            } 
            else{
                if(rule1 != 3){
                    printf("Rule1 ");
                }
                if(rule2 != 1){
                    printf("Rule2 ");
                }
                if(rule3 != 1){
                    printf("Rule3 ");
                }
                printf("not follow!");
                printf("\n");
            }
            break;
        }
        
        if(input < 0 || input > 9){
            printf("Invalid input. Please enter a digit between 0 and 9.\n");
            break;
        }
        
        if(state == 0){
            if (input == 1) {
                state = 1;
                rule1 = 1;
            }
        }
        else if(state == 1){
            if (input == 6) {
                state = 2;
                rule1 = 2;
            }
        }
        else if(state == 2){
            if(input == 5){
                state = 3;
                rule1 = 3;
            }
        }
        else if(state == 3){
            if (input == 9 || input == 7) {
                state = 4;
            }
        }
        else if(state == 4){
            if (input == 7 || input == 3) {
                state = 5;
                rule2 = 1;
            }
        }
        else if(state == 5){
            if (input == 4) {
                state = 6;
                rule3 = 1;
            }
        }
        else if(state == 6){
            if(input == 6){
                state = 7;
            }
        }
        else if(state == 7){
            if(input == 6){
                state = 8;
            }
        }
        else if(state == 8){
            if(input == 8){
                state = 9;
            }
        }
    }
    
    return 0;
}