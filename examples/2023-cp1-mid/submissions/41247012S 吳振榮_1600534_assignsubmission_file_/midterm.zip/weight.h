#ifndef _WEIGHT_H_
#define _WEIGHT_H_
#include <stdio.h>
#include <stdint.h>
void setup_girl_weight(uint32_t kg);
void setup_boy_weight(uint32_t kg);
int64_t afford_weight(int32_t x, int32_t y);

#endif