#ifndef _PARITY_H_
#define _PARITY_H_
#include <stdio.h>
#include <stdint.h>
#include <math.h>
uint64_t parity_2d(int32_t a, int32_t b, int32_t c, int32_t d, int32_t e);
#endif