#include<stdio.h>
#include<stdint.h>

int main()
{
    //blue printf ("\033[44m \033[0m\n");
    //red printf ("\033[41m \033[0m\n");
    //green printf ("\033[42m \033[0m\n");
    
    int32_t length = 0;
    int32_t layer = 0;
    int32_t redrule = 0;
    int32_t bluerule = 0;
    int32_t greenrule = 0;
    
    //input
    printf ("Please enter n: ");
    scanf ("%d", &layer);
    printf ("Please enter the edge length: ");
    scanf ("%d", &length);
    
    redrule = layer % 3;
    greenrule = redrule + 1;
    bluerule = redrule + 2;
    
    if ( greenrule >= 3 )
    {
        greenrule = greenrule-3;
    }
    if ( bluerule >= 3 )
    {
        bluerule = bluerule-3;
    } 
    
    int32_t ncount1 = 1;
    int32_t ncount2 = 0;
    int32_t inverse = 0;
    
    //upper
    for ( int i = 0 ; i < layer ; i++ )
    {
        int32_t space = (length*2+1)*(layer-1);
        
        for ( int j = 0 ; j < space-i*(length*2+1) ; j++ )
        {
            printf (" ");
        }
        
        //line
        for ( int j = 0 ; j < 2*i+1 ; j++ )
        {
            printf ("+");
            
            for ( int i = 0 ; i < length*2 ; i++ )
            {
                printf ("-");
            }
            
        }
        
        printf ("+");
        printf ("\n");
        
        for ( int q = 0 ; q < length ; q++ )
        {
        
            for ( int j = 0 ; j < space-i*(length*2+1) ; j++ )
            {
                printf (" ");
            }
        
            ncount1 = 0;
                        
            for ( int k = 0 ; k < i+1 ; k++ )
            {
                
                printf ("|");

                for ( int l = 0 ; l < length*2 ; l++ )
                {
                    if ( ncount1%3 == 0 )
                    {
                        printf ("\033[41m \033[0m");
                    }
                    else if ( ncount1%3 == 1 )
                    {
                        printf ("\033[42m \033[0m");
                    }
                    else
                    {
                        printf ("\033[44m \033[0m");
                    }
                }
                
                ncount1 = ncount1 + 1;

            }
            
            ncount2 = ncount1-2;

            for ( int k = 0 ; k < i ; k++ )
            {

                printf ("|");

                for ( int l = 0 ; l < length*2 ; l++ )
                {
                    if ( ncount2%3 == 0 )
                    {
                        printf ("\033[41m \033[0m");
                    }
                    else if ( ncount2%3 == 1 )
                    {
                        printf ("\033[42m \033[0m");
                    }
                    else
                    {
                        printf ("\033[44m \033[0m");
                    }
                }

                ncount2 = ncount2 - 1;

            }
            
            
            printf ("|");
            printf ("\n");
        
        }    
    }
    
    //mid
    for ( int j = 0 ; j < layer*2-1 ; j++ )
    {
        printf ("+");

        for ( int i = 0 ; i < length*2 ; i++ )
        {
            printf ("-");
        }

    }

    printf ("+");
    printf ("\n");
    
    //lower
    for ( int i = layer-1 ; i > 0 ; i-- )
    {

        int32_t space = (length*2+1)*(layer-1);
        
        for ( int q = length-1 ; q>=0 ; q-- )
        {

            for ( int j = space - (i-1)*(2*length+1) - 1 ; j >= 0 ; j-- )
            {
                printf (" ");
            }

            ncount1 = 0;
            
            for ( int k = i-1 ; k >= 0 ; k-- )
            {
                printf ("|");

                for ( int l = length*2-1 ; l >= 0 ; l-- )
                {
                    if ( ncount1%3 == 0 )
                    {
                        printf ("\033[41m \033[0m");
                    }
                    else if ( ncount1%3 == 1 )
                    {
                        printf ("\033[42m \033[0m");
                    }
                    else
                    {
                        printf ("\033[44m \033[0m");
                    }
                }

                ncount1 = ncount1 + 1;

            }
            
            ncount2 = ncount1 - 2;
            
            for ( int k = i-2 ; k >= 0 ; k-- )
            {

                printf ("|");

                for ( int l = length*2-1 ; l >= 0 ; l-- )
                {
                    if ( ncount2%3 == 0 )
                    {
                        printf ("\033[41m \033[0m");
                    }
                    else if ( ncount2%3 == 1 )
                    {
                        printf ("\033[42m \033[0m");
                    }
                    else
                    {
                        printf ("\033[44m \033[0m");
                    }
                }

                ncount2 = ncount2 - 1;

            }

            printf ("|");
            printf ("\n");

        }
        
        for ( int j =  space - (i-1)*(2*length+1) - 1 ; j >= 0 ; j-- )
        {
            printf (" ");
        }
        
        //line
        for ( int j = 2*(i-1) ; j >= 0 ; j-- )
        {
            printf ("+");

            for ( int i = 0 ; i < length*2 ; i++ )
            {
                printf ("-");
            }

        }
        
        printf ("+");
        printf ("\n");
    
    
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}