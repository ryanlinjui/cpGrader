#include<stdio.h>
#include<stdint.h>

//int32_t ifrun1 ( int32_t year1 );
//int32_t ifrun2 ( int32_t year2 );
int32_t yearcount ( int32_t year1 , int32_t year2 );
static int32_t yearcount1 = 0;
static int32_t correctday1 = 0;
static int32_t correctday2 = 0;
static int32_t correctsecond1 = 0;
static int32_t correctsecond2 = 0; 
int32_t daycount1 ( int32_t year1 , int32_t month1 , int32_t day1 );
int32_t daycount2 ( int32_t year2 , int32_t month2 , int32_t day2 );

int main()
{
    int32_t year1 = 0;
    int32_t month1 = 0;
    int32_t day1 = 0;
    int32_t hour1 = 0;
    int32_t minute1 = 0;
    int32_t second1 = 0;
    int64_t all1 = 0;
    int32_t runcount = 0;
    
    int32_t year2 = 0;
    int32_t month2 = 0;
    int32_t day2 = 0;
    int32_t hour2 = 0;
    int32_t minute2 = 0;
    int32_t second2 = 0;
    int64_t all2 = 0;
    
    int64_t ans = 0;
    
    int32_t run = 0;
    
    
    //avoid idoit
    
    
    //input
    printf("Start Time: ");
    scanf( "%d-%d-%d %d:%d:%d", &year1, &month1, &day1, &hour1, &minute1, &second1 );
    printf("End Time:   ");
    scanf( "%d-%d-%d %d:%d:%d", &year2, &month2, &day2, &hour2, &minute2, &second2 );
    
    //calculate year
    yearcount ( year1, year2 );
    //printf ( "%d\n", yearcount1 );
    
    //calculate day1
    daycount1 ( year1, month1, day1 );
    //printf ( "%d\n", correctday1 );
    
    //calculate day2
    daycount2 ( year2, month2, day2 );
    //printf ( "%d\n", correctday2 ); 
    
    //calculate minus day
    int32_t minusday = 0;
    minusday = yearcount1 - correctday1 + correctday2;
    //printf ( "%d\n", minusday );
    
    //count daysecond 
    correctsecond1 = hour1*60*60 + minute1*60 + second1;
    //printf ( "%d\n", correctsecond1 );
    correctsecond2 = hour2*60*60 + minute2*60 + second2;
    //printf ( "%d\n", correctsecond2 );
    

    ans = minusday*24*3600 - correctsecond1 + correctsecond2;
    
    printf ( "Duration:   %ld sec\n", ans );
    
    return 0;
    
}

int32_t yearcount ( int32_t year1, int32_t year2 )
{
    for ( int i = year1 ; i < year2 ; i++ )
    {
        if ( ( i % 4 == 0 && i % 100 != 0 ) || i % 400 == 0 )
        {
            yearcount1 = yearcount1 + 366;
        }
        else
        {
            yearcount1 = yearcount1 + 365;
        }
    
    }
    
    return yearcount1;

}

int32_t daycount1 ( int32_t year1 , int32_t month1 , int32_t day1 )
{
    int daymonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    
    if ( ( year1 % 4 == 0 && year1 % 100 != 0 ) || year1 % 400 == 0 )
    {
        daymonth[2] = 29;
    }
    
    for ( int i = 0 ; i < month1 ; i++ )
    {
        correctday1 = correctday1 + daymonth[i];
    }
    
    correctday1 = correctday1 + day1;
    
    return correctday1;

}

int32_t daycount2 ( int32_t year2 , int32_t month2 , int32_t day2 )
{
    int daymonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    if ( ( year2 % 4 == 0 && year2 % 100 != 0 ) || year2 % 400 == 0 )
    {
        daymonth[2] = 29;
    }

    for ( int i = 0 ; i < month2 ; i++ )
    {
        correctday2 = correctday2 + daymonth[i];
    }

    correctday2 = correctday2 + day2;

    return correctday2;

}





