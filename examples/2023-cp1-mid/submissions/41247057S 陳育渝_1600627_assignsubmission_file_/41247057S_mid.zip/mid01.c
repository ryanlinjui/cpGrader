#include <stdio.h>
#include <stdint.h>

int main()
{
	int32_t sy = 0;
	int32_t sm = 0;
	int32_t sd = 0;
	int32_t sh = 0;
	int32_t smu = 0;
	int32_t ss = 0;
	int32_t ey = 0;
	int32_t em = 0;
	int32_t ed = 0;
	int32_t eh = 0;
	int32_t emu = 0;
	int32_t es = 0;
	int64_t d = 0;
	int64_t s = 0;

	printf("Start Time: ");
	scanf("%d-%d-%d %d:%d:%d", &sy, &sm, &sd, &sh, &smu, &ss);
	printf("End Time:   ");
	scanf("%d-%d-%d %d:%d:%d", &ey, &em, &ed, &eh, &emu, &es);

	//算中間經過了幾年（不包含起始和結束）
	for (int32_t i = sy + 1; ey > i; i++){
		if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0){
			d = d + 366;
		}
		else{
			d = d + 365;
		}
	}

	//算起始過了幾個月（不包含起始月）
	if (ey > sy){
		for (int32_t i = sm + 1; 12 >= i; i++){
			if ( i == 1 || i == 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12){
				d = d + 31;
			}
			else if ((( sy % 4 == 0 && sy % 100 != 0) || sy % 400 == 0) && i == 2){
				d = d + 29;
			}
			else if (i == 4 || i == 6 || i == 9 || i == 11){
				d = d + 30;
			}
			else{
				d = d + 28;
			}
		}
	}

	//算結束過了幾個月（不包含結束月）
	if (ey > sy){
		for (int32_t i = 0; i <= em; i++){
	       		if ( i == 1 || i == 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12){
                		d = d + 31;
                	}
               		else if ((( ey % 4 == 0 && ey % 100 != 0) || ey % 400 == 0) && i == 2){
              	        	d = d + 29;
             		}
               		else if (i == 4 || i == 6 || i == 9 || i == 11){
                     		d = d + 30;
               		}
               		else{
                	       	d = d + 28;
               		}
		}
	}

	//假如同年
	if (ey == sy){
		for (int32_t i = sm + 1; i < em; i++){
                        if ( i == 1 || i == 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12){
                                d = d + 31;
                        }
                        else if ((( ey % 4 == 0 && ey % 100 != 0) || ey % 400 == 0) && i == 2){
                                d = d + 29;
                        }
                        else if (i == 4 || i == 6 || i == 9 || i == 11){
                                d = d + 30;
                        }
                        else{
                                d = d + 28;
                        }
                }
	}
	
	//開始過了幾天（不包含當天）
	if ( ey >= sy && em > sm){
		if ( sm == 1 || sm == 3 || sm == 5 || sm == 7 || sm == 8 || sm == 10 || sm == 12){
        	                d = d + (31 - sd);
                	}
                	else if ((( sy % 4 == 0 && sy % 100 != 0) || sy % 400 == 0) && sm == 2){
                        	d = d + (29 - sd);
                	}
                	else if (sm == 4 || sm == 6 || sm == 9 || sm == 11){
                	        d = d + (30 - sd);
                	}
                	else{
                	        d = d + (28 - sd);
                	}
	}

	//結束過了幾天（不包含當天）
	if (ey >= sy && em > sm){
		d = d + ed - 1;
	}

	//假如同月
	if (ey == sy && em == sm){
		d = ed - sd;
	}

	//計算這些天有幾秒
	s = d * 86400;

	//計算第一天有幾秒
	if (ey >= sy && em > sm){
		s = s + (24 - sh - 1) * 3600;
		s = s + (60 - smu - 1) * 60;
		s = s + (60 - ss);
	}

	//計算最後一天有幾秒
	if (ey >= sy && em > sm){
		s = s + sh * 3600;
		s = s + smu * 60;
		s = s + ss;
	}

	//假如同一天
	if (es == ey && em == sm && ed == sd){
		s = s + (eh - sh - 1) * 3600;
		s = s + (emu - smu - 1) * 60;
		s = s + (es - ss);
	}

	printf("Duration:   %lld sec\n", s);

	return 0;
}
	

