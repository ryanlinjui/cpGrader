#include <stdio.h>
#include <stdint.h>

int32_t r1 (int32_t num);
int32_t r2 (int32_t num);
int32_t r3 (int32_t num);
int32_t a = 0;
int32_t b = 0;
int32_t c = 0;

int32_t r1 (int32_t num){
	if (a == 1){
		return 0;
	}
	if (num == 0){
		return 0;
	}
	int32_t i = 0;
	if (num == 1){
		i = 5;
	}
	if (i == 0 && num == 3){
		i++;
	}
	if (i == 1 && (num == 2)){
		i = 5;
	}
	else{
		return 0;
	}

	if (i == 5 && num == 6){
		i++;
	}
	if (i == 6 && num == 5){
		i = 10;
	}
	else{
		a = -1;
	}

	if (i == 10 && num == 9){
		a = 1;
	}
	if (i == 10 && num == 7){
		i++;
	}
	if (i == 11 && num == 8){
		a = 1;
	}
	else{
		a = -1;
	}
	return 0;
}

int32_t r2 (int32_t num){
	if (b == 1){
		return 0;
	}
	if (num == 0){
		return 0;
	}
	int32_t i = 0;
	if (num == 7){
		i = 1;
	}
	if (i == 1 && num == 5){
		i++;
	}
	if (i > 1){
		b = -1;
	}
	if (i == 1 && num == 3){
		b = 1;
	}
	else{
		b = -1;
	}
	return 0;
}

int32_t r3 (int32_t num){
	if (c == 1){
		return 0;
	}
	if (num == 0){
		return 0;
	}
	int32_t i = 0;
	if (num == 4){
		i = 1;
	}
	if (i == 1 && num == 6){
		i++;
	}
	if (i > 1 && num == 8){
		c = 1;
	}
	else{
		c = -1;
	}
	return 0;
}

int main()
{
	int32_t ans = 0;

	while (ans >= 0 && ans <= 9){
		printf("Please input the digit: ");
		scanf("%d", &ans);

		r1(ans);
		r2(ans);
		r3(ans);

		if (a == 1 && b == 1 && c == 1){
			printf("SUCCESS!\n");
			return 0;
		}
		else if ( a < 0 || b < 0 || c < 0){
			if (a < 0){
				printf("Rule1 ");
			}
			if (b < 0){
				printf("Rule2 ");
			}
			if (c < 0){
				printf("Rule3 ");
			}
			printf("not follow!\n");
			return 0;
		}
	}
}
