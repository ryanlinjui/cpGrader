#include <stdio.h>
#include <stdlib.h>
#include <time.h>



int is_leap_year(int year){
    if (year % 4 == 0){
        if (year % 100 == 0){
            if (year % 400 == 0){
                return 1;
            }
            else{
                return 0;
            }
        }
        else{
            return 1;
        }
    }
    else{
        return 0;
    }
}

int count_leap_years(int start_year, int end_year){
    int count = 0;
    for (int year = start_year; year <= end_year; year++){
        if (is_leap_year(year)){
            count++;
        }
    }
    if(start_year==end_year){
        return 0;
    }else{
        return count;
    }
    
}


int main(){
    long long start_year, start_month, start_day, start_hour, start_minute, start_second;
    long long end_year, end_month, end_day, end_hour, end_minute, end_second;
    time_t start_t, end_t;
    unsigned long long duration;

    printf("Start Time: ");
    scanf("%lld-%lld-%lld %lld:%lld:%lld", &start_year, &start_month, &start_day, &start_hour, &start_minute, &start_second);
    printf("End Time:   ");
    scanf("%lld-%lld-%lld %lld:%lld:%lld", &end_year, &end_month, &end_day, &end_hour, &end_minute, &end_second);

    int days_in_month[] = {31, 28 + is_leap_year(start_year), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    start_t = (time_t) (start_second + start_minute * 60 + start_hour * 3600 + (start_day - 1) * 86400);
    for (int i = 0; i < start_month - 1; i++){
        start_t += days_in_month[i] * 86400;
    }
    for (int i = 1970; i < start_year; i++){
        start_t += (is_leap_year(i) ? 366 : 365) * 86400;
    }

    end_t = (time_t) (end_second + end_minute * 60 + end_hour * 3600 + (end_day - 1) * 86400);
    for (int i = 0; i < end_month - 1; i++){
        end_t += days_in_month[i] * 86400;
    }
    for (int i = 1970; i < end_year; i++){
        end_t += (is_leap_year(i) ? 366 : 365) * 86400;
    }

    duration = (unsigned long long) difftime(end_t, start_t);
    //duration += count_leap_years(start_year, end_year) * 86400;
    printf("Duration:   %llu sec\n", duration);
    //printf("how many leap year:%d\n", count_leap_years(start_year, end_year));
    return 0;
}