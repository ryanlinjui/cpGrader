#include <stdio.h>
#define int long long
#define green "\033[42m"
#define red "\033[41m"
#define blue "\033[44m"
#define reset "\x1b[0;m"

int get_ith_odd(int i) {
    return 2 * i - 1;
}
int color_counter=0; //0=red,1=green,2=blue
void next_color(){
    color_counter++;
    color_counter%=3;
}
void last_color(){
    color_counter--;
    if(color_counter<0){
        color_counter=2;
    }
}
int n;
int the_edge_length;

signed main(){
    // printf(red);
    // printf(" ");
    // printf(green);
    // printf(" ");
    // printf(blue);
    // printf(" ");
    // printf(reset);
    // printf(" ");
    printf("Please enter n: ");
    scanf("%lld", &n);
    if(n<1){
        printf("n must be greater than or equal to 1.\n");
        return 0;
    }

    printf("Please enter the edge length: ");
    scanf("%lld", &the_edge_length);
    if(the_edge_length<1){
        printf("The edge length must be greater than or equal to 1.\n");
        return 0;
    }

    int max_length = get_ith_odd(n)*(the_edge_length*2)+get_ith_odd(n)+1;
    //printf("%lld\n",max_length);

    int now_box=1;
    int now_space=(max_length-(the_edge_length*2+2))/2;
    for(int i=0;i<n;i++){
        //print space
        //debug: printf("%lld\n",now_space);
        for(int k=0;k<now_space;k++){
            printf(" ");
        }
        printf("+");
        for(int p=0;p<now_box;p++){
            for(int j=0;j<the_edge_length*2;j++){
                printf("-");
            }
            printf("+");
        }
        printf("\n");

        //print box
        for(int i=0;i<the_edge_length;i++){
            color_counter=0;
            for(int k=0;k<now_space;k++){
                printf(" ");
            }
            printf("|");
            for(int p=0;p<now_box;p++){
                if(color_counter==0){
                    printf(red);
                }else if(color_counter==1){
                    printf(green);
                }else{
                    printf(blue);
                }
                for(int j=0;j<the_edge_length*2;j++){
                    printf(" ");
                }
                printf(reset);
                printf("|");
                if(p<((now_box+1)/2)-1){
                    next_color();
                }else{
                    last_color();
                }
            }
            printf("\n");            
        }
        now_space-=the_edge_length*2+1;
        now_box+=2;
    }


    now_box-=2;
    
    printf("+");
    for(int p=0;p<now_box;p++){
        for(int j=0;j<the_edge_length*2;j++){
            printf("-");
        }
        printf("+");
    }
    printf("\n");
    
    now_box-=2;
    now_space=the_edge_length*2+1;
    for(int i=0;i<n-1;i++){
        for(int i=0;i<the_edge_length;i++){
            color_counter=0;
            for(int k=0;k<now_space;k++){
                printf(" ");
            }
            printf("|");
            for(int p=0;p<now_box;p++){
                if(color_counter==0){
                    printf(red);
                }else if(color_counter==1){
                    printf(green);
                }else{
                    printf(blue);
                }
                for(int j=0;j<the_edge_length*2;j++){
                    printf(" ");
                }
                printf(reset);
                printf("|");
                if(p<((now_box+1)/2)-1){
                    next_color();
                }else{
                    last_color();
                }
            }
            printf("\n");            
        }

        for(int k=0;k<now_space;k++){
            printf(" ");
        }
        printf("+");
        for(int p=0;p<now_box;p++){
            for(int j=0;j<the_edge_length*2;j++){
                printf("-");
            }
            printf("+");
        }
        printf("\n");

        now_space+=the_edge_length*2+1;
        now_box-=2;
    }
    return 0;
}