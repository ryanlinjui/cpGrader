#include <stdio.h>
#include <stdint.h>
long long girl_weight;
long long boy_weight;
// Setup weights for boys and girls
void setup_girl_weight( uint32_t x){
    girl_weight=x;
}

void setup_boy_weight( uint32_t y){
    boy_weight=y;
}

// Calculate the weight that the member at (x,y) should bear.
// If there is any error inputs or weights are not initialized , return -1.
int64_t afford_weight( int32_t x, int32_t y ){
    
    if(x==0&&y==0){
        return 0;
    }
    if(x<0||y<0){
        return -1;
    }

    int now_gender;//0=gir,1=boy;
    now_gender=x%2;
    long long last_level_person_weight;
    if(now_gender==0){
        last_level_person_weight=boy_weight;
    }else{
        last_level_person_weight=girl_weight;
    }

    if(y==0){
        return afford_weight(x-1,0)+last_level_person_weight/2;
    }else if(x==y){
        return afford_weight(x-1,y-1)+last_level_person_weight/2;
    }else{
        return afford_weight(x-1,y-1)+afford_weight(x-1,y)+last_level_person_weight;
    }
}
