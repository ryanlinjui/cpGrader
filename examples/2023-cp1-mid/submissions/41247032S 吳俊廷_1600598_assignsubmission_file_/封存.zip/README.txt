Name: 吳俊廷
Student ID: 41247032S

## How to build the program?
Open the terminal and type "make" to build the program.

## How to execute your built programs?
Open the terminal and type "./<midYY>" to execute the program, which YY is the problem number.

## About the solution to problem 6(Bonus): Your Comments
Please open the file mid06.txt. I wrote the answer in it.


