# BONUS

Bonus question.
Great question.
Cool question.

Best professor.
Best TAs.
Best homework.

Worst places.
Worst seats.
Worst positions.

Free points.
Free places.
Freed.
