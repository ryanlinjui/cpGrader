#ifndef _MYTLV_H_
#define _MYTLV_H_
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

int32_t run( uint8_t *pByteArray, int32_t size );

#endif