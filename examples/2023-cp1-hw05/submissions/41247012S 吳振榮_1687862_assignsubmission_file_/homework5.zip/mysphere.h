#ifndef _MYSPHERE_H_
#define _MYSPHERE_H_
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>

int32_t get_cap_area( double r, double a, double b, double c, double d, double *pArea );

#endif