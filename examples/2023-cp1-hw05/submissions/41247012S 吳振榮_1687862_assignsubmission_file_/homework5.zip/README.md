# Computer Programming I homework 5
## Author
- 我是資工系116級的吳振榮，學號是41247012S。

## Overview
台師大資工程式設計(一)第五次作業，共5+1道題目。

## Build and Run
Run `make` to compile my code.
```shell
$ make
```
After compiling the program, you can execute hw0301 code by entering `./hw0501` in the terminal, and the remaining programs follow the same pattern.
```shell
$ ./hw0501
$ ./hw0502
$ ./hw0503
$ ./hw0504
$ ./hw0505
```

## homework description
### hw0501
Returns 0 on success.
Returns -1 on error, such as invalid input size or a NULL data pointer.

### hw0502
Returns 1 on success.
Returns 0 if the system is inconsistent (no solution).
Returns 2 if the system is underdetermined (infinite solutions).
Returns -1 on error, such as invalid input size or a NULL pointer.

### hw0503
Returns 1 on success.
Returns 0 if the plane does not intersect the sphere or if the radius is non-positive.
Returns -1 on error, such as a NULL pointer for pArea or if the plane coefficients indicate a degenerate case.

### hw0504
The program will return -1 if the inputs are invalid.
### hw0505
If the src parameter in the decode function is NULL, the function will return.
## Something to notify TAs
None