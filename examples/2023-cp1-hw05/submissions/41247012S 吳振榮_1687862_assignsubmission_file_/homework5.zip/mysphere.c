#include "mysphere.h"

int32_t get_cap_area( double r, double a, double b, double c, double d, double *pArea ){
    if(pArea == NULL) return -1;
    if(r <= 0) return -1;
    if(a == 0 && b == 0 && c == 0) return -1;
    // if(d == 0 && (a != 0 || b != 0 || c != 0)){
    //     *pArea = 0;
    //     return 0;
    // }
    if(sqrt((a * a) + (b * b) + (c * c)) == 0){
        *pArea = 0;
        return 0;
    }
    double dis = fabs(a * 0 + b * 0 + c * 0 + d) / sqrt((a * a) + (b * b) + (c * c));
    if(dis > r) return 0;
    if(dis == r){
        *pArea = 0;
        return 0;
    }
    double radius = sqrt((r * r) - (dis * dis));
    *pArea = radius * radius * M_PI;
    return 1;
}