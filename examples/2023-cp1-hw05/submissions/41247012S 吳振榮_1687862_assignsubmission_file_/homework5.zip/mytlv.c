#include "mytlv.h"

int32_t run( uint8_t *pByteArray, int32_t size ){
    int32_t last = 0, jdg = 0;
    // if(cancel % 2 == 1) jdg = 1;
    if(size <= 0) return -1;
    uint64_t num = 0;
    uint64_t pre = 0, set_ = 0, prin = 0;
    for(int32_t i = 0;i < size;i++){
        if(pByteArray[i] == 1){
            prin = 0;
            pre = num;
            num = 0;
            // pre = 0;
            // int32_t leng = pByteArray[i + 1] + pByteArray[i + 2];
            uint16_t leng = (pByteArray[i + 2] << 8) | pByteArray[i + 1];
            // printf("leng: %d\n", leng);
            int32_t tmp = 1;
            for(int32_t j = 1;j < leng;j++) tmp *= 10;
            i += 3;
            leng += i;
            for(;i < leng;i++){
                num += (tmp * pByteArray[i]);
                tmp /= 10;
            }
            i--;
            // printf("%lld %d\n", num, i);
            // return 0;
        }
        else if(pByteArray[i] == 2){
            prin = 0;
            uint16_t leng = (pByteArray[i + 2] << 8) | pByteArray[i + 1];
            int32_t tmp = 1;
            for(int32_t j = 1;j < leng;j++) tmp *= 10;
            i += 3;
            leng += i;
            pre = num;
            for(;i < leng;i++){
                num += (tmp * pByteArray[i]);
                tmp /= 10;
            }
            i--;
            // printf("%lld %d\n", num, i);
            // return 0;
        }
        else if(pByteArray[i] == 3){
            prin = 0;
            uint16_t leng = (pByteArray[i + 2] << 8) | pByteArray[i + 1];
            int32_t tmp = 1;
            int64_t mul = 0;
            for(int32_t j = 1;j < leng;j++) tmp *= 10;
            i += 3;
            leng += i;
            pre = num;
            for(;i < leng;i++){
                mul += (tmp * pByteArray[i]);
                // printf("tmp: %d\n", tmp * pByteArray[i]);
                tmp /= 10;
            }
            i--;
            // printf("mul: %d\n", mul);
            // return 0;
            num *= mul;
        }
        else if(pByteArray[i] == 4){
            
            uint16_t leng = (pByteArray[i + 2] << 8) | pByteArray[i + 1];
            i += 2;
            if(leng == 0){
                num /= 2;
                pre = num;
                prin = 0;
            }
        }
        else if(pByteArray[i] == 5){
            uint16_t leng = (pByteArray[i + 2] << 8) | pByteArray[i + 1];
            i += 2;
            if(leng == 0){
                num /= 10;
                pre = num;
                prin = 0;
            }
        }
        else if(pByteArray[i] == 6){
            prin = 0;
            uint16_t leng = (pByteArray[i + 2] << 8) | pByteArray[i + 1];
            i += 3;
            int64_t val = 0;
            int32_t tmp = 1, tmp2 = 1;
            for(int32_t j = 1;j < leng;j++){
                tmp *= 10;
                // tmp2 *= 10;
            }
            leng += i;
            for(;i < leng;i++){
                val += (tmp * pByteArray[i]);
                tmp /= 10;
            }
            int32_t tmp_num = num;
            while(tmp_num){
                tmp_num /= 10;
                tmp2 *= 10;
            }
            i--;
            // printf("num: %d\n", num);
            // return 0;
            pre = num;
            num += (val * tmp2);
            set_ = 1;
            // printf("%lld\n", num);
            // return 0;
        }
        else if(pByteArray[i] == 7){
            prin = 0;
            uint16_t leng = (pByteArray[i + 2] << 8) | pByteArray[i + 1];
            i += 3;
            int64_t val = 0;
            int32_t tmp = 1, tmp2 = 10;
            for(int32_t j = 1;j < leng;j++){
                tmp *= 10;
                tmp2 *= 10;
            }
            leng += i;
            for(;i < leng;i++){
                val += (tmp * pByteArray[i]);
                tmp /= 10;
            }
            i--;
            pre = num;
            num = ((num * tmp2) + val);
            set_ = 0;
            // printf("%lld\n", pre);
            // return 0;
        }
        else if(pByteArray[i] == 8){
            uint16_t leng = (pByteArray[i + 2] << 8) | pByteArray[i + 1];
            i += 2;
            if(leng == 0){
                prin = 0;
                pre = num;
                num = 0;
            }
        }
        else if(pByteArray[i] == 9){
            if(i == 0) return -1;
            uint16_t leng = (pByteArray[i + 2] << 8) | pByteArray[i + 1];
            // printf("%d\n", i);
            i += 2;
            i += leng;
            int32_t canc = 0;
            if(pByteArray[i + 1] == 10){
                // printf("fdsfdsfdsfasd");
                while(pByteArray[i + 1] == 10){
                    // printf("pt: %d\n", pByteArray[i]);
                    int32_t lengt = (pByteArray[i + 2] << 8) | pByteArray[i + 1];
                    i += lengt;
                    i += 3;
                    canc++;
                }
                i--;
            }
            if(canc & 1) continue;
            else if(leng == 0){
                printf("%lld\n", num);
                prin = 1;
            }
        }
        else if(pByteArray[i] == 10){
            int32_t canc = 0;
            uint16_t leng;
            while(pByteArray[i] == 10){
                // printf("pt: %d\n", pByteArray[i]);
                leng = (pByteArray[i + 2] << 8) | pByteArray[i + 1];
                i += leng;
                i += 3;
                canc++;
            }
            i--;
            if(canc & 1 && leng == 0){
                // if(prin){
                //     printf("%lld\n", num);
                //     continue;
                // }
                int64_t tmp = pre;
                num = pre;
                pre = tmp;
            }
        }
        else{
            uint16_t leng = (pByteArray[i + 2] << 8) | pByteArray[i + 1];
            // printf("%02x %02x\n", pByteArray[i + 1], pByteArray[i + 2]);
            // printf("leng: %d\ni: %d\n\n", leng, i);
            
            i += 2;
            i += leng;
            // printf("%d\n", i);
        }
    }
    return 0;
}