#ifndef _MYSTATISTICS_H_
#define _MYSTATISTICS_H_
#include <stdio.h>
#include <stdint.h>
#include <math.h>

int32_t statistics( int32_t *pData , int32_t size, double *pMean, double *pVariance , double *pStd );

#endif