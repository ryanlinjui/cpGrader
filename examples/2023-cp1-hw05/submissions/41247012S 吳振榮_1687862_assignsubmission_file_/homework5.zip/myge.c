#include "myge.h"

int32_t gaussian_elimination(int32_t n, int32_t *pA, int32_t *py, int32_t **px) {
    if (n <= 0 || pA == NULL || py == NULL) {
        return -1;
    }
    double *tmp = (double *)malloc(sizeof(double) * n * n);
    double *y = (double *)malloc(sizeof(double) * n);

    for (int32_t i = 0; i < n; i++) {
        for (int32_t j = 0; j < n; j++) {
            tmp[i * n + j] = (double)(pA[i * n + j]);
        }
        y[i] = (double)py[i];
    }

    for (int32_t i = 0; i < n; i++) {
        for (int32_t j = 0; j < n; j++) {
            if (tmp[i * n + i] != 0 && tmp[j * n + i] != 0 && i != j) {
                double fac = tmp[j * n + i] / tmp[i * n + i];
                y[j] -= fac * y[i];
                for (int32_t k = 0; k < n; k++) {
                    tmp[j * n + k] -= fac * tmp[i * n + k];
                }
            }
        }
    }

    for (int32_t i = 0; i < n; i++) {
        if (tmp[i * n + i] == 0 && py[i] != 0) {
            free(tmp);
            free(y);
            return 0;
        }
    }

    for (int32_t i = 0; i < n; i++) {
        int32_t judge = 1;
        for (int32_t j = 0; j < n; j++) {
            if (tmp[i * n + j] != 0) {
                judge = 0;
                break;
            }
        }
        if (judge) {
            free(tmp);
            free(y);
            return 2;
        }
    }

    double *x = (double *)malloc(sizeof(double) * n);
    *px = (int32_t *)malloc(sizeof(int32_t) * n);
    for (int32_t i = n - 1; i >= 0; i--) {
        x[i] = y[i];
        for (int32_t j = i + 1; j < n; j++) {
            y[i] -= tmp[i * n + j] * x[j];
        }
        x[i] /= tmp[i * n + i];
    }
    for(int32_t i = 0;i < n;i++){
        int32_t temp = (int32_t)x[i];
        if(x[i] - temp > 0.5) temp++;
        else if(temp - x[i] > 0.5) temp--;
        (*px)[i] = temp;
    }

    free(tmp);
    free(y);
    free(x);

    return 1;
}