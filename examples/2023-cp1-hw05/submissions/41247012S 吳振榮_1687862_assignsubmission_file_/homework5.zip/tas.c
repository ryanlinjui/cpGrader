#include "tas.h"
void button_set_frame(uint8_t **src, size_t *size, const uint8_t button, const uint64_t start_frame, const uint64_t end_frame){
    if(src == NULL){
        *src = (uint8_t*)malloc(sizeof(uint8_t) * (*size));
        for(size_t i = 0;i < size;i++) (*src)[i] = 0;
    }
    if(end_frame > (*size)){
        int32_t alloc_start = (*size);
        *src = (uint8_t*)realloc(*src, (end_frame * sizeof(uint8_t)) + 1);
        *size = end_frame + 1;
        for(uint64_t i = (*size);i <= end_frame;i++) (*src)[i] = 0;
    }
    for(uint64_t i = start_frame;i <= end_frame;i++){
        (*src)[i] |= button;
    }
}
void button_unset_frame(uint8_t *src, const size_t size, const uint8_t button, const uint64_t start_frame, const uint64_t end_frame){
    if(src == NULL) return;
    for(uint64_t i = start_frame;i <= ((size < end_frame) ? size : end_frame);i++){
        src[i] = src[i] & (~button);
    }
}