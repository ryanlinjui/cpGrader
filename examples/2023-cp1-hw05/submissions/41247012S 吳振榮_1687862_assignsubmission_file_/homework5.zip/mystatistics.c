#include "mystatistics.h"
int32_t statistics( int32_t *pData , int32_t size, double *pMean, double *pVariance , double *pStd ){
    if(size <= 0) return -1;
    if(pData == NULL) return -1;
    int64_t sum = 0;
    for(int32_t i = 0;i < size;i++){
        sum += *(pData + i);
    }
    *pMean = (double)sum / (double)size;
    double var = 0;
    for(int32_t i = 0;i < size;i++){
        var += ((*(pData + i) - *pMean) * (*(pData + i) - *pMean));
    }
    *pVariance = var / (double)size;
    *pStd = sqrt(*pVariance);
    return 0;
}