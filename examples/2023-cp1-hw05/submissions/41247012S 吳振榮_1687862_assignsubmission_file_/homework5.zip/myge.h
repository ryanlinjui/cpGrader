#ifndef _MYGE_H_
#define _MYGE_H_
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

int32_t gaussian_elimination( int32_t n, int32_t *pA, int32_t *py, int32_t **px );

#endif