#pragma once

#include <stdint.h>
#include <stdlib.h>

void extract_fm2_file(const uint8_t *src, const size_t size);
