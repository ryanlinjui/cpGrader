#pragma once
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
// Return -1 if the inputs are invalid.
// Otherwise , Return 0.
int32_t run( uint8_t *pByteArray , int32_t size );