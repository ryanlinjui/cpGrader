#include "myge.h"

// Function to calculate gcd of two numbers
int32_t gcd(int32_t a, int32_t b) {
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

// Function to calculate lcm of two numbers
int32_t lcm(int32_t a, int32_t b) {
    return (a / gcd(a, b)) * b;
}


// I promise that A is an nxn matrix (2d array).
// However , you need to check if the inputs are valid.
// You should malloc for x.
// Return -1 if the inputs are invalid.
// Return 0 if there is no solution.
// Return 1 if there is only one solution.
// Return 2 if there are more than one solutions.
int32_t gaussian_elimination(int32_t n, int32_t *pA, int32_t *py, int32_t **px) {
    if (n <= 0 || pA == NULL || py == NULL || px == NULL) {
        return -1;
    }

    *px = (int32_t *)malloc(n * sizeof(int32_t));
    if (*px == NULL) {
        return -1;
    }

    double *pA_double = (double *)malloc(n * n * sizeof(double));
    double *py_double = (double *)malloc(n * sizeof(double));

    for (int32_t i = 0; i < n; i++) {
        for (int32_t j = 0; j < n; j++) {
            pA_double[i*n+j] = (double)pA[i*n+j];
        }
        py_double[i] = (double)py[i];
    }

    for (int32_t i = 0; i < n; i++) {

        // Search for maximum in this column

        double maxEl = fabs(pA_double[i*n+i]);
        int32_t maxRow = i;
        for (int32_t k=i+1; k<n; k++) {
            if (fabs(pA_double[k*n+i]) > maxEl) {
                maxEl = fabs(pA_double[k*n+i]);
                maxRow = k;
            }
        }

        // Swap maximum row with current row (column by column)
        if (i != maxRow) {
            for (int32_t k=i; k<n; k++) {
                double tmp = pA_double[maxRow*n+k];
                pA_double[maxRow*n+k] = pA_double[i*n+k];
                pA_double[i*n+k] = tmp;
            }
            double tmp = py_double[maxRow];
            py_double[maxRow] = py_double[i];
            py_double[i] = tmp;
        }

        // Make all rows below this one 0 in current column
        for (int32_t k=i+1; k<n; k++) {
            double factor = pA_double[k*n+i] / pA_double[i*n+i];
            for (int32_t j=i; j<n; j++) {
                if (i==j) {
                    pA_double[k*n+j] = 0;
                } else {
                    pA_double[k*n+j] -= factor * pA_double[i*n+j];
                }
            }
            py_double[k] -= factor * py_double[i];
        }

        //DEBUG: printf matrix and vector
        // printf("\n======%d\n", i);
        // for (int32_t k=0; k<n; k++) {
        //     for (int32_t j=0; j<n; j++) {
        //         printf("%f ", pA_double[k*n+j]);
        //     }
        //     printf("| %f\n", py_double[k]);
        //     printf("\n");
        // }

    }

    // Solve equation Ax=b for an upper triangular matrix A
    for (int32_t i=n-1; i>=0; i--) {
        (*px)[i] = (float)py_double[i] / (float)pA_double[i*n+i];
        for (int32_t k=i-1;k>=0; k--) {
            py_double[k] -= pA_double[k*n+i] * (*px)[i];
        }
    }

    free(pA_double);
    free(py_double);

    return 1;
}