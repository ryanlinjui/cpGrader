#include "mysphere.h"
/*
Now given a sphere where its center is at (0, 0, 0) and a plane
ax + by + cz = d, please develop a function to derive the area of the base
of the cap.
*/

// Return -1 if the inputs are invalid.
// Return 0 if no such a plane.
// Otherwise , Return 1.
int32_t get_cap_area( double r, double a, double b, double c, double d, double *pArea ){
    //check if the inputs are valid
    if(r <= 0|| (a == 0 && b == 0 && c == 0)){
        return -1;
    }

    double distance = fabs(d) / sqrt(pow(a, 2) + pow(b, 2) + pow(c, 2));

    if (distance > r) {
        return 0;
    }

    double cap_radius = sqrt(pow(r, 2) - pow(distance, 2));
    *pArea = M_PI * pow(cap_radius, 2);

    if(*pArea==0){
        return 0;
    }

    return 1;
}