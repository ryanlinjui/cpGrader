/*Please develop a program for simple data analysis. Given a series of
int32_t data, please derive mean, variance, and standard deviation.*/

#include "mystatistics.h"

int32_t statistics( int32_t *pData , int32_t size, double *pMean, double *pVariance , double *pStd ){
    if(size <= 0){
        return -1;
    }
    double sum = 0;
    for(int i = 0; i < size; i++){
        //printf("DEBUG: %d\n", pData[i]);
        sum += pData[i];
    }
    *pMean = sum / size;
    sum = 0;
    for(int i = 0; i < size; i++){
        sum += pow(pData[i] - *pMean, 2);
    }
    *pVariance = sum / size;
    *pStd = sqrt(*pVariance);
    return 0;
}