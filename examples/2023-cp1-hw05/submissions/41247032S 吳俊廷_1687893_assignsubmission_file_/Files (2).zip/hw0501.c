#include <stdio.h>
#include <stdint.h>
#include "mystatistics.h"

int main()
{
    int32_t data[]={68, 89, 22, 67, 3, 52, 85, 22, 18, };
    double mean, variance, std;
    int32_t ret = statistics(data, 9, &mean, &variance, &std);
    if(ret == -1){
        printf("Invalid input\n");
    }
    else{
        printf("return value: %d\n", ret);
        printf("Mean: %lf\n", mean);
        printf("Variance: %lf\n", variance);
        printf("Standard deviation: %lf\n", std);
    }
    return 0;
}