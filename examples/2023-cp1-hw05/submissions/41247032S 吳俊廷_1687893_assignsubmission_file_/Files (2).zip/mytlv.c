#include "mytlv.h"



long long merge_two_ints(int a, int b) {
    char str_a[20], str_b[20], str_merged[40];

    sprintf(str_a, "%d", a);
    sprintf(str_b, "%d", b);

    strcpy(str_merged, str_a);
    strcat(str_merged, str_b);

    return atoll(str_merged);
}

long long *commandStack = NULL;
int stackSize = 0;

void push(long long value) {
    commandStack = realloc(commandStack, sizeof(long long) * (stackSize + 1));
    commandStack[stackSize++] = value;
}

void pop() {
    if (stackSize > 0) {
        commandStack = realloc(commandStack, sizeof(long long) * (--stackSize));
    }
}

long long top() {
    if (stackSize > 0) {
        return commandStack[stackSize - 1];
    }
    return 0;
}



// Return -1 if the inputs are invalid.
// Otherwise , Return 0.
int32_t run( uint8_t *pByteArray , int32_t size ){
    long long ans_has_value=0;
    if(pByteArray==NULL||size<=0){
        return -1;
    }

    //printf("DEBUG: size=%d\n",size);
    uint8_t *now_type_ptr=NULL;
    uint16_t *now_length_ptr=NULL;
    //uint32_t *now_ptr=NULL;
    
    long long now_index=0;;
    long long ans_value=0;
    while(now_index<size){
        //printf("DEBUG: New round!\n");
        //printf("DEBUG: now_index=%lld\n",now_index);
        //printf("DEBUG: size=%d\n",size);
        
        //Search Type
        now_type_ptr=pByteArray+now_index;
        //printf("DEBUG: type=%d at %p\n",*now_type_ptr,now_type_ptr);
        now_index++;

        now_length_ptr=(uint16_t*)(pByteArray+now_index);
        //now_length_ptr=(uint16_t*)(now_type_ptr+1);
        //printf("DEBUG: length=%d at %p\n",*now_length_ptr,now_length_ptr);
        if(*now_length_ptr>size-now_index){
            return -1;
        }
        now_index+=2;
        

        //do actions
        if(*now_type_ptr==1){
            //printf("==DEBUG: Enter Type 1\n");
            ans_has_value=1;
            long long power=pow(10,*now_length_ptr-1);
            long long temp_value=0;
            for(int i=0;i<*now_length_ptr;i++){
                //printf("DEBUG: value=%d at %p\n",*(pByteArray+now_index+i),pByteArray+now_index+i);
                //printf("DEBUG: power=%lld\n",power);
                temp_value+=*(pByteArray+now_index+i)*power;
                power/=10;
                //now_value+=*(pByteArray+now_index+i);
            }
            //printf("DEBUG: value=%lld\n",temp_value);
            ans_value=temp_value;
            push(ans_value);
            //printf("DEBUG: ans_value=%lld\n",ans_value);

            now_index+=*now_length_ptr;
        }else if(*now_type_ptr==2){
            //printf("==DEBUG: Enter Type 2\n");
            long long power=pow(10,*now_length_ptr-1);
            long long temp_value=0;
            if(ans_has_value==0){
                return -1;
            }
            for(int i=0;i<*now_length_ptr;i++){
                //printf("DEBUG: value=%d at %p\n",*(pByteArray+now_index+i),pByteArray+now_index+i);
                //printf("DEBUG: power=%lld\n",power);
                temp_value+=*(pByteArray+now_index+i)*power;
                power/=10;
                //now_value+=*(pByteArray+now_index+i);
            }
            //printf("DEBUG: value=%lld\n",temp_value);
            ans_value+=temp_value;
            push(ans_value);
            //printf("DEBUG: ans_value=%lld\n",ans_value);

            now_index+=*now_length_ptr;
        }else if(*now_type_ptr==3){
            //printf("==DEBUG: Enter Type 3\n");
            long long power=pow(10,*now_length_ptr-1);
            long long temp_value=0;
            if(ans_has_value==0){
                return -1;
            }
            for(int i=0;i<*now_length_ptr;i++){
                //printf("DEBUG: value=%d at %p\n",*(pByteArray+now_index+i),pByteArray+now_index+i);
                //printf("DEBUG: power=%lld\n",power);
                temp_value+=*(pByteArray+now_index+i)*power;
                power/=10;
                //now_value+=*(pByteArray+now_index+i);
            }
            //printf("DEBUG: value=%lld\n",temp_value);
            ans_value*=temp_value;
            push(ans_value);
            //printf("DEBUG: ans_value=%lld\n",ans_value);

            now_index+=*now_length_ptr;
        }else if(*now_type_ptr==4){
            //printf("==DEBUG: Enter Type 4\n");
            if(*now_length_ptr!=0||ans_has_value==0){
                return -1;
            }
            ans_value=ans_value/2;
            push(ans_value);
            //printf("DEBUG: ans_value=%lld\n",ans_value);

            now_index+=0;
        }else if(*now_type_ptr==5){
            //printf("==DEBUG: Enter Type 5\n");
            if(*now_length_ptr!=0||ans_has_value==0){
                return -1;
            }
            ans_value=ans_value/10;
            push(ans_value);
            //printf("DEBUG: ans_value=%lld\n",ans_value);

            now_index+=0;
        }else if(*now_type_ptr==6){
            //printf("==DEBUG: Enter Type 6\n");
            long long power=pow(10,*now_length_ptr-1);
            long long temp_value=0;
            if(ans_has_value==0){
                return -1;
            }
            for(int i=0;i<*now_length_ptr;i++){
                //printf("DEBUG: value=%d at %p\n",*(pByteArray+now_index+i),pByteArray+now_index+i);
                //printf("DEBUG: power=%lld\n",power);
                temp_value+=*(pByteArray+now_index+i)*power;
                power/=10;
                //now_value+=*(pByteArray+now_index+i);
            }
            //printf("DEBUG: value=%lld\n",temp_value);
            ans_value=merge_two_ints(temp_value,ans_value);
            push(ans_value);
            //printf("DEBUG: ans_value=%lld\n",ans_value);

            now_index+=*now_length_ptr;
        }else if(*now_type_ptr==7){
            //printf("==DEBUG: Enter Type 7\n");
            long long power=pow(10,*now_length_ptr-1);
            long long temp_value=0;
            if(ans_has_value==0){
                return -1;
            }
            for(int i=0;i<*now_length_ptr;i++){
                //printf("DEBUG: value=%d at %p\n",*(pByteArray+now_index+i),pByteArray+now_index+i);
                //printf("DEBUG: power=%lld\n",power);
                temp_value+=*(pByteArray+now_index+i)*power;
                power/=10;
                //now_value+=*(pByteArray+now_index+i);
            }
            //printf("DEBUG: value=%lld\n",temp_value);
            ans_value=merge_two_ints(ans_value,temp_value);
            push(ans_value);
            //printf("DEBUG: ans_value=%lld\n",ans_value);

            now_index+=*now_length_ptr;
        }else if(*now_type_ptr==8){
            //printf("==DEBUG: Enter Type 8\n");
            ans_has_value=1;
            if(*now_length_ptr!=0){
                return -1;
            }
            ans_value=0;
            push(ans_value);
            //printf("DEBUG: ans_value=%lld\n",ans_value);
        }else if(*now_type_ptr==9){
            //printf("==DEBUG: Enter Type 9\n");
            if(*now_length_ptr!=0||ans_has_value==0){
                return -1;
            }

            // Check if the next command is type 10
            uint8_t *now_temp_TypePtr = now_type_ptr;
            long long temp_index=now_index;
            int consecutiveTens = 0;
            
            while (temp_index < size) {
                now_temp_TypePtr+=3;
                temp_index+=3;

                if(*now_temp_TypePtr!=10){
                    break;
                }else{
                    consecutiveTens++;
                }
            }

            // If the number of consecutive type 10 commands is odd, skip this command
            if (consecutiveTens % 2 == 1) {
                now_index += 3;
                continue;
            }

            //printf("HERE: %lld\n",ans_value);
            printf("%lld\n",ans_value);
        }else if(*now_type_ptr==10){
            //printf("==DEBUG: Enter Type 10\n");
            if(*now_length_ptr!=0){
                return -1;
            }

            // Check for consecutive cancel commands
            int consecutiveCancels = 1;

            uint8_t *now_temp_TypePtr = now_type_ptr;
            long long temp_index=now_index;
            
            while (temp_index <= size) {
                //printf("DEBUG: temp_index=%lld\n",temp_index);
                //printf("DEBUG: size=%d\n",size);
                now_temp_TypePtr+=3;
                temp_index+=3;

                //printf("DEBUG:in type 10: type=%d at %p\n",*now_temp_TypePtr,now_temp_TypePtr);
                if(*now_temp_TypePtr!=10){
                    break;
                }else{
                    now_temp_TypePtr+=3;
                    //printf("DEBUG: type=%d at %p\n",*now_temp_TypePtr,now_temp_TypePtr);
                    consecutiveCancels++;
                }
            }
            //break;
            //printf("DEBUG: consecutiveCancels=%d\n",consecutiveCancels);

            // If there are an odd number of consecutive cancels, execute the cancel command
            if (consecutiveCancels % 2 == 1) {
                pop();
                ans_value=top();
                push(ans_value);
                //printf("DEBUG: ans_value=%lld\n",ans_value);
            }
            // Skip the consecutive cancel commands
            now_index += (consecutiveCancels-1)*3;
        }else{
            //Enter Type others
            //printf("==DEBUG: Enter Type others\n");
            now_index+=*now_length_ptr;
        }
        
    }
    


    return 0;
}