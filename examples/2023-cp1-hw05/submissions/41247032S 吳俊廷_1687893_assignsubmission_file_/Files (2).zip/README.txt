Name: 吳俊廷
Student ID: 41247032S

## How to build the program?
Open the terminal and type "make" to build the program.

## How to execute your built programs?
Open the terminal and type "./<hw05YY>" to execute the program, which YY is the problem number.
For example, ./hw0502 is the executable program for homework #5 problem 2.

## About hw0502
記得在執行對number操作的各種指令（如指令type2,type3......）時，務必先初始化number（指令type1,type8）

