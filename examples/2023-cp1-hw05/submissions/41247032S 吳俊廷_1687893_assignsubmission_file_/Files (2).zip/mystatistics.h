#pragma once
#include <stdint.h>
#include <stdio.h>
#include <math.h>

int32_t statistics( int32_t *pData , int32_t size, double *pMean, double *pVariance , double *pStd );