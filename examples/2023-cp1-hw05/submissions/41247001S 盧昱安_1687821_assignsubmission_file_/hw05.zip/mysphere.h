#ifndef DICEROLLS_H
#define DICEROLLS_H
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

int32_t get_cap_area( double r, double a, double b, double c,double d, double *pArea );

#endif