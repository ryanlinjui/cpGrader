#ifndef DICEROLLS_H
#define DICEROLLS_H
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>


int32_t gaussian_elimination( int32_t n, int32_t *pA, int32_t *py, int32_t **px );



#endif 