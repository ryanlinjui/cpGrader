#include <stdio.h>
#include <stdint.h>
#include <math.h>

int32_t statistics(int32_t *pData, int32_t size, double *pMean, double *pVariance, double *pStd);

int32_t statistics(int32_t *pData, int32_t size, double *pMean, double *pVariance, double *pStd){
	if (pData == NULL || size <= 0 || pMean == NULL || pVariance == NULL || pStd == NULL){
		return -1;
	}
	//cauculate mean
	int32_t sum = 0;
	for (int32_t i = 0; i < size; i++){
		sum = sum + pData[i];
	}
	*pMean = sum / (double)size;
	//cauculate var
	double diff = 0;
	for (int32_t i = 0; i < size; i++){
		diff = diff + (*pMean-pData[i]) * (*pMean-pData[i]);
	}
	*pVariance = diff / size;
	//cauculate std
	*pStd = sqrt(*pVariance);
	return 0;
}