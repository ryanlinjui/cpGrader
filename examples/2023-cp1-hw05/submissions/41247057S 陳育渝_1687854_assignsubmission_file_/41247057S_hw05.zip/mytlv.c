#include <stdio.h>
#include <stdint.h>
#include <math.h>

int32_t run (uint8_t *pByteArray, int32_t size);

int32_t run (uint8_t *pByteArray, int32_t size){
    //check inputs
    if (size <= 0 || pByteArray == NULL){
        return -1;
    } 
    for (int32_t i = 0; i < size; i++){
        if (*(pByteArray+i) < 0){
            return -1;
        }
    }
    //scan type
    int32_t number = 0;
    int32_t value = 0;

    uint8_t *total = pByteArray + size;
    int32_t save[size];
    int32_t i = 0;
    while (pByteArray < total){
        if (*pByteArray == 1){
            int32_t len = *(pByteArray + 2) * 256 + *(pByteArray + 1);
            pByteArray = pByteArray + 2;
            for (int32_t j = len-1; j >= 0; j--){
                if (pByteArray > total){
                    return -1;
                }
                pByteArray++;
                number = number + (*pByteArray * pow(10, j));
            }
            pByteArray++;
        }
        else if (*pByteArray == 2){
            int32_t len = *(pByteArray + 2) * 256 + *(pByteArray + 1);
            pByteArray = pByteArray + 2;
            for (int32_t j = len-1; j >= 0; j--){
                if (pByteArray > total){
                    return -1;
                }
                pByteArray++;
                value = value + (*pByteArray * pow(10, j));
            }
            number = number + value;
            value = 0;
            pByteArray++;
        }
        else if (*pByteArray == 3){
            int32_t len = *(pByteArray + 2) * 256 + *(pByteArray + 1);
            pByteArray = pByteArray + 2;
            for (int32_t j = len-1; j >= 0; j--){
                if (pByteArray > total){
                    return -1;
                }
                pByteArray++;
                value = value + (*pByteArray * pow(10, j));
            }
            number = number * value;
            value = 0;
            pByteArray++;
        }
        else if (*pByteArray == 4){
            if (*(pByteArray+1) != 0 || *(pByteArray+2) != 0){
                return -1;
            }
            number = number / 2;
            pByteArray = pByteArray + 3;
        }
        else if (*pByteArray == 5){
            if (*(pByteArray+1) != 0 || *(pByteArray+2) != 0){
                return -1;
            }
            number = number / 10;
            pByteArray = pByteArray + 3;
        }   
        else if (*pByteArray == 6){
            int32_t len = *(pByteArray + 2) * 256 + *(pByteArray + 1);
            pByteArray = pByteArray + 2;
            int32_t count = 0;
            int32_t temp = number;
            while (temp > 0){
                temp = temp / 10;
                count++;
            }
            for (int32_t j = count + len - 1; j >= count; j--){
                if (pByteArray > total){
                    return -1;
                }
                pByteArray++;
                value = value + (*pByteArray * pow(10, j));
            }
            number = number + value;
            value = 0;
            pByteArray++;
        }
        else if (*pByteArray == 7){
            int32_t len = *(pByteArray + 2) * 256 + *(pByteArray + 1);
            pByteArray = pByteArray + 2;
            number = number * pow(10, *(pByteArray-1));
            for (int32_t j = len-1; j >= 0; j--){
                if (pByteArray > total){
                    return -1;
                }
                pByteArray++;
                value = value + (*pByteArray * pow(10, j));
            }
            number = number + value;
            value = 0;
            pByteArray++;
        }
        else if (*pByteArray == 8){
            if (*(pByteArray+1) != 0 || *(pByteArray+2) != 0){
                return -1;
            }
            number = 0;
            pByteArray = pByteArray + 3;
        }
        else if (*pByteArray == 9){
            if (*(pByteArray+1) != 0 || *(pByteArray+2) != 0){
                return -1;
            }
            printf("%d\n", number);
            pByteArray = pByteArray + 3;
        }
        else if (*pByteArray == 10){
            if (save[i-2] == save[i]){
                number = save[i-1];
            }
            if (*(pByteArray+1) != 0 || *(pByteArray+2) != 0){
                return -1;
            }
            if (i-2 < 0){
                save[i-2] = 0;
            }
            if (save[i-2] == 0){
                number = 0;
            }
            else{
                number = save[i-2];
            }
            pByteArray = pByteArray + 3;
        }
        else{
            pByteArray++;
        }
        save[i] = number;
        i++;
    }
    return 0;
}