#include <stdio.h>
#include <stdint.h>

int32_t statistics(int32_t *pData, int32_t size, double *pMean, double *pVariance, double *pStd);
