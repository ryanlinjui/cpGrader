#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>

int32_t get_cap_area (double r, double a, double b, double c, double d, double *pArea);

int32_t get_cap_area (double r, double a, double b, double c, double d, double *pArea){
    double D = fabs(d) / sqrt (a * a + b * b + c * c);
    //return -1
    if (a == 0 && b == 0 && c == 0){
        return -1;
    }
    if (D < 0 || pArea == NULL || r <= 0){
        return -1;
    }
    //return 0
    if (D >= r){
        return 0;
    }
    //cauculate
    *pArea = (r * r - D * D) * M_PI;
    return 1;
}