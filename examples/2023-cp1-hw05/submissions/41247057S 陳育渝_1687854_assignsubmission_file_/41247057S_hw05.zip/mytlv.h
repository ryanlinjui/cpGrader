#include <stdio.h>
#include <stdint.h>

int32_t run (uint8_t *pByteArray, int32_t size);