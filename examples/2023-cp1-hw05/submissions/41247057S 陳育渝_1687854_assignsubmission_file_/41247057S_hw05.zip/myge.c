#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>

int32_t gaussian_elimination (int32_t n, int32_t *pA, int32_t *py, int32_t **px);

int32_t gaussian_elimination (int32_t n, int32_t *pA, int32_t *py, int32_t **px){
    //check inputs
    if (n < 1 || pA == NULL || py == NULL){
        return -1;
    }

    //no solution
    for (int32_t i = 0; i < n; i++){
        int32_t count = 0;
        for (int32_t j = n * i; j < n * (i + 1); j++){
            if (*(pA + j) == 0){
                count++;
            }
        }
        if (count == n && *(py + i) != 0){
            return 0;
        }
    }
    
    //more than one solution
    for (int32_t i = 0; i < n; i++){
        int32_t count = 0;
        for (int32_t j = n * i; j < n * (i + 1); j++){
            if (*(pA + j) == 0){
                count++;
            }
        }
        if (count == n && *(py + i) == 0){
            return 2;
        }
    }

    *px = (int32_t *)malloc(n * sizeof(int32_t));

    //only one solution
    double mixtrix[n][n+1];
    int32_t index = 0;
    for (int32_t i = 0; i < n; i++){
        for (int32_t j = 0; j < n; j++){
            mixtrix[i][j] = *(pA + index);
            index++;
        }
        mixtrix[i][n] = *(py + i);
    }

    //move to top
    for (int32_t i = 1; i < n; i++){
        for (int32_t j= 0; j < n + 1; j++){
            if (mixtrix[i][0] == 1 || mixtrix[i][0] == -1){
                for (int32_t a = 0; a < n + 1; a++){
                    int32_t temp = 0;
                    temp = mixtrix[i-1][a];
                    mixtrix[i-1][a] = mixtrix[i][a];
                    mixtrix[i][a] = temp;
                }
            }
        }
    }

    //cauculate
    for (int32_t i = 0; i < n; i++){
        for (int32_t j = i + 1; j < n; j++){
            double ratio = mixtrix[j][i] / mixtrix[i][i];
            int64_t lcm = 0;
            int32_t new = 0;
            if ((int)ratio != ratio){
                int32_t a = mixtrix[j][i];
                int32_t b = mixtrix[i][i];
                while (b != 0){
                    int32_t temp = a % b;
                    a = b;
                    b = temp;
                }
                lcm = (mixtrix[j][i] * mixtrix[i][i]) / a;
                ratio = lcm / mixtrix[i][i];
                new = lcm / mixtrix[j][i];
            }

            for (int32_t k = 0; k < n+1; k++){
                if (lcm != 0){
                    mixtrix[j][k] = new * mixtrix[j][k] - ratio * mixtrix[i][k];
                }
                else{
                    mixtrix[j][k] = mixtrix[j][k] - ratio * mixtrix[i][k];
                }
            }
        }
    }

    //debug
    /*
    for (int32_t i = 0; i < n; i++){
        for (int32_t j = 0; j < n+1; j++){
            printf("%.0lf  ", mixtrix[i][j]);
        }
        printf("\n");
    }
    */

    for (int32_t i = n-1; i >= 0; i--){
        *(*px + i) = mixtrix[i][n] / mixtrix[i][i];
        for (int32_t j = i - 1; j >= 0; j--){
            mixtrix[j][n] = mixtrix[j][n] - mixtrix[j][i] * *(*px + i);
        }
    }

    return 1;
}