#include<stdio.h>
#include<stdint.h>
#include<math.h>

static int32_t sum = 0;
static double myvar = 0;
static double mean = 0;

int32_t statistics ( int32_t *pData, int32_t size, double *pMean, double *pVariance, double *pStd );

int32_t statistics ( int32_t *pData, int32_t size, double *pMean, double *pVariance, double *pStd )
{
    //avoid idiot
    if ( pData == NULL ) return -1;
    if ( size <= 0 ) return -1;
    
    sum = 0;
    //sum
    for ( int i = 0 ; i < size ; i ++ )
    {
        sum = sum + *pData;
        pData++;
    } 
    //mean
    mean = 0;
    *pMean = ( double ) sum / size;
    mean = ( double ) sum / size;
    
    //var
    pData -= size;
    myvar = 0;
    for ( int i = 0 ; i < size ; i ++ )
    {
        myvar = myvar + (*pData-*pMean)*(*pData-*pMean);
        pData++;
    }
    myvar = myvar / size;
    *pVariance = myvar;
    
    //std
    *pStd = sqrt(myvar);
    
    return 0;

}