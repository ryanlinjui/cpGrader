#include<stdio.h>
#include<stdint.h>
#include<math.h>
#include<stdlib.h>

static double distance = 0;
static double circler = 0;

int32_t get_cap_area ( double r, double a, double b, double c, double d, double *pArea );

int32_t get_cap_area ( double r, double a, double b, double c, double d, double *pArea )
{
    if ( pArea == NULL ) return -1;
    if ( r <= 0 ) return -1;
    if ( a == b && b == c && c == 0 ) return -1;
    
    //the cloest
    distance = abs (d) / sqrt (a*a+b*b+c*c);
    
    //circle r
    if ( r*r - distance*distance <= 0 ) return 0;
    circler = sqrt ( r*r - distance*distance );
    
    //calculate area
    *pArea = circler*circler*M_PI;
    
    return 1; 
}