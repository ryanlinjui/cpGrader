#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>
#include<math.h>

int32_t gaussian_elimination ( int32_t n, int32_t *pA, int32_t *py, int32_t **px );

int32_t gaussian_elimination ( int32_t n, int32_t *pA, int32_t *py, int32_t **px )
{
    if ( pA == NULL || py == NULL ) return -1;
    if ( n <= 0 ) return -1;
    
    int32_t b[n][n+1];
    
    for ( int i = 0 ; i < n ; i ++ )
    {
        for ( int j = 0 ; j < n ; j ++ )
        {
            b[i][j] = 0;
        }
    }  
    for ( int i = 0 ; i < n ; i ++ )
    {
        for ( int j = 0 ; j < n ; j ++ )
        {
            b[i][j] = *(pA+i*n+j);
        }
    }
    for ( int i = 0 ; i < n ; i ++ )
    {
        b[i][n] = *(py+i);
    }
    
    double c[n][n+1];
    for ( int i = 0 ; i < n ; i ++ )
    {
        for ( int j = 0 ; j < n + 1 ; j ++ )
        {
            c[i][j] = b[i][j];
        }
    }
    
    //*
    /*
    for ( int i = 0 ; i < n ; i ++ )
    {
        for ( int j = 0 ; j < n + 1 ; j ++ )
        {
            printf ( "%f ", c[i][j] );
        }
        printf ("\n");
    }*/
    
    //change line
    for ( int i = 0 ; i < n ; i ++ )
    {
        if ( c[i][i] == 0 )
        {
            for ( int j = 0 ; j < n + 1 ; j ++ )
            {
                int32_t temp = c[i][j];
                c[i][j] = c[i+1][j];
                c[i+1][j] = temp;
            }
        }
    }
    
    for ( int time = 0 ; time < n ; time ++ )
    {
        for ( int i = time + 1  ; i < n ; i ++ )
        {     
            if ( c[i][time] == 0 || c[time][time] == 0 ) continue;
            double multi = -c[i][time]/c[time][time];
                              
            for ( int j = 0 ; j < n + 1 ; j ++ )
            {
                c[i][j] = c[i][j] + c[time][j]*multi;
            }       
        }
    }
    //*
    /*
    for ( int i = 0 ; i < n ; i ++ )
    {
        for ( int j = 0 ; j < n + 1 ; j ++ )
        {
            printf ( "%f ", c[i][j] );
        }
        printf ("\n");
    }*/
        
    for ( int i = 0 ; i < n ; i ++ )
    {
        int32_t noans = 0;
        for ( int j = 0 ; j < n ; j ++ )
        {
            noans += c[i][j];
        }
        if ( noans == 0 && c[i][n] != 0 ) return 0;
        if ( noans == 0 && c[i][n] == 0 ) return 2;
    }
    
    //to 1 
    for ( int i = 0 ; i < n ; i ++ )
    {
        double divi = c[i][i];
        
        for ( int j = 0 ; j < n + 1 ; j ++ )
        {
            c[i][j] /= divi;    
        }
    }
    
    //*
    /*
    for ( int i = 0 ; i < n ; i ++ )
    {
        for ( int j = 0 ; j < n + 1 ; j ++ )
        {
            printf ( "%f ", c[i][j] );
        }
        printf ("\n");
    }*/
    
    for ( int i = n - 1 ; i >= 0 ; i -- )
    {
        double chen = c[i][i];
        if ( chen == 0 ) continue;
        
        for ( int j = 0 ; j < n ; j ++ )
        {
            c[i][j] /= chen;
        }    
        for ( int k = i-1 ; k >= 0 ; k -- )
        {
            double fac = c[k][i];
            if ( fac == 0 ) continue;
            
            for ( int j = 0 ; j < n+1 ; j ++ )
            {
                c[k][j] -= fac*c[i][j];
            }
        }
    }
    //*
    /*
    for ( int i = 0 ; i < n ; i ++ )
    {
        for ( int j = 0 ; j < n + 1 ; j ++ )
        {
            printf ( "%f ", c[i][j] );
        }
        printf ("\n");
    }*/
    
    for ( int i = 0 ; i < n ; i ++ )
    {
        int32_t noans = 0;
        for ( int j = 0 ; j < n ; j ++ )
        {
            noans += c[i][j];
        }
        if ( noans == 0 && c[i][n] != 0 ) return 0;
        if ( noans == 0 && c[i][n] == 0 ) return 2;
    }
    
    int32_t ans[n];
    
    for ( int i = 0 ; i < n ; i ++ ) ans[i] = 0;
    
    //ans
    for ( int i = 0 ; i < n ; i ++ )
    {
        ans[i] = (int) round ( c[i][n]/c[i][i] );
    }
    
    //save
    *px = malloc ( n*sizeof(int) );
    //*px = calloc ( n, sizeof (int) );
    for ( int i = 0 ; i < n ; i ++ )
    {
        *(*px+i) = ans[i];
    }
    
    //print
    /*
    for ( int i = 0 ; i < n ; i ++ )
    {
        for ( int j = 0 ; j < n + 1 ; j ++ )
        {
            printf ( "%d ", b[i][j] );
        }
        printf ("\n");
    }
    for ( int i = 0 ; i < n ; i ++ )
    {
        for ( int j = 0 ; j < n + 1 ; j ++ )
        {
            printf ( "%f ", c[i][j] );
        }
        printf ("\n");
    }
    for ( int i = 0 ; i < n ; i ++ ) printf ("%d ", ans[i]);
    printf ("\n");*/
    return 1;
    
}