#include<stdio.h>
#include<stdint.h>
#include<math.h>

static uint64_t oldans = 0;
static uint64_t ans = 0;
static int32_t length = 0;
static int32_t count = 0;
static int32_t move = 0;
static int32_t error = 0;

int32_t run ( uint8_t *pByteArray, int32_t size );
void one ( uint8_t *pByteArray, int32_t size );
void two ( uint8_t *pByteArray, int32_t size );
void three ( uint8_t *pByteArray, int32_t size );
void four ( uint8_t *pByteArray, int32_t size );
void five ( uint8_t *pByteArray, int32_t size );
void six ( uint8_t *pByteArray, int32_t size );
void seven ( uint8_t *pByteArray, int32_t size );
void eight ( uint8_t *pByteArray, int32_t size );
void nine ( uint8_t *pByteArray, int32_t size );
void ten ( uint8_t *pByteArray, int32_t size );
void other ( uint8_t *pByteArray, int32_t size );

void one ( uint8_t *pByteArray, int32_t size )
{
    move = 0;
    oldans = ans;
    ans = 0;
    pByteArray++;
    length = *(pByteArray+1)*256 + *pByteArray;
    //printf ( "%u\n", length );
    pByteArray++;
    for ( int32_t i = length ; i > 0 ; i -- )
    {
        pByteArray++;
        ans += *pByteArray*pow(10,i-1);
        //printf ( "%d ",*pByteArray );
    }
    count += 3+length;
    move = 3+length;
    //printf ( "\n%ld %d\n", ans, count );
}

void two ( uint8_t *pByteArray, int32_t size )
{
    move = 0;
    length = 0;
    oldans = ans;
    pByteArray++;
    length = *(pByteArray+1)*256 + *pByteArray;
    pByteArray++;
    for ( int32_t i = length ; i > 0 ; i -- )
    {
        pByteArray++;
        ans += *pByteArray*pow(10,i-1);
        //printf ( "%d ",*pByteArray );
    }
    count += 3+length;
    move = 3+length;
    //printf ( "\n%d %d\n", ans, count );
}

void three ( uint8_t *pByteArray, int32_t size )
{
    move = 0;
    pByteArray++;
    length = 0;
    oldans = ans;
    length = *(pByteArray+1)*256 + *pByteArray;
    pByteArray++;
    int32_t multi = 0;
    for ( int32_t i = length ; i > 0 ; i -- )
    {
        pByteArray++;
        multi += *pByteArray*pow(10,i-1);
        //printf ( "%d ",*pByteArray );
    }
    ans *= multi;
    count += 3+length;
    move = 3+length;
    //printf ( "\n%d %d\n", ans, count );
}

void four ( uint8_t *pByteArray, int32_t size )
{
    move = 0;
    pByteArray++;
    length = 0;
    oldans = ans;
    length = *(pByteArray+1)*256 + *pByteArray;
    if ( length != 0 ) error++;
    ans /= 2;
    count += 3;
    move = 3;
    //printf ( "\n%d %d\n", ans, count );
}

void five ( uint8_t *pByteArray, int32_t size )
{
    move = 0;
    pByteArray++;
    length = 0;
    oldans = ans;
    length = *(pByteArray+1)*256 + *pByteArray;
    if ( length != 0 ) error++;
    ans /= 10;
    count += 3;
    move = 3;
    //printf ( "\n%d %d\n", ans, count );
}

void six ( uint8_t *pByteArray, int32_t size )
{
    move = 0;
    pByteArray++;
    oldans = ans;
    length = *(pByteArray+1)*256 + *pByteArray;
    int32_t anslength = 0;
    int32_t anscount = ans;
    while ( anscount > 0 ) anscount /= 10, anslength++;
    pByteArray++;
    for ( int32_t i = length ; i > 0 ; i -- )
    {
        pByteArray++;
        ans += *pByteArray*pow(10,i+anslength-1);
    }
    count += 3+length;
    move = 3+length;
    pByteArray++;
    //printf ("\n%d\n", ans);
}

void seven ( uint8_t *pByteArray, int32_t size )
{
    move = 0;
    pByteArray++;
    oldans = ans;
    length = *(pByteArray+1)*256 + *pByteArray;
    pByteArray++;
    ans *= pow ( 10, length );
    for ( int32_t i = length ; i > 0 ; i -- )
    {
        pByteArray++;
        ans += *pByteArray*pow(10,i-1);
    }
    count += 3+length;
    move = 3+length;
    pByteArray++;
    //printf ("\n%d\n", ans);
}

void eight ( uint8_t *pByteArray, int32_t size )
{
    move = 0;
    pByteArray++;
    oldans = ans;
    if ( *(pByteArray+1) != 0 || *pByteArray != 0 ) error++;
    else ans = 0;
    count += 3;
    move = 3;
}

void nine ( uint8_t *pByteArray, int32_t size )
{
    move = 0;
    pByteArray++;
    if ( *(pByteArray+1) != 0 || *pByteArray != 0 ) error++; 
    else if ( *(pByteArray+2) != 10 ) printf ( "%ld\n", ans );
    count += 3;
    move = 3;
}

void ten ( uint8_t *pByteArray, int32_t size )
{
    move = 0;
    pByteArray++;
    if ( *(pByteArray+1) != 0 || *pByteArray != 0 ) error++; 
    if ( *(pByteArray+2) != 10 ) ans = oldans, count += 3, move = 3;
    else if ( *(pByteArray+2) == 10 )
    {
        if ( *(pByteArray+3) == 0 && *(pByteArray+4) == 0 ) count += 6, move = 6;
        else error++;
    } 
    //printf ("\n%d\n", ans);
}

void other ( uint8_t *pByteArray, int32_t size )
{
    move = 0;
    oldans = ans;
    pByteArray++;
    length = *(pByteArray+1)*256 + *pByteArray;
    count += 3+length;
    move = 3+length;
}

int32_t run ( uint8_t *pByteArray, int32_t size )
{    
    //printf ("%d", *pByteArray );   
    while ( count < size )
    {
        if ( error != 0 ) return -1;
        //printf ("%d %d\n", *pByteArray, count );
        if ( *pByteArray == 1 )
        {
            one ( pByteArray, size );
            pByteArray += move;
        }
        else if ( *pByteArray == 2 )
        {
            two ( pByteArray, size );
            pByteArray += move;
        }
        else if ( *pByteArray == 3 )
        {
            three ( pByteArray, size );
            pByteArray += move;
        }
        else if ( *pByteArray == 4 )
        {
            four ( pByteArray, size );
            pByteArray += move;        
        }
        else if ( *pByteArray == 5 )
        {
            five ( pByteArray, size );
            pByteArray += move;
        }
        else if ( *pByteArray == 6 )
        {
            six ( pByteArray, size );
            pByteArray += move;
        }
        else if ( *pByteArray == 7 )
        {
            seven ( pByteArray, size );
            pByteArray += move;    
        }
        else if ( *pByteArray == 8 )
        {
            eight ( pByteArray, size );
            pByteArray += move;
        }
        else if ( *pByteArray == 9 )
        {
            nine ( pByteArray, size );
            pByteArray += move;
        }
        else if ( *pByteArray == 10 )
        {
            ten ( pByteArray, size );
            pByteArray += move;
        }
        else
        {
            other ( pByteArray, size );
            pByteArray += move;
        }
    }
    //printf ( "%d\n", count );
    return 0;
    
}