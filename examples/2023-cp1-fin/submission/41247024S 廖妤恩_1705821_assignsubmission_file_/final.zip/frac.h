#include<stdio.h>
#include<stdint.h>

static int32_t mom = 0;
static int32_t son = 0;
static int32_t divi = 0;
static int64_t check = 0;

int32_t frac_add ( int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d );
int32_t frac_del ( int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d );
int32_t frac_mul ( int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d );
int32_t frac_div ( int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d );
int32_t gcd ( int32_t u, int32_t v );

int32_t gcd ( int32_t u, int32_t v )
{
    while ( v != 0 )
    {
        int32_t temp = v;
        v = u % v;
        u = temp;
    }
    return u; 
}

int32_t frac_add ( int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d )
{
    mom = b*d;
    son = a*d+c*b;
    if ( son == 0 ) mom == 1;
    check = son;
    if ( check > 2147483647 || check < -2147483648 ) return -1;
    check = mom;
    if ( check > 2147483647 || check < -2147483648 ) return -1;
    if ( mom == 0 ) return -1;
    divi = gcd ( son, mom );
    son /= divi;
    mom /= divi;
    if ( son > 0 && mom < 0 )
    {
        son *= -1;
        mom *= -1;
    }    
    *x = son;
    *y = mom;
    return 0;
}

int32_t frac_del ( int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d )
{
    mom = b*d;
    son = a*d-b*c;
    if ( son == 0 ) mom == 1;
    check = son;
    if ( check > 2147483647 || check < -2147483648 ) return -1;
    check = mom;
    if ( check > 2147483647 || check < -2147483648 ) return -1;
    if ( mom == 0 ) return -1;
    divi = gcd ( son, mom );
    son /= divi;
    mom /= divi;
    if ( son > 0 && mom < 0 )
    {
        son *= -1;
        mom *= -1;
    }
    *x = son;
    *y = mom;
    return 0;
}

int32_t frac_mul ( int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d )
{
    mom = b*d;
    son = a*c;
    if ( son == 0 ) mom == 1;
    check = son;
    if ( check > 2147483647 || check < -2147483648 ) return -1;
    check = mom;
    if ( check > 2147483647 || check < -2147483648 ) return -1;
    if ( mom == 0 ) return -1;
    divi = gcd ( son, mom );
    son /= divi;
    mom /= divi;
    if ( son > 0 && mom < 0 )
    {
        son *= -1;
        mom *= -1;
    }
    *x = son;
    *y = mom;
    return 0;
}

int32_t frac_div ( int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d )
{
    mom = b*c;
    son = a*d;
    if ( son == 0 ) mom == 1;
    check = son;
    if ( check > 2147483647 || check < -2147483648 ) return -1;
    check = mom;
    if ( check > 2147483647 || check < -2147483648 ) return -1;
    if ( mom == 0 ) return -1;
    divi = gcd ( son, mom );
    son /= divi;
    mom /= divi;
    if ( son > 0 && mom < 0 )
    {
        son *= -1;
        mom *= -1;
    }
    *x = son;
    *y = mom;
    return 0;
}




