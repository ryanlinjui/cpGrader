#include<stdio.h>
#include<stdint.h>
#include<time.h>
#include<stdlib.h>
#include<ctype.h>

int main ()
{
    int32_t height = 0;
    int32_t width = 0;
    
    printf ("Please input the height of the map:");
    scanf ("%d", &height);
    printf ("Please input the width of the map:");
    scanf ("%d", &width);
    
    // 7:- 6:| 3:space 1:people 2:gun 4:computer 5:r
    
    //set up map
    int32_t map[height][width];
    for ( int i = 0 ; i < width ; i ++ ) map[0][i] = 7;
    for ( int i = 0 ; i < width ; i ++ ) map[height-1][i] = 7;
    for ( int i = 1 ; i < height-1 ; i ++ ) map[i][0] = 6;
    for ( int i = 1 ; i < height-1 ; i ++ ) map[i][width-1] = 6;
    for ( int i = 1 ; i < height-1 ; i ++ )
    {
        for ( int j = 1 ; j < width-1 ; j ++ )
        {
            map[i][j] = 3;
        }
    }
    
    srand ( time(0) );
    //man
    int32_t mani = rand()%(height-3)+2;
    int32_t manj = rand()%(width-2)+1;
    map[mani][manj] = 1;
    map[mani-1][manj] = 2;
    
    //computer
    int32_t comi1 = rand()%(height-3)+2; 
    int32_t comj1 = rand()%(width-2)+1;
    while ( comi1 == mani || comi1 == mani+1 || comi1 == mani-1 ) comi1 = rand()%(height-3)+2;
    while ( comj1 == manj ) comj1 = rand()%(width-2)+1;
    map[comi1][comj1] = 4;
    map[comi1-1][comj1] = 2;
    
    int32_t comi2 = rand()%(height-3)+2; 
    int32_t comj2 = rand()%(width-2)+1;
    while ( comi2 == mani || comi2 == mani+1 || comi2 == mani-1 || comi2 == comi1 || comi2 == comi1+1 || comi2 == comi1-1 ) comi2 = rand()%(height-3)+2;
    while ( comj2 == manj || comj2 == comj1 ) comj2 = rand()%(width-2)+1;
    map[comi2][comj2] = 4;
    map[comi2-1][comj2] = 2;
    
    int32_t comi3 = rand()%(height-3)+2; 
    int32_t comj3 = rand()%(width-2)+1;
    while ( comi3 == mani || comi3 == mani+1 || comi3 == mani-1 || comi3 == comi1 || comi3 == comi1+1 || comi3 == comi1-1 || comi3 == comi2 || comi3 == comi2+1 || comi3 == comi2-1 ) comi3 = rand()%(height-3)+2; 
    while ( comj3 == manj || comj3 == comj1 || comj3 == comj2 ) comj3 = rand()%(width-2)+1;
    map[comi3][comj3] = 4;
    map[comi3-1][comj3] = 2;
    
    //r
    int32_t x = 0;
    int32_t y = 0;
    int32_t numr = ( width*height )/40;
    int32_t count = 0;
    while ( count < numr )
    {
        x = rand()*count%(height-2)+2;
        y = rand()*count%(width-2)+1;
        while ( map[x][y] !=3 ) x = rand()%(height-2)+2, y = rand()%(width-2)+1;
        map[x][y] = 5;
        count ++;
    }

    //print
    for ( int i = 0 ; i < height ; i ++ )
    {
        for ( int j = 0 ; j < width ; j ++ )
        {
            if ( map[i][j] == 7 ) printf ("-");
            else if ( map[i][j] == 6 ) printf ("|");
            else if ( map[i][j] == 3 ) printf (" ");
            else if ( map[i][j] == 1 ) printf ("P");
            else if ( map[i][j] == 2 ) printf ("I");
            else if ( map[i][j] == 4 ) printf ("C");
            else if ( map[i][j] == 5 ) printf ("R");
        }
        printf ("\n");
    }
    
    //move
    char input = 0;
    printf ("Please input the action: ");    
    scanf (" %c", &input);
    if ( input == 'W' || input == 'w' ) map[mani-1][manj] = 1, map[mani-2][manj+1] = 2, map[mani][manj] = 3, mani-=1;
    if ( (input == 'S' || input == 's') && map[mani+1][manj] == 3 ) map[mani+1][manj] = 1, map[mani][manj+1] = 2, map[mani-1][manj] = 3, mani+=1;
    if ( (input == 'A' || input == 'a') && map[mani][manj-1] == 3 ) map[mani][manj-1] = 1, map[mani][manj] = 3, map[mani-1][manj] = 2, manj-=1;
    if ( (input == 'D' || input == 'd') && map[mani][manj+1] == 3 ) map[mani][manj+1] = 1, map[mani][manj] = 3, map[mani-1][manj] = 3, map[mani-1][manj+2] = 2, map[mani-1][manj] = 3, manj+=1;
    //printf ("%c\n",input );
    
    //print
    for ( int i = 0 ; i < height ; i ++ )
    {
        for ( int j = 0 ; j < width ; j ++ )
        {
            if ( map[i][j] == 7 ) printf ("-");
            else if ( map[i][j] == 6 ) printf ("|");
            else if ( map[i][j] == 3 ) printf (" ");
            else if ( map[i][j] == 1 ) printf ("P");
            else if ( map[i][j] == 2 ) printf ("I");
            else if ( map[i][j] == 4 ) printf ("C");
            else if ( map[i][j] == 5 ) printf ("R");
        }
        printf ("\n");
    }
    

}