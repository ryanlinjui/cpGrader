#include<stdio.h>
#include<stdint.h>

int32_t hit ( int32_t board[16][30], int32_t row, int32_t col );

int32_t hit ( int32_t board[16][30], int32_t row, int32_t col )
{
    int32_t xmove[3] = { -1, 0, 1 };
    int32_t ymove[3] = { -1, 0, 1 };
    int32_t minecount = 0;
     
    if ( row < 0 || row >= 16 || col < 0 || col >= 30 ) return -1;
    
    for ( int i = 0 ; i < 16 ; i ++ )
    {
        for ( int j = 0 ; j < 30 ; j ++ )
        {
            if ( board[i][j] > 8 || board[i][j] < -2 ) return -1;
        }
    }    
    if ( board[row][col] == -2 ) return 1;
    if ( board[row][col] == -1 )
    {
        for ( int i = 0 ; i < 3 ; i ++ )
        {
            for ( int j = 0 ; j < 3 ; j ++ )
            {
                if ( board[row+xmove[i]][col+ymove[j]] == -2 ) minecount++;
            }
        } 
        
        //printf ("%d\n", minecount);
        
        if ( minecount > 0 ) board[row][col] = minecount;
        else
        {
            board[row][col] = 0;
            for ( int i = -1 ; i <= 1 ; i ++ )
            {
                for ( int j = -1 ; j <= 1 ; j ++ )
                {
                    if ( row+i >= 0 && row+i < 16 && col+j >= 0 && col+j < 30 ) hit ( board, row+i, col+j );
                }
            }  
        } 
    }
    
    return 0;
}