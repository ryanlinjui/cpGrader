#include <stdio.h>
#include <stdint.h>

int32_t frac_add (int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d);
int32_t frac_del (int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d);
int32_t frac_mul (int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d);
int32_t frac_div (int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d);

int32_t frac_add (int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d){
    if (x == NULL || y == NULL || (int64_t)a > 2147483647 || (int64_t)a < -2147483647 || (int64_t)b > 2147483647 || (int64_t)b < -2147483647 || (int64_t)c > 2147483647 || (int64_t)c < -2147483647 || (int64_t)d > 2147483647 || (int64_t)d < -2147483647 || b == 0 || d == 0){
        return -1;
    }
    *x = a * d + c * b;
    *y = b * d;
    //reduce
    if (*x > *y){
        for (int32_t i = *x; i > 0; i--){
            if (*x % i == 0 && *y % i == 0){
                *x = *x / i;
                *y = *y / i;
            }
        }
    }
    else{
        for (int32_t i = *y; i > 0; i--){
            if (*x % i == 0 && *y % i == 0){
                *x = *x / i;
                *y = *y / i;
            }
        }
    }
    if (*x == 0){
        *y = 1;
    }
    if (*x < 0 && *y < 0){
        *x = -*x;
        *y = -*y;
    }
    if ((int64_t)*x > 2147483647 || (int64_t)*x < -2147483647 || (int64_t)*y > 2147483647 || (int64_t)*y < -2147483647){
        return -1;
    }
    return 0;
}

int32_t frac_del (int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d){
    if (x == NULL || y == NULL || (int64_t)a > 2147483647 || (int64_t)a < -2147483647 || (int64_t)b > 2147483647 || (int64_t)b < -2147483647 || (int64_t)c > 2147483647 || (int64_t)c < -2147483647 || (int64_t)d > 2147483647 || (int64_t)d <= -2147483647 || b == 0 || d == 0){
        return -1;
    }
    *x = a * d - b * c;
    *y = b * d;
    if (*x > *y){
        for (int32_t i = *x; i > 0; i--){
            if (*x % i == 0 && *y % i == 0){
                *x = *x / i;
                *y = *y / i;
            }
        }
    }
    else{
        for (int32_t i = *y; i > 0; i--){
            if (*x % i == 0 && *y % i == 0){
                *x = *x / i;
                *y = *y / i;
            }
        }
    }
    if ((int64_t)*x > 2147483647 || (int64_t)*x < -2147483647 || (int64_t)*y > 2147483647 || (int64_t)*y < -2147483647){
        return -1;
    }
    if (*x == 0){
        *y = 1;
    }
    if (*x < 0 && *y < 0){
        *x = -*x;
        *y = -*y;
    }
    return 0;
}

int32_t frac_mul (int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d){
    if (x == NULL || y == NULL || (int64_t)a > 2147483647 || (int64_t)a < -2147483647 || (int64_t)b > 2147483647 || (int64_t)b < -2147483647 || (int64_t)c > 2147483647 || (int64_t)c < -2147483647 || (int64_t)d > 2147483647 || (int64_t)d < -2147483647 || b == 0 || d == 0){
        return -1;
    }
    *x = a * c;
    *y = b * d;
    if (*x > *y){
        for (int32_t i = *x; i > 0; i--){
            if (*x % i == 0 && *y % i == 0){
                *x = *x / i;
                *y = *y / i;
            }
        }
    }
    else{
        for (int32_t i = *y; i > 0; i--){
            if (*x % i == 0 && *y % i == 0){
                *x = *x / i;
                *y = *y / i;
            }
        }
    }
    if ((int64_t)*x > 2147483647 || (int64_t)*x < -2147483647 || (int64_t)*y > 2147483647 || (int64_t)*y < -2147483647){
        return -1;
    }
    if (*x == 0){
        *y = 1;
    }
    if (*x < 0 && *y < 0){
        *x = -*x;
        *y = -*y;
    }
    return 0;
}

int32_t frac_div (int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d){
    if (x == NULL || y == NULL || (int64_t)a > 2147483647 || (int64_t)a < -2147483647 || (int64_t)b > 2147483647 || (int64_t)b < -2147483647 || (int64_t)c > 2147483647 || (int64_t)c < -2147483647 || (int64_t)d > 2147483647 || (int64_t)d < -2147483647 || b == 0 || d == 0){
        return -1;
    }
    *x = a * d;
    *y = b * c;
    if (*x > *y){
        for (int32_t i = *x; i > 0; i--){
            if (*x % i == 0 && *y % i == 0){
                *x = *x / i;
                *y = *y / i;
            }
        }
    }
    else{
        for (int32_t i = *y; i > 0; i--){
            if (*x % i == 0 && *y % i == 0){
                *x = *x / i;
                *y = *y / i;
            }
        }
    }
    if ((int64_t)*x > 2147483647 || (int64_t)*x < -2147483647 || (int64_t)*y > 2147483647 || (int64_t)*y < -2147483647){
        return -1;
    }
    if (*x == 0){
        *y = 1;
    }
    if (*x < 0 && *y < 0){
        *x = -*x;
        *y = -*y;
    }
    return 0;
}

