#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int32_t hum_h = 0;
int32_t hum_w = 0;

void build_world(char **map, int hei, int wid){   // 1.1 初始地圖
    for (int32_t i = 0; i < hei; i++){
        for (int32_t j = 0; j < wid; j++){
            if (i == 0 || i == (hei - 1)){
                map[i][j] = '-';
            }
            else if (j == 0 || j == (wid - 1)){
                map[i][j] = '|';
            }
            else{
                map[i][j] = ' ';
            }
        }
    }
}

void set_map(char **map, int32_t hei, int32_t wid){
    int32_t player_num = 4;
    int32_t obs = 0;
    obs = round((double)(hei * wid) / 40);
    int32_t h = 0;
    int32_t w = 0;
    for (int32_t i = 0; i < player_num; i++){    // 1.1.1 玩家設置
        h = (rand() % (hei - 3)) + 2;
        w = (rand() % (wid - 2)) + 1;
        if (i == 0){
            map[h][w] = 'P';
            map[h - 1][w] = 'I';
            hum_h = h;
            hum_w = w;
        }
        else{
            if (map[h][w] != ' ' || map[h - 1][w] != ' '){
                while (1){
                    h = (rand() % (hei - 3)) + 2;
                    w = (rand() % (wid - 2)) + 1;
                    if (map[h][w] == ' ' && map[h - 1][w] == ' ')
                        break;
                }
                map[h][w] = 'C';
                map[h - 1][w] = 'I';
            }
            else{
                map[h][w] = 'C';
                map[h - 1][w] = 'I';
            }
        }
    }
    for (int i = 0; i < obs; i++){   // 1.1.2 障礙物設置
        while (1){
            h = (rand() % (hei - 3)) + 2;
            w = (rand() % (wid - 2)) + 1;
            if (map[h][w] == ' ')
                break;
        }
        map[h][w] = 'R';
    }
}

void human_move(char **map, char act){
    switch (act){
    case 'W':
        if (map[hum_h - 1][hum_w] == '|' || map[hum_h - 1][hum_w] == '-' || map[hum_h - 1][hum_w] == 'R')
            break;
        else{
            map[hum_h][hum_w] = ' ';
            hum_h -= 1;
            map[hum_h][hum_w] = 'P';
            break;
        }
    case 'A':
        if (map[hum_h][hum_w - 1] == '|' || map[hum_h][hum_w - 1] == '-' || map[hum_h][hum_w - 1] == 'R')
            break;
        else{
            map[hum_h][hum_w] = ' ';
            hum_w -= 1;
            map[hum_h][hum_w] = 'P';
        }
    case 'S':
        if (map[hum_h + 1][hum_w] == '|' || map[hum_h + 1][hum_w] == '-' || map[hum_h + 1][hum_w] == 'R')
            break;
        else{
            map[hum_h][hum_w] = ' ';
            hum_h += 1;
            map[hum_h][hum_w] = 'P';
        }
    case 'D':
        if (map[hum_h][hum_w + 1] == '|' || map[hum_h][hum_w + 1] == '-' || map[hum_h][hum_w + 1] == 'R')
            break;
        else{
            map[hum_h][hum_w] = ' ';
            hum_w += 1;
            map[hum_h][hum_w] = 'P';
        }
    case 'R':
        break;
    }
}

int main(){
    int32_t hei = 0;
    int32_t wid = 0;
    printf("Please input the height of the map: ");
    scanf("%d", &hei);
    if (hei < 4){
        printf("the height is too short!\n");
        return 0;
    }
    printf("Please input the width of the map: ");
    scanf("%d", &wid);
    if (wid < 6){
        printf("invalid width\n");
        return 0;
    }

    char **map = (char **)malloc(hei * sizeof(char *));
    for (int32_t i = 0; i < hei; i++){
        map[i] = (char *)malloc(wid * sizeof(char));
    }

    build_world(map, hei, wid);
    srand(time(0));
    set_map(map, hei, wid);

    for (int32_t i = 0; i < hei; i++){   // 1.2.1 顯示初始化地圖
        for (int32_t j = 0; j < wid; j++){
            printf("%c", map[i][j]);
        }
        printf("\n");
    }

    char act;
    while (1){
        printf("Please input the action: ");
        scanf(" %c", &act);  // 注意這裡的空格，以避免吸收上一次的換行符

        human_move(map, act);

        for (int32_t i = 0; i < hei; i++){   // 1.2.1 顯示初始化地圖
            for (int32_t j = 0; j < wid; j++){
                printf("%c", map[i][j]);
            }
            printf("\n");
        }
    }

    for (int32_t i = 0; i < hei; i++){
        free(map[i]);
    }
    free(map);

    return 0;
}