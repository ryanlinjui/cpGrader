#include <stdio.h>
#include <stdint.h>

#define ROW 16
#define COL 30

int32_t check (int32_t board[ROW][COL], int32_t row, int32_t col);
int32_t hit( int32_t board[ROW][COL], int32_t row, int32_t col );