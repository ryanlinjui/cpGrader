#include <stdio.h>
#include <stdint.h>

#define ROW  16
#define COL  30

int32_t check (int32_t board[ROW][COL], int32_t row, int32_t col);
int32_t hit (int32_t board[ROW][COL], int32_t row, int32_t col);
int32_t count = 0;

int32_t check (int32_t board[ROW][COL], int32_t row, int32_t col){
    count = 0;
    for (int32_t i = row-1; i < row+2; i++){
        if (i >= ROW){
            break;
        }
        if (i < 0){
            i++;
        }
        for (int32_t j = col-1; j < col+2; j++){
            if (j >= COL){
                break;
            }
            if (j < 0){
                j++;
            }
            if (board[i][j] == -2){
                count++;
            }
        }
    }
    board[row][col] = count;
    return count;
}

int32_t hit (int32_t board[ROW][COL], int32_t row, int32_t col){
    //return -1
    if (row >= ROW || col >= COL || row < 0 || col < 0){
        return -1;
    }
    for (int32_t i = 0; i < ROW; i++){
        for (int32_t j = 0; j < COL; j++){
            if (board[i][j] != -1 && board[i][j] != -2){
                count = 0;
                for (int32_t a = i-1; a < i+2 && i-1 >= 0 && i+2 < ROW; i++){
                    for (int32_t b = j-1; b < j+2 && j-1 >= 0 && j+2 < COL; j++){
                        if (board[a][b] == -2){
                            count++;
                        }
                    }
                }
                if (count != board[i][j]){
                    return -1;
                }
            }
        }
    }

    //return 1
    if (board[row][col] == -2){
        return 1;
    }

    //surrounding mines
    count = 0;
    for (int32_t i = row-1; i < row+2 && row-1 >= 0 && row+2 < ROW; i++){
        for (int32_t j = col-1; j < col+2 && col-1 >= 0 && col+2 < COL; j++){
            if (board[i][j] == -2){
                count++;
            }
        }
    }
    if (count != 0){
        board[row][col] = count;
        return 0;
    }

    //no surrounding mine
    count = 0;
    for (int32_t i = row-1; i < row+2; i++){
        if (i >= ROW){
            break;
        }
        if (i < 0){
            i++;
        }
        for (int32_t j = col-1; j < col+2; j++){
            if (j >= COL){
                break;
            }
            if (j < 0){
                j++;
            }
            count = check(board, i, j);
            printf("count = %d\n", count);
        }
    }
    return 0;
}