#ifndef DICEROLLS_H
#define DICEROLLS_H
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

int32_t hit( int32_t board[16][30], int32_t row, int32_t col );



#endif