Name: 吳俊廷
Student ID: 41247032S

## How to build the program?
Open the terminal and type "make" to build the program.
