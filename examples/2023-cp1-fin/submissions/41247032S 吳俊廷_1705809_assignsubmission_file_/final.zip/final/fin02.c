#include <assert.h>
#include "mine.h"

void debug_show_board(int32_t board[16][30]){
    printf("board:\n");
    for (int32_t i = 0; i < 16; i++){
        for (int32_t j = 0; j < 30; j++){
            printf("%d ", board[i][j]);
        }
        printf("\n");
    }
}


void test_hit() {
    int32_t board[16][30];

    // 初始化 board
    for (int i = 0; i < 16; i++) {
        for (int j = 0; j < 30; j++) {
            board[i][j] = -1;
            
        }
    }


    board[0][2] = -2; // 有地雷
    board[0][3] = -2;
    board[1][1] = -2;
    board[2][1] = -2;
    board[3][2] = -2;

    debug_show_board(board);
    printf("Return: %d\n",hit(board, 2, 4));
    debug_show_board(board);
    
}

int main() {
    test_hit();
    printf("All tests passed.\n");
    return 0;
}