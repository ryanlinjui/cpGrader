#include "mine.h"
// Minesweeper is a logic puzzle video game genre generally played on personal computers and
// I think that I do not need to teach you how to play this game right? Figure 1 is an example
// of the game screen.
// A player selects a cell to open it. If a player opens a mined cell, the game ends. Otherwise,
// the opened cell displays either a number, indicating the number of mines diagonally and/or
// adjacent to it, or a blank tile (or ”0”), and all adjacent non-mined cells will automatically
// be opened. For your simplicity, the board size is fixed to 16 × 30.
// You need to implement a function to print the board result after hitting a given position.
// The user will input the board, which is a 16×30 two-dimensional array. Each element should
// be -1 or -2 where -1 implies there is no mine at that position and -2 implies there is a mine
// at that position. The user also input two int32_t, row and col, to indicate the hit position,
// which is board[row][col]. You need to modify the board array to the board result after
// hitting a position.

// board: game board. If the cell is a mine , the value is -2; otherwise , -1.
// row, col: implies hitting board[row][col].
// Note that the row and col should start from the top left corner and start
// from 0.
// Return -1 if the input is invalid and return 1 is hit the mine; otherwise
// return 0.

void open_surrounding_blocks(int32_t board[16][30], int32_t row, int32_t col) {
    if (row < 0 || row >= 16 || col < 0 || col >= 30 || board[row][col] != -1) {
        return;
    }

    int32_t count = 0;
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (row + i >= 0 && row + i < 16 && col + j >= 0 && col + j < 30 && board[row + i][col + j] == -2) {
                count++;
            }
        }
    }

    board[row][col] = count;

    if (count == 0) {
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                open_surrounding_blocks(board, row + i, col + j);
            }
        }
    }
}

int32_t hit(int32_t board[16][30], int32_t row, int32_t col) {
    for (int i = 0; i < 16; i++) {
        for (int j = 0; j < 30; j++) {
            if (board[i][j] != -2 && board[i][j] != -1) {
                if(board[i][j] >8 || board[i][j] < 0){
                    return -1;
                }
                
            }
        }
    }

    if (row < 0 || row >= 16 || col < 0 || col >= 30) {
        return -1;
    }

    if (board[row][col] == -2) {
        return 1;
    }

    open_surrounding_blocks(board, row, col);

    return 0;
}