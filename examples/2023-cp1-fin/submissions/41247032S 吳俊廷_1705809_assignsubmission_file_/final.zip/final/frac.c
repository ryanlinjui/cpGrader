#include "frac.h"

// 分數加法
int32_t frac_add( int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d ) {
    if (b == 0 || d == 0) {
        return -1; 
    }
    frac_simplify(x, y);
    *x = a*d + b*c;
    *y = b*d;
    frac_simplify(x, y);
    return 0;
}

// 分數減法
int32_t frac_del( int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d ) {
    if (b == 0 || d == 0) {
        return -1; 
    }
    frac_simplify(x, y);
    *x = a*d - b*c;
    *y = b*d;
    frac_simplify(x, y);
    return 0;
}

// 分數乘法
int32_t frac_mul( int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d ) {
    if (b == 0 || d == 0) {
        return -1;
    }
    frac_simplify(x, y);
    *x = a*c;
    *y = b*d;
    frac_simplify(x, y);
    return 0;
}

// 分數除法
int32_t frac_div( int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d ) {
    if (b == 0 || d == 0) {
        return -1;
    }
    frac_simplify(x, y);
    *x = a*d;
    *y = b*c;
    frac_simplify(x, y);
    return 0;
}

int32_t gcd(int32_t a, int32_t b) {
    while (b != 0) {
        int32_t t = b;
        b = a % b;
        a = t;
    }
    return a;
}

int32_t frac_simplify( int32_t *x, int32_t *y ) {
    int32_t g = gcd(abs(*x), abs(*y));
    *x /= g;
    *y /= g;
    return 0;
}


//忘記處理負數的狀況了
// int32_t frac_simplify( int32_t *x, int32_t *y ) {
//     int32_t i;
//     int32_t min = *x < *y ? *x : *y;
//     for ( i = 2; i <= min; i++ ) {
//         if ( *x % i == 0 && *y % i == 0 ) {
//             *x /= i;
//             *y /= i;
//             i = 1;
//         }
//     }
//     return 0;
// }