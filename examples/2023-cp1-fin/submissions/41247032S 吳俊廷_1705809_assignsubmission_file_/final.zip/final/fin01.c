#include <stdio.h>
#include "frac.h"
int main(){
    int x=0;
    int y=0;
    int a;
    int b;
    int c;
    int d;
    scanf("%d%d%d%d",&a,&b,&c,&d);
    printf("Add return:%d\n",frac_add(&x,&y,a,b,c,d));
    printf("x=%d y=%d\n",x,y);
    printf("Del return:%d\n",frac_del(&x,&y,a,b,c,d));
    printf("x=%d y=%d\n",x,y);
    printf("Mul return:%d\n",frac_mul(&x,&y,a,b,c,d));
    printf("x=%d y=%d\n",x,y);
    printf("Div return:%d\n",frac_div(&x,&y,a,b,c,d));
    printf("x=%d y=%d\n",x,y);

    return 0;
}