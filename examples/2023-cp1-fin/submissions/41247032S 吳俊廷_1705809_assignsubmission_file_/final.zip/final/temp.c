#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include <time.h>


long long map_height;//地圖高度
long long map_width;//地圖寬度

long long gox[]={99,0,1,1, 1, 0,-1,-1,-1,0,1};
long long goy[]={99,-1,-1,0,1,1,1,0,-1,-1,-1};

long long now_map[1000][1000]={0};//目前地圖 -1=障礙物 0=空地

long long mode;//遊戲模式 0=basic 1=advanced
char action;//玩家動作

//width=10 height=5
//  0123456789
// 0+--------+
// 1|        |
// 2|        |
// 3|        |
// 4+--------+

struct tank{
    long long x;
    long long y;
    long long face_direction;
    /*
    812
    7P3
    654
    */
};

struct bullet{
    long long avalible;
    long long exist_time;
    long long x;
    long long y;
    long long face_direction;
};

struct tank enemy[3];//敵人共有3人
struct bullet enemy_bullet[3][1];//敵人子彈共有3人 每人最多1發
struct bullet player_bullet;//玩家子彈共有1發

struct tank player;
//選擇遊戲模式
void choose_mode(){
    printf("Please choose the mode:\n");
    printf("0: Basic\n");
    printf("1: Advanced\n");
    printf("Your choice: ");
    scanf("%lld", &mode);
    if(mode!=0 && mode!=1){
        printf("Invalid input!\n");
        choose_mode();
    }
}

//輸入地圖大小
void input_map_size(){
    printf("Please input the height of the map: ");
    scanf("%lld", &map_height);
    printf("Please input the width of the map: ");
    scanf("%lld", &map_width);
    if(map_height<=0 || map_width<=0){
        printf("Invalid map size input!\n");
        input_map_size();
    }
}

//確認是否是敵方坦克位置
int is_enemy_tank(long long x, long long y){
    for(int i=0; i<3; i++){
        if(enemy[i].x == x && enemy[i].y == y){
            return 1;
        }
    }
    return 0;
}

//隨機生成障礙物
void generate_obstacle(){
    long long obstacle_num = (map_height*map_width)/40;
    for(long long i=0;i<obstacle_num;i++){
        long long obstacle_x, obstacle_y;
        do {
            obstacle_x = rand()%(map_width-2)+1;
            obstacle_y = rand()%(map_height-2)+1;
        } while (now_map[obstacle_y][obstacle_x] != 0 || (obstacle_x == player.x && obstacle_y == player.y) || is_enemy_tank(obstacle_x, obstacle_y));

        now_map[obstacle_y][obstacle_x] = -1;
    }
}


//隨機產生玩家初始位置x=(1~map_width-2) y=(1~map_height-2
void generate_player_position(){
    player.x = rand()%(map_width-2)+1;
    player.y = rand()%(map_height-2)+1;
    player.face_direction = 1;
}



//隨機產生敵人初始位置x=(1~map_width-2) y=(1~map_height-2
void generate_enemy_position(){
    for(long long i=0;i<3;i++){
        enemy[i].x = rand()%(map_width-2)+1;
        enemy[i].y = rand()%(map_height-2)+1;
        enemy[i].face_direction = rand()%8+1;
    }
}

//輸入動作(1=W 2=A 3=S 4=D 5=R,6=Q, 7=Invalid)
int ask_action(){
    printf("Please input the action:\n");
    
    scanf("%s", &action);
    //printf("DEBUG:%c\n", action);
    if(action=='W'){
        return 1;
    }else if(action=='A'){
        return 2;
    }else if(action=='S'){
        return 3;
    }else if(action=='D'){
        return 4;
    }else if(action=='R'){
        return 5;
    }else if(action=='Q'){
        return 6;
    }else{
        printf("Invalid action!\n");
        return 7;
    }

}

//顯示地圖
void show_map(){
    printf("\n");
    for(long long i=0;i<map_height;i++){
        for(long long j=0;j<map_width;j++){
            // 玩家子彈
            if(player_bullet.avalible && i == player_bullet.y && j == player_bullet.x){
                printf("o");
            }
            else if(i==0 || i==map_height-1){
                printf("-");
            }
            else if(j==0 || j==map_width-1){
                printf("|");
            }
            else if(now_map[i][j]==-1){
                printf("R");
            }else if(i==player.y && j==player.x){
                printf("P");
            }
            else if(i==player.y-1 && j==player.x && player.face_direction==1){
                printf("I");
            }
            else if(i==player.y-1 && j==player.x+1 && player.face_direction==2){
                printf("I");
            }
            else if(i==player.y && j==player.x+1 && player.face_direction==3){
                printf("I");
            }
            else if(i==player.y+1 && j==player.x+1 && player.face_direction==4){
                printf("I");
            }
            else if(i==player.y+1 && j==player.x && player.face_direction==5){
                printf("I");
            }
            else if(i==player.y+1 && j==player.x-1 && player.face_direction==6){
                printf("I");
            }
            else if(i==player.y && j==player.x-1 && player.face_direction==7){
                printf("I");
            }else if(i==player.y-1 && j==player.x-1 && player.face_direction==8){
                printf("I");
            }else{
                int isEnemy = 0;
                for(int k=0; k<10; k++){
                    if(i==enemy[k].y && j==enemy[k].x){
                        printf("E");
                        isEnemy = 1;
                        break;
                    }
                    else if(i==enemy[k].y-1 && j==enemy[k].x && enemy[k].face_direction==1){
                        printf("I");
                        isEnemy = 1;
                        break;
                    }
                    else if(i==enemy[k].y-1 && j==enemy[k].x+1 && enemy[k].face_direction==2){
                        printf("I");
                        isEnemy = 1;
                        break;
                    }
                    else if(i==enemy[k].y && j==enemy[k].x+1 && enemy[k].face_direction==3){
                        printf("I");
                        isEnemy = 1;
                        break;
                    }
                    else if(i==enemy[k].y+1 && j==enemy[k].x+1 && enemy[k].face_direction==4){
                        printf("I");
                        isEnemy = 1;
                        break;
                    }
                    else if(i==enemy[k].y+1 && j==enemy[k].x && enemy[k].face_direction==5){
                        printf("I");
                        isEnemy = 1;
                        break;
                    }
                    else if(i==enemy[k].y+1 && j==enemy[k].x-1 && enemy[k].face_direction==6){
                        printf("I");
                        isEnemy = 1;
                        break;
                    }
                    else if(i==enemy[k].y && j==enemy[k].x-1 && enemy[k].face_direction==7){
                        printf("I");
                        isEnemy = 1;
                        break;
                    }else if(i==enemy[k].y-1 && j==enemy[k].x-1 && enemy[k].face_direction==8){
                        printf("I");
                        isEnemy = 1;
                        break;
                    }
                }
                if(!isEnemy){
                    printf(" ");
                }
            }
        }
        printf("\n");
    }
}

//旋轉玩家方向
void rotate_player(){
    if(player.face_direction==8){
        player.face_direction=1;
    }else{
        player.face_direction++;
    }
}

//旋轉敵人方向
void rotate_enemy(){
    for(int i=0; i<3; i++){
        if(enemy[i].x == -1){
            continue;
        }
        if(enemy[i].face_direction==8){
            enemy[i].face_direction=1;
        }else{
            enemy[i].face_direction++;
        }
    }
}

//檢查位置是否合法 0=不合法 1=合法
int check_position(long long x, long long y){
    //printf("DEBUG:%lld %lld\n", x, y);
    if(x<1 || x>=map_width-1 || y<1 || y>=map_height-1){
        return 0;
    }
    if(now_map[y][x]==-1){
        return 0;
    }
    return 1;
}


//所有敵人移動
void all_enemy_move(){
    for(int i=0; i<3; i++){
        if(enemy[i].x == -1){
            continue;
        }
        long long new_x = enemy[i].x;
        long long new_y = enemy[i].y;
        long long new_go_direction = rand()%8+1; // 隨機選擇一個方向
        long long go_direction = new_go_direction; // 更新敵人的方向
        if(go_direction==1){
            new_y--;
        }else if(go_direction==2){
            new_x--;
        }else if(go_direction==3){
            new_y++;
        }else if(go_direction==4){
            new_x++;
        }else if(go_direction==5){
            new_x++;
            new_y--;
        }else if(go_direction==6){
            new_x++;
            new_y++;
        }else if(go_direction==7){
            new_x--;
            new_y++;
        }else if(go_direction==8){
            new_x--;
            new_y--;
        }

        if(check_position(new_x, new_y)){
            enemy[i].x = new_x;
            enemy[i].y = new_y;
        }
    }

}

//玩家射擊
void player_shoot(){
    
    if(player_bullet.avalible==0){
        long long new_bullet_x=player.x+gox[player.face_direction+1]*2;
        long long new_bullet_y=player.y+goy[player.face_direction+1]*2;
        if(check_position(new_bullet_x,new_bullet_y)){
            player_bullet.avalible = 1;
            player_bullet.exist_time = 0;
            player_bullet.face_direction = player.face_direction+1;
            player_bullet.x=new_bullet_x;
            player_bullet.y=new_bullet_y;

            if(now_map[player_bullet.y][player_bullet.x]==-1){
                now_map[player_bullet.y][player_bullet.x]=0;
                player_bullet.avalible=0;
            }
        }
    }

    printf("DEBUG:avail: %lld\n", player_bullet.avalible);
    printf("DEBUG:%lld\n", player_bullet.exist_time);
    printf("DEBUG:player.x: %lld\n",player.x);
    printf("DEBUG:player.y: %lld\n",player.y);
    printf("DEBUG:player_bullet.x %lld\n", player_bullet.x);
    printf("DEBUG:player_bullet.y %lld\n", player_bullet.y);
    printf("DEBUG:direction %lld\n", player_bullet.face_direction);
    
}



//計算玩家砲彈時間和移動子彈
void count_player_bullet_time(){
    if(player_bullet.avalible==1){
        player_bullet.exist_time++;
        if(player_bullet.exist_time>10){
            player_bullet.avalible=0;
        }        
    }
}

void move_player_bullet(){
    if(player_bullet.avalible==1){
        long long next_bullet_x=player_bullet.x+gox[player_bullet.face_direction];
        long long next_bullet_y=player_bullet.y+goy[player_bullet.face_direction];
        player_bullet.x=next_bullet_x;
        player_bullet.y=next_bullet_y;
        if(now_map[player_bullet.y][player_bullet.x]==-1){
            now_map[player_bullet.y][player_bullet.x]=0;
            player_bullet.avalible=0;
        }
    }
    
}

int main(){
    srand( time(NULL) );
    choose_mode();
    input_map_size();
    generate_player_position();
    generate_enemy_position();
    generate_obstacle();

    if(mode==0){
        show_map();
        while(ask_action()>0){
            long long new_x = player.x;
            long long new_y = player.y;
            count_player_bullet_time();
            move_player_bullet();

            if(action=='W'){
                new_y--;
            }else if(action=='A'){
                new_x--;
            }else if(action=='S'){
                new_y++;
            }else if(action=='D'){
                new_x++;
            }else if(action=='Q'){
                player_shoot();
            }

            if(check_position(new_x, new_y)){
                player.x = new_x;
                player.y = new_y;
            }

            rotate_player();
            all_enemy_move();
            rotate_enemy();
            show_map();
        }
    }
    

    return 0;
}