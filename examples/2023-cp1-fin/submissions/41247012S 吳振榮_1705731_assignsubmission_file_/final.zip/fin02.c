#include <stdio.h>
#include <stdint.h>
#include "mine.h"
int main(){
    // int32_t board[4][5] = { {-1,-1,-1,-2,-1},{-1,-2,-1,-1,-1},{-1,-2,-1,-1,-1},{-1,-1,-2,-1,-1} };
    int32_t board[16][30] = { {-1,-1,-1,-2,-1},{-1,-2,-1,-1,-1},{-1,-2,-1,-1,-1},{-1,-1,-2,-1,-1} };
    hit(board, 2, 4);
    for(int32_t i = 0;i < 4;i++){
        for(int32_t j = 0;j < 5;j++){
            printf("%d ", board[i][j]);
        }
        printf("\n");
    }

    return 0;
}