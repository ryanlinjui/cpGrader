#include <stdio.h>
#include <stdint.h>
#include "frac.h"
int main(){
    int32_t x, y;
    int32_t a = -1, b = -11, c = -4, d = -19;  // 1/2 + 1/3 的例子

    int32_t res = frac_del(&x, &y, a, b, c, d);

    // 輸出結果
    printf("Result: %d/%d\n", x, y);

    return 0;
}