#ifndef _FRAC_H_
#define _FRAC_H_
#include <stdio.h>
#include <stdint.h>
int32_t check(int32_t board[16][30], int32_t row, int32_t col);
int32_t hit( int32_t board[16][30], int32_t row, int32_t col );
// int32_t check(int32_t board[4][5], int32_t row, int32_t col);
// int32_t hit( int32_t board[4][5], int32_t row, int32_t col );

#endif