#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#define OBS_MAX 1600
int32_t dx[10] = {0, 1, 1, 1, 0, -1, -1, -1}, dy[10] = {1, 1, 0, -1, -1, -1, 0, 0};
int32_t turnx[10] = {0, 1, 1, 1, 0, -1, -1, -1}, turny[10] = {1, 1, 0, -1, -1, -1, 0, 0};
int32_t obs_amount;
struct Obstacle{
    int32_t x, y;
}obs[OBS_MAX];

struct Player{
    int32_t x, y;
    int32_t muzzle;
    int32_t cycle;
    int32_t cannon;
    int32_t cannon_x, cannon_y;
    int32_t before;
}player;

struct Computer{
    int32_t x, y;
    int32_t muzzle;
    int32_t cycle;
    int32_t cannon;
    int32_t cannon_x, cannon_y;
    int32_t before;
}computer[3];

void init(int32_t width, int32_t height){
    obs_amount = (int32_t)((width * height) / 40);
    player.x = (rand() % (width - 1)) + 1;
    player.y = (rand() % (height - 1)) + 1;
    player.muzzle = rand() % 8;
    player.cycle = player.muzzle;
    player.before = player.muzzle;
    player.cannon = 0;
    player.cannon_x = player.x + dx[player.muzzle];
    player.cannon_y = player.y + dy[player.muzzle];
    for(int32_t i = 0;i < 3;i++){
        computer[i].x = (rand() % (width - 1)) + 1;
        computer[i].y = (rand() % (height - 1)) + 1;
        computer[i].muzzle = (rand() % 8);
        computer[i].cycle = computer[i].muzzle;
        computer[i].cannon = 0;
        computer[i].cannon_x = computer[i].x + dx[computer[i].muzzle];
        computer[i].cannon_y = computer[i].y + dy[computer[i].muzzle];
        computer[i].before = computer[i].muzzle;
    }
    for(int32_t i = 0;i < obs_amount;i++){
        obs[i].x = (rand() % (width - 1)) + 1;
        obs[i].y = (rand() % (height - 1)) + 1;
    }
}
void draw(int32_t width, int32_t height){
    printf("\033[2J");
    for(int32_t i = 0;i < width;i++){
        printf("-");
    }
    printf("\n");
    for(int32_t i = 0;i < height;i++){
        printf("|");
        int32_t space = 1;
        for(int32_t j = 1;j < width - 1;j++){
            for(int32_t c = 0;c < 3;c++){
                if(computer[c].x == j && computer[c].y == i){
                    printf("C");
                    space = 0;
                }
                else if(computer[c].x + dx[computer[c].muzzle] == j && computer[c].y + dy[computer[c].muzzle] == i){
                    printf("I");
                    space = 0;
                }
                if(computer[c].cannon >= 1 && computer[c].cannon_x == j && computer[c].cannon_y == i){
                    printf("o");
                    space = 0;
                }
            }
            if(player.x == j && player.y == i){
                printf("P");
                space = 0;
            }
            else if(player.x + dx[player.muzzle] == j && player.y + dy[player.muzzle] == i){
                printf("I");
                space = 0;
            }
            if(player.cannon >= 1 && player.cannon_x == j && player.cannon_y == i){
                printf("o");
                space = 0;
            }
            for(int32_t o = 0;o < obs_amount;o++){
                if(obs[o].x == j && obs[o].y == i){
                    printf("R");
                    space = 0;
                }
            }
            if(space) printf(" ");
            space = 1;
        }
        printf("|\n");
    }
    for(int32_t i = 0;i < width;i++){
        printf("-");
    }
    printf("\n");
}

void collision(int32_t x, int32_t y){
    for(int32_t i = 0;i < obs_amount;i++){
        if(obs[i].x == x && obs[i].y == y){
            obs[i].x = -1;
            obs[i].y = -1;
        }
    }
    for(int32_t i = 0;i < 3;i++){
        if(computer[i].cannon_x == player.x && computer[i].cannon_y == player.y){
            player.x = -1;
            player.y = -1;
        }
    }
}
void computer_control(int32_t width, int32_t height){
    for(int32_t i = 0;i < 3;i++){
        // if(computer[i].x + dx[rand() % 8] < width - 2 && computer[i].x + dx[rand() % 8] >= 2)
            computer[i].x += dx[rand() % 8];
        // if(computer[i].y = dy[rand() % 8] < height - 2 && computer[i].y + dy[rand() % 8] >= 2)
            computer[i].y += dy[rand() % 8];
        computer[i].cycle = (computer[i].cycle == 7 ? 0 : computer[i].cycle + 1);
        computer[i].muzzle = computer[i].cycle;
        computer[i].cannon++;
        collision(computer[i].x, computer[i].y);
        collision(computer[i].x + dx[computer[i].muzzle], computer[i].y + dy[computer[i].muzzle]);
        if(computer[i].cannon <= 10){
            computer[i].cannon_x += dx[computer[i].before];
            computer[i].cannon_y += dy[computer[i].before];
            collision(computer[i].cannon_x, computer[i].cannon_y);
            if(computer[i].cannon_x >= width - 1 || computer[i].cannon_y >= height - 1 || computer[i].cannon_x <= 1 || computer[i].cannon_y <= 1)
                computer[i].before = (computer[i].before + 4) % 8;
        }
        else{
            computer[i].before = computer[i].muzzle;
            computer[i].cannon_x = computer[i].x + dx[computer[i].muzzle];
            computer[i].cannon_y = computer[i].y + dy[computer[i].muzzle];
            computer[i].cannon = 0;
        }
    }

}
void human_collision(int32_t x, int32_t y){
    for(int32_t i = 0;i < obs_amount;i++){
        if(obs[i].x == x && obs[i].y == y){
            obs[i].x = -1;
            obs[i].y = -1;
        }
    }
}
void human_action(char action, int32_t width, int32_t height){
    if(action == 'W'){
        if(player.y - 1 > 0) player.y--;
    }
    else if(action == 'A'){
        if(player.x - 1 > 0) player.x--;
    }
    else if(action == 'S'){
        if(player.y + 1 < height - 1) player.y++;
    }
    else if(action == 'D'){
        if(player.x + 1 < width - 1) player.x++;
    }
    else if(action == 'Q'){
        if(player.cannon > 0) return;
        else{
            player.cannon++;
            // if(player.cannon <= 10){
            //     player.cannon_x += dx[player.before];
            //     player.cannon_y += dy[player.before];
            //     collision(player.cannon_x, player.cannon_y);
            //     if(player.cannon_x >= width - 1 || player.cannon_y >= height - 1 || player.cannon_x <= 1 || player.cannon_y <= 1)
            //         player.before = (player.before + 4) % 8;
            // }
        }
    }
    else if(action == 'R'){
        return;
    }
}

int main(){
    srand(time(NULL));
    int32_t width, height;
    printf("Please input the height of the map: ");
    scanf("%d", &height);
    printf("Please input the width of the map: ");
    scanf("%d", &width);
    init(width, height);
    while(1){
        draw(width, height);
        char action;
        printf("Please input the action: ");
        printf("\n");
        scanf("%c", &action);
        human_action(action, width, height);
        human_collision(player.x, player.y);
        human_collision(player.x + dx[player.muzzle], player.y + dy[player.muzzle]);
        player.cycle = (player.cycle == 7 ? 0 : player.cycle + 1);
        player.muzzle = player.cycle;
        if(player.cannon == 0) player.before = player.muzzle;
        else if(player.cannon > 0 && player.cannon <= 10){
            player.cannon++;
            player.cannon_x += dx[player.before];
            player.cannon_y += dy[player.before];
            collision(player.cannon_x, player.cannon_y);
            if(player.cannon_x >= width - 1 || player.cannon_y >= height - 1 || player.cannon_x <= 1 || player.cannon_y <= 1)
                player.before = (player.before + 4) % 8;
        }
        if(player.cannon > 10){
            player.cannon = 0;
        }
        computer_control(width, height);
        usleep(1000000);
    }

    return 0;
}