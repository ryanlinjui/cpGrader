# Computer Programming I Final
## Author
- 我是資工系116級的吳振榮，學號是41247012S。

## Overview
台師大資工程式設計(一)期末考，共4+1道題目。

## Build and Run
Run `make` to compile my code.
```shell
$ make
```
After compiling the program, you can execute fin01 code by entering `./fin01` in the terminal, and the remaining programs follow the same pattern.
```shell
$ ./fin01
$ ./fin02
$ ./fin03
$ ./fin04
$ ./fin05
```