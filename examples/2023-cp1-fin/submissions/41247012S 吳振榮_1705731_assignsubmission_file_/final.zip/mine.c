#include "mine.h"
int32_t check(int32_t board[16][30], int32_t row, int32_t col){ // check how many mine in the block
    int32_t dx[10] = {1, 0, -1, 0, 1, -1, 1, -1}, dy[10] = {0, 1, 0, -1, 1, -1, -1, 1};
    int32_t mine = 0;
    for(int32_t i = 0;i < 8;i++){
        if(dy[i] + row >= 0 && dy[i] + row <= 15 && dx[i] + col >= 0 && dx[i] + col <= 29){
            if(board[dy[i] + row][dx[i] + col] == -2) mine++;
        }
    }
    return mine;
}

int32_t hit( int32_t board[16][30], int32_t row, int32_t col ){
    if(row < 0 || row >= 16 || col < 0 || col >= 30) return -1;
    for(int32_t i = 0;i < 16;i++){
        for(int32_t j = 0;j < 30;j++){
            if(board[i][j] != -1 && board[i][j] != -2){
                int32_t res = check(board, i, j);
                if(res != board[i][j]) return -1;
            }
        }
    }
    if(board[row][col] == -2) return 1;
    if(board[row][col] != -1) return 0;
    int32_t dx[10] = {1, 0, -1, 0, 1, -1, 1, -1}, dy[10] = {0, 1, 0, -1, 1, -1, -1, 1};
    int32_t num = check(board, row, col);
    // printf("num: %d\n", num);
    // printf("row: %d col: %d\n", row, col);
    if(num > 0) board[row][col] = num;
    else if(num == 0){
        board[row][col] = 0;
        for(int32_t i = 0;i < 8;i++){
            if(dy[i] + row >= 0 && dy[i] + row <= 15 && dx[i] + col >= 0 && dx[i] + col <= 29){
                hit(board, dy[i] + row, dx[i] + col);
            }
        }
    }
    return 0;
}

// #include "mine.h"
// int32_t check(int32_t board[4][5], int32_t row, int32_t col){ // check how many mine in the block
//     int32_t dx[10] = {1, 0, -1, 0, 1, -1, 1, -1}, dy[10] = {0, 1, 0, -1, 1, -1, -1, 1};
//     int32_t mine = 0;
//     for(int32_t i = 0;i < 8;i++){
//         if(dy[i] + row >= 0 && dy[i] + row <= 3 && dx[i] + col >= 0 && dx[i] + col <= 4){
//             if(board[dy[i] + row][dx[i] + col] == -2) mine++;
//         }
//     }
//     return mine;
// }

// int32_t hit( int32_t board[4][5], int32_t row, int32_t col ){
//     if(row < 0 || row >= 4 || col < 0 || col >= 5) return -1;
//     for(int32_t i = 0;i < 4;i++){
//         for(int32_t j = 0;j < 5;j++){
//             if(board[i][j] != -1 && board[i][j] != -2){
//                 int32_t res = check(board, i, j);
//                 if(res != board[i][j]) return -1;
//             }
//         }
//     }
//     if(board[row][col] == -2) return 1;
//     if(board[row][col] != -1) return 0;
//     int32_t dx[10] = {1, 0, -1, 0, 1, -1, 1, -1}, dy[10] = {0, 1, 0, -1, 1, -1, -1, 1};
//     int32_t num = check(board, row, col);
//     // printf("num: %d\n", num);
//     // printf("row: %d col: %d\n", row, col);
//     if(num > 0) board[row][col] = num;
//     else if(num == 0){
//         board[row][col] = 0;
//         for(int32_t i = 0;i < 8;i++){
//             if(dy[i] + row >= 0 && dy[i] + row <= 3 && dx[i] + col >= 0 && dx[i] + col <= 4){
//                 hit(board, dy[i] + row, dx[i] + col);
//             }
//         }
//     }
//     return 0;
// }