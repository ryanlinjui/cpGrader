#include "frac.h"

int32_t gcd(int32_t a, int32_t b){
    while(b != 0){
        int32_t temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

void simplify_fraction(int32_t *numerator, int32_t *denominator){
    int32_t common = gcd(*numerator, *denominator);
    *numerator /= common;
    *denominator /= common;
}

int32_t frac_add( int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d ){
    if(b == 0 || d == 0) return -1;
    int32_t common_denominator = b * d;
    *x = a * d + c * b;
    *y = common_denominator;
    simplify_fraction(x, y);
    if(*y < 0 && *x > 0){
        *x = -(*x);
        *y = -(*y);
    }
    return 0;
}

int32_t frac_del(int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d){
    if(b == 0 || d == 0) return -1;
    int32_t common_denominator = b * d;
    *x = a * d - c * b;
    *y = common_denominator;
    simplify_fraction(x, y);
    if(*y < 0 && *x > 0){
        *x = -(*x);
        *y = -(*y);
    }
    return 0;
}

int32_t frac_mul(int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d){
    if(b == 0 || d == 0) return -1;
    *x = a * c;
    *y = b * d;
    simplify_fraction(x, y);
    if(*y < 0 && *x > 0){
        *x = -(*x);
        *y = -(*y);
    }
    return 0;
}

int32_t frac_div(int32_t *x, int32_t *y, int32_t a, int32_t b, int32_t c, int32_t d){
    if(b == 0 || d == 0) return -1;
    *x = a * d;
    *y = b * c;
    simplify_fraction(x, y);
    if(*y < 0 && *x > 0){
        *x = -(*x);
        *y = -(*y);
    }
    return 0;
}