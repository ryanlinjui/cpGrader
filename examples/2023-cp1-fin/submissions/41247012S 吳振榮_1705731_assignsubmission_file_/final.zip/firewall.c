#include "firewall.h"
#define MAX_RULES 100

// Rule array
static int32_t (*rules[MAX_RULES])(const uint8_t *, const int32_t,
                                   uint8_t **, int32_t *);

// Function to set a rule at a specific index in the rule array
int32_t set_rule(int32_t idx, int32_t (*rule)(const uint8_t *,
                                              const int32_t,
                                              uint8_t **,
                                              int32_t *)) {
    if(idx < 0 || idx >= MAX_RULES || rule == NULL){
        return -1; // Invalid input
    }

    rules[idx] = rule;
    return 0;
}

// Function to unset a rule at a specific index in the rule array
int32_t unset_rule(int32_t idx){
    if(idx < 0 || idx >= MAX_RULES){
        return -1; // Invalid input
    }

    rules[idx] = NULL;
    return 0;
}

// Function to apply all rules on input packets and store output packets
int32_t filter(const uint8_t *p_input_packets, const int32_t input_size, uint8_t **pp_output_packets, int32_t *p_output_size){
    if(p_input_packets == NULL || input_size <= 0 || pp_output_packets == NULL || p_output_size == NULL){
        return -1; // Invalid input
    }

    // Initialize output variables
    *pp_output_packets = NULL;
    *p_output_size = 0;

    // Loop through each packet in the input
    for(int32_t i = 0; i < input_size; i += sizeof(uint32_t) * 2 + sizeof(uint16_t) + p_input_packets[i + sizeof(uint32_t) * 2]){
        const uint8_t *current_packet = p_input_packets + i;

        // Apply each rule on the current packet
        for(int32_t j = 0; j < MAX_RULES && rules[j] != NULL; ++j){
            int32_t result = rules[j](current_packet, sizeof(uint32_t) * 2 + sizeof(uint16_t) + p_input_packets[i + sizeof(uint32_t) * 2], pp_output_packets, p_output_size);

            if(result == 1) break;
            else if(result == -1) break;
        }
    }

    return 0;
}