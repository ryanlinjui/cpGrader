# Final

41247039S 韓欣劭

Computer Programming (I)

## Notes for fin04

* If the cannon hit the muzzle, I considered the situation as died.
* Upper case and lower case of same letter are both considered as same action.
* Right angle cannonball does not stop for 1 frame, please consider this as a feature.
* Destroy all enemy tanks or dead will end the game.
