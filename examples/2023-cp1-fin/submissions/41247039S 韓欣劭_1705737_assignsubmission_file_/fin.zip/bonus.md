# BONUS: Comments

I've no idea what comments that I can provide, so maybe I write what I am doing for the whole process of the exam.

* 09:50 - Ready
* 10:00 - Exam start
* 10:00 - Find easy questions to start with
* 10:00 - Read q1
* 10:01 - Do q1
* 10:18 - Done q1, maybe
* 10:19 - Read q2
* 10:21 - Do q2
* 10:47 - Done q2, maybe
* 10:47 - Read q3
* 10:52 - What the hell is q3
* 11:04 - Fix q1
* 11:10 - Continue q3
* 11:32 - Done q3, maybe
* 11:34 - Fix q1
* 11:35 - Fix q2
* 11:40 - Do q4
* 12:07 - Upload my files
* 13:11 - Eat something
* 14:28 - Segmentation fault
* 15:18 - Done q4 player's parts
* 15:18 - Upload my files
* 15:44 - Done q4 some of computer's parts
* 15:47 - Upload my files
* 15:49 - Give up and write something here
* 15:50 - Upload my files
* 16:00 - Exam end
