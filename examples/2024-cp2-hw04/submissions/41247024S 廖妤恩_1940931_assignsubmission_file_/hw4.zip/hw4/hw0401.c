#include<stdio.h>
#include<stdint.h>
#include<unistd.h>
#include<getopt.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<dirent.h>

static double hertz;

void printinfo( int32_t this )
{
    DIR *dp;
    struct dirent *drip;
    dp = opendir("/proc");
    //printf("%lf\n",hertz);
    FILE *upfile = fopen("/proc/uptime","r");
    char *temp = calloc(1025,sizeof(char));
    fgets(temp,1025,upfile);
    double uptime = strtod(temp,NULL);
    //printf("%lf\n",uptime);
    while((drip = readdir(dp)))
    {
        int32_t pid = 0;
        for ( int32_t i = 0 ; i < strlen(drip->d_name) ; i ++ )
        {
            if ( (drip->d_name[i] >= 'A' && drip->d_name[i] <= 'Z') || (drip->d_name[i] >= 'a' && drip->d_name[i] <= 'z') ) break;
            //printf("%c", drip->d_name[i]);
            pid = pid*10 + drip->d_name[i] - 48;
        }
        if ( pid <= 0 ) continue;
        if ( this != -1 && pid != this ) continue;
        char *place = calloc(1025,sizeof(char));
        strcpy(place,"/proc/");
        sprintf(place+strlen(place),"%d",pid);
        strcpy(place+strlen(place),"/stat");
        FILE * a = fopen(place,"r");
        char *in = calloc(1025,sizeof(char));
        double utime = 0;
        double stime = 0;
        double cutime = 0;
        double cstime = 0;
        double starttime = 0;
        double cpu = 0;
        while( fgets(in,1025,a) != NULL )
        {
            int32_t count = 0;
            int32_t namesite = 0;
            char name[1025];
            char type[2];
            int32_t mem = 0;
            char *u = calloc(1025,sizeof(char));
            char *s = calloc(1025,sizeof(char));
            char *cu = calloc(1025,sizeof(char));
            char *cs = calloc(1025,sizeof(char));
            char *st = calloc(1025,sizeof(char));
            char *me = calloc(1025,sizeof(char));
            for ( int32_t i = 0 ; i < strlen(in) ; i ++ )
            {
                if ( in[i] == ' ')
                {
                    count++;
                    continue;
                }
                if ( in[i] == '(' ) continue;
                else if ( in[i] == ')' ) name[namesite] = '\0';
                else if ( count == 1 )
                {
                    name[namesite] = in[i];
                    namesite++;
                }
                if ( count == 2 )
                {
                    type[0] = in[i];
                    type[1] = '\0';
                    continue;
                }
                else if ( count == 13 ) u[strlen(u)] = in[i];
                else if ( count == 14 ) s[strlen(s)] = in[i];
                else if ( count == 15 ) cu[strlen(cu)] = in[i];
                else if ( count == 16 ) cs[strlen(cs)] = in[i];
                else if ( count == 21 ) st[strlen(st)] = in[i];
                else if ( count == 22 ) me[strlen(me)] = in[i];
            }
            utime = atoi(u);
            stime = atoi(s);
            cutime = atoi(cu);
            cstime = atoi(cs);
            starttime = atoi(st);
            mem = atoi(me);
            //printf("%s\n",in);
            cpu = (((utime+stime+cutime+cstime)*100/hertz)/(uptime-(starttime/hertz)));
            printf("%-6d%5s%-39s%-4s%12.2lf%%%8s%-13d\n",pid," ",name,type,cpu," ",(int)mem);
            free(u);
            free(s);
            free(cu);
            free(cs);
            free(st);
            free(me);
            //printf("%s %s %d %lf %lf %lf %lf %lf %lf\n",name,type,mem,utime,stime,cutime,cstime,starttime,cpu);
        }
        //printf("%d\n",pid);
        //printf("%s\n", drip->d_name);
        fclose(a);
        free(place);
        free(in);
    }
    closedir(dp);
    fclose(upfile);
}

struct option opts[] =
{
    {"help",0,NULL,'h'},
    {"time-interval",1,NULL,'t'},
    {"count",1,NULL,'c'},
    {"pid",1,NULL,'p'}
};

int main( int argc, char *argv[] )
{
    int32_t c;
    char *optstring = "ht:c:p:";
    int32_t hcount = 0;
    int32_t tcount = 0;
    int32_t ccount = 0;
    int32_t pcount = 0;
    int32_t num = -1;
    double time = 5;
    int32_t skip = -1;
    hertz = sysconf(_SC_CLK_TCK);
    char *number = calloc(1025,sizeof(char));
    char *timee = calloc(1025,sizeof(char));
    char *ppid = calloc(1025,sizeof(char));
    while (  ( c = getopt_long( argc, argv , optstring, opts , NULL) ) != -1 )
    {
        switch(c)
        {
            case'h':
                hcount++;
                break;

            case't':
                tcount++;
                strcpy(timee,optarg);
                break;

            case'c':
                ccount++;
                strcpy(number,optarg);
                break;

            case'p':
                pcount++;
                strcpy(ppid,optarg);
                break;

            default:
                printf("Invalid command, please input again.\n");
                return 0;
        }
    }
    if ( hcount > 0 )
    {
        printf("Usage: hw0401 [options]\n");
        printf("-t, --time-interval=time  Update the information every [time] seconds. Default: 5 seconds.\n");
        printf("-c, --count  Update the information [count] times. Default: infinite.\n");
        printf("-p, --pid=pid  Only display the given process information.\n");
        printf("-h, --help  Display this information and exit.\n");
        free(number);
        free(timee);
        return 0;
    }
    if ( tcount > 0 )
    {
        time = strtod(timee,NULL);
        if ( time <= 0 )
        {
            printf("Wrong input.\n");
            return 0;
        }
    }
    if ( ccount > 0 ) num = atoi(number);
    if ( pcount > 0 ) skip = atoi(ppid);
    //printf("time %d num %d\n",time,num);
    //printf("%6s%5s%s%20s%5s%5s%10s%s\n","PID","","NAME","STATE","","CPU","","MEM");
    if ( num == -1 )
    {
        while(1)
        {
            system("clear");
            printf("%-6s%5s%s%40s%5s%5s%10s%s\n","PID","","NAME","STATE","","CPU","","MEM");
            printinfo(skip);
            usleep(1000000*time);
        }
    }
    else
    {
        for ( int32_t i = 0 ; i < num+1 ; i ++ )
        {
            //printf("\e[1;1H\e[2J");
            system("clear");
            printf("%-6s%5s%s%40s%5s%5s%10s%s\n","PID","","NAME","STATE","","CPU","","MEM");
            printinfo(skip);
            usleep(1000000*time);
        }
    }
    free(number);
    free(timee);
    free(ppid);
}