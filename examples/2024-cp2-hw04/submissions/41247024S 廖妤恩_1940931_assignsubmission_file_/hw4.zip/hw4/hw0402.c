#include<stdio.h>
#include<stdint.h>
#include<unistd.h>
#include<getopt.h>
#include<string.h>
#include<stdlib.h>
#include<curl/curl.h>
#include<time.h>
#include<assert.h>

void specify_output( char *jq, char *outputname, int32_t index )
{
    char place[200];
    strcpy(place,"jq \".[");
    sprintf(place+strlen(place),"%d",index-1);
    strcpy(place+strlen(place),"].");
    strcpy(place+strlen(place),jq);
    strcpy(place+strlen(place),"\" ./a.json");
    FILE *a = popen ( place, "r" );
    char *in = calloc(1025,sizeof(char));
    fgets(in,1025,a);
    printf("%s: ",outputname);
    if ( in[strlen(in)-1] == 0 )  in[strlen(in)-1] = 10;
    if ( strcmp ( outputname, "Station Name" ) == 0 || strcmp ( outputname, "Address" ) == 0 ) for ( int32_t j = 1 ; j < strlen(in)-2 ; j ++ ) printf("%c",in[j]);
    else if ( strcmp ( outputname, "Available Bikes" ) == 0 ) for ( int32_t j = 0 ; j < strlen(in)-1 ; j ++ ) printf("%c",in[j]);
    else if ( strcmp( outputname, "Available Parking Slots") == 0 ) for ( int32_t j = 0 ; j < strlen(in)-1 ; j ++ ) printf("%c",in[j]);    
    else for ( int32_t j = 1 ; j < strlen(in)-2 ; j ++ ) printf("%c",in[j]);
    printf("\n");
    fclose(a);
    free(in);
}

void printn( char *target, uint64_t num, char *theme, int32_t condition )
{
    int32_t total = 0;
    int32_t record[10];
    int32_t x = 0;
    char place[200];
    FILE *b;
    char *in2 = calloc(1025,sizeof(char));
    strcpy(place,"jq \".[] | .");
    strcpy(place+strlen(place),theme);
    strcpy(place+strlen(place),"\" a.json");
    FILE *a = popen( place, "r" );
    //FILE *a = popen ( "jq \".[] | .snaen\" a.json", "r" );
    char *in = calloc(1025,sizeof(char));
    if ( condition == 1 ) b = popen( "jq \".[] | .aren\" a.json", "r" );
    int32_t i = 0;
    while ( fgets(in,1025,a) != NULL )
    {
        int32_t add = 0;
        //printf("%s",in);
        if ( condition == 1 )
        {
            fgets(in2,1025,b);
            //printf("%s",in2);
            for ( int32_t j = 0 ; j < strlen(in2) ; j ++ )
            {
                int32_t count = 0;
                for ( int32_t k = 0 ; k < strlen(target) ; k ++ )
                {
                    if ( target[k] == in2[j+k] ) count++;
                    else if ( target[k]-32 == in2[j+k] ) count++;
                    else if ( target[k]+32 == in2[j+k] ) count++;
                    else break;
                }
                if ( count == strlen(target) )
                {
                    add++;
                    break;
                }
            }
        }
        if(!add)
        {
            for ( int32_t j = 0 ; j < strlen(in) ; j ++ )
            {
                int32_t count = 0;
                for ( int32_t k = 0 ; k < strlen(target) ; k ++ )
                {
                    if ( target[k] == in[j+k] ) count++;
                    else if ( target[k]-32 == in[j+k] ) count++;
                    else if ( target[k]+32 == in[j+k] ) count++;
                    else break;
                }
                if ( count == strlen(target) )
                {
                    add++;
                    break;
                }
            }
        }
        i++;
        if ( add != 0 )
        {
            total++;
            //printf("%d\n",i);
            if ( x == 5 ) break;
            else 
            {
                record[x] = i;
                x++;
            }
        }
    }
    fclose(a);
    free(in);
    if ( condition == 1 )
    {
        fclose(b);
        free(in2);
        printf("%d station(s) found with the substring ",total);
        printf("\033[38;2;%d;%d;%dm",255,255,189);
        printf("\"%s\"",target);
        printf("\033[38;2;%d;%d;%dm",255,255,255);
        printf(" in snaen and aren: \n\n");
    }
    else if ( condition == 2 )
    {
        printf("%d station(s) found with the UID substring ",total);
        printf("\033[38;2;%d;%d;%dm",255,255,189);
        printf("\"%s\"",target);
        printf("\033[38;2;%d;%d;%dm",255,255,255);
        printf(" in sno: \n\n");
    }
    for ( int32_t i = 0 ; i < x ; i ++ )
    {
        specify_output( "sno", "UID", record[i] );
        specify_output( "snaen", "Station Name", record[i] );
        specify_output( "aren", "Address", record[i] );
        specify_output( "available_rent_bikes", "Available Bikes", record[i] );
        specify_output( "available_return_bikes", "Available Parking Slots", record[i] );
        specify_output( "updateTime", "Last Update Time", record[i] );
        printf("\n");
    }
}

struct option opts[] =
{
    {"help",0,NULL,'h'},
    {"name",1,NULL,'N'},
    {"uid",1,NULL,'U'}
};

int main( int argc, char *argv[] )
{
    int32_t c;
    char *optstring = "hN:U:";
    CURL *curl;
    CURLcode res;
    curl = curl_easy_init();
    if ( curl )
    {
        curl_easy_setopt( curl, CURLOPT_URL, "https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json");
        FILE *file = fopen("a.json","w");
        assert(file);
        curl_easy_setopt( curl, CURLOPT_WRITEDATA, file );
        res = curl_easy_perform(curl);
        fclose(file);
    }
    char nname[1000];
    int32_t ncount = 0;
    int32_t hcount = 0;
    int32_t ucount = 0;
    while (  ( c = getopt_long( argc, argv , optstring, opts , NULL) ) != -1 )
    {
        switch(c)
        {
            case'h':
                hcount++;
                break;

            case'N':
                ncount++;
                strcpy(nname,optarg);
                break;

            case'U':
                ucount++;
                strcpy(nname,optarg);
                break;

            default:
                printf("Invalid command, please input again.\n");
                return 0;
        }
    }

    if ( hcount > 0 )
    {
        printf("-h Show this help message\n");
        printf("-N <station_name > Search station by name\n");
        printf("-U <uid> Search station by UID\n");
        return 0;
    }
    //length
    FILE *a = popen ("jq \". | length\" a.json","r");
    char *b = calloc(1025,sizeof(char));
    fgets(b,1025,a);
    uint64_t length = atoi(b);
    fclose(a);
    if ( ncount > 0 && ucount > 0 )
    {
        printf("Error input.\n");
        return 0;
    }
    else if ( ncount > 0 )
    {
        printf("( show at most 5 station with the substring ");
        printf("\033[38;2;%d;%d;%dm",255,255,189);
        printf("\"%s\"",nname);
        printf("\033[38;2;%d;%d;%dm",255,255,255);
        printf(" )\n");
        if ( nname[strlen(nname)-1] == '\n' ) nname[strlen(nname)-1] = '\0';
        printn(nname,length,"snaen",1);
    }
    else if ( ucount > 0 )
    {
        printf("( show at most 5 station with the UID string ");
        printf("\033[38;2;%d;%d;%dm",255,255,189);
        printf("\"%s\"",nname);
        printf("\033[38;2;%d;%d;%dm",255,255,255);
        printf(" )\n");
        if ( nname[strlen(nname)-1] == '\n' ) nname[strlen(nname)-1] = '\0';
        printn(nname,length,"sno",2);
    }
    system("rm a.json");
}