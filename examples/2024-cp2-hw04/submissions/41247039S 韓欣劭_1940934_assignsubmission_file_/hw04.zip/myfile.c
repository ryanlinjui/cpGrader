#include "myfile.h"

int32_t openFile(FILE **file, const char *fileName, char *mode) {
    *file = fopen(fileName, mode);

    if (*file == NULL) {
        // perror("myfile: file error");
        return 1;
    }

    return 0;
}

int32_t openProcess(FILE **file, const char *command, const char *mode) {
    *file = popen(command, mode);

    if (*file == NULL) {
        perror("myfile: command error");
        return 1;
    }

    return 0;
}

int32_t readLine(FILE *file, char *buffer, size_t size) {
    if (fgets(buffer, size, file) == NULL) {
        if (fgetc(file) == EOF) {
            printf("myfile: EOF detected\n");
        } else {
            perror("myfile: read error");
        }

        return 1;
    }

    if (buffer[strlen(buffer) - 1] == '\n') {
        buffer[strlen(buffer) - 1] = '\0';
    }

    return 0;
}

void closeFile(FILE *file) {
    if (file == NULL) {
        return;
    }

    fclose(file);
}

void closeProcess(FILE *file) {
    if (file == NULL) {
        return;
    }

    pclose(file);
}
