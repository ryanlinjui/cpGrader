#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>

#include "myfile.h"

typedef struct _Usage {
    char     name[256];
    char     state;
    uint32_t utime;
    uint32_t stime;
    int32_t  cutime;
    int32_t  cstime;
    uint64_t starttime;
    uint32_t vsize;
} Usage;

/**
 * Print the system information.
 * @param times the update interval
 * @param count the update count
 * @param pid the process id
 * @return 0 if the system information is printed successfully, 1 otherwise.
 */
int32_t printSystemInfo(int32_t times, int32_t count, int32_t pid);

/**
 * Print all the processes if the pid is -1, otherwise print the process with the given pid.
 * @param pid the process id
 * @return 0 if all the processes are printed successfully, 1 otherwise.
 */
int32_t printAllProcesses(int32_t pid);

/**
 * Print the process information with the given pid.
 * @param pid the process id
 * @return 0 if the process information is printed successfully, 1 otherwise.
 */
int32_t printProcessInfo(int32_t pid);

/**
 * Get the uptime.
 * @param uptime the uptime
 * @return 0 if the uptime is got successfully, 1 otherwise.
 */
int32_t getUptime(double *uptime);

/**
 * Get the usage of the process with the given pid.
 * @param pid the process id
 * @param usage the usage
 * @return 0 if the usage is got successfully, 1 otherwise.
 */
int32_t getUsage(int32_t pid, Usage *usage);

/**
 * Calculate the CPU usage.
 * @param usage the usage
 * @param uptime the uptime
 * @return the CPU usage.
 */
double calculateCpuUsage(Usage *usage, double uptime);
