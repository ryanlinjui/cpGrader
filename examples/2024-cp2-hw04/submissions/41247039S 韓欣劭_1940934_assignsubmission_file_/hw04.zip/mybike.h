#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <curl/curl.h>

#include "myfile.h"

#define ARR_SIZE 50
#define STR_SIZE 4096
#define PI 3.14159265358979323846L

typedef enum _SearchType {
    SEARCH_NONE = 0,
    SEARCH_BY_NAME_CN,
    SEARCH_BY_NAME_EN,
    SEARCH_BY_UID,
    SEARCH_BY_LAT_LON,
} SearchType;

typedef struct _Search {
    SearchType flag;
    int32_t count;
    char url[STR_SIZE];
    char str[STR_SIZE];
    double lat;
    double lon;
} Search;

typedef struct _BikeStation {
    char uid[STR_SIZE];
    char snacn[STR_SIZE];
    char snaen[STR_SIZE];
    char arcn[STR_SIZE];
    char aren[STR_SIZE];
    char update_time[STR_SIZE];
    double lat;
    double lon;
    int32_t rent_bikes;
    int32_t return_bikes;
} BikeStation;

typedef struct _BikeData {
    BikeStation *stations;
    int32_t size;
} BikeData;

/**
 * Search bike station by the given search type.
 * @param search The search structure
 * @return 0 if success, 1 otherwise
 */
int32_t searchBikeStation(Search *search);

/**
 * Download bike data from the given URL.
 * @param url The URL to download bike data
 * @return 0 if success, 1 otherwise
 */
int32_t downloadBikeData(const char *url);

/**
 * Delete bike data json files.
 * @return 0 if success, 1 otherwise
 */
int32_t deleteBikeFile();

/**
 * Get the size of the JSON array.
 * @param json The JSON string to get the size
 * @param size The size of the JSON array
 * @return 0 if success, 1 otherwise
 */
int32_t getJsonArraySize(const char *json, int32_t *size);

/**
 * Search bike station by the given string.
 * @param keys The keys to search
 * @param size The size of the keys
 * @param value The value to search
 * @return 0 if success, 1 otherwise
 */
int32_t searchByStr(char *keys[], int32_t size, char *value);

/**
 * Search bike station by the given latitude and longitude.
 * @param lat The latitude to search
 * @param lon The longitude to search
 * @return 0 if success, 1 otherwise
 */
int32_t searchByLatLon(double lat, double lon);

/**
 * Calculate the distance between two points.
 * @param shortest The shortest distance
 * @param indexes The indexes of the shortest distance
 * @param index The index of the shortest distance
 * @param lat1 The latitude of the first point
 * @param lon1 The longitude of the first point
 * @param lat2 The latitude of the second point
 * @param lon2 The longitude of the second point
 * @return The distance between two points
 */
int32_t findShortestDistance(double *shortest, int32_t *indexes, int32_t index, double lat1, double lon1, double lat2, double lon2);

/**
 * Add bike data to the given data structure.
 * @param data The data structure to add
 * @return 0 if success, 1 otherwise
 */
int32_t addBikeData(BikeData *data);

/**
 * Print bike data to the standard output.
 * @param data The data structure to print
 * @param count The number of data to print
 */
void printBikeData(BikeData *data, int32_t count);

/**
 * Free bike data from the given data structure.
 * @param data The data structure to free
 */
void freeBikeData(BikeData *data);
