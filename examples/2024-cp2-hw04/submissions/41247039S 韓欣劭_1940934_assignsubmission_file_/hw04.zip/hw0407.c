#include <stdio.h>
#include <tgmath.h>
// #include <math.h>

#define PRINT_SIZE(x) printf("sizeof(" #x ") = %lu\n", sizeof(x))

int main() {
    long double a = 4.5;
    double b = 4.5;
    float c = 4.5;
    float e = 2.0;

    PRINT_SIZE(pow(a, e));
    PRINT_SIZE(pow(b, e));
    PRINT_SIZE(pow(c, e));

    return 0;
}
