#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define F_SIZE 4096

/**
 * Open a file.
 * @param file the file stream pointer.
 * @param fileName the file name
 * @param mode the open mode
 * @return 0 if the file is opened successfully, 1 otherwise
 */
int32_t openFile(FILE **file, const char *fileName, char *mode);

/**
 * Open a process.
 * @param file the file stream pointer.
 * @param command the command
 * @param mode the open mode
 * @return 0 if the process is opened successfully, 1 otherwise
 */
int32_t openProcess(FILE **file, const char *command, const char *mode);

/**
 * Read a line from a file.
 * @param file the file stream pointer
 * @param buffer the buffer to store the line
 * @param size the buffer size
 * @return 0 if the line is read successfully, 1 otherwise
 */
int32_t readLine(FILE *file, char *buffer, size_t size);

/**
 * Close a file.
 * @param file the file stream pointer
 */
void closeFile(FILE *file);

/**
 * Close a process.
 * @param file the file stream pointer
 */
void closeProcess(FILE *file);
