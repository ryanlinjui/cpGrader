#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>

#include "mytop.h"

const char *g_short_opts = "t:c:p:h";
const struct option g_long_opts[] = {
    {"time-iterval", required_argument, NULL, 't'},
    {"count",        required_argument, NULL, 'c'},
    {"pid",          required_argument, NULL, 'p'},
    {"help",         no_argument,       NULL, 'h'},
    {0, 0, 0, 0},
};

const char *g_help_usage = "Usage: hw0401 [options]\n";
const char *g_help_info  = "Try ./hw0401 --help for more information.\n";
const char *g_help_msg   = "\
  -t, --time-interval=time  Update the information every [time] seconds. Default: 5 seconds.\n\
  -c, --count=count         Update the information [count] times. Default: infinite.\n\
  -p, --pid=pid             Only display the given process information.\n\
  -h, --help                Display this infomation and exit\n\
";

int main(int argc, char *argv[]) {
    char c = 0;

    int32_t times = 5;
    int32_t count = -1;
    int32_t pid   = -1;

    while ((c = getopt_long(argc, argv, g_short_opts, g_long_opts, NULL)) != -1) {
        if (c == '?') {
            perror(g_help_usage);
            return EXIT_FAILURE;
        }
        else if (c == 'h') {
            printf("%s%s", g_help_usage, g_help_msg);
            return EXIT_SUCCESS;
        }
        else if (c == 't') {
            times = strtol(optarg, NULL, 10);

            if (times <= 0) {
                printf("hw0401: invalid time interval\n");
                return EXIT_FAILURE;
            }
        }
        else if (c == 'c') {
            count = strtol(optarg, NULL, 10);

            if (count <= -1) {
                printf("hw0401: invalid count\n");
                return EXIT_FAILURE;
            }
        }
        else if (c == 'p') {
            pid = strtol(optarg, NULL, 10);

            if (pid <= 0) {
                printf("hw0401: invalid pid\n");
                return EXIT_FAILURE;
            }
        }
    }

    if (optind < argc) {
        printf("hw0401: warning: extra operand '%s'\n", argv[optind]);
    }

    printSystemInfo(times, count, pid);

    return EXIT_SUCCESS;
}
