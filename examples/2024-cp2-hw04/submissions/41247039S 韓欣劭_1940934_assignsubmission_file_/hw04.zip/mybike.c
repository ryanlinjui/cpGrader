#include "mybike.h"

const char *g_out = "bike_out.json";
const char *g_tmp = "bike_tmp.json";

int32_t searchBikeStation(Search *search) {
    if (search == NULL) {
        fprintf(stderr, "mybike: error: search is NULL\n");
        return 1;
    }

    BikeData data = {NULL, 0};
    int32_t  res  = 0;

    if (downloadBikeData(search->url) != 0) {
        return 1;
    }

    char *keysEN[] = { "snaen", "aren" };
    char *keysCN[] = { "sna", "ar" };
    char *keyUID[] = { "sno" };

    switch (search->flag) {
    case SEARCH_BY_NAME_CN:
        res = searchByStr(keysCN, 2, search->str);
        break;

    case SEARCH_BY_NAME_EN:
        res = searchByStr(keysEN, 2, search->str);
        break;

    case SEARCH_BY_UID:
        res = searchByStr(keyUID, 1, search->str);
        break;

    case SEARCH_BY_LAT_LON:
        res = searchByLatLon(search->lat, search->lon);
        break;

    default:
        fprintf(stderr, "mybike: error: invalid search\n");
        return 1;
    }

    if (res != 0) {
        fprintf(stderr, "mybike: error: search failed\n");
        return 1;
    }

    if (addBikeData(&data) != 0) {
        return 1;
    }

    printBikeData(&data, search->count);
    freeBikeData(&data);

    if (deleteBikeFile() != 0) {
        return 1;
    }

    return 0;
}

int32_t downloadBikeData(const char *url) {
    if (!url) {
        fprintf(stderr, "mybike: error: download bike data failed\n");
        return 1;
    }

    char command[STR_SIZE] = {0};

    printf("Downloading bike data...\n");
    snprintf(command, STR_SIZE, "curl -# %s > %s", url, g_out);

    if (system(command) != 0) {
        fprintf(stderr, "mybike: error: command failed\n");
        return 1;
    }

    return 0;
}

int32_t deleteBikeFile() {
    if (remove(g_out) != 0) {
        fprintf(stderr, "mybike: error: delete bike data failed\n");
        return 1;
    }

    if (remove(g_tmp) != 0) {
        fprintf(stderr, "mybike: error: delete bike data failed\n");
        return 1;
    }

    return 0;
}

int32_t getJsonArraySize(const char *json, int32_t *size) {
    if (!json) {
        fprintf(stderr, "mybike: error: get json array size failed\n");
        return 1;
    }

    FILE *file = NULL;
    char command[STR_SIZE] = {0};
    char *endptr = NULL;

    snprintf(command, STR_SIZE, "jq 'length' %s", json);

    if (openProcess(&file, command, "r") != 0) {
        return 1;
    }

    if (readLine(file, command, STR_SIZE) != 0) {
        closeProcess(file);
        return 1;
    }

    *size = strtol(command, &endptr, 10);

    if (*endptr != '\0') {
        fprintf(stderr, "mybike: error: invalid json array size\n");
        closeProcess(file);
        return 1;
    }

    closeProcess(file);

    return 0;
}

int32_t searchByStr(char *keys[], int32_t size, char *value) {
    if (!keys || !value) {
        fprintf(stderr, "mybike: error: search by string failed\n");
        return 1;
    }

    char command[STR_SIZE] = {0};

    snprintf(command, STR_SIZE, "jq '[.[] | ");

    for (int32_t i = 0; i < size; i++) {
        strncat(command, "select(.", 10);
        strncat(command, keys[i], STR_SIZE);
        strncat(command, "|test(\"", 10);
        strncat(command, value, STR_SIZE);
        strncat(command, "\"; \"gil\"))", 20);

        if (i < size - 1) {
            strncat(command, ", ", 10);
        }
    }

    strncat(command, "]' ", 10);
    strncat(command, g_out, STR_SIZE);
    strncat(command, " > ", 10);
    strncat(command, g_tmp, STR_SIZE);

    if (system(command) != 0) {
        fprintf(stderr, "mybike: error: command failed\n");
        return 1;
    }

    return 0;
}

int32_t searchByLatLon(double lat, double lon) {
    if (lat < -90 || lat > 90 || lon < -180 || lon > 180) {
        fprintf(stderr, "mybike: error: invalid lat/lon\n");
        return 1;
    }

    // Find the number of bike stations

    int32_t size = 0;

    if (getJsonArraySize(g_out, &size) != 0) {
        return 1;
    }

    // Find the shortest 10 distances between the given lat/lon and the bike stations

    FILE *file = NULL;
    char command[STR_SIZE] = {0};
    char buffer[STR_SIZE]  = {0};

    snprintf(command, STR_SIZE, "jq '.[] | .latitude, .longitude' %s", g_out);

    if (openProcess(&file, command, "r") != 0) {
        return 1;
    }

    double shortest[ARR_SIZE] = {0};
    int32_t indexes[ARR_SIZE] = {0};

    for (int32_t i = 0; i < ARR_SIZE; i++) {
        shortest[i] = -1;
    }

    for (int32_t i = 0; i < size; i++) {
        double lat2 = 0;
        double lon2 = 0;

        if (readLine(file, buffer, STR_SIZE) != 0) {
            closeProcess(file);
            return 1;
        }

        lat2 = strtod(buffer, NULL);

        if (readLine(file, buffer, STR_SIZE) != 0) {
            closeProcess(file);
            return 1;
        }

        lon2 = strtod(buffer, NULL);

        findShortestDistance(shortest, indexes, i, lat, lon, lat2, lon2);
    }

    closeProcess(file);

    // Output the shortest 10 distances to a temporary file

    strncpy(command, "jq '[.[", 9);

    char temp[256] = {0};

    for (int32_t i = 0; i < ARR_SIZE; i++) {
        if (indexes[i] == -1) {
            break;
        }

        snprintf(temp, 256, "%d", indexes[i]);

        strncat(command, temp, STR_SIZE);

        if (i < ARR_SIZE - 1) {
            strncat(command, ",", 2);
        }
    }

    strncat(command, "]]' ", 5);
    strncat(command, g_out, STR_SIZE);
    strncat(command, " > ", 4);
    strncat(command, g_tmp, STR_SIZE);

    // printf("%s\n", command);

    if (system(command) != 0) {
        fprintf(stderr, "mybike: error: command failed\n");
        return 1;
    }

    return 0;
}

int32_t findShortestDistance(double *shortest, int32_t *indexes, int32_t index, double lat1, double lon1, double lat2, double lon2) {
    double phi1 = lat1 * PI / 180;
    double phi2 = lat2 * PI / 180;
    double delta_phi    = (lat2 - lat1) * PI / 180;
    double delta_lambda = (lon2 - lon1) * PI / 180;

    double a = sin(delta_phi / 2) * sin(delta_phi / 2) + cos(phi1) * cos(phi2) * sin(delta_lambda / 2) * sin(delta_lambda / 2);
    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    double d = 6371 * c;

    for (int32_t i = 0; i < ARR_SIZE; i++) {
        if (shortest[i] == -1) {
            shortest[i] = d;
            indexes[i]  = index;
            break;
        }

        if (d < shortest[i]) {
            for (int32_t j = ARR_SIZE - 1; j > i; j--) {
                shortest[j] = shortest[j - 1];
                indexes[j]  = indexes[j - 1];
            }

            shortest[i] = d;
            indexes[i]  = index;
            break;
        }
    }

    return 0;
}

int32_t addBikeData(BikeData *data) {
    if (data == NULL) {
        fprintf(stderr, "mybike: error: add bike data failed\n");
        return 1;
    }

    // Find the number of bike stations

    if (getJsonArraySize(g_tmp, &data->size) != 0) {
        return 1;
    }

    const char *keys =
        ".sno, .sna, .ar, .snaen, .aren, .infoTime, .available_rent_bikes, .available_return_bikes, .latitude, .longitude";

    enum {
        UID, SNA, AR, SNAEN, AREN, INFO_TIME, RENT_BIKES, RETURN_BIKES, LATITUDE, LONGITUDE
    };

    int32_t field = 10;

    data->stations = (BikeStation *) calloc(data->size, sizeof(BikeStation));

    if (data->stations == NULL) {
        fprintf(stderr, "mybike: error: add bike data failed\n");
        return 1;
    }

    int32_t idx = 0;

    for (int32_t i = 0; i < data->size; i++) {
        char cmd[STR_SIZE] = {0};
        char buf[STR_SIZE] = {0};

        snprintf(cmd, STR_SIZE, "jq -r '.[%d] | %s' %s", i, keys, g_tmp);

        FILE *file = NULL;

        if (openProcess(&file, cmd, "r") != 0) {
            return 1;
        }

        int32_t flag = 0;

        for (int32_t j = 0; j < field; j++) {
            if (readLine(file, buf, STR_SIZE) != 0) {
                closeProcess(file);
                return 1;
            }

            // Skip the same station

            if (i > 0 && strcmp(data->stations[idx - 1].uid, buf) == 0) {
                flag = 1;
                break;
            }

            // Add the bike station data

            switch (j) {
            case UID:
                strncpy(data->stations[idx].uid, buf, STR_SIZE);
                break;

            case SNA:
                strncpy(data->stations[idx].snacn, buf, STR_SIZE);
                break;

            case AR:
                strncpy(data->stations[idx].arcn, buf, STR_SIZE);
                break;

            case SNAEN:
                strncpy(data->stations[idx].snaen, buf, STR_SIZE);
                break;

            case AREN:
                strncpy(data->stations[idx].aren, buf, STR_SIZE);
                break;

            case INFO_TIME:
                strncpy(data->stations[idx].update_time, buf, STR_SIZE);
                break;

            case RENT_BIKES:
                data->stations[idx].rent_bikes = strtol(buf, NULL, 10);
                break;

            case RETURN_BIKES:
                data->stations[idx].return_bikes = strtol(buf, NULL, 10);
                break;

            case LATITUDE:
                data->stations[idx].lat = strtod(buf, NULL);
                break;

            case LONGITUDE:
                data->stations[idx].lon = strtod(buf, NULL);
                break;

            default:
                break;
            }
        }

        if (flag == 0) {
            idx++;
        }

        closeProcess(file);
    }

    // Update the number of bike stations

    data->size = idx;

    return 0;
}

void printBikeData(BikeData *data, int32_t count) {
    if (data == NULL) {
        fprintf(stderr, "printBikeData() failed\n");
        return;
    }

    if (data->size == 0) {
        printf("No bike stations found\n");
        return;
    }

    int32_t size = (count < data->size) ? count : data->size;

    for (int32_t i = 0; i < size; i++) {
        printf("========================================================================================\n");
        printf("\033[33m[%d/%d] UID: %s\033[0m\n", i + 1, size, data->stations[i].uid);
        printf("----------------------------------------------------------------------------------------\n");
        printf("Station Name (CN) | %s\n", data->stations[i].snacn);
        printf("Address (CN)      | %s\n", data->stations[i].arcn);
        printf("Station Name (EN) | %s\n", data->stations[i].snaen);
        printf("Address (EN)      | %s\n", data->stations[i].aren);
        printf("----------------------------------------------------------------------------------------\n");
        printf("Available Bikes   | %d\n", data->stations[i].rent_bikes);
        printf("Available Spaces  | %d\n", data->stations[i].return_bikes);
        printf("Update Time       | %s\n", data->stations[i].update_time);
        printf("----------------------------------------------------------------------------------------\n");
        printf("Link              |\033[34m https://www.google.com/maps/?q=%f,%f \033[0m\n", 
            data->stations[i].lat, data->stations[i].lon);
    }
    printf("========================================================================================\n");
    printf("Found %d bike stations.", data->size);

    if (size < data->size) {
        printf(" To show more results, please use the -c option.");
    }

    printf("\n");
}

void freeBikeData(BikeData *data) {
    if (!data || !data->stations) {
        return;
    }

    free(data->stations);
    data->stations = NULL;
}
