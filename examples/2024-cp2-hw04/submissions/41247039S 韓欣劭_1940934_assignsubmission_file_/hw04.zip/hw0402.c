#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>

#include "mybike.h"

const char *g_short_opts = "n:N:U:c:h";
const struct option g_long_opts[] = {
    {"snaen",   required_argument, NULL, 'n'},
    {"snacn",   required_argument, NULL, 'N'},
    {"uid",     required_argument, NULL, 'U'},
    {"lat",     required_argument, NULL, 'l'},
    {"lon",     required_argument, NULL, 'L'},
    {"count",   required_argument, NULL, 'c'},
    {"help",    no_argument,       NULL, 'h'},
    {0, 0, 0, 0},
};

const char *g_help_usage = "Usage: ./hw0402 [options]...\n";
const char *g_help_info  = "Try ./hw0402 --help for more information.\n";
const char *g_help_msg   = "\
Options:\n\
    -n, --snaen=station_name_en   Search by English station name or address\n\
    -N, --snacn=station_name_cn   Search by Chinese station name or address\n\
    -U, --uid=station_uid         Search by station UID\n\
\n\
        --lat=latitude            Search the nearest station by latitude\n\
        --lon=longitude           Search the nearest station by longitude\n\
\n\
    -c, --count=number            Show the number of results (default: 5, max: 50)\n\
    -h, --help                    Display this infomation and exit\n\
\n\
--lat and --lon should be used together. -n, -N, -U, --lat, --lon are exclusive.\n\
";

int main(int argc, char *argv[]) {
    Search  search = {0};
    int32_t l_flag = 0;

    char c = 0;
    char *endptr = NULL;

    search.count = 5;

    while ((c = getopt_long(argc, argv, g_short_opts, g_long_opts, NULL)) != -1) {
        if (c == '?') {
            perror(g_help_usage);
            return EXIT_FAILURE;
        }
        else if (c == 'h') {
            printf("%s%s", g_help_usage, g_help_msg);
            return EXIT_SUCCESS;
        }
        else if (c == 'n' || c == 'N' || c == 'U' || c == 'l' || c == 'L') {
            if (search.flag != SEARCH_NONE) {
                fprintf(stderr, "hw0402: error: -n, -N, -U, --lat, --lon are exclusive\n");
                return EXIT_FAILURE;
            }
        }

        if (c == 'n') {
            search.flag = SEARCH_BY_NAME_EN;
        }
        else if (c == 'N') {
            search.flag = SEARCH_BY_NAME_CN;
        }
        else if (c == 'U') {
            search.flag = SEARCH_BY_UID;
        }

        if (c == 'n' || c == 'N' || c == 'U') {
            strncpy(search.str, optarg, STR_SIZE);
        }
        else if (c == 'l') {
            search.lat = strtod(optarg, &endptr);

            if (endptr == NULL) {
                fprintf(stderr, "hw0402: error: invalid latitude\n");
                return EXIT_FAILURE;
            }
            else if (search.lat < -90 || search.lat > 90) {
                fprintf(stderr, "hw0402: error: latitude should be between -90 and 90\n");
                return EXIT_FAILURE;
            }

            l_flag++;
        }
        else if (c == 'L') {
            search.lon = strtod(optarg, &endptr);

            if (endptr == NULL) {
                fprintf(stderr, "hw0402: error: invalid longitude\n");
                return EXIT_FAILURE;
            }
            else if (search.lon < -180 || search.lon > 180) {
                fprintf(stderr, "hw0402: error: longitude should be between -180 and 180\n");
                return EXIT_FAILURE;
            }

            l_flag++;
        }
        else if (c == 'c') {
            search.count = strtol(optarg, &endptr, 10);

            if (endptr == NULL) {
                fprintf(stderr, "hw0402: error: invalid count\n");
                return EXIT_FAILURE;
            }

            if (search.count < 1 || search.count > ARR_SIZE) {
                fprintf(stderr, "hw0402: error: count should be between 1 and %d\n", ARR_SIZE);
                return EXIT_FAILURE;
            }
        }
    }

    if (l_flag == 2) {
        search.flag = SEARCH_BY_LAT_LON;
    }
    else if (l_flag == 1) {
        fprintf(stderr, "hw0402: error: latitude and longitude should be used together\n");
        return EXIT_FAILURE;
    }
    else if (search.flag == SEARCH_NONE && l_flag == 0) {
        fprintf(stderr, "hw0402: error: no search option\n");
        return EXIT_FAILURE;
    }

    if (optind < argc) {
        printf("hw0402: warning: extra operand '%s'\n", argv[optind]);
    }

    const char *url = "https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json";
    strncpy(search.url, url, STR_SIZE);

    if (searchBikeStation(&search) != 0) {
        fprintf(stderr, "searchBikeStation() failed\n");
        return EXIT_FAILURE;
    }

    return 0;
}
