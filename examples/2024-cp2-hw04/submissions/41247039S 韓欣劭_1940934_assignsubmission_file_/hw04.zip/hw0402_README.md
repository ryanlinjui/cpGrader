# How to Rent Your Bike?

This program will find the Youbike stations across Taipei City. Usage:

```console
./hw0402 [options]...
```

Available options:

- `-n` or `--snaen=station_name_en`: search the station by English name or address
- `-N` or `--snacn=station_name_cn`: search the station by Chinese name or address
- `-U` or `--uid=station_uid`: search by the station UID
- `--lat=latitude --lon=longitude`: search the nearest station by latitude and longitude
- `-c` or `--count=number`: show the number of results, default is 5 and maximum is 50
- `-h` or `--help`: display the help message and exit

Features:

- Chinese-friendly: both station name and address are displayed in English and Chinese (Traditional)
- Case-insensitive: uppercase and lowercase are ignored when searcing in English
- Lat-lon search: able to search by latitude and longitude
- Google Maps: the search result will give a link to Google Maps for the bike station
