#include "mytop.h"

int32_t printSystemInfo(int32_t times, int32_t count, int32_t pid) {
    while (1) {
        system("clear");

        if (printAllProcesses(pid)) {
            return 1;
        }

        if (count == 0) {
            break;
        }
        else if (count > 0) {
            count--;
        }

        sleep(times);
    }

    return 0;
}

int32_t printAllProcesses(int32_t pid) {
    DIR *dir = opendir("/proc");

    if (dir == NULL) {
        perror("mytop: opendir error");
        return 1;
    }

    struct dirent *entry = NULL;

    printf("PID     NAME             state   CPU      MEM\n");

    if (pid == -1) {
        while ((entry = readdir(dir)) != NULL) {
            if (strspn(entry->d_name, "0123456789") != strlen(entry->d_name)) {
                continue;
            }

            int32_t currPid = strtol(entry->d_name, NULL, 10);

            if (printProcessInfo(currPid) == 1) {
                closedir(dir);
                return 1;
            }
        }
    }
    else if (printProcessInfo(pid)) {
        printf("mytop: process not found\n");
        closedir(dir);
        return 1;
    }

    closedir(dir);

    return 0;
}

int32_t printProcessInfo(int32_t pid) {
    double uptime = 0;
    Usage  usage  = {0};

    if (getUptime(&uptime)) {
        return 1;
    }

    int32_t u = getUsage(pid, &usage);

    if (u == 1) {
        return 1;
    }
    else if (u == 2) {
        return 2;
    }

    double cpuUsage = calculateCpuUsage(&usage, uptime);

    printf("%-7d %-16s %c     %6.2f%%    %u\n",
        pid, usage.name, usage.state, cpuUsage, usage.vsize);

    return 0;
}

int32_t getUptime(double *uptime) {
    FILE *file = NULL;
    char buffer[F_SIZE] = {0};

    if (openFile(&file, "/proc/uptime", "r")) {
        return 1;
    }

    if (readLine(file, buffer, F_SIZE)) {
        closeFile(file);
        return 1;
    }

    if (sscanf(buffer, "%lf %*f", uptime) != 1) {
        printf("mytop: sscanf error\n");
        closeFile(file);
        return 1;
    }

    closeFile(file);

    return 0;
}

int32_t getUsage(int32_t pid, Usage *u) {
    FILE *file = NULL;

    char cmd[F_SIZE] = {0};
    char buf[F_SIZE] = {0};

    // Find the process name

    snprintf(cmd, F_SIZE, "/proc/%d/comm", pid);

    if (openFile(&file, cmd, "r")) {
        return 2;
    }

    if (readLine(file, u->name, 256)) {
        closeFile(file);
        return 1;
    }

    closeFile(file);

    // Find the process information

    memset(cmd, 0, F_SIZE);
    snprintf(cmd, F_SIZE, "/proc/%d/stat", pid);

    if (openFile(&file, cmd, "r")) {
        return 1;
    }

    if (readLine(file, buf, F_SIZE)) {
        closeFile(file);
        return 1;
    }

    closeFile(file);

    char *format = "%*d %*s %c %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %u %u %d %d %*d %*d %*d %*d %lu %u %*[^\n]";

    int32_t scan = sscanf(buf, format, &u->state, &u->utime, &u->stime, &u->cutime, &u->cstime, &u->starttime, &u->vsize);

    if (scan != 7) {
        printf("mytop: sscanf error\n");
        return 1;
    }

    return 0;
}

double calculateCpuUsage(Usage *usage, double uptime) {
    uint64_t time  = usage->utime + usage->stime + usage->cutime + usage->cstime;
    uint64_t hertz = sysconf(_SC_CLK_TCK);

    double seconds  = uptime - ((double) usage->starttime / hertz);
    double cpuUsage = 100 * (((double) time / hertz) / seconds);

    // Check if CPU usage is nan
    if (cpuUsage != cpuUsage) {
        return 0;
    }

    return cpuUsage;
}
