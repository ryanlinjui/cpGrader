# hw04

Name: 41247039S 韓欣劭

Course: Computer Programming II

Link:

- [Question link](https://drive.google.com/file/d/1BBz1GcqWKvX_-RTRXV_5QUCQeu4MLGMW/view)
- [Additional information](https://hackmd.io/t3q_Hq5fS0GdkwqwioFJzA)

## Table of Contents

- [p1](#p1-system-monitor)
- [p2](#p2-how-to-rent-your-bike)
- [bonuses](#bonuses)

## p1 System Monitor

This program is used to monitor the linux processes. Usage:

```console
./hw0401 [options]...
```

Avaliable options:

- `-t` or `--time-interval=time`: update the information every [time] seconds, default is 5 seconds.
- `-c` or `--count=count`: update the information [count] times, default is infinite.
- `-p` or `--pid=pid`: display only the given process information.
- `-h` or `--help`: display the help message and exit

## p2 How to Rent Your Bike?

This question's readme is written in [hw0402_README.md](hw0402_README.md).

## Bonuses

The bonus question p4, p5, p6 and p7 is written in [hw0404.md](hw0404.md), [hw0405.md](hw0405.md), [hw0406.md](hw0406.md) and [hw0407.md](hw0407.md) respectively.
