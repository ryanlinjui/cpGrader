Name: 吳俊廷
Student ID: 41247032S

## How to build the program?
Open the terminal and type "make" to build the program.

## How to execute your built programs?
Open the terminal and type "./<hw04YY>" to execute the program, which YY is the problem number.
For example, ./hw0202 is the executable program for homework #2 problem 2.

## About hw0402
Please read hw0402_README.md for more information.