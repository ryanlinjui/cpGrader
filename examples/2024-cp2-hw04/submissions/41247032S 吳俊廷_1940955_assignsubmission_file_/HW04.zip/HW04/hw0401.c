/*
top command is used to show the Linux processes. It provides a dynamic real-time view of the running system. You can try this command on your computer. This time, I want you to develop a program similar to top. Do not worry, I will show you how to do this.
The proc filesystem (procfs) is a special filesystem in Unix-like operating systems that presents information about processes and other system information. It provides a more convenient and standardized method for accessing process data held in the kernel than traditional tracing methods or direct access to kernel memory. What you should do is to find all numeric directories in /proc. Each process in your computer will have a directory here and you can get the process information in the directory. For your simplicity, I only want you to read /proc/[pid]/stat. You can read the proc manual1 to know how to parse this file.


$ ./hw0401 --help
Usage: hw0401 [options]
-t, --time-interval=time Update the information every [time] seconds. Default: 5 seconds.
-c, --count Update the information [count] times. Default: infinite.
-p, --pid=pid Only display the given process information.
-h, --help Display this information and exit.
*/

#include <stdio.h>
#include <dirent.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>

struct option long_options[] = {
    {"time-interval", required_argument, 0, 't'},
    {"count", required_argument, 0, 'c'},
    {"pid", required_argument, 0, 'p'},
    {"help", no_argument, 0, 'h'},
    {0, 0, 0, 0}
};


void print_proc_stat(int pid) {
    // Read the system uptime
    FILE *uptime_file = fopen("/proc/uptime", "r");
    if (uptime_file == NULL) {
        perror("fopen uptime_file failed");
        return;
    }
    double uptime;
    fscanf(uptime_file, "%lf", &uptime);
    fclose(uptime_file);

    // Read the process stat
    char path[256];
    sprintf(path, "/proc/%d/stat", pid);
    FILE *file = fopen(path, "r");
    if (file == NULL) {
        perror("fopen");
        return;
    }
    int pid_value;
    char comm[256];
    char state;
    long int utime;
    long int stime;
    long int cutime;
    long int cstime;
    long int vsize;
    long int starttime;
    //printf("DEBUG: uptime=%lf\n", uptime);
    if (fscanf(file, "%d %s %c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %ld %ld %*d %*d %*d %*d %*d %*d %*u %ld %ld", &pid_value, comm, &state, &utime, &stime, &vsize, &starttime) == 7) {
        // Remove parentheses from the process name
        char *name = strtok(comm, "()");
        
        long int total_time = utime + stime;
        double seconds = uptime - (double)starttime / sysconf(_SC_CLK_TCK);
        long int pcpu = 0;
        if (seconds > 0) {
            pcpu = (total_time * 1000 / sysconf(_SC_CLK_TCK)) / seconds;
        }
        printf("%d\t%-40s\t%c\t%ld.%ld\t%ld\n", pid_value, name, state, pcpu / 10, pcpu % 10, vsize);
    }
    fclose(file);
}

int main(int argc, char** argv){

    int option_index = 0;
    int time_interval = 5;
    int count = -1;//-1=infinite
    int pid = -1;

    int c;
    while((c = getopt_long(argc, argv, "t:c:p:h", long_options, &option_index)) != -1) {
        switch(c) {
            case 't':
                time_interval=atoi(optarg);
                if(time_interval<=0){
                    printf("time-interval must be greater than 0\n");
                    return 1;
                }
                break;
            case 'c':
                count=atoi(optarg);
                break;
            case 'p':
                pid=atoi(optarg);
                break;
            case 'h':
                printf("Usage: hw0401 [options]\n");
                printf("  -t, --time-interval=time Update the information every [time] seconds. Default: 5 seconds.\n");
                printf("  -c, --count Update the information [count] times. Default: infinite.\n");
                printf("  -p, --pid=pid Only display the given process information.\n");
                printf("  -h, --help Display this information and exit.\n\n");
                return 0;
            case '?':
                printf("Operation failed\n");
                return 1;
            default:
                return 1;
        }
    }

    // DEBUG
    // printf("time_interval = %d\n", time_interval);
    // printf("count = %d\n", count);
    // printf("pid = %d\n", pid);

    

    if(count==-1){
        while(1){
            printf("PID\tNAME                                    \tstate\tCPU\tMEM\n");
            if (pid == -1) {
                //讀取/proc下的所有數字目錄
                DIR *dir = opendir("/proc");
                if (dir == NULL) {
                    perror("opendir faild");
                    return 1;
                }
                struct dirent *entry;
                while ((entry = readdir(dir)) != NULL) {
                    int pid = atoi(entry->d_name);
                    if (pid > 0) {
                        print_proc_stat(pid);
                    }
                }

                closedir(dir);
            } else {
                print_proc_stat(pid);
            }
            sleep(time_interval);
            system("clear");
        }
    }else{
        for(int i=0;i<count+1;i++){
            printf("PID\tNAME                                    \tstate\tCPU\tMEM\n");
            if (pid == -1) {
                //讀取/proc下的所有數字目錄
                DIR *dir = opendir("/proc");
                if (dir == NULL) {
                    perror("opendir faild");
                    return 1;
                }
                struct dirent *entry;
                while ((entry = readdir(dir)) != NULL) {
                    int pid = atoi(entry->d_name);
                    if (pid > 0) {
                        print_proc_stat(pid);
                    }
                }

                closedir(dir);
            } else {
                print_proc_stat(pid);
            }
            sleep(time_interval);
            system("clear");
        }
    }
    return 0;
}