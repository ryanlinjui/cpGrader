#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <getopt.h>
#include <dirent.h>
#include <math.h>
#include <curl/curl.h>

struct option long_options[] = {
    {"uid", required_argument, 0, 'u'},
    {"taipei", no_argument, 0, 'T'},
    {"help", no_argument, 0, 'h'},
    {0, 0, 0, 0}
};




bool uidExist(int uid){
    char cmd[256];
    char buffer[512];
    sprintf(cmd, "cat youbike_immediate.json | jq '.[][] | select(.sno==\"%d\")' ", uid);
    FILE *pJSON = popen(cmd, "r");
    while(fgets(buffer, sizeof(buffer), pJSON) != NULL) {
        pclose(pJSON);
        return true;
    }
    pclose(pJSON);
    return false;
}

//Find the region of the uid, 1=New Taipei, 2=Taipei, 0=uid is invalid
int uidRegion(int uid){
    if(uidExist(uid) == false){
        return 0;
    }
    
    if(uid > 500201000||uid < 2000){
        return 1;
    }else{
        return 2;
    }
}


int main(int argc, char** argv){
    int option_index = 0;
    int c;
    int isOnlyTaipei=0;

    int mode = 0;
    int uid = -1;
    while((c = getopt_long(argc, argv, "Tu:h", long_options, &option_index)) != -1) {
        switch(c) {
            case 'u':
                mode = 1;
                uid = atoi(optarg);
                break;
            case 'T':
                isOnlyTaipei = 1;
                break;
            case 'h':
                printf("Usage: hw0402 [options]\n");
                printf("  -u, --uid=<uid>   Search by [uid].\n");
                printf("  -T, --taipei      Search only in Taipei.\n");
                printf("  -h, --help        Display this information and exit.\n\n");
                return 0;
            case '?':
                printf("Operation failed\n");
                return 1;
            default:
                printf("Undefined action\n");
                return 1;
        }
    }
    //printf("DEBUG: mode = %d\n", mode);
    //printf("DEBUG: uid = %d\n", uid);

    

    FILE *pJSON = NULL;
    CURL *curl;
    CURLcode res;
    char buffer[512];

    /*Download Taipei Ubike API Data*/
    printf("Fetching Taipei Ubike data...");
    curl = curl_easy_init();
    if(curl) {
        curl_easy_setopt(curl, CURLOPT_URL, "https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json");
        
        FILE *pfile = fopen("youbike_Taipei_immediate.json", "w");
        
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, pfile);

        res = curl_easy_perform(curl);

        if(res != CURLE_OK) {
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
        }
        curl_easy_cleanup(curl);
        fclose(pfile);
    }
    printf("Done!\n");
    
    if(isOnlyTaipei != 1){
        /*Download New Taipei Ubike 2.0 API Data*/
        //printf("ddd\n");
        printf("Fetching New Taipei Ubike 2.0 data...");
        curl = curl_easy_init();
        if(curl) {
            curl_easy_setopt(curl, CURLOPT_URL, "https://data.ntpc.gov.tw/api/datasets/010e5b15-3823-4b20-b401-b1cf000550c5/json?size=5000");
            
            FILE *pfile = fopen("youbike_New_Taipei_immediate.json", "wa");
            
            curl_easy_setopt(curl, CURLOPT_WRITEDATA, pfile);

            res = curl_easy_perform(curl);

            if(res != CURLE_OK) {
                fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
            }
            curl_easy_cleanup(curl);

            fclose(pfile);
        }
        printf("Done!\n");

        /*Download New Taipei Ubike 1.0 API Data*/
        printf("Fetching New Taipei Ubike 1.0 data...");
        curl = curl_easy_init();
        if(curl) {
            curl_easy_setopt(curl, CURLOPT_URL, "https://data.ntpc.gov.tw/api/datasets/71cd1490-a2df-4198-bef1-318479775e8a/json?size=10000");
            
            FILE *pfile = fopen("youbike_New_Taipei_immediate_v1.json", "wa");
            
            curl_easy_setopt(curl, CURLOPT_WRITEDATA, pfile);

            res = curl_easy_perform(curl);

            if(res != CURLE_OK) {
                fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
            }
            curl_easy_cleanup(curl);
            fclose(pfile);
        }
        printf("Done!\n");

        /*Merge json files*/
        printf("Merging json files...");
        pJSON = popen("jq -s '[.[]]' youbike_Taipei_immediate.json youbike_New_Taipei_immediate.json youbike_New_Taipei_immediate_v1.json", "r");
        FILE *pfile = fopen("youbike_immediate.json", "w");
        while(fgets(buffer, sizeof(buffer), pJSON) != NULL) {
            fprintf(pfile, "%s", buffer);
        }
        pclose(pJSON);
        fclose(pfile);
        //system("rm youbike_Taipei_immediate.json");
        //system("rm youbike_New_Taipei_immediate.json");
        //system("rm youbike_New_Taipei_immediate_v1.json");
        printf("Done!\n\n");
    }else{
        pJSON = popen("jq -s '[.[]]' youbike_Taipei_immediate.json ", "r");
        FILE *pfile = fopen("youbike_immediate.json", "w");
        while(fgets(buffer, sizeof(buffer), pJSON) != NULL) {
            fprintf(pfile, "%s", buffer);
        }
        pclose(pJSON);
        fclose(pfile);
    }
    printf("\033[0m");

    if(mode == 1) {
        char cmd[256];

        if(uidExist(uid) == false) {
            printf("ERROR: uid = %d not found\n",uid);
            return 1;
        }

        /*Print station data*/
        sprintf(cmd, "cat youbike_immediate.json | jq -r '.[][] | select(.sno==\"%d\") | .sna'", uid);
        pJSON = popen(cmd, "r");

        printf("UID: \033[1;34m%d\n", uid);
        printf("\033[0m");
        printf("Region: ");
        printf("\33[0;33m");
        if(uidRegion(uid) == 1){
            printf("New Taipei\n");
        }else{
            printf("Taipei\n");
        }
        printf("\33[0m");


        printf("Station name: ");
        printf("\33[0;33m");
        while((c = fgetc(pJSON)) != EOF) {
            putchar(c);
        }
        printf("\033[0m");
        pclose(pJSON);

        printf("Available bikes: ");
        int available_bikes = 0;
        if(uidRegion(uid) == 2){
            sprintf(cmd, "cat youbike_immediate.json | jq '.[][] | select(.sno==\"%d\") | .available_rent_bikes'", uid);
        }else{
            sprintf(cmd, "cat youbike_immediate.json | jq -r '.[][] | select(.sno==\"%d\") | .sbi'", uid);
        }
        pJSON = popen(cmd, "r");

        
        fscanf(pJSON, "%d", &available_bikes);
        if(available_bikes > 0){
            printf("\033[4;32m");
            printf("%d\n", available_bikes);
        }else{
            printf("\033[4;31m");
            printf("%d\n", available_bikes);
        }
        printf("\033[0m");
        pclose(pJSON);

        printf("Available parking slots: ");
        int available_parking_slots = 0;
        if(uidRegion(uid) == 2){
            sprintf(cmd, "cat youbike_immediate.json | jq '.[][] | select(.sno==\"%d\") | .available_return_bikes'", uid);
        }else{
            sprintf(cmd, "cat youbike_immediate.json | jq -r '.[][] | select(.sno==\"%d\") | .bemp'", uid);
        }
        pJSON = popen(cmd, "r");
        fscanf(pJSON, "%d", &available_parking_slots);
        if(available_parking_slots > 0){
            printf("\033[4;32m");
            printf("%d\n", available_parking_slots);
        }else{
            printf("\033[4;31m");
            printf("%d\n", available_parking_slots);
        }
        printf("\033[0m");
        pclose(pJSON);


        printf("Last update time (GMT+8): ");
        printf("\033[4;36m");
        if(uidRegion(uid) == 2){
            sprintf(cmd, "cat youbike_immediate.json | jq -r '.[][] | select(.sno==\"%d\") | .updateTime'", uid);
            pJSON = popen(cmd, "r");
            while((c = fgetc(pJSON)) != EOF) {
                putchar(c);
            }
        }else{
            char str[256];
            int date;
            sprintf(cmd, "cat youbike_immediate.json | jq -r '.[][] | select(.sno==\"%d\") | .mday'", uid);
            pJSON = popen(cmd, "r");
            fgets(str, sizeof(str), pJSON);
            
            for(int i=0;i<4;i++){
                printf("%c",str[i]);
            }
            printf("-");
            for(int i=4;i<6;i++){
                printf("%c",str[i]);
            }
            printf("-");
            for(int i=6;i<8;i++){
                printf("%c",str[i]);
            }
            printf(" ");
            for(int i=8;i<10;i++){
                printf("%c",str[i]);
            }
            printf(":");
            for(int i=10;i<12;i++){
                printf("%c",str[i]);
            }
            printf(":");
            for(int i=12;i<14;i++){
                printf("%c",str[i]);
            }
            printf("\n");

        }
        printf("\033[0m");
        pclose(pJSON);

    }
    system("rm youbike_immediate.json");
    return 0;
}