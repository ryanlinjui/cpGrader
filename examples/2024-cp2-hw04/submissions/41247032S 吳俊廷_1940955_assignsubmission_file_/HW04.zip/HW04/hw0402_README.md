# hw0402 README
## Features
- Provide a -h function to show how to use the program(+5)
- The program should be able to search the station by uid (+5)
- The program should show the status of every station (+5)
- Print error message upon invalid input (+5)
- Show Station Name in Chinese (+5)
- Support Youbike stop status search from New Taipei City as well (+5)
- Colorful UI: if the number is zero, it will be red; otherwise, it will be green. (+0~5)
- Show the process when fetching API data

## Notice
新北市Ubike資料來源為https://data.ntpc.gov.tw/，該平台非常爛，常常要等很久而且有機會沒有回應！，若卡在無法下載新北市的資料請多試幾次，若還是一直取不到資料請稍後再試，一定可以成功的！我實作功能寫好久QAQ

可以先加上`-T`參數單獨測試台北市Ubike功能

## License
本程式使用了jq,libcurl進行資料爬取和處理
新北市Ubike資料來源為新北市政府資料開放平臺(https://data.ntpc.gov.tw/)
台北市Ubike資料來源為https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json