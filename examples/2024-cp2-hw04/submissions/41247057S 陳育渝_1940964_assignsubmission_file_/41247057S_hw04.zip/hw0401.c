#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <math.h>

// 向左邊對齊
// cpu_usage數據比對top不一樣

int32_t switch_int(char *string, int32_t *integer){
    *integer = 0;
    if (string == NULL){
        return -1;
    }
    int32_t count = strlen(string);
    for (int32_t i = 0; i < count; i++){
        *integer += pow(10, (count-i-1))*(string[i]-'0');
    }
    return 0;
}

int32_t read_status (const char *pid){
    char path[256] = {0};
    snprintf(path, 256, "/proc/%s/status", pid);
    FILE *file = fopen(path, "r");
    snprintf(path, 256, "/proc/uptime");
    FILE *uptime = fopen(path, "r");
    snprintf(path, 256, "/proc/%s/stat", pid);
    FILE *stat = fopen(path, "r");
    if (file == NULL){
        return -1;
    }
    // read file
    char buffer[512] = {0};
    char name[512] = "";
    char status[512] = "";
    char time[128] = "";
    char vmsize[512] = "";
    double cpu_usage = 0;
    double upTime = 0;
    int32_t utime = 0;
    int32_t stime = 0;
    int32_t cutime = 0;
    int32_t cstime = 0;
    int32_t starttime = 0;
    int32_t count = 0;
    fscanf(uptime, "%s", time);
    int32_t COUNT = 0;
    for (int32_t i = 0; i < strlen(time); i++){
        if (time[i] == '.'){
            COUNT = i;
        }
    }
    for (int32_t i = 0; i < strlen(time); i++){
        if (i < COUNT){
            upTime += pow(10, (COUNT-i-1))*(time[i]-'0');
        }
        if (i > COUNT){
            upTime += pow(10, (COUNT-i))*(time[i]-'0');
        }
    }
    while(fscanf(stat, "%s", time) != EOF){
        count++;
        if (count == 14){
            switch_int(time, &utime);
        }
        if (count == 15){
            switch_int(time, &stime);
        }
        if (count == 16){
            switch_int(time, &cutime);
        }
        if (count == 17){
            switch_int(time, &cstime);
        }
        if (count == 22){
            switch_int(time, &starttime);
            break;
        }
    }
    int32_t total_time = utime + stime + cutime + cstime;
    int32_t Hertz = sysconf(_SC_CLK_TCK);
    int32_t seconds = upTime - (starttime / Hertz);
    cpu_usage = 100 * (((double)total_time / Hertz) / seconds);
    while (fgets(buffer, sizeof(buffer), file) != 0){
        if (strstr(buffer, "Name:") != 0){
            sscanf(buffer, "Name:\t%s", name);
        }
        else if (strstr(buffer, "State:") != 0){
            sscanf(buffer, "State:\t%s", status);
        }
        else if (strstr(buffer, "VmSize:") != 0){
            sscanf(buffer, "VmSize:\t%s", vmsize);
        }
    }
    if (vmsize[0] == '\0'){
        strcpy(vmsize, "0");
    }
    if (cpu_usage>=10){
        printf("%-7s %-40s %-6s %-5.2lf%%   %-s\n", pid, name, status, cpu_usage, vmsize);
    }
    else{
        printf("%-7s %-40s %-6s %-4.2lf%%    %-s\n", pid, name, status, cpu_usage, vmsize);
    }
    fclose(uptime);
    fclose(stat);
    fclose(file);
    return 0;
}

int main(int32_t argc, char *argv[]){
    for (int32_t i = 0; i < argc; i++){
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0){
            printf("Usage: hw0401 [options]\n");
            printf("  -t, --time-interval=time    Update the information every [time] seconds.Default: 5 seconds.\n");
            printf("  -c, --count=count     Update the information [count] times. Default:infinite.\n");
            printf("  -p, --pid=pid         Only display the given process information.\n");
            printf("  -h, --help            Display this information and exit.\n");
            return 0;
        }
    }
    char time_string[10] = {0};
    int32_t time = 5;
    char count_string[10] = {0};
    int32_t count = -1;
    char pid[10] = {0};
    for (int32_t i = 0; i < argc; i++){
        if (strcmp(argv[i], "-t") == 0){
            i++;
            strcpy(time_string, argv[i]);
            if (switch_int(time_string, &time) != 0){
                printf("wrong input\n");
                return 0;
            }
            if (time <= 0){
                printf("wrong input\n");
                return 0;
            }
        }
        else if (strstr(argv[i], "--time-interval=") != 0){
            char *start = strstr(argv[i], "--time-interval=")+16;
            strcpy(time_string, start);
            if (switch_int(time_string, &time) != 0){
                printf("wrong input\n");
                return 0;
            }
            if (time <= 0){
                printf("wrong input\n");
                return 0;
            }
        }
        if (strcmp(argv[i], "-c") == 0){
            i++;
            strcpy(count_string, argv[i]);
            if (switch_int(count_string, &count) != 0){
                printf("wrong input\n");
                return 0;
            }
            if (count < 0){
                printf("wrong input\n");
                return 0;
            }
            count++;
        }
        else if (strstr(argv[i], "--count=") != 0){
            char *start = strstr(argv[i], "--count=")+8;
            strcpy(count_string, start);
            if (switch_int(count_string, &count) != 0){
                printf("wrong input\n");
                return 0;
            }
            if (count < 0){
                printf("wrong input\n");
                return 0;
            }
            count++;
        }
        if (strcmp(argv[i], "-p") == 0){
            i++;
            strcpy(pid, argv[i]);
        }
        else if (strstr(argv[i], "--pid=") != 0){
            char *start = strstr(argv[i], "--pid=")+6;
            strcpy(pid, start);
        }
    }
    int32_t index = 0;
    while(1){
        if (index == count && count != -1){
            break;
        }
        if (index < count && count != -1){
            index++;
        }
        DIR *proc_dir = opendir("/proc");
        if (proc_dir == NULL){
            printf("wrong input\n");
            return 0;
        }
        struct dirent *entry;
        printf("%-7s %-40s %-6s %-7s  %-10s\n", "PID", "NAME", "state", "CPU", "MEM");
        while ((entry = readdir(proc_dir)) != NULL){
            if (entry->d_type == DT_DIR && strcmp(entry->d_name, pid) == 0){
                if (read_status(entry->d_name) != 0){
                    printf("wrong input\n");
                    return 0;
                }
                break;
            }
            if (entry->d_type == DT_DIR && (entry->d_name[0] >= '0' && entry->d_name[0] <= '9') && pid[0] == 0){
                if (read_status(entry->d_name) != 0){
                    printf("wrong input\n");
                    return 0;
                }
            }
        }
        closedir(proc_dir);
        sleep(time);
        printf("\e[1;1H\e[2J");
    }
}