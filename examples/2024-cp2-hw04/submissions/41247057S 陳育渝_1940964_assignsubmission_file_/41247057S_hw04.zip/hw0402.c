#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>

typedef struct _sMemoryStruct{
    char *memory;
    size_t size;
}MemoryStruct;

typedef struct _sPrintInfo{
    char *uid;
    char *station_name;
    char *avaliable_bikes;
    char *avaliable_parking;
    char *update_time;
}PrintInfo;

void allocateMEM(PrintInfo **MEM){
    *MEM = calloc(5, sizeof(PrintInfo));
    for (int32_t i = 0; i < 5; i++){
        (*MEM)[i].uid = calloc(100, sizeof(char));
        (*MEM)[i].station_name = calloc(100, sizeof(char));
        (*MEM)[i].avaliable_bikes = calloc(100, sizeof(char));
        (*MEM)[i].avaliable_parking = calloc(100, sizeof(char));
        (*MEM)[i].update_time = calloc(100, sizeof(char));
    }
}

size_t write_callback(void *ptr, size_t size, size_t nmemb, void *userdata){
    size_t real_size = size*nmemb;
    MemoryStruct *mem = (MemoryStruct *)userdata;
    char *ptr_realloc = realloc(mem->memory, mem->size+real_size+1);
    if (ptr_realloc == NULL){
        // wrong
    }
    mem->memory = ptr_realloc;
    memcpy(&(mem->memory[mem->size]), ptr, real_size);
    mem->size += real_size;
    mem->memory[mem->size] = 0;
    return real_size;
}

int32_t storeinfo(FILE *file, int32_t now, PrintInfo *information){
    char temp[100] = {0};
    int32_t index = 0;
    int32_t enter = 0;
    int32_t count = now;
    while(fgets(temp, sizeof(temp), file) != 0){
        if (count == 5){
            break;
        }
        if (index == 0){
            enter = 1;
            strcpy(information[count].uid, temp);
        }
        else if (index == 1){
            strncpy(information[count].station_name, temp, 100);
        }
        else if (index == 2){
            strncpy(information[count].avaliable_bikes, temp, 100);
        }
        else if (index == 3){
            strncpy(information[count].avaliable_parking, temp, 100);
        }
        else if (index == 4){
            strcpy(information[count].update_time, temp);
            index = 0;
            count++;
            continue;
        }
        index++;
    }
    return count;
}

int main(int32_t argc, char *argv[]){
    for (int32_t i = 0; i < argc; i++){
        if (strcmp(argv[i], "-h") == 0){
            printf("Usage: ./hw0402 [OPTIONS]\n");
            printf("Options:\n");
            printf("  -h                       Show this help message\n");
            printf("  -N <station_name>        Search station by name\n");
            printf("  -U <uid>                 Search station by UID\n");
            printf("  --sna <station_name>     Search station by name in Chinese\n");
            printf("  --lat <latitude > --lon <longitude > Search nearest stations by latitude and longitude\n");
            return 0;
        }
    }

    CURL *curl;
    CURLcode res;
    MemoryStruct chunk;
    chunk.memory = malloc(1);
    chunk.size = 0;
    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    if (curl == 0){
        printf("wrong input\n");
        return 0;
    }
    curl_easy_setopt(curl, CURLOPT_URL, "https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json");
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
    res = curl_easy_perform(curl);
    if (res != CURLE_OK){
        printf("wrong input\n");
        return 0;
    }
    char *search_station = NULL;
    char *search_uid = NULL;
    char *search_sna = NULL;
    char *search_lat = NULL;
    char *search_lon = NULL;
    for (int32_t i = 0; i < argc; i++){
        if (strcmp(argv[i], "-N") == 0){
            i++;
            search_station = calloc(strlen(argv[i]), sizeof(char));
            strcpy(search_station, argv[i]);
            char temp[100] = {0};
            char command[512] = {0};
            PrintInfo *information;
            allocateMEM(&information);
            int32_t one = 1;
            snprintf(command, sizeof(command), "curl -s https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json | jq -r '.[] | select(.snaen|test(\"%s\"; \"i\"))| .sno, .snaen, .available_rent_bikes, .available_return_bikes, .srcUpdateTime'", search_station);
            FILE *info = popen(command, "r");
            if (fgets(temp, sizeof(temp), info) == 0){
                one = 0;
            }
            pclose(info);
            info = popen(command, "r");
            int32_t now = storeinfo(info, 0, information);
            pclose(info);
            if (one == 0 || now < 5){
                snprintf(command, sizeof(command), "curl -s https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json | jq -r '.[] | select((.snaen|test(\"%s\"; \"i\")|not) and (.aren|test(\"%s\"; \"i\"))) | .sno, .aren, .available_rent_bikes, .available_return_bikes, .srcUpdateTime'", search_station, search_station);
                info = popen(command, "r");
                now = storeinfo(info, now, information);
                pclose(info);
            }
            if (now == 0 && one == 0){
                printf("Error: No such station found with Name %s\n", search_station);
                continue;
            }
            printf("\n%d station(s) found with the substring \"%s\" in snaen and aren:\n\n", now, search_station);
            for (int32_t i = 0; i < now; i++){
                printf("Uid: %s", information[i].uid);
                printf("Station Name: %s", information[i].station_name);
                printf("Available Bikes: %s", information[i].avaliable_bikes);
                printf("Available Parking Slots: %s", information[i].avaliable_parking);
                printf("Last Update Time: %s", information[i].update_time);
                if (i != now-1){
                    printf("\n");
                }
            }
            free(information);
        }
        else if (strcmp(argv[i], "-U") == 0){
            i++;
            search_uid = calloc(strlen(argv[i]), sizeof(char));
            strcpy(search_uid, argv[i]);
            char temp[100] = {0};
            char command[256] = {0};
            PrintInfo *information;
            allocateMEM(&information);
            snprintf(command, sizeof(command), "curl -s https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json | jq -r '.[] | select(.sno | contains(\"%s\")) | .sno, .snaen, .available_rent_bikes, .available_return_bikes, .srcUpdateTime'", search_uid);
            FILE *info = popen(command, "r");
            if (fgets(temp, sizeof(temp), info) == 0){
                printf("Error: No such station found with Uid %s\n", search_uid);
                continue;
            }
            pclose(info);
            info = popen(command, "r");
            int32_t now = storeinfo(info, 0, information);
            printf("\n%d station(s) found with uid substring `%s`:\n\n", now, search_uid);
            for (int32_t i = 0; i < now; i++){
                printf("Uid: %s", information[i].uid);
                printf("Station Name: %s", information[i].station_name);
                printf("Available Bikes: %s", information[i].avaliable_bikes);
                printf("Available Parking Slots: %s", information[i].avaliable_parking);
                printf("Last Update Time: %s", information[i].update_time);
                if (i != now-1){
                    printf("\n");
                }
            }
            free(information);
        }
        else if (strcmp(argv[i], "--sna") == 0){
            i++;
            search_sna = calloc(strlen(argv[i]), sizeof(char));
            strcpy(search_sna, argv[i]);
            char temp[100] = {0};
            char command[512] = {0};
            PrintInfo *information;
            allocateMEM(&information);
            int32_t one = 1;
            snprintf(command, sizeof(command), "curl -s https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json | jq -r '.[] | select(.sna|contains(\"%s\"))| .sno, .sna, .available_rent_bikes, .available_return_bikes, .srcUpdateTime'", search_sna);
            FILE *info = popen(command, "r");
            if (fgets(temp, sizeof(temp), info) == 0){
                one = 0;
            }
            pclose(info);
            info = popen(command, "r");
            int32_t now = storeinfo(info, 0, information);
            pclose(info);
            if (one == 0 || now < 5){
                snprintf(command, sizeof(command), "curl -s https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json | jq -r '.[] | select(.sna|contains(\"%s\")|not)|select(.ar|contains(\"%s\"))| .sno, .ar, .available_rent_bikes, .available_return_bikes, .srcUpdateTime'", search_sna, search_sna);
                info = popen(command, "r");
                now = storeinfo(info, now, information);
                pclose(info);
            }
            if (now == 0 && one == 0){
                printf("Error: No such station found with Name %s\n", search_sna);
                continue;
            }
            printf("\n%d station(s) found with the substring \"%s\" in sna and ar:\n\n", now, search_sna);
            for (int32_t i = 0; i < now; i++){
                printf("Uid: %s", information[i].uid);
                printf("Station Name: %s", information[i].station_name);
                printf("Available Bikes: %s", information[i].avaliable_bikes);
                printf("Available Parking Slots: %s", information[i].avaliable_parking);
                printf("Last Update Time: %s", information[i].update_time);
                if (i != now-1){
                    printf("\n");
                }
            }
            free(information);
        }
        else if (strcmp(argv[i], "--lat") == 0){
            i++;
            search_lat = calloc(strlen(argv[i]), sizeof(char));
            strcpy(search_lat, argv[i]);
        }
        else if (strcmp(argv[i], "--lon") == 0 && search_lat != NULL){
            i++;
            search_lon = calloc(strlen(argv[i]), sizeof(char));
            strcpy(search_lon, argv[i]);
        }
    }
    free(chunk.memory);
    curl_easy_cleanup(curl);
    curl_global_cleanup();
}