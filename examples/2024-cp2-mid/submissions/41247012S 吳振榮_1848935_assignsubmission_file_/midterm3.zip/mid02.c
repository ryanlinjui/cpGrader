#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <stddef.h>
int main(){

    return 0;
}