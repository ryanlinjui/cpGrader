#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Function for matrix multiplication
void matrix_multiply(int A[][30], int B[][30], int m, int n, int p, int result[][30])
{
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < p; j++)
        {
            result[i][j] = 0;
            for (int k = 0; k < n; k++)
            {
                result[i][j] += A[i][k] * B[k][j];
            }
            // printf("Result[%d][%d] = %d\n", i, j, result[i][j]); // Print intermediate result
        }
    }
}

// Function for parsing matrix input
void parseMatrix(const char *input, int matrix[][30], int *rows, int *cols)
{
    int row = 0, col = 0;
    int value;
    while (*input != '\0')
    {
        if (*input == '[')
        {
            col = 0;
            while (*(++input) != ']')
            {
                if (sscanf(input, "%d", &value) == 1)
                {
                    matrix[row][col++] = value;
                    while (*(input++) != ',' && *input != ']')
                    {
                        // Move to the next number or ']'
                    }
                }
            }
            (*rows)++;
            *cols = col;
            row++;
        }
        input++;
    }
}

int main()
{
    int matrices[30][30][30]; // Maximum of 30 matrices with a maximum size of 30x30
    char input[1000];         // Maximum input size
    int count = 1;
    int rows = 0, cols = 0; // Define rows and cols here

    while (1)
    {
        printf("%d matrix: ", count);
        fgets(input, sizeof(input), stdin);

        if (strcmp(input, "end\n") == 0)
            break;

        rows = 0;
        cols = 0; // Reset rows and cols before parsing each matrix
        parseMatrix(input, matrices[count - 1], &rows, &cols);
        if (rows == 0 || cols == 0)
        {
            printf("Invalid Input\n");
            return 1;
        }

        count++; // Increment the count of matrices
    }

    if (count < 3)
    { // Check if there are at least two matrices
        printf("Invalid Input\n");
        return 1;
    }

    // Initialize result matrix with the dimensions of the first matrix
    int result_rows = rows;
    int result_cols = cols;
    int result[30][30];
    for (int i = 0; i < result_rows; i++)
    {
        for (int j = 0; j < result_cols; j++)
        {
            result[i][j] = matrices[0][i][j];
        }
    }

    // Perform matrix multiplication
    for (int i = 1; i < count - 1; i++)
    {
        int m = result_rows; // Number of rows in the first matrix
        int n = result_cols; // Number of columns in the first matrix and rows in the second matrix
        int p = cols;        // Number of columns in the second matrix

        // Create temporary result matrix for current multiplication
        int temp_result[30][30];

        // Multiply matrices
        matrix_multiply(result, matrices[i], m, n, p, temp_result);

        // Update result matrix with the temporary result
        for (int k = 0; k < result_rows; k++)
        {
            for (int l = 0; l < p; l++)
            {
                result[k][l] = temp_result[k][l];
            }
        }

        // Update result dimensions for the next multiplication
        result_cols = p;
    }

    // Print the result
    printf("Result: [");
    for (int i = 0; i < result_rows; i++)
    {
        printf("[");
        for (int j = 0; j < result_cols; j++)
        {
            printf("%d", result[i][j]);
            if (j != result_cols - 1)
                printf(",");
        }
        if (i == result_rows - 1)
            printf("]]");
        else
            printf("],");
    }
    printf("\n");

    return 0;
}
