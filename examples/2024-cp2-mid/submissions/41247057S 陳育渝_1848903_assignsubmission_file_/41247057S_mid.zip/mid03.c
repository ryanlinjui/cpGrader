#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <stdlib.h>
#include "mybmp.h"

int main(){
    char input_name[20] = {0};
    char new_name[20] = {0};
    char output_name[20] = {0};
    int32_t x = 0;
    int32_t y = 0;
    int32_t w = 0;
    int32_t h = 0;
    printf("cover: ");
    scanf("%s", input_name);
    FILE *input = fopen(input_name, "rb");
    if (input == NULL){
        printf("wrong input\n");
        return 0;
    }
    printf("x (in pixel): ");
    scanf("%d", &x);
    printf("y (in pixel): ");
    scanf("%d", &y);
    printf("w (in pixel): ");
    scanf("%d", &w);
    printf("h (in pixel): ");
    scanf("%d", &h);
    printf("new: ");
    scanf("%s", new_name);
    FILE *new = fopen(new_name, "rb+wb");
    if (new == NULL){
        printf("wrong input\n");
        return 0;
    }
    printf("output: ");
    scanf("%s", output_name);
    FILE *output = fopen(output_name, "wb");
    if (output == NULL){
        printf("wrong input\n");
        return 0;
    }

    // read input file
    BMPHeader input_header;
    read_header(input, &input_header);
    uint8_t **input_array = calloc(input_header.width*input_header.height, sizeof(uint8_t));
    for (int32_t i = 0; i < input_header.width*input_header.height; i++){
        input_array[i] = calloc(3, sizeof(uint8_t));
    }
    read_array(input, input_array, &input_header);
    fclose(input);

    // set new file
    BMPHeader new_header;
    read_header(new, &new_header);
    uint8_t **new_array = calloc(new_header.width*new_header.height, sizeof(uint8_t));
    for (int32_t i = 0; i < new_header.width*new_header.height; i++){
        new_array[i] = calloc(3, sizeof(uint8_t));
    }
    read_array(new, new_array, &new_header);
    double width_ratio = (w/new_header.width);
    double height_ratio = (h/new_header.height);
    uint8_t newnew_array[h*w][3];
    for (int32_t i = 0; i < h*w; i++){
        for (int32_t j = 0; j < 3; j++){
            newnew_array[i][j] = 0;
        }
    }
    for (int32_t i = 0; i < new_header.height; i++){
        for (int32_t j = 0; j < new_header.width; j++){
            int32_t newindex = (round)(i*height_ratio)*(round)(j*width_ratio)+(round)(j*width_ratio);
            for (int32_t k = 0; k < 3; k++){
                newnew_array[newindex][k] = new_array[i*new_header.width+j][k];
            }
            // printf("%d %d %d\n", newnew_array[newindex][0], newnew_array[newindex][1], newnew_array[newindex][2]);
        }
    }

    // write output file
    write_array(input_array, &input_header, output_name);
    fseek(output, input_header.dataOffset+((input_header.height-y)*input_header.width+x)*3, SEEK_SET);
    for (int32_t j = 0; j < h; j++){
        for (int32_t i = 0; i < w; i++){
            fwrite(newnew_array[j*i+i], sizeof(uint8_t), 3, output);
            // printf("%d %d %d\n", newnew_array[j*w+i][0], newnew_array[j*w+i][1], newnew_array[j*w+i][2]);
        }
        fseek(output,input_header.dataOffset+((input_header.height-j-y)*input_header.width+x)*3, SEEK_SET);
    }
}