#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "mybmp.h"

int32_t read_header(FILE *file, BMPHeader *header){
    if (file == NULL) {
        return -1;
    }
    fseek(file, 0, SEEK_SET);
    if (fread(header, sizeof(*header), 1, file) != 1) {
        printf("Failed to read BMP header.\n");
        fclose(file);
        return 0;
    }
    return 0;
}

int32_t read_array(FILE *file, uint8_t **pixel, BMPHeader *header){
    if (file == NULL){
        return -1;
    }
    // put the ptr to the data offset
    fseek(file, 0, SEEK_SET);
    fseek(file, header->dataOffset, SEEK_SET);
    // pixel should allocate in main function
    for (int y = 0; y < header->height; y++){
        for (int x = 0; x < header->width; x++){
            fread(pixel[y*header->width+x], sizeof(uint8_t), 3, file);
            // printf("%d %d %d\n", pixel[y*header->width+x][0], pixel[y*header->width+x][1], pixel[y*header->width+x][2]);
        }
    }
    return 0;
}

int32_t write_array(uint8_t **pixel, BMPHeader *header, char output_name[20]){
    FILE *output = fopen(output_name, "wb");
    fwrite(header, sizeof(BMPHeader), 1, output);
    for (int y = 0; y < header->height; y++){
        for (int x = 0; x < header->width; x++){
            fwrite(pixel[y*header->width+x], sizeof(uint8_t), 3, output);
        }
    }
    return 0;
}