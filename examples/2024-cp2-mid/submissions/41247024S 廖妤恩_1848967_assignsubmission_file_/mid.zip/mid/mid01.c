#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<stdlib.h>

int main()
{
    char input[1025];
    int32_t first = 0;
    int32_t width = 0;
    int32_t height = 0;
    int32_t count = 0;
    int32_t ansnumber = 0;
    int32_t *p = calloc(10000,sizeof(int32_t));
    int32_t *ans = calloc(10000,sizeof(int32_t));
    while ( 1 )
    {
        printf("%d matrix: ",count+1);
        count++;
        fgets( input, 1025, stdin );
        if ( input[ strlen(input) - 1 ] == 10 ) input[ strlen(input) - 1 ] = 0;   
        if (strcmp(input, "end") == 0)
        {
            printf("Result: [");
            for ( int32_t i = 0 ; i < ansnumber ; i ++ )
            {
                printf("[%d]",p[i]);
                if ( i != ansnumber-1 ) printf(",");
            }
            printf("]\n");
            return 0;
        }
        int32_t record = 0;
        int32_t recorddo = 0;
        for ( int32_t i = 0 ; input[i] != '\0' ; i ++ )
        {
            if ( input[i] == '[' ) record++;
            if ( input[i] == ',' ) recorddo++;
        }
        record--;
        recorddo = (recorddo-record+1)/record+1;
        //printf("%d %d\n",record, recorddo);
        if ( first == 0 ) 
        {
            first++;
            int32_t a[record][recorddo];
            for ( int32_t i = 0 ; i < record ; i ++ )
            {
                for ( int32_t j = 0 ; j < recorddo ; j ++ )
                {
                    a[i][j] = 0;
                }
            }
            int32_t j = 0;
            int32_t i = 0;
            for ( int32_t k = 0 ; input[k] != '\0' ; k ++ )
            {
                int32_t save = 0;
                if ( input[k] >= '0' && input[k] <= '9' )
                {
                    while ( input[k] != ']' && input[k] != ',' )
                    {
                        save = save*10 + input[k] - '0';
                        k++;
                    }
                    //printf("%d %d\n",k, save);
                    a[i][j] = save;
                    //printf("o %d %d\n",i, j);
                    j++;
                    if ( j == recorddo )
                    {
                        j=0;
                        i++;
                    }
                }  
            }
            /*for ( int32_t i = 0 ; i < record ; i ++ )
            {
                for ( int32_t j = 0 ; j < recorddo ; j ++ )
                {
                    printf("%d ",a[i][j]);
                }
                printf("\n");
            }*/
            int32_t k = 0;
            for ( int32_t i = 0 ; i < record ; i ++ )
            {
                for ( int32_t j = 0 ; j < recorddo ; j ++ )
                {
                    p[k] = a[i][j];
                    k++;   
                }
            }
            height = record;
            continue;
        }
        
        int32_t a[record][recorddo];
        for ( int32_t i = 0 ; i < record ; i ++ )
            {
                for ( int32_t j = 0 ; j < recorddo ; j ++ )
                {
                    a[i][j] = 0;
                }
            }
            int32_t j = 0;
            int32_t i = 0;
            for ( int32_t k = 0 ; input[k] != '\0' ; k ++ )
            {
                int32_t save = 0;
                if ( input[k] >= '0' && input[k] <= '9' )
                {
                    while ( input[k] != ']' && input[k] != ',' )
                    {
                        save = save*10 + input[k] - '0';
                        k++;
                    }
                    //printf("%d %d\n",k, save);
                    a[i][j] = save;
                    //printf("o %d %d\n",i, j);
                    j++;
                    if ( j == recorddo )
                    {
                        j=0;
                        i++;
                    }
                }  
            }
        //plus
        int32_t k = 0;
        int32_t m = 0;
        
        //printf("%d %d \n",height,recorddo);
        /*for ( int32_t i = 0 ; i < height ; i ++ )
        {
            for ( int32_t j = 0 ; j < recorddo ; j ++ )
            {
                int32_t save = 0;
                for ( int32_t l = 0 ; l < record ; l ++ )
                {
                    save += p[l]*a[i][j];
                }
                ans[k] = save;
                k++;
                printf("%d ",save);
            }
        }*/
        for ( int32_t i = 0 ; i < height ; i ++ )
        {
            for ( int32_t j = 0 ; j < recorddo ; j ++ )
            {
                int32_t save = 0;
                for ( int32_t k = 0 ; k < record ; k ++ )
                {
                    save += p[i*record+k]*a[k][j];
                }
                ans[k] = save;
                k++;
                //printf("%d ",save);
            }
        }
        /*for ( int32_t i = 0 ; i < recorddo ; i ++ )
        {
            int32_t save = 0;
            for ( int32_t j = 0 ; j < record ; j ++ )
            {
                save +=  a[i][j]*p[k];
                k++;
            }
            printf(": %d\n",save);
            ans[m] = save;
            m++;
        }*/


        
        /*for ( int i = 0 ; i < height*recorddo ; i ++ )
        {
            printf("%d ",ans[i]);
        }*/
        ansnumber = height*recorddo;
        for ( int i = 0 ; i < 10000 ; i ++ )
        {
            p[i] = 0;
        }
        for ( int i = 0 ; i < height*recorddo ; i ++ )
        {
            p[i] = ans[i];
        }
        for ( int i = 0 ; i < 10000 ; i ++ )
        {
            ans[i] = 0;
        }
        height = record;
        //printf("hi\n");
    }
}