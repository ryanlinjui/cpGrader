#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>
#include<string.h>

typedef struct _sBmpHeader
{
    char bm[2];
    uint32_t size;
    uint32_t reserve;
    uint32_t offset;
    uint32_t infoheader;
    int32_t width;
    int32_t height;
    uint16_t plane;
    uint16_t bpp;
    uint32_t compress;
    uint32_t bmpsize;
    uint32_t hres;
    uint32_t vres;
    uint32_t used;
    uint32_t important;
}sBmpHeader;

void saveheader( sBmpHeader *header, FILE *file )
{
    fread( &header->bm, 2, 1, file );
    fread( &header->size, 4, 1, file );
    fread( &header->reserve, 4, 1, file );
    fread( &header->offset, 4, 1, file );
    fread( &header->infoheader, 4, 1, file );
    fread( &header->width, 4, 1, file );
    fread( &header->height, 4, 1, file );
    fread( &header->plane, 2, 1, file );
    fread( &header->bpp, 2, 1, file );
    fread( &header->compress, 4, 1, file );
    fread( &header->bmpsize, 4, 1, file );
    fread( &header->hres, 4, 1, file );
    fread( &header->vres, 4, 1, file );
    fread( &header->used, 4, 1, file );
    fread( &header->important, 4, 1, file );

    /*printf("%c%c\n",header->bm[0], header->bm[1]);
    printf("size: %u\n",header->size);
    printf("reserve: %u\n",header->reserve);
    printf("offset: %u\n",header->offset);
    printf("infoheader: %u\n",header->infoheader);
    printf("width: %d\n",header->width);
    printf("height: %d\n",header->height);
    printf("plane: %u\n",header->plane);
    printf("bpp: %u\n",header->bpp);
    printf("compress: %u\n",header->compress);
    printf("bmpsize: %u\n",header->bmpsize);
    printf("xpi: %u\n",header->hres);
    printf("ypi: %u\n",header->vres);
    printf("used: %u\n",header->used);
    printf("import: %u\n",header->important);*/
}


int main ()
{
    printf("cover: ");
    char path[1025];
    fgets( path, 1025, stdin );
    if ( path[ strlen(path) - 1 ] == 10 ) path[ strlen(path) - 1 ] = 0;
    FILE *ori_file = fopen ( path, "rb" );
    if ( ori_file == NULL )
    {
        printf ("Wrong file, please check your file again.\n");
        return 0;
    }
    int32_t x = 0;
    int32_t y = 0;
    int32_t w = 0;
    int32_t h = 0;
    printf("x (in pixel): ");
    scanf("%d",&x);
    printf("y (in pixel): ");
    scanf("%d",&y);   
    printf("w (in pixel): ");
    scanf("%d",&w);    
    printf("h (in pixel): ");
    scanf("%d",&h);
    int32_t c;
    while ((c = getchar()) != '\n' && c != EOF);
    printf("new: ");
    char new[1025];
    fgets( new, 1025, stdin );
    if ( new[ strlen(new) - 1 ] == 10 ) new[ strlen(new) - 1 ] = 0;
    FILE *cover_file = fopen ( new, "rb" );
    if ( cover_file == NULL )
    {
        printf ("Wrong file, please check your file again.\n");
        return 0;
    }
    char output[1025];
    printf("output: ");
    fgets( output, sizeof(output), stdin );
    if ( output[ strlen(output) - 1 ] == 10 ) output[ strlen(output) - 1 ] = 0; 

    sBmpHeader *original_fileheader = malloc(sizeof(sBmpHeader));
    saveheader(original_fileheader,ori_file);

    sBmpHeader *cover_fileheader = malloc(sizeof(sBmpHeader));
    saveheader(cover_fileheader,cover_file);

    //new file
    FILE *new_file = fopen(output,"wb");
    fwrite( &original_fileheader->bm[0], 1, 1, new_file );
    fwrite( &original_fileheader->bm[1], 1, 1, new_file );
    fwrite( &original_fileheader->size, 4, 1, new_file );
    fwrite( &original_fileheader->reserve, 4, 1, new_file );
    fwrite( &original_fileheader->offset, 4, 1, new_file );
    fwrite( &original_fileheader->infoheader, 4, 1, new_file );
    fwrite( &original_fileheader->width, 4, 1, new_file );
    fwrite( &original_fileheader->height, 4, 1, new_file );
    fwrite( &original_fileheader->plane, 2, 1, new_file );
    fwrite( &original_fileheader->bpp, 2, 1, new_file );
    fwrite( &original_fileheader->compress, 4, 1, new_file );
    fwrite( &original_fileheader->bmpsize, 4, 1, new_file );
    fwrite( &original_fileheader->hres, 4, 1, new_file );
    fwrite( &original_fileheader->vres, 4, 1, new_file );
    fwrite( &original_fileheader->used, 4, 1, new_file );
    fwrite( &original_fileheader->important, 4, 1, new_file );

    int32_t nowx = 0;
    int32_t nowy = 0;
    int32_t coverx = 0;
    int32_t covery = 0;
    uint8_t white = 255;
    double scalex = 0;
    double scaley = 0;
    double recordx = 0;
    double recordy = 0;
    scalex = w/cover_fileheader->width;
    scaley = h/cover_fileheader->height;  

    //copy
    for ( int32_t i = 0 ; i < original_fileheader->height ; i ++ )
    {
        for ( int32_t j = 0 ; j < original_fileheader->width ; j ++ )
        {
            char temp[original_fileheader->bpp/8];
            char copy[original_fileheader->bpp/8];
            nowx++;
            if ( nowx == original_fileheader->width )
            {
                nowx = 0;
                nowy++;
            }
            fread(temp,original_fileheader->bpp/8,1,ori_file);

            if ( nowx >= x && nowx <= x+w && nowy >= original_fileheader->height-y-h && nowy <= original_fileheader->height-y )
            {
                coverx++;
                if ( coverx == cover_fileheader->width-1 )
                {
                    coverx = 0;
                    covery++;
                    recordy+=scaley;
                    for( int32_t k = 0 ; k < ( 4-(cover_fileheader->width*(int)cover_fileheader->bpp/8)%4)%4 ; k ++ )
                    {
                        fwrite("00",1,1,new_file);
                    }
                    for( int32_t k = 0 ; k < ( 4-(cover_fileheader->width*(int)cover_fileheader->bpp/8)%4)%4 ; k ++ )
                    {
                        fread(temp,1,1,cover_file);
                    }
                }

                fread(copy,cover_fileheader->bpp/8,1,cover_file);
                recordx+=scalex;
                //printf("%lf\n",recordx);
                if ( recordx >= 1 && recordx < 2 )
                {
                    recordx-=1;
                    fwrite(&copy,cover_fileheader->bpp/8,1,new_file);
                }
                else if ( recordx >= 2 )
                {
                    while ( recordx >= 1 )
                    {
                        recordx--;
                        fwrite(&copy,cover_fileheader->bpp/8,1,new_file);
                    }
                }
                
                //printf("%lf\n",recordx);
                //printf("%d %d\n",coverx,covery);
            }
            else 
            {
                fwrite(temp,original_fileheader->bpp/8,1,new_file);
            }
            for( int32_t k = 0 ; k < ( 4-(original_fileheader->width*(int)original_fileheader->bpp/8)%4)%4 ; k ++ )
            {
                fread(temp,1,1,ori_file);
            }
            //printf("%d %d\n",nowx,nowy);
        } 
        for( int32_t k = 0 ; k < ( 4-(original_fileheader->width*(int)original_fileheader->bpp/8)%4)%4 ; k ++ )
        {
            fwrite("00",1,1,new_file);
        }
    }
    //printf("%d %d\n", nowx, nowy);





    //free and close
    free(original_fileheader);
    free(cover_fileheader);
    fclose(ori_file);
    fclose(cover_file);

}