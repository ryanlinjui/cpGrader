# Bonus

## 1

I have a Calculus
I have a Discrete
Ah
Course Withdrawal

I have no Makefile
I have no #include
Ah
Course Withdrawal

Course Withdrawal
Course Withdrawal
Ah
Thank you teacher, see you next year.

## 2

I hear C bells a-ringing
Homework bmp files are singing
Be my mirror, my taiko and GGUF
My missionaries in a computer programming

For some reason, I can't explain
Once I've submit, there was never
Never an answer correct
And that was when I withdrawed the course

## 3

C一跳 夜就開始煎熬
每一分 每一秒
bmp爛掉 爛成灰有多好
求助教 幫幫忙
我相信我已經快要
快要把課退掉
跟痛苦 再和好

## 4

こんなこと いいな できたら いいな
あんな問題 こんな問題 何もできない
全部 全部 全部 エラーを報告する
ふしぎな 方法を エラーを報告する
写真をじゆうに 描くたいな
「ハイ！ メモリセグメントエラー！」
アン アン アン とっても だいすき プログラミング

（翻譯）
這種事情真好，可以完成更好
這種題目、那種題目，全部都不會做
所有所有的程式，都能夠報錯
用不可思議的方式來報錯
我想要在圖片自由地繪畫
「哈！那就是記憶體區段錯誤！」
啊啊啊，我最喜歡程式設計了！
