#include "myfile.h"

int32_t inputFileName(char *file) {
    if (fgets(file, F_SIZE, stdin) == NULL) {
        if (fgetc(stdin) == EOF) {
            printf("myfile: EOF detected\n");
        } else {
            perror("myfile: input error");
        }

        return -1;
    }

    if (file[strlen(file) - 1] == '\n') {
        file[strlen(file) - 1] = '\0';
    }

    return 0;
}

int32_t openFile(FILE **file, char *fileName, char *mode) {
    *file = fopen(fileName, mode);

    if (*file == NULL) {
        char err[F_SIZE] = {0};
        snprintf(err, F_SIZE, "myfile: '%s' error", fileName);
        perror(err);

        return -1;
    }

    return 0;
}

void closeFile(FILE *file) {
    if (file == NULL) {
        return;
    }

    fclose(file);
}
