#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include "mybmp.h"
#include "myfile.h"

int32_t processFile(FILE *cov, FILE *new, FILE *out, int32_t x, int32_t y, int32_t w, int32_t h);

int main() {
    FILE *covFile = NULL;
    FILE *newFile = NULL;
    FILE *outFile = NULL;

    char covName[F_SIZE] = {0};
    char newName[F_SIZE] = {0};
    char outName[F_SIZE] = {0};

    printf("cover: ");

    if (inputFileName(covName) != 0) {
        return 1;
    }

    if (openFile(&covFile, covName, "rb") != 0) {
        return 1;
    }

    int32_t x, y, w, h;

    printf("x (in pixel): ");
    scanf("%d", &x);

    printf("y (in pixel): ");
    scanf("%d", &y);

    printf("w (in pixel): ");
    scanf("%d", &w);

    printf("h (in pixel): ");
    scanf("%d", &h);

    // Clear input buffer
    while (getchar() != '\n');

    printf("new: ");

    if (inputFileName(newName) != 0) {
        return 1;
    }

    if (openFile(&newFile, newName, "rb") != 0) {
        closeFile(covFile);
        return 1;
    }

    printf("Output file: ");

    if (inputFileName(outName) != 0) {
        closeFile(covFile);
        closeFile(newFile);
        return 1;
    }

    if (strcmp(covName, outName) == 0) {
        printf("Input file name and output file name cannot be the same.\n");
        closeFile(covFile);
        closeFile(newFile);
        return 1;
    }

    if (openFile(&outFile, outName, "wb") != 0) {
        closeFile(covFile);
        closeFile(newFile);
        return 1;
    }

    if (processFile(covFile, newFile, outFile, x, y, w, h) != 0) {
        closeFile(covFile);
        closeFile(newFile);
        closeFile(outFile);
        return 1;
    }

    closeFile(covFile);
    closeFile(outFile);

    return 0;
}

int32_t processFile(FILE *cov, FILE *new, FILE *out, int32_t x, int32_t y, int32_t w, int32_t h) {
    BMP covBMP = {NULL, NULL};
    BMP newBMP = {NULL, NULL};

    if (initBMP(&covBMP, cov) != 0) {
        return 1;
    }

    if (initBMP(&newBMP, new) != 0) {
        freeBMP(&covBMP);
        return 1;
    }

    // TODO: Process BMP here

    int32_t covWidth  = covBMP.header->width;
    int32_t covHeight = covBMP.header->height;

    if (covHeight < 0) {
        covHeight = -covHeight;
    }

    int32_t xPos = x;
    int32_t yPos = covHeight - y - h;

    // if (xPos < 0 || yPos < 0) {
    //     printf("Invalid position\n");
    //     freeBMP(&covBMP);
    //     freeBMP(&newBMP);
    //     return 1;
    // }

    for (int32_t i = 0; i < h; i++) {
        for (int32_t j = 0; j < w; j++) {
            if (xPos + j < 0 || yPos + i < 0 || xPos + j >= covWidth || yPos + i >= covHeight) {
                continue;
            }

            // scale newBMP to w times h
            int32_t newX = (int32_t) (j * (newBMP.header->width - 1) / (w - 1));
            int32_t newY = (int32_t) (i * (newBMP.header->height - 1) / (h - 1));

            covBMP.pixels[yPos + i][xPos + j].r = newBMP.pixels[newY][newX].r;
            covBMP.pixels[yPos + i][xPos + j].g = newBMP.pixels[newY][newX].g;
            covBMP.pixels[yPos + i][xPos + j].b = newBMP.pixels[newY][newX].b;
        }
    }

    if (writeBMP(&covBMP, out) != 0) {
        freeBMP(&covBMP);
        return 1;
    }

    freeBMP(&covBMP);

    return 0;
}
