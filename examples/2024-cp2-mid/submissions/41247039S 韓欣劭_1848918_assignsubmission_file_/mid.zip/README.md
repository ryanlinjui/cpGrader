# Mid Term

ID: 41247039S
Name: 韓欣劭
Course: Computer Programming II
