#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include "mybmp.h"
#include "myfile.h"

const uint8_t colors[8][3] = {
    {0x00, 0x00, 0x00},
    {0x33, 0x66, 0xff},
    {0x00, 0xcc, 0x00},
    {0x00, 0xcc, 0xcc},
    {0xcc, 0x00, 0x00},
    {0xcc, 0x00, 0xcc},
    {0xcc, 0xcc, 0x00},
    {0xff, 0xff, 0xff},
};

const int32_t dx[8] = {1, 1, 0, -1, -1, -1, 0, 1};
const int32_t dy[8] = {0, 1, 1, 1, 0, -1, -1, -1};

void processFile(FILE *file, int32_t r, int32_t g, int32_t b, char *command);

int32_t processCommand(BMP *bmp, char *command);

void parseCommand(BMP *bmp, char *command, int32_t x, int32_t y, int32_t color, int32_t dir, int32_t pos);

int main() {
    FILE *file = NULL;
    char fileName[F_SIZE] = {0};

    printf("Enter the output filename: ");

    if (inputFileName(fileName) != 0) {
        return 1;
    }

    if (openFile(&file, fileName, "wb") != 0) {
        return 1;
    }

    int32_t r, g, b;

    printf("Enter the background color (R,G,B): ");
    scanf("(%d,%d,%d)", &r, &g, &b);

    // Clear input buffer

    while (getchar() != '\n');

    char command[F_SIZE] = {0};

    printf("Type code here: ");

    if (fgets(command, F_SIZE, stdin) == NULL) {
        printf("Input error\n");
        return 1;
    }

    if (command[strlen(command) - 1] == '\n') {
        command[strlen(command) - 1] = '\0';
    }

    processFile(file, r, g, b, command);

    closeFile(file);

    return 0;
}

void processFile(FILE *file, int32_t r, int32_t g, int32_t b, char *command) {
    int32_t size = 256;

    BMP bmp;

    if (initBMPHeader(&bmp) != 0) {
        return;
    }

    bmp.header->bm[0] = 'B';
    bmp.header->bm[1] = 'M';

    bmp.header->size = 54 + size * size * 3;
    bmp.header->reserve = 0;
    bmp.header->offset = 54;
    bmp.header->header_size = 40;
    bmp.header->width = size;
    bmp.header->height = size;
    bmp.header->planes = 1;
    bmp.header->bpp = 24;
    bmp.header->compression = 0;
    bmp.header->bitmap_size = size * size * 3;
    bmp.header->hres = 0;
    bmp.header->vres = 0;
    bmp.header->used = 0;
    bmp.header->important = 0;

    if (initBMPPixels(&bmp) != 0) {
        return;
    }

    for (int32_t i = 0; i < size; i++) {
        for (int32_t j = 0; j < size; j++) {
            bmp.pixels[i][j].r = r;
            bmp.pixels[i][j].g = g;
            bmp.pixels[i][j].b = b;
        }
    }

    // printf("command: %s\n", command);

    if (processCommand(&bmp, command) != 0) {
        return;
    }

    if (writeBMP(&bmp, file) != 0) {
        return;
    }
}

int32_t processCommand(BMP *bmp, char *command) {
    int32_t x = 127;
    int32_t y = 127;

    int32_t color = 7;
    int32_t dir   = 0;

    // printf("result: %s\n", result);

    for (size_t i = 0; i < strlen(command); i++) {
        if (command[i] == 'F') {
            // Move forward and paint
            x += dx[dir];
            y += dy[dir];

            bmp->pixels[x][y].r = colors[color][0];
            bmp->pixels[x][y].g = colors[color][1];
            bmp->pixels[x][y].b = colors[color][2];
        } else if (command[i] == 'R') {
            dir = (dir + 1) % 8;
        } else if (command[i] == 'C') {
            color = (color + 1) % 8;
        }
    }

    return 0;
}
