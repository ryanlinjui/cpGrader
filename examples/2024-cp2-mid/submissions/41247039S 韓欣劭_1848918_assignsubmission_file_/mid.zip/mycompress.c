#include "mycompress.h"

int32_t readCodebook(FILE *codebook, Codebook *cb) {
    if (codebook == NULL || cb == NULL) {
        return -1;
    }

    int32_t i = 0;

    char code[1024] = {0};

    while (fgets(code, 1024, codebook) != NULL) {
        if (i >= 30) {
            break;
        }

        size_t len = strspn(code, "abcdefghijklmnopqrstuvwxyz");

        if (len == 5 || len == 6) {
            if (code[0] == 's') {
                cb->codeArr[i].code = ' ';
            } else if (code[0] == 'c') {
                cb->codeArr[i].code = ',';
            } else if (code[0] == 'p') {
                cb->codeArr[i].code = '.';
            }
        } else {
            cb->codeArr[i].code = code[0];
        }

        // Find zero and one from the code string.

        char *compress = strpbrk(code, "01");

        if (compress == NULL) {
            return -1;
        }

        // Copy the code string.

        strncpy(cb->codeArr[i].codeStr, compress, 128);

        if (cb->codeArr[i].codeStr[strlen(cb->codeArr[i].codeStr) - 1] == '\n') {
            cb->codeArr[i].codeStr[strlen(cb->codeArr[i].codeStr) - 1] = '\0';
        }

        cb->codeArr[i].codeLen = strlen(cb->codeArr[i].codeStr);

        // printf("%s\n", cb->codeArr[i].codeStr);

        i++;
    }

    cb->codeSize = i;

    return 0;
}

int32_t compressFile(FILE *iFile, FILE *oFile, Codebook *cb) {
    if (iFile == NULL || oFile == NULL || cb == NULL) {
        return -1;
    }

    char c = 0;

    uint8_t buffer = 0, bufferLen = 0;

    while ((c = fgetc(iFile)) != EOF) {
        for (int32_t i = 0; i < cb->codeSize; i++) {
            if (cb->codeArr[i].code == c) {
                // printf("%c", c);

                for (int32_t j = 0; j < cb->codeArr[i].codeLen; j++) {
                    buffer <<= 1;

                    if (cb->codeArr[i].codeStr[j] == '1') {
                        buffer |= 1;
                    }

                    bufferLen++;

                    if (bufferLen == 8) {
                        fputc(buffer, oFile);

                        buffer = 0;
                        bufferLen = 0;
                    }
                }
            }
        }
    }

    if (bufferLen > 0) {
        for (int32_t i = 0; i < 8; i++) {
            buffer <<= 1;

            if (i == 0) {
                buffer |= 1;
            } else {
                buffer |= 0;
            }

            bufferLen++;

            if (bufferLen == 8) {
                fputc(buffer, oFile);
                break;
            }
        }
    }

    return 0;
}
