#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include "myfile.h"
#include "mycompress.h"

void processFile(FILE *codebook, FILE *iFile, FILE *oFile);

int main() {
    FILE *codebookFile = NULL;
    FILE *inputFile = NULL;
    FILE *outputFile = NULL;

    char codebookName[F_SIZE] = {0};
    char inputName[F_SIZE] = {0};
    char outputName[F_SIZE] = {0};

    printf("Codebook: ");

    if (inputFileName(codebookName) == -1) {
        return 1;
    }

    if (openFile(&codebookFile, codebookName, "r") == -1) {
        return 1;
    }

    printf("Input File: ");

    if (inputFileName(inputName) == -1) {
        return 1;
    }

    if (openFile(&inputFile, inputName, "r") == -1) {
        return 1;
    }

    printf("Output File: ");

    if (inputFileName(outputName) == -1) {
        return 1;
    }

    if (strcmp(inputName, outputName) == 0) {
        printf("Error: input file and output file are the same.\n");
        return 1;
    }

    if (strcmp(codebookName, outputName) == 0) {
        printf("Error: codebook file and output file are the same.\n");
        return 1;
    }

    if (openFile(&outputFile, outputName, "w") == -1) {
        return 1;
    }

    processFile(codebookFile, inputFile, outputFile);

    closeFile(codebookFile);
    closeFile(inputFile);
    closeFile(outputFile);

    return 0;
}

void processFile(FILE *codebook, FILE *iFile, FILE *oFile) {
    Codebook cb = {0};

    if (readCodebook(codebook, &cb) == -1) {
        return;
    }

    if (compressFile(iFile, oFile, &cb) == -1) {
        return;
    }
}
