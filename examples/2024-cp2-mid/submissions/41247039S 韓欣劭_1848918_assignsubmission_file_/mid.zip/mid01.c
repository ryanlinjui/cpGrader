#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "mymatrix.h"

#define SIZE 2048

int main() {
    char str[SIZE] = {0};

    MatrixList matList;
    matList.size = 0;

    int32_t count = 0;

    while (1) {
        printf("%d matrix: ", count + 1);

        if (fgets(str, SIZE, stdin) == NULL) {
            return 1;
        }

        if (str[strlen(str) - 1] == '\n') {
            str[strlen(str) - 1] = '\0';
        }

        if (strcmp(str, "end") == 0) {
            break;
        }

        if (checkValidMatrix(str, &matList.matrix[count]) != 0) {
            printf("Invalid matrix\n");
            return 1;
        }

        count++;
    }

    matList.size = count;

    if (checkCanMultiply(&matList) != 0) {
        printf("Cannot multiply\n");
        return 1;
    }

    Matrix result;

    if (multiplyMatrix(&matList, &result) != 0) {
        printf("Cannot multiply\n");
        return 1;
    }

    printMatrix(&result);

    return 0;
}
