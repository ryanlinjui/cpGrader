#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct _Matrix {
    int32_t data[30][30];
    int32_t row;
    int32_t col;
} Matrix;

typedef struct _MatrixList {
    Matrix matrix[1024];
    int32_t size;
} MatrixList;

int32_t checkValidMatrix(char *str, Matrix *matrix);

int32_t checkCanMultiply(MatrixList *matList);

int32_t multiplyMatrix(MatrixList *matList, Matrix *result);

void printMatrix(Matrix *matrix);
