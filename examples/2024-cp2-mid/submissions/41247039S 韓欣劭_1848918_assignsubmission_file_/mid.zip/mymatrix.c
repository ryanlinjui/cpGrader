#include "mymatrix.h"

int32_t checkValidMatrix(char *str, Matrix *matrix) {
    if (str[0] != '[' || str[strlen(str) - 1] != ']') {
        return 1;
    }

    int32_t row  = 0;
    int32_t col  = 0;
    int32_t flag = 1;

    for (size_t i = 1; i < strlen(str) - 1; i++) {
        if (str[i] == '[') {
            if (i != 1) {
                row++;
            }
            col = 0;
        } else if (str[i] == ']') {
            if (flag) {
                matrix->col = col + 1;
                flag = 0;
            } else if (col + 1 != matrix->col) {
                return 1;
            }
        } else if (str[i] == ',') {
            col++;
        } else if (str[i] == ' ') {
            continue;
        } else if (str[i] >= '0' && str[i] <= '9') {
            matrix->data[row][col] = matrix->data[row][col] * 10 + str[i] - '0';

            // printf("%d %d %d\n", row, col, matrix->data[row][col]);
        } else {
            return 1;
        }
    }

    matrix->row = row + 1;

    return 0;
}

int32_t checkCanMultiply(MatrixList *matList) {
    if (matList->size == 0) {
        return 1;
    } else if (matList->size == 1) {
        return 0;
    }

    for (int32_t i = 0; i < matList->size - 1; i++) {
        if (matList->matrix[i].col != matList->matrix[i + 1].row) {
            return 1;
        }
    }

    return 0;
}

int32_t multiplyMatrix(MatrixList *matList, Matrix *result) {
    // Copy first matrix to result

    for (int32_t i = 0; i < matList->matrix[0].row; i++) {
        for (int32_t j = 0; j < matList->matrix[0].col; j++) {
            result->data[i][j] = matList->matrix[0].data[i][j];
        }
    }

    result->row = matList->matrix[0].row;
    result->col = matList->matrix[0].col;

    // Loop through the rest of the matrix

    for (int32_t i = 1; i < matList->size; i++) {
        Matrix temp;

        for (int32_t j = 0; j < result->row; j++) {
            for (int32_t k = 0; k < matList->matrix[i].col; k++) {
                temp.data[j][k] = 0;

                for (int32_t l = 0; l < result->col; l++) {
                    temp.data[j][k] += result->data[j][l] * matList->matrix[i].data[l][k];
                }
            }
        }

        result->row = result->row;
        result->col = matList->matrix[i].col;

        for (int32_t j = 0; j < result->row; j++) {
            for (int32_t k = 0; k < result->col; k++) {
                result->data[j][k] = temp.data[j][k];
            }
        }
    }

    return 0;
}

void printMatrix(Matrix *matrix) {
    printf("[");

    for (int32_t i = 0; i < matrix->row; i++) {
        printf("[");

        for (int32_t j = 0; j < matrix->col; j++) {
            printf("%d", matrix->data[i][j]);

            if (j != matrix->col - 1) {
                printf(",");
            }
        }

        printf("]");

        if (i != matrix->row - 1) {
            printf(",");
        }
    }

    printf("]\n");
}
