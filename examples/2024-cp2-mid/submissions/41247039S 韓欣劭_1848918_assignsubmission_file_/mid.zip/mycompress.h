#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct _Code {
    char code;
    char codeStr[128];
    int32_t codeLen;
} Code;

typedef struct _Codebook {
    Code codeArr[30];
    int32_t codeSize;
} Codebook;

int32_t readCodebook(FILE *codebook, Codebook *cb);

int32_t compressFile(FILE *iFile, FILE *oFile, Codebook *cb);
