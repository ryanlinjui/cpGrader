#ifndef MYINCLUDE_H
#define MYINCLUDE_H

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <ctype.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

#endif

