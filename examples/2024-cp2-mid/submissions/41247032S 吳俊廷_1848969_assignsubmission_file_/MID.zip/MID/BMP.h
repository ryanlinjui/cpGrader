#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>


//BMP file header struct
struct _sBmpHeader
{
    char		bm[2];
    uint32_t	size;
    uint32_t	reserve;
    uint32_t	offset;
    uint32_t	header_size;
    int32_t	    width;
    int32_t	    height;
    uint16_t	planes;
    uint16_t	bpp;
    uint32_t	compression;
    uint32_t	bitmap_size;
    uint32_t	hres;
    uint32_t	vres;
    uint32_t	used;
    uint32_t	important;
}__attribute__ ((__packed__));


//pixel struct
struct _sPixel
{
    uint8_t b;
    uint8_t g;
    uint8_t r;
};


typedef struct _sBmpHeader sBmpHeader;
typedef struct _sPixel sPixel;
typedef struct _sBMPImage sBMPImage;

//Print BMP file header
void print_bmp_header( sBmpHeader *pHeader );

//parse BMP file header
sBmpHeader *parse_bmp_header( FILE *pFile, sBmpHeader *pHeader);

//parse BMP pixel data
int32_t parse_bmp_pixel_data( FILE *pFile, sBmpHeader *pHeader, sPixel *pPixelData );

//get BMP width with padding
int32_t get_bmp_width_with_padding( sBmpHeader *pHeader );



//write BMP file header
void write_bmp_header( FILE *pFile, sBmpHeader *pHeader );

//write BMP pixel data
void write_bmp_pixel_data( FILE *pFile, sBmpHeader *pHeader, sPixel *pPixelData );
