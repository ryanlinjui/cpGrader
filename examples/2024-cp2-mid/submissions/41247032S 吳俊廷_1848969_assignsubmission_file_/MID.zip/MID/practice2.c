#include <stdio.h>
#include <stdlib.h>


void printt_array(int arr[3][2], int row, int col){
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }
    return;
}

int main(){
    int test[3][2]={1,2,3,4,5,6};
    printt_array(test, 3, 2);

    return 0;
}
