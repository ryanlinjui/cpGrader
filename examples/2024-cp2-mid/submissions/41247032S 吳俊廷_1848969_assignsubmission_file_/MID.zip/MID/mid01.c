#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <math.h>
/*
Please develop a program to calculate matrix multiplication. The user can input man matrices and your program needs to derive the product from them. The end of input will be a
string ”end”. 

If there is any wrong input format, you should print ”Invalid Input” and terminate
the program. If the input matrices cannot be multiplied, you should print ”Multiplication
Fails” and terminate the program. For your simplicity, I promise all values are in int32_t.

Example:
1 $ ./mid01
2 1 matrix: [[1,0,0],[0,1,0],[0,0,1]]
3 2 matrix: [[2,2,2,2],[3,3,3,3],[4,4,4,4]]
4 3 matrix: [[1],[0],[0],[0]]
5 4 matrix: end
6 Result: [[2],[3],[4]]
*/

bool readEnd=false;
//有幾個矩陣
int32_t matrixCount;

int main(){

    char input[1050]={0};
    matrixCount=0;
    int32_t matrix1[100][100];
    int32_t matrix1_row=0;
    int32_t matrix1_col=0;

    int32_t matrix2[100][100];
    int32_t matrix2_row=0;
    int32_t matrix2_col=0;

    int32_t matrixans[100][100];
    int32_t matrixans_row=0;
    int32_t matrixans_col=0;

    while(readEnd==false){
        matrixCount++;
        printf("%d matrix: ",matrixCount);

        //Read input
        //fgets(input,1050,stdin);
        if( fgets( input, sizeof(input), stdin ) == NULL ){
            printf( "Invalid Input!\n" );
            return 0;
        }
        // Since fgets will include '\n', we need to remove this character.

        //printf("DEBUG strlen: %d\n",strlen(input));
        if( input[ strlen( input ) - 1 ] == '\n' ){
            input[ strlen( input ) - 1 ] = '\0';
        }else{
            // If the last byte is not '\n', we need to clean the input buffer.
            int32_t c = 0;
            while( ( c = fgetc( stdin ) ) != '\n' && c != EOF ){}
        }

        //printf("DEBUG input: %s\n",input);
        if(strcmp(input,"end")==0){
            readEnd=true;
            break;
        }

        //Check if the input is valid
        if(input[0]!='[' || input[strlen(input)-1]!=']'){
            //printf("Read: %c\n",input[0]);
            printf("Invalid Input!\n");
            return 0;
        }

        //Parse the input
        
        int32_t row=0;
        int32_t col=0;

        

        bool isRow=true;
        bool isCol=false;
        bool isNum=false;
        char num[1050]={0};
        char num2[1050]={0};
        
        
        for(int i=1;i<strlen(input)-1;i++){
            if(input[i]=='['){
                col = 0;
                continue;
            }else if(input[i]==']'){
                if(isNum==true){
                    matrix1[row][col]=atoi(num);
                    memset(num,0,sizeof(num));
                    isNum=false;
                }
                row++;
                
                continue;
            }else if(input[i]==','){
                if(isNum==true){
                    matrix1[row][col]=atoi(num);
                    col++;
                    memset(num,0,sizeof(num));
                    isNum=false;
                }
            }else if(input[i]==' '){
                continue;
            }else if(input[i]>='0' && input[i]<='9'){
                num[strlen(num)]=input[i];
                isNum=true;
            }else{
                printf("Read: %c\n",input[i]);
                printf("Invalid Input!\n");
                return 0;
            }
        }
        if(isNum==true){
            matrix1[row][col]=atoi(num);
        }
        col++;

        matrix1_row=row;
        matrix1_col=col;


        // //DEBUG
        // printf("DEBUG row: %d\n",row);
        // printf("DEBUG col: %d\n",col);
        // for(int i=0;i<row;i++){
        //     for(int j=0;j<col;j++){
        //         printf("%d ",matrix1[i][j]);
        //     }
        //     printf("\n");
        // }

        // //DEBUG
        // printf("DEBUG matrix 1 row: %d\n",matrix1_row);
        // printf("DEBUG matrix 1 col: %d\n",matrix1_col);
        // for(int i=0;i<matrix1_row;i++){
        //     for(int j=0;j<matrix1_col;j++){
        //         printf("%d ",matrix1[i][j]);
        //     }
        //     printf("\n");
        // }


        // printf("DEBUG matrix 2 row: %d\n",matrix2_row);
        // printf("DEBUG matrix 2 col: %d\n",matrix2_col);
        // for(int i=0;i<matrix2_row;i++){
        //     for(int j=0;j<matrix2_col;j++){
        //         printf("%d ",matrix2[i][j]);
        //     }
        //     printf("\n");
        // }

        if(matrixCount>1){
            //Check if the matrix can be multiplied
            if(matrix1_row!=matrix2_col){
                printf("Multiplication Fails\n");
                return 0;
            }

            //Count matrixans row and col
            matrixans_row=matrix2_row;
            matrixans_col=matrix1_col;

            //Count matrix2 times matrix1 and save it in matrixans
            for(int i=0;i<matrixans_row;i++){
                for(int j=0;j<matrixans_col;j++){
                    matrixans[i][j]=0;
                    for(int k=0;k<matrix1_row;k++){
                        matrixans[i][j]+=matrix2[i][k]*matrix1[k][j];
                    }
                }
            }

            //Copy matrixans to matrix1
            matrix1_row=matrixans_row;
            matrix1_col=matrixans_col;
            for(int i=0;i<matrixans_row;i++){
                for(int j=0;j<matrixans_col;j++){
                    matrix1[i][j]=matrixans[i][j];
                }
            }

        }
        

        //DEBUG
        // printf("DEBUG matrix ans row: %d\n",matrixans_row);
        // printf("DEBUG matrix ans col: %d\n",matrixans_col);
        // for(int i=0;i<matrixans_row;i++){
        //     for(int j=0;j<matrixans_col;j++){
        //         printf("%d ",matrixans[i][j]);
        //     }
        //     printf("\n");
        // }

        //Copy matrix1 to matrix2
        matrix2_row=matrix1_row;
        matrix2_col=matrix1_col;
        for(int i=0;i<matrix1_row;i++){
            for(int j=0;j<matrix1_col;j++){
                matrix2[i][j]=matrix1[i][j];
            }
        }
    }
    //DEBUG
    // printf("DEBUG matrix 1 row: %d\n",matrix1_row);
    // printf("DEBUG matrix 1 col: %d\n",matrix1_col);
    // for(int i=0;i<matrix1_row;i++){
    //     for(int j=0;j<matrix1_col;j++){
    //         printf("%d ",matrix1[i][j]);
    //     }
    //     printf("\n");
    // }
    printf("Result: ");
    printf("[");
    for(int i=0;i<matrix1_row;i++){
        printf("[");
        for(int j=0;j<matrix1_col;j++){
            printf("%d",matrix1[i][j]);
            if(j!=matrix1_col-1){
                printf(",");
            }
        }
        printf("]");
        if(i!=matrix1_row-1){
            printf(",");
        }
    }
    printf("]\n");
    return 0;
}