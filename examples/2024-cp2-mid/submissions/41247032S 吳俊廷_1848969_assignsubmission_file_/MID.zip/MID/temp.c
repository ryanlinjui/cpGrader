
    //Read new BMP header
    sBmpHeader *pHeader2 = (sBmpHeader *)malloc(sizeof(sBmpHeader));
    pHeader2 = parse_bmp_header(pFile2, pHeader2);
    int32_t width_with_padding2 = get_bmp_width_with_padding(pHeader2);

    //Read new BMP pixel data
    printf("DEBUG: pHeader2->width: %d\n", pHeader2->width);
    printf("DEBUG: pHeader2->height: %d\n", pHeader2->height);
    printf("DEBUG: width_with_padding2: %d\n", width_with_padding2);
    sPixel** PixelData2=calloc(width_with_padding2*pHeader2->height,sizeof(sPixel*));
    parse_bmp_pixel_data(pFile2, pHeader2, *PixelData2);

    //resize new BMP according to w and h linearly
    // int32_t width_with_padding2_resized = w+(4-(w*3)%4)%4;
    // printf("DEBUG: width_with_padding2_resized: %d\n", width_with_padding2_resized);
    // sPixel PixelData2_resized[w][h];
    // for(int i = 0; i < h; i++){
    //     for(int j = 0; j < w; j++){
    //         int32_t x2 = (int32_t)((float)j / (float)w * (float)(pHeader2->width - pHeader2->width % 4));
    //         int32_t y2 = (int32_t)((float)i / (float)h * (float)pHeader2->height);
    //         PixelData2_resized[j][i] = PixelData2[x2][y2];
    //     }
    // }

    // sBmpHeader *pHeaderOut = (sBmpHeader *)malloc(sizeof(sBmpHeader));
    // pHeaderOut = pHeader1;
    // pHeaderOut->width = pHeader1->width;
    // pHeaderOut->height = pHeader1->height;
    // int32_t width_with_paddingOut = get_bmp_width_with_padding(pHeaderOut);

    // pHeaderOut->width = w;
    // pHeaderOut->height = h;

    // write_bmp_header(pFileOut, pHeaderOut);
    // write_bmp_pixel_data(pFileOut, pHeaderOut, *PixelData2_resized);




