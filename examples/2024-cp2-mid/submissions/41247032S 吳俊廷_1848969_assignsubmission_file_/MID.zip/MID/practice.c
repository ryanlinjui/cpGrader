#include "BMP.h"

int main(){
    //Read BMP header
    FILE *pFile = fopen("out.bmp", "rb");
    sBmpHeader *pHeader = (sBmpHeader *)malloc(sizeof(sBmpHeader));
    pHeader = parse_bmp_header(pFile, pHeader);

    //DEBUG: print width with padding
    int32_t width_with_padding = get_bmp_width_with_padding(pHeader);
    printf("Width with padding: %d\n", width_with_padding);

    //DEBUG: print BMP header
    print_bmp_header(pHeader);
    
    //Read BMP pixel data

    sPixel PixelData[width_with_padding][pHeader->height];
    parse_bmp_pixel_data(pFile, pHeader, *PixelData);

    for(int i = 0; i < pHeader->height; i++){
        for(int j = 0; j < width_with_padding; j++){
            //printf("PixelData[%d][%d]: %d %d %d\n", i, j, PixelData[j][i].b, PixelData[j][i].g, PixelData[j][i].r);
            PixelData[j][i].b = 255 - PixelData[j][i].b;
            PixelData[j][i].g = 255 - PixelData[j][i].g;
            PixelData[j][i].r = 255 - PixelData[j][i].r;
        }
    }
    
    FILE *pFileOut = fopen("out2.bmp", "wb");
    write_bmp_header(pFileOut, pHeader);
    write_bmp_pixel_data(pFileOut, pHeader, *PixelData);
    fclose(pFileOut);
    fclose(pFile);
    



    return 0;
}