#include "BMP.h"

void print_bmp_header( sBmpHeader *pHeader )
{
    printf( "ID: %c%c\n", pHeader -> bm[0], pHeader -> bm[1] );
    printf( "Size: %u\n", pHeader -> size );
    printf( "Reserve: %u\n", pHeader -> reserve );
    printf( "Offset: %u\n", pHeader -> offset );
    printf( "Header Size: %u\n", pHeader -> header_size );
    printf( "Width: %d\n", pHeader -> width );
    printf( "Height: %d\n", pHeader -> height );
    printf( "Planes: %u\n", pHeader -> planes );
    printf( "Bits Per Pixel: %u\n", pHeader -> bpp );
    printf( "Compression: %u\n", pHeader -> compression );
    printf( "Bitmap Data Size: %u\n", pHeader -> bitmap_size );
    printf( "H-Resolution: %u\n", pHeader -> hres );
    printf( "V-Resolution: %u\n", pHeader -> vres );
    printf( "Used Colors: %u\n", pHeader -> used );
    printf( "Important Colors: %u\n", pHeader -> important );
    
    return;
}

//parse bmp header
sBmpHeader *parse_bmp_header( FILE *pFile, sBmpHeader *pHeader)
{
    
    if( pHeader == NULL )
    {
        printf( "(pHeader==NULL!)Memory allocation failed!\n" );
        return NULL;
    }
    
    fread( pHeader, sizeof( sBmpHeader ), 1, pFile );
    
    return pHeader;
}

int32_t get_bmp_width_with_padding( sBmpHeader *pHeader ){
    if( pHeader == NULL )
    {
        printf( "(pHeader==NULL!)Memory allocation failed!\n" );
        return -1;
    }
    int32_t width = pHeader->width;
    int32_t padding = (4 - (width ) % 4) % 4;
    return width + padding;
}

int32_t parse_bmp_pixel_data( FILE *pFile, sBmpHeader *pHeader, sPixel *pPixelData ){
    if( pHeader == NULL )
    {
        printf( "(pHeader==NULL!)Memory allocation failed!\n" );
        return -1;
    }
    int32_t width = pHeader->width;
    int32_t height = pHeader->height;
    int32_t width_with_padding = get_bmp_width_with_padding(pHeader);
    for( int i = 0; i < height; i++ ){
        for( int j = 0; j < width_with_padding; j++ ){
            sPixel temp;
            fread( &temp.b, sizeof(uint8_t), 1, pFile );
            fread( &temp.g, sizeof(uint8_t), 1, pFile );
            fread( &temp.r, sizeof(uint8_t), 1, pFile );
            pPixelData[i * width_with_padding + j] = temp;
        }
    }   
    return 0;
}


void write_bmp_header(FILE *pFile, sBmpHeader *pHeader){
    fwrite(pHeader, sizeof(sBmpHeader), 1, pFile);
    return;
}


void write_bmp_pixel_data(FILE *pFile, sBmpHeader *pHeader, sPixel *pPixelData){
    int32_t width = pHeader->width;
    int32_t height = pHeader->height;
    int32_t width_with_padding = get_bmp_width_with_padding(pHeader);
    for( int i = 0; i < height; i++ ){
        for( int j = 0; j < width; j++ ){
            fwrite(&pPixelData[i * width_with_padding + j].b, sizeof(uint8_t), 1, pFile);
            fwrite(&pPixelData[i * width_with_padding + j].g, sizeof(uint8_t), 1, pFile);
            fwrite(&pPixelData[i * width_with_padding + j].r, sizeof(uint8_t), 1, pFile);
        }
        if(width < width_with_padding){
            for(int j = width; j < width_with_padding; j++){
                uint8_t temp = 0;
                fwrite(&temp, sizeof(uint8_t), 1, pFile);
                fwrite(&temp, sizeof(uint8_t), 1, pFile);
                fwrite(&temp, sizeof(uint8_t), 1, pFile);
            }
        }
    }
    return;
}

