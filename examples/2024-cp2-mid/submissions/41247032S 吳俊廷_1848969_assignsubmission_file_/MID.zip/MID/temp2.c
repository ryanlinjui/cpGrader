#include "BMP.h"

/*
I want you to develop a program to cover the new BMP on the origina BMP.
The user will input the original BMP file name, the new BMP file name, the x, y, w, h of the new BMP, and the output file name.
The program will read the original BMP file and the new BMP file, and then cover the new BMP on the original BMP.
Finally, the program will output the result to the output file.
If there is any wrong input format, you should print ”Invalid Input” and terminate the program.
w h 為縮放後 new 之寬與高～
x y 為 new 對於 cover 左上原點之橫向與縱向位移量～
Note that w × h may be different to the embedded image. You need to resize it linearly.
For any wrong input, simply print an error message and terminate the program.
*/

int main(){
    FILE	*pFile1 = NULL;
    FILE	*pFile2 = NULL;
    FILE    *pFileOut = NULL;

    char file1Name1[1050]={0};
    char file1Name2[1050]={0};
    char fileOutName[1050]={0};
    
    int32_t x,y,w,h;
    //Read cover file name
    printf("cover: ");
    if( fgets( file1Name1, sizeof( file1Name1 ), stdin ) == NULL ){
        printf( "Error!\n" );
        return 0;
    }

    // Since fgets will include '\n', we need to remove this character.
    if( file1Name1[ strlen( file1Name1 ) - 1 ] == '\n' ){
        file1Name1[ strlen( file1Name1 ) - 1 ] = '\0';
    }else{
        // If the last byte is not '\n', we need to clean the input buffer.
        int32_t c = 0;
        while( ( c = fgetc( stdin ) ) != '\n' && c != EOF ){}
    }
    if( ( pFile1 = fopen( file1Name1, "rb" ) ) == NULL )
    {
        printf( "File could not be opened!\n" );
        return 0;
    }


    //Read x,y,w,g;
    printf("x (in pixel): ");
    scanf("%d", &x);
    printf("y (in pixel): ");
    scanf("%d", &y);
    printf("w (in pixel): ");
    scanf("%d", &w);
    printf("h (in pixel): ");
    scanf("%d", &h);

    //Read new file name
    //Since scanf will include '\n', we need to remove this character.
    int32_t c = 0;
    while( ( c = fgetc( stdin ) ) != '\n' && c != EOF ){}
    printf("new: ");
    if( fgets( file1Name2, sizeof( file1Name2 ), stdin ) == NULL ){
        printf( "New File Error!\n" );
        return 0;
    }

    // Since fgets will include '\n', we need to remove this character.
    if( file1Name2[ strlen( file1Name2 ) - 1 ] == '\n' ){
        file1Name2[ strlen( file1Name2 ) - 1 ] = 0;
    }else{
        // If the last byte is not '\n', we need to clean the input buffer.
        int32_t c = 0;
        while( ( c = fgetc( stdin ) ) != '\n' && c != EOF ){}
    }
    if( ( pFile2 = fopen( file1Name2, "rb" ) ) == NULL )
    {
        printf( "File could not be opened!\n" );
        return 0;
    }

    //printf("DEBUG: file1Name2: %s\n", file1Name2);

    //Read output file name
    printf("output: ");
    if( fgets( fileOutName, sizeof( fileOutName ), stdin ) == NULL ){
        printf( "Error!\n" );
        return 0;
    }

    // Since fgets will include '\n', we need to remove this character.
    if( fileOutName[ strlen( fileOutName ) - 1 ] == '\n' ){
        fileOutName[ strlen( fileOutName ) - 1 ] = '\0';
    }else{
        // If the last byte is not '\n', we need to clean the input buffer.
        int32_t c = 0;
        while( ( c = fgetc( stdin ) ) != '\n' && c != EOF ){}
    }
    if( ( pFileOut = fopen( fileOutName, "wb" ) ) == NULL )
    {
        printf( "File could not be opened!\n" );
        return 0;
    }


    //Read original BMP header
    sBmpHeader *pHeader1 = (sBmpHeader *)malloc(sizeof(sBmpHeader));
    pHeader1 = parse_bmp_header(pFile1, pHeader1);
    int32_t width_with_padding1 = get_bmp_width_with_padding(pHeader1);


    //Read original BMP pixel data
    sPixel** PixelData1 = (sPixel**)malloc(pHeader1->height * sizeof(sPixel*));
    for(int i = 0; i < pHeader1->height; i++) {
        PixelData1[i] = (sPixel*)malloc(width_with_padding1 * sizeof(sPixel));
    }
    parse_bmp_pixel_data(pFile1, pHeader1, *PixelData1);
    printf("PixelData1[0][0]: %d %d %d\n", PixelData1[0][0].b, PixelData1[0][0].g, PixelData1[0][0].r);

    fclose(pFile1);

    fclose(pFile2);
    fclose(pFileOut);
    
    return 0;
}