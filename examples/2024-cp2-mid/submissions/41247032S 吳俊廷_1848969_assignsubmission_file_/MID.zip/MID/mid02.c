#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

int main(){


    printf("Codebook: ");
    scanf("%s");
    printf("Input File: ");
    scanf("%s");
    printf("Output File: ");
    scanf("%s");
    printf("Invalid input file\n");
    return 0;
}