#pragma once

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#define WORD_SIZE 5

typedef enum _ValidAlpha {
    EMPTY = 0,
    BLACK,
    YELLOW,
    GREEN
} ValidAlpha;

typedef struct _Word {
    char word[WORD_SIZE + 1];
    bool valid;
    uint64_t weight;
} Word;

typedef struct _Wordle {
    Word *word;
    size_t size;
} Wordle;

/**
 * Play the wordle game. Steps to play:
 * 1. The program will give a best word to guess in current situation.
 * 2. The user replies the result of the guessed word, by giving a string with
 * length of 5. The string must only includes 3 types of alphabets: 'B' means
 * the alphabet not in the word, 'Y' means the alphabet is in the word but wrong
 * position, 'G' means the alphabet is in the word and correct position.
 * 3. Repeat the step 1 and 2 until the word is guessed. In other words, the user
 * should give a feedback of "GGGGG" to end the program.
 * @param file the file stream pointer.
 * @return true: valid input; false: invalid input
 */
bool playWordle(FILE *file);

/**
 * Initialize the wordle.
 * @param file the file stream pointer.
 * @param wordle the wordle struct.
 * @return true: valid input; false: invalid input
 */
bool initWordle(FILE *file, Wordle *wordle);

/**
 * Advice a word to user.
 * @param wordle the wordle struct.
 * @return the index of word adviced; -1: no more word is valid
 */
int32_t adviceWord(const Wordle *wordle);

/**
 * Get feedback from user.
 * @param feedback the feedback pointer.
 * @return 1: valid feedback; 0: invalid feedback; -1: error feedback
 */
int32_t getFeedback(char *feedback);

/**
 * Process the feedback from user for next advice.
 * @param wordle the wordle struct.
 * @param feedback the feedback pointer.
 * @param index the word index that is advised.
 * @return 1: answer is found; 0: answer is not found; -1: invalid process
 */
int32_t processFeedback(Wordle *wordle, char *feedback, size_t index);

/**
 * Add the word to the wordle's words list.
 * @param wordle the wordle struct.
 * @param word the word to be added.
 */
void addWord(Wordle *wordle, char *word);

/**
 * Sort the wordle words by weight.
 * @param wordle the wordle struct.
 */
void sortWord(Wordle *wordle);

/**
 * Check the word is valid for wordle.
 * @param word the given word.
 * @return true: valid word; false: invalid word
 */
bool isValidWord(char *word);

/**
 * Check the feedback is valid.
 * @param buffer the input buffer.
 * @return true: valid feedback; false: invalid feedback
 */
bool isValidFeedback(char *buffer);

/**
 * Update the word validity with feedback.
 * @param word the word to be compared.
 * @param comp the word to compare.
 * @param feedback the feedback string.
 * @return true: the word is valid; false: the word is invalid
 */
bool updateWordValidity(const char *word, const char *comp, const char *feedback);

/**
 * Calculate the weight of the word.
 * @param word the given word.
 * @return the weight of word
 */
uint64_t calculateWeight(char *word);

/**
 * Parse alphabet to index, 0 = a/A, 1 = b/B, etc.
 * @param ch the given alphabet.
 * @return the index of alphabet
 */
int32_t parseAlpha(char ch);

/**
 * Clear the wordle.
 * @param wordle the wordle struct.
 */
void clearWordle(Wordle *wordle);
