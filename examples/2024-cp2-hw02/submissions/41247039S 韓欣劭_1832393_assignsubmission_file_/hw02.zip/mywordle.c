#include "mywordle.h"

bool playWordle(FILE *file) {
    if (file == NULL) {
        return false;
    }

    Wordle wordle = {NULL, 0};

    if (!initWordle(file, &wordle)) {
        printf("Invalid file\n");
        clearWordle(&wordle);
        return false;
    }

    // printf("size: %lu\n", wordle.size);

    // for (size_t i = 0; i < wordle.size; i++) {
    //     printf("%s %6lu\n", wordle.word[i].word, wordle.word[i].weight);
    // }

    bool result = true;

    bool flag   = false;
    bool advice = true;
    int32_t adviceIndex = 0;

    while (!flag) {
        if (advice) {
            adviceIndex = adviceWord(&wordle);

            if (adviceIndex == -1) {
                printf("No Advice\n");
                result = false;
                break;
            }

            advice = false;
        }

        char feedback[6] = {0};

        int32_t check = getFeedback(feedback);

        if (check == -1) {
            printf("Error Input\n");
            result = false;
            break;
        } else if (check == 0) {
            printf("Wrong Input\n");
            continue;
        }

        advice = true;
        check  = processFeedback(&wordle, feedback, adviceIndex);

        if (check == 1) {
            printf("Congratulations!!\n");
            flag = true;
        } else if (check == -1) {
            printf("Error process\n");
            result = false;
            break;
        }
    }

    clearWordle(&wordle);

    return result;
}

bool initWordle(FILE *file, Wordle *wordle) {
    char buffer[128] = {0};

    while (fgets(buffer, 128, file) != NULL) {
        if (isValidWord(buffer)) {
            addWord(wordle, buffer);
        }
    }

    sortWord(wordle);

    return true;
}

int32_t adviceWord(const Wordle *wordle) {
    for (size_t i = 0; i < wordle->size; i++) {
        if (wordle->word[i].valid) {
            printf("Advice:   %s\n", wordle->word[i].word);
            return i;
        }
    }

    return -1;
}

int32_t getFeedback(char *feedback) {
    char buffer[1024] = {0};

    printf("Feedback: ");
    if (fgets(buffer, 1024, stdin) == NULL) {
        return -1;
    } else if (!isValidFeedback(buffer)) {
        return 0;
    }

    for (size_t i = 0; i < WORD_SIZE; i++) {
        feedback[i] = buffer[i];
    }

    feedback[WORD_SIZE] = 0;

    // printf("Feedback is %s\n", feedback);

    return true;
}

int32_t processFeedback(Wordle *wordle, char *feedback, size_t index) {
    if (feedback == NULL || index >= wordle->size) {
        return -1;
    }

    int32_t green = 0;

    for (size_t i = 0; i < WORD_SIZE; i++) {
        if (feedback[i] == 'G') {
            green++;
        }
    }

    if (green == 5) {
        return 1;
    }

    wordle->word[index].valid = false;

    char *comp = wordle->word[index].word;

    for (size_t i = 0; i < wordle->size; i++) {
        if (!wordle->word[i].valid) {
            continue;
        }

        char *temp = wordle->word[i].word;

        wordle->word[i].valid = updateWordValidity(temp, comp, feedback);
    }

    return 0;
}

void addWord(Wordle *wordle, char *word) {
    if (wordle->size == 0) {
        wordle->word = (Word *) calloc(1, sizeof(Word));
    } else {
        wordle->word = (Word *) reallocarray(wordle->word, wordle->size + 1, sizeof(Word));
    }

    size_t idx = wordle->size;
    wordle->size++;

    for (size_t i = 0; i < WORD_SIZE; i++) {
        char ch = word[i];

        if (ch >= 'a' && ch <= 'z') {
            ch = ch - 'a' + 'A';
        }

        wordle->word[idx].word[i] = ch;
    }

    wordle->word[idx].word[5] = 0;
    wordle->word[idx].valid   = true;
    wordle->word[idx].weight  = calculateWeight(wordle->word[idx].word);
}

void sortWord(Wordle *wordle) {
    // Stable sort the word

    for (size_t i = 0; i < wordle->size; i++) {
        size_t max = i;

        for (size_t j = i + 1; j < wordle->size; j++) {
            if (wordle->word[max].weight < wordle->word[j].weight) {
                max = j;
            }
        }

        Word temp = wordle->word[max];

        for (size_t j = max; j > i; j--) {
            wordle->word[j] = wordle->word[j - 1];
        }

        wordle->word[i] = temp;
    }
}

bool isValidWord(char *word) {
    char accept[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    int32_t len = strspn(word, accept);

    if (len != 5) {
        return false;
    }

    return true;
}

bool isValidFeedback(char *buffer) {
    char accept[] = "BGY";
    int32_t len = strspn(buffer, accept);

    if (buffer[strlen(buffer) - 1] == '\n') {
        buffer[strlen(buffer) - 1] = '\0';
    }

    if (len == 5 && strlen(buffer) == 5) {
        return true;
    }

    return false;
}

bool updateWordValidity(const char *word, const char *comp, const char *feedback) {
    int32_t check[5] = {0};

    for (size_t i = 0; i < WORD_SIZE; i++) {
        if (feedback[i] == 'G') {
            check[i] = 1;

            if (word[i] != comp[i]) {
                return false;
            }
        } else if (feedback[i] == 'Y' || feedback[i] == 'B') {
            if (word[i] == comp[i]) {
                return false;
            }
        }
    }

    for (size_t i = 0; i < WORD_SIZE; i++) {
        if (feedback[i] != 'Y') {
            continue;
        }

        if (word[i] == comp[i]) {
            return false;
        }

        int32_t flag = 0;

        for (size_t j = 0; j < WORD_SIZE; j++) {
            if (j == i || check[j]) {
                continue;
            }

            if (word[j] == comp[i]) {
                check[j] = 1;
                flag = 1;
                break;
            }
        }

        if (!flag) {
            return false;
        }
    }

    for (size_t i = 0; i < WORD_SIZE; i++) {
        if (feedback[i] != 'B') {
            continue;
        }

        for (size_t j = 0; j < WORD_SIZE; j++) {
            if (check[j]) {
                continue;
            }

            if (word[j] == comp[i]) {
                return false;
            }
        }
    }

    return true;
}

uint64_t calculateWeight(char *word) {
    const uint64_t charWeight[] = {
        8200, 1500, 2800, 4300, 12700,      // ABCDE
        2200, 2000, 6100, 7000, 150,        // FGHIJ
        770,  4000, 2400, 6700, 7500,       // KLMNO
        1900, 95,   6000, 6300, 9100,       // PQRST
        2800, 980,  2400, 150,  2000, 74,   // UVWXYZ
    };
    uint64_t weight = 0;

    for (size_t i = 0; i < WORD_SIZE; i++) {
        int32_t idx = parseAlpha(word[i]);

        weight += charWeight[idx];
    }

    return weight;
}

int32_t parseAlpha(char ch) {
    if (ch >= 'a' && ch <= 'z') {
        ch -= 'a';
    } else if (ch >= 'A' && ch <= 'Z') {
        ch -= 'A';
    }

    return (int32_t) ch;
}

void clearWordle(Wordle *wordle) {
    if (wordle->word != NULL) {
        free(wordle->word);
    }
}
