#pragma once

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#define NAME_SIZE 256

typedef struct _Team {
    char name[NAME_SIZE];
    uint32_t win;
    uint32_t draw;
    uint32_t lose;
    uint32_t goalF;
    uint32_t goalA;
    uint32_t point;
} Team;

typedef struct _League {
    Team *team;
    uint32_t size;
} League;

/**
 * Process the csv file.
 * @param file the file stream pointer.
 * @return true: input correct, false: input error
 */
bool processCSV(FILE *file);

/**
 * Process each match of leagues.
 * @param league the league struct.
 * @param file the file stream pointer.
 * @return true: input correct, false: input error
 */
bool processLeague(League *league, FILE *file);

/**
 * Add a team to league.
 * @param league the league struct.
 * @param name the team name.
 * @return the index of team, -1: error input
 */
int32_t addTeam(League *league, char *name);

/**
 * Init a team.
 * @param league the league struct.
 * @param name the team name.
 * @return the index of team, -1: error input
 */
int32_t initTeam(League *league, char *name);

/**
 * Sort the league by points.
 * @param league the league struct.
 */
void sortLeague(League *league);

/**
 * Print the league.
 * @param league the league struct.
 */
void printLeague(League *league);

/**
 * Clear the league.
 * @param league the league struct.
 */
void clearLeague(League *league);
