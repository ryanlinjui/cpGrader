# hw02

Name: 41247039S 韓欣劭

Course: Computer Programming II

Link:

- [Question link](https://drive.google.com/file/d/1ani8FSxEBnrE48MvYh0w9FPed7NF9NzS/view)
- [Additional information](https://hackmd.io/@cp2023/cp2-hw2-info)

## Table of Contents

- [p1 Subtitle Player](#p1-subtitle-player)
- [p2 Premier League](#p2-premier-league)
- [p3 Wordle Solver](#p3-wordle-solver)
- [p4 BMP](#p4-bmp)
- [p5 Large Language Model](#p5-large-language-model)
- [p6 bonus](#p6-bonus-errno)

## p1 Subtitle Player

This program read the ASS file and present the content as subtitle player. Input the following data:

- ASS file name (the file should be same directory as the program)
- time shift (integer from -10 to 10, included)
- playback speed (only accept 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75 and 2)

and the program will start play the subtitle. Notes:

- It will only show the FIRST given color, while the remaining color will be ignored.
- Time shift and playback speed will be required to input again if any error input is given.

## p2 Premier League

This program will read the [Premier League CSV file](https://github.com/datasets/football-datasets/tree/master/datasets/premier-league) and output the final result in table form. The table includes:

- Team name, sorted by points > goal difference > goals for (GF).
- W/D/L stats
- GF/GA/GD stats
- points achieved

One of the result is given below:

```text
    Team                 W    D    L    GF    GA    GD    Pts
01) Liverpool            17   3    1    49    10    +39    54
02) Man City             16   2    3    56    17    +39    50
03) Tottenham            16   0    5    46    21    +25    48
04) Chelsea              13   5    3    38    16    +22    44
05) Arsenal              12   5    4    46    31    +15    41
06) Man United           11   5    5    43    32    +11    38
07) Leicester            9    4    8    25    23    +2     31
08) Watford              8    5    8    30    31    -1     29
09) Wolves               8    5    8    23    25    -2     29
10) West Ham             8    4    9    29    32    -3     28
11) Everton              7    6    8    31    31    +0     27
12) Bournemouth          8    3    10   31    40    -9     27
13) Brighton             7    5    9    24    29    -5     26
14) Crystal Palace       6    4    11   19    26    -7     22
15) Newcastle            4    6    11   15    29    -14    18
16) Burnley              5    3    13   21    42    -21    18
17) Cardiff              5    3    13   19    41    -22    18
18) Southampton          3    7    11   21    38    -17    16
19) Fulham               3    5    13   19    47    -28    14
20) Huddersfield         2    4    15   13    37    -24    10
```

## p3 Wordle Solver

This program will solve the Wordle game with a given [dictionary](https://cgit.freedesktop.org/libreoffice/dictionaries/tree/en). The dictionary `en_US.dic` must present in the same directory with the program or otherwise it will terminate the program.

The program will produce the following steps:

1. The program will give a best word to guess in current situation.
2. The user replies the result of the guessed word, by giving a string with
length of 5. The string must only includes 3 types of alphabets: 'B' means
the alphabet not in the word, 'Y' means the alphabet is in the word but wrong
position, 'G' means the alphabet is in the word and correct position.
3. Repeat the step 1 and 2 until the word is guessed. In other words, the user
should give a feedback of "GGGGG" to end the program.

One of the example is given below (the word is 'apple'):

```text
Advice:   EERIE
Feedback: BBBBG
Advice:   STATE
Feedback: BBYBG
Advice:   ANODE
Feedback: GBBBG
Advice:   ALGAE
Feedback: GYBBG
Advice:   AMPLE
Feedback: GBGGG
Advice:   APPLE
Feedback: GGGGG
Congratulations!!
```

## p4 BMP

This program will skew the image with given angle. The user input the BMP image and the skew angle in degree (0 to 90, exclude 90), then the program will produce the skewed image.

If the angle is invalid, the user is required to input again.

## p5 Large Language Model

This program will process the GGUF file and output the metadata and tensors of the file. Notes:

- It only accepts the file named with `model.gguf` in the same directory with the program.
- The metadata is sorted by the name with lexicographic order.
- The tensors is grouped and sorted increasingly by the block number.
- If the magic number is incorrect, it will give the result of `GGUF: false`.

## p6 Bonus: errno

the bonus question is written in [hw0206.md](hw0206.md).
