#pragma once

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif

typedef struct _Subtitle {
    uint8_t color[3];
    int32_t shift;
    double  speed;
} Subtitle;

/**
 * Play the subtitle with given ass file.
 * @param file the ass file.
 * @return 1: valid file; 0: invalid file
 */
int32_t playSubtitle(FILE *file);

/**
 * Set the time shift, from -10 to 10.
 * @param shift the time shift pointer.
 * @return 1: valid input; 0: invalid input
 */
int32_t setTimeShift(int32_t *shift);

/**
 * Set the playback speed, accepts value:
 * 0.25, 0.50, 0.75, 1.00, 1.25, 1.50, 1.75, 2.00.
 * @param speed the playback speed pointer.
 * @return 1: valid input; 0: invalid input
 */
int32_t setPlaybackSpeed(double *speed);

/**
 * Read the primary color from the ass file.
 * @param file the file stream pointer.
 * @param subtitle the subtitle struct.
 * @return 1: valid input; 0: invalid input
 */
int32_t readPrimaryColor(FILE *file, Subtitle *subtitle);

/**
 * Read the dialogue from the ass file.
 * @param file the file stream pointer.
 * @param subtitle the subtitle struct.
 * @return 1: valid input; 0: invalid input
 */
int32_t readDialogue(FILE *file, Subtitle *subtitle);

/**
 * Convert the primary color string to color.
 * @param file the file stream pointer.
 * @param subtitle the subtitle struct.
 * @return 1: valid color; 0: invalid color
 */
int32_t parseColor(const char *str, uint8_t *color);

/**
 * Convert the hex character to decimal.
 * @param ch the hex character.
 * @return the decimal number; -1: not a hex char.
 */
int8_t parseHex(char ch);

/**
 * Convert the dec character to decimal.
 * @param ch the dec character.
 * @return the decimal number; -1: not a dec char.
 */
int8_t parseDec(char ch);

/**
 * Convert the time string to integer in microseconds.
 * @param time the time string.
 * @return the time in microseconds.
 */
uint64_t parseTime(char *time);
