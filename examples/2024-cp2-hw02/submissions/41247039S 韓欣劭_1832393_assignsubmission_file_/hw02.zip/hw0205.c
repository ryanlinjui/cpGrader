#include <stdio.h>
#include <stdlib.h>

#include "myfile.h"
#include "mygguf.h"

int main() {
    FILE *file = NULL;
    char fileName[] = "model.gguf";

    if (!openFile(&file, fileName, "r")) {
        return 1;
    }

    int32_t res = 0;

    if (!processGGUF(file)) {
        res = 1;
    }

    closeFile(file);

    return res;
}
