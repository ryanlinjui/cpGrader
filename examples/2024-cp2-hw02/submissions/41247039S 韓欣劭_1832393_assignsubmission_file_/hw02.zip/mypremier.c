#include "mypremier.h"

bool processCSV(FILE *file) {
    if (file == NULL) {
        return false;
    }

    League league = {NULL, 0};

    if (!processLeague(&league, file)) {
        return false;
    }

    sortLeague(&league);
    printLeague(&league);
    clearLeague(&league);

    return true;
}

bool processLeague(League *league, FILE *file) {
    char buffer[512] = {0};

    char homeTeam[NAME_SIZE] = {0};
    char awayTeam[NAME_SIZE] = {0};
    uint32_t homeGoal = 0;
    uint32_t awayGoal = 0;

    if (fgets(buffer, 512, file) == NULL) {
        return false;
    }

    while (!feof(file)) {
        if (fscanf(file, "%*[^,],%[^,],%[^,],%u,%u,%*[^\n]", homeTeam, awayTeam, &homeGoal, &awayGoal) != 4) {
            break;
        }

        int32_t homeIdx = addTeam(league, homeTeam);
        int32_t awayIdx = addTeam(league, awayTeam);

        if (homeIdx == -1 || awayIdx == -1) {
            return false;
        }

        league->team[homeIdx].goalA += homeGoal;
        league->team[homeIdx].goalF += awayGoal;

        league->team[awayIdx].goalA += awayGoal;
        league->team[awayIdx].goalF += homeGoal;

        if (homeGoal == awayGoal) {
            league->team[homeIdx].draw++;
            league->team[awayIdx].draw++;

            league->team[homeIdx].point += 1;
            league->team[awayIdx].point += 1;
        } else if (homeGoal > awayGoal) {
            league->team[homeIdx].win++;
            league->team[awayIdx].lose++;

            league->team[homeIdx].point += 3;
        } else {
            league->team[homeIdx].lose++;
            league->team[awayIdx].win++;

            league->team[awayIdx].point += 3;
        }
    }

    if (!feof(file)) {
        return false;
    }

    return true;
}

int32_t addTeam(League *league, char *name) {
    if (name == NULL) {
        return -1;
    }

    for (uint32_t i = 0; i < league->size; i++) {
        if (strcmp(league->team[i].name, name) == 0) {
            return i;
        }
    }

    return initTeam(league, name);
}

int32_t initTeam(League *league, char *name) {
    if (league->size == 0) {
        league->size++;
        league->team = (Team *) calloc(1, sizeof(Team));
    } else {
        league->size++;
        league->team = (Team *) reallocarray(league->team, league->size, sizeof(Team));
    }

    Team *team   = league->team;
    uint32_t pos = league->size - 1;

    for (uint32_t i = 0; i < strlen(name); i++) {
        team[pos].name[i] = name[i];
    }
    team[pos].name[strlen(name)] = 0;

    team[pos].win   = 0;
    team[pos].draw  = 0;
    team[pos].lose  = 0;
    team[pos].goalA = 0;
    team[pos].goalF = 0;
    team[pos].point = 0;

    return pos;
}

void sortLeague(League *league) {
    for (uint32_t i = 0; i < league->size; i++) {
        for (uint32_t j = i + 1; j < league->size; j++) {
            uint32_t igoalF = league->team[i].goalF;
            uint32_t jgoalF = league->team[j].goalF;

            if (jgoalF >= igoalF) {
                Team temp = league->team[i];
                league->team[i] = league->team[j];
                league->team[j] = temp;
            }
        }
    }

    for (uint32_t i = 0; i < league->size; i++) {
        for (uint32_t j = i + 1; j < league->size; j++) {
            uint32_t igoalD = league->team[i].goalF - league->team[i].goalA;
            uint32_t jgoalD = league->team[j].goalF - league->team[j].goalA;

            if (jgoalD >= igoalD) {
                Team temp = league->team[i];
                league->team[i] = league->team[j];
                league->team[j] = temp;
            }
        }
    }

    for (uint32_t i = 0; i < league->size; i++) {
        for (uint32_t j = i + 1; j < league->size; j++) {
            uint32_t iPoint = league->team[i].point;
            uint32_t jPoint = league->team[j].point;

            if (jPoint >= iPoint) {
                Team temp = league->team[i];
                league->team[i] = league->team[j];
                league->team[j] = temp;
            }
        }
    }
}

void printLeague(League *league) {
    int32_t teamLength = -20;

    // for (uint32_t i = 0; i < league->size; i++) {
    //     int32_t len = strlen(league->team[i].name);
    //     if (teamLength < len) {
    //         teamLength = len;
    //     }
    // }

    // teamLength++;
    // teamLength = -teamLength;

    printf("    %*s W    D    L    GF    GA    GD    Pts\n", teamLength, "Team");

    for (uint32_t i = 0; i < league->size; i++) {
        int32_t diff = league->team[i].goalA - league->team[i].goalF;
        char diffCh  = 0;

        if (diff < 0) {
            diffCh = '-';
            diff = -diff;
        } else {
            diffCh = '+';
        }

        printf("%02u) ", i + 1);
        printf("%*s ", teamLength, league->team[i].name);
        printf("%-4u ", league->team[i].win);
        printf("%-4u ", league->team[i].draw);
        printf("%-4u ", league->team[i].lose);
        printf("%-5u ", league->team[i].goalA);
        printf("%-5u ", league->team[i].goalF);
        printf("%c%-4u ", diffCh, diff);
        printf("%3u", league->team[i].point);
        printf("\n");
    }
}

void clearLeague(League *league) {
    if (league->team != NULL) {
        free(league->team);
    }
}
