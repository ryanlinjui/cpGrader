#pragma once

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

struct _BmpHeader {
    char	 bm[2];
    uint32_t size;
    uint32_t reserve;
    uint32_t offset;
    uint32_t header_size;
    int32_t  width;
    int32_t  height;
    uint16_t planes;
    uint16_t bpp;
    uint32_t compression;
    uint32_t bitmap_size;
    int32_t  hres;
    int32_t  vres;
    uint32_t used;
    uint32_t important;
}__attribute__ ((__packed__));

typedef struct _BmpHeader BmpHeader;

/**
 * Process the image and output to a bmp file.
 * @param iFile input bmp image.
 * @param oFile output bmp image.
 * @return 1: valid input and output; 0: invalid input or output
 */
int32_t processImage(FILE *iFile, FILE *oFile);

/**
 * Skew the image and output to a bmp file.
 * @param iFile input bmp image.
 * @param oFile output bmp image.
 * @param header the input image header.
 * @param degree the skew angle.
 * @return 1: valid input and output; 0: invalid input or output
 */
int32_t skewImage(FILE *iFile, FILE *oFile, BmpHeader *header, double degree);

/**
 * Read the angle input. Only accept the angle in the range [0, 90).
 * @param degree the skew angle.
 * @return 1: valid input; 0: invalid input
 */
int32_t readAngle(double *degree);

/**
 * Calculate the length added after skewing the image.
 * @param height the height of image.
 * @param degree the skew angle.
 * @return the length added.
 */
int32_t skewLength(int32_t height, double degree);
