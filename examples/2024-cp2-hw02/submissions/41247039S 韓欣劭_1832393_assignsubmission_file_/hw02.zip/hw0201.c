#include <stdio.h>
#include <stdlib.h>

#include "myfile.h"
#include "mysubtitle.h"

int main() {
    FILE *file = NULL;
    char fileName[F_SIZE] = {0};

    printf("Please enter the file name: ");

    if (!inputFileName(fileName) || !openFile(&file, fileName, "r")) {
        return 1;
    }

    int32_t res = 0;

    if (!playSubtitle(file)) {
        printf("error: file error\n");
        res = 1;
    }

    closeFile(file);

    return res;
}
