#include <stdio.h>
#include <stdint.h>
#include <errno.h>
#include <string.h>

#define MY_NEW_ERROR 1000

void printError() {
    for (int32_t i = 0; i < 150; i++) {
        printf("errno: %d, %s\n", i, strerror(i));
    }
}

void f() {
    errno = MY_NEW_ERROR;
}

int main() {
    f();

    if (errno == MY_NEW_ERROR) {
        perror("new error");
    }

    return 0;
}
