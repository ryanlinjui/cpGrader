#include "mygguf.h"

int32_t processGGUF(FILE *file) {
    gguf_file_t gguf = {
        {0, 0, 0, 0, NULL}, NULL, NULL
    };

    int32_t result = 1;

    if (!readHeader(file, &(gguf.header))) {
        result = 0;
    }

    int64_t param = readTensor(file, &(gguf.tensor_infos), gguf.header.tensor_count);

    if (result && param) {
        printf("GGUF: true\n");

        printf("Parameters: ");
        printCommaNum(param);

        printf("\n\n");

        printGGUF(&gguf);
    } else {
        printf("GGUF: false\n");
    }

    // freeHeader(&(gguf.header));
    freeGGUF(&gguf);

    return result;
}

int32_t readHeader(FILE *file, gguf_header_t *header) {
    if (!fread(&(header->magic), 4, 1, file) || header->magic != 0x46554747) {
        return 0;
    }

    if (!fread(&(header->version), 4, 1, file) ||
        !fread(&(header->tensor_count), 8, 1, file) ||
        !fread(&(header->metadata_kv_count), 8, 1, file)) {
        return 0;
    }

    if (header->metadata_kv_count == 0) {
        return 1;
    }

    header->metadata_kv =
        (gguf_metadata_kv_t *) calloc(header->metadata_kv_count, sizeof(gguf_metadata_kv_t));

    for (size_t i = 0; i < header->metadata_kv_count; i++) {
        gguf_metadata_kv_t *metadata = &(header->metadata_kv[i]);

        if (!readString(file, &(metadata->key)) ||
            !fread(&(metadata->value_type), 4, 1, file) ||
            !readValue(file, &(metadata->value), metadata->value_type)) {
            return 0;
        }
    }

    sortMetaData(header);

    return 1;
}

int64_t readTensor(FILE *file, gguf_tensor_info_t **tensor, size_t tensor_size) {
    int64_t param = 0;

    *tensor = (gguf_tensor_info_t *) calloc(tensor_size, sizeof(gguf_tensor_info_t));

    for (size_t i = 0; i < tensor_size; i++) {
        gguf_tensor_info_t *info = &(*tensor)[i];

        if (!readString(file, &(info->name))) {
            return 0;
        }

        if (!fread(&(info->n_dimensions), 4, 1, file)) {
            return 0;
        }

        if (info->n_dimensions < 1 || info->n_dimensions > 4) {
            return 0;
        }

        info->dimensions = (uint64_t *) calloc(info->n_dimensions, sizeof(uint64_t));

        int64_t temp = 1;

        for (size_t j = 0; j < info->n_dimensions; j++) {
            if (!fread(&(info->dimensions[j]), 8, 1, file)) {
                return 0;
            }

            temp *= info->dimensions[j];
        }

        param += temp;

        if (!fread(&(info->type), 4, 1, file) ||
            !fread(&(info->offset), 8, 1, file)) {
            return 0;
        }
    }

    sortTensor(*tensor, tensor_size);

    return param;
}

int32_t readString(FILE *file, gguf_string_t *gstr) {
    if (!fread(&(gstr->len), 8, 1, file)) {
        return 0;
    }

    gstr->string = (char *) calloc(gstr->len + 1, sizeof(char));

    if (!fread(gstr->string, gstr->len, 1, file)) {
        return 0;
    }

    return 1;
}

int32_t readValue(FILE *file, gguf_metadata_value_t *value, gguf_metadata_value_type type) {
    if (type == GGUF_METADATA_VALUE_TYPE_STRING) {
        if (!readString(file, &(value->string))) {
            return 0;
        }

        return 1;
    } else if (type == GGUF_METADATA_VALUE_TYPE_ARRAY) {
        if (!fread(&(value->array.type), 4, 1, file) ||
            !fread(&(value->array.len),  8, 1, file)) {
            return 0;
        }

        size_t length = (value->array.len > 10) ? 10 : value->array.len;
        value->array.array = (gguf_metadata_value_t *) calloc(length, sizeof(gguf_metadata_value_t));

        for (size_t i = 0; i < length; i++) {
            if (!readValue(file, &(value->array.array[i]), value->array.type)) {
                return 0;
            }
        }

        for (size_t i = 0; i < value->array.len - length; i++) {
            if (!skipValue(file, value->array.type)) {
                return 0;
            }
        }

        return 1;
    }

    size_t size = 0;

    if (type == GGUF_METADATA_VALUE_TYPE_UINT8 ||
        type == GGUF_METADATA_VALUE_TYPE_INT8  ||
        type == GGUF_METADATA_VALUE_TYPE_BOOL) {
        size = 1;
    } else if (type == GGUF_METADATA_VALUE_TYPE_UINT16 ||
               type == GGUF_METADATA_VALUE_TYPE_INT16) {
        size = 2;
    } else if (type == GGUF_METADATA_VALUE_TYPE_UINT32 ||
               type == GGUF_METADATA_VALUE_TYPE_INT32  ||
               type == GGUF_METADATA_VALUE_TYPE_FLOAT32) {
        size = 4;
    } else if (type == GGUF_METADATA_VALUE_TYPE_UINT64 ||
               type == GGUF_METADATA_VALUE_TYPE_INT64  ||
               type == GGUF_METADATA_VALUE_TYPE_FLOAT64) {
        size = 8;
    } else {
        return 0;
    }

    if (!fread(value, size, 1, file)) {
        return 0;
    }

    return 1;
}

int32_t skipValue(FILE *file, gguf_metadata_value_type type) {
    gguf_metadata_value_t temp;

    if (!readValue(file, &temp, type)) {
        return 0;
    }

    freeValue(&temp, type);

    return 1;
}

void sortMetaData(gguf_header_t *header) {
    gguf_metadata_kv_t *metadata = header->metadata_kv;

    for (size_t i = 0; i < header->metadata_kv_count; i++) {
        for (size_t j = i+1; j < header->metadata_kv_count; j++) {
            if (strcmp(metadata[i].key.string, metadata[j].key.string) > 0) {
                gguf_metadata_kv_t temp = metadata[i];
                metadata[i] = metadata[j];
                metadata[j] = temp;
            }
        }
    }
}

void sortTensor(gguf_tensor_info_t *tensor, size_t tensor_size) {
    for (size_t i = 0; i < tensor_size; i++) {
        for (size_t j = i+1; j < tensor_size; j++) {
            if (strcmp(tensor[i].name.string, tensor[j].name.string) > 0) {
                gguf_tensor_info_t temp = tensor[i];
                tensor[i] = tensor[j];
                tensor[j] = temp;
            }
        }
    }

    bool flag = false;
    size_t head = 0, tail = 0;

    for (size_t i = 0; i < tensor_size; i++) {
        if (strstr(tensor[i].name.string, "blk.") == NULL) {
            if (!flag) {
                continue;
            } else {
                tail = i;
                break;
            }
        }

        if (!flag) {
            head = i;
            flag = true;
        }
    }

    for (size_t i = head; i < tail; i++) {
        for (size_t j = i + 1; j < tail; j++) {
            char *tmp_i = strpbrk(tensor[i].name.string, "0123456789");
            char *tmp_j = strpbrk(tensor[j].name.string, "0123456789");

            int32_t blk_i = 0;
            int32_t blk_j = 0;

            for (size_t k = 0; k < strspn(tmp_i, "0123456789"); k++) {
                blk_i = blk_i * 10 + (tmp_i[k] - '0');
            }

            for (size_t k = 0; k < strspn(tmp_j, "0123456789"); k++) {
                blk_j = blk_j * 10 + (tmp_j[k] - '0');
            }

            if (blk_i > blk_j) {
                gguf_tensor_info_t temp = tensor[i];
                tensor[i] = tensor[j];
                tensor[j] = temp;
            }
        }
    }
}

void printGGUF(gguf_file_t *gguf) {
    // Print Header

    gguf_header_t *header = &(gguf->header);

    if (header->metadata_kv_count == 0) {
        return;
    }

    int32_t len1 = -40;
    int32_t len2 = -25;

    printf("%*s %s\n",  len1, "Metadata", "Value");
    printf("%*s %u\n",  len1, "version", header->version);
    printf("%*s %lu\n", len1, "tensor_count", header->tensor_count);
    printf("%*s %lu\n", len1, "kv_count", header->metadata_kv_count);

    for (size_t i = 0; i < header->metadata_kv_count; i++) {
        gguf_metadata_kv_t *metadata  = &(header->metadata_kv[i]);
        gguf_metadata_value_type type = metadata->value_type;

        printf("%*s ", len1, metadata->key.string);
        printValue(&(metadata->value), type);
        printf("\n");
    }

    printf("\n");

    // Print Tensor

    printf("%*s %*s %s\n", len1, "Tensors", len2, "Shape", "Precision");

    int32_t blk = -1;

    for (size_t i = 0; i < header->tensor_count; i++) {
        gguf_tensor_info_t *tensor = &(gguf->tensor_infos[i]);

        printTensorName(tensor->name.string, len1, &blk);
        printDimension(tensor, -24);
        printPrecision(tensor->type);

        printf("\n");
    }
}

void printValue(gguf_metadata_value_t *value, gguf_metadata_value_type type) {
    if (type == GGUF_METADATA_VALUE_TYPE_STRING) {
        if (value->string.len < 35) {
            printf("%s", value->string.string);
        } else {
            for (size_t i = 0; i < 35; i++) {
                printf("%c", value->string.string[i]);
            }

            printf("...");
        }
    } else if (type == GGUF_METADATA_VALUE_TYPE_ARRAY) {
        size_t len = value->array.len > 5 ? 5 : value->array.len;

        printf("[");

        for (size_t i = 0; i < len; i++) {
            printValue(&(value->array.array[i]), value->array.type);

            if (i != len - 1) {
                printf(",");
            }
        }

        if (value->array.len > 5) {
            printf(",...");
        }

        printf("]");
    } else if (type == GGUF_METADATA_VALUE_TYPE_UINT8) {
        printf("%hhu", value->uint8);
    } else if (type == GGUF_METADATA_VALUE_TYPE_INT8) {
        printf("%hhd", value->int8);
    } else if (type == GGUF_METADATA_VALUE_TYPE_UINT16) {
        printf("%hu", value->uint16);
    } else if (type == GGUF_METADATA_VALUE_TYPE_INT16) {
        printf("%hd", value->int16);
    } else if (type == GGUF_METADATA_VALUE_TYPE_UINT32) {
        printf("%u", value->uint32);
    } else if (type == GGUF_METADATA_VALUE_TYPE_INT32) {
        printf("%d", value->int32);
    } else if (type == GGUF_METADATA_VALUE_TYPE_FLOAT32) {
        printf("%.21g", value->float32);
    } else if (type == GGUF_METADATA_VALUE_TYPE_BOOL) {
        printf(value->bool_ ? "true" : "false");
    } else if (type == GGUF_METADATA_VALUE_TYPE_UINT64) {
        printf("%lu", value->uint64);
    } else if (type == GGUF_METADATA_VALUE_TYPE_INT64) {
        printf("%ld", value->uint64);
    } else if (type == GGUF_METADATA_VALUE_TYPE_FLOAT64) {
        printf("%.21lg", value->float64);
    }
}

void printTensorName(char *name, int32_t len, int32_t *blk) {
    if (strstr(name, "blk.") == NULL) {
        printf("%*s ", len, name);
        return;
    }

    char *tmp = strpbrk(name, "0123456789");
    int32_t currBlk = 0;

    for (size_t i = 0; i < strspn(tmp, "0123456789"); i++) {
        currBlk = currBlk * 10 + (tmp[i] - '0');
    }

    if (*blk != currBlk) {
        *blk = currBlk;
        printf("blk.%d\n", *blk);
    }

    tmp = tmp + strspn(tmp, "0123456789");

    printf("    %*s ", len + 4, tmp);
}

void printDimension(gguf_tensor_info_t *tensor, int32_t len) {
    printf("[");
    for (size_t j = 0; j < tensor->n_dimensions; j++) {
        printf("%lu", tensor->dimensions[j]);

        if (j != tensor->n_dimensions - 1) {
            printf(",");
            len++;
        }

        len += numOfDigit(tensor->dimensions[j]);
    }
    printf("%*s ", len, "]");
}

void printPrecision(ggml_type type) {
    if (type == GGML_TYPE_F32) {
        printf("F32");
    } else if (type == GGML_TYPE_F16) {
        printf("F16");
    } else if (type == GGML_TYPE_Q4_0) {
        printf("Q4_0");
    } else if (type == GGML_TYPE_Q4_1) {
        printf("Q4_1");
    } else if (type == GGML_TYPE_Q5_0) {
        printf("Q5_0");
    } else if (type == GGML_TYPE_Q5_1) {
        printf("Q5_1");
    } else if (type == GGML_TYPE_Q8_0) {
        printf("Q8_0");
    } else if (type == GGML_TYPE_Q8_1) {
        printf("Q8_1");
    } else if (type == GGML_TYPE_Q2_K) {
        printf("Q2_K");
    } else if (type == GGML_TYPE_Q3_K) {
        printf("Q3_K");
    } else if (type == GGML_TYPE_Q4_K) {
        printf("Q4_K");
    } else if (type == GGML_TYPE_Q5_K) {
        printf("Q5_K");
    } else if (type == GGML_TYPE_Q6_K) {
        printf("Q6_K");
    } else if (type == GGML_TYPE_Q8_K) {
        printf("Q8_K");
    } else if (type == GGML_TYPE_I8) {
        printf("I8");
    } else if (type == GGML_TYPE_I16) {
        printf("I16");
    } else if (type == GGML_TYPE_I32) {
        printf("I32");
    } else if (type == GGML_TYPE_COUNT) {
        printf("COUNT");
    }
}

void printCommaNum(int64_t num) {
    if (num < 1000) {
        printf("%ld", num);
        return;
    }

    printCommaNum(num / 1000);
    printf(",%03ld", num % 1000);
}

int32_t numOfDigit(uint64_t num) {
    int32_t digit = 0;

    while (num > 0) {
        num /= 10;
        digit++;
    }

    return digit;
}

void freeGGUF(gguf_file_t *gguf) {
    // Free Header

    gguf_header_t *header = &(gguf->header);

    if (header->metadata_kv_count == 0) {
        return;
    }

    for (size_t i = 0; i < header->metadata_kv_count; i++) {
        gguf_metadata_kv_t *metadata = &(header->metadata_kv[i]);

        freeValue(&(metadata->value), metadata->value_type);

        if (metadata->key.string) {
            free(metadata->key.string);
            metadata->key.string = NULL;
        }
    }

    free(header->metadata_kv);
    header->metadata_kv = NULL;

    // Free Tensor

    gguf_tensor_info_t *tensor = gguf->tensor_infos;

    if (gguf->header.tensor_count == 0) {
        return;
    }

    for (size_t i = 0; i < gguf->header.tensor_count; i++) {
        gguf_tensor_info_t *info = &(tensor[i]);

        if (info->name.string) {
            free(info->name.string);
            info->name.string = NULL;
        }

        if (info->dimensions) {
            free(info->dimensions);
            info->dimensions = NULL;
        }
    }

    free(tensor);
    tensor = NULL;
}

void freeValue(gguf_metadata_value_t *value, gguf_metadata_value_type type) {
    if (type == GGUF_METADATA_VALUE_TYPE_STRING) {
        if (value->string.string != NULL) {
            free(value->string.string);
            value->string.string = NULL;
        }
    } else if (type == GGUF_METADATA_VALUE_TYPE_ARRAY) {
        gguf_metadata_value_type arrType = value->array.type;

        size_t len = value->array.len > 10 ? 10 : value->array.len;

        for (size_t i = 0; i < len; i++) {
            freeValue(&(value->array.array[i]), arrType);
        }

        free(value->array.array);
    }
}
