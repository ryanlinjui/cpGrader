#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define F_SIZE 1024

/**
 * Input a file name.
 * @param fileName the file name to be set.
 * @return true: correct input, false: error input
 */
bool inputFileName(char *fileName);

/**
 * Open a file.
 * @param file the file stream pointer.
 * @param fileName the file name.
 * @param mode the open mode.
 */
bool openFile(FILE **file, char *fileName, char *mode);

/**
 * Close a file.
 * @param file the file stream pointer.
 */
void closeFile(FILE *file);
