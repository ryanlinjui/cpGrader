#include <stdio.h>
#include <stdlib.h>

#include "myfile.h"
#include "myskew.h"

int main() {
    FILE *iFile = NULL;
    FILE *oFile = NULL;
    char iName[F_SIZE] = {0};
    char oName[F_SIZE] = {0};

    printf("Please input a BMP inputFile: ");

    if (!inputFileName(iName)) {
        return 1;
    }

    printf("Please input the output BMP inputFile name: ");

    if (!inputFileName(oName)) {
        return 1;
    }

    if (strcmp(iName, oName) == 0) {
        printf("Input file name and output file name cannot be the same.\n");

        return 1;
    }

    if (!openFile(&iFile, iName, "rb") || !openFile(&oFile, oName, "wb")) {
        return 1;
    }

    int32_t res = 0;

    if (!processImage(iFile, oFile)) {
        res = 1;
    }

    closeFile(iFile);
    closeFile(oFile);

    return res;
}
