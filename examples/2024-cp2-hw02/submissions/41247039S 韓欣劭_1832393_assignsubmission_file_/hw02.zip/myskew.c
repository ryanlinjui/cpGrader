#include "myskew.h"

#define PI 3.141592653589793238L

int32_t processImage(FILE *iFile, FILE *oFile) {
    BmpHeader header;
    double degree = 0;

    if (!fread(&header, sizeof(header), 1, iFile)) {
        printf("Input file error\n");
        return 0;
    }

    if (!readAngle(&degree)) {
        printf("Input error\n");
        return 0;
    }

    if (!skewImage(iFile, oFile, &header, degree)) {
        return 0;
    }

    return 1;
}

int32_t skewImage(FILE *iFile, FILE *oFile, BmpHeader *header, double degree) {
    int32_t height = header->height;

    if (height < 0) {
        height = -height;
    }

    int32_t oldWidth = header->width;
    int32_t addWidth = skewLength(height, degree);

    int32_t oldSize = (header->bpp * oldWidth + 31) / 32;
    int32_t addSize = (header->bpp * addWidth + 31) / 32;

    oldSize *= 4;
    addSize *= 4;

    int32_t oldRowSize = (header->bpp * oldWidth) / 8;
    int32_t addRowSize = (header->bpp * addWidth) / 8;

    int32_t oldPadding = oldSize - oldRowSize;
    int32_t addPadding = addSize - addRowSize;
    int32_t newPadding = (oldPadding + addPadding) % 4;

    // printf("%d %d %d\n", oldSize, oldRowSize, oldPadding);
    // printf("%d %d %d\n", addSize, addRowSize, addPadding);
    // printf("%d\n", newPadding);

    // Update image size

    int32_t size = addRowSize * height;
    size += newPadding * height;
    size -= oldPadding * height;

    header->size += size;
    header->bitmap_size += size;

    // Update image width

    header->width += addWidth;

    const uint8_t white = 255;

    fwrite(header, sizeof(*header), 1, oFile);

    for (int32_t i = 0; i < height; i++) {
        uint8_t temp = 0;

        int32_t addHeadSize = (header->bpp * skewLength(i, degree)) / 8;
        int32_t addTailSize = addRowSize - addHeadSize;

        if (header->height < 0) {
            int32_t swap = addHeadSize;
            addHeadSize  = addTailSize;
            addTailSize  = swap;
        }

        // Heading white empty space

        for (int32_t j = 0; j < addHeadSize; j++) {
            fwrite(&white, 1, 1, oFile);
        }

        // Original image

        for (int32_t j = 0; j < oldRowSize; j++) {
            fread(&temp, 1, 1, iFile);
            fwrite(&temp, 1, 1, oFile);
        }

        // Skip the padding of original image by reading it

        for (int32_t j = 0; j < oldPadding; j++) {
            fread(&temp, 1, 1, iFile);
        }

        // Trailing white empty space

        for (int32_t j = 0; j < addTailSize; j++) {
            fwrite(&white, 1, 1, oFile);
        }

        // Add padding to new image

        for (int32_t j = 0; j < newPadding; j++) {
            fwrite(&white, 1, 1, oFile);
        }
    }

    return 1;
}

int32_t readAngle(double *degree) {
    bool isValid = false;

    while (!isValid) {
        printf("Angle (0-90): ");

        if (scanf("%lf", degree) != 1) {
            return 0;
        }

        if (*degree >= 0 && *degree < 90) {
            isValid = true;
        } else {
            printf("Invalid degree, please input again\n");
        }
    }

    return 1;
}

int32_t skewLength(int32_t height, double degree) {
    if (height < 0) {
        height = -height;
    }

    double length = height * tan(degree * PI / 180.0);

    return (int32_t) round(length);
}
