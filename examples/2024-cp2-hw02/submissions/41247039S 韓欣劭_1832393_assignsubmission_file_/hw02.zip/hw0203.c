#include <stdio.h>
#include <stdlib.h>

#include "myfile.h"
#include "mywordle.h"

int main() {
    FILE *file = NULL;
    char fileName[] = "en_US.dic";

    if (!openFile(&file, fileName, "r")) {
        return 1;
    }

    int32_t res = 0;

    if (!playWordle(file)) {
        res = 1;
    }

    closeFile(file);

    return res;
}
