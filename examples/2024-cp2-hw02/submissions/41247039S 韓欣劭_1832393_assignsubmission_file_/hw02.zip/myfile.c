#include "myfile.h"

bool inputFileName(char *file) {
    if (fgets(file, F_SIZE, stdin) == NULL) {
        if (fgetc(stdin) == EOF) {
            printf("myfile: EOF detected\n");
        } else {
            perror("myfile: input error");
        }

        return false;
    }

    if (file[strlen(file) - 1] == '\n') {
        file[strlen(file) - 1] = '\0';
    }

    return true;
}

bool openFile(FILE **file, char *fileName, char *mode) {
    *file = fopen(fileName, mode);

    if (*file == NULL) {
        char err[F_SIZE] = {0};
        snprintf(err, F_SIZE, "myfile: '%s' error", fileName);
        perror(err);

        return false;
    }

    return true;
}

void closeFile(FILE *file) {
    if (file == NULL) {
        return;
    }

    fclose(file);
}
