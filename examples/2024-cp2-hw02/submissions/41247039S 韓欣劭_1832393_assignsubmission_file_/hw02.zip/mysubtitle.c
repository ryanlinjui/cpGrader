#include "mysubtitle.h"

#define S_SIZE 1024

int32_t playSubtitle(FILE *file) {
    if (file == NULL) {
        printf("File error\n");
        return 0;
    }

    Subtitle subtitle = {{0}, 0, 0};

    if (!setTimeShift(&(subtitle.shift)) || !setPlaybackSpeed(&(subtitle.speed))) {
        printf("Input error\n");
        return 0;
    }

    if (!readPrimaryColor(file, &subtitle) || !readDialogue(file, &subtitle)) {
        printf("File process error\n");
        return 0;
    }

    return 1;
}

int32_t setTimeShift(int32_t *shift) {
    if (shift == NULL) {
        return 0;
    }

    bool valid = false;

    while (!valid) {
        printf("Time Shift ( -10 ~ 10 ): ");

        if (scanf("%d", shift) != 1) {
            return 0;
        }

        if (-10 <= *shift && *shift <= 10) {
            valid = true;
        } else {
            printf("Error time shift, please input again\n");
        }
    }

    return 1;
}

int32_t setPlaybackSpeed(double *speed) {
    if (speed == NULL) {
        return 0;
    }

    bool valid = false;

    double check[] = {
        0.25, 0.50, 0.75, 1.00,
        1.25, 1.50, 1.75, 2.00
    };

    while (!valid) {
        printf("Speed (0.25,0.5,0.75,1,1.25,1.5,1.75,2): ");

        if (scanf("%lf", speed) != 1) {
            return 0;
        }

        for (int32_t i = 0; i < 8; i++) {
            if (*speed == check[i]) {
                valid = true;
                break;
            }
        }

        if (!valid) {
            printf("Error speed, please input again\n");
        }
    }

    return 1;
}

int32_t readPrimaryColor(FILE *file, Subtitle *subtitle) {
    if (file == NULL) {
        return 0;
    }

    char buffer[S_SIZE] = {0};

    rewind(file);

    while (fgets(buffer, S_SIZE, file)) {
        if (strstr(buffer, "[V4+ Styles]") != NULL) {
            break;
        }
    }

    // Find primary color field

    if (!fgets(buffer, S_SIZE, file) || !strstr(buffer, "Format:")) {
        return 0;
    }

    int32_t field = 0;

    char *token = strtok(buffer, ",");

    while (token) {
        if (strstr(token, "PrimaryColour")) {
            break;
        }

        token = strtok(NULL, ",");
        field++;
    }

    if (token == NULL) {
        return 0;
    }

    // Find the value of primary color

    if (!fgets(buffer, S_SIZE, file) || !strstr(buffer, "Style:")) {
        return 0;
    }

    token = strtok(buffer, ",");

    while (field--) {
        token = strtok(NULL, ",");
    }

    if (!parseColor(token, subtitle->color)) {
        return 0;
    }

    return 1;
}

int32_t readDialogue(FILE *file, Subtitle *subtitle) {
    if (file == NULL) {
        return 0;
    }

    char buffer[S_SIZE] = {0};

    rewind(file);

    while (fgets(buffer, S_SIZE, file)) {
        if (strstr(buffer, "[Events]") != NULL) {
            break;
        }
    }

    // Find start time, end time and text field

    if (!fgets(buffer, S_SIZE, file) || !strstr(buffer, "Format:")) {
        return 0;
    }

    size_t total = 0;
    size_t field = 0;
    size_t startField = 0;
    size_t endField   = 0;
    size_t textField  = 0;

    char *token = strtok(buffer, ",");

    while (token) {
        if (strstr(token, "Start")) {
            startField = field;
            total++;
        } else if (strstr(token, "End")) {
            endField = field;
            total++;
        } else if (strstr(token, "Text")) {
            textField = field;
            total++;
        }

        if (total == 3) {
            break;
        }

        token = strtok(NULL, ",");
        field++;
    }

    if (total != 3) {
        return 0;
    }

    // printf("%lu %lu %lu %lu\n", startField, endField, textField, field);

    uint64_t time = 0;

    while (fgets(buffer, S_SIZE, file) && strstr(buffer, "Dialogue:")) {
        uint64_t startTime = 0;
        uint64_t endTime   = 0;

        char *temp = buffer;

        for (size_t i = 0; i < textField; i++) {
            char *token = strsep(&temp, ",");

            if (i == startField) {
                startTime = parseTime(token);
            } else if (i == endField) {
                endTime = parseTime(token);
            }
        }

        startTime += subtitle->shift * 1000000;
        startTime /= subtitle->speed;

        endTime += subtitle->shift * 1000000;
        endTime /= subtitle->speed;

        if (!(time <= startTime && startTime <= endTime)) {
            return 0;
        }

        uint64_t sleepBefore = startTime - time;
        uint64_t sleepMiddle = endTime - startTime;

        system("clear");
        usleep(sleepBefore);

        printf("\x1B[38;2;%hhu;%hhu;%hhum", subtitle->color[0], subtitle->color[1], subtitle->color[2]);
        printf("%s", temp);
        printf("\x1B[0m");

        usleep(sleepMiddle);

        time = endTime;
    }

    return 1;
}

int32_t parseColor(const char *str, uint8_t *color) {
    if (str == NULL || color == NULL) {
        return 0;
    }

    bool hex = false;

    for (size_t i = 0; i < strlen(str); i++) {
        if (str[i] == 'H') {
            hex = true;
            break;
        }
    }

    char *tmp = strpbrk(str, "0123456789abcdefABCDEF");

    if (tmp == NULL) {
        return false;
    }

    if (hex) {
        size_t offset = 0;

        if (strlen(tmp) >= 8) {
            offset = 2;
        }

        for (size_t i = 0; i < 6; i++) {
            size_t idx = i / 2;
            char ch = tmp[i + offset];

            color[2 - idx] = color[2 - idx] * 16 + (uint8_t) parseHex(ch);
        }
    } else {
        size_t num = 0;

        for (size_t i = 0; i < 10; i++) {
            int8_t parse = parseDec(tmp[i]);

            if (parse == -1) {
                break;
            }

            num = num * 10 + parse;
        }

        for (size_t i = 0; i < 3; i++) {
            size_t curr = (num >> (i * 8)) & 0xff;

            color[i] = curr;
        }
    }

    return 1;
}

int8_t parseHex(char ch) {
    int8_t res = 0;

    if ('0' <= ch && ch <= '9') {
        res = ch - '0';
    } else if ('a' <= ch && ch <= 'f') {
        res = ch - 'a' + 10;
    } else if ('A' <= ch && ch <= 'F') {
        res = ch - 'A' + 10;
    } else {
        res = -1;
    }

    return res;
}

int8_t parseDec(char ch) {
    int8_t res = 0;

    if ('0' <= ch && ch <= '9') {
        res = ch - '0';
    } else {
        res = -1;
    }

    return res;
}

uint64_t parseTime(char *time) {
    uint64_t times[3] = {0};
    size_t i = 0, count = 0;

    for (i = 0; i < strlen(time); i++) {
        if (time[i] == ':') {
            count++;
        } else if (time[i] == '.') {
            continue;
        } else {
            times[count] = times[count] * 10 + parseDec(time[i]);
        }
    }

    // for (size_t i = 0; i < 3; i++) {
    //     printf("%lu-", times[i]);
    // }
    // printf("\n");

    uint64_t result = times[2] * 10000;
    result += times[1] * 60 * 1000000;
    result += times[0] * 3600 * 1000000;

    return result;
}
