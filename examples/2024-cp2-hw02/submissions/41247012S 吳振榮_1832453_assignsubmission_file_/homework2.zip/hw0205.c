#include <stdio.h>
#include <stdint.h>
int main(){
    printf("GGUF: false\n");

    return 0;
}