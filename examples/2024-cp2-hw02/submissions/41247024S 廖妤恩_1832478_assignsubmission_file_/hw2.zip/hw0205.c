#include<stdio.h>
#include<stdint.h>

int main()
{
    char input[1025];
    FILE *file = fopen( "model.gguf", "r" );
    if ( file == NULL )
    {
        printf ("No such file, please check your file again.\n");
        return 0;
    }
    char check[4];
    fread( &check, 4, 1, file );
    if ( check[0] != 'G' || check[1] != 'G' || check[2] != 'U' || check[3] != 'F' )
    {
        printf("Wrong file, please input again.\n");
        return 0;
    }
}