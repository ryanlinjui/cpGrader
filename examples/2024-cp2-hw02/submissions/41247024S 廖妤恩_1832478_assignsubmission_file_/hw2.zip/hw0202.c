#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<stdlib.h>

typedef struct _sRecord
{
    char name[100];
    int32_t win;
    int32_t deuce;
    int32_t lose;
    int32_t get;
    int32_t take;
    int32_t minus;
    int32_t total;
} sRecord;

int main ()
{   
    printf("Please enter the data file name: ");
    char path[1025];
    fgets ( path, 1025, stdin );
    if ( path[ strlen(path) - 1 ] == 10 ) path[ strlen(path) - 1 ] = 0;
    FILE *file = fopen ( path, "r" );
    if ( file == NULL )
    {
        printf ("Wrong file, please check your file again.\n");
        return 0;
    }
    sRecord save[1000];
    int32_t length = 0;
    char input[1025];
    int32_t h = 0;
    int32_t skip = 0;
    while ( fgets ( input, 1025, file ) != NULL )
    {
        //save to struct
        h = 0;
        if ( skip == 0 )
        {
            skip++;
            continue;
        }
        char *a = input;
        //printf("%s\n",a);
        while( *a != ',' ) a++; 
        a++;
        int32_t xsite = 0;
        int32_t ysite = 0;
        int32_t x = 0;
        int32_t y = 0;
        for ( int32_t i = 0 ; i < 4 ; i ++ )
        {
            int32_t checkl = 0;
            char *b = (char *)calloc( strlen(a), sizeof(char) );
            //printf("%d\n",strlen(a));
            if ( i == 0 )
            {
                int32_t m = 0;
                //copy a to b
                while ( *a != ',' )
                {
                    b[m] = *a;
                    //printf("%c",b[m]);
                    a++;
                    m++;
                }
                a++;
                int32_t len = strlen(b);
                //check whether this name is exist
                for ( int32_t j = 0 ; j < length ; j ++ )
                {
                    int32_t check = 0;
                    for ( int32_t k = 0 ; k < len ; k ++ )
                    {
                        if ( save[j].name[k] == b[k] ) check++;
                    }
                    if ( check == len ) 
                    {
                        xsite = j;
                        checkl = 1;
                        break;
                    } 
                }
                if ( checkl == 0 ) 
                {
                    xsite = length;
                    save[xsite].win = 0;
                    save[xsite].deuce = 0;
                    save[xsite].lose = 0;
                    save[xsite].get = 0;
                    save[xsite].take = 0;
                    save[xsite].minus = 0; 
                    save[xsite].total = 0;
                    length++;
                }
                //copy
                for ( int32_t j = 0 ; j < len ; j ++ )
                {
                    save[xsite].name[j] = b[j];
                }
            }
            else if ( i == 1 )
            {
                int32_t m = 0;
                //copy a to b
                while ( *a != ',' )
                {
                    b[m] = *a;
                    //printf("%c",b[m]);
                    a++;
                    m++;
                }
                a++;
                int32_t len = strlen(b);
                //check whether this name is exist
                for ( int32_t j = 0 ; j < length ; j ++ )
                {
                    int32_t check = 0;
                    for ( int32_t k = 0 ; k < len ; k ++ )
                    {
                        if ( save[j].name[k] == b[k] ) check++;
                    }
                    if ( check == len ) 
                    {
                        ysite = j;
                        checkl = 1;
                        break;
                    } 
                }
                if ( checkl == 0 ) 
                {
                    ysite = length;
                    save[ysite].win = 0;
                    save[ysite].deuce = 0;
                    save[ysite].lose = 0;
                    save[ysite].get = 0;
                    save[ysite].take = 0;
                    save[ysite].minus = 0; 
                    save[ysite].total = 0;
                    length++;
                }
                //copy
                for ( int32_t j = 0 ; j < len ; j ++ )
                {
                    save[ysite].name[j] = b[j];
                }
            }
            else if ( i == 2 )
            {
                while ( *a != ',' )
                {
                    x = x*10 + *a - '0';
                    a++;
                }
                a++;
                //printf("%d\n",x);
            }
            else if ( i == 3 )
            {
                while ( *a != ',' )
                {
                    y = y*10 + *a - '0';
                    a++;
                }
                a++;
            }
            free(b);
        }
        //win or lose
        if ( x > y )
        {
            save[xsite].win++;
            save[ysite].lose++;
        }
        else if ( x < y )
        {
            save[xsite].lose++;
            save[ysite].win++;
        }
        else
        {
            save[xsite].deuce++;
            save[ysite].deuce++;
        }
        //point
        save[xsite].get += x;
        save[ysite].get += y;
        save[xsite].take += y;
        save[ysite].take += x;
        save[xsite].minus += (x-y);
        save[ysite].minus += (y-x);
    }
    for ( int32_t i = 0 ; i < length ; i ++ )
    {
        save[i].total = save[i].win*3 + save[i].deuce;
    }
    //sort
    for ( int32_t i = 0 ; i < length ; i ++ )
    {
        for ( int32_t j = i + 1 ; j < length ; j ++ )
        {
            if ( save[i].total < save[j].total )
            {
                sRecord temp = save[i];
                save[i] = save[j];
                save[j] = temp;
            }
        }
    }
    //gd
    for ( int32_t i = 0 ; i < length ; i ++ )
    {
        for ( int32_t j = i + 1 ; j < length ; j ++ )
        {
            if ( save[i].total == save[j].total && save[i].minus < save[j].minus )
            {
                sRecord temp = save[i];
                save[i] = save[j];
                save[j] = temp;
            }
        }
    }
    //gf
    for ( int32_t i = 0 ; i < length ; i ++ )
    {
        for ( int32_t j = i + 1 ; j < length ; j ++ )
        {
            if ( save[i].total == save[j].total && save[i].minus == save[j].minus && save[i].get < save[j].get )
            {
                sRecord temp = save[i];
                save[i] = save[j];
                save[j] = temp;
            }
        }
    }
    printf("    Team                  W    D    L    GF    GA    GD    Pts\n");
    for ( int32_t i = 0 ; i < length ; i ++ )
    {
        if ( i+1 < 10 ) printf ( "0%d) ", i+1 );
        else printf ( "%d) ", i+1 );
        //printf ("%-21s %-4d %-4d %-4d %-5d %-5d %-5d %3d\n",save[i].name, save[i].win, save[i].deuce, save[i].lose, save[i].get, save[i].take, save[i].minus, save[i].total );
        printf ( "%-21s %-4d %-4d %-4d %-5d %-6d",save[i].name, save[i].win, save[i].deuce, save[i].lose, save[i].get, save[i].take );
        if ( save[i].minus >= 0 )
        {
            printf( "+%-5d", save[i].minus );
        }
        else
        {
            printf( "%-6d", save[i].minus );
        }
        printf( "%3d\n", save[i].total );
    }
    fclose(file);
}