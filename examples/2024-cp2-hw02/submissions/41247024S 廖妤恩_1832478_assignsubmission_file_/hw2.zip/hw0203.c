#include<stdio.h>
#include<stdint.h>
#include<string.h>

typedef struct _sWord
{
    char word[6];
    int32_t fre;
    int32_t alive;
} sWord;

int main()
{
    char input[1025];
    FILE *file = fopen ( "en_US.dic", "r" );
    if ( file == NULL )
    {
        printf ("No such file, please check your file again.\n");
        return 0;
    }
    int32_t diclength = 0;
    sWord voc[5000];
    while ( fgets ( input, 1025, file ) != NULL )
    {
        //save word
        if ( strlen ( input ) == 6 )
        {
            int32_t count = 0;
            for ( int32_t i = 0 ; i < 5 ; i ++ )
            {
                if ( ( input[i] >= 'A' && input[i] <= 'Z' ) || ( input[i] >= 'a' && input[i] <= 'z' ) ) count++;
            }
            if ( count == 5 )
            {
                for ( int32_t i = 0 ; i < 5 ; i ++ )
                {
                    voc[diclength].word[i] = input[i];
                }
                voc[diclength].word[5] = '\0';
                diclength++;
            } 
            //printf("%s",input);
        }
        else if ( strlen ( input ) > 6 )
        {
            if ( input[5] == '/' )
            {
                int32_t count = 0;
                for ( int32_t i = 0 ; i < 5 ; i ++ )
                {
                    if ( ( input[i] >= 'A' && input[i] <= 'Z' ) || ( input[i] >= 'a' && input[i] <= 'z' ) ) count++;
                
                }
                if ( count == 5 )
                {
                    for ( int32_t i = 0 ; i < 5 ; i ++ )
                    {
                        voc[diclength].word[i] = input[i];
                    }
                    voc[diclength].word[5] = '\0';
                    diclength++;
                }
            }
        }
    }
    //printf("%d\n",diclength);
    //to big
    for ( int32_t i = 0 ; i < diclength ; i ++ )
    {
        for ( int32_t j = 0 ; j < 5 ; j ++ )
        {
            if ( voc[i].word[j] >= 'a' && voc[i].word[j] <= 'z' )
            {
                voc[i].word[j] -= 32;
            }
        }
    }
    int32_t frequent[26] = { 8200, 1500, 2800, 4300, 12700, 2200, 2000, 6100, 7000, 150, 770, 4000, 2400, 6700, 7500, 1900, 95, 6000, 6300, 9100, 2800, 980, 2400, 150, 2000, 74 };
    //count fre
    for ( int32_t i = 0 ; i < diclength ; i ++ )
    {
        voc[i].fre = 0;
        voc[i].alive = 0; //0 is alive
        for ( int32_t j = 0 ; j < 5 ; j ++ )
        {
            voc[i].fre += frequent[(voc[i].word[j])-65];
        }
    }
    int32_t advicefre = 0;
    char advice[6] = { 'E', 'E', 'R', 'I', 'E', '\0' };
    while ( 1 )
    {
        printf ( "Advice:   %s\n", advice );
        char in[1025];
        printf ("Feedback: ");
        fgets ( in, sizeof(in), stdin );
        advicefre = 0;
        if ( in [ strlen(in) - 1 ] == '\n' ) in [ strlen(in) - 1 ] = '\0';
        //if ( strcmp ( in, "ans" ) == 0 ) break;
        if ( strlen(in) != 5 )
        {
            printf( "Wrong input\n" );
            return 0;
        }
        for ( int32_t i = 0 ; i < 5 ; i ++ )
        {
            if ( in[i] != 'B' && in[i] != 'G' && in[i] != 'Y' )
            {
                printf ("Wrong input\n");
                return 0;
            }
        }
        if ( strcmp ( in, "GGGGG" ) == 0 )
        {
            printf ("Congratulations!!\n");
            return 0;
        }
        int32_t ycount[26] = {0}, gcount[26] = {0}, bcount[26] = {0};
        for ( int32_t i = 0 ; i < 5 ; i ++ )
        {
            if ( in[i] == 'Y' ) ycount[advice[i]-'A']++;
            if ( in[i] == 'G' ) gcount[advice[i]-'A']++;
            if ( in[i] == 'B' ) bcount[advice[i]-'A']++;
        } 
        for ( int32_t i = 0 ; i < 5 ; i ++ )
        {
            if ( in[i] == 'B' )
            {
                for ( int32_t j = 0 ; j < diclength ; j ++ )
                {
                    if ( advice[i] == voc[j].word[i] ) voc[j].alive++;
                    if ( !ycount[advice[i]-'A'] && !gcount[advice[i]-'A'] )
                    {
                        for ( int32_t k = 0 ; k < 5 ; k ++ ) 
                        {
                            if ( advice[i] == voc[j].word[k] ) voc[j].alive++;
                        }
                    }
                }
            }
            else if ( in[i] == 'Y' )
            {
                for ( int32_t j = 0 ; j < diclength ; j ++ )
                {
                    if ( advice[i] == voc[j].word[i] ) voc[j].alive++;
                    
                }
            }
            else if ( in[i] == 'G' )
            {
                for ( int32_t j = 0 ; j < diclength ; j ++ )
                {
                    if ( advice[i] != voc[j].word[i] ) voc[j].alive++;
                }
            }
            for ( int32_t j = 0 ; j < diclength ; j ++ )
            {
                int32_t count = 0;
                for ( int32_t k = 0 ; k < 5 ; k ++ )
                {
                    if ( advice[i] == voc[j].word[k] ) count++;       
                }
                if ( count < ycount[advice[i]-'A'] + gcount[advice[i]-'A'] ) voc[j].alive++;
                if ( count > ycount[advice[i]-'A'] + gcount[advice[i]-'A'] && bcount[advice[i]-'A'] ) voc[j].alive++;
            }
        }
        //choose word
        int32_t noanswer = 0;
        for ( int32_t i = 0 ; i < diclength ; i ++ )
        {
            if ( voc[i].alive == 0 && voc[i].fre > advicefre )
            {
                for ( int32_t j = 0 ; j < 5 ; j ++ )
                {
                    advice[j] = voc[i].word[j];
                }
                advicefre = voc[i].fre;
            }
            if ( voc[i].alive != 0 ) noanswer++;
        }
        if ( noanswer == diclength )
        {
            printf("No advice\n");
            return 0;
        }
    }
    for ( int32_t i = 0 ; i < diclength ; i ++ )
    {
        if ( voc[i].alive == 0 ) printf( "%s %d\n",voc[i].word, voc[i].fre );
    }
    fclose(file);
}