#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<math.h>

int main()
{
    char path[1025];
    printf("Please input a BMP file: ");
    fgets( path, 1025, stdin );
    if ( path[ strlen(path) - 1 ] == 10 ) path[ strlen(path) - 1 ] = 0;
    FILE *file = fopen ( path, "rb" );
    if ( file == NULL )
    {
        printf ("Wrong file, please check your file again.\n");
        return 0;
    }
    printf("Please input the output BMP file name: ");
    char output[1025];
    fgets( output, sizeof(output), stdin );
    if ( output[ strlen(output) - 1 ] == 10 ) output[ strlen(output) - 1 ] = 0;   
    printf("Angle (0-90): ");
    double angle = 0;
    scanf ("%lf", &angle );
    if ( angle >= 90 || angle < 0 )
    {
        printf("Wrong angle, please check your input.\n");
        return 0;
    }
    char bm[2];
    fread( &bm, 2, 1, file );
    if ( bm[0] != 'B' || bm[1] != 'M' )
    {
        printf("Wrong file, please input again.\n");
        return 0;
    }
    uint32_t size;
    fread( &size, 4, 1, file );
    uint32_t reserve;
    fread( &reserve, 4, 1, file );
    uint32_t offset;
    fread( &offset, 4, 1, file );
    uint32_t infoheader;
    fread( &infoheader, 4, 1, file );
    int32_t width;
    fread( &width, 4, 1, file );
    int32_t height;
    fread( &height, 4, 1, file );
    uint16_t plane;
    fread( &plane, 2, 1, file );
    uint16_t bpp;
    fread( &bpp, 2, 1, file );
    uint32_t compress;
    fread( &compress, 4, 1, file );
    uint32_t bmpsize;
    fread( &bmpsize, 4, 1, file );
    uint32_t xpi;
    fread( &xpi, 4, 1, file );
    uint32_t ypi;
    fread( &ypi, 4, 1, file );
    uint32_t used;
    fread( &used, 4, 1, file );
    uint32_t import;
    fread( &import, 4, 1, file );

    int32_t padding = 0;
    //COPY
    //printf("%s\n",output);
    FILE *new_file = fopen(output,"wb");
    fwrite( &bm[0], 1, 1, new_file );
    fwrite( &bm[1], 1, 1, new_file );
    double new = 0;
    new = width + height*tan(angle*M_PI/180);
    //printf("%lf\n",new);
    int32_t newwidth = 0;
    newwidth = round(new);
    //printf("%d\n",newwidth);
    uint32_t headersize = 0;
    headersize = newwidth*height*bpp/8+offset;
    fwrite( &headersize, 4, 1, new_file );
    fwrite( &reserve, 4, 1, new_file );
    fwrite( &offset, 4, 1, new_file );
    fwrite( &infoheader, 4, 1, new_file );
    fwrite( &newwidth, 4, 1, new_file );
    fwrite( &height, 4, 1, new_file );
    fwrite( &plane, 2, 1, new_file );
    fwrite( &bpp, 2, 1, new_file );
    fwrite( &compress, 4, 1, new_file );
    uint32_t newbpmsize = 0;
    newbpmsize = newwidth*height*bpp/8;
    fwrite( &newbpmsize, 4, 1, new_file );
    fwrite( &xpi, 4, 1, new_file );
    fwrite( &ypi, 4, 1, new_file );
    fwrite( &used, 4, 1, new_file );
    fwrite( &import, 4, 1, new_file );
    uint8_t white = 255;
    for ( int32_t i = 0 ; i < height ; i ++ )
    {
        if ( height > 0 )
        {
            for ( int32_t j = 0 ; j < round(i*tan(angle*M_PI/180)) ; j ++ )
            {
                fwrite(&white,1,1,new_file);//B
                fwrite(&white,1,1,new_file);//G
                fwrite(&white,1,1,new_file);//R
            }
        }
        else
        {
           for ( int32_t j = 0 ; j < newwidth-width-round(i*tan(angle*M_PI/180)) ; j ++ )
            {
                fwrite(&white,1,1,new_file);//B
                fwrite(&white,1,1,new_file);//G
                fwrite(&white,1,1,new_file);//R
            }
        }
        //copy
        for ( int32_t j = 0 ; j < width ; j ++ )
        {
            char temp[bpp/8];
            fread(temp,bpp/8,1,file);
            fwrite(temp,bpp/8,1,new_file);
            for( int32_t k = 0 ; k < ( 4-width*bpp/8%4 )%4 ; k ++ )
            {
                fread(temp,1,1,file);
            }
        }
        if ( height < 0 )
        {
            for ( int32_t j = 0 ; j < round(i*tan(angle*M_PI/180)) ; j ++ )
            {
                fwrite(&white,1,1,new_file);//B
                fwrite(&white,1,1,new_file);//G
                fwrite(&white,1,1,new_file);//R
            }
        }
        else
        {
           for ( int32_t j = 0 ; j < newwidth-width-round(i*tan(angle*M_PI/180)) ; j ++ )
            {
                fwrite(&white,1,1,new_file);//B
                fwrite(&white,1,1,new_file);//G
                fwrite(&white,1,1,new_file);//R
            }
        }
        for( int32_t k = 0 ; k < ( 4-newwidth*bpp/8%4 )%4 ; k ++ )
        {
            fwrite("00",1,1,new_file);
        }
    }
    //printf("%d",newwidth);
    /*printf("%c%c\n",bm[0],bm[1]);
    printf("size: %u\n",size);
    printf("reserve: %u\n",reserve);
    printf("offset: %u\n",offset);
    printf("infoheader: %u\n",infoheader);
    printf("width: %d\n",width);
    printf("height: %d\n",height);
    printf("plane: %u\n",plane);
    printf("bpp: %u\n",bpp);
    printf("compress: %u\n",compress);
    printf("bmpsize: %u\n",bmpsize);
    printf("xpi: %u\n",xpi);
    printf("ypi: %u\n",ypi);
    printf("used: %u\n",used);
    printf("import: %u\n",import);*/
    fclose(file);
    fclose(new_file);
}