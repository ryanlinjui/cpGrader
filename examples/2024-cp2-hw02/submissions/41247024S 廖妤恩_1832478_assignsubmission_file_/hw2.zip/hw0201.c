#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include<unistd.h>

int main()
{
    printf ("Please enter the file name: ");
    char path[1025];
    fgets ( path, 1025, stdin );
    if ( path[ strlen(path) - 1 ] == 10 ) path[ strlen(path) - 1 ] = 0;
    FILE *file = fopen ( path, "r" );
    if ( file == NULL )
    {
        printf ("Wrong file, please check your file again.\n");
        return 0;
    }
    printf ( "Time Shift ( -10 ~ 10 ): " );
    int32_t timeshift = 0;
    scanf ( "%d", &timeshift );
    if ( timeshift > 10 || timeshift < -10 )
    {
        printf ("Wrong input of timeshift, please check your input again.\n");
        return 0;
    }
    printf ( "Speed (0.25,0.5,0.75,1,1.25,1.5,1.75,2): ");
    double speed = 0;
    scanf ( "%lf", &speed );
    if ( speed != 0.25 && speed != 0.5 && speed != 0.75 && speed != 1 && speed != 1.25 && speed != 1.5 && speed != 1.75 && speed != 2 )
    {
        printf ("Wrong input of speed, please check your input again.\n");
        return 0;
    }
    char input[1025];
    char color[16];
    int32_t colorlength = 0;
    int32_t r = 0;
    int32_t g = 0;
    int32_t b = 0;
    int32_t start = 0;
    int32_t end = 0;
    //double first = (double)timeshift*-1;
    double first = 0;
    while ( fgets ( input, 1025, file ) != NULL )
    {
        char *a = input;
        while ( *a != '\0' )
        {
            //set color
            if ( *a == 'S' && *(a+1) == 't' && *(a+2) == 'y' && *(a+3) == 'l' && *(a+4) == 'e' && *(a+5) == ':' && *(a+6) == ' ' )
            {
                a+=7;
                int32_t findcolor = 0;
                while ( *a != '\0' )
                {
                    if ( *a == ',' ) findcolor++;
                    if ( findcolor == 3 )
                    {
                        a++;
                        int32_t i = 0;
                        while ( *a != ',' )
                        {
                            color[i] = *a;
                            a++;
                            i++;
                            colorlength++;
                        }
                        //color
                        if ( color[0] == '&' && color[1] == 'H' )
                        {
                            //set number
                            for ( int32_t i = 2 ; i < colorlength ; i ++ )
                            {
                                if ( color[i] >= 'a' && color[i] <= 'f' )
                                {
                                    color[i] -= 87;
                                }
                                else if ( color[i] >= 'A' && color[i] <= 'F' )
                                {
                                    color[i] -= 55;
                                }
                                else if ( color[i] >= '0' && color[i] <= '9' )
                                {
                                    color[i] -= 48;
                                }
                            }
                            //count
                            r = color[colorlength-2]*16 + color[colorlength-1];
                            g = color[colorlength-4]*16 + color[colorlength-3];
                            b = color[colorlength-6]*16 + color[colorlength-5];
                            printf("\033[38;2;%d;%d;%dm",r,g,b);
                        }
                        else
                        {
                            int32_t bignum = 0;
                            for ( int32_t i = 0 ; i < colorlength ; i ++ )
                            {
                                bignum = bignum*10 + color[i] - '0';
                            }
                            r = bignum%256;
                            g = (bignum/256)%256;
                            b = (bignum/(256*256))%256;
                            printf("\033[38;2;%d;%d;%dm",r,g,b);
                        }
                        break;
                    }
                    a++;
                }
            }
            if ( *a == 'D' && *(a+1) == 'i' && *(a+2) == 'a' && *(a+3) == 'l' && *(a+4) == 'o' && *(a+5) == 'g' && *(a+6) == 'u' && *(a+7) == 'e' && *(a+8) == ':' && *(a+9) == ' ' )
            {
                a+=10;
                int32_t findstartandend = 0;
                double second = 0;
                double third = 0;
                while ( *a != '\0' )
                {
                    if ( *a == ',' ) findstartandend++;
                    //calculate start time
                    if ( findstartandend == 1 )
                    {
                        a++;
                        printf("\e[1;1H\e[2J");
                        double starttime = 0;
                        int32_t hour = 0;
                        int32_t minute = 0;
                        while ( *a != ':' )
                        {
                            hour = hour*10 + *a - '0';
                            a++;
                        }
                        a++;
                        while ( *a != ':' )
                        {
                            minute = minute*10 + *a - '0';
                            a++;
                        }
                        a++;
                        while ( *a != '.' )
                        {
                            starttime = starttime*10 + *a - '0';
                            a++;
                        }
                        a++;
                        starttime += (*a-'0')*0.1;
                        a++;
                        starttime += (*a-'0')*0.01;
                        a++;
                        starttime += minute*60 + hour*3600;
                        //printf("starttime: %lf ",starttime);
                        //end
                        double endtime = 0;
                        hour = 0;
                        minute = 0;
                        a++;
                        while ( *a != ':' )
                        {
                            hour = hour*10 + *a - '0';
                            a++;
                        }
                        a++;
                        while ( *a != ':' )
                        {
                            minute = minute*10 + *a - '0';
                            a++;
                        }
                        a++;
                        while ( *a != '.' )
                        {
                            endtime = endtime*10 + *a - '0';
                            a++;
                        }
                        a++;
                        endtime += (*a-'0')*0.1;
                        a++;
                        endtime += (*a-'0')*0.01;
                        a++;
                        endtime += minute*60 + hour*3600;
                        //printf("endtime: %lf \n",endtime);
                        starttime += timeshift;
                        endtime += timeshift;
                        //subtitle
                        char sub[100];
                        int32_t tochar = 0;
                        while ( tochar != 7 )
                        {
                            if ( *a == ',' ) tochar++;
                            a++;
                        }
                        //printf("%c \n",*a);
                        int32_t i = 0;
                        while ( *a != '\0' )
                        {
                            sub[i] = *a;
                            //printf("%c",*a);
                            a++;
                            i++;
                        }
                        //printf(" %d\n",i);
                        /*for ( int32_t j = 0 ; j < i ; j ++ )
                        {
                            printf("%c",sub[j]);
                        }*/
                        //printf("\n");
                        //printf("%s\n",sub);
                        //print
                        second = starttime;
                        third = endtime;
                        usleep((second-first)/speed*1000000);
                        for ( int32_t j = 0 ; j < i ; j ++ )
                        {
                            printf("%c",sub[j]);
                        }
                        usleep((third-second)/speed*1000000);
                        //clear
                        printf("\e[1;1H\e[2J");
                        first = third;
                        break;
                    }
                    a++;
                }
            }
            a++;
        }
    }
    fclose(file);
}