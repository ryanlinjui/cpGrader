#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

int intLength(int value) {
    return snprintf(NULL, 0, "%d", value);
}

void printf80Spaces(char* text){
    for(int i = 0; i < 80-strlen(text); i++){
        printf(" ");
    }
}

void printf15Spaces(char* text){
    for(int i = 0; i < 15-strlen(text); i++){
        printf(" ");
    }
}

void printf80SpacesCountNumber(int count){
    for(int i = 0; i < 80-count; i++){
        printf(" ");
    }
}

void printf15SpacesCountNumber(int count){
    for(int i = 0; i < 15-count; i++){
        printf(" ");
    }
}

// union gguf_metadata_value_t {
//     uint8_t uint8;
//     int8_t int8;
//     uint16_t uint16;
//     int16_t int16;
//     uint32_t uint32;
//     int32_t int32;
//     float float32;
//     uint64_t uint64;
//     int64_t int64;
//     double float64;
//     bool bool_;
//     gguf_string_t string;
//     struct {
//         // Any value type is valid , including arrays.
//         gguf_metadata_value_type type;
//         // Number of elements , not bytes
//         uint64_t len;
//         // The array of values.
//         gguf_metadata_value_t array[len];
//     } array;
// };

void readGGUF_uint8(FILE *pFile){
    // uint8_t uint8;
    uint8_t value;
    fread(&value, sizeof(uint8_t), 1, pFile);
    printf("%d", value);
}

void readGGUF_int8(FILE *pFile){
    // int8_t int8;
    int8_t value;
    fread(&value, sizeof(int8_t), 1, pFile);
    printf("%d", value);
}

void readGGUF_uint16(FILE *pFile){
    // uint16_t uint16;
    uint16_t value;
    fread(&value, sizeof(uint16_t), 1, pFile);
    printf("%d", value);
}

void readGGUF_int16(FILE *pFile){
    // int16_t int16;
    int16_t value;
    fread(&value, sizeof(int16_t), 1, pFile);
    printf("%d", value);
}

void readGGUF_uint32(FILE *pFile){
    // uint32_t uint32;
    uint32_t value;
    fread(&value, sizeof(uint32_t), 1, pFile);
    printf("%d", value);
}

void readGGUF_int32(FILE *pFile){
    // int32_t int32;
    int32_t value;
    fread(&value, sizeof(int32_t), 1, pFile);
    printf("%d", value);
}

void readGGUF_float32(FILE *pFile){
    // float float32;
    float value;
    fread(&value, sizeof(float), 1, pFile);
    printf("%f", value);
}

void readGGUF_bool(FILE *pFile){
    // bool
    bool value;
    fread(&value, sizeof(bool), 1, pFile);
    if(value==1){
        printf("true");
    }else{
        printf("false");
    }
}

void readGGUF_uint64(FILE *pFile){
    // uint64_t uint64;
    uint64_t value;
    fread(&value, sizeof(uint64_t), 1, pFile);
    printf("%ld", value);
}

void readGGUF_int64(FILE *pFile){
    // int64_t int64;
    int64_t value;
    fread(&value, sizeof(int64_t), 1, pFile);
    printf("%ld", value);
}

void readGGUF_float64(FILE *pFile){
    // double float64;
    double value;
    fread(&value, sizeof(double), 1, pFile);
    printf("%f", value);
}

//回傳該字串長度
long long readGGUF_string(FILE *pFile){
    // string
    uint64_t stringLength;
    fread(&stringLength, sizeof(uint64_t), 1, pFile);
    char* string = (char*)calloc(stringLength + 1, sizeof(char)); // 預留空間給 null 字元
    fread(string, sizeof(char)*stringLength, 1, pFile);
    string[stringLength] = '\0'; // 添加 null 字元
    //printf("DEBUG: stringLength=%ld ", stringLength);
    printf("%s", string);
    free(string);
    return stringLength;
}

void readGGUF_array(FILE *pFile){
    //Array
    uint32_t gguf_metadata_value_type_2;
    fread(&gguf_metadata_value_type_2, sizeof(uint32_t), 1, pFile);
    //printf("DEBUG: array type2:%d\n", gguf_metadata_value_type_2);
    uint64_t len;
    fread(&len, sizeof(uint64_t), 1, pFile);
    //printf("DEBUG: array len:%ld ", len);
    printf("[");
    for(uint64_t i=0;i<len;i++){
        if(gguf_metadata_value_type_2 == 0){
            // uint8_t uint8;
            readGGUF_uint8(pFile);
        }else if(gguf_metadata_value_type_2 == 1){
            // int8_t int8;
            readGGUF_int8(pFile);
        }else if(gguf_metadata_value_type_2 == 2){
            // uint16_t uint16;
            readGGUF_uint16(pFile);
        }else if(gguf_metadata_value_type_2 == 3){
            // int16_t int16;
            readGGUF_int16(pFile);
        }else if(gguf_metadata_value_type_2 == 4){
            // uint32_t uint32;
            readGGUF_uint32(pFile);
        }else if(gguf_metadata_value_type_2 == 5){
            // int32_t int32;
            readGGUF_int32(pFile);
        }else if(gguf_metadata_value_type_2 == 6){
            // float float32;
            readGGUF_float32(pFile);
        }else if(gguf_metadata_value_type_2 == 7){
            // bool
            readGGUF_bool(pFile);
        }else if(gguf_metadata_value_type_2 == 8){
            // string
            readGGUF_string(pFile);
        }else if(gguf_metadata_value_type_2 == 9){
            // array
            readGGUF_array(pFile);            
        }else if(gguf_metadata_value_type_2 == 10){
            // uint64_t uint64;
            readGGUF_uint64(pFile);
        }else if(gguf_metadata_value_type_2 == 11){
            // int64_t int64;
            readGGUF_int64(pFile);
        }else if(gguf_metadata_value_type_2 == 12){
            // double float64;
            readGGUF_float64(pFile);
        }
        if(i!=len-1){
            printf(",");
        }
    }
    printf("]");


}

int main() {
    uint32_t magic;
    uint32_t version;
    uint64_t tensor_Count;
    uint64_t kv_Count;


    FILE *pFile;

    
    //Open File
    printf("GGUF: ");
    if( ( pFile = fopen("model.gguf", "rb") ) == NULL )
    {
        printf( "false\n" );
        return 0;
    }

    
    fread(&magic, sizeof(uint32_t), 1, pFile);
    
    if(magic != 0x46554747)
    {
        printf("false\n");
        return 0;
    }else{
        printf("true\n");
    }

    printf("\n");

    printf("Metadata");
    printf80Spaces("Metadata");
    printf("Value\n");

    fread(&version, sizeof(uint32_t), 1, pFile);
    printf("Version");
    printf80Spaces("Version");
    printf("%d\n", version);

    fread(&tensor_Count, sizeof(uint64_t), 1, pFile);
    printf("Tensor_Count");
    printf80Spaces("Tensor_Count");
    printf("%ld\n", tensor_Count);

    fread(&kv_Count, sizeof(uint64_t), 1, pFile);
    printf("KV_Count");
    printf80Spaces("KV_Count");
    printf("%ld\n", kv_Count);


    for(int i=0;i<kv_Count;i++){
        //Read key
        uint64_t stringLength;
        fread(&stringLength, sizeof(uint64_t), 1, pFile);
        char* string = (char*)calloc(stringLength + 1, sizeof(char));
        fread(string, sizeof(char), stringLength, pFile);
        printf("%s",string);
        printf80Spaces(string);
        free(string);

        //Read value type
        uint32_t gguf_metadata_value_type;
        fread(&gguf_metadata_value_type, sizeof(uint32_t), 1, pFile);
        //printf("DEBUG: type=%d  ", gguf_metadata_value_type);

        if(gguf_metadata_value_type == 0){
            // uint8_t uint8;
            readGGUF_uint8(pFile);
            printf("\n");
        }else if(gguf_metadata_value_type == 1){
            // int8_t int8;
            readGGUF_int8(pFile);
            printf("\n");
        }else if(gguf_metadata_value_type == 2){
            // uint16_t uint16;
            readGGUF_uint16(pFile);
            printf("\n");
        }else if(gguf_metadata_value_type == 3){
            // int16_t int16;
            readGGUF_int16(pFile);
            printf("\n");
        }else if(gguf_metadata_value_type == 4){
            // uint32_t uint32;
            readGGUF_uint32(pFile);
            printf("\n");
        }else if(gguf_metadata_value_type == 5){
            // int32_t int32;
            readGGUF_int32(pFile);
            printf("\n");
        }else if(gguf_metadata_value_type == 6){
            // float float32;
            readGGUF_float32(pFile);
            printf("\n");
        }else if(gguf_metadata_value_type == 7){
            // bool
            readGGUF_bool(pFile);
            printf("\n");
        }else if(gguf_metadata_value_type == 8){
            // string
            readGGUF_string(pFile);
            printf("\n");
        }else if(gguf_metadata_value_type == 9){
            // array
            readGGUF_array(pFile);  
            printf("\n");          
        }else if(gguf_metadata_value_type == 10){
            // uint64_t uint64;
            readGGUF_uint64(pFile);
            printf("\n");
        }else if(gguf_metadata_value_type == 11){
            // int64_t int64;
            readGGUF_int64(pFile);
            printf("\n");
        }else if(gguf_metadata_value_type == 12){
            // double float64;
            readGGUF_float64(pFile);
            printf("\n");
        }

    }
    
    printf("\n");

    //Read Tensor
    printf("Tensor");
    printf80Spaces("Tensor");
    printf("Shape");
    printf15Spaces("Shape");
    printf("Precision\n");

    //printf("DEBUG: tensor_Count=%ld\n", tensor_Count);
    for(int64_t j=0;j<tensor_Count;j++){
        long long int curLen=0;
        long long tensorStringLength=readGGUF_string(pFile);
        printf80SpacesCountNumber(tensorStringLength);
        uint32_t n_dims;
        fread(&n_dims, sizeof(uint32_t), 1, pFile);
        //printf(DEBUG: %d", n_dims);
        printf("[");
        curLen++;
        for(int i=0;i<n_dims;i++){
            uint64_t dim;
            fread(&dim, sizeof(uint64_t), 1, pFile);
            printf("%ld", dim);
            curLen+=intLength(dim);
            if(i!=n_dims-1){
                printf(",");
                curLen+=1;
            }
        }
        printf("]");
        curLen+=1;
        //printf("DEBUG:curlen:%ld", curLen);
        printf15SpacesCountNumber(curLen);

        uint32_t gguml_type;
        fread(&gguml_type, sizeof(uint32_t), 1, pFile);
        if(gguml_type == 0){
            printf("F32\n");
        }else if(gguml_type == 1){
            printf("F16\n");
        }else if(gguml_type == 2){
            printf("Q4_0\n");
        }else if(gguml_type == 3){
            printf("Q4_1\n");
        }else if(gguml_type == 6){
            printf("Q5_0\n");
        }else if(gguml_type == 7){
            printf("Q5_1\n");
        }else if(gguml_type == 8){
            printf("Q8_0\n");
        }else if(gguml_type == 9){
            printf("Q8_1\n");
        }else if(gguml_type == 10){
            printf("Q2_K\n");
        }else if(gguml_type == 11){
            printf("Q3_K\n");
        }else if(gguml_type == 12){
            printf("Q4_K\n");
        }else if(gguml_type == 13){
            printf("Q5_K\n");
        }else if(gguml_type == 14){
            printf("Q6_K\n");
        }else if(gguml_type == 15){
            printf("Q8_K\n");
        }else if(gguml_type == 16){
            printf("I8\n");
        }else if(gguml_type == 17){
            printf("I16\n");
        }else if(gguml_type == 18){
            printf("I32\n");
        }else if(gguml_type == 19){
            printf("COUNT\n");
        }

        uint64_t offset;
        fread(&offset, sizeof(uint64_t), 1, pFile);
        //printf("DEBUG: offset=%ld\n", offset);

        
    }
    
    








    return 0;
}