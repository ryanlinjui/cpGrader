#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#define CUSTON_ERROR 999





int main(){

    errno = 999;
    perror("ERROR:");

    return 0;
}