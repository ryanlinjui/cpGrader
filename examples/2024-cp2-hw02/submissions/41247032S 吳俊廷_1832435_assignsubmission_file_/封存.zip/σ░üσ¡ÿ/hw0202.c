#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char date[20];
    char homeTeam[50];
    char awayTeam[50];
    int FTHG, FTAG;
    char FTR[5];
    int HTHG, HTAG;
    char HTR[5];
    char referee[50];
    int HS, AS, HST, AST, HF, AF, HC, AC, HY, AY, HR, AR;
} Match;

typedef struct {
    char name[50];
    int W, D, L, GF, GA, GD, Pts;
} TeamStats;

TeamStats teams[100];
int teamCount = 0;

TeamStats *getTeamStats(char *name) {
    for (int i = 0; i < teamCount; i++) {
        if (strcmp(teams[i].name, name) == 0) {
            return &teams[i];
        }
    }
    strcpy(teams[teamCount].name, name);
    return &teams[teamCount++];
}

void updateTeamStats(Match match) {
    TeamStats *homeTeam = getTeamStats(match.homeTeam);
    TeamStats *awayTeam = getTeamStats(match.awayTeam);

    homeTeam->GF += match.FTHG;
    homeTeam->GA += match.FTAG;
    homeTeam->GD = homeTeam->GF - homeTeam->GA;

    awayTeam->GF += match.FTAG;
    awayTeam->GA += match.FTHG;
    awayTeam->GD = awayTeam->GF - awayTeam->GA;

    if (strcmp(match.FTR, "H") == 0) {
        homeTeam->W++;
        homeTeam->Pts += 3;
        awayTeam->L++;
    } else if (strcmp(match.FTR, "A") == 0) {
        awayTeam->W++;
        awayTeam->Pts += 3;
        homeTeam->L++;
    } else {
        homeTeam->D++;
        awayTeam->D++;
        homeTeam->Pts++;
        awayTeam->Pts++;
    }
}

int compareTeams(const void *a, const void *b) {
    TeamStats *teamA = (TeamStats *)a;
    TeamStats *teamB = (TeamStats *)b;

    if (teamA->Pts != teamB->Pts) {
        return teamB->Pts - teamA->Pts;
    }
    if (teamA->GD != teamB->GD) {
        return teamB->GD - teamA->GD;
    }
    return teamB->GF - teamA->GF;
}

int main(){

    FILE *pFile;
    char fileName[1000];
    //int maxTeamSize=0;
    int totalMatchesCount=0;
    printf("Please enter the data file name: ");

    if( fgets( fileName, sizeof( fileName ), stdin ) == NULL ){
        printf( "Error!\n" );
        return 0;
    }

    // Since fgets will include '\n', we need to remove this character.
    if( fileName[ strlen( fileName ) - 1 ] == '\n' ){
        fileName[ strlen( fileName ) - 1 ] = 0;
    }else{
        // If the last byte is not '\n', we need to clean the input buffer.
        int32_t c = 0;
        while( ( c = fgetc( stdin ) ) != '\n' && c != EOF ){}
    }

    //printf("DEBUG: FileName: %s\n",fileName);
    
    //Open File
    if( ( pFile = fopen( fileName, "r" ) ) == NULL )
    {
        printf( "File could not be opened!\n" );
        return 0;
    }

    Match matches[380]; // Assuming a maximum of 380 matches in a season
    int matchCount = 0;

    char line[1024];
    int lineNumber = 0;
    while (fgets(line, sizeof(line), pFile)) {
        lineNumber++;
        //printf("Line %d: %s", lineNumber, line);
        if(lineNumber!=1){
            Match match;
            sscanf(line, "%[^,],%[^,],%[^,],%d,%d,%[^,],%d,%d,%[^,],%[^,],%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d",
                match.date, match.homeTeam, match.awayTeam, &match.FTHG, &match.FTAG, match.FTR,
                &match.HTHG, &match.HTAG, match.HTR, match.referee, &match.HS, &match.AS, &match.HST, &match.AST,
                &match.HF, &match.AF, &match.HC, &match.AC, &match.HY, &match.AY, &match.HR, &match.AR);
            matches[matchCount++] = match;
        }
        
    }

    fclose(pFile);
    //printf("%d\n",lineNumber);
    totalMatchesCount=lineNumber-1;


    for (int i = 0; i < totalMatchesCount; i++) {
        updateTeamStats(matches[i]);
    }
    //printf("teamCount: %d\n",teamCount);

    qsort(teams, teamCount, sizeof(TeamStats), compareTeams);

    printf("%-3s  %-20s %-3s %-3s %-3s %-3s %-3s %-4s %-3s\n", "   ", "Team", "W", "D", "L", "GF", "GA", "GD", "Pts");
    for (int i = 0; i < teamCount; i++) {
        char gd[5];
        if (teams[i].GD >= 0) {
            sprintf(gd, "+%d", teams[i].GD);
        } else {
            sprintf(gd, "%d", teams[i].GD);
        }
        printf("%02d)  %-20s %-3d %-3d %-3d %-3d %-3d %-4s %-3d\n", i+1, teams[i].name, teams[i].W, teams[i].D, teams[i].L, teams[i].GF, teams[i].GA, gd, teams[i].Pts);
    }
    return 0;
}