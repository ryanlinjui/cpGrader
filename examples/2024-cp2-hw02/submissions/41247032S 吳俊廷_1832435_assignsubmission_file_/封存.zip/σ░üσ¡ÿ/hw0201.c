#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>

typedef struct {
    int startHour;
    int startMin;
    int startSec;
    unsigned long long startMillisec;
    int endHour;
    int endMin;
    int endSec;
    unsigned long long endMillisec;
    char *text;
} Subtitle;

int totalSubtitleCount;
unsigned int color;
Subtitle *parseASS(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Cannot open file %s\n", filename);
        return NULL;
    }

    Subtitle *subtitles = malloc(1000 * sizeof(Subtitle));
    int subtitleCount = 0;

    char line[256];
    while (fgets(line, sizeof(line), file)) {
        if (strstr(line, "Style:") == line) {
            
            char* token = strtok(line, ",");
            for (int i = 0; i < 3; i++) {
                token = strtok(NULL, ",");
            }
            if (token[0] == '&') {
                sscanf(token, "&H%x", &color);
            } else {
                sscanf(token, "%u", &color);
            }
            // Convert BGR to RGB
            unsigned int r = color & 0xFF;
            unsigned int g = (color >> 8) & 0xFF;
            unsigned int b = (color >> 16) & 0xFF;
            color = (r << 16) | (g << 8) | b;
            //printf("PrimaryColor: #%06x\n", color);
        } else if (strstr(line, "Dialogue:") == line) {
            Subtitle *subtitle = &subtitles[subtitleCount++];
            sscanf(line, "Dialogue: %*d,%d:%d:%d.%lld,%d:%d:%d.%lld,%*[^,],%m[^\n]",
                   &subtitle->startHour, &subtitle->startMin, &subtitle->startSec, &subtitle->startMillisec,
                   &subtitle->endHour, &subtitle->endMin, &subtitle->endSec, &subtitle->endMillisec,
                   &subtitle->text);

            // Convert the start and end times to milliseconds
            subtitle->startMillisec += subtitle->startSec * 1000 + subtitle->startMin * 60000 + subtitle->startHour * 3600000;
            subtitle->endMillisec += subtitle->endSec * 1000 + subtitle->endMin * 60000 + subtitle->endHour * 3600000;
        }
    }
    totalSubtitleCount = subtitleCount;
    fclose(file);
    return subtitles;
}

void printSubtitles(Subtitle *subtitles, int subtitleCount, double speed, int timeShift) {
    int nowMilisecond=0;
    for (int i = 0; i < subtitleCount; i++) {
        Subtitle *subtitle = &subtitles[i];

        // Adjust the start and end times in milliseconds
        //int startMs = (subtitle->startHour * 3600000 + subtitle->startMin * 60000 + subtitle->startSec * 1000 + subtitle->startMillisec) + timeShift * 1000;
        //int endMs = (subtitle->endHour * 3600000 + subtitle->endMin * 60000 + subtitle->endSec * 1000 + subtitle->endMillisec) + timeShift * 1000;

        // Wait for the start time
        //printf("DEBUG: nowMilisecond: %d\n", nowMilisecond);
        //printf("DEBUG: startMillisec: %d\n", subtitle->startMillisec);
        //printf("DEBUG: endMillisec: %d\n", subtitle->endMillisec);
        if (subtitle[i].startMillisec-nowMilisecond > 0) {
            //printf("DEBUG: usleep(%d)\n", (subtitle->startMillisec-nowMilisecond) * 1000 / speed);
            usleep((subtitle->startMillisec-nowMilisecond) * 1000 / speed);
        }
        nowMilisecond = subtitle[i].startMillisec;

        // Print the subtitle
        //請印出text中由前數來第5個逗號後面的字元
        // Print the subtitle
        char *text = subtitle->text;
        for (int j = 0; j < 5; j++) {
            text = strchr(text, ',');
            if (text != NULL) {
                text++; // Skip the comma
            } else {
                break;
            }
        }

        if (text != NULL) {
            // Convert the color to RGB
            unsigned int r = (color >> 16) & 0xFF;
            unsigned int g = (color >> 8) & 0xFF;
            unsigned int b = color & 0xFF;

            // Print the text with color
            printf("\033[38;2;%d;%d;%dm%s\033[0m\n", r, g, b, text);
        } else {
            printf("SUBTITLE ERROR\n");
        }

        // Wait for the end time
        if (subtitle[i].endMillisec > subtitle[i].startMillisec) {
            //printf("DEBUG: usleep(%d)\n", (subtitle->endMillisec - subtitle->startMillisec) * 1000 / speed);
            usleep((subtitle->endMillisec - subtitle->startMillisec) * 1000 / speed);
            
        }
        //printf("clear\n");
        system("clear");
        nowMilisecond = subtitle->endMillisec;
    }
}

void applyTimeShift(Subtitle *subtitles, int subtitleCount, int timeShift) {
    for (int i = 0; i < subtitleCount; i++) {
        Subtitle *subtitle = &subtitles[i];

        // Apply the time shift to the start and end times
        subtitle->startMillisec += timeShift * 1000;
        subtitle->endMillisec += timeShift * 1000;
    }
}

void parseAndPrintASS(const char *filename, double speed, int timeShift) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Cannot open file %s\n", filename);
        return;
    }

    char line[256];
    int nowMilisecond = 0;
    while (fgets(line, sizeof(line), file)) {
        if (strstr(line, "Style:") == line) {
           
            char* token = strtok(line, ",");
            for (int i = 0; i < 3; i++) {
                token = strtok(NULL, ",");
            }
            if (token[0] == '&') {
                sscanf(token, "&H%x", &color);
            } else {
                sscanf(token, "%u", &color);
            }
            // Convert BGR to RGB
            unsigned int r = color & 0xFF;
            unsigned int g = (color >> 8) & 0xFF;
            unsigned int b = (color >> 16) & 0xFF;
            color = (r << 16) | (g << 8) | b;
            //printf("PrimaryColor: #%06x\n", color);
        } else if (strstr(line, "Dialogue:") == line) {
            Subtitle subtitle;
            sscanf(line, "Dialogue: %*d,%d:%d:%d.%lld,%d:%d:%d.%lld,%*[^,],%m[^\n]",
                   &subtitle.startHour, &subtitle.startMin, &subtitle.startSec, &subtitle.startMillisec,
                   &subtitle.endHour, &subtitle.endMin, &subtitle.endSec, &subtitle.endMillisec,
                   &subtitle.text);

            // Convert the start and end times to milliseconds
            subtitle.startMillisec += subtitle.startSec * 1000 + subtitle.startMin * 60000 + subtitle.startHour * 3600000;
            subtitle.endMillisec += subtitle.endSec * 1000 + subtitle.endMin * 60000 + subtitle.endHour * 3600000;

            // Apply the time shift to the start and end times
            subtitle.startMillisec += timeShift * 1000;
            subtitle.endMillisec += timeShift * 1000;

            // Wait for the start time
            if (subtitle.startMillisec-nowMilisecond > 0) {
                usleep((subtitle.startMillisec-nowMilisecond) * 1000 / speed);
            }
            nowMilisecond = subtitle.startMillisec;

            // Print the subtitle
            char *text = subtitle.text;
            for (int j = 0; j < 5; j++) {
                text = strchr(text, ',');
                if (text != NULL) {
                    text++; // Skip the comma
                } else {
                    break;
                }
            }

            if (text != NULL) {
                // Convert the color to RGB
                unsigned int r = (color >> 16) & 0xFF;
                unsigned int g = (color >> 8) & 0xFF;
                unsigned int b = color & 0xFF;

                // Print the text with color
                printf("\033[38;2;%d;%d;%dm%s\033[0m\n", r, g, b, text);
            } else {
                printf("SUBTITLE ERROR\n");
            }

            // Wait for the end time
            if (subtitle.endMillisec > subtitle.startMillisec) {
                usleep((subtitle.endMillisec - subtitle.startMillisec) * 1000 / speed);
            }
            system("clear");
            nowMilisecond = subtitle.endMillisec;

            // Free the text
            free(subtitle.text);
        }
    }

    fclose(file);
}

int main() {
    printf("Please enter the file name: ");
    char fileName[256];
    double speed;//the speed that all subtitles will be played at
    int timeShift;//the seconds that all subtitles will be shifted by
    

    if( fgets( fileName, sizeof( fileName ), stdin ) == NULL ){
        printf( "Error!\n" );
        return 0;
    }

    // Since fgets will include '\n', we need to remove this character.
    if( fileName[ strlen( fileName ) - 1 ] == '\n' ){
        fileName[ strlen( fileName ) - 1 ] = 0;
    }else{
        // If the last byte is not '\n', we need to clean the input buffer.
        int32_t c = 0;
        while( ( c = fgetc( stdin ) ) != '\n' && c != EOF ){}
    }
    //Subtitle *subtitles = parseASS(fileName);

    printf("Time Shift ( -10 ~ 10 ): ");
    
    scanf("%d", &timeShift);
    //printf("Time Shift: %d\n", timeShift);
    if( timeShift < -10 || timeShift > 10 ){
        printf( "Time Shift Value Error!\n" );
        return 0;
    }

    printf("Speed (0.25,0.5,0.75,1,1.25,1.5,1.75,2): ");
    scanf("%lf", &speed);
    if( speed != 0.25 && speed != 0.5 && speed != 0.75 && speed != 1 && speed != 1.25 && speed != 1.5 && speed != 1.75 && speed != 2 ){
        printf( "Error!\n" );
        return 0;
    }
    
    //DEBUG: Check subtitle
    // printf("Subtitles:\n");
    // printf("Start Time\tEnd Time\tText\n");
    // for (int i = 0; i < 1000; i++) {
    //     Subtitle *subtitle = &subtitles[i];
    //     if (subtitle->text == NULL) {
    //         break;
    //     }
    //     printf("%02d:%02d:%02d.%03d\t%02d:%02d:%02d.%03d\t%s\n",
    //            subtitle->startHour, subtitle->startMin, subtitle->startSec, subtitle->startMillisec,
    //            subtitle->endHour, subtitle->endMin, subtitle->endSec, subtitle->endMillisec,
    //            subtitle->text);
    // }
    // printf("Total Subtitle Count: %d\n", totalSubtitleCount);
    // printf("PrimaryColor: #%06x\n", color);



    //applyTimeShift(subtitles, totalSubtitleCount, timeShift);
    system("clear");
    parseAndPrintASS(fileName, speed, timeShift);
    //printSubtitles(subtitles, totalSubtitleCount, speed, timeShift);

    return 0;
}