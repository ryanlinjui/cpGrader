#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

struct _sBmpHeader
{
    char		bm[2];
    uint32_t	size;
    uint32_t	reserve;
    uint32_t	offset;
    uint32_t	header_size;
    int32_t	    width;
    int32_t	    height;
    uint16_t	planes;
    uint16_t	bpp;
    uint32_t	compression;
    uint32_t	bitmap_size;
    uint32_t	hres;
    uint32_t	vres;
    uint32_t	used;
    uint32_t	important;
}__attribute__ ((__packed__));

typedef struct _sBmpHeader sBmpHeader;

void print_bmp_header( sBmpHeader *pHeader )
{
    printf( "ID: %c%c\n", pHeader -> bm[0], pHeader -> bm[1] );
    printf( "Size: %u\n", pHeader -> size );
    printf( "Reserve: %u\n", pHeader -> reserve );
    printf( "Offset: %u\n", pHeader -> offset );
    printf( "Header Size: %u\n", pHeader -> header_size );
    printf( "Width: %u\n", pHeader -> width );
    printf( "Height: %u\n", pHeader -> height );
    printf( "Planes: %u\n", pHeader -> planes );
    printf( "Bits Per Pixel: %u\n", pHeader -> bpp );
    printf( "Compression: %u\n", pHeader -> compression );
    printf( "Bitmap Data Size: %u\n", pHeader -> bitmap_size );
    printf( "H-Resolution: %u\n", pHeader -> hres );
    printf( "V-Resolution: %u\n", pHeader -> vres );
    printf( "Used Colors: %u\n", pHeader -> used );
    printf( "Important Colors: %u\n", pHeader -> important );
    
    return;
}


int main()
{
    FILE	*pFile = NULL;
    FILE	*pFile2 = NULL;
    char fileName[256] = {0};
    char fileName2[256] = {0};
    double angle=0;
    int64_t new_height;
    int64_t new_width;
    
    //Input file
    printf("Please input a BMP file: ");
    if( fgets( fileName, sizeof( fileName ), stdin ) == NULL ){
        printf( "Error!\n" );
        return 0;
    }

    // Since fgets will include '\n', we need to remove this character.
    if( fileName[ strlen( fileName ) - 1 ] == '\n' ){
        fileName[ strlen( fileName ) - 1 ] = 0;
    }else{
        // If the last byte is not '\n', we need to clean the input buffer.
        int32_t c = 0;
        while( ( c = fgetc( stdin ) ) != '\n' && c != EOF ){}
    }

    if( ( pFile = fopen( fileName, "rb" ) ) == NULL )
    {
        printf( "File could not be opened!\n" );
        return 0;
    }

    printf("Please input the output BMP file name: ");
    if( fgets( fileName2, sizeof( fileName2 ), stdin ) == NULL ){
        printf( "Error!\n" );
        return 0;
    }
    // Since fgets will include '\n', we need to remove this character.
    if( fileName2[ strlen( fileName2 ) - 1 ] == '\n' ){
        fileName2[ strlen( fileName2 ) - 1 ] = 0;
    }else{
        // If the last byte is not '\n', we need to clean the input buffer.
        int32_t c = 0;
        while( ( c = fgetc( stdin ) ) != '\n' && c != EOF ){}
    }
    if(fileName==fileName2){
        printf("Error: Input and output file names are the same!\n");
        return 0;
    }
    if( ( pFile2 = fopen( fileName2, "wb" ) ) == NULL )
    {
        printf( "File could not be opened!\n" );
        return 0;
    }

    //Input angle
    printf("angle (0-90): ");
    scanf("%lf",&angle);
    if(angle<0 || angle>=90){
        printf("Error: Angle must be between 0 and 90!\n");
        return 0;
    }

    

    sBmpHeader	header;
    fread( &header, sizeof( header ), 1, pFile );

    //print_bmp_header( &header );

    int32_t original_width = header.width;
    int32_t original_height = header.height;

    //Count new height and width
    new_height = header.height;
    double rad = angle * M_PI / 180;
    new_width = original_width + original_height * tan(rad);
    

    //printf("DEBUG: new_height: %ld\n",new_height);
    //printf("DEBUG: new_width: %ld\n",new_width);

    header.width = new_width;
    header.height = new_height;

    fwrite( &header, sizeof( header ), 1, pFile2 );

    int64_t current_height = 0;
    int64_t current_width = 0;
    int64_t new_width_with_padding;
    new_width_with_padding = new_width+(4-(new_width%4))%4;
    //printf("DEBUG: new_width: %ld\n",new_width);
    //printf("DEBUG: new_width_with_padding: %ld\n",new_width_with_padding);
    while( !feof( pFile ) )
    {

        uint8_t	original[original_width*3];
        uint8_t modified[new_width_with_padding*3];
        
        size_t count = fread( original, 1, original_width*3, pFile );

        //printf("DEBUG: count: %ld\n",count);

        int64_t fillWhitePixel=current_height * tan(rad);
        //printf("DEBUG: fillWhitePixel: %ld\n",fillWhitePixel);

        for(int j=0;j<fillWhitePixel*3;j++){
            modified[j]=255;
        }

        current_width = fillWhitePixel+1;

        for(int i=0;i<original_width*3;i++){
            modified[current_width*3+i]=original[i];
        }

        for(int i=current_width*3+original_width*3;i<new_width_with_padding*3;i++){
            modified[i]=255;
        }

        //printf("DEBUG count: %ld\n",count);
        fwrite( modified, new_width*3+(new_width_with_padding-new_width), 1, pFile2 );
        current_height++;
        
    }
                
    fclose( pFile );
    fclose( pFile2 );
    
    return 0;
}