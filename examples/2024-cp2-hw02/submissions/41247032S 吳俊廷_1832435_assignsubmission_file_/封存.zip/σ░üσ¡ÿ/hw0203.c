#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

#define MAX_WORD_LENGTH 100

// Function to check if a word contains only letters
int isAlpha(char *word) {
    for (int i = 0; i < strlen(word); i++) {
        if (!isalpha(word[i])) {
            return 0;
        }
    }
    return 1;
}



void buildFrenquencyTable(int *freq) {
    // Letter frequency table from https://en.wikipedia.org/wiki/Letter_frequency
    // The frequencies are in the order of A-Z
    int freqTable[26] = {8200, 1500, 2800, 4300, 12700, 2200, 2000, 6100, 7000, 150, 770, 4000, 2400, 6700, 7500, 1900, 95, 6000, 6300, 9100, 2800, 980, 2400, 150, 2000, 74};
    for (int i = 0; i < 26; i++) {
        freq[i] = freqTable[i];
    }
}

struct singleWord {
    char word[6];
    int freq;
};

//playerWin is a global variable to check if the player has won the game
bool playerWin=false;

//char status meas the color of the char, 0 means not set, 1 means B, 2 means Y, 3 means G
int charStatus[26]={0};

int possibleWordCount=0;
char sureWord[]={255,255,255,255,255};

void printCharStatus(){
    for(int i=0;i<26;i++){
        printf("%c: %d\n",i+'A' ,charStatus[i]);
    }
    printf("\n");
}  

int main() {
    FILE *file = fopen("en_US.dic", "r");
    if (file == NULL) {
        printf("Cannot open dictionary file\n");
        return 1;
    }

    char word[MAX_WORD_LENGTH];
    char words[10000][6]; // Assuming there are less than 10000 such words
    int count = 0;

    while (fgets(word, sizeof(word), file)) {
        // Remove the newline character
        word[strcspn(word, "\n")] = 0;

        // If the word contains '/', only consider the part before '/'
        char *slash = strchr(word, '/');
        if (slash != NULL) {
            *slash = '\0';
        }

        // Only consider 5-letter words that contain only letters
        if (strlen(word) == 5 && isAlpha(word)) {
            strcpy(words[count], word);
            count++;
        }
    }

    fclose(file);
    possibleWordCount=count;
    // DEBUG: Print the words
    // for (int i = 0; i < count; i++) {
    //     printf("%s\n", words[i]);
    // }
    // printf("Number of words: %d\n", count);

    // Turn words dict into upper letters
    for (int i = 0; i < count; i++) {
        for (int j = 0; j < 5; j++) {
            words[i][j] = toupper(words[i][j]);
        }
    }

    struct singleWord singleWords[count];
    for (int i = 0; i < count; i++) {
        strcpy(singleWords[i].word, words[i]);
        singleWords[i].freq = 0;
    }

    // Build the letter frequency table
    int freq[26] = {0};
    buildFrenquencyTable(freq);

    // Calculate the sum of frequencies for each word
    for (int i = 0; i < count; i++) {
        for (int j = 0; j < 5; j++) {
            singleWords[i].freq += freq[words[i][j] - 'A'];
        }
    }
    
    // Find the word with the highest frequency
    int maxFreq = 0;
    int maxFreqIndex = 0;
    for (int i = 0; i < count; i++) {
        if (singleWords[i].freq > maxFreq) {
            maxFreq = singleWords[i].freq;
            maxFreqIndex = i;
        }
    }

    // DEBUG: Print the word with the highest frequency
    //printf("Word with the highest frequency: %s\n", singleWords[maxFreqIndex].word);


    while(playerWin==false){
        //printCharStatus();
        //sort the words by frequency from big to small, if the frequency is the same, sort by the word index from small to big
        for (int i = 0; i < count; i++) {
            for (int j = i + 1; j < count; j++) {
                if (singleWords[i].freq < singleWords[j].freq) {
                    struct singleWord temp = singleWords[i];
                    singleWords[i] = singleWords[j];
                    singleWords[j] = temp;
                }
                else if (singleWords[i].freq == singleWords[j].freq && strcmp(singleWords[i].word, singleWords[j].word) > 0) {
                    struct singleWord temp = singleWords[i];
                    singleWords[i] = singleWords[j];
                    singleWords[j] = temp;
                }
            }
        }

        //print the word with the highest frequency
        //printf("DEBUG: Possible word count: %d\n", possibleWordCount);
        if(possibleWordCount==0){
            printf("No Advice\n");
            return 0;
        }
        printf("Advice:   %s\n", singleWords[0].word);

        //get the feedback from the user
        char feedback[6];
        printf("Feedback: ");
        scanf("%s", feedback);

        //check feedvack is valid
        if(strlen(feedback)!=5){
            printf("Wrong Input\n");
            return 0;
        }
        for(int i = 0; i < 5; i++) {
            if(feedback[i] != 'B' && feedback[i] != 'Y' && feedback[i] != 'G') {
                printf("Wrong Input\n");
                return 0;
            }
        }
        

        //check if the player has won the game
        if(strcmp(feedback,"GGGGG")==0){
            playerWin=true;
            printf("Congratulations!!\n");
            break;
        }
        

        //remove the words that are not possible
        for (int i = 0; i < count; i++) {
            int g = 0;
            int y = 0;
            int b = 0;
            for (int j = 0; j < 5; j++) {
                if (feedback[j] == 'G' && strchr(singleWords[i].word, singleWords[0].word[j]) == &singleWords[0].word[j]) {
                    sureWord[j]=singleWords[0].word[j];
                    if(charStatus[singleWords[0].word[j]-'A']==0||charStatus[singleWords[0].word[j]-'A']==2){
                        charStatus[singleWords[0].word[j]-'A']=3;
                    }
                    g++;
                }
                else if (feedback[j] == 'Y' && strchr(singleWords[i].word, singleWords[0].word[j]) != NULL) {
                    if(charStatus[singleWords[0].word[j]-'A']==0){
                        charStatus[singleWords[0].word[j]-'A']=2;
                    }
                    y++;
                }
                else if (feedback[j] == 'B' && strchr(singleWords[i].word, singleWords[0].word[j]) == NULL) {
                    if(charStatus[singleWords[0].word[j]-'A']==0){
                        charStatus[singleWords[0].word[j]-'A']=1;
                    }
                    b++;
                }
            }
        }
        singleWords[0].freq = 0;
        possibleWordCount--;


        //printf("DEBUG: Sure word: %s\n", sureWord);
        //calculate the frequency of the words
        for (int i = 0; i < count; i++) {
            if(singleWords[i].freq!=0){
                for (int j = 0; j < 5; j++) {
                    if(charStatus[singleWords[i].word[j]-'A']==1){
                        singleWords[i].freq=0;
                        possibleWordCount--;
                        break;
                    }

                    //printf("DEBUG: sureWord[j]: %d\n", sureWord[j]);
                    
                    if(sureWord[j]!=255 && singleWords[i].word[j]!=sureWord[j]){
                        singleWords[i].freq=0;
                        possibleWordCount--;
                        break;
                    }
                }
            }
        }

        //calculate the frequency of the words




    }




    return 0;
}

/*
I want you to develop a tool for me to win
this game. I will show you what I want.
1. First, you need an English dictionary. You can install hunspell-en-us in Ubuntu and
get the English dictionary en_US.dic. Or you can directly download it from the
following link.
https://cgit.freedesktop.org/libreoffice/dictionaries/tree/en
2. Find all possible 5-letter words from the dictionary.
3. Propose the most possible candidate word to the user.
• You must use the letter frequency table from the following link to calculate the
summation of 5-letter frequency. You should use the text one. The 5-letter word
in the candidate with the highest frequency is the most possible one.
https://en.wikipedia.org/wiki/Letter_frequency
4. Let the user to input the feedback from the Wordle site. The feedback will be
”XXXXX” where X can be:
• G: in the word and in the correct spot.
• Y: in the word but in the wrong spot.
• B: not in the word in any spot.
For your convenience,
• You do not need to provide the dictionary file when submitting your homework. Our
TAs will put a dictionary file in your program directory and you can simply open the
dictionary file directly in your program.
• Undoubtedly, there is no complete dictionary in this world. In this problem, you can
just treat the dictionary as the complete one.
• You do not need to care about any variations of the word.
• The input should be case insensitive.
The program interface is as follows. Note that this is from my playing record and I do
not do frequency analysis when playing.
1 ./hw0203
2 Advice: AUDIO // <-- Advice from your program
3 Feedback: YBYBB // <-- User input
4 Advice: SHADE // <-- Advice from your program
5 Feedback: GGGGG // <-- User input
6 Congratulations!!
*/