#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

typedef struct _sTeam{
    char name[50];
    int32_t W;
    int32_t D;
    int32_t L;
    int32_t GF;
    int32_t GA;
    int32_t GD;
    int32_t Pts;
} sTeam;

int32_t compare(const void *a, const void *b) {
    const sTeam *team1 = (const sTeam *)a;
    const sTeam *team2 = (const sTeam *)b;
    if (team2->Pts != team1->Pts){
        return team2->Pts - team1->Pts;
    }
    if (team2->GD != team1->GD){
        return team2->GD - team1->GD;
    }
    return team2->GF - team1->GF;
}

int main(){
    FILE *season;
    char filename[100] = {0};

    printf("Please enter the data file name: ");
    scanf("%s", filename);
    season = fopen (filename, "r");
    if (season == NULL){
        printf("file not found\n");
        return 0;
    }

    char buffer[200];
    sTeam team[30];
    for (int32_t i = 0; i < 30; i++){
        memset(team[i].name, 0, sizeof(team[i].name));
        team[i].W = 0;
        team[i].D = 0;
        team[i].L = 0;
        team[i].GF = 0;
        team[i].GA = 0;
        team[i].GD = 0;
        team[i].Pts = 0;
    }
    int32_t index = -1;

    while (fgets(buffer, sizeof(buffer), season) != NULL) {
        if (buffer[0] == 'D'){
            continue;
        }

        int32_t length = strlen(buffer);
        int32_t count = 0;
        int32_t start = 0;
        char temp[200] = {0};
        int32_t home = 0;
        int32_t away = 0;
        for (int32_t i = 0; i < length; i++){
            if (buffer[i] == ','){
                start = i;
                count++;
                for (int32_t j = 0; temp[j]; j++){
                    temp[j] = 0;
                }
            }
            // input name
            if ((count == 1 || count == 2) && buffer[i+1] != ','){
                // printf("%d %d %d\n", count, i, i-start);
                temp[i-start] = buffer[i+1];
                // printf("%s\n", temp);
                if (buffer [i+2] == ','){
                    int32_t check = 0;
                    for (int32_t j = 0; j <= index; j++){
                        // printf("%s\n %s\n", temp, team[j].name);
                        if (strcmp(temp, team[j].name) == 0){
                            if (count == 1){
                                home = j;
                            }
                            else if (count == 2){
                                away = j;
                            }
                            check = -1;
                            break;
                        }
                    }
                    if (check == 0){
                        index++;
                        strcpy(team[index].name, temp);
                        if (count == 1){
                            home = index;
                        }
                        else if (count == 2){
                            away = index;
                        }
                        // printf("%s %d\n", team[index].name, index);
                    }
                }
            }

            // W D L Pts
            if (count == 5 && buffer[i] == ','){
                if (buffer[i+1] == 'H'){
                    team[home].W++;
                    team[home].Pts += 3;
                    team[away].L++;
                }
                else if (buffer[i+1] == 'D'){
                    team[home].D++;
                    team[away].D++;
                    team[home].Pts++;
                    team[away].Pts++;
                }
                else if (buffer[i+1] == 'A'){
                    team[away].W++;
                    team[away].Pts += 3;
                    team[home].L++;
                }
            }

            // GF GA
            if (count == 3 && buffer[i] == ','){
                team[home].GF += buffer[i+1]-48;
                team[away].GA += buffer[i+1]-48;
            }
            if (count == 4 && buffer[i] == ','){
                team[away].GF += buffer[i+1]-48;
                team[home].GA += buffer[i+1]-48;
            }

        }
        // printf("%s", buffer);
    }

    // calculate GD
    for (int32_t i = 0; i <= index; i++){
        team[i].GD = team[i].GF - team[i].GA;
    }

    // sort
    qsort(team, index+1, sizeof(sTeam), compare);
    
    // align
    printf("    Team                  W    D    L    GF    GA    GD    Pts\n");
    for (int32_t i = 0; i <= index; i++){
        if (team[i].GD > 0){
            printf("%02d) %-21s %-4d %-4d %-4d %-5d %-5d +%-3d %4d\n", i+1, team[i].name, team[i].W, team[i].D, team[i].L, team[i].GF, team[i].GA, team[i].GD, team[i].Pts);
        }
        else{
            printf("%02d) %-21s %-4d %-4d %-4d %-5d %-5d %-5d %3d\n", i+1, team[i].name, team[i].W, team[i].D, team[i].L, team[i].GF, team[i].GA, team[i].GD, team[i].Pts);
        }
    }

    // close
    fclose(season);
}