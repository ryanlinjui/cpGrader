#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include "mybmp.h"

int main(){
    FILE *input;
    FILE *output;
    char input_name[50] = {0};
    char output_name[50] = {0};
    double angle = 0;
    printf("Please input a BMP file: ");
    scanf("%s", input_name);
    input = fopen(input_name, "rb");
    if (input == NULL){
        printf("file not found\n");
        return 0;
    }
    printf("Please input the output BMP file name: ");
    scanf("%s", output_name);
    printf("Angle (0-90): ");
    scanf("%lf", &angle);
    if (angle < 0 || angle >= 90){
        printf("out of range\n");
        return 0;
    }

    // read file
    BMPHeader myheader;
    read_header(input, &myheader);
    output = fopen(output_name, "wb");
    if (output == NULL){
        printf("create new file failed\n");
        return 0;
    }

    // new width
    int32_t old_width = myheader.width;
    myheader.width += round(myheader.height * tan((angle/180)*M_PI));
    
    // calculate padding
    int32_t bytes_per_row = myheader.width*myheader.bitsPerPixel/8;
    int32_t padding = (4 - (bytes_per_row%4))%4;
    // write header to new file
    fwrite(&myheader, sizeof(BMPHeader), 1, output);

    uint8_t pixel[3] = {0};
    uint8_t white[3] = {255, 255, 255};
    uint8_t padding_byte = 255;
    for (int y = 0; y < myheader.height; y++){
        for (int x = 0; x < myheader.width; x++){
            if (x < round(y*tan((angle/180)*M_PI))){
                fwrite(white, sizeof(uint8_t), 3, output);
            }
            else if (x >= round(y*tan((angle/180)*M_PI))+old_width){
                fwrite(white, sizeof(uint8_t), 3, output);
            }
            else{
                fread(pixel, sizeof(uint8_t), 3, input);
                fwrite(pixel, sizeof(uint8_t), 3, output);
            }
        }
        // add padding
        for (int32_t i = 0; i < padding; i++){
            fwrite(&padding_byte, sizeof(uint8_t), 1, output);
        }
    }
}