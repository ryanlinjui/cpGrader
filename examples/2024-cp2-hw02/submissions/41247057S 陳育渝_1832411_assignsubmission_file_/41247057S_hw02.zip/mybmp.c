#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "mybmp.h"

int32_t read_header(FILE *file, BMPHeader *header){
    if (file == NULL) {
        return -1;
    }
    if (fread(header, sizeof(*header), 1, file) != 1) {
        printf("Failed to read BMP header.\n");
        fclose(file);
        return 0;
    }
    return 0;
}

// int32_t read_array(FILE *file, uint8_t **pixel, BMPHeader *header){
//     if (file == NULL){
//         return -1;
//     }
//     *pixel = calloc(header->width*header->height, sizeof(uint8_t));
//     for (int y = 0; y < header->height; y++){
//         for (int x = 0; x < header->width; x++){
//             fread(pixel, sizeof(uint8_t), 3, file);
//         }
//     }
//     return 0;
// }