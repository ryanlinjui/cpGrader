#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

// BGR

int main(){
    FILE *ass;
    char filename[100] = {0};
    printf("Please enter the file name: ");
    scanf("%s", filename);
    ass = fopen (filename, "r");
    if (ass == NULL){
        printf("file not found\n");
        return 0;
    }
    int32_t shift = 0;
    printf("Time Shift ( -10 ~ 10 ): ");
    scanf("%d", &shift);
    if (shift < -10 || shift > 10){
        printf("out of range\n");
        return 0;
    }
    double speed = 0;
    printf("Speed (0.25,0.5,0.75,1,1.25,1.5,1.75,2): ");
    scanf("%lf", &speed);
    int32_t check = 0;
    for (int32_t i = 1; i <= 8; i++){
        if (speed == 0.25*i){
            check++;
        }
    }
    if (check != 1){
        printf("only support above candidate\n");
        return 0;
    }
    
    char buffer[1000] = {0};
    uint8_t red = 0;
    uint8_t green = 0;
    uint8_t blue = 0;
    int32_t zero = -1;
    while (fgets(buffer, sizeof(buffer), ass) != NULL){
        int32_t length = strlen(buffer);
        int32_t count = 0;
        uint32_t COLOR = 0;
        char color_string[15] = {0};
        //color set
        if (buffer[0] == 'S' && buffer[1] == 't' && buffer[2] == 'y'){
            int32_t index = 0;
            for (int32_t i = 0; count < 4; i++){
                if (buffer[i] == ','){
                    count++;
                }
                if (count == 4){
                    index = i+1;
                }
            }
            for (int32_t i = 0; buffer[index+i] != ','; i++){
                color_string[i] = buffer[index+i];
            }
            if (color_string[0] == '&' && color_string[1] == 'H'){
                int32_t len = strlen(color_string)-2;
                char hex[7] = "000000\0";
                if (len == 6){
                    strncpy(hex, color_string+2, 6);
                    uint32_t color = strtol(hex, NULL, 16);
                    blue = (color >> 16) & 0xFF; 
                    green = (color >> 8) & 0xFF;
                    red = color & 0xFF;
                }
                if (len == 8){
                    strncpy(hex, color_string+4, 6);
                    uint32_t color = strtol(hex, NULL, 16);
                    blue = (color >> 16) & 0xFF; 
                    green = (color >> 8) & 0xFF;
                    red = color & 0xFF;
                }
            }
            else if (strlen(color_string) == 8){
                uint32_t color = strtol(color_string, NULL, 10);
                blue = (color / (256 * 256)) % 256;
                green = (color / 256) % 256;
                red = color % 256;
            }
        }
        // Dialogue 會改變
        char *needle = strstr(buffer, "Dialogue");
        if (needle == NULL){
            continue;
        }
        zero++;
        count = 0;
        int32_t index = 0;
        char start_time[11] = {0};
        start_time[10] = '\0';
        int64_t start = 0;
        int64_t time = 0;
        // time set
        for (int32_t i = 0; count < 1; i++){
            if (buffer[i] == ','){
                count++;
            }
            if (count == 1){
                index = i+1;
            }
        }
        for (int32_t i = 0; buffer[index+i] != ','; i++){
            start_time[i] = buffer[index+i];
        }
        for (int32_t i = 0; start_time[i] != '\0'; i++){
            start += 3600 * (start_time[0]-48);
            if (start_time[i] == ':' && i > 2){
                start += 60 * ((start_time[i-2]-48)*10+(start_time[i-1]-48));
            }
            if (start_time[i] == '.'){
                start += (start_time[i-2]-48)*10+(start_time[i-1]-48)+shift;
            }
            if (start_time[i+1] == '\0'){
                start *= 1000000;
                start += ((start_time[i-1]-48)*10+(start_time[i]-48))*10000;
            }
        }
        if (zero == 0){
            time = start - zero;
            usleep((double)time/speed);
        }
        char end_time[11] = {0};
        end_time[10] = '\0';
        count = 0;
        index = 0;
        int64_t end = 0;
        for (int32_t i = 0; count < 2; i++){
            if (buffer[i] == ','){
                count++;
            }
            if (count == 2){
                index = i+1;
            }
        }
        for (int32_t i = 0; buffer[index+i] != ','; i++){
            end_time[i] = buffer[index+i];
        }
        for (int32_t i = 0; end_time[i] != '\0'; i++){
            end += 3600 * (end_time[0]-48);
            if (end_time[i] == ':' && i > 2){
                end += 60 * ((end_time[i-2]-48)*10+(end_time[i-1]-48));
            }
            if (end_time[i] == '.'){
                end += (end_time[i-2]-48)*10+(end_time[i-1]-48)+shift;
            }
            if (end_time[i+1] == '\0'){
                end *= 1000000;
                end += ((end_time[i-1]-48)*10+(end_time[i]-48))*10000;
            }
        }
        time = end-start;
        // printf("%d\n", time);
        // printf("%s\n", start_time);
        // printf("%s\n", end_time);
        // print text
        count = 0;
        int32_t START = 1;
        for (int32_t i = 0; i < length; i++){
            if (buffer[i] == ','){
                count++;
            }
            if (count == 9){
                START += i;
                break;
            }
        }
        // printf("%d %d %d\n", red, green, blue);
        printf("\033[38;2;%d;%d;%dm", red, green, blue);
        printf("%s", buffer+START);
        usleep((double)time/speed);
    }

}