#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

typedef struct s_Word{
    char letter[20];
    double frequency;
}sWord;

int32_t find_advice(char ans[20], sWord list[5000], int32_t total, char input[10], int32_t delete[26], int32_t used[5][26]){
    double max = 0;
    int32_t max_index = 0;
    for (int32_t i = 0; i < total; i++){
        if (round(list[i].frequency*1000) > round(max*1000)){
            int32_t check = 0;
            int32_t COUNT[26] = {0};
            for (int32_t j = 0; j < 5; j++){
                int32_t temp = list[i].letter[j]-65;
                COUNT[temp]++;
            }
            for (int32_t j = 0; j < 5; j++){
                int32_t temp = list[i].letter[j]-65;
                // printf("%d %d %s", delete[temp], temp, list[i].letter);
                if (delete[temp] < 0){
                    check = -1;
                    break;
                }
                if (used[j][temp] > 0){
                    check = -1;
                    break;
                }
                // printf("%d %d %c\n", COUNT[temp], delete[temp], list[i].letter[j]);
                if (delete[temp] > 0){
                    if (COUNT[temp] != delete[temp]){
                        // printf("%s", list[i].letter);
                        // printf("%d %d %c\n", COUNT[temp], delete[temp], list[i].letter[j]);
                        check = -1;
                        break;
                    }
                }
                // printf("%c %d\n", temp+65, COUNT[temp]);
            }
            for (int32_t j = 0; j < 5; j++){
                if (input[j] == 'G' && ans[j] != list[i].letter[j]){
                    check = -1;
                    break;
                }
                else if (input[j] == 'Y'){
                    int32_t temp = ans[j]-65;
                    used[j][temp] = 1;
                    int32_t count = 0;
                    for (int32_t k = 0; k < 5; k++){
                        if (ans[j] == list[i].letter[k] && k != j){
                            count++;
                        }
                    }
                    if (count == 0){
                        check = -1;
                        break;
                    }
                }
                else if (input[j] == 'B'){
                    int32_t temp = ans[j]-65;
                    int32_t b = 0;
                    int32_t first = 0;
                    if (delete[temp] > 0){
                        first = 1;
                    }
                    for (int32_t k = 0; k < 5; k++){
                        if ((input[k] == 'Y' || input[k] == 'G') && ans[k] == ans[j] && first == 0){
                            // printf("%c %d\n", temp+65, delete[temp]);
                            used[j][temp] = 1;
                            delete[temp]++;
                            b = -1;
                        }
                        else if ((input[k] == 'Y' || input[k] == 'G') && ans[k] == ans[j] && first > 0){
                            used[j][temp] = 1;
                            b = -1;
                            break;
                        }
                    }
                    if (b == -1){
                        // printf("%c %d\n", temp+65, delete[temp]);
                        continue;
                    }
                    if (temp+65 == 'T'){
                        // printf("check\n");
                    }
                    delete[temp] = -1;
                    int32_t count = 0;
                    for (int32_t k = 0; k < 5; k++){
                        if (ans[j] == list[i].letter[k]){
                            count++;
                        }
                    }
                    if (count > 0){
                        check = -1;
                        break;
                    }
                    // printf("%d %c\n", count, ans[j]);
                }
            }
            if (check == 0){
                max = list[i].frequency;
                max_index = i;
            }
        }
    }
    for (int32_t i = 0; i < 5; i++){
        if (list[max_index].letter[i] >= 97 && list[max_index].letter[i] <= 122){
            list[max_index].letter[i] -= 32;
        }
        ans[i] = list[max_index].letter[i];
    }
    if (max == 0){
        return -1;
    }
    return 0;
}

int main(){
    FILE *dic = fopen("en_US.dic", "r");
    double freq[26] = {8.2, 1.5, 2.8, 4.3, 12.7, 2.2, 2.0, 6.1, 7.0, 0.15, 0.77, 4.0, 2.4, 6.7, 7.5, 1.9, 0.095, 6.0, 6.3, 9.1, 2.8, 0.98, 2.4, 0.15, 2.0, 0.074};
    char advice[20] = {0};
    char feedback[10] = {0};
    char buffer[20];
    sWord word[5000];
    int32_t index = 0;
    int32_t used_words[26] = {0};
    int32_t position[5][26] = {0};
    while(fgets(buffer, sizeof(buffer), dic) != NULL){
        int32_t check = 0;
        for (int32_t i = 0; i < 5; i++){
            if (buffer[i] == '/'){
                check++;
                break;
            }
            if ((buffer[i]<65 || buffer[i]>90) && (buffer[i]<97 || buffer[i]>122)){
                check++;
                break;
            }
        }
        if ((buffer[5] == '/' || strlen(buffer) == 6) && check == 0){
            strcpy(word[index].letter, buffer);
            int32_t number = 0;
            word[index].frequency = 0;
            for (int32_t i = 0; i < 5; i++){
                if (word[index].letter[i] >= 65 && word[index].letter[i] <= 90){
                    number = word[index].letter[i]-65;
                }
                else{
                    number = word[index].letter[i]-97;
                    word[index].letter[i] -= 32;
                }
                word[index].frequency += freq[number];
            }
            // printf("%s", word[index].letter);
            index++;
        }
        else{
            continue;
        }
    }
    fclose(dic);
    while(1){
        // set advice
        int32_t RETURN = find_advice(advice, word, index, feedback, used_words, position);
        if (RETURN == -1){
            printf("No Advice\n");
            return 0;
        }
        printf("Advice: ");
        printf("%s\n", advice);
        printf("Feedback: ");
        scanf("%s", feedback);
        int32_t length = strlen(feedback);
        if (length != 5){
            printf("Wrong Input\n");
            return 0;
        }
        for (int32_t i = 0; i < length; i++){
            if (!(feedback[i] == 'G' || feedback[i] == 'Y' || feedback[i] == 'B')){
                printf("Wrong Input\n");
                return 0;
            }
        }
        if (strcmp(feedback, "GGGGG") == 0){
            printf("Congratulations!!\n");
            return 0;
        }
    }
}