#ifndef BMP_HEADER_H
#define BMP_HEADER_H

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#pragma pack(push, 1) // 使用1字节对齐
typedef struct {
    uint16_t signature;  // 文件标识，固定为0x4D42（"BM"）
    uint32_t fileSize;   // 文件大小，单位为字节
    uint32_t reserved;   // 保留，必须为0
    uint32_t dataOffset; // 数据偏移量，文件头的大小
    uint32_t headerSize; // BITMAPINFOHEADER的大小，一般为40字节
    int32_t width;       // 图像宽度，单位为像素
    int32_t height;      // 图像高度，单位为像素
    uint16_t planes;     // 色彩平面数，固定为1
    uint16_t bitsPerPixel; // 每个像素的位数，一般为24
    uint32_t compression; // 压缩类型，0表示不压缩
    uint32_t dataSize;    // 数据大小，等于文件大小减去数据偏移量
    int32_t horizontalResolution; // 水平分辨率，单位为像素/米
    int32_t verticalResolution;   // 垂直分辨率，单位为像素/米
    uint32_t colorsUsed;          // 使用的颜色数，对于24位图像，一般为0
    uint32_t importantColors;     // 重要颜色数，对于24位图像，一般为0
} BMPHeader;
#pragma pack(pop)

int32_t read_header(FILE *file, BMPHeader *header);
int32_t read_array(FILE *file, uint8_t **pixel, BMPHeader *header);

#endif