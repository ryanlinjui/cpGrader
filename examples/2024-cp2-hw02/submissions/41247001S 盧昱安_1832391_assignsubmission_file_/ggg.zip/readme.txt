Hello TAs, 

My Student ID = 41247001S

I forgot what I wrote in README in last semester XD.
This semester I manage to write CP2 homework in VSCode, Windows.
However, I promise that all of my code are still tested under Ubuntu
after I done all my the homework.
Therefore, I consider that there will be no compile error (maybe).
Please give me 100 pls ><.

Bonus are written in hw0206.pdf


