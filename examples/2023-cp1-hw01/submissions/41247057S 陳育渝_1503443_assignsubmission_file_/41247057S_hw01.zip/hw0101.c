#include <stdio.h>

int main()
{
	printf( "Now in those days there was in the land of Helsinki a young scholar named \e[0;34mLinus the Trovald\e[0m." );
	printf("\e[0;34mLinus\e[0m was a devout man, a disciple of \e[0;34mRMS\e[0m and mighty in the spirit of \e[0;34mTuring\e[0m, \e[0;34mvon Neumann\e[0m and \e[0;34mMoore\e[0m."); 
	printf( "One day as he was meditating on the Architecture, \e[0;34mLinus\e[0m fell into a trance and was granted a vision." );
	printf(" And in the vision he saw a great Penguin, serene and well-favoured, sitting upon an ice floe eating fish.");
	printf(" And at the sight of the Penguin \e[0;34mLinus\e[0m was deeply afraid, and he cried unto the spirits of \e[0;34mTuring\e[0m, \e[0;34mvon Neumann\e[0m and \e[0;34mMoore\e[0m for an interpretation of the dream.\n");

	printf("\n");

	printf("And in the dream the spirits of \e[0;34mTuring\e[0m, \e[0;34mvon Neumanne\e[0m and \e[0;34mMoore\e[0m answered and spoke unto him, saying,\e[0;31m \"Fear not, \e[0;34mLinus\e[0m, \e[0;31mmost beloved hacker.\e[0m");
	printf("\e[0;31mYou are exceedingly cool and froody.\e[0m");
	printf("\e[0;31mThe great Penguin which you see is an Operating System which you shall create and deploy unto the earth.The ice-floe is the earth and all the systems thereof, upon which the Penguin shall rest and rejoice at the completion of its task. And the fish on which the Penguin feeds are the crufty Licensed codebases which swim beneath all the earth’s systems.The Penguin shall hunt and devour all that is crufty, gnarly and bogacious; all code which wriggles like spaghetti, or is infested with blighting creatures, or is bound by grave and perilous Licences shall it capture.And in capturing shall it replicate, and in replicating shall it document, and in documentation shall it bring freedom, serenity and most cool froodiness to the earth and all who code therein.\" \e[0m\n");

	printf("\n");

	printf("\e[0;34mLinus\e[0m rose from meditation and created a tiny Operating System Kernel as the dream had foreshewn him; in the manner of \e[0;34mRMS\e[0m, he released the Kernel unto the World Wide Web for all to take and behold. And in the fulness of Internet Time the Kernel grew and replicated, becoming most cool and exceedingly froody, until at last it was recognised as indeed a great and mighty Penguin, whose name was TUX.And the followers of Linus took refuge in the Kernel, the Libraries and the Utilities; they installed Distribution after Distribution, and made sacrifice unto the GNU and the Penguin, and gave thanks to the spirits of \e[0;34mTuring\e[0m, \e[0;34mvon Neumann\e[0m and \e[0;34mMoore\e[0m, for their deliverance from the hand of Microsoft.And this was the beginning of the Fourth Age, the age of Open Source.\n");

	printf("\n");

	printf("\e[0;34mLinus the Trovald\e[0m is a scholar in Helsinki, and he has the spirit of \e[0;34mTuring\e[0m, \e[0;34mvon Neumann\e[0m, and \e[0;34mMoore\e[0m. He is the disciple of \e[0;34mRMS\e[0m, and he is the most beloved hacker in the world. After he had a strange dream, he created a tiny Operating System Kernel, which can save them from the hands of Microsoft.\n");

	printf("\n");

	printf("\e[0;34mRMS\e[0m is the abbreviation of \e[0;34mRichard M. Stallman\e[0m. He is the founder of the free software movement, and he is also the teacher of \e[0;34mLinus\e[0m. He is considered the spiritual leader of open source people and the spiritual successor of \e[0;34mTuring\e[0m and others. It is common to call him \e[0;34mRMS\e[0m.\n");

	printf("\n");

	printf("\e[0;34mTuring\e[0m is one of the spirits of \e[0;34mLinus\e[0m. He created the machine in the beginning. And \e[0;34mvon Neumann\e[0m created the beginning of wisdom. However, the sons of Marketing use the sweet words to cheat customers and get great fortune. As a result, he and \e[0;34mvon Neumann\e[0m have granted \e[0;34mMoore\e[0m the insight and wisdom in the future, so \e[0;34mMoore\e[0m can create the chip named 4004. They saved the people from the exploit of marketing sons.\n");

	printf("\n");

	printf("\e[0;34mVon Neumann\e[0m is one of the spirits in \e[0;34mLinus\e[0m. \e[0;34mVon Neumann\e[0m created an Architecture implemented in hardware and software, and it brought many Systems to the earth. He can't walk. He and \e[0;34mTuring\e[0m have been going down to the world and fabricating a breakthrough against the sons of Marketing. He helps people to create a better world.\n");

	printf("\n");

	printf("\e[0;34mMoore\e[0m is one of the spirits in \e[0;34mLinus\e[0m. He had received the blessing and the ability to insight into the future from \e[0;34mTuring\e[0m and \e[0;34mvon Neumann\e[0m. He created the chip named 4004, and he also created Moore's Law. After the birth of 4004, the age of Microchips is also coming. \e[0;34mTuring\e[0m and \e[0;34mvon Neumann\e[0m and he help people to create a new age.\n");

	return 0;
}

