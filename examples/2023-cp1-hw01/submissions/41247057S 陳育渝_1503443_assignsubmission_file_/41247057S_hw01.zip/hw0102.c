#include <stdio.h>
#include <stdint.h>

int main()
{
	int32_t a = 0;
	int32_t b = 0;
	int32_t ans1 = 0;
	int32_t ans2 = 0;
	int32_t ans3 = 0;
	printf("Please enter the first integer (0~99):");
	scanf( "%d", &a );
	if ( a < 0 || a > 99){
		printf("Wrong input, your input must between 0 ~ 99.\n");
		return 0;
	}
	printf("Please enter the second integer (0~99):");
        scanf( "%d", &b );
	if ( b < 0 || b > 99){
		printf("Wrong input, your input must between 0 ~ 99.\n");
		return 0;
	}
	
	ans1 = a * (b % 10);
	ans2 = a * (b / 10);
	ans3 = ans1 + 10 * ans2;

	//如果乘數只有一位數
	if (a < 10 && b < 10 && ans3 < 10){
		printf( "   %d\n", a);
		printf( "*) %d\n", b);
		printf("----\n");
		printf("   %d\n", ans3);
		return 0;
       	}
        if (a < 10 && b < 10 && 100 > ans3 && ans3 > 10){
        	printf( "    %d\n", a);
        	printf( "*)  %d\n", b);
        	printf("-----\n");
        	printf("  %d %d\n", ans3/10, ans3%10);
        	return 0;
	}
	if (a < 10 && b > 9 && ans3 < 100 && ans3 > 10){
		printf( "      %d\n", a);
		printf( "*)  %d %d\n", b/10, b%10);
		printf("-------\n");
		printf("    %d %d\n", ans3/10, ans3%10);
		return 0;
	}
	else if ( a < 10 && b > 9 && ans3 > 99){
		printf( "      %d\n", a);
                printf( "*)  %d %d\n", b/10, b%10);
                printf("-------\n"); 
		printf("  %d %d %d\n",(ans3%1000)/100, (ans3%100/10), ans3%10);
		return 0;
	}
	if (a > 9 && b < 10 && ans3 < 100 && ans3 > 10){
                printf( "    %d %d\n", a/10, a%10);
                printf( "*)    %d\n", b);
                printf("-------\n");
                printf("    %d %d\n", ans3/10, ans3%10);
		return 0;
        }
        else if ( a > 9 && b < 10 && ans3 > 99){
                printf( "    %d %d\n", a/10, a%10);
                printf( "*)    %d\n", b);
                printf("-------\n");
                printf("  %d %d %d\n",(ans3%1000)/100, (ans3%100/10), ans3%10);
		return 0;
	}

	//如果乘數= 0
	if ( a == 0){
		printf( "      0\n");
		printf( "*)  %d %d\n", b/10, b%10);
		printf("-------\n");
		printf("      0\n");
		return 0;
	}
	if ( b == 0){
		printf( "    %d %d\n", a/10, a%10);
		printf( "*)    0\n");
		printf("-------\n");
		printf("      0\n");
		return 0;
	}

	if ( ans3 > 999){
		printf("      %d %d\n", a/10, a%10);
		printf("*)    %d %d\n", b/10, b%10);
        	printf("---------\n");
	}
	else{
		printf("    %d %d\n", a/10, a%10);
		printf("*)  %d %d\n", b/10, b%10);
		printf("-------\n");
	}
        if (ans1 > 99 ){
        	printf( "    %d %d %d\n",ans1/100, (ans1%100)/10, ans1%10 );
        }
        else if (ans1 == 0 && (100 > ans3 && ans3 > 9) ){
		printf( "      0\n");
	}
	else if (ans1 == 0 && (ans3 > 99 && ans3 < 1000) ){
		printf( "      0\n");
	}
	else if (ans1 == 0 && ans3 > 999){
		printf( "        0\n");
	}
	else if (ans3 > 100){
		printf( "    %d %d\n", (ans1%100)/10, ans1%10 );
	}
	else {
        	printf( "      %d %d\n", (ans1%100)/10, ans1%10 );
        }
        if (ans2 > 99){
        	printf("  %d %d %d\n",ans2/100, (ans2%100)/10, ans2%10 );
        }
	else if (ans3 > 100){
		printf("  %d %d\n", (ans2%100)/10, ans2%10 );
	}
	else{
            	printf("    %d %d\n", (ans2%100)/10, ans2%10 );
        }	
        if (ans3 > 999){
        	printf("---------\n");
		printf("  %d %d %d %d\n",ans3/1000, (ans3%1000)/100, (ans3%100/10), ans3%10);
        }
	else if (ans3 > 99){
		printf("-------\n");
        	printf("  %d %d %d\n",(ans3%1000)/100, (ans3%100/10), ans3%10);
        }
        else {
		printf("-------\n");
        	printf("          %d %d\n",(ans3%100/10), ans3%10);
        }
        
	return 0;	
}
