#include <stdio.h>
#include <stdint.h>

int main()
{
	int32_t a1 = 0;
	int32_t a2 = 0;
	int32_t b1 = 0;
	int32_t b2 = 0;
	float x1 = 0;
	float x2 = 0;
	float y1 = 0;
	float y2 = 0;
	float x = 0;
	float y = 0;
	float area = 0;

	printf("Please enter the point A (x,y): ");
	scanf( "%d, %d", &a1, &a2);
	printf("Please enter the point B (x,y): ");
	scanf( "%d, %d", &b1, &b2);

	if ( a1 == b1 || a2 == b2){
		printf( "Area:0\n");
		return 0;
	} 	

	x1 = (0 - a2) * (b1 - a1);
	x2 = (b2 - a2);
	x = x1 / x2 + a1;

	y1 = (0 - a1) * (b2 - a2);
	y2 = (b1 - a1);
	y = y1 / y2 + a2;

	area = x * y / 2;
	
	if ( area < 0 ){
		printf( "Area:" "%.2f\n", - area);
	}
	else{
		printf("Area:" "%.2f\n", area);
	}	

	return 0;
}
