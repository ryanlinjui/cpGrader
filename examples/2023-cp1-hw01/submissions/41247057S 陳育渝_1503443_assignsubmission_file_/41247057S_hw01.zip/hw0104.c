#include <stdio.h>
#include <stdint.h>

int main()
{
	int32_t a = 0;
	int32_t b = 0;
	int32_t c = 0;
	int32_t d = 0;
	int32_t e = 0;
	int32_t f = 0;
	int32_t g = 0;
	int32_t h = 0;
	int32_t i = 0;
	int32_t j = 0;
	int32_t k = 0;
	int32_t l = 0;
	int32_t m = 0;
	int32_t HCP = 0;
	int32_t spade = 0;
	int32_t heart = 0;
	int32_t diamond = 0;
	int32_t club = 0;

	printf("1st card: ");
	scanf( "%d", &a);
	if (1 > a || a > 52){
		printf("Please input the correct number.\n");
		return 0;
	}
	printf("2nd card: ");
	scanf( "%d", &b);
	if (1 > b || b > 52 || b == a){
                printf("Please input the correct number.\n");
                return 0;
        }
	printf("3rd card: ");
	scanf( "%d", &c);
	if (1 > c || c > 52 || c == b || c == a){
                printf("Please input the correct number.\n");
                return 0;
        }
	printf("4th card: ");
	scanf( "%d", &d);
	if (1 > d || d > 52 || d == c || d == b || d == a){
                printf("Please input the correct number.\n");
                return 0;
        }
	printf("5th card: ");
	scanf( "%d", &e);
	if (1 > e || e > 52 || e == d || e == c || e == b || e == a){
                printf("Please input the correct number.\n");
                return 0;
        }
	printf("6th card: ");
	scanf( "%d", &f);
	if (1 > f || f > 52 || f == e || f == d || f == c || f == b || f == a){
                printf("Please input the correct number.\n");
                return 0;
        }
	printf("7th card: ");
	scanf( "%d", &g);
	if (1 > g || g > 52 || g == f || g == e || g == d || g == c || g == b || g ==a){
                printf("Please input the correct number.\n");
                return 0;
        }
	printf("8th card: ");
	scanf( "%d", &h);
	if (1 > h || h > 52 || h == g || h == f || h == e || h == d || h == c || h == b || h == a){
                printf("Please input the correct number.\n");
                return 0;
        }
	printf("9th card: ");
	scanf( "%d", &i);
	if (1 > i || i > 52 || i == h || i == g || i == f || i == e || i == d || i == c || i == b || i == a){
                printf("Please input the correct number.\n");
                return 0;
        }
	printf("10th card: ");
	scanf( "%d", &j);
	if (1 > j || j > 52 || j == i || j == h || j == g || j == f || j == e || j == d || j == c || j == b || j == a){
                printf("Please input the correct number.\n");
                return 0;
        }
	printf("11th card: ");
	scanf( "%d", &k);
	if (1 > k || k > 52 || k == j || k == i || k == h || k == g || k == f || k == e || k == d || k == c || k == b || k == a){
                printf("Please input the correct number.\n");
                return 0;
        }
	printf("12th card: ");
	scanf( "%d", &l);
	if (1 > l || l > 52 || l == k || l == j || l == i || l == h || l == g || l == f || l == e || l == d || l == c || l == b || l == a){
                printf("Please input the correct number.\n");
                return 0;
        }
	printf("13th card: ");
	scanf( "%d", &m);	
	if (1 > m || m > 52 || m == l || m == k || m == j || m == i || m == h || m == g || m == f || m == e || m == d || m == c || m == b || m == a){
                printf("Please input the correct number.\n");
                return 0;
        }

	printf("---\n");

	//HCP
	if ( a % 13 == 1){
		HCP = HCP + 4;
	}
	else if ( a % 13 == 11){
		HCP = HCP + 1;
	}
	else if ( a % 13 == 12){
		HCP = HCP + 2;
	}
	else if ( a % 13 == 0){
		HCP = HCP + 3;
	}
	else{
		HCP = HCP + 0;
	}
	if ( b % 13 == 1){
		HCP = HCP + 4;
	}
	else if ( b % 13 == 11){
		HCP = HCP + 1;
	}
	else if ( b % 13 == 12){
		HCP = HCP + 2;
	}
	else if ( b % 13 == 0){
		HCP = HCP + 3;
	}
	else{
		HCP = HCP + 0;
	}
	if ( c % 13 == 1){
                HCP = HCP + 4;
	}
        else if ( c % 13 == 11){
                HCP = HCP + 1;
        }
        else if ( c % 13 == 12){
                HCP = HCP + 2; 
        }
	else if ( c % 13 == 0){
		HCP = HCP + 3;
	}
        else{
                HCP = HCP + 0;
        }
	if ( d % 13 == 1){
                HCP = HCP + 4;
        }
        else if ( d % 13 == 11){
                HCP = HCP + 1;
        }
        else if ( d % 13 == 12){
                HCP = HCP + 2; 
        }
	else if ( d % 13 == 0){
                HCP = HCP + 3;
        }
        else{
                HCP = HCP + 0;
        }
	if ( e % 13 == 1){
                HCP = HCP + 4;
        }
        else if ( e % 13 == 11){
                HCP = HCP + 1;
        }
        else if ( e % 13 == 12){
                HCP = HCP + 2; 
        }
	else if ( e % 13 == 0){
                HCP = HCP + 3;
        }
        else{
                HCP = HCP + 0;
	}
	if ( f % 13 == 1){
                HCP = HCP + 4;
        }
        else if ( f % 13 == 11){
                HCP = HCP + 1;
        }
        else if ( f % 13 == 12){
                HCP = HCP + 2; 
        }
	else if ( f % 13 == 0){
		HCP = HCP + 3;
	}
        else{
                HCP = HCP + 0;
        }
	if ( g % 13 == 1){
                HCP = HCP + 4;
        }
        else if ( g % 13 == 11){
                HCP = HCP + 1;
        }
        else if ( g % 13 == 12){
                HCP = HCP + 2; 
        }
	else if ( g % 13 == 0){
		HCP = HCP + 3;
	}
	else{
                HCP = HCP + 0;
        }
	if ( h % 13 == 1){
        	HCP = HCP + 4;
        }
        else if ( h % 13 == 11){
                HCP = HCP + 1;
        }
        else if ( h % 13 == 12){
                HCP = HCP + 2; 
        }
	else if ( h % 13 == 0){
		HCP = HCP +3;
	}
        else{
                HCP = HCP + 0;
        } 
	if ( i % 13 == 1){
                HCP = HCP + 4;
        }
        else if ( i % 13 == 11){
                HCP = HCP + 1;
        }
        else if ( i % 13 == 12){
                HCP = HCP + 2; 
        }
	else if ( i % 13 == 0){
		HCP = HCP +3;
	}
        else{
                HCP = HCP + 0;
        }
	if ( j % 13 == 1){
                HCP = HCP + 4;
        }
        else if ( j % 13 == 11){
                HCP = HCP + 1;
        }
        else if ( j % 13 == 12){
                HCP = HCP + 2; 
        }
	else if ( j % 13 == 0){
		HCP = HCP + 3;
	}
        else{
                HCP = HCP + 0;
        }
	if ( k % 13 == 1){
                HCP = HCP + 4;
        }
        else if ( k % 13 == 11){
                HCP = HCP + 1;
        }
        else if ( k % 13 == 12){
                HCP = HCP + 2; 
        }
	else if ( k % 13 == 0){
		HCP = HCP + 3;
	}
        else{
                HCP = HCP + 0;
        }
	if ( l % 13 == 1){
                HCP = HCP + 4;
        }
        else if ( l % 13 == 11){
                HCP = HCP + 1;
        }
        else if ( l % 13 == 12){
                HCP = HCP + 2; 
        }
	else if ( l % 13 == 0){
		HCP = HCP + 3;
	}
        else{
                HCP = HCP + 0;
        }
	if ( m % 13 == 1){
                HCP = HCP + 4;
        }
        else if ( m % 13 == 11){
                HCP = HCP + 1;
        }
        else if ( m % 13 == 12){
                HCP = HCP + 2; 
        }
	else if ( m % 13 == 0){
		HCP = HCP + 3;
	}
        else{
                HCP = HCP + 0;
        }
	printf( "HCP: %d pts\n", HCP);

	//SUIT
	if ( 1 <= a && a <= 13){
		spade = spade + 1;
	}
	else if ( 14 <= a && a <= 26){
		heart = heart + 1;
	}
	else if ( 27 <= a && a <= 39){
		diamond = diamond + 1;	
	}
	else{
		club = club + 1;
	}
	if ( 1 <= b && b <= 13){
                spade = spade + 1;
        } 
        else if ( 14 <= b && b <= 26){
                heart = heart + 1;
        }
        else if ( 27 <= b && b <= 39){
                diamond = diamond + 1;
        }
        else{
                club = club + 1;
        }
	if ( 1 <= c && c <= 13){
                spade = spade + 1;
        } 
        else if ( 14 <= c && c <= 26){
                heart = heart + 1;
        }
        else if ( 27 <= c && c <= 39){
                diamond = diamond + 1;
        }
        else{
                club = club + 1;
        }
	if ( 1 <= d && d <= 13){
                spade = spade + 1;
        } 
        else if ( 14 <= d && d <= 26){
                heart = heart + 1;
        }
        else if ( 27 <= d && d <= 39){
                diamond = diamond + 1;
        }
        else{
                club = club + 1;
        }
	if ( 1 <= e && e <= 13){
                spade = spade + 1;
        } 
        else if ( 14 <= e && e <= 26){
                heart = heart + 1;
        }
        else if ( 27 <= e && e <= 39){
                diamond = diamond + 1;
        }
        else{
                club = club + 1;
        }
	if ( 1 <= f && f <= 13){
                spade = spade + 1;
        } 
        else if ( 14 <= f && f <= 26){
                heart = heart + 1;
        }
        else if ( 27 <= f && f <= 39){
                diamond = diamond + 1;
        }
        else{
                club = club + 1;
        }
	if ( 1 <= g && g <= 13){
                spade = spade + 1;
        } 
        else if ( 14 <= g && g <= 26){
                heart = heart + 1;
        }
        else if ( 27 <= g && g <= 39){
                diamond = diamond + 1;
        }
        else{
                club = club + 1;
        }
	if ( 1 <= h && h <= 13){
                spade = spade + 1;
        } 
        else if ( 14 <= h && h <= 26){
                heart = heart + 1;
        }
        else if ( 27 <= h && h <= 39){
                diamond = diamond + 1;
        }
        else{
                club = club + 1;
        }
	if ( 1 <= i && i <= 13){
                spade = spade + 1;
        } 
        else if ( 14 <= i && i <= 26){
                heart = heart + 1;
        }
        else if ( 27 <= i && i <= 39){
                diamond = diamond + 1;
        }
        else{
                club = club + 1;
        }
	if ( 1 <= j && j <= 13){
                spade = spade + 1;
        } 
        else if ( 14 <= j && j <= 26){
                heart = heart + 1;
        }
        else if ( 27 <= j && j <= 39){
                diamond = diamond + 1;
        }
        else{
                club = club + 1;
        }
	if ( 1 <= k && k <= 13){
                spade = spade + 1;
        } 
        else if ( 14 <= k && k <= 26){
                heart = heart + 1;
        }
        else if ( 27 <= k && k <= 39){
                diamond = diamond + 1;
        }
        else{
                club = club + 1;
        }
	if ( 1 <= l && l <= 13){
                spade = spade + 1;
        } 
        else if ( 14 <= l && l <= 26){
                heart = heart + 1;
        }
        else if ( 27 <= l && l <= 39){
                diamond = diamond + 1;
        }
        else{
                club = club + 1;
        }
	if ( 1 <= m && m <= 13){
                spade = spade + 1;
        } 
        else if ( 14 <= m && m <= 26){
                heart = heart + 1;
        }
        else if ( 27 <= m && m <= 39){
                diamond = diamond + 1;
        }
        else{
                club = club + 1;
        }

	printf("Suit: %d-%d-%d-%d\n", spade, heart, diamond, club);

	//The bidding choice
	//2NT
	if (HCP >= 22 && HCP <= 24){
		if (spade == 4 && heart == 3 && diamond == 3 && club == 3){
                printf("The bidding choice: 2NT\n");
		return 0;
                }
                else if (spade == 3 && diamond == 3 && club == 3 && heart == 4){
                printf("The bidding choice: 2NT\n");
		return 0;
                }
                else if (spade == 3 && heart == 3 && club == 3 && diamond == 4){
                printf("The bidding choice: 2NT\n");
		return 0;
                }
                else if (spade == 3 && heart == 3 && diamond == 3 && club == 4){
                printf("The bidding choice: 2NT\n");
		return 0;
                }
	}
	//1C
	if (HCP >= 16){
		printf("The bidding choice: 1C\n");
	return 0;
	}
	//1S, 1H
        if ( (HCP >= 11 && HCP <= 15) && spade >= 5 ){
        	if (spade == heart){
                	printf("The bidding choice: 1S\n");
			return 0;
		}
		printf("The bidding choice: 1S\n");
		return 0;
	}
	else if ( (HCP >= 11 && HCP <= 15) && heart >= 5){
		printf("The bidding choice: 1H\n");
        return 0;
	}
	//1NT
	if (HCP >= 13 && HCP <= 15 ){
		if (spade == 4 && heart == 3 && diamond == 3 && club == 3){
		printf("The bidding choice: 1NT\n");
		return 0;
		}
		else if (spade == 3 && diamond == 3 && club == 3 && heart == 4){
		printf("The bidding choice: 1NT\n");
		return 0;
		}
		else if (spade == 3 && heart == 3 && club == 3 && diamond == 4){
		printf("The bidding choice: 1NT\n");
		return 0;
		}
		else if (spade == 3 && heart == 3 && diamond == 3 && club == 4){
		printf("The bidding choice: 1NT\n");
		return 0;
		}
	}
	//1D
	if (HCP >= 11 && HCP <= 15 && diamond >= 4){
		printf("The bidding choice: 1D\n");
	return 0;
	}
	//2C
	if (HCP >= 11 && HCP <= 15 && club >= 6){
		printf("The bidding choice: 2C\n");
	return 0;
	}
	//2D
	if (HCP >= 11 && HCP <= 15 && club >= 5 && diamond == 0){
		printf("The bidding choice: 2D\n");
	return 0;
	}
	//2H, 2S
	if ( (HCP >= 8 && HCP <= 10) && (heart == 6 || spade == 6) ){
		if (heart == spade){
		printf("The bidding choice: 2S\n");
		}
		else if (spade == 6){
		printf("The bidding choice: 2S\n");
		}
		else if (heart == 6){
		printf("The bidding choice: 2H\n");
		}
	return 0;
	}
	//3C = 3D = 3H = 3S
	if (HCP >= 8 && HCP <= 11){
		if (club >= 7){
		printf("The bidding choice: 3C\n");
		}
		else if (diamond >= 7){
		printf("The bidding choice: 3D\n");
		}
		else if (heart >= 7){
		printf("The bidding choice: 3H\n");
		}
		else if (spade >= 7){
		printf("The bidding choice: 3S\n");
		}
	return 0;
	}
	//3NT
	if (HCP < 16 && ( spade == 7 || heart == 7)){
		if ( (a == 1 || b == 1 || c == 1 || d == 1 || e == 1 || f == 1 || g == 1 || h == 1 || i == 1 || j == 1 || k == 1 || l == 1 || m == 1 ) &&
		(a == 12 || b == 12 || c == 12 || d == 12 || e == 12 || f == 12 || g == 12 || h == 12 || i == 12 || j == 12 || k == 12 || l == 12 || m == 12 ) &&
		(a == 13 || b == 13 || c == 13 || d == 13 || e == 13 || f == 13 || g == 13 || h == 13 || i == 13 || j == 13 || k == 13 || l == 13 || m == 13 ) ){
		printf("The bidding choice: 3NT\n");
		}
		else if ( ( a == 14 || b == 14 || c == 14 || d == 14 || e == 14 || f == 14 || g == 14 || h == 14 || i == 14 || j == 14 || k == 14 || l == 14 || m == 14) &&
		( a == 26 || b == 26 || c == 26 || d == 26 || e == 26 || f == 26 || g == 26 || h == 26 || i == 26 || j == 26 || k == 26 || l == 26 || m == 26 ) &&
		( a == 25 || b == 25 || c == 25 || d == 25 || e == 25 || f == 25 || g == 25 || h == 25 || i == 25 || j == 25 || k == 25 || l == 25 || m == 25) ) {
		printf("The bidding choice: 3NT\n");
		}
	return 0;
	}
	//pass
	printf("The bidding choice: pass\n");
	return 0;
}
