#include <stdio.h>
#include <stdint.h>

int main()
{
	printf( "Please enter the sender addres       > ");
		int32_t local_part = 0;
		int32_t domain_part = 0;
		int count = 0;
		scanf("%*[a-z0-9A-Z]@%n", &count);
		scanf("csie.cool%n", &domain_part);
		scanf("csie.ntnu.edu.tw%n", &domain_part);
		scanf("ntnu.edu.tw%n", &domain_part);
		scanf("gapps.ntnu.edu.tw%n", &domain_part);
	printf("Please enter the email subject       > ");
		int32_t a = 0;
		int32_t b = 0;
		int32_t title = 0;
		int32_t category = 0;
		scanf("%*[^\n]");
		scanf("%*c");
		scanf("[");
		scanf("general]%n %*[a-z0-9A-Z]%n", &category, &title);
		scanf("hw %d ][p %d ] %*[a-z0-9A-Z]%n", &a, &b, &title);
	printf("Please enter the email content score > ");
		unsigned long long int score = 0;
		scanf("%*[^\n]");
		scanf("%*c");
		scanf("%lld", &score);
	printf("==============================================================\n");

	printf("\n");

	printf("Sender Address Test : ");
	//check email address
	if (count == 0){
		printf("Failed, please enter the correct email address\n");
	}
	else if (domain_part != 9 && domain_part != 11 && domain_part != 16 && domain_part != 17){
		//check domain part
		printf("Failed, domain in not authorized\n");
	}
	else{
		printf("Passed\n"); 
	}
	printf("Email Subject Test  : ");
	//check email subject
	if (count == 0 || (domain_part != 9 && domain_part != 11 && domain_part != 16 && domain_part != 17) ){
		printf("- \n");
	}
	else if (title == 0){
		if ( a == 0 && b == 0 && category != 8){
			printf("no category\n");
		}
		else{
			printf("Failed, title is empty\n");
		}
	}
	else if (category == 8 && title != 0 && a == 0 && b == 0){
		printf("Passed\n");
	}
	else if (a > 10 || b > 10 || a <= 0 || b <= 0){
		printf("Failed, please enter the correct number\n");
		printf("%d", title);
	}
	else if ( a == 0 && b == 0 && category != 8){
		printf("no category\n");
	}
	else if (a <= 10 && b <= 10 && title > 0){
		printf("Passed\n");
	}
	else{
		printf("- \n");
	}
	printf("Email Content Test  : ");
	//check content scores
	if (count == 0 || (domain_part != 9 && domain_part != 11 && domain_part != 16 && domain_part != 17) || (title == 0 && category != 8) || title == 0 || ( category == 0 && ( a > 10 || b > 10 || a <= 0 || b <= 0) ) ){
		printf("- \n");
	} 
	else if (score < 0 || score > 1000000000000000000){
		printf("out of range\n");
	}
	else if (score < title * 10000000000){
		printf("too low\n");
	}
	else{
		printf("Passed\n");
	}
	printf("--------------------------------------------------------------\n");

	printf("\n");

	//check the assignment
	if ( a == 0 && b == 0){
		if (category == 8){
			printf("Assigned to TA QB\n");
		}
		else{
			printf("Rejected\n");
		}
	}
	else if ( (score < 0 || score > 1000000000000000000) || (score < title * 10000000000) || (count == 0 || (domain_part != 9 && domain_part != 11 && domain_part != 16 && domain_part != 17) ) || ( category == 0 && (a > 10 || b > 10 || a <= 0 || b <= 0) ) ){
		printf("Rejected\n");
	}
	else if ( (a * b) % 5 == 0){
		printf("Assigned to Kaname Madoka\n");
	}
	else if ( ( a * b) % 5 == 1){
		printf("Assigned to Akemi Homura\n");
	}
	else if ( ( a * b ) % 5 == 2){
		printf("Assigned to Miki Sayaka\n");
	}
	else if ( ( a * b ) % 5 == 3){
		printf("Assigned to Tomoe Mami\n");
	}
	else if ( (a * b ) % 5 == 4){
		printf("Assigned to Sakura Kyoko\n");
	}
	else{
		printf("Rejected\n");
	}
	return 0;
}
