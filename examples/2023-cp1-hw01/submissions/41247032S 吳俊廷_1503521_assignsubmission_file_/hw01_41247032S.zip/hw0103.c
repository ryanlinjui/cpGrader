#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>


int main() {
    double x1, y1, x2, y2;
    printf("Please enter the point A (x,y): ");
    scanf("%lf,%lf", &x1, &y1);
    printf("Please enter the point B (x,y): ");
    scanf("%lf,%lf", &x2, &y2);

    if (x1 == x2 || y1 == y2) {
        printf("Error: The line is parallel to the axis\n");
        return -1;
    }

    double m=(y2-y1)/(x2-x1);
    double width = fabs((-y1+m*x1)/m);
    double height = fabs(-m*x1+y1);
    double area = width * height / 2;

    // printf("m: %.2f\n", m);
    // printf("width: %.2f\n", width);
    // printf("height: %.2f\n", height);
    // printf("area: %.2f\n", area);

    if(area==0){
        printf("Error: Area: 0\n");
        return -1;
    }else{
        printf("Area: %.2f\n", area);
    }
    

    return 0;
}