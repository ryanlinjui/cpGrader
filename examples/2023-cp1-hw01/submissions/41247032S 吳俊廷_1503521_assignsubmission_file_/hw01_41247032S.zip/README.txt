/*
                       _oo0oo_
                      o8888888o
                      88" . "88
                      (| -_- |)
                      0\  =  /0
                    ___/`---'\___
                  .' \\|     |//  '.
                 / \\|||  卍  |||// \
                / _||||| -:- |||||_ \
               |   | \\\  -  /// |   |
               | \_|  ''\---/''  |_/ |
               \  .-\__  '-'   __/-. /
             ___'. .'  /--.--\   '. .'___
          ."" '<  '.___\_<|>_/___.' >' "" .
         | | :  '- \'.;'\ _ /';.'/ - ' : | |
         \  \ '_.   \_ __\ /__ _/   .-' /  /
     ====='-.____'.___ \_____/___.-'___.-'=====
                        '=---='
     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                      阿彌陀佛保佑
                [ 願程式沒有Bug，一切順利 ]
*/

Name:吳俊廷
ID: 41247032S

## How to build the program?
Open the terminal and type "make" to build the program.

## How to execute your built programs?
Open the terminal and type "./<hw01YY>" to execute the program, which YY is the problem number.
For example, ./hw0102 is the executable program for homework #1 problem 2.

## About the solution to problem 1.6(Bonus): Makefile for Multiple files
It's simple to make b.c be built even a.c fails. Just add "-" to the command "gcc -c a.c" in the Makefile.
I have already done it in this homework's Makefile.

