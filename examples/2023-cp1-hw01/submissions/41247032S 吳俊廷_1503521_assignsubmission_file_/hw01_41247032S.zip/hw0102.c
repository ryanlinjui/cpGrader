#include <stdio.h>
#include <stdint.h>
int main(){
	float a_f=0;
	float b_f=0;
	int32_t a=0;
	int32_t b=0;
	int32_t a1=-1;
	int32_t a2=-1;
	int32_t b1=-1;
	int32_t b2=-1;
	int32_t max_length=-1;
	int32_t ans=-1;
	int32_t ans1=-1;
	int32_t ans2=-1;
	int32_t ans3=-1;
	int32_t ans4=-1;
	int32_t a_length=-1;
	int32_t b_length=-1;
	int32_t ans_length=-1;
	int32_t dash_counter=0;

	printf("Please enter the first  number: ");
	scanf("%f",&a_f);

	if(a_f>99||a_f<0||a_f!=(int)a_f){
		printf("Wrong input, your input must between 0 ~ 99.\n");
		return 0;
	}

	printf("Please enter the second number: ");
	scanf("%f",&b_f);

	if(b_f>99||b_f<0||b_f!=(int)b_f){
		printf("Wrong input, your input must between 0 ~ 99.\n");
		return 0;
	}
	
	//start caaulate
	b=(int)b_f;
	a=(int)a_f;
	ans=a*b;
	
	a1=a/10;
	a2=a%10;
	b1=b/10;
	b2=b%10;
	ans1=ans/1000;
	ans2=ans/100-10*ans1;
	ans3=ans/10-10*(ans/100);
	ans4=ans%10;

	//check number length
	if(a1==0){
		a_length=1;
	}else{
		a_length=2;
	}

	if(b1==0){
		b_length=1;
	}else{
		b_length=2;
	}

	if(ans1!=0){
		ans_length=4;
	}else if(ans1==0&&ans2!=0){
		ans_length=3;
	}else if(ans1==0&&ans2==0&&ans3!=0){
		ans_length=2;
	}else{
		ans_length=1;
	}
	//printf("DEBUG=%d\n",ans_length);
	//max_length=max(a_length,b_length,ans_length);	
	if(a_length>b_length){
		max_length=a_length;
	}else{
		max_length=b_length;
	}

	if(ans_length>max_length){
		max_length=ans_length;
	}
	
	// printf("Debug: length=%d %d %d\n",a_length,b_length,ans_length);
	// printf("max_length=%d\n",max_length);
	// printf("%d %d\n",a1,a2);
	// printf("%d %d\n",b1,b2);
	// printf("%d %d %d %d\n",ans1,ans2,ans3,ans4);

	//output result
	int32_t diff=max_length-a_length;
	if(diff==3){
		printf("        ");
	}else if(diff==2){
		printf("      ");
	}else if(diff==1){
		printf("    ");
	}else{
		printf("  ");
	}
	
	if(a_length==2){
		printf("%d %d\n",a1,a2);
	}else{
		printf("%d\n",a2);
	}

	//output:line2
	printf("*)");
	diff=max_length-b_length;
	if(diff==3){
		printf("      ");
	}else if(diff==2){
		printf("    ");
	}else if(diff==1){
		printf("  ");
	}

	if(b_length==2){
		printf("%d %d\n",b1,b2);
	}else{
		printf("%d\n",b2);
	}
	
	//output:line3
	if(max_length==4){
		dash_counter=9;
		printf("---------\n");
	}else if(max_length==3){
		dash_counter=7;
		printf("-------\n");
	}else if(max_length==2){
		dash_counter=5;
		printf("-----\n");
	}else{
		dash_counter=3;
		printf("---\n");
	}

	//caculate layer1
	int32_t ans_layer1=a*b2;
	int32_t ans_layer1_1=ans_layer1/100;
	int32_t ans_layer1_2=ans_layer1/10-ans_layer1/100*10;
	int32_t ans_layer1_3=ans_layer1%10;
	int32_t ans_layer1_length;
	if(ans_layer1_1!=0){
		ans_layer1_length=3;
	}else if(ans_layer1_1==0&&ans_layer1_2!=0){
		ans_layer1_length=2;
	}else{
		ans_layer1_length=1;
	}
	//printf("%d %d %d\n",ans_layer1_1,ans_layer1_2,ans_layer1_3);

	//caculate layer2
	int32_t ans_layer2=a*b1;
	int32_t ans_layer2_1=ans_layer2/100;
	int32_t ans_layer2_2=ans_layer2/10-ans_layer2/100*10;
	int32_t ans_layer2_3=ans_layer2%10;
	int32_t ans_layer2_length;
	if(ans_layer2_1!=0){
		ans_layer2_length=3;
	}else if(ans_layer2_1==0&&ans_layer2_2!=0){
		ans_layer2_length=2;
	}else{
		ans_layer2_length=1;
	}
	//printf("DEBUG:%d %d %d\n",ans_layer2_1,ans_layer2_2,ans_layer2_3);

	//output layer1
	diff=dash_counter-ans_layer1_length*2;
	//printf("diff=%d\n",diff);
	if(diff==1){
		printf(" ");
	}else if(diff==2){
		printf("  ");
	}else if(diff==3){
		printf("   ");
	}else if(diff==4){
		printf("    ");
	}else if(diff==5){
		printf("     ");
	}else if(diff==6){
		printf("      ");
	}else if(diff==7){
		printf("       ");
	}else if(diff==8){
		printf("        ");
	}else if(diff==9){
		printf("         ");
	}else if(diff==10){
		printf("          ");
	}
	if(ans_layer1_length==1){
		printf(" %d",ans_layer1_3);
	}else if(ans_layer1_length==2){
		printf(" %d %d",ans_layer1_2,ans_layer1_3);
	}else{
		printf(" %d %d %d",ans_layer1_1,ans_layer1_2,ans_layer1_3);
	}
	printf("\n");

	//ouput layer2
	if(ans_layer2==0){
		return 0;
	}

	diff=dash_counter-ans_layer2_length*2;
	//printf("DEBUG:diff=%d\n",diff);
	if(diff==3){
		printf(" ");
	}else if(diff==4){
		printf("  ");
	}else if(diff==5){
		printf("   ");
	}else if(diff==6){
		printf("    ");
	}else if(diff==7){
		printf("     ");
	}else if(diff==8){
		printf("      ");
	}else if(diff==9){
		printf("       ");
	}else if(diff==10){
		printf("        ");
	}
	if(ans_layer2_length==1){
		printf(" %d  ",ans_layer2_3);
	}else if(ans_layer2_length==2){
		printf(" %d %d  ",ans_layer2_2,ans_layer2_3);
	}else{
		printf(" %d %d %d  ",ans_layer2_1,ans_layer2_2,ans_layer2_3);
	}
	printf("\n");

	//output final line
	if(max_length==4){
		dash_counter=9;
		printf("---------\n");
	}else if(max_length==3){
		dash_counter=7;
		printf("-------\n");
	}else if(max_length==2){
		dash_counter=5;
		printf("-----\n");
	}else{
		dash_counter=3;
		printf("---\n");
	}

	//output final_ans
	diff=dash_counter-ans_length*2;
	//printf("diff=%d\n",diff);
	if(diff==1){
		printf(" ");
	}else if(diff==2){
		printf("  ");
	}else if(diff==3){
		printf("   ");
	}else if(diff==4){
		printf("    ");
	}else if(diff==5){
		printf("     ");
	}else if(diff==6){
		printf("      ");
	}else if(diff==7){
		printf("       ");
	}else if(diff==8){
		printf("        ");
	}else if(diff==9){
		printf("         ");
	}else if(diff==10){
		printf("          ");
	}
	if(ans_length==1){
		printf(" %d",ans4);
	}else if(ans_length==2){
		printf(" %d %d",ans3,ans4);
	}else if(ans_length==3){
		printf(" %d %d %d",ans2,ans3,ans4);
	}else{
		printf(" %d %d %d %d",ans1,ans2,ans3,ans4);
	}
	printf("\n");
	return 0;
}
