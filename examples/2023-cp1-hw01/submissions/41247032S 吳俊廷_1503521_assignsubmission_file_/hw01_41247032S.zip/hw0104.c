#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

int32_t first,second,third,fourth,fifth,sixth,seventh,eighth,ninth,tenth,eleventh,twelfth,thirteenth;
int32_t spade=0,heart=0,diamond=0,club=0;

int32_t spade_A=0;
int32_t spade_Q=0;
int32_t spade_K=0;

int32_t heart_A=0;
int32_t heart_Q=0;
int32_t heart_K=0;

int32_t hcp=0;
int32_t balanced_hand=0;//0->not balanced,1->balanced

void checke_valid(int32_t card){
    if(card<1||card>52){
        printf("Error, the number is not a valid card.\n");
        exit(0);
    }
}

void suit_counter(int32_t card){
    if(card>=1&&card<=13){
        spade++;
    }
    else if(card>=14&&card<=26){
        heart++;
    }
    else if(card>=27&&card<=39){
        diamond++;
    }
    else if(card>=40&&card<=52){
        club++;
    }
    if(card==1){
        spade_A=1;
    }else if(card==12){
        spade_Q=1;
    }else if(card==13){
        spade_K=1;
    }else if(card==14){
        heart_A=1;
    }else if(card==25){
        heart_Q=1;
    }else if(card==26){
        heart_K=1;
    }
}

void balance_hand_checker(){
    if(spade==4&&heart==3&&diamond==3&&club==3){
        balanced_hand=1;
    }else if(spade==3&&heart==4&&diamond==3&&club==3){
        balanced_hand=1;
    }else if(spade==3&&heart==3&&diamond==4&&club==3){
        balanced_hand=1;
    }else if(spade==3&&heart==3&&diamond==3&&club==4){
        balanced_hand=1;
    }else{
        balanced_hand=0;
    }
}

void count_hcp(int32_t card){
    //printf("card: %d\n",card);
    if(card==1||card==14||card==27||card==40){
        hcp+=4;
    }
    else if(card==13||card==26||card==39||card==52){
        hcp+=3;
    }
    else if(card==12||card==25||card==38||card==51){
        hcp+=2;
    }
    else if(card==11||card==24||card==37||card==50){
        hcp+=1;
    }
}
int main(){
    //input
    printf("1st card: ");
    scanf("%d",&first);
    checke_valid(first);
    suit_counter(first);
    

    printf("2nd card: ");
    scanf("%d",&second);
    checke_valid(second);
    suit_counter(second);

    printf("3rd card: ");
    scanf("%d",&third);
    checke_valid(third);
    suit_counter(third);

    printf("4th card: ");
    scanf("%d",&fourth);
    checke_valid(fourth);
    suit_counter(fourth);

    printf("5th card: ");
    scanf("%d",&fifth);
    checke_valid(fifth);
    suit_counter(fifth);

    printf("6th card: ");
    scanf("%d",&sixth);
    checke_valid(sixth);
    suit_counter(sixth);

    printf("7th card: ");
    scanf("%d",&seventh);
    checke_valid(seventh);
    suit_counter(seventh);

    printf("8th card: ");
    scanf("%d",&eighth);
    checke_valid(eighth);
    suit_counter(eighth);

    printf("9th card: ");
    scanf("%d",&ninth);
    checke_valid(ninth);
    suit_counter(ninth);

    printf("10th card: ");
    scanf("%d",&tenth);
    checke_valid(tenth);
    suit_counter(tenth);

    printf("11th card: ");
    scanf("%d",&eleventh);
    checke_valid(eleventh);
    suit_counter(eleventh);

    printf("12th card: ");
    scanf("%d",&twelfth);
    checke_valid(twelfth);
    suit_counter(twelfth);

    printf("13th card: ");
    scanf("%d",&thirteenth);
    checke_valid(thirteenth);
    suit_counter(thirteenth);

    //count hcp
    count_hcp(first);
    count_hcp(second);
    count_hcp(third);
    count_hcp(fourth);
    count_hcp(fifth);
    count_hcp(sixth);
    count_hcp(seventh);
    count_hcp(eighth);
    count_hcp(ninth);
    count_hcp(tenth);
    count_hcp(eleventh);
    count_hcp(twelfth);
    count_hcp(thirteenth);
  
    balance_hand_checker();

    //print result
    printf("---\n");
    printf("HCP: %d pts\n",hcp);
    printf("Suit: %d-%d-%d-%d\n",spade,heart,diamond,club);
    printf("The bidding choice : ");

    //biding
    if(hcp>=11&&hcp<=15&&(spade>=5||heart>=5)){
        if(spade==heart){
            printf("1S\n");
        }else if(spade>heart){
            printf("1S\n");
        }else{
            printf("1H\n");
        }
    }else if(13<=hcp&&hcp<=15&&balanced_hand==1){
        printf("1NT\n");
    }else if(22<=hcp&&hcp<=24&&balanced_hand==1){
        printf("2NT\n");
    }else if(hcp>=16){
        printf("1C\n");
    }else if(hcp>=11&&hcp<=15&&diamond>=4){
        printf("1D\n");
    }else if(hcp>=11&&hcp<=15&&club>=6){
        printf("2C\n");
    }else if(hcp>=11&&hcp<=15&&club>=5&&diamond==0){
        printf("2D\n");
    }else if(hcp>=8&&hcp<=10&&spade==6){
        printf("2S\n");
    }else if(hcp>=8&&hcp<=10&&heart==6){
        printf("2H\n");
    }else if(hcp>=8&&hcp<=11&&club==7){
        printf("3C\n");
    }else if(hcp>=8&&hcp<=11&&diamond==7){
        printf("3D\n");
    }else if(hcp>=8&&hcp<=11&&heart==7){
        printf("3H\n");
    }else if(hcp>=8&&hcp<=11&&spade==7){
        printf("3S\n");
    }else if(hcp<16&&((spade==7&&spade_A==1&&spade_K==1&&spade_Q==1)||(heart==7&&heart_A==1&&heart_K==1&&heart_Q==1))){
        printf("3NT\n");
    }else{
        printf("Pass\n");
    }
    return 0;
}