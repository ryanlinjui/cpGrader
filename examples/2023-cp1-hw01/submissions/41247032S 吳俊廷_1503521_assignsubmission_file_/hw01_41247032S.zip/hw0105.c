#include <stdio.h>
#include <stdint.h>
int main(){
    int32_t readed=-1;//-1->local_error

    int32_t title_type=-1;//-1->uncheck 1->[general]

    char sender_domain_checker='0';//0->uncheck,1->local-part is invalid,2->domain error,3->success
    char title_general_checker='0';
    int32_t problem_number_checker=-1;
    int32_t problem_id=-1;
    int32_t C;

    int32_t sender_test_result=0;//0->uncheck,1->local-part is invalid,2->domain error,3->success

    int32_t title_counter=0;
    unsigned long long content_test_value=0;
    unsigned long long target=1e19;
    int32_t content_digits=-1;
    int32_t equal_to_1e9=0;
    int32_t general_judge=0;

    int32_t sender_test_failed=0;
    int32_t title_test_failed=0;
    int32_t email_counter_test_failed=0;
    int32_t content_test_result=0;//0->uncheck,1->out of range,2->too low,3->success


    printf("Please enter the sender address \t > ");
    scanf("%*[a-z-A-Z-0-9]@%n", &readed);

    /*Input & Check Domain*/
    scanf("csie.cool%c",&sender_domain_checker);
    if(sender_domain_checker!='\n'){
        scanf("csie.ntnu.edu.tw%c",&sender_domain_checker);
    }

    if(sender_domain_checker!='\n'){
        scanf("gapps.ntnu.edu.tw%c",&sender_domain_checker);
    }

    if(sender_domain_checker!='\n'){
        scanf("ntnu.edu.tw%c",&sender_domain_checker);
    }

    //printf("domain checker:%d\n",sender_domain_checker);
    if(sender_domain_checker=='0'){
        sender_test_result=2;
    }else if(sender_domain_checker==10){
        sender_test_result=3;
    }
    if(readed==-1){
        sender_test_result=1;
    }
    if(sender_test_result!=3){
        scanf("%*[^\n]");
        scanf("%*c"); // read and discard the newline character
    }
    
    //scanf("%*c"); // read and discard the newline character
    // printf("readed:%d senderdomain:%d\n",readed,sender_domain_checker);
    //printf("readed:%d domain test:%d trash:%d\n",readed,sender_test_result,trash);
    
    printf("Please enter the email subject \t\t > ");

    scanf("[general]%n%*[^\n]%n%c",&general_judge,&title_counter,&title_general_checker);
    // printf("title_counter:%d\n",title_counter);
    // printf("title_general_checker:%d: [%c]",title_general_checker,title_general_checker);
    // printf("general_judge:%d\n",general_judge);

    // scanf("%s",debug_the_rest);
    // for(int i=0;i<20;i++){
    //     printf(" %c",debug_the_rest[i]);
    // }
    
    if(title_general_checker=='\n'){
        //printf("yes\n");
	    title_type=1;
    }else{
        //printf("in\n");
        // scanf("%s",debug_the_rest);
        // for(int i=0;i<20;i++){
        //     printf("%c",debug_the_rest[i]);
        // }
        //printf("\n");
        scanf("hw%d][p%d]",&problem_number_checker,&problem_id);
        //printf("problem_number_checker:%d\n",problem_number_checker);
        
    }
    if(general_judge==9){
        title_type=1;
    }
    // printf("title_counter:%d\n",title_counter-10);
    // printf("title_general_checker:%d: [%c]",title_general_checker,title_general_checker);
    // printf("title_type:%d\n",title_type);
    // printf("general_judge:%d\n",general_judge);
    // printf("problem_number_checker:%d problem_id:%d\n",problem_number_checker,problem_id);
    
    if(title_type!=1){
        //printf("title_type!=1\n");
        scanf("%*[^\n]");
        scanf("%*c"); // read and discard the newline character
    }

    printf("Please enter the email content score \t > ");

    //scanf("%n%lld",&content_digits,&content_test_value);
    scanf("%llu%n",&content_test_value,&content_digits);
    //printf("content_digits:%d\n",content_digits);
    //printf("content_test_value:%llu\n",content_test_value);

    
    if(content_test_value<0||content_test_value>1e19){
        content_test_result=1;
    }else if(content_test_value<(title_counter-10)*1e10){
        content_test_result=2;
    }else{
        content_test_result=3;
    }

    if(content_digits>19){
        content_test_result=1;
    }

    if(content_test_value==target){
        if(content_test_value<(title_counter-10)*1e10){
            content_test_result=2;
        }else{
            content_test_result=3;
        }
    }
    //printf("content_test_result:%d\n",content_test_result);
    printf("================================================================================\n");

    //
    printf("Sender Address Test : ");
    if(sender_test_result==1){
        printf("Failed , local-part is invalid\n");
        sender_test_failed=1;
    }else if(sender_test_result==2){
        printf("Failed , domain is not authorized\n");
        sender_test_failed=1;
    }else if(sender_test_result==3){
        printf("Passed\n");
    }else{
        printf("ERROR...\n");
    }

    printf("Email Subject Test  : ");
    if(sender_test_failed==0){
        if(title_type==1){
            if(title_counter-10<=0){
                printf("Failed , title is empty\n");
                title_test_failed=1;
            }else{
                printf("Passed\n");
            }
        }else if(problem_number_checker==-1||problem_number_checker<1||problem_id<1||problem_id>9||problem_number_checker>9){
            printf("Failed , no category\n");
            title_test_failed=1;
        }else{
            printf("Passed\n");
        }
    }else{
        title_test_failed=1;
        printf(" -\n");
    }
    
    printf("Email Content Test  : ");
    if(sender_test_failed==0&&title_test_failed==0){
        if(content_test_result==1){
            printf("Failed , out of range\n");
            email_counter_test_failed=1;
        }else if(content_test_result==2){
            printf("Failed , too low\n");
            email_counter_test_failed=1;
        }else{
            printf("Passed\n");
        }
    }else{
        email_counter_test_failed=1;
        printf(" -\n");
    }
    printf("--------------------------------------------------------------------------------\n");
    if(sender_test_failed==1||title_test_failed==1||email_counter_test_failed==1){
        printf("Rejected\n");
    }else{
        printf("Assigned to ");
        C=(problem_number_checker*problem_id)%5;
        // printf("C=%d\n",C);
        if(title_type==1){
            C=5;
        }
        if(C==0){
            printf("Kaname Madoka\n");
        }else if(C==1){
            printf("Akemi Homura\n");
        }else if(C==2){
            printf("Miki Sayaka\n");
        }else if(C==3){
            printf("Tomoe Mami\n");
        }else if(C==4){
            printf("Sakura Kyoko\n");
        }else{
            printf("TA QB\n");
        }
    }
    return 0;
}
