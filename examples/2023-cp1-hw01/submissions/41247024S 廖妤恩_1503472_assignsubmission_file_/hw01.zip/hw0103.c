#include<stdio.h>
#include<stdint.h>

int main()
{
    int32_t x1=0;
    int32_t x2=0;
    float x3=0;
    int32_t y1=0;
    int32_t y2=0;
    float y3=0;
    
    //x
    float a=0;
    //y
    float b=0;
    float m=0;
    double c=0;
    
    //input
    printf("Please enter the point A (x,y):\n");
    scanf("%d, %d", &x1, &y1);
    
    printf("Please enter the point B (x,y):\n");
    scanf("%d, %d", &x2, &y2);
    
    //calculate m
    x3 = x1-x2;
    y3 = y1-y2;
    
    //check whether x3 or y3 = 0
    if ( x3 ==0 || y3 == 0 )
    {
        printf("Area: 0\n");
        
        return 0;
    }
    m = y3/x3;
    
    //calculate b
    b = y1-m*x1;
    
    //check whether it pass origin
    if ( b == 0 )
    {
        printf("Area: 0\n");
        return 0;
    }
    
    //calculate a
    a = -b/m;
    
    //set number
    if ( a<0 )
    {
        a = -a;
    }
    if ( b<0 )
    {
        b = -b;
    }
    
    //calculate area
    c = (a*b)/2;
    printf("Area: %.2f\n", c);

            
}