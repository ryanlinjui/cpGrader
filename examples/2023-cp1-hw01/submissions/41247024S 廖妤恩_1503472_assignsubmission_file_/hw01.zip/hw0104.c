#include<stdio.h>
#include<stdint.h>

int main()
{
    //set up
    int32_t x1 = 0;
    int32_t x2 = 0;
    int32_t x3 = 0;
    int32_t x4 = 0;
    int32_t x5 = 0;
    int32_t x6 = 0;
    int32_t x7 = 0;
    int32_t x8 = 0;
    int32_t x9 = 0;
    int32_t x10 = 0;
    int32_t x11 = 0;
    int32_t x12 = 0;
    int32_t x13 = 0;
    
    //shdc
    int32_t S = 0;
    int32_t H = 0;
    int32_t D = 0;
    int32_t C = 0;
    
    //HCP
    int32_t HCP = 0;
    
    //input
    printf("1st card:");
    scanf(" %d", &x1);
    printf("2nd card:");
    scanf(" %d", &x2);
    printf("3rd card:");
    scanf(" %d", &x3);
    printf("4th card:");
    scanf(" %d", &x4);
    printf("5th card:");
    scanf(" %d", &x5);
    printf("6th card:");
    scanf(" %d", &x6);
    printf("7th card:");
    scanf(" %d", &x7);
    printf("8th card:");
    scanf(" %d", &x8);
    printf("9th card:");
    scanf(" %d", &x9);
    printf("10th card:");
    scanf(" %d", &x10);
    printf("11th card:");
    scanf(" %d", &x11);
    printf("12th card:");
    scanf(" %d", &x12);
    printf("13th card:");
    scanf(" %d", &x13);
    
    //check range
    if ( x1<1 || x1>52 || x2<1 || x2>52 || x3<1 || x3>52 || x4<1 || x4>52 || x5<1 || x5>52 || x6<1 || x6>52 || x7<1 || x7>52 || x8<1 || x8>52 || x9<1 || x9>52 || x10<1 || x10>52 || x11<1 || x11>52 || x12<1 || x12>52 || x13<1 || x13>52 )
    {
        printf("Your input must between 1~52.\n");
        return 0;
    }
    
    //avoid idiot
    if ( x1==x2 || x1==x3 || x1==x4 || x1==x5 || x1==x6 || x1==x7 || x1==x8 || x1==x9 || x1==x10 || x1==x11 || x1==x12 || x1==x13 )
    {
        printf("You can't input same values, please input again.\n");
        return 0;
    }
    
    if ( x2==x3 || x2==x4 || x2==x5 || x2==x6 || x2==x7 || x2==x8 || x2==x9 || x2==x10 || x2==x11 || x2==x12 || x2==x13 )
    {
        printf("You can't input same values, please input again.\n");
        return 0;
    }
    
    if ( x3==x4 || x3==x5 || x3==x6 || x3==x7 || x3==x8 || x3==x9 || x3==x10 || x3==x11 || x3==x12 || x3==x13 )
    {
        printf("You can't input same values, please input again.\n");
        return 0;
    }
    
    if ( x4==x5 || x4==x6 || x4==x7 || x4==x8 || x4==x9 || x4==x10 || x4==x11 || x4==x12 || x4==x13 )
    {
        printf("You can't input same values, please input again.\n");
        return 0;
    }
    
    if ( x5==x6 || x5==x7 || x5==x8 || x5==x9 || x5==x10 || x5==x11 || x5==x12 || x5==x13 )
    {
        printf("You can't input same values, please input again.\n");
        return 0;
    }
    
    if ( x6==x7 || x6==x8 || x6==x9 || x6==x10 || x6==x11 || x6==x12 || x6==x13 )
    {
        printf("You can't input same values, please input again.\n");
        return 0;
    }
    
    if ( x7==x8 || x7==x9 || x7==x10 || x7==x11 || x7==x12 || x7==x13 )
    {
        printf("You can't input same values, please input again.\n");
        return 0;
    }
    
    if ( x8==x9 || x8==x10 || x8==x11 || x8==x12 || x8==x13 )
    {
        printf("You can't input same values, please input again.\n");
        return 0;
    }
    
    if ( x9==x10 || x9==x11 || x9==x12 || x9==x13 )
    {
        printf("You can't input same values, please input again.\n");
        return 0;
    }
    
    if ( x10==x11 || x10==x12 || x10==x13 )
    {
        printf("You can't input same values, please input again.\n");
        return 0;
    }
    
    if ( x11==x12 || x11==x13 )
    {
        printf("You can't input same values, please input again.\n");
        return 0;
    }
    
    if ( x12==x13 )
    {
        printf("You can't input same values, please input again.\n");
        return 0;
    }
            
    //calculate
    if ( x1%13 == 1 )
    {
        HCP = HCP+4;
    }
    else if ( x1%13 == 0 )
    {
        HCP = HCP+3;
    }
    else if ( x1%13 == 12 )
    {
        HCP = HCP+2;
    }
    else if ( x1%13 == 11 )
    {
        HCP = HCP+1;
    }
    else 
    {
        HCP = HCP;
    }
    
    if ( x2%13 == 1 )
    {
        HCP = HCP+4;
    }
    else if ( x2%13 == 0 )
    {
        HCP = HCP+3;
    }
    else if ( x2%13 == 12 )
    {
        HCP = HCP+2;
    }
    else if ( x2%13 == 11 )
    {
        HCP = HCP+1;
    }
    else 
    {
        HCP = HCP;
    }
    
    if ( x3%13 == 1 )
    {
        HCP = HCP+4;
    }
    else if ( x3%13 == 0 )
    {
        HCP = HCP+3;
    }
    else if ( x3%13 == 12 )
    {
        HCP = HCP+2;
    }
    else if ( x3%13 == 11 )
    {
        HCP = HCP+1;
    }
    else 
    {
        HCP = HCP;
    }
    
    if ( x4%13 == 1 )
    {
        HCP = HCP+4;
    }
    else if ( x4%13 == 0 )
    {
        HCP = HCP+3;
    }
    else if ( x4%13 == 12 )
    {
        HCP = HCP+2;
    }
    else if ( x4%13 == 11 )
    {
        HCP = HCP+1;
    }
    else 
    {
        HCP = HCP;
    }
    
    if ( x5%13 == 1 )
    {
        HCP = HCP+4;
    }
    else if ( x5%13 == 0 )
    {
        HCP = HCP+3;
    }
    else if ( x5%13 == 12 )
    {
        HCP = HCP+2;
    }
    else if ( x5%13 == 11 )
    {
        HCP = HCP+1;
    }
    else 
    {
        HCP = HCP;
    }
    
    if ( x6%13 == 1 )
    {
        HCP = HCP+4;
    }
    else if ( x6%13 == 0 )
    {
        HCP = HCP+3;
    }
    else if ( x6%13 == 12 )
    {
        HCP = HCP+2;
    }
    else if ( x6%13 == 11 )
    {
        HCP = HCP+1;
    }
    else 
    {
        HCP = HCP;
    }
    
    if ( x7%13 == 1 )
    {
        HCP = HCP+4;
    }
    else if ( x7%13 == 0 )
    {
        HCP = HCP+3;
    }
    else if ( x7%13 == 12 )
    {
        HCP = HCP+2;
    }
    else if ( x7%13 == 11 )
    {
        HCP = HCP+1;
    }
    else 
    {
        HCP = HCP;
    }
    
    if ( x8%13 == 1 )
    {
        HCP = HCP+4;
    }
    else if ( x8%13 == 0 )
    {
        HCP = HCP+3;
    }
    else if ( x8%13 == 12 )
    {
        HCP = HCP+2;
    }
    else if ( x8%13 == 11 )
    {
        HCP = HCP+1;
    }
    else 
    {
        HCP = HCP;
    }
    
    if ( x9%13 == 1 )
    {
        HCP = HCP+4;
    }
    else if ( x9%13 == 0 )
    {
        HCP = HCP+3;
    }
    else if ( x9%13 == 12 )
    {
        HCP = HCP+2;
    }
    else if ( x9%13 == 11 )
    {
        HCP = HCP+1;
    }
    else 
    {
        HCP = HCP;
    }
    
    if ( x10%13 == 1 )
    {
        HCP = HCP+4;
    }
    else if ( x10%13 == 0 )
    {
        HCP = HCP+3;
    }
    else if ( x10%13 == 12 )
    {
        HCP = HCP+2;
    }
    else if ( x10%13 == 11 )
    {
        HCP = HCP+1;
    }
    else 
    {
        HCP = HCP;
    }
    
    if ( x11%13 == 1 )
    {
        HCP = HCP+4;
    }
    else if ( x11%13 == 0 )
    {
        HCP = HCP+3;
    }
    else if ( x11%13 == 12 )
    {
        HCP = HCP+2;
    }
    else if ( x11%13 == 11 )
    {
        HCP = HCP+1;
    }
    else 
    {
        HCP = HCP;
    }
    
    if ( x12%13 == 1 )
    {
        HCP = HCP+4;
    }
    else if ( x12%13 == 0 )
    {
        HCP = HCP+3;
    }
    else if ( x12%13 == 12 )
    {
        HCP = HCP+2;
    }
    else if ( x12%13 == 11 )
    {
        HCP = HCP+1;
    }
    else 
    {
        HCP = HCP;
    }
    
    if ( x13%13 == 1 )
    {
        HCP = HCP+4;
    }
    else if ( x13%13 == 0 )
    {
        HCP = HCP+3;
    }
    else if ( x13%13 == 12 )
    {
        HCP = HCP+2;
    }
    else if ( x13%13 == 11 )
    {
        HCP = HCP+1;
    }
    else 
    {
        HCP = HCP;
    }
    
    //print
    printf("-------\n");
    printf("HCP: %d pts\n", HCP);
    
    //suit
    if ( x1 <= 13 )
    {
        S = S+1;
    }
    else if ( x1 <= 26 )
    {
        H = H+1;
    }
    else if ( x1 <= 39 )
    {
        D = D+1;
    }
    else
    {
        C = C+1;
    }
    
    if ( x2 <= 13 )
    {
        S = S+1;
    }
    else if ( x2 <= 26 )
    {
        H = H+1;
    }
    else if ( x2 <= 39 )
    {
        D = D+1;
    }
    else
    {
        C = C+1;
    }

    if ( x3 <= 13 )
    {
        S = S+1;
    }
    else if ( x3 <= 26 )
    {
        H = H+1;
    }
    else if ( x3 <= 39 )
    {
        D = D+1;
    }
    else
    {
        C = C+1;
    }
    
    if ( x4 <= 13 )
    {
        S = S+1;
    }
    else if ( x4 <= 26 )
    {
        H = H+1;
    }
    else if ( x4 <= 39 )
    {
        D = D+1;
    }
    else
    {
        C = C+1;
    }
    
    if ( x5 <= 13 )
    {
        S = S+1;
    }
    else if ( x5 <= 26 )
    {
        H = H+1;
    }
    else if ( x5 <= 39 )
    {
        D = D+1;
    }
    else
    {
        C = C+1;
    }
    
    if ( x6 <= 13 )
    {
        S = S+1;
    }
    else if ( x6 <= 26 )
    {
        H = H+1;
    }
    else if ( x6 <= 39 )
    {
        D = D+1;
    }
    else
    {
        C = C+1;
    }
    
    if ( x7 <= 13 )
    {
        S = S+1;
    }
    else if ( x7 <= 26 )
    {
        H = H+1;
    }
    else if ( x7 <= 39 )
    {
        D = D+1;
    }
    else
    {
        C = C+1;
    }
    
    if ( x8 <= 13 )
    {
        S = S+1;
    }
    else if ( x8 <= 26 )
    {
        H = H+1;
    }
    else if ( x8 <= 39 )
    {
        D = D+1;
    }
    else
    {
        C = C+1;
    }
    
    if ( x9 <= 13 )
    {
        S = S+1;
    }
    else if ( x9 <= 26 )
    {
        H = H+1;
    }
    else if ( x9 <= 39 )
    {
        D = D+1;
    }
    else
    {
        C = C+1;
    }
    
    if ( x10 <= 13 )
    {
        S = S+1;
    }
    else if ( x10 <= 26 )
    {
        H = H+1;
    }
    else if ( x10 <= 39 )
    {
        D = D+1;
    }
    else
    {
        C = C+1;
    }
    
    if ( x11 <= 13 )
    {
        S = S+1;
    }
    else if ( x11 <= 26 )
    {
        H = H+1;
    }
    else if ( x11 <= 39 )
    {
        D = D+1;
    }
    else
    {
        C = C+1;
    }
    
    if ( x12 <= 13 )
    {
        S = S+1;
    }
    else if ( x12 <= 26 )
    {
        H = H+1;
    }
    else if ( x12 <= 39 )
    {
        D = D+1;
    }
    else
    {
        C = C+1;
    }
    
    if ( x13 <= 13 )
    {
        S = S+1;
    }
    else if ( x13 <= 26 )
    {
        H = H+1;
    }
    else if ( x13 <= 39 )
    {
        D = D+1;
    }
    else
    {
        C = C+1;
    }
    
    //print
    printf("Suit: %d-%d-%d-%d\n", S, H, D, C);
    
     //2NT
    if ( HCP>=22 && HCP<=24 ) 
    {
    	if  ( S == 4 && H == 3 && D == 3 && C==3 )
        {
            printf ("The bidding choice : 2NT\n");
            return 0;
        }
        if  ( S == 3 && H == 4 && D == 3 && C==3 )
        {
            printf ("The bidding choice : 2NT\n");
            return 0;
        }
        if  ( S == 3 && H == 3 && D == 4 && C==3 )
        {
            printf ("The bidding choice : 2NT\n");
            return 0;
        }
        if  ( S == 3 && H == 3 && D == 3 && C==4 )
        {
            printf ("The bidding choice : 2NT\n");
            return 0;
        } 
        else 
        {
            printf ("The bidding choice : 1C\n");
            return 0;
        }
    }
    //1C
    else if ( HCP >= 16 )
    {
    	printf ("The bidding choice : 1C\n");
        return 0;
    }
    //1S or 1H
    else if ( ( HCP>=11 && HCP<=15 ) && (( S>=5 ) || ( H>=5 )) )
    {
    	if ( S>=H )
    	{
    	    printf ("The bidding choice : 1S\n");
    	    return 0;
    	}
    	else 
    	{
    	    printf ("The bidding choice : 1H\n");
            return 0;
    	}   
    }
    //1NT
    else if ( ( HCP>=13 && HCP<=15 ) &&
        (( S == 4 && H == 3 && D == 3 && C==3 ) ||
        ( S == 3 && H == 4 && D == 3 && C==3 ) ||
        ( S == 3 && H == 3 && D == 4 && C==3 ) ||
        ( S == 3 && H == 3 && D == 3 && C==4 ) )
         )
    {
        printf ("The bidding choice : 1NT\n");
        return 0;
    }
    //1D
    else if ( ( HCP>=11 && HCP<=15 ) && ( D>=4 ) ) 
    {
    	printf ("The bidding choice : 1D\n");
        return 0;
    }
    //2C
    else if ( ( HCP>=11 && HCP<=15 ) && ( C>=6 ) )
    {
    	printf ("The bidding choice : 2C\n");
        return 0;
    }
    //2D
    else if ( ( HCP>=11 && HCP<=15 ) && ( C>=5 ) && ( D==0) )
    {
        printf ("The bidding choice : 2D\n");
        return 0;
    }
    //2H 2S
    else if ( ( HCP>=8 && HCP<=10 ) && ( (H==6) || (S==6) ) )
    {
       if ( H==S )
        {
            printf ("The bidding choice : 2S\n");
            return 0;
        }
        else if ( H==6 ) 
        {
            printf ("The bidding choice : 2H\n");
            return 0;
        }
        else
        {
            printf ("The bidding choice : 2S\n");
            return 0;
        }
    }
    //3C 3D 3S 3H
    else if ( ( HCP>=8 && HCP<=11 ) && ( C==7 || D==7 || S==7 || H==7 ) )
    {
        if ( C==7 )
        {
            printf ("The bidding choice : 3C\n");
            return 0;
        }
        else if ( D==7 )
        {
            printf ("The bidding choice : 3D\n");
            return 0;
        }
        else if ( S==7 )
        {
            printf ("The bidding choice : 3S\n");
            return 0;
        }
        else
        {
            printf ("The bidding choice : 3H\n");
            return 0;
        }
        
    }
    //3NT
    else if ( (HCP<16) && 
            (  ( S==7 ) && ( x1==1 || x2==1 || x3==1 || x4==1 || x5==1 || x6==1 || x7==1 || x8==1 || x9==1 || x10==1 || x11==1 || x12==1 || x13==1 )
                && ( x1==12 || x2==12 || x3==12 || x4==12 || x5==12 || x6==12 || x7==12 || x8==12 || x9==12 || x10==12 || x11==12 || x12==12 || x13==12 )
                && ( x1==13 || x2==13 || x3==13 || x4==13 || x5==13 || x6==13 || x7==13 || x8==13 || x9==13 || x10==13 || x11==13 || x12==13 || x13==13 ) ) ||
            ( ( H==7 ) && ( x1==14 || x2==14 || x3==14 || x4==14 || x5==14 || x6==14 || x7==14 || x8==14 || x9==14 || x10==14 || x11==14 || x12==14 || x13==14 ) 
            && ( x1==25 || x2==25 || x3==25 || x4==25 || x5==25 || x6==25 || x7==25 || x8==25 || x9==25 || x10==25 || x11==25 || x12==25 || x13==25 )
            && ( x1==26 || x2==26 || x3==26 || x4==26 || x5==26 || x6==26 || x7==26 || x8==26 || x9==26 || x10==26 || x11==26 || x12==26 || x13==26 ) )
            )
    {
    	printf ("The bidding choice : 3NT\n");
        return 0;
    }
    //else
    else
    {
        printf ("The bidding choice : pass\n");
        return 0;
    }

}