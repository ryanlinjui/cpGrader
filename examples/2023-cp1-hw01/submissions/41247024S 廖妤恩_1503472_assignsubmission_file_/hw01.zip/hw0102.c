#include<stdio.h>
#include<stdint.h>
#include<ctype.h>

int main()
{
    int32_t a=0;
    int32_t b=0;
    int32_t c=0;
    int32_t d=0;
    int32_t e=0;
    
    printf("please enter the first interger:\n");
    scanf("%d", &a);
    //if ( isdigit(a) == 0 )
    {
        //printf("Wrong input, your input must between 0~99.\n");
        //return 0;
    }

    printf("please enter the second interger:\n");
    scanf("%d", &b);
    //if ( isdigit(b) == 0 )
    {
        //printf("Wrong input, your input must between 0~99.\n");
        //return 0;
    }

    
    //avoid idiot
    if ( a>99 || a<0 || b>99 || b<0 )
    {
        printf("Wrong input, your input must between 0~99.\n");
        return 0;
    }
    
    
    //a>9,b>9
    if ( a>9 && a<100 && b>9 && b<100)
    {
        c = a*(b%10);
        d = a*(b/10);
        e = c+d*10;
        
        //c>9<100 d>9<100
        if ( c>9 && c<100 && d>9 && d<100 )
        {
            //line1
            printf("   ");
            printf(" %d", a/10);
            printf(" %d", a%10);
            printf("\n");

            //line2
            printf("*) ");
            printf(" %d", b/10);
            printf(" %d", b%10);
            printf("\n");

            //line3
            printf("-------");
            printf("\n");
            
            //line4
            printf("   ");
            printf(" %d", c/10);
            printf(" %d", c%10);
            printf("\n");
            
            //line5
            printf(" ");
            printf(" %d", d/10);
            printf(" %d", d%10);
            
            //line6
            printf("\n");
            printf("-------");
            printf("\n");
            
            //line7
            printf(" ");
            printf(" %d", e/100);
            printf(" %d", (e%100)/10);
            printf(" %d", (e%100)%10);
            printf("\n");
            
            return 0;
                        
        }
        
        //c>99 d>99
        if ( c>99 && c<1000 && d>99 && d<1000 )
        {
            //line1
            printf("     ");
            printf(" %d", a/10);
            printf(" %d", a%10);
            printf("\n");

            //line2
            printf("*)   ");
            printf(" %d", b/10);
            printf(" %d", b%10);
            printf("\n");

            //line3
            printf("---------");
            printf("\n");

            //line4
            printf("   ");
            printf(" %d", c/100);
            printf(" %d", (c%100)/10);
            printf(" %d", (c%100)%10);
            printf("\n");

            //line5
            printf(" ");
            printf(" %d", d/100);
            printf(" %d", (d%100)/10);
            printf(" %d", (d%100)%10);
            
            //line6
            printf("\n");
            printf("---------");
            printf("\n");
            
            //line7
            printf(" ");
            printf(" %d", e/1000);
            printf(" %d", (e%1000)/100);
            printf(" %d", (e%1000)%100/10);
            printf(" %d", (e%1000)%100%10);
            printf("\n");

            return 0;

        }
        
        //c<99 d>99
        if ( c>9 && c<100 && d>99 && d<1000 )
        {
            //line1
            printf("     ");
            printf(" %d", a/10);
            printf(" %d", a%10);
            printf("\n");

            //line2
            printf("*)   ");
            printf(" %d", b/10);
            printf(" %d", b%10);
            printf("\n");

            //line3
            printf("---------");
            printf("\n");

            //line4
            printf("     ");
            printf(" %d", (c%100)/10);
            printf(" %d", (c%100)%10);
            printf("\n");

            //line5
            printf(" ");
            printf(" %d", d/100);
            printf(" %d", (d%100)/10);
            printf(" %d", (d%100)%10);

            //line6
            printf("\n");
            printf("---------");
            printf("\n");

            //line7
            printf(" ");
            printf(" %d", e/1000);
            printf(" %d", (e%1000)/100);
            printf(" %d", (e%1000)%100/10);
            printf(" %d", (e%1000)%100%10);
            printf("\n");

            return 0;

        }
        
        //c>99 d<99
        if ( c>99 && c<1000 && d>9 && d<100 )
        {
            //line1
            printf("   ");
            printf(" %d", a/10);
            printf(" %d", a%10);
            printf("\n");

            //line2
            printf("*) ");
            printf(" %d", b/10);
            printf(" %d", b%10);
            printf("\n");

            //line3
            printf("-------");
            printf("\n");

            //line4
            printf(" ");
            printf(" %d", c/100);
            printf(" %d", (c%100)/10);
            printf(" %d", (c%100)%10);
            printf("\n");

            //line5
            printf(" ");
            printf(" %d", (d%100)/10);
            printf(" %d", (d%100)%10);

            //line6
            printf("\n");
            printf("-------");
            printf("\n");
            
            //line7
            printf(" ");
            printf(" %d", (e%1000)/100);
            printf(" %d", (e%1000)%100/10);
            printf(" %d", (e%1000)%100%10);
            printf("\n");

            return 0;
        
        }
        
        //c=0 d<100
        if ( c==0  && d>9 && d<100 )
        {
            //line1
            printf("   ");
            printf(" %d", a/10);
            printf(" %d", a%10);
            printf("\n");

            //line2
            printf("*) ");
            printf(" %d", b/10);
            printf(" %d", b%10);
            printf("\n");

            //line3
            printf("-------");
            printf("\n");

            //line4
            printf("      0");
            printf("\n");

            //line5
            printf(" ");
            printf(" %d", (d%100)/10);
            printf(" %d", (d%100)%10);

            //line6
            printf("\n");
            printf("-------");
            printf("\n");

            //line7
            printf(" ");
            printf(" %d", (e%1000)/100);
            printf(" %d", (e%1000)%100/10);
            printf(" %d", (e%1000)%100%10);
            printf("\n");

            return 0;

        }
        
        //c=0 d>99
        if ( c==0  && d>99 && d<1000 )
        {
            //line1
            printf("     ");
            printf(" %d", a/10);
            printf(" %d", a%10);
            printf("\n");

            //line2
            printf("*)   ");
            printf(" %d", b/10);
            printf(" %d", b%10);
            printf("\n");

            //line3
            printf("---------");
            printf("\n");

            //line4
            printf("        0");
            printf("\n");

            //line5
            printf(" ");
            printf(" %d", d/100);
            printf(" %d", (d%100)/10);
            printf(" %d", (d%100)%10);

            //line6
            printf("\n");
            printf("---------");
            printf("\n");

            //line7
            printf(" ");
            printf(" %d", e/1000);
            printf(" %d", (e%1000)/100);
            printf(" %d", (e%1000)%100/10);
            printf(" %d", (e%1000)%100%10);
            printf("\n");
            
            return 0;

        }    
    }
    
    //a>10 b<10    
    if ( a>9 && a<100 && b<10 && b>=0 )    
    {
        e = a*b;
        if ( e>99 )
        {
            //line1
            printf("   ");
            printf(" %d", a/10);
            printf(" %d", a%10);
            printf("\n");

            //line2
            printf("*)   ");
            printf(" %d", b);
            printf("\n");

            //line3
            printf("-------");
            printf("\n");
            
            //line4
            printf(" ");
            printf(" %d", e/100);
            printf(" %d", (e%100)/10);
            printf(" %d", (e%100)%10);
            printf("\n");
            
            return 0;
                    
        }
        
        if ( e<100 && e>0 )
        {
            //line1
            printf(" ");
            printf(" %d", a/10);
            printf(" %d", a%10);
            printf("\n");

            //line2
            printf("*) ");
            printf(" %d", b);
            printf("\n");

            //line3
            printf("-----");
            printf("\n");
            
            //line4
            printf(" ");
            printf(" %d", e/10);
            printf(" %d", e%10);
            printf("\n");
            
            return 0;
                    
        }
        
        if ( e==0 )
        {
            //line1
            printf(" ");
            printf(" %d", a/10);
            printf(" %d", a%10);
            printf("\n");

            //line2
            printf("*) ");
            printf(" %d", b);
            printf("\n");

            //line3
            printf("-----");
            printf("\n");
            
            //line4
            printf("    0");
            printf("\n");
            
            return 0;
                    
        }
        
    }
    
    //a<10 b>10
    if ( a>=0 && a<10 && b>9 && b<100 )
    {
        e = a*b;
        c = a*(b%10);
        d = a*(b/10);
        
        if ( e==0 )
        {
            //line1
            printf("    ");
            printf(" %d", a);
            printf("\n");

            //line2
            printf("*)");
            printf(" %d", b/10);
            printf(" %d", b%10);
            printf("\n");

            //line3
            printf("------");
            printf("\n");

            //line4
            printf("     0");
            printf("\n");
            
            return 0;
        }
        
        if ( c>=10 && d>=10 )
        {
            //line1
            printf("     ");
            printf(" %d", a);
            printf("\n");

            //line2
            printf("*) ");
            printf(" %d", b/10);
            printf(" %d", b%10);
            printf("\n");
        
            //line3
            printf("-------");
            printf("\n");
            
            //line4
            printf("   ");
            printf(" %d", c/10);
            printf(" %d", c%10);
            printf("\n");
            
            //line5
            printf(" ");
            printf(" %d", d/10);
            printf(" %d", d%10);
            printf("\n");
            
            //line6
            printf("-------");
            printf("\n");
            
            //line7
            printf(" ");
            printf(" %d", e/100);
            printf(" %d", e%100/10);
            printf(" %d", e%100%10);
            printf("\n");
            
            return 0;
        }
        
        if ( c<10 && d>=10 )
        {
            //line1
            printf("     ");
            printf(" %d", a);
            printf("\n");

            //line2
            printf("*) ");
            printf(" %d", b/10);
            printf(" %d", b%10);
            printf("\n");
        
            //line3
            printf("-------");
            printf("\n");
            
            //line4
            printf("     ");
            printf(" %d", c);
            printf("\n");
            
            //line5
            printf(" ");
            printf(" %d", d/10);
            printf(" %d", d%10);
            printf("\n");
            
            //line6
            printf("-------");
            printf("\n");
            
            //line7
            printf(" ");
            printf(" %d", e/100);
            printf(" %d", e%100/10);
            printf(" %d", e%100%10);
            printf("\n");
            
            return 0;
            
        }
        
        if ( c>=10 && d<10 )
        {
            //line1
            printf("    ");
            printf(" %d", a);
            printf("\n");

            //line2
            printf("*)");
            printf(" %d", b/10);
            printf(" %d", b%10);
            printf("\n");

            //line3
            printf("------");
            printf("\n");

            //line4
            printf("  ");
            printf(" %d", c/10);
            printf(" %d", c%10);
            printf("\n");

            //line5
            printf("  ");
            printf(" %d", d);
            printf("\n");

            //line6
            printf("------");
            printf("\n");

            //line7
            printf("  ");
            printf(" %d", e/10);
            printf(" %d", e%10);
            printf("\n");
            
            return 0;
            
        }
        
        if ( c<10 && d<10 )
        {
            //line1
            printf("    ");
            printf(" %d", a);
            printf("\n");

            //line2
            printf("*)");
            printf(" %d", b/10);
            printf(" %d", b%10);
            printf("\n");

            //line3
            printf("------");
            printf("\n");

            //line4
            printf("    ");
            printf(" %d", c);
            printf("\n");

            //line5
            printf("  ");
            printf(" %d", d);
            printf("\n");

            //line6
            printf("------");
            printf("\n");

            //line7
            printf("  ");
            printf(" %d", e/10);
            printf(" %d", e%10);
            printf("\n");
            
            return 0;
        
        }
     
    }
    
    //a<10 b<10
    if ( a<10 && a>=0 && b<10 && b>=0)
    {
        e = a*b;
        
        if ( e==0 )
        {
            //line1
            printf("  ");
            printf(" %d", a);
            printf("\n");

            //line2
            printf("*)");
            printf(" %d", b);
            printf("\n");

            //line3
            printf("----");
            printf("\n");
            
            //line4
            printf("   0");
            printf("\n");
            return 0;

        }
        
        if ( e<10 )
        {
            //line1
            printf("  ");
            printf(" %d", a);
            printf("\n");

            //line2
            printf("*)");
            printf(" %d", b);
            printf("\n");

            //line3
            printf("----");
            printf("\n");
            
            //line4
            printf("  ");
            printf(" %d", e);
            printf("\n");
            
            return 0;

        }
        
        if ( e>9 )
        {
            //line1
            printf("   ");
            printf(" %d", a);
            printf("\n");

            //line2
            printf("*) ");
            printf(" %d", b);
            printf("\n");

            //line3
            printf("-----");
            printf("\n");

            //line4
            printf(" ");
            printf(" %d", e/10);
            printf(" %d", e%10);
            printf("\n");
             
            return 0;

        }
        //line1
        printf("    ");
        printf(" %d", a);
        printf("\n");

        //line2
        printf("*)  ");
        printf(" %d", b);
        printf("\n");

        //line3
        printf("--------");
        printf("\n");
        
        //whether 0
        e = a*b;
        if ( e==0 )
        {
            printf("     0");
            printf("\n");
            return 0;
        }
      
        //line4
        printf("  ");
        printf(" %d", e/10);
        printf(" %d", e%10);
        printf("\n");
        
    }    
    
     
}