#include<stdio.h>

int main (int argc, char **argv)
{
    //first
    printf("Now in those days there was in the land of Helsinki a young scholar named");
    printf("\033[34m Linus the Torvald\033[0m");
    printf(".");
    printf("\033[34m Linus\033[0m");
    printf(" was a devout man, a disciple of");
    printf("\033[34m RMS \033[0m");
    printf("and mighty in the spirit of");
    printf("\033[34m Turing\033[0m");
    printf(",");
    printf("\033[34m von Neumann \033[0m");
    printf("and");
    printf("\033[34m Moore\033[0m");
    printf(".One day as he was meditating on the Architecture,");
    printf("\033[34m Linus \033[0m");
    printf("fell into a trance and was granted a vision. And in the vision he saw a great Penguin, serene and well-favoured, sitting upon an ice floe eating fish. And at the sight of the Penguin");
    printf("\033[34m Linus \033[0m");
    printf("was deeply afraid, and he cried unto the spirits of");
    printf("\033[34m Turing\033[0m");
    printf(",");
    printf("\033[34m von Neumann \033[0m");
    printf("and");
    printf("\033[34m Moore \033[0m");
    printf("for an interpretation of the dream.\n");
    
    //second
    printf("\n");
    printf("And in the dream the spirits of");
    printf("\033[34m Turing\033[0m");
    printf(",");
    printf("\033[34m von Neumann \033[0m");
    printf("and");
    printf("\033[34m Moore \033[0m");
    printf("answered and spoke unto him, saying,");
    printf("\033[31m \"Fear not, \033[0m");
    printf("\033[34m Linus\033[0m");
    printf("\033[31m, most beloved hacker. You are exceedingly cool and froody. The great Penguin which you see is an Operating System which you shall create and deploy unto the earth. The ice-floe is the earth and all the systems thereof, upon which the Penguin shall rest and rejoice at the completion of its task. And the fish on which the Penguin feeds are the crufty Licensed codebases which swim beneath all the earth’s systems. The Penguin shall hunt and devour all that is crufty, gnarly and bogacious; all code which wriggles like spaghetti, or is infested with blighting creatures, or is bound by grave and perilous Licences shall it capture. And in capturing shall it replicate, and in replicating shall it document, and in documentation shall it bring freedom, serenity and most cool froodiness to the earth and all who code therein.\"\n\033[0m");
    
    //third
    printf("\033[34m\nLinus \033[0m");
    printf("rose from meditation and created a tiny Operating System Kernel as the dream had foreshewn him; in the manner of");
    printf("\033[34m RMS \033[0m");
    printf(",he released the Kernel unto the World Wide Web for all to take and behold. And in the fulness of Internet Time the Kernel grew and replicated, becoming most cool and exceedingly froody, until at last it was recognised as indeed a great and mighty Penguin, whose name was Tux. And the followers of");
    printf("\033[34m Linus \033[0m");
    printf("took refuge in the Kernel, the Libraries and the Utilities; they installed Distribution after Distribution, and made sacrifice unto the GNU and the Penguin, and gave thanks to the spirits of");
    printf("\033[34m Turing\033[0m");
    printf(",");
    printf("\033[34m von Neumann \033[0m");
    printf("and");
    printf("\033[34m Moore \033[0m");
    printf(",for their deliverance from the hand of Microsoft. And this was the beginning of the Fourth Age, the age of Open Source.\n");
    
    //linus
    printf("\033[34m\nLinus \033[0m");
    printf("was born in Helsinki, Finland, and pursued his university education at the university education at the University of Helsinki, majoring in Computer Science. In 1989, during his service in the Finnish Army's new area brigade, he purchesed textbook and the Minix operating system source code, igniting his interest in operating systems. Then, on August 25, 1991,");
    printf("\033[34m Linus \033[0m"); 
    printf("released the source code for the Linux kernel on the internet. His contributions have had a profound and lasting impact on the field of software technology.");
    printf("\n");
    
    //RMS
    printf("\033[34m\nRMS\033[0m");
    printf(", founded the GNU Project in 1983, advocating for software freedom, open source principles, and user rights.");
    printf("\033[34m RMS\033[0m"); 
    printf(" is renowned for creating open-source licenses like the General Public License, which safeguards software freedom. He is a staunch advocate for free software, and his work has had a profound impact on the software industry, championing personal computing and digital freedom. His contributions continue to shape the world of technology and promote the values of open and free software.");
    printf("\n");
    
    //turing
    printf("\033[34m\nTuring\033[0m");
    printf(", a 20th-century mathematical genius and computer science pioneer, revolutionized the world of computation. In 1936, he introduced the"); 
    printf("\033[34m Turing\033[0m");
    printf(" machine concept, a fundamental building block of modern computers and computer science theory. During WWII, he played a pivotal role in breaking the German Enigma code at Bletchley Park, contributing significantly to the Allied victory. ");
    printf("\033[34mTuring\033[0m");
    printf("'s ");
    printf("\033[34mTuring \033[0m");
    printf("Test question laid the groundwork for artificial intelligence. Despite facing discrimination due to his homosexuality, his legacy endures, profoundly influencing mathematics, computer science, and technology.");
    printf("\n");
    
    //von
    printf("\033[34m\nJohn von Neumann\033[0m"); 
    printf(", a renowned mathematician and physicist, made groundbreaking contributions to various fields, including computer science. He is best known for his work on the architecture of modern computers, introducing the concept of the"); 
    printf("\033[34m von Neumann \033[0m"); 
    printf("architecture. This groundbreaking design, which separates data and program memory, forms the foundation of most digital computers today."); 
    printf("\033[34mvon Neumann\033[0m");
    printf(" also played a pivotal role in the development of game theory and quantum mechanics. His legacy as a polymath and visionary thinker continues to shape scientific and technological advancements.");    
    printf("\n");
    
    //Moore
    printf("\033[34m\nGordon Moore\033[0m");
    printf(" , a co-founder of Intel Corporation, is a visionary figure in the world of technology. He is best known for ");
    printf("\033[34mMoore\033[0m");
    printf("'s Law, a prediction he made in 1965 that the number of transistors on a microchip would double approximately every two years, leading to exponential growth in computing power. This law has been a driving force behind the rapid advancement of the semiconductor industry and the digital revolution. ");
    printf("\033[34mMoore\033[0m");
    printf("'s influential contributions have had a profound impact on the development of modern electronics and continue to shape our digital world.");
    printf("\n");
    
    return 0;
}
