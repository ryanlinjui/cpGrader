#include<stdio.h>
#include<stdint.h>
#include<math.h>

int main()
{
    int32_t mail = 0;
    int32_t address = 0;
    int32_t error1 = 0;
    int32_t error2 = 0;
    int32_t error3 = 0;
    int32_t extra = 0;
    int32_t subject = 0;
    unsigned long long int score = 0;
    int32_t category = 0;
    int32_t hw = 0;
    int32_t p = 0;
    int32_t title = 0;
    int32_t c = 0;
    int32_t success1 = 0;
    int32_t success2 = 0;
    int32_t length = 0;
    int32_t wrong = 0;
    
    /*
    error11:local part invalid
    error12:domain is not authorized
    error21:no category
    error22:title is empty
    error31:out of range
    error32:too low
    */
    
    //address
    printf("Please enter the sender address      >");
    scanf("%*[0-9a-zA-Z]@%n", &mail);
        
    if ( mail==0 )
    {
        //mail=0
        error1 = 1;
        scanf("%*[^\n]%n", &mail); 
    }
    else
    {
        scanf("csie.cool%n", &address);
        scanf("ntnu.edu.tw%n", &address);
        scanf("csie.ntnu.edu.tw%n", &address);
        scanf("gapps.ntnu.edu.tw%n", &address);
        
        if ( address==17 || address==16 || address==11 || address==9 )
        {
            success1 = 1; 
        }
        else
        {
            error1 = 2;
        }
    }
       
    //subject
    printf("Please enter the email subject       >");
    scanf("%*[^\n]");
    scanf("%*c");
    scanf("[%n", &wrong);
    scanf("general]%n %*[0-9a-zA-Z]%n", &length, &title); 
    scanf("hw %d ][p %d ] %*[0-9a-zA-Z]%n", &hw, &p, &title);
    
    if ( length==0 )
    {
        if ( hw>9 || hw<1 || p>9 || p<1 )
        {
            error2 = 3;
        }
    }
    
    if ( wrong==0 )
    {
        error2 = 1;
    }
    if ( title==0 )
    {
        if ( length!=8 && hw==0 && p==0 )
        {
            error2 = 1;
        }
        else
        {
            error2 = 2;
        }
    }
    else if ( length!=8 && hw==0 && p==0 )
    {
        error2 = 1;
    }
    
    //scanf("general] %*[0-9a-zA-Z]%n", &title);   
    //scanf("hw %d ][p %d ] %*[0-9a-zA-Z]%n", &hw, &p, &title);
    
    /*
    //error2 1
    if ( length==8 )
    {
        success2 = 1;
    }
    else
    {
        error2 = 1;
    }*/
    
    //scanf("%*[^\n]%n", &title);
    
    
    //score
    printf("Please enter the email content score >");
    scanf("%*[^\n]");
    scanf("%*c");
    scanf("%lld", &score);
    
    if ( score<0 || score>1000000000000000000 )
    {
        error3 = 1;
    }
    else if ( score<title*10000000000 )
    {
        error3 = 2;
    }
    
    
    //print
    printf("\n");
    printf("================================================================================\n");
    
    //address
    if ( error1==1 )
    {
        printf("\n");
        printf("Sender Address Test: Failed, local-part is invalid.\n");
        printf("Email Subject Test: -\n");
        printf("Email Content Test: -\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("Rejected.\n");
        
        return 0;
    }
    else if ( error1==2 )
    {
        printf("\n");
        printf("Sender Address Test: Failed, domain is not authorized.\n");
        printf("Email Subject Test: -\n");
        printf("Email Content Test: -\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("Rejected.\n");
        
        return 0;
    }
    else
    {
        printf("\n");
        printf("Sender Address Test: Passed.\n");
    }
        
    //subject
    if ( error2==1 )
    {
        printf("Email Subject Test: Failed, no category.\n");
        printf("Email Content Test: -\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("Rejected.\n");

        return 0;
    }
    else if ( error2==2 )
    {
        printf("Email Subject Test: Failed, title is empty.\n");
        printf("Email Content Test: -\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("Rejected.\n");

        return 0;
    }
    else if ( error2==3 )
    {
        printf("Email Subject Test: Failed, please enter the correct number.\n");
        printf("Email Content Test: -\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("Rejected.\n");

        return 0;
    }
    else
    {
        printf("Email Subject Test: Passed.\n");
    }
    
    //score
    if ( error3==1 )
    {
        printf("Email Content Test: Failed, out of range.\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("Rejected.\n");

        return 0;
    }
    else if ( error3==2 )
    {
        printf("Email Content Test: Failed, too low.\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("Rejected.\n");

        return 0;
    }
    else
    {
        printf("Email Content Test: Passed.\n");
    }
    
    //printf
    printf("---------------------------------------------------------------------------------\n");
    
    //calculate c
    c = (hw*p)%5;
    
    if ( c==0 )
    {
        printf("Assigned to Kaname Madoka\n");
    }
    else if ( c==1 )
    {
        printf("Assigned to Akemi Homura\n");
    }
    else if ( c==2 )
    {
        printf("Assigned to Miki Sayaka\n");
    }
    else if ( c==3 )
    {
        printf("Assigned to Tomoe Mami\n");
    }
    else
    {
        printf("Assigned to Sakura Kyoko\n");
    }
            
}