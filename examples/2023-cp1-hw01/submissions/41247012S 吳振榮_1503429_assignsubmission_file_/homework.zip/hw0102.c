#include <stdio.h>
#include <stdint.h>
int32_t a, b;
void print_space(int32_t res, int32_t status){
	int32_t q = res / 1000;
	res -= (res/1000) * 1000;
	int32_t w = res / 100;
	res -= (res/100) * 100;
	int32_t e = res / 10;
	res -= (res/10) * 10;
	int32_t r = res % 10;
	if(q != 0){
		if(status == 0){
			printf("      ");
		}
		else if(status == 1){
			printf("    ");
		}
		else if(status == 2){
			printf("    ");
		}
		else if(status == 3){
			printf("  ");
		}
	}
	else if(w != 0){
		if(status == 0){
			printf("    ");
		}
		else if(status == 1){
			if(b / 10 == 0) printf("  ");
			printf("  ");
		}
		else if(status == 2){
			printf("  ");
		}
		else if(status == 3){
			printf("  ");
		}
	}
	else if(e != 0){
		if(status == 0){
			printf("  ");
		}
		else if(status == 1){
			printf("  ");
		}
		else if(status == 2){
			printf("  ");
		}
		else if(status == 3){
			printf("");
		}
	}
}
void print_dash(int32_t res){
	int32_t q = res / 1000;
	res -= (res/1000) * 1000;
	int32_t w = res / 100;
	res -= (res/100) * 100;
	int32_t e = res / 10;
	res -= (res/10) * 10;
	int32_t r = res % 10;
	if(q != 0) printf("------");
	else if(w != 0) printf("----");
	else if(e != 0) printf("--");
}	
int main(){
    printf("Please enter the first number: ");
    scanf("%d", &a);
    printf("Please enter the second number: ");
    scanf("%d", &b);
	if(a < 0 || b < 0 || a > 99 || b > 99){
		printf("Invalid input. Please enter an integer between 0 and 99.\n");
		return 0;
	}
	int32_t res = a * b, product = a * b;
	int32_t q = res / 1000;
	res -= (res/1000) * 1000;
	int32_t w = res / 100;
	res -= (res/100) * 100;
	int32_t e = res / 10;
	res -= (res/10) * 10;
	int32_t r = res % 10;
	if(a == 0){
		if(b == 0){
			print_space(product, 0);
        	printf("  %d\n", a);
			printf("*)");
			print_space(product, 1);
			printf("%d\n", b);
		}
		else if(b >= 10){
			print_space(b, 0);
			printf("  %d\n", a);
			printf("*)");
			print_space(b, 1);
			printf("%d %d\n", b / 10, b % 10);
		}
		else if(b < 10 && b > 0){
			print_space(b, 0);
			printf("  %d\n", a);
			printf("*)");
			print_space(b, 1);
			printf("%d\n", b);
		}
	}
	else if(b == 0){
		if(a >= 10){
			print_space(a, 0);
			printf("%d %d\n", a / 10, a % 10);
			printf("*)");
			// print_space(a, 1);
			printf("  ");
			printf("%d\n", b);
		}
		else if(a < 10 && a > 0){
			print_space(a, 0);
			printf("  %d\n", a);
			printf("*)");
			print_space(a, 1);
			printf("%d\n", b);
		}
	}
	else{
		if(a >= 10){
			print_space(product, 0);
			printf("%d %d\n", a / 10, a % 10);
		}
		else if(a < 10 && a > 0){
			print_space(product, 0);
			printf("  %d\n", a);
		}
		if(b >= 10){
			printf("*)");
			print_space(product, 1);
			printf("%d %d\n", b / 10, b % 10);
		}
		else if(b < 10 && b > 0){
			printf("*)");
			print_space(product, 1);
			printf("%d\n", b);
		}
	}
	if(a == 0) print_dash(b);
	else if(b == 0) print_dash(a);
	else print_dash(product);
	printf("---\n");
	int32_t tmp = 0, multiple, z;
	multiple = (a % 10) * (b % 10);

	if(multiple >= 10){
		tmp = multiple / 10;
		z = multiple % 10;
	}
	else if(multiple < 10)
		z = multiple;
	multiple = (a / 10) * (b % 10);
	if(multiple == 0){
		if(tmp > 0){
			if(q != 0 || w != 0) printf("  ");
			print_space(product, 2);
			printf("%d %d\n", tmp, z);
		}
		else{
			if(q != 0 || w != 0) printf("  ");
			if(a == 0 && b != 0) print_space(b, 2);
			else if(a != 0 && b == 0) print_space(a, 2);
			else print_space(product, 2);
			printf("  %d\n", z);
		}
	}
	else{
		multiple += tmp;
		tmp = 0;
		if(multiple >= 10){
			print_space(product, 2);
			printf("%d %d %d\n", multiple / 10, multiple % 10, z);
		}
		else{
			if(q != 0 || w != 0) printf("  ");
			print_space(product, 2);
			printf("%d %d\n", multiple, z);
		}
	}
	tmp = 0;
	multiple = (b / 10) * (a % 10);
	if(multiple == 0){
		return 0;
	}
	else{
		if(multiple >= 10){
			tmp = multiple / 10;
			z = multiple % 10;
		}
		else if(multiple < 10)
			z = multiple;
	}
	multiple = (a / 10) * (b / 10);
	if(multiple == 0){
		if(tmp > 0){
			print_space(product, 3);
			printf("%d %d\n", tmp, z);
		}
		else{
			print_space(product, 3);
			printf("  %d\n", z);
		}
	}
	else{
		multiple += tmp;
		if(multiple >= 10){
			print_space(product, 3);
			printf("%d %d %d\n", multiple / 10, multiple % 10, z);
		}
		else{
			print_space(product, 3);
			printf("%d %d\n", multiple, z);
		}
	}
	print_dash(product);
	printf("---\n");
	if(q != 0) printf("  %d %d %d %d\n", q, w, e, r);
	else if(w != 0) printf("  %d %d %d\n", w, e, r);
	else if(e != 0) printf("  %d %d\n", e, r);
	else if(r != 0) printf("  %d\n", r);
	
    return 0;
}
