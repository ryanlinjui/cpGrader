#include <stdio.h>
#include <stdint.h>
int32_t spades = 0, hearts = 0, diamond = 0, clubs = 0, hcp = 0, sa = 0, sq = 0, sk = 0, ha = 0, hq = 0, hk = 0;
int judge_suits(int suit){
    if(suit == 1) sa++;
    else if(suit == 13) sk++;
    else if(suit == 12) sq++;
    else if(suit == 14) ha++;
    else if(suit == 26) hk++;
    else if(suit == 25) hq++;
    if(suit == 1 || suit == 14 || suit == 27 || suit == 40) hcp += 4;
    else if(suit == 13 || suit == 26 || suit == 39 || suit == 52) hcp += 3;
    else if(suit == 12 || suit == 25 || suit == 38 || suit == 51) hcp += 2;
    else if(suit == 11 || suit == 24 || suit == 37 || suit == 50) hcp += 1;
    if(suit >= 1 && suit <= 13)  spades++;
    else if(suit >= 14 && suit <= 26) hearts++;
    else if(suit >= 27 && suit <= 39) diamond++;
    else if(suit >= 40 && suit <= 52) clubs++;
}
int balance(){
    if(spades == 4 && hearts == 3 && diamond == 3 && clubs == 3) return 1;
    else if(spades == 3 && hearts == 4 && diamond == 3 && clubs == 3) return 1;
    else if(spades == 3 && hearts == 3 && diamond == 4 && clubs == 3) return 1;
    else if(spades == 3 && hearts == 3 && diamond == 3 && clubs == 4) return 1;
    else return 0;
}
int error_input(int num){
    if(num > 52 || num < 1){
        printf("Invalid Input. Please input a number between 1 to 52.\n");
        return 1;
    }
    else return 0;
}
int main(){
    int32_t inp;
    printf("1st card: ");
    scanf("%d", &inp);
    if(error_input(inp)) return 0;
    judge_suits(inp);
    printf("2nd card: ");
    scanf("%d", &inp);
    if(error_input(inp)) return 0;
    judge_suits(inp);
    printf("3rd card: ");
    scanf("%d", &inp);
    if(error_input(inp)) return 0;
    judge_suits(inp);
    printf("4th card: ");
    scanf("%d", &inp);
    if(error_input(inp)) return 0;
    judge_suits(inp);
    printf("5th card: ");
    scanf("%d", &inp);
    if(error_input(inp)) return 0;
    judge_suits(inp);
    printf("6th card: ");
    scanf("%d", &inp);
    if(error_input(inp)) return 0;
    judge_suits(inp);
    printf("7th card: ");
    scanf("%d", &inp);
    if(error_input(inp)) return 0;
    judge_suits(inp);
    printf("8th card: ");
    scanf("%d", &inp);
    if(error_input(inp)) return 0;
    judge_suits(inp);
    printf("9th card: ");
    scanf("%d", &inp);
    if(error_input(inp)) return 0;
    judge_suits(inp);
    printf("10th card: ");
    scanf("%d", &inp);
    if(error_input(inp)) return 0;
    judge_suits(inp);
    printf("11th card: ");
    scanf("%d", &inp);
    if(error_input(inp)) return 0;
    judge_suits(inp);
    printf("12th card: ");
    scanf("%d", &inp);
    if(error_input(inp)) return 0;
    judge_suits(inp);
    printf("13th card: ");
    scanf("%d", &inp);
    if(error_input(inp)) return 0;
    judge_suits(inp);
    printf("---\n");
    printf("HCP: %d pts\n", hcp);
    printf("Suit: %d-%d-%d-%d\n", spades, hearts, diamond, clubs);
    printf("The bidding choice : ");
    if(hcp >= 22 && hcp <= 24 && balance()){
        printf("2NT\n");
        return 0;
    }
    if(hcp >= 16){
        printf("1C\n");
        return 0;
    }
    if(hcp >= 11 && hcp <= 15){
        if(hearts >= 5 && spades >= 5 && hearts == spades){
            printf("1S\n");
            return 0;
        }
        else if(hearts >= 5){
            printf("1H\n");
            return 0;
        }
        else if(spades >= 5){
            printf("1S\n");
            return 0;
        }
    }
    if(hcp >= 13 && hcp <= 15 && balance()){
        printf("1NT\n");
        return 0;
    }
    if(hcp >= 11 && hcp <= 15 && diamond >= 4){
        printf("1D\n");
        return 0;
    }
    if(hcp >= 11 && hcp <= 15 && clubs >= 6){
        printf("2C\n");
        return 0;
    }
    if(hcp >= 11 && hcp <= 15 && clubs >= 5 && diamond == 0){
        printf("2D\n");
        return 0;
    }
    if(hcp >= 8 && hcp <= 10){
        if(hearts == 6 && spades == 6){
            printf("2S\n");
            return 0;
        }
        else if(hearts == 6){
            printf("2H\n");
            return 0;
        }
        else if(spades == 6){
            printf("2S\n");
            return 0;
        }
    }
    if(hcp >= 8 && hcp <= 11){
        if(spades == 7){
            printf("3S\n");
            return 0;
        }
        else if(hearts == 7){
            printf("3H\n");
            return 0;
        }
        else if(diamond == 7){
            printf("3D\n");
            return 0;
        }
        else if(clubs == 7){
            printf("3C\n");
            return 0;
        }
    }
    if(hcp < 16){
        if(spades == 7 && sa && sk && sq){
            printf("3NT\n");
            return 0;
        }
        else if(hearts == 7 && ha && hk && hq){
            printf("3NT\n");
            return 0;
        }
    }
    printf("Pass\n");

    return 0;
}