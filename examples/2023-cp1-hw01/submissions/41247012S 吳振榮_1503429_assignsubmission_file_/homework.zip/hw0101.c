#include <stdio.h>
int main(){
    printf("Now in those days there was in the land of Helsinki a young\n\
    scholar named \x1B[0;34mLinus the Torvald\033[0m. \x1B[0;34mLinus\033[0m was a devout man, a\n\
    disciple of \x1B[0;34mRMS\033[0m and mighty in the spirit of \x1B[0;34mTuring\033[0m , \x1B[0;34mvon\n\
    Neumann\033[0m and \x1B[0;34mMoore\033[0m. One day as he was meditating on the\n\
    Architecture , \x1B[0;34mLinus\033[0m fell into a trance and was granted a\n\
    vision. And in the vision he saw a great Penguin , serene and\n\
    well-favoured , sitting upon an ice floe eating fish. And at\n\
    the sight of the Penguin \x1B[0;34mLinus\033[0m was deeply afraid , and he\n\
    cried unto the spirits of \x1B[0;34mTuring\033[0m , \x1B[0;34mvon Neumann\033[0m and \x1B[0;34mMoore\033[0m for\n\
    an interpretation of the dream.\n\
And in the dream the spirits of \x1B[0;34mTuring\033[0m , \x1B[0;34mvon Neumann\033[0m and \x1B[0;34mMoore\033[0m\n\
    answered and spoke unto him, saying , \033[1;31m\"Fear not,\033[0m \x1B[0;34mLinus\033[0m \033[1;31m, most\n\
    beloved hacker. You are exceedingly cool and froody. The\n\
    great Penguin which you see is an Operating System which you\n\
    shall create and deploy unto the earth. The ice-floe is the\n\
    earth and all the systems thereof , upon which the Penguin\n\
    shall rest and rejoice at the completion of its task. And\n\
    the fish on which the Penguin feeds are the crufty Licensed\n\
    codebases which swim beneath all the earth’s systems. The\n\
    Penguin shall hunt and devour all that is crufty , gnarly and\n\
    bogacious; all code which wriggles like spaghetti , or is\n\
    infested with blighting creatures , or is bound by grave and\n\
    perilous Licences shall it capture. And in capturing shall\n\
    it replicate , and in replicating shall it document , and in\n\
    documentation shall it bring freedom , serenity and most cool\n\
    froodiness to the earth and all who code therein.\"\033[0m\n\
\x1B[0;34mLinus\033[0m rose from meditation and created a tiny Operating System\n\
    Kernel as the dream had foreshewn him; in the manner of \x1B[0;34mRMS\033[0m,\n\
    he released the Kernel unto the World Wide Web for all to\n\
    take and behold. And in the fulness of Internet Time the\n\
    Kernel grew and replicated , becoming most cool and\n\
    exceedingly froody , until at last it was recognised as\n\
    indeed a great and mighty Penguin , whose name was Tux. And\n\
    the followers of \x1B[0;34mLinus\033[0m took refuge in the Kernel , the\n\
    Libraries and the Utilities; they installed Distribution\n\
    after Distribution , and made sacrifice unto the GNU and the\n\
    Penguin , and gave thanks to the spirits of \x1B[0;34mTuring\033[0m , \x1B[0;34mvon\n\
    Neumann\033[0m and \x1B[0;34mMoore\033[0m , for their deliverance from the hand of\n\
    Microsoft. And this was the beginning of the Fourth Age, the\n\
    age of Open Source.\n");

    printf("\x1B[0;34mLinus the Torvald\033[0m: At age 10 \x1B[0;34mTorvalds\033[0m began to dabble in computer programming on his grandfather’s Commodore VIC-20.\n\
    In 1991, while a computer science student at the University of Helsinki (M.S., 1996), he purchased his first personal computer (PC).\n\
    He was not satisfied, however, with the computer’s operating system (OS). His PC used MS-DOS.\n\
    but \x1B[0;34mTorvalds\033[0m preferred the UNIX operating system he had used on the university’s computers.\n\
    He decided to create his own PC-based version of UNIX. Months of determined programming work yielded the beginnings of an operating system known as Linux.\n");

    printf("\x1B[0;34mRMS\033[0m: \x1B[0;34mRichard Stallman\033[0m, in full \x1B[0;34mRichard Matthew Stallman\033[0m, (born March 16, 1953, New York, New York, U.S.), \n\
    American computer programmer and free-software advocate who founded (1985) the Free Software Foundation.\n\
    \x1B[0;34mStallman\033[0m earned a bachelor’s degree in physics from Harvard University in 1974. In 1971, as a freshman at Harvard, \n\
    he had begun working at the Artificial Intelligence Laboratory at the Massachusetts Institute of Technology (MIT). \n\
    There he wrote the Emacs text editor in the C computer programming language with \x1B[0;34mJames Gosling\033[0m (who later developed Java).\n");

    printf("\x1B[0;34mTuring\033[0m: \x1B[0;34mAlan Turing\033[0m, in full \x1B[0;34mAlan Mathison Turing\033[0m, (born June 23, 1912, London, England—died June 7, 1954, Wilmslow, Cheshire), \n\
    British mathematician and logician who made major contributions to mathematics, cryptanalysis, logic, philosophy, \n\
    and mathematical biology and also to the new areas later named computer science, cognitive science, artificial intelligence, and artificial life.\n");

    printf("\x1B[0;34mvon Neumann\033[0m: \x1B[0;34mJohn von Neumann\033[0m, original name \x1B[0;34mJános Neumann\033[0m. \n\
    \x1B[0;34mVon Neumann\033[0m grew from child prodigy to one of the world’s foremost mathematicians by his mid-twenties. \n\
    Important work in set theory inaugurated a career that touched nearly every major branch of mathematics. \n\
    \x1B[0;34mVon Neumann’s\033[0m gift for applied mathematics took his work in directions that influenced quantum theory, automata theory, economics, and defense planning. \n\
    \x1B[0;34mVon Neumann\033[0m pioneered game theory and, along with \x1B[0;34mAlan Turing\033[0m and \x1B[0;34mClaude Shannon\033[0m, was one of the conceptual inventors of the stored-program digital computer.\n");
    
    printf("\x1B[0;34mMoore\033[0m: \x1B[0;34mRoger D. Moore\033[0m was the 1973 recipient of the Grace Murray Hopper Award from the Association for Computing Machinery (ACM). \n\
    It was given \033[1;31m\"for their work in the design and implementation of APL\\360, setting new standards in simplicity, efficiency, \n\
    reliability and response time for interactive systems.\"\033[0m\n\
    \x1B[0;34mMoore\033[0m was a cofounder of I. P. Sharp Associates and held a senior position in the company for many years. \n\
    Before this, he contributed to the SUBALGOL compiler at Stanford University and wrote the ALGOL 60 compiler for the Ferranti-Packard 6000 and the ICT 1900. \n");

    return 0;
}