// #include <stdio.h>
// #include <stdint.h>
// int main(){
//     printf("Please enter the sender address      > ");
//     int32_t read_in = 0;
//     scanf("%*[a-zA-Z0-9]@%n", &read_in);
//     int32_t domain = 0, judge = 0;
//     scanf("ntnu.edu.tw%n", &domain);
//     if(domain == 0) scanf("gapps.ntnu.edu.tw%n", &domain);
//     if(domain == 0) scanf("csie.cool%n", &domain);
//     // printf("%d\n", domain);
//     if(domain == 0) scanf("ntnu.edu.tw%n", &domain); // csie.ntnu.edu.tw
//     // printf("%d\n", domain);
//     int32_t tmp;
//     printf("Please enter the email subject       > ");
//     scanf("%*[^\n]%n", &judge);
//     // printf("%d\n", judge);
//     scanf("%*c");
//     int32_t hw, p, gen, gen_len;
//     int32_t sub_len, bracket;
//     scanf("%*[[]%n", &bracket);
//     // int32_t status = scanf("hw%d][p%d] %*[ ?a-zA-Z0-9\"]%n", &hw, &p, &sub_len);
//     int32_t status = scanf("hw%d][p%d]", &hw, &p);
//     if(status == 0){
//         scanf("general]%n", &gen);
//         char inp;
//         scanf("%1c", &inp);
//         if(inp == ' ')
//             scanf("%*[ ?a-zA-Z0-9\"]%n", &gen_len);
//         // scanf("%c%*[ ?a-zA-Z0-9\"]%n", &inp, &gen_len);
//         // if(inp == '\n')
//         // printf("hi\n");
//         // scanf("%*c");
//     }
//     else{
//         char inp;
//         scanf("%1c", &inp);
//         if(inp == ' ') 
//             scanf("%*[ ?a-zA-Z0-9\"]%n", &gen_len);
//         // scanf("%c%*[ ?a-zA-Z0-9\"]%n", &inp, &sub_len);
//         // printf("hi\n");
//         // scanf("%*c");
//     }
//     // printf("%d %d\n", status, gen);
//     // printf("%d\n", bracket);
//     // if(status == 0) scanf("general] %*[ ?a-zA-Z0-9\"]%n", &gen);
//     // printf("%d %d\n", sub_len, gen_len);
//     printf("Please enter the email content score > ");
//     if(sub_len != 0 || gen != 0){
//         scanf("%*[^\n]");
//         scanf("%*c");
//     }
//     int64_t num;
//     int32_t cnt;
//     scanf("%ld%n", &num, &cnt);
//     // scanf("%ld", &num);
//     printf("%d %ld", cnt, num);
//     scanf("%*[^\n]");
//     scanf("%*c");
//     printf("%ld %ld\n", (int64_t)sub_len * (int64_t)1e10, (int64_t)gen_len * (int64_t)1e10);
//     printf("================================================================================\n\n");
//     if(read_in <= 0){
//         printf("Sender Address Test : Failed, local-part is invalid\n");
//         printf("Email Subject Test  : -\n");
//         printf("Email Content Test  : -\n");
//         printf("--------------------------------------------------------------------------------\n");
//         printf("\nRejected\n");
//         return 0;
//     }
//     else if(domain <= 0 || judge){
//         printf("Sender Address Test : Failed , domain is not authorized\n");
//         printf("Email Subject Test  : -\n");
//         printf("Email Content Test  : -\n");
//         printf("--------------------------------------------------------------------------------\n");
//         printf("\nRejected\n");
//         return 0;
//     }
//     // printf("%ld\n", num);
//     // printf("%ld\n", (int64_t)1e19);
//     if(bracket != 1){
//         printf("Sender Address Test : Passed\n");
//         printf("Email Subject Test  : Failed , no category\n");
//         printf("Email Content Test  : -\n");
//         printf("--------------------------------------------------------------------------------\n");
//         printf("\nRejected\n");
//         return 0;
//     }
//     else if(hw > 9 || hw < 0 || p > 9 || p < 0){
//         printf("Sender Address Test : Passed\n");
//         printf("Email Subject Test  : Failed, no category\n");
//         printf("Email Content Test  : -\n");
//         printf("--------------------------------------------------------------------------------\n");
//         printf("\nRejected\n");
//         return 0;
//     }
//     else if(status == 0 && gen == 0){
//         printf("Sender Address Test : Passed\n");
//         printf("Email Subject Test  : Failed , no category\n");
//         printf("Email Content Test  : -\n");
//         printf("--------------------------------------------------------------------------------\n");
//         printf("\nRejected\n");
//         return 0;
//     }
//     else if(sub_len == 0 && gen_len == 0){
//         printf("Sender Address Test : Passed\n");
//         printf("Email Subject Test  : Failed , title is empty\n");
//         printf("Email Content Test  : -\n");
//         printf("--------------------------------------------------------------------------------\n");
//         printf("\nRejected\n");
//         return 0;
//     }
//     if(cnt >= 20){
//         printf("Sender Address Test : Passed\n");
//         printf("Email Subject Test  : Passed\n");
//         printf("Email Content Test  : Failed , out of range\n");
//         printf("--------------------------------------------------------------------------------\n");
//         printf("\nRejected\n");
//         return 0;
//     }
//     else if(num < 0 || num < (int64_t)sub_len * (int64_t)1e10 || num < (int64_t)gen_len * (int64_t)1e10){
//         printf("Sender Address Test : Passed\n");
//         printf("Email Subject Test  : Passed\n");
//         printf("Email Content Test  : Failed , too low\n");
//         printf("--------------------------------------------------------------------------------\n");
//         printf("\nRejected\n");
//         return 0;
//     }
//     else{
//         printf("Sender Address Test : Passed\n");
//         printf("Email Subject Test  : Passed\n");
//         printf("Email Content Test  : Passed\n");
//         printf("--------------------------------------------------------------------------------\n\n");
//         int32_t c = (hw * p) % 5;
//         if(gen_len > 0){
//             printf("Assigned to TA QB\n");
//             return 0;
//         }
//         if(c == 0){
//             printf("Assigned to Kaname Madoka\n");
//         }
//         else if(c == 1){
//             printf("Assigned to Akemi Homura\n");
//         }
//         else if(c == 2){
//             printf("Assigned to Miki Sayaka\n");
//         }
//         else if(c == 3){
//             printf("Assigned to Tomoe Mami\n");
//         }
//         else if(c == 4){
//             printf("Assigned to Sakura Kyoko\n");
//         }
//     }

//     return 0;
// }



#include <stdio.h>
#include <stdint.h>
int main(){
    printf("Please enter the sender address      > ");
    int32_t read_in = 0;
    scanf("%*[a-zA-Z0-9]@%n", &read_in);
    int32_t domain = 0, judge = 0;
    scanf("ntnu.edu.tw%n", &domain);
    if(domain == 0) scanf("gapps.ntnu.edu.tw%n", &domain);
    if(domain == 0) scanf("csie.cool%n", &domain);
    if(domain == 0) scanf("ntnu.edu.tw%n", &domain); // csie.ntnu.edu.tw
    int32_t tmp;
    printf("Please enter the email subject       > ");
    scanf("%*[^\n]%n", &judge);
    scanf("%*c");
    int32_t hw = 0, p = 0, gen = 0, gen_len = 0;
    int32_t sub_len = 0, bracket = 0, special_case = 0;
    scanf("%*[[]%n", &bracket);
    int32_t status = scanf("hw%d][p%d]", &hw, &p);
    if(status == 0){
        scanf("general]%n", &gen);
        if(gen != 0){
            special_case = 1;
            char inp;
            scanf("%1c", &inp);
            if(inp == ' ')
                scanf("%*[ ._?a-zA-Z0-9\"]%n", &gen_len);
        }
    }
    else{
        special_case = 1;
        char inp;
        scanf("%1c", &inp);
        if(inp == ' ') 
            scanf("%*[ ._?a-zA-Z0-9\"]%n", &sub_len);
    }
    printf("Please enter the email content score > ");
    if(sub_len != 0 || gen_len != 0 || special_case == 0){
        scanf("%*[^\n]");
        scanf("%*c");
    }
    int64_t num;
    int32_t cnt;
    scanf("%ld%n", &num, &cnt);
    printf("================================================================================\n\n");
    if(read_in <= 0){
        printf("Sender Address Test : Failed, local-part is invalid\n");
        printf("Email Subject Test  : -\n");
        printf("Email Content Test  : -\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("\nRejected\n");
        return 0;
    }
    else if(domain <= 0 || judge){
        printf("Sender Address Test : Failed , domain is not authorized\n");
        printf("Email Subject Test  : -\n");
        printf("Email Content Test  : -\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("\nRejected\n");
        return 0;
    }
    if(bracket != 1){
        printf("Sender Address Test : Passed\n");
        printf("Email Subject Test  : Failed , no category\n");
        printf("Email Content Test  : -\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("\nRejected\n");
        return 0;
    }
    else if(hw > 9 || hw < 0 || p > 9 || p < 0){
        printf("Sender Address Test : Passed\n");
        printf("Email Subject Test  : Failed, no category\n");
        printf("Email Content Test  : -\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("\nRejected\n");
        return 0;
    }
    else if(status == 0 && gen == 0){
        printf("Sender Address Test : Passed\n");
        printf("Email Subject Test  : Failed , no category\n");
        printf("Email Content Test  : -\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("\nRejected\n");
        return 0;
    }
    else if(sub_len == 0 && gen_len == 0){
        printf("Sender Address Test : Passed\n");
        printf("Email Subject Test  : Failed , title is empty\n");
        printf("Email Content Test  : -\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("\nRejected\n");
        return 0;
    }
    if(cnt >= 20){
        printf("Sender Address Test : Passed\n");
        printf("Email Subject Test  : Passed\n");
        printf("Email Content Test  : Failed , out of range\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("\nRejected\n");
        return 0;
    }
    else if(num < 0 || num < (int64_t)sub_len * (int64_t)1e10 || num < (int64_t)gen_len * (int64_t)1e10){
        printf("Sender Address Test : Passed\n");
        printf("Email Subject Test  : Passed\n");
        printf("Email Content Test  : Failed , too low\n");
        printf("--------------------------------------------------------------------------------\n");
        printf("\nRejected\n");
        return 0;
    }
    else{
        printf("Sender Address Test : Passed\n");
        printf("Email Subject Test  : Passed\n");
        printf("Email Content Test  : Passed\n");
        printf("--------------------------------------------------------------------------------\n\n");
        int32_t c = (hw * p) % 5;
        if(gen_len > 0){
            printf("Assigned to TA QB\n");
            return 0;
        }
        if(c == 0){
            printf("Assigned to Kaname Madoka\n");
        }
        else if(c == 1){
            printf("Assigned to Akemi Homura\n");
        }
        else if(c == 2){
            printf("Assigned to Miki Sayaka\n");
        }
        else if(c == 3){
            printf("Assigned to Tomoe Mami\n");
        }
        else if(c == 4){
            printf("Assigned to Sakura Kyoko\n");
        }
    }

    return 0;
}