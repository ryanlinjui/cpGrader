#include <stdio.h>
#include <stdint.h>
int main(){
    double a_x, a_y, b_x, b_y;
    printf("Please enter the point A (x,y): ");
    scanf("%lf,%lf", &a_x, &a_y);
    printf("Please enter the point B (x,y): ");
    scanf("%lf,%lf", &b_x, &b_y);
    if(a_x == b_x && a_y == b_y){
        printf("Invalid input. They are the same point.\n");
        return 0;
    } 
    if(b_x - a_x == 0){
        printf("Invalid input. Line AB is vertical.\n");
        return 0;
    }
    long double m = (b_y - a_y) / (b_x - a_x);
    if(m == 0){
        printf("Invalid input. Line AB is horizontal.\n");
        return 0;
    }
    double k = a_y - (m * a_x);
    double x = (0 - k) / m;
    double y = k;
    if((x * y) / 2 == 0){
        printf("Invalid input. The area is 0.\n");
        return 0;
    }
    double area = (x * y) / 2;
    if(area < 0) area *= (-1);
    printf("Area: %.2lf\n", area);
    
    return 0;
}