#include "mycal.h"
/*
*pExpr format will be as follows:
<Operand 1> (Operator 1) <Operand 2> (Operator 2) <Operand 3> ...
+ Operand format: digits_base. Example: ”123_10”, ”BEEF_16”.
+ Operator: +, -, *
+ For your simplicity, you do NOT need to consider parentheses.
+ If the format is not valid, return -1.

Note:
+ pExpr 中每個運算元之 base 10 均不會超過 int32_t 範圍
+ pExpr 長度不超過 100
+ 2 <= base <= 16
+ 運算子和運算元間必有空格
*/

bool checkLegal(char *pExpr) {
    regex_t regex;
    int ret;

    // Compile the regular expression
    ret = regcomp(&regex, "^([0-9A-Fa-f]*_[0-9]+ [\\+\\*-] )*[0-9A-Fa-f]*_[0-9]+$", REG_EXTENDED);
    if (ret) {
        return false;
    }

    // Execute the regular expression
    ret = regexec(&regex, pExpr, 0, NULL, 0);
    if (!ret) {
        regfree(&regex);
        return true;
    } else if (ret == REG_NOMATCH) {
        regfree(&regex);
        return false;
    } else {
        regfree(&regex);
        return false;
    }

    
}

int32_t turnToDecimal(char *pTocken) {
    char *underscore = strchr(pTocken, '_');
    int32_t base = strtol(underscore + 1, NULL, 10);
    int32_t operand = strtol(pTocken, NULL, base);
    //printf("DEBUG: %d\n", base);
    //printf("DEBUG turnToDecimal: %d\n", operand);
    return operand;
}

int32_t decimalToOtherBase(int32_t decimal_value, int32_t base, char **ppResult) {
    char digits[] = "0123456789ABCDEF";
    char *result = malloc(100);
    int i = 0;
    bool isNegative = false;

    // Check if decimal_value is negative
    if (decimal_value < 0) {
        isNegative = true;
        decimal_value = -decimal_value; // Convert to positive
    }

    // Handle the case of 0 separately
    if (decimal_value == 0) {
        result[i++] = '0';
    }

    // Convert decimal_value to the specified base
    while (decimal_value > 0) {
        result[i++] = digits[decimal_value % base];
        decimal_value /= base;
    }

    // If the original decimal_value was negative, add a minus sign
    if (isNegative) {
        result[i++] = '-';
    }

    // Reverse the result string
    for (int j = 0; j < i / 2; j++) {
        char temp = result[j];
        result[j] = result[i - j - 1];
        result[i - j - 1] = temp;
    }

    // Create the final result string in the format "value_base"
    char *finalResult = malloc(100);
    sprintf(finalResult, "%s_%d", result, base);

    free(result);
    *ppResult = finalResult;

    return 0;
}

bool checkBase(char *token) {
    char *digits = "0123456789ABCDEF";
    char *underscore = strchr(token, '_');
    if (!underscore) {
        return false;  // No underscore found
    }
    int base = strtol(underscore + 1, NULL, 10);
    //printf("DEBUG: checking: %s\n", token);
    //printf("DEBUG: base: %d\n", base);
    for (int i = 0; i < underscore - token; i++) {
        //printf("DEBUG: checking: %c\n", token[i]);
        bool found = false;
        for (int j = 0; j < base; j++) {
            if (toupper(token[i]) == digits[j]) {
                //printf("DEBUG: found: %c\n", token[i]);
                found = true;
                break;
            }
        }
        if (!found) {
            return false;
        }
    }

    return true;
}

int32_t calculate(char *pExpr, int32_t base, char **ppResult) {
    if (!checkLegal(pExpr)) {
        return -1;
    }

    char *pExprCopy = strdup(pExpr);
    char *token = strtok(pExprCopy, " ");
    int32_t operands[50];
    char operators[50];
    int operandCount = 0;
    int operatorCount = 0;

    // Parse the expression
    while (token != NULL) {
        if (token[0] != '+' && token[0] != '-' && token[0] != '*') {
            operands[operandCount++] = turnToDecimal(token);
            if (!checkBase(token)) {
                //printf("Invalid binary number: %s\n", token);
                return -1;
            }
        } else {
            operators[operatorCount++] = token[0];
        }
        token = strtok(NULL, " ");
    }

    // Perform all multiplications and divisions first
    for (int i = 0; i < operatorCount; i++) {
        if (operators[i] == '*') {
            operands[i] *= operands[i + 1];
            // Shift the remaining elements to the left
            for (int j = i + 1; j < operandCount - 1; j++) {
                operands[j] = operands[j + 1];
            }
            operandCount--;
            // Shift the remaining elements to the left
            for (int j = i; j < operatorCount - 1; j++) {
                operators[j] = operators[j + 1];
            }
            operatorCount--;
            i--; // Check the current index again
        }
    }

    // Perform all additions and subtractions
    int32_t result = operands[0];
    for (int i = 0; i < operatorCount; i++) {
        if (operators[i] == '+') {
            result += operands[i + 1];
        } else if (operators[i] == '-') {
            result -= operands[i + 1];
        }
    }

    free(pExprCopy);

    decimalToOtherBase(result, base, ppResult);
    return 0;
}
    