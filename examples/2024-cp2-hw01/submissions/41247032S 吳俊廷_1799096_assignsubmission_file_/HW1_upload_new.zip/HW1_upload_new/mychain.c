#include "mychain.h"


// Polynomial structures
// Example:
// f(x) = x^3-2x+1
// size = 3
// pPowers: [3,1,0]
// pCoefficients: [1,-2,1]

// typedef struct _sPoly{
//     uint32_t size;
//     uint32_t *pPowers;
//     int32_t *pCoefficients;
// } sPoly;

// Input:
// *pFy: z = f1(y);
// *pFx: y = f2(x);
// Note that pPower can be in any orders.
// Output:
// *pResult = dz/dx
// Note that pPower should be in the descending order.
// Return:
// 0: Success; -1: Error input

// Function to sort the polynomial in descending order of powers
void debugPrintPoly(sPoly a){
    printf("size=%d\n",a.size);
    for(int i=0;i<a.size;i++){
        printf("pPowers[%d]=%d\n",i,a.pPowers[i]);
        printf("pCoefficients[%d]=%d\n",i,a.pCoefficients[i]);
    }
}


int partition(sPoly *pPoly, int low, int high) {
    uint32_t pivot = pPoly->pPowers[high];
    int i = (low - 1);

    for (int j = low; j <= high - 1; j++) {
        if (pPoly->pPowers[j] > pivot) {
            i++;
            // Swap powers
            uint32_t tempPower = pPoly->pPowers[i];
            pPoly->pPowers[i] = pPoly->pPowers[j];
            pPoly->pPowers[j] = tempPower;

            // Swap coefficients
            int32_t tempCoefficient = pPoly->pCoefficients[i];
            pPoly->pCoefficients[i] = pPoly->pCoefficients[j];
            pPoly->pCoefficients[j] = tempCoefficient;
        }
    }

    // Swap powers
    uint32_t tempPower = pPoly->pPowers[i + 1];
    pPoly->pPowers[i + 1] = pPoly->pPowers[high];
    pPoly->pPowers[high] = tempPower;

    // Swap coefficients
    int32_t tempCoefficient = pPoly->pCoefficients[i + 1];
    pPoly->pCoefficients[i + 1] = pPoly->pCoefficients[high];
    pPoly->pCoefficients[high] = tempCoefficient;

    return (i + 1);
}

void quickSort(sPoly *pPoly, int low, int high) {
    if (low < high) {
        int pi = partition(pPoly, low, high);

        quickSort(pPoly, low, pi - 1);
        quickSort(pPoly, pi + 1, high);
    }
}

void sort_poly(sPoly *pPoly) {
    quickSort(pPoly, 0, pPoly->size - 1);
}


sPoly removeZeroCoefficients(sPoly* pPoly) {
    // Count the number of terms with non-zero coefficients
    uint32_t nonZeroCount = 0;
    for (uint32_t i = 0; i < pPoly->size; i++) {
        if (pPoly->pCoefficients[i] != 0) {
            nonZeroCount++;
        }
    }

    // Create a new polynomial with only the non-zero terms
    sPoly newPoly;
    newPoly.size = nonZeroCount;
    newPoly.pPowers = (uint32_t*)calloc(sizeof(uint32_t) , newPoly.size);
    newPoly.pCoefficients = (int32_t*)calloc(sizeof(int32_t) , newPoly.size);

    uint32_t j = 0;
    for (uint32_t i = 0; i < pPoly->size; i++) {
        if (pPoly->pCoefficients[i] != 0) {
            newPoly.pPowers[j] = pPoly->pPowers[i];
            newPoly.pCoefficients[j] = pPoly->pCoefficients[i];
            j++;
        }
    }
    return newPoly;
}

sPoly simplifyPolynomial(sPoly* pPoly) {
    // Create a new polynomial
    sPoly newPoly;
    newPoly.size = 0;
    newPoly.pPowers = (uint32_t*)calloc(sizeof(uint32_t) , pPoly->size);
    newPoly.pCoefficients = (int32_t*)calloc(sizeof(int32_t) , pPoly->size);

    // Iterate over each term in the original polynomial
    for (uint32_t i = 0; i < pPoly->size; i++) {
        // Check if the new polynomial already contains a term with the same power
        bool found = false;
        for (uint32_t j = 0; j < newPoly.size; j++) {
            if (newPoly.pPowers[j] == pPoly->pPowers[i]) {
                // If it does, add the coefficients
                newPoly.pCoefficients[j] += pPoly->pCoefficients[i];
                found = true;
                break;
            }
        }

        // If it doesn't, add a new term to the new polynomial
        if (!found) {
            newPoly.pPowers[newPoly.size] = pPoly->pPowers[i];
            newPoly.pCoefficients[newPoly.size] = pPoly->pCoefficients[i];
            newPoly.size++;
        }
    }

    // Remove terms with zero coefficients
    sPoly simplifiedPoly = removeZeroCoefficients(&newPoly);
    //printf("DEBUG:\n");
    //debugPrintPoly(newPoly);

    //Sort the polynomial in descending order of powers
    sort_poly(&simplifiedPoly);

    // Free the memory allocated for the new polynomial
    free(newPoly.pPowers);
    free(newPoly.pCoefficients);

    return simplifiedPoly;
}

sPoly copyPolynomial(sPoly* pPoly) {
    // Create a new polynomial with the same size as the original
    sPoly newPoly;
    newPoly.size = pPoly->size;
    newPoly.pPowers = (uint32_t*)calloc(sizeof(uint32_t) , newPoly.size);
    newPoly.pCoefficients = (int32_t*)calloc(sizeof(int32_t) , newPoly.size);

    // Copy the powers and coefficients from the original polynomial to the new one
    for (uint32_t i = 0; i < pPoly->size; i++) {
        newPoly.pPowers[i] = pPoly->pPowers[i];
        newPoly.pCoefficients[i] = pPoly->pCoefficients[i];
    }
    
    return newPoly;
}

sPoly multiplyPolynomials(sPoly* pPoly1, sPoly* pPoly2) {
    // Create a new polynomial with size equal to the product of the sizes of the input polynomials
    sPoly newPoly;
    newPoly.size = pPoly1->size * pPoly2->size;
    newPoly.pPowers = (uint32_t*)calloc(sizeof(uint32_t) , newPoly.size);
    newPoly.pCoefficients = (int32_t*)calloc(sizeof(int32_t) , newPoly.size);

    // Initialize the powers and coefficients of the new polynomial to zero
    for (uint32_t i = 0; i < newPoly.size; i++) {
        newPoly.pPowers[i] = 0;
        newPoly.pCoefficients[i] = 0;
    }

    // Multiply each term of the first polynomial by each term of the second polynomial
    uint32_t index = 0;
    for (uint32_t i = 0; i < pPoly1->size; i++) {
        for (uint32_t j = 0; j < pPoly2->size; j++) {
            newPoly.pPowers[index] += pPoly1->pPowers[i] + pPoly2->pPowers[j];
            newPoly.pCoefficients[index] += pPoly1->pCoefficients[i] * pPoly2->pCoefficients[j];
            index++;
        }
    }
    //printf("before\n");
    //debugPrintPoly(newPoly);
    newPoly=simplifyPolynomial(&newPoly);
    //printf("after\n");
    //debugPrintPoly(newPoly);
    return newPoly;
}

sPoly plusPolynomials(sPoly* pPoly1, sPoly* pPoly2) {
    // Create a new polynomial with size equal to the sum of the sizes of the input polynomials
    sPoly newPoly;
    newPoly.size = pPoly1->size + pPoly2->size;
    newPoly.pPowers = (uint32_t*)calloc(sizeof(uint32_t) , newPoly.size);
    newPoly.pCoefficients = (int32_t*)calloc(sizeof(int32_t) , newPoly.size);

    // Copy the powers and coefficients of the first polynomial to the new polynomial
    for (uint32_t i = 0; i < pPoly1->size; i++) {
        newPoly.pPowers[i] = pPoly1->pPowers[i];
        newPoly.pCoefficients[i] = pPoly1->pCoefficients[i];
    }

    // Add the powers and coefficients of the second polynomial to the new polynomial
    for (uint32_t i = 0; i < pPoly2->size; i++) {
        newPoly.pPowers[i + pPoly1->size] = pPoly2->pPowers[i];
        newPoly.pCoefficients[i + pPoly1->size] = pPoly2->pCoefficients[i];
    }

    newPoly=simplifyPolynomial(&newPoly);

    return newPoly;
}

sPoly multiplyConstPolynomials(sPoly* pPoly, int32_t constant) {
    // Create a new polynomial with size equal to the size of the input polynomial
    sPoly newPoly;
    newPoly.size = pPoly->size;
    newPoly.pPowers = (uint32_t*)calloc(sizeof(uint32_t) , newPoly.size);
    newPoly.pCoefficients = (int32_t*)calloc(sizeof(int32_t) , newPoly.size);

    // Multiply the coefficients of the input polynomial by the constant and copy the powers
    for (uint32_t i = 0; i < pPoly->size; i++) {
        newPoly.pPowers[i] = pPoly->pPowers[i];
        newPoly.pCoefficients[i] = pPoly->pCoefficients[i] * constant;
    }

    newPoly=simplifyPolynomial(&newPoly);
    
    return newPoly;
}

sPoly countPolynomialTimes(sPoly* pPoly, uint32_t times) {
    // Create a new polynomial that is a copy of the original
    sPoly result = copyPolynomial(pPoly);

    // Multiply the result by the original polynomial the specified number of times
    for (uint32_t i = 1; i < times; i++) {
        result = multiplyPolynomials(&result, pPoly);
    }

    result=simplifyPolynomial(&result);

    return result;
}



int32_t chain_rule(sPoly *pResult, const sPoly *pFy, const sPoly *pFx) {

    pResult->pPowers = (uint32_t*)calloc(sizeof(uint32_t) , 1002);
    pResult->pCoefficients = (int32_t*)calloc(sizeof(int32_t) , 1002);

    pResult->size = 0;
    pResult->pPowers[0] = 0;
    pResult->pCoefficients[0] = 0;
    sPoly tempYPoly=*pFy;
    sPoly tempXPoly=*pFx;


    // Calculate the derivative of pFy
    sPoly pFy_derivative;
    pFy_derivative.size = pFy->size;
    pFy_derivative.pPowers = (uint32_t*)calloc(sizeof(uint32_t) , pFy_derivative.size);
    pFy_derivative.pCoefficients = (int32_t*)calloc(sizeof(int32_t) , pFy_derivative.size);
    for (uint32_t i = 0; i < pFy->size; i++) {
        if (pFy->pPowers[i] == 0) {
            pFy_derivative.pPowers[i] = 0;
            pFy_derivative.pCoefficients[i] = 0;
        } else {
            pFy_derivative.pPowers[i] = pFy->pPowers[i] - 1;
            pFy_derivative.pCoefficients[i] = pFy->pCoefficients[i] * pFy->pPowers[i];
        }
        //printf("pFy_derivative.pPowers[%d] = %d\n", i, pFy_derivative.pPowers[i]);
        //printf("pFy_derivative.pCoefficients[%d] = %d\n", i, pFy_derivative.pCoefficients[i]);
    }

    pFy_derivative = simplifyPolynomial(&pFy_derivative);

    // Calculate the derivative of pFx
    sPoly pFx_derivative;
    pFx_derivative.size = pFx->size;
    pFx_derivative.pPowers = (uint32_t*)calloc(sizeof(uint32_t) , pFx_derivative.size);
    pFx_derivative.pCoefficients = (int32_t*)calloc(sizeof(int32_t) , pFx_derivative.size);
    for (uint32_t i = 0; i < pFx->size; i++) {
        if (pFx->pPowers[i] == 0) {
            pFx_derivative.pPowers[i] = 0;
            pFx_derivative.pCoefficients[i] = 0;
        } else {
            pFx_derivative.pPowers[i] = pFx->pPowers[i] - 1;
            pFx_derivative.pCoefficients[i] = pFx->pCoefficients[i] * pFx->pPowers[i];
        }
        //printf("pFx_derivative.pPowers[%d] = %d\n", i, pFx_derivative.pPowers[i]);
        //printf("pFx_derivative.pCoefficients[%d] = %d\n", i, pFx_derivative.pCoefficients[i]);
    }

    pFx_derivative = simplifyPolynomial(&pFx_derivative);


    //debug
    // for(int i=0;i<pFx_derivative.size;i++){
    //     printf("pFx_derivative.pPowers[%d] = %d\n", i, pFx_derivative.pPowers[i]);
    //     printf("pFx_derivative.pCoefficients[%d] = %d\n", i, pFx_derivative.pCoefficients[i]);
    // }
    // for(int i=0;i<pFy_derivative.size;i++){
    //     printf("pFy_derivative.pPowers[%d] = %d\n", i, pFy_derivative.pPowers[i]);
    //     printf("pFy_derivative.pCoefficients[%d] = %d\n", i, pFy_derivative.pCoefficients[i]);
    // }
    

    // Create a temporary polynomial to store the product of the derivatives
    sPoly temp;
    temp.size = 1005;
    temp.pPowers = (uint32_t*)calloc(sizeof(uint32_t) , temp.size);
    temp.pCoefficients = (int32_t*)calloc(sizeof(int32_t) , temp.size);
    temp.size=1;
    temp.pPowers[0]=0;
    temp.pCoefficients[0]=0;


    // Debug
    // sPoly debug;
    // debug=countPolynomialTimes(&pFy_derivative,0);
    // debugPrintPoly(debug);

    // Calculate the power of the derivatives
    for(int i=0;i<pFy_derivative.size;i++){

        if(pFy_derivative.pPowers[i]==0){
            temp.size=1;
            temp.pPowers[0]=0;
            temp.pCoefficients[0]=pFy_derivative.pCoefficients[i];
        }else{
            temp=countPolynomialTimes(&tempXPoly,pFy_derivative.pPowers[i]);
            // printf("\n\nTEMP1 DEBUG:\n");
            // debugPrintPoly(temp);
            // printf("\n\n");
            temp=multiplyConstPolynomials(&temp,pFy_derivative.pCoefficients[i]);
            // printf("\n\nTEMP2 DEBUG:\n");
            // debugPrintPoly(temp);
            // printf("\n\n");
        }
        
        temp=multiplyPolynomials(&temp,&pFx_derivative);
        // printf("\n\nTEMP3 DEBUG:\n");
        // debugPrintPoly(temp);
        // printf("\n\n");
        *pResult=plusPolynomials(pResult,&temp);
        
        // printf("\n\nRESULT DEBUG:\n");
        // debugPrintPoly(*pResult);
        // printf("\n\n");
    }
    
    //debugPrintPoly(*pResult);

    
    // Free the memory allocated for the derivatives and the temporary polynomial
    free(pFy_derivative.pPowers);
    free(pFy_derivative.pCoefficients);
    free(pFx_derivative.pPowers);
    free(pFx_derivative.pCoefficients);
    free(temp.pPowers);
    free(temp.pCoefficients);
    return 0;
}

/*
規則：
保證 *pResult 的 size 不超過 10^3
保證 Power 皆為 uint32_t
保證 Coefficient 在計算過程與結果皆為 int32_t
保證 pFy 和 pFx 給的 size 和 pPowers 及 pCoefficients 一致
若單筆測資執行時間超過 10 秒會視為錯誤
記得輸出要降序排序
輸出的多項式必須為最簡，也就是2x+2x要合併成 4x
化為最簡包含將係數為 0 的項移除，例如:2x^3 + 0x^2 + 3x^1 + 0會變成2x^3 + 3x^1
可能會有重複的次方項(如2x + 3x^2 + 4x)

提示：
可以把運算拆成 function 來寫，會比較簡單
記得處理壞壞的輸入哦(不過題目保證那麼多就只剩下…)
可能會有以下情況f(y)=y^2,f(x)=x^{10^9}+1，你如果想跑 10^9\times10^9 迴圈會跑很久哦
*/

//EXAMPLE:
// *pFy:
// size = 1
// pPowers: [2]
// pCoefficients: [1]
// *pFx:
// size = 2
// pPowers: [1,0]
// pCoefficients: [4,-3]
// *pResult:
// size = 2
// pPowers: [1,0]
// pCoefficients: [32,-24]