#include "mychain.h"

int main(){

    sPoly pFx;
    pFx.size = 3;
    pFx.pPowers = (uint32_t*)malloc(sizeof(uint32_t) * pFx.size);
    pFx.pCoefficients = (int32_t*)malloc(sizeof(int32_t) * pFx.size);
    pFx.pPowers[0] = 1;
    pFx.pPowers[1] = 2;
    pFx.pPowers[2] = 0;
    pFx.pPowers[100] = 999999;
    pFx.pCoefficients[0] = -2;
    pFx.pCoefficients[1] = 1;
    pFx.pCoefficients[2] = 1;
    printf("pFx.pPowers[100]=%d\n", pFx.pPowers[100]);

    sort_poly(&pFx);
    debugPrintPoly(pFx);
    return 0;

}