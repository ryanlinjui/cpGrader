#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>

typedef struct _sRoom{
    uint32_t cost;
    uint8_t doors; // 8 bits: aabbccdd
    // aa: the up door number 0-3
    // bb: the right door number 0-3
    // cc: the down number 0-3
    // dd: the left door number 0-3
} sRoom;

typedef struct _sPoint{
    uint32_t row;
    uint32_t col;
} sPoint;

typedef struct _sPath
{
    uint32_t length; // Path length.
    uint32_t cost;   // Cost
    sPoint *pPath;   // An array of all points in order.
} sPath;

int main(){
    
    sRoom test[2][2];
    test[0][0].cost=1;
    test[0][1].cost=2;
    test[1][0].cost=3;
    test[1][1].cost=4;

    printf("%p\n",test);
    printf("%p\n",test+1);
    printf("%p\n",test+2);
    printf("%p\n",test+3);

    printf("cost=%d\n",(*test)->cost);
    printf("cost=%d\n",(*test+1)->cost);
    printf("cost=%d\n",(*test+2)->cost);
    printf("cost=%d\n",(*test+3)->cost);

    printf("cost=%d\n",test[0][0].cost);
    printf("cost=%d\n",test[0][1].cost);
    printf("cost=%d\n",test[1][0].cost);
    printf("cost=%d\n",test[1][1].cost);
    return 0;
}