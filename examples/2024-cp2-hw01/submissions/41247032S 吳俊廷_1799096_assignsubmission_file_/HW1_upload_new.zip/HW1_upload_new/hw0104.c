#include "mymaze.h"



// void printABox(const sRoom room){
//     // 讀取上門的數字
//     uint8_t upDoor = (room.doors & 0b11000000) >> 6;

//     // 讀取右門的數字
//     uint8_t rightDoor = (room.doors & 0b00110000) >> 4;

//     // 讀取下門的數字
//     uint8_t downDoor = (room.doors & 0b00001100) >> 2;

//     // 讀取左門的數字
//     uint8_t leftDoor = room.doors & 0b00000011;
//     printf("+%d+\n",upDoor);
//     printf("%d %d\n",leftDoor,rightDoor);
//     printf("+%d+\n",downDoor);
// }
// void print_maze(const sRoom *maze, uint8_t row, uint8_t col) {
//     for (uint8_t i = 0; i < row; i++) {
//         for (uint8_t j = 0; j < col; j++) {
//             printABox(maze[i * col + j]);
//             //printf("cost=%d, doors=%d\n", maze[i * col + j].cost, maze[i * col + j].doors);
//         }
//     }
// }

int main(){
    sRoom test[3][4]; //[row][col]
    test[0][0].cost=1;
    test[0][0].doors=0b01110101;
    test[1][0].cost=2;
    test[1][0].doors=0b00101111;
    test[2][0].cost=9;
    test[2][0].doors=0b00101100;
    test[0][1].cost=7;
    test[0][1].doors=0b11000011;
    test[1][1].cost=5;
    test[1][1].doors=0b10111100;
    test[2][1].cost=15;
    test[2][1].doors=0b01111011;
    test[0][2].cost=2;
    test[0][2].doors=0b11011100;
    test[1][2].cost=10;
    test[1][2].doors=0b01001010;
    test[2][2].cost=7;
    test[2][2].doors=0b01111010;
    test[0][3].cost=8;
    test[0][3].doors=0b11100101;
    test[1][3].cost=2;
    test[1][3].doors=0b01111001;
    test[2][3].cost=3;
    test[2][3].doors=0b10001101;
    //print_maze((sRoom *)test, 3, 4);
    //sPath *pMinPath;
    sPath *pMinPath = (sPath *)malloc(sizeof(sPath));
    //pMinPath->pPath = (sPoint *)malloc(sizeof(sPoint) * 12);
    printf("Address=%p\n",pMinPath);
    int32_t result = find_min_path((sRoom *)test, 3, 4, pMinPath);
    printf("Address=%p\n",pMinPath);
    printf("return=%d\n",result);
    printf("cost=%d\n",pMinPath->cost);
    printf("length=%d\n",pMinPath->length);

    for(int i=0;i<pMinPath->length;i++){
        printf("(%d,%d)\n",pMinPath->pPath[i].row,pMinPath->pPath[i].col);
    }


    return 0;
}