Name: 吳俊廷
Student ID: 41247032S

Warning!
all the file are base on clang compiler. please use clang to compile my files 
please Orzzzzzzzzzzzzzzz!
拜託您了偉大的助教Orzzzzzzzzz

## HW0102
Please ensure that you have regex.h when you compile the code.

## HW0104
allocate問題

## HW0105
