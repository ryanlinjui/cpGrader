#pragma once
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <regex.h>
#include <ctype.h>

// ### Input:
// + char *pExpr: the arithmetic expression.
// + int32_t base: the base that is used to show the arithmetic result. (2-16)
// ### Output:
// + char **ppResult: the arithmetic result string.
// ### Return:
// + 0: Success; 
// + -1: Error input
int32_t calculate( char *pExpr , int32_t base, char **ppResult );


//+ 將*pTocken轉換成10進位
//+ return 10進位數字
int32_t turnToDecimal(char *pTocken);

//將*pTocken轉換成其他進位(不包含10進位)
//return 0: Success; -1: Error input
int32_t decimalToOtherBase(int32_t decimal_value, int32_t base, char **ppResult);

// ## Check if *pExpr is legal
// the *ptr should follow: 
// + <Operand 1> (Operator 1) <Operand 2> (Operator 2) <Operand 3> ...
// + 運算子和運算元間必有空格
bool checkLegal( char *pExpr );