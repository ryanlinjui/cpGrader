#include "mymaze.h"

// Define the directions
const int dx[4] = {-1, 0, 1, 0};
const int dy[4] = {0, 1, 0, -1};

bool checkerBorder(int32_t col, int32_t row,int32_t maxCol, int32_t maxRow){
    if(col<0 || row<0 || col>=maxCol || row>=maxRow){
        return false;
    }
    return true;
}

bool checkDoorAccess(sRoom curRoom,sRoom nextRoom, int32_t dir){

    // 讀取目前上門的數字
    uint8_t curUpDoor = (curRoom.doors & 0b11000000) >> 6;

    // 讀取目前右門的數字
    uint8_t curRightDoor = (curRoom.doors & 0b00110000) >> 4;

    // 讀取目前下門的數字
    uint8_t curDownDoor = (curRoom.doors & 0b00001100) >> 2;

    // 讀取目前左門的數字
    uint8_t curLeftDoor = curRoom.doors & 0b00000011;

    // 讀取下一個上門的數字
    uint8_t nextUpDoor = (nextRoom.doors & 0b11000000) >> 6;

    // 讀取右門的數字
    uint8_t nextRightDoor = (nextRoom.doors & 0b00110000) >> 4;

    // 讀取下門的數字
    uint8_t nextDownDoor = (nextRoom.doors & 0b00001100) >> 2;

    // 讀取左門的數字
    uint8_t nextLeftDoor = nextRoom.doors & 0b00000011;

    if(dir==0){
        if(curUpDoor==nextDownDoor){
            return true;
        }
    }else if(dir==1){
        if(curRightDoor==nextLeftDoor){
            return true;
        }
    }else if(dir==2){
        if(curDownDoor==nextUpDoor){
            return true;
        }
    }else if(dir==3){
        if(curLeftDoor==nextRightDoor){
            return true;
        }
    }
    return false;
}

int32_t find_min_path(const sRoom *pMaze, const uint8_t row, const uint8_t col, sPath *pMinPath) {

    //sPath *pMinPathTemp=(sPath *)malloc(sizeof(sPath));
    pMinPath->pPath = (sPoint *)calloc(sizeof(sPoint) , row * col);
    
    if(pMaze==NULL || row<=0 || col<=0){
        return -1;
    }
    //printf("%d",pMaze[0].cost);
    int32_t mazeMap[row][col];

    sPoint pre[row][col];
    for(int i=0;i<row;i++){
        for(int j=0;j<col;j++){
            mazeMap[i][j]=INT_MAX;
            pre[i][j].row=-1;
            pre[i][j].col=-1;
        }
    }

    sPoint start;
    start.row=0;
    start.col=0;

    sPoint queue[row*col];
    
    //BFS
    int32_t front=0;
    int32_t rear=0;
    queue[rear++]=start;
    mazeMap[start.row][start.col]=pMaze[start.row*col+start.col].cost;
    while(front!=rear){
        
        sPoint cur=queue[front++];
        //printf("cur=%d,%d\n",cur.row,cur.col);
        for(int i=0;i<4;i++){
            int32_t newRow=cur.row+dx[i];
            int32_t newCol=cur.col+dy[i];

            if(checkerBorder(newCol,newRow,col,row) &&  checkDoorAccess(pMaze[cur.row*col+cur.col],pMaze[newRow*col+newCol],i) && mazeMap[newRow][newCol]>mazeMap[cur.row][cur.col]+pMaze[newRow*col+newCol].cost){
                mazeMap[newRow][newCol]=mazeMap[cur.row][cur.col]+pMaze[newRow*col+newCol].cost;
                pre[newRow][newCol]=cur;
                //printf("pre[%d][%d]=%d,%d\n",newRow,newCol,cur.row,cur.col);
                sPoint next;
                next.row=newRow;
                next.col=newCol;
                queue[rear++]=next;
            }
        }
    }
    if(mazeMap[row-1][col-1]==INT_MAX){
        return 0;
    }
    //printf("cost=%d\n",mazeMap[row-1][col-1]);
    
    pMinPath->cost=mazeMap[row-1][col-1];
    //printf("%d\n",pMinPathTemp->cost);
    //printf("cost=%d\n",mazeMap[row-1][col-1]);

    sPoint path[row*col];
    int32_t pathLength=0;
    sPoint cur;
    cur.row=row-1;
    cur.col=col-1;
    while(cur.row!=-1 && cur.col!=-1){
        path[pathLength++]=cur;
        cur=pre[cur.row][cur.col];
    }
    pMinPath->length=pathLength;
    pMinPath->pPath=(sPoint *)calloc(sizeof(sPoint),pathLength);
    for(int i=0;i<pathLength;i++){
        pMinPath->pPath[i]=path[pathLength-1-i];
    }
    
    //printf("Address1=%p\n",pMinPathTemp);
    //printf("Address2=%p\n",pMinPath);
    //pMinPath=pMinPathTemp;
    //printf("Address3=%p\n",pMinPath);
    return 1;
}