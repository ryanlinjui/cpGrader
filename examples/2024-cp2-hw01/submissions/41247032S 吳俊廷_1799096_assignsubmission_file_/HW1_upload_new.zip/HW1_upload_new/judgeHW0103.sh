#!/bin/bash
# Run test cases on HW0503

for loop in {0..9}; do
    echo "Test case 0$loop:"
    #./hw0501 <./testdata/test05/01/in/hw0501_0$loop.in
    ./hw0103 <./testdata/HW01/03/darrin/in/hw0103_0$loop.in > output.out
    diff ./testdata/HW01/03/darrin/out/hw0103_0$loop.out output.out
    echo
done