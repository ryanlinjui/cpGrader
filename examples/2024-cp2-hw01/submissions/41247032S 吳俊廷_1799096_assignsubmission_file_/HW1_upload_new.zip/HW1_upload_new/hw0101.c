#include <stdio.h>
#include <string.h>
#include "mystring.h"

char s='e';
char *test_string={"goodbye"};
char *ptr=NULL;
char *str1 = "ABCDEFG019874";
char *str2 = "ABCD";


int main(){
    printf("String: %s\n",test_string);
    printf("char s= %c",s);
    printf("\n================\n");

    printf("C standard strchr(): ");
    ptr=strchr(test_string,s);
    printf("%s",ptr);
    printf("\n");

    printf("my strchr()        : ");
    ptr=mystrchr(test_string,s);
    printf("%s",ptr);
    printf("\n================\n");

    printf("C standard strrchr(): ");
    ptr=strrchr(test_string,s);
    printf("%s",ptr);
    printf("\n");

    printf("my strrchr()        : ");
    ptr=mystrrchr(test_string,s);
    printf("%s",ptr);
    printf("\n================\n");

    str1 = "ABCDEFG019874";
    str2 = "ABCD";

    printf("C standard strspn(): %ld\n",strspn(str1, str2));
    printf("my strspn()        : %ld\n",mystrspn(str1, str2));
    printf("\n================\n");

    str1 = "ABCDEF4960910";
    str2 = "013";

    printf("C standard strcspn(): %ld\n",strcspn(str1, str2));
    printf("my strcspn()        : %ld\n",mystrcspn(str1, str2));
    printf("\n================\n");

    str1 = "ABCDEF4960910";
    str2 = "Z";

    printf("C standard strcspn(): %s\n",strpbrk(str1, str2));
    printf("my strcspn()        : %s\n",mystrpbrk(str1, str2));
    printf("\n================\n");

    const char haystack[20] = "RUNOOBNOdfsdfOB";
    const char needle[10] = "NOOB";

    printf("C standard strstr(): %s\n",strstr(haystack, needle));
    printf("my strstr()        : %s\n",mystrstr(haystack, needle));
    printf("\n================\n");

    char str[80] = "This is - ntnu - website";
    const char s[2] = "-";
    char *token;

    printf("C standard strtok(): %s\n",strtok(str, s));
    printf("my strtok()        : %s\n",mystrtok(str, s));
    printf("\n================\n");

}