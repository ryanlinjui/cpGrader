#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

//難易度
typedef enum _Course {
    Easy = 0,
    Normal,
    Hard,
    Oni,
    Edit,
    UNDEFINED
} Course;


typedef enum _TaikoNote { 
    BLANK = 0,
    DON,
    KA,
    BIGDON,
    BIGKA,
    DRUMROLL,
    BIGDRUMROLL,
    BALLOON,
    END,
    POTATO
} TaikoNote;

typedef struct _Measure
{
    char *chart_content;
    double bpm;
    uint64_t beat;
    uint64_t note;
} Measure;


typedef struct _Chart
{
    Course course;
    Measure *measure;
    uint64_t measure_size;
} Chart;

typedef struct _Taiko
{
    Chart *chart[5];
    double offset;
} Taiko;

double offset=0;
double bpm=-1;
int32_t beat=4;
int32_t note=4;
Course course=5;
bool inCourseNote=false;

//是否擁有該難度的譜面
bool hasCourse[5]={0};

int printCurrentVariableAll(){
    printf("DEBUG: ===printCurrentAll===\n");
    printf("DEBUG: Offset: %f\n", offset);
    printf("DEBUG: BPM: %f\n", bpm);
    printf("DEBUG: Beat: %d\n", beat);
    printf("DEBUG: Note: %d\n", note);
    printf("DEBUG: Course: %d\n", course);
    printf("DEBUG: ===End printCurrentAll===\n");
    return 0;
}
int32_t gcd(int m, int n) {
    while(n != 0) { 
        int r = m % n; 
        m = n; 
        n = r; 
    } 
    return m;
}

int32_t lcm(int m, int n) {
    //printf("DEBUG: m:%d\n",m);
    //printf("DEBUG: n:%d\n",n);
    //printf("DEBUG: gcd(m, n):%d\n",gcd(m, n));   
    //printf("DEBUG: m * n / gcd(m, n):%d\n",m * n / gcd(m, n));
    return m * n / gcd(m, n);
}

bool courseModeCheck(){
    if(course==5||bpm==-1||beat==0||note==0){
        //printf("DEBUG: Course mode check failed\n");
        return false;
    }
    //printf("DEBUG: Course mode check passed\n");
    return true;
}


int main(){
    char buffer[1024];
    Taiko chartData;
    while(fgets(buffer, sizeof(buffer), stdin) != NULL){
        
        char *found;
        found=strstr(buffer,"#START");
        if(found!=NULL){
            //printf("#START\n");
            inCourseNote=true;
        }else{
            found=strstr(buffer,"#END");
            if(found!=NULL){
                //printf("#END\n");
                inCourseNote=false;
            }else{
                found=strstr(buffer,"COURSE");
                int32_t courseInputIntTemp;//check if input is under 5
                if(found!=NULL){
                    //printf("COURSE\n");
                    if(strstr(buffer,"Easy")!=NULL){
                        //printf("DEBUG:Course: EASY\n");
                        course=Easy;
                    }else if(strstr(buffer,"Normal")!=NULL){
                        //printf("DEBUG:Course: NORMAL\n");
                        course=Normal;
                    }else if(strstr(buffer,"Hard")!=NULL){
                        //printf("DEBUG:Course: HARD\n");
                        course=Hard;
                    }else if(strstr(buffer,"Oni")!=NULL){
                        //printf("DEBUG:Course: ONI\n");
                        course=Oni;
                    }else if(strstr(buffer,"Edit")!=NULL){
                        //printf("DEBUG:Course: EDIT\n");
                        course=Edit;
                    }else if(sscanf(buffer, "COURSE:%d", &courseInputIntTemp) == 1){
                        if(courseInputIntTemp>4||courseInputIntTemp<0){
                            //printf("DEBUG:Course range error!\n");
                            return 0;
                        }
                        //printf("DEBUG:Course: %d\n", courseInputIntTemp );
                        course=courseInputIntTemp;
                    }else{
                        //printf("DEBUG:Failed to parse course\n");
                        return 0;
                    }
                    //printf("DEBUG: Final Course: %d\n", course);
                }else{
                    found=strstr(buffer,"#MEASURE");
                    if(found!=NULL){
                        //printf("#MEASURE\n");
                        if(sscanf(buffer, "#MEASURE %d/%d", &beat, &note) == 2){
                            //printf("DEBUG:Beat: %d\n", beat);
                            //printf("DEBUG:Note: %d\n", note);
                        }else{
                            //printf("DEBUG:Failed to parse measure\n");
                            return 0;
                        }
                    }else{
                        found=strstr(buffer,"#BPMCHANGE");
                        if(found!=NULL){
                            //printf("#BPMCHANGE\n");
                            if(sscanf(buffer, "#BPMCHANGE %lf", &bpm) == 1){
                                //printf("DEBUG:BPM: %f\n", bpm);
                            }else{
                                //printf("DEBUG:Failed to parse bpmchange\n");
                                return 0;
                            }
                        }else{
                            found=strstr(buffer,"OFFSET");
                            if(found!=NULL){
                                if (sscanf(buffer, "OFFSET:%lf", &offset) == 1) {
                                    chartData.offset=offset;
                                    //printf("DEBUG:Offset: %f\n", offset);
                                } else {
                                    //printf("DEBUG:Failed to parse offset\n");
                                    return 0;
                                }
                            }else{
                                found=strstr(buffer,"#END");
                                if(found!=NULL){
                                    //printf("#END\n");
                                }else{
                                    found=strstr(buffer,"BPM");
                                    if(found!=NULL){
                                        //printf("BPM\n");
                                        if (sscanf(buffer, "BPM:%lf", &bpm) == 1) {
                                            //printf("DEBUG:BPM: %f\n", bpm);
                                        } else {
                                            //printf("DEBUG:Failed to parse bpm\n");
                                            return 0;
                                        }
                                    }else{
                                        //printf("UNKNOWN\n");
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        ///DEBUG: print all variable
        //printCurrentVariableAll();


        if(inCourseNote==true){
            //check every variable is set
            if(courseModeCheck()==false){
                return 0;
            }
            hasCourse[course]=true;
            chartData.chart[course]=malloc(sizeof(Chart));
            chartData.chart[course]->course=course;
            chartData.chart[course]->measure=malloc(sizeof(Measure)*1000);
            chartData.chart[course]->measure_size=0;
            chartData.chart[course]->measure[chartData.chart[course]->measure_size].chart_content=malloc(sizeof(char)*1024);
            bool readEnd=0;
            while(readEnd==0){
                fgets(buffer, sizeof(buffer), stdin);
                if( buffer[strlen(buffer) - 1] == '\n'){
                    buffer[strlen(buffer) - 1] = '\0';
                }

                found=strstr(buffer,"#END");
                if(found!=NULL){
                    readEnd=1;
                    inCourseNote=false;
                    break;
                }

                found=strstr(buffer,"#MEASURE");
                if(found!=NULL){
                    //printf("#MEASURE\n");
                    if(sscanf(buffer, "#MEASURE %d/%d", &beat, &note) == 2){
                        //printf("DEBUG:Beat: %d\n", beat);
                        //printf("DEBUG:Note: %d\n", note);
                    }else{
                        //printf("DEBUG:Failed to parse measure\n");
                        return 0;
                    }
                }else if(strstr(buffer,"#BPMCHANGE")!=NULL){
                    //printf("#BPMCHANGE\n");
                    if(sscanf(buffer, "#BPMCHANGE %lf", &bpm) == 1){
                        //printf("DEBUG:BPM: %f\n", bpm);
                    }else{
                        //printf("DEBUG:Failed to parse bpmchange\n");
                        return 0;
                    }
                }else if((strstr(buffer,",")!=NULL)){

                    int32_t realSize=strlen(buffer)-1;
                    //printf("DEBUG:Read:%s\n",buffer);
                    //printf("DEBUG:size:%d\n",realSize);
                    
                    //DEBUG: check if only ,
                    if(strlen(buffer)==1&&buffer[0]==','){
                        //printf("DEBUG:only ,\n");
                        char temp[beat];
                        for(int i=0;i<beat;i++){
                            temp[i]='0';
                        }
                        temp[beat] = '\0';  // 確保字串結尾有 '\0'
                        strcpy(chartData.chart[course]->measure[chartData.chart[course]->measure_size].chart_content, temp);
                    }else if(realSize!=beat){
                        //Length(chart) < beat, 必須extend the length of chart content to lcm(Length(chart), beat).
                        int32_t lcm_value=lcm(strlen(buffer)-1,beat);
                        //printf("DEBUG:LCM:%d\n",lcm_value);
                        char temp[lcm_value];
                        int32_t tempIndex=0;
                        for(int i=0;i<strlen(buffer)-1;i++){
                            //printf("DEBUG:temp[%d]=%c\n",tempIndex,buffer[i]);
                            temp[tempIndex]=buffer[i];
                            tempIndex++;
                            //printf("DEBUG:j:%d\n",(lcm_value/realSize)-1);
                            for(int j=0;j<(lcm_value/realSize)-1;j++){
                                //printf("DEBUG:tempIndex:%d\n",tempIndex);
                                temp[tempIndex]='0';
                                tempIndex++;
                            }
                        }
                        //printf("DEBUG:temp:%s\n",temp);
                        temp[lcm_value] = '\0';  // 確保字串結尾有 '\0'
                        strcpy(chartData.chart[course]->measure[chartData.chart[course]->measure_size].chart_content, temp);
                    }else{
                        strcpy(chartData.chart[course]->measure[chartData.chart[course]->measure_size].chart_content, buffer);
                    }
                    //printf("DEBUG:content:%s\n",chartData.chart[course]->measure[chartData.chart[course]->measure_size].chart_content);
                    chartData.chart[course]->measure[chartData.chart[course]->measure_size].bpm=bpm;
                    chartData.chart[course]->measure[chartData.chart[course]->measure_size].beat=beat;
                    chartData.chart[course]->measure[chartData.chart[course]->measure_size].note=note;

                    chartData.chart[course]->measure_size++;
                    chartData.chart[course]->measure[chartData.chart[course]->measure_size].chart_content=malloc(sizeof(char)*1024);
                }
   
                
            }
            

        }

    }



    //PRINT JSON testdata
    // for(int i=0;i<5;i++){
    //     if(hasCourse[i]==true){
    //         printf("COURSE:%d\n",i);
    //         for(int j=0;j<chartData.chart[i]->measure_size;j++){
    //             printf("%s\n",chartData.chart[i]->measure[j].chart_content);
    //             printf("MEASURE %d/%d\n",chartData.chart[i]->measure[j].beat,chartData.chart[i]->measure[j].note);
    //             printf("BPM %f\n",chartData.chart[i]->measure[j].bpm);
    //             printf("\n");
    //         }
    //         printf("#END\n");
    //     }
    // }

    printf("{\n");
    printf("\t\"data\": [\n");

    for(int i=4;i>=0;i--){
        if(hasCourse[i]==true){
            printf("\t\t{\n");
            printf("\t\t\t\"course\": %d,\n",i);
            printf("\t\t\t\"chart\": [\n");
            double nowtime=0;
            nowtime+=fabs(chartData.offset);
            for(int j=0;j<chartData.chart[i]->measure_size;j++){
                //printf("%s\n",chartData.chart[i]->measure[j].chart_content);
                double curBeat=chartData.chart[i]->measure[j].beat;
                double curNote=chartData.chart[i]->measure[j].note;
                double curBpm=chartData.chart[i]->measure[j].bpm;
                double curLength=(double) strlen(chartData.chart[i]->measure[j].chart_content);
                // printf("DEBUG:beat:%lf\n",curBeat);
                // printf("DEBUG:note:%lf\n",curNote);
                // printf("DEBUG:bpm:%f\n",curBpm);
                // printf("DEBUG:strlen:%f\n",curLength);

                
                
                
                double duration=(60.0/curBpm)*(curBeat/curLength)*(4.0/curNote);
                //double duration_count=0;
                //printf("DEBUG:duration:%f\n",duration);
                for(int k=0;k<strlen(chartData.chart[i]->measure[j].chart_content);k++){
                    
                    //printf("%c",chartData.chart[i]->measure[j].chart_content[k]);
                    if(chartData.chart[i]->measure[j].chart_content[k]=='1'||
                    chartData.chart[i]->measure[j].chart_content[k]=='2'||
                    chartData.chart[i]->measure[j].chart_content[k]=='3'||
                    chartData.chart[i]->measure[j].chart_content[k]=='4'){
                        printf("\t\t\t\t[%c, %lf],\n",chartData.chart[i]->measure[j].chart_content[k],nowtime);
                    }
                    nowtime+=duration;
                }
                
                //printf("MEASURE %d/%d\n",chartData.chart[i]->measure[j].beat,chartData.chart[i]->measure[j].note);
                //printf("BPM %f\n",chartData.chart[i]->measure[j].bpm);
                //printf("\n");
            }
            printf("\t\t\t]\n");
            printf("\t\t},\n");

            //printf("\n");
        }
    }
    printf("\t]\n");
    printf("}\n");
    return 0;
}