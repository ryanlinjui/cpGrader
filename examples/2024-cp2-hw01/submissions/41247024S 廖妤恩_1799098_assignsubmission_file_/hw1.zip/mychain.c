#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<stdlib.h>
#include"mychain.h"

void printsTidy ( int32_t temp_size, sTidy *temp )
{
    printf ( "power : " );
    for ( int32_t i = 0 ; i < temp_size ; i ++ ) printf( "%d ",temp[i].power );
    printf ( "\n" );
    printf( "coefficents : ");
    for ( int32_t i = 0 ; i < temp_size ; i ++ ) printf( "%d ",temp[i].coe );
    printf("\n");
}

int32_t chain_rule( sPoly *pResult , const sPoly *pFy, const sPoly *pFx )
{
    //check
    if ( pFy == NULL ) return -1;
    if ( pFx == NULL ) return -1;

    sTidy pFxlist[pFx->size];
    sTidy pFylist[pFy->size];

    //transfer
    for ( int32_t i = 0 ; i < pFy->size ; i ++ )
    {
        pFylist[i].power = pFy->pPowers[i];
        pFylist[i].coe = pFy->pCoefficients[i];
    }
    for ( int32_t i = 0 ; i < pFx->size ; i ++ )
    {
        pFxlist[i].power = pFx->pPowers[i];
        pFxlist[i].coe = pFx->pCoefficients[i];
    }

    //sort
    for ( int32_t i = 0 ; i < pFx->size ; i ++ )
    {
        for ( int32_t j = i+1 ; j < pFx->size ; j ++ )
        {
            if ( pFxlist[i].power < pFxlist[j].power )
            {
                sTidy temp = pFxlist[i];
                pFxlist[i] = pFxlist[j];
                pFxlist[j] = temp;
            }
            if ( pFxlist[i].power == pFxlist[j].power )
            {
                pFxlist[j].coe += pFxlist[i].coe;
                pFxlist[i].coe = 0;
            }
        }
    }
    for ( int32_t i = 0 ; i < pFy->size ; i ++ )
    {
        for ( int32_t j = i+1 ; j < pFy->size ; j ++ )
        {
            if ( pFylist[i].power < pFylist[j].power )
            {
                sTidy temp = pFylist[i];
                pFylist[i] = pFylist[j];
                pFylist[j] = temp;
            }
            if ( pFylist[i].power == pFylist[j].power )
            {
                pFylist[j].coe += pFylist[i].coe;
                pFylist[i].coe = 0;
            }
        }
    }

    //calculate
    sTidy answer[2000];
    int32_t answer_size = 0;

    for ( int32_t i = 0 ; i < pFy->size ; i ++ )
    {   
        sTidy temp[2000];
        int32_t temp_size = 0;
        if ( pFylist[i].power == 0 ) continue;
        //transfer
        for ( int32_t k = 0 ; k < pFx->size ; k++ )
        {
            temp[temp_size].coe = pFxlist[k].coe;
            temp[temp_size].power = pFxlist[k].power;
            temp_size++;
        }
        //printsTidy ( temp_size, temp );
        for ( int32_t a = 0 ; a < pFylist[i].power-1 ; a ++ ) 
        {
            sTidy temp2[2000];
            int32_t temp2_size = 0;
            for ( int32_t j = 0 ; j < pFx->size ; j ++ )
            {
                for ( int32_t k = 0 ; k < temp_size ; k++ )
                {
                    //calculate
                    int32_t tempp, tempc, new = 1;
                    tempp = pFxlist[j].power + temp[k].power;
                    tempc = pFxlist[j].coe * temp[k].coe;
                    //printf ( "%d %d %d \n", k, tempp, tempc );
                    for ( int32_t l = 0 ; l < temp2_size ; l ++ )
                    {
                        if ( temp2[l].power == tempp )
                        {
                            temp2[l].coe += tempc;
                            new = 0;
                            break;
                        }
                    }
                    if ( new == 1 ) 
                    {
                        temp2[temp2_size].power = tempp;
                        temp2[temp2_size].coe = tempc;
                        temp2_size++;
                        answer_size++;
                    }
                }
                //printsTidy ( temp2_size, temp2 );
            }
            for ( int32_t i = 0 ; i < temp2_size ; i ++ ) temp[i] = temp2[i];
            temp_size = temp2_size;
            //for ( int32_t i = 0 ; i < temp_size ; i ++ ) temp[i].coe *= pFylist[i].coe;
            //printsTidy( temp_size, temp);
        }
        for ( int32_t g = 0 ; g < temp_size ; g ++ ) temp[g].coe *= pFylist[i].coe;
        //printsTidy( temp_size, temp );
        //save to ans
        for ( int32_t g = 0 ; g < temp_size ; g ++ )
        {
            int32_t found = 0;
            for ( int32_t h = 0 ; h < answer_size ; h ++ )
            {
                if ( temp[g].power == answer[h].power )
                {
                    answer[h].coe += temp[g].coe;
                    found = 1;
                    break;
                }
            }
            if ( found == 0 )
            {
                answer[answer_size].power = temp[g].power;
                answer[answer_size].coe = temp[g].coe;
                answer_size++;
            }
        }
        //printsTidy( answer_size, answer );
    }
    sTidy real_answer[200];
    int32_t real_answer_size = 0;
    for ( int32_t i = 0 ; i < answer_size ; i ++ )
    {
        if ( answer[i].coe != 0 )
        {
            real_answer[real_answer_size].power = answer[i].power;
            real_answer[real_answer_size].coe = answer[i].coe;
            real_answer_size++;
        }
    }
    //printsTidy ( real_answer_size, real_answer );
    //sort
    for ( int32_t i = 0 ; i < real_answer_size ; i ++ )
    {
        for ( int32_t j = i + 1 ; j < real_answer_size ; j ++ )
        {
            if ( real_answer[i].power < real_answer[j].power )
            {
                sTidy temp = real_answer[i];
                real_answer[i] = real_answer[j];
                real_answer[j] = temp;
            }
        }
    }
    //printsTidy ( real_answer_size, real_answer );
    //wei
    int32_t zero = 0;
    for ( int32_t i = 0 ; i < real_answer_size ; i ++ )
    {
        if ( real_answer[i].power == 0 ) zero++;
        real_answer[i].coe *= real_answer[i].power;
        real_answer[i].power--;
    }
    //printf("wei: \n");
    //printsTidy ( real_answer_size, real_answer );

    //save answer
    sPoly return_poly;
    return_poly.size = real_answer_size-zero;
    return_poly.pCoefficients = calloc ( real_answer_size-zero, sizeof(int32_t) );
    return_poly.pPowers = calloc ( real_answer_size-zero, sizeof(uint32_t) );
    for ( int32_t i = 0 ; i < real_answer_size-zero ; i ++ )
    {
        return_poly.pCoefficients[i] = real_answer[i].coe;
        return_poly.pPowers[i] = real_answer[i].power;
    }
    *pResult = return_poly;

    //print
    /*for ( int32_t i = 0 ; i < pFx->size ; i ++ )
    {
        printf ("power: %d  coe: %d\n", pFxlist[i].power, pFxlist[i].coe );
    }*/
    return 0;
}