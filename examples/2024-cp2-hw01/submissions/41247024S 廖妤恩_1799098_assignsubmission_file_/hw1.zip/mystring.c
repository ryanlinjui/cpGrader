#include<stdio.h>
#include<stdint.h>
#include"mystring.h"

int32_t length_of_string ( const char *target_string )
{
   int32_t idx = 0;
   while ( *(target_string+idx) != 0) idx ++;
   return idx;
}

char *mystrchr(const char *s, int c)
{
    while ( *s != '\0' )
    {
        if ( *s == c ) return ( char *)s;
        s++;
    }
    return NULL;
}

char *mystrrchr(const char *s, int c)
{
    const char *pptr = s + length_of_string(s) - 1;
    while ( pptr >= s )
    {
        if ( *pptr == c ) return ( char *)pptr;
        pptr--;
    }
    return NULL;
}

size_t mystrspn(const char *s, const char *accept)
{
    size_t count = 0;
    const char *ptr_s = s;
    const char *ptr_accept;
    while ( *ptr_s != '\0' ) 
    { 
        ptr_accept = accept;
        while ( *ptr_accept != '\0') 
        {
            if ( *ptr_s == *ptr_accept ) 
            {
                count++;
                break;
            }
            ptr_accept++;
        }
        if ( *ptr_accept == '\0' ) break;
        ptr_s++;
    }
    return count;
}

size_t mystrcspn(const char *s, const char *reject)
{
    size_t count = 0;
    const char *ptr_s = s;
    const char *ptr_reject;
    while ( *ptr_s != '\0' )
    {
        ptr_reject = reject;
        while ( *ptr_reject != '\0' )
        {
            if ( *ptr_reject == *ptr_s ) return count;
            ptr_reject++;
        }
        count++;
        ptr_s++;
    }
    return count;
}

char *mystrpbrk(const char *s, const char *accept)
{
    const char *ptr_s = s;
    const char *ptr_acp;
    while ( *ptr_s != '\0' )
    {
        ptr_acp = accept;
        while ( *ptr_acp != '\0' )
        {
            if ( *ptr_acp == *ptr_s ) return ( char *)ptr_s;
            ptr_acp++;
        }
        ptr_s++;
    }
    return NULL;
}

char *mystrstr(const char *haystack , const char *needle)
{
    const char *ptr_hay = haystack;
    const char *ptr_need;
    int32_t count = 0;
    int32_t length = length_of_string(needle);
    while( *ptr_hay != '\0' )
    {
        count = 0;
        ptr_need = needle;
        while( *ptr_hay != '\0' && *ptr_need != '\0' && *ptr_hay == *ptr_need )
        {
            ptr_hay++;
            ptr_need++;
            count++;
        }
        if ( count == length ) return(char*)(ptr_hay-length);
        ptr_hay++;
    }
    return NULL;
}

char *save = NULL;
char *start;

char *mystrtok(char *str, const char *delim)
{
    //char *save = NULL;
    //char *start;
    if( str != NULL ) save = str;
    else start = save;
    start = save;
    char *ptr_str = start;
    const char *ptr_deli;
    int32_t length = length_of_string(delim);
    int32_t count = 0;
    while ( *ptr_str != '\0' )
    {
        count = 0;
        ptr_deli = delim;
        while ( *ptr_str != '\0' && *ptr_deli != '\0' && *ptr_deli == *ptr_str )
        {
            count++;
            ptr_str++;
            ptr_deli++;
        }
        if ( count == length )
        {
            *(ptr_str-length) = '\0';
            save = ptr_str+length;
            if ( str != NULL ) return (char *)start;
            else return (char *)(start-length);
        }
        ptr_str++;
    }
    //save = NULL;
    return NULL;
}