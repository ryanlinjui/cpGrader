#ifndef MYCAL_H
#define MYCAL_H
#include<stdio.h>
#include<string.h>
#include<stdint.h>

int32_t calculate( char *pExpr , int32_t base, char **ppResult );

#endif