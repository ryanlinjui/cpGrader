#include<stdio.h>
#include<stdint.h>
#include"mymaze.h"

static int32_t saveroute[10000][2];
static int32_t r,c;
static uint32_t answer_cost = 4294967295;
static uint32_t answer_length = 0;
static sPoint *paths; 

void visit ( int32_t i, int32_t j, int32_t maze[r][c][5], uint32_t l, uint32_t w, sPoint *n, int32_t q )
{
    if ( w > answer_cost ) return;
    if ( i == r-1 && j == c-1 )
    {
        answer_cost = w;
        answer_length = l;
        paths = n;
        return;
    }
    if ( maze[i][j][1] > 0 && q != 3 && i > 0 )
    {
        sPoint *rn = calloc ( l+1, sizeof(sPoint) );
        for ( int32_t a = 0 ; a < l ; a ++ ) rn[a] = n[a];
        rn[l].row = i-1;
        rn[l].col = j;
        visit ( i-1, j, maze, l+1, w+maze[i-1][j][0], rn, 1 );
    }
    if ( maze[i][j][2] > 0 && q != 4 && j < c - 1 )
    {
        sPoint *rn = calloc ( l+1, sizeof(sPoint) );
        for ( int32_t a = 0 ; a < l ; a ++ ) rn[a] = n[a];
        rn[l].row = i;
        rn[l].col = j+1;
        visit ( i, j+1, maze, l+1, w + maze[i][j+1][0], rn, 2 );
    }
    if ( maze[i][j][3] > 0 && q != 1 && i < r - 1 )
    {
        //printf("?");
        sPoint *rn = calloc ( l+1, sizeof(sPoint) );
        for ( int32_t a = 0 ; a < l ; a ++ ) rn[a] = n[a];
        rn[l].row = i+1;
        rn[l].col = j;
        //printf("%d %d",i,j);
        visit ( i+1, j, maze, l+1, w+maze[i+1][j][0], rn, 3 );
    }
    if ( maze[i][j][4] > 0 && q != 2 && j > 0 )
    {
        sPoint *rn = calloc ( l+1, sizeof(sPoint) );
        for ( int32_t a = 0 ; a < l ; a ++ ) rn[a] = n[a];
        rn[l].row = i;
        rn[l].col = j-1;
        visit ( i, j-1, maze, l+1, w+maze[i][j-1][0], rn, 4 );
    }
}

int32_t dtb ( int32_t num, int32_t index )
{
    int32_t save[8] = {-1};
    int32_t x = 0;
    int32_t y = 0;
    int32_t i = 0;
    while ( num > 0 ) 
    {
        save[i] = num % 2;
        num = num / 2;
        i++;
    }
    for ( int32_t j = 0 ; j < 8 ; j ++ )
    {
        if ( save[i] == -1 ) save[i] = 0;
    }
    if ( index == 1 ) 
    {
        x = save[7];
        y = save[6];
    }
    else if ( index == 2 )
    {
        x = save[5];
        y = save[4];
    }
    else if ( index == 3 )
    {
        x = save[3];
        y = save[2];
    }
    else
    {
        x = save[1];
        y = save[0];
    }
    return x*2+y*1;
}

int32_t find_min_path ( const sRoom *pMaze , const uint8_t row, const uint8_t col, sPath *pMinPath )
{   
    int32_t secondmaze[row][col][5];
    r = row;
    c = col;
    int32_t firstmaze[row][col][5];
    //save cost
    int32_t k = 0;
    for ( int32_t i = 0 ; i < row ; i ++ )
    {
        for ( int32_t j = 0 ; j < col ; j ++ )
        {
            firstmaze[i][j][0] = pMaze[k].cost;
            k++;
        }
    }
    k = 0;
    //save door
    int32_t doornum[row][col];
    for ( int32_t i = 0 ; i < row ; i ++ )
    {
        for ( int32_t j = 0 ; j < col ; j ++ )
        {
            doornum[i][j] = pMaze[k].doors;
            k++;
        }
    }
    k = 0;
    for ( int32_t i = 0 ; i < row ; i ++ )
    {
        for ( int32_t j = 0 ; j < col ; j ++ )
        {
            for ( int32_t h = 1 ; h <= 4 ; h ++ )
            {
                int32_t a = doornum[i][j];
                firstmaze[i][j][h] = dtb ( a, h );
                //printf( "%d ", firstmaze[i][j][h] );
            }
            //printf("\n");
        }
    }
    //which door can't
    for ( int32_t i = 0 ; i < row ; i ++ )
    {
        for ( int32_t j = 0 ; j < col ; j ++ )
        {
            for ( int32_t h = 1 ; h <= 4 ; h ++ )
            {
                secondmaze[i][j][h] = -1;
            }
        }
    }
    k = 0;
    for ( int32_t i = 0 ; i < row ; i ++ )
    {
        for ( int32_t j = 0 ; j < col ; j ++ )
        {
            secondmaze[i][j][0] = pMaze[k].cost;
            k++;
        }
    }
    for ( int32_t i = 0 ; i < row-1 ; i ++ )
    {
        for ( int32_t j = 0 ; j < col ; j ++ )
        {
            if ( firstmaze[i][j][3] == firstmaze[i+1][j][1] )
            {
                secondmaze[i][j][3] = 1;
                secondmaze[i+1][j][1] = 1;
            }
        } 
    }
    for ( int32_t i = 0 ; i < row ; i ++ )
    {
        for ( int32_t j = 0 ; j < col-1 ; j ++ )
        {
            if ( firstmaze[i][j][2] == firstmaze[i][j+1][4] )
            {
                secondmaze[i][j][2] = 1;
                secondmaze[i][j+1][4] = 1;
            }
        }
    }
    sPath answer;
    sPoint *temp = calloc( 1, sizeof(sPoint) );
    temp[0].row = 0;
    temp[0].col = 0;

    visit ( 0, 0, secondmaze, 1, secondmaze[0][0][0], temp, -1 );
    //printf("?");
    *pMinPath = answer;
    pMinPath->cost = answer_cost;
    pMinPath->length = answer_length;
    pMinPath->pPath = paths;
    if(pMinPath->length) return 1;
    return 0;
}