#ifndef MYCHAIN_H
#define MYCHAIN_H
#include<stdio.h>
#include<stdint.h>

typedef struct _sPoly
{
    uint32_t size;
    uint32_t *pPowers;
    int32_t *pCoefficients;
} sPoly;

typedef struct _sTidy
{
    uint32_t power;
    int32_t coe;
} sTidy;

int32_t chain_rule( sPoly *pResult , const sPoly *pFy, const sPoly *pFx );

#endif