#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<stdlib.h>
#include"mycal.h"

int32_t calculate ( char *pExpr, int32_t base, char **ppResult )
{
    int32_t length = strlen(pExpr);
    //printf( "%d\n", length );
    int32_t symbolcount = 0;
    int32_t multicount = 0;
    while ( *pExpr != '\0' )
    {
        if ( *pExpr == '+' || *pExpr == '-' || *pExpr == '*' ) symbolcount++;
        if ( *pExpr == '*' ) multicount++;
        pExpr++;   
    }
    //printf ( "symbol: %d\n", symbolcount );
    pExpr-=length;
    //check
    //symbol
    while ( *pExpr != '\0' )
    {
        if ( *pExpr != 48 && *pExpr != 49 && *pExpr != 50 && *pExpr != 51 && *pExpr != 52 && *pExpr != 53 && *pExpr != 54 && *pExpr != 55 && *pExpr != 56 && *pExpr != 57 && *pExpr != 65 && *pExpr != 66 && *pExpr != 67 && *pExpr != 68 && *pExpr != 69 && *pExpr != 70 && *pExpr != 32 && *pExpr != 42 && *pExpr != 43 && *pExpr != 45 && *pExpr != 95 ) return -1;
        pExpr++;
    }
    pExpr-=length;
    //space+save
    char sym[symbolcount];
    int32_t i = 0;
    while ( *pExpr != '\0' )
    {
        if ( *pExpr == '+' || *pExpr == '-' || *pExpr == '*' )
        {
            sym[i] = *pExpr;
            i++;       
            if ( *(pExpr+1) != ' ' || *(pExpr-1) != ' ' ) return -1;
        }
        pExpr++;
    }
    pExpr-=length;
    //for ( i = 0 ; i < symbolcount ; i ++ ) printf ( "%c ", sym[i] );
    //save number
    int32_t basesave[symbolcount+1];
    i = 0;
    while ( *pExpr != '\0' )
    {
        if ( *pExpr == '_' && *(pExpr+2) != ' ' && *(pExpr+2) != '\0' )
        {
            basesave[i] = 10+(*(pExpr+2)-48);
            if ( basesave[i] < 2 || basesave[i] > 16 ) return -1;
            i++;
        }
        else if ( *pExpr == '_' )
        {
            basesave[i] = *(pExpr+1)-48;
            if ( basesave[i] < 2 || basesave[i] > 16 ) return -1;
            i++;
        }
        pExpr++;
    }
    pExpr-=length;
    i = 0;
    int32_t total = 0;
    int32_t firstnum[symbolcount+1];
    while ( *pExpr != '\0' )
    {
        if ( *pExpr == '_' )
        {
            firstnum[i] = total;
            i++;
            total = 0;
            pExpr+=2;
            continue;
        }
        else if ( *pExpr == ' ' || *pExpr == '+' || *pExpr == '-' || *pExpr == '*' ) 
        {
            total = 0;
            pExpr++;
            continue;
        }
        if ( *pExpr >= 'A' && *pExpr <= 'F' ) total = total*basesave[i]+(*pExpr-'A'+10);
        else total = total*basesave[i]+(*pExpr-'0');
        pExpr++;
    }
    pExpr-=length;
    //multi
    i = 0;
    for ( i = 0 ; i < symbolcount ; i ++ )
    {
        if ( sym[i] == '*' )
        {
            firstnum[i+1] = firstnum[i]*firstnum[i+1];
            firstnum[i] = -1;
        }
    }
    //for ( i = 0 ; i < symbolcount+1 ; i ++ ) printf ( "%d \n", firstnum[i] );

    //plus minus
    char truesym[symbolcount-multicount];
    i = 0;
    for ( int32_t j = 0 ; j < symbolcount ; j ++ )
    {
        if ( sym[j] == '*' ) continue;
        else 
        {
            truesym[i] = sym[j];
            i++;
        }
    }
    //for ( i = 0 ; i < symbolcount-multicount ; i ++ ) printf ( "%c \n", truesym[i] );

    //delete
    i = 0;
    int32_t truenum[symbolcount-multicount+1];
    for ( int32_t j = 0 ; j < symbolcount + 1 ; j ++ )
    {
        if ( firstnum[j] != -1 )
        {
            truenum[i] = firstnum[j];
            i++;
        }
        else continue;
    }
    //for ( int32_t j = 0 ; j < symbolcount - multicount + 1 ; j ++ ) printf( "%d\n", truenum[j] );

    //calculate
    int32_t ans = truenum[0];
    for ( int32_t j = 0 ; j < symbolcount-multicount ; j ++ )
    {
        if ( truesym[j] == '+' )
        {
            ans = ans + truenum[j+1];
        }
        else if ( truesym[j] == '-' )
        {
            ans = ans - truenum[j+1];
        }
    }
    //printf( "ans: %d\n", ans );
    int32_t fu = 0;
    if ( ans < 0 ) 
    {
        fu = 1;
        ans*=-1;
    }
    char ansconvert[1000] = {0};
    i = 0;
    int32_t length_of_ans = 0;
    while ( ans > 0 ) 
    {
        int32_t rem = ans % base;
        if ( rem < 10 ) ansconvert[i] = rem + '0';
        else ansconvert[i] = rem + 55;
        i++;
        length_of_ans++;
        ans /= base;
    }
    /*
    for ( int32_t j = length_of_ans-1 ; j >= 0 ; j -- ) 
    {
        printf( "%c ", ansconvert[j] );
    }*/
    i = 0;
    if ( base >= 10 )
    {
        char realans[length_of_ans+fu+3];
        if ( fu == 1 )
        {
            i = 1;
            realans[0] = '-';
        }
        for ( int32_t j = length_of_ans-1 ; j >= 0 ; j -- )
        {
            realans[i] = ansconvert[j];
            i++;
        }
        realans[i] = '_';
        i++;
        realans[i] = '1';
        i++;
        realans[i] = base%10+'0';
        /*
        for ( int32_t j = 0 ; j < length_of_ans+fu+3 ; j ++ )
        {
            printf ( "%c", realans[j] );
        }*/
        char *ptr_ans = calloc( length_of_ans+fu+3, sizeof(char) );
        for ( i = 0 ; i < length_of_ans + fu + 3 ; i ++ ) ptr_ans[i] = realans[i];
        *ppResult = ptr_ans;
    }
    else
    {
        char realans[length_of_ans+fu+2];
        if ( fu == 1 )
        {
            i = 1;
            realans[0] = '-';
        }
        for ( int32_t j = length_of_ans-1 ; j >= 0 ; j -- )
        {
            realans[i] = ansconvert[j];
            i++;
        }
        realans[i] = '_';
        i++;
        realans[i] = base%10+'0';
        /*for ( int32_t j = 0 ; j < length_of_ans+fu+2 ; j ++ )
        {
            printf ( "%c", realans[j] );
        }*/
        char *ptr_ans = calloc( length_of_ans+fu+2, sizeof(char) );
        for ( i = 0 ; i < length_of_ans + fu + 2 ; i ++ ) ptr_ans[i] = realans[i];
        *ppResult = ptr_ans;
    }
    return 0;
}