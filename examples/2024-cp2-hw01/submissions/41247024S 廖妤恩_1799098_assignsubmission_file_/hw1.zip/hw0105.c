#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

int main ()
{
    char *input = calloc ( 1000, sizeof(char) );
    float bpm = 0;
    float offset = 0;
    int32_t course = 5;
    uint32_t beat = 4;
    uint32_t note = 4;
    while ( fgets ( input, 1000*sizeof(char), stdin ) != NULL )
    {
        if ( input [ strlen(input) - 1 ] == 10 ) input [ strlen(input) - 1 ] = 0;
        //bpm
        if ( *input == 'B' && *(input+1) == 'P' && *(input+2) == 'M' && *(input+3) == ':' )
        {
            bpm = strtod ( input+4, NULL );
            //printf ("bpm: %lf\n", bpm);
        }

        //offset
        if ( *input == 'O' && *(input+1) == 'F' && *(input+2) == 'F' && *(input+3) == 'S' && *(input+4) == 'E' && *(input+5) == 'T' && *(input+6) == ':' )
        {
            offset = strtod ( input+7, NULL );
            //printf ("offset: %lf\n", offset);
        }

        //course
        if ( *input == 'C' && *(input+1) == 'O' && *(input+2) == 'U' && *(input+3) == 'R' && *(input+4) == 'S' && *(input+5) == 'E' && *(input+6) == ':' )
        {
            input += 7;
            if ( *input == 'E' && *(input+1) == 'a' && *(input+2) == 's' && *(input+3) == 'y' ) course = 0;
            if ( *input == 'N' && *(input+1) == 'o' && *(input+2) == 'r' && *(input+3) == 'm' && *(input+4) == 'a' && *(input+5) == 'l' ) course = 1;
            if ( *input == 'H' && *(input+1) == 'a' && *(input+2) == 'r' && *(input+3) == 'd' ) course = 2;
            if ( *input == 'O' && *(input+1) == 'n' && *(input+2) == 'i' ) course = 3;
            if ( *input == 'E' && *(input+1) == 'd' && *(input+2) == 'i' && *(input+3) == 't' ) course = 4;
            printf ("course: %d\n", course);
        }

        //start
        if ( *input == '#' && *(input+1) == 'S' && *(input+2) == 'T' && *(input+3) == 'A' && *(input+4) == 'R' && *(input+5) == 'T' )
        {
            char *chart = calloc ( 1000, sizeof(char) );
            float time = -1*offset;
            float duration = 0;
            int32_t count = 0;
            while ( fgets ( chart, 1000*sizeof(char), stdin ) != NULL )
            {
                if ( *chart == '#' && *(chart+1) == 'E' && *(chart+2) == 'N' && *(chart+3) == 'D' ) break;
                //measure
                else if ( *chart == '#' && *(chart+1) == 'M' && *(chart+2) == 'E' && *(chart+3) == 'A' && *(chart+4) == 'S' && *(chart+5) == 'U' && *(chart+6) == 'R' && *(chart+7) == 'E' && *(chart+8) == ' ' )
                {
                    chart += 9;
                    beat = 0;
                    note = 0;
                    while ( *chart != '/' )
                    {
                        beat = beat*10 + *chart - '0';
                        chart++;
                    }
                    //printf ( "%d\n", beat );
                    chart ++;
                    while ( isdigit(*chart) )
                    {
                        note = note*10 + *chart - '0';
                        chart++;
                    }
                    //printf ( "%d\n", note );
                }
                //bpm change
                else if ( *chart == '#' && *(chart+1) == 'B' && *(chart+2) == 'P' && *(chart+3) == 'M' && *(chart+4) == 'C' && *(chart+5) == 'H' && *(chart+6) == 'A' && *(chart+7) == 'N' && *(chart+8) == 'G' && *(chart+9) == 'E' && *(chart+10) == ' ' )
                {
                    bpm = strtod ( chart+11, NULL );
                }
                //output
                else
                {
                    int32_t length = 0;
                    while ( isdigit(chart[length]) ) length++;
                    //printf("%d",length);
                    //printf("%d\n", length);
                    int32_t a = 1;
                    if ( length < beat )
                    {
                        int32_t b = beat;
                        while ( b%length + b%beat ) b++;
                        a = b/length;
                    }
                    duration = (60/bpm)*beat/length*4/note*a;
                    while ( isdigit(*chart) )
                    {
                        if ( *chart >= 1 || *chart <= 4 ) printf( "[%c, %.6lf]\n", *chart, time );
                        time += duration;
                        chart++;
                    }
                }
            }
            free ( chart );
        }
    }
    free ( input );
}