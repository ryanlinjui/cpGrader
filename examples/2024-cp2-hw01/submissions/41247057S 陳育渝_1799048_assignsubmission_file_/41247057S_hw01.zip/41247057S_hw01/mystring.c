#include <stdio.h>
#include <stdint.h>
#include <string.h>

//avoid NULL

char *mystrchr(const char *s, int c){
    int32_t length = strlen(s);
    for (int32_t i = 0; i < length; i++){
        if (s[i] == c){
            return (char *)s+i;
        }
    }
    return NULL;
}

char *mystrrchr(const char *s, int c){
    int32_t RETURN = 0;
    int32_t i = 0;
    while(s[i] != '\0'){
        if (s[i] == c){
            RETURN = c;
        }
        i++;
    }
    if (RETURN != 0){
        return (char *)s+RETURN;
    }
    else{
        return NULL;
    }
}

size_t mystrspn(const char *s, const char *accept){
    int32_t i = 0;
    while(s[i] == accept[i] && s[i] != '\0' && accept[i] != '\0'){
        i++;
    }
    return i;
}

size_t mystrcspn(const char *s, const char *reject){
    int32_t i = 0;
    while(s[i] != reject[i] && s[i] != '\0' && reject[i] != '\0'){
        i++;
    }
    return i;
}

char *mystrpbrk(const char *s, const char *accept){
    int32_t len_s = strlen(s);
    int32_t len_accept = strlen(accept);
    for (int32_t i = 0; i < len_s; i++){
        for (int32_t j = 0; j < len_accept; j++){
            if (s[i] == accept[j]){
                return (char *)s+i;
            }
        }
    }
    return NULL;
}

char *mystrstr(const char *haystack, const char *needle){
    int32_t i = 0;
    int32_t length = strlen(needle);
    int32_t check = 0;
    while(haystack[i] != '\0'){
        if (haystack[i] == needle[0]){
            for (int32_t j = 0; j < length; j++){
                if (haystack[i+j] != needle[j]){
                    check = -1;
                    break;
                }
            }
            if (check == 0){
                return (char *)haystack+i;
            }
            check = 0;
        }
        i++;
    }
    return NULL;
}

char *mystrtok(char *str, const char *delim){
    int32_t i = 0;
    int32_t length = strlen(delim);
    while(str[i] != '\0'){
        for (int32_t j = 0; j < length; j++){
            if (str[i] == delim[j]){
                return (char *)str+i;
            }
        }
        i++;
    }
    return NULL;
}