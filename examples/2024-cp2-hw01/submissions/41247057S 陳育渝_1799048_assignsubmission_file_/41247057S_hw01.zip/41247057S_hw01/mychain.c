#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "mychain.h"

int32_t chain_rule( sPoly *pResult, const sPoly *pFy, const sPoly *pFx ){

    //check the memory NULL or not
    if (pFy == NULL || pFx == NULL){
        return -1;
    }

    //copy
    sPoly y;
    y.size = pFy->size;
    y.pPowers = calloc(y.size, sizeof(uint32_t));
    y.pCoefficients = calloc(y.size, sizeof(int32_t));
    for (int32_t i = 0; i < y.size; i++){
        y.pPowers[i] = pFy->pPowers[i];
        y.pCoefficients[i] = pFy->pCoefficients[i];
    }
    sPoly x;
    x.size = pFx->size;
    x.pPowers = calloc(x.size, sizeof(uint32_t));
    x.pCoefficients = calloc(x.size, sizeof(int32_t));
    for (int32_t i = 0; i < x.size; i++){
        x.pPowers[i] = pFx->pPowers[i];
        x.pCoefficients[i] = pFx->pCoefficients[i];
        //printf("%d %d\n", x.pPowers[i], x.pCoefficients[i]);
    }

    //sort input(升冪)
    for (int32_t i = 0; i < y.size; i++){
        for (int32_t j = 0; j < y.size-1; j++){
            if (y.pPowers[j] > y.pPowers[j+1]){
                uint32_t temp1 = y.pPowers[j];
                int32_t temp2 = y.pCoefficients[j];
                y.pPowers[j] = y.pPowers[j+1];
                y.pCoefficients[j] = y.pCoefficients[j+1];
                y.pPowers[j+1] = temp1;
                y.pCoefficients[j+1] = temp2;
            }
        }
    }

    for (int32_t i = 0; i < x.size; i++){
        for (int32_t j = 0; j < x.size-1; j++){
            if (x.pPowers[j] > x.pPowers[j+1]){
                uint32_t temp1 = x.pPowers[j];
                int32_t temp2 = x.pCoefficients[j];
                x.pPowers[j] = x.pPowers[j+1];
                x.pCoefficients[j] = x.pCoefficients[j+1];
                x.pPowers[j+1] = temp1;
                x.pCoefficients[j+1] = temp2;
            }
        }
    }

    int32_t max_deg = (x.pPowers[x.size-1])*(y.pPowers[y.size-1])-1;

    //set pResult
    pResult->size = max_deg+1;
    pResult->pPowers = calloc(pResult->size, sizeof(uint32_t));
    pResult->pCoefficients = calloc(pResult->size, sizeof(int32_t));
    for (int32_t i = 0; i < pResult->size; i++){
        pResult->pPowers[i] = i;
    }

    //calculus f(y) 升冪ver.
    for (int32_t i = y.size-1; i >= 0; i--){
        y.pCoefficients[i] *= y.pPowers[i];
        y.pPowers[i]--;
    }

    //把y移位
    if (y.pPowers[0] > y.pPowers[y.size-1]){
        for (int32_t i = 1; i <= y.size-1; i++){
            y.pCoefficients[i-1] = y.pCoefficients[i];
            y.pPowers[i-1] = y.pPowers[i];
        }
        y.size--;
    }

    if (y.pPowers[0] == 0){
        pResult->pCoefficients[0] = y.pCoefficients[0];
    }
    if (y.pPowers[0] == 1){
        for (int32_t i = 0; i < x.size; i++){
            pResult->pPowers[x.pPowers[i]] = x.pPowers[i];
            pResult->pCoefficients[pResult->pPowers[x.pPowers[i]]] += y.pCoefficients[0] * x.pCoefficients[i];
        }
    }
    else if (y.pPowers[1] == 1){
        for (int32_t i = 0; i <= x.size; i++){
            pResult->pPowers[x.pPowers[i]] = x.pPowers[i];
            pResult->pCoefficients[pResult->pPowers[x.pPowers[i]]] += y.pCoefficients[1] * x.pCoefficients[i];
            //printf("%d %d %d\n", pResult->pCoefficients[i], x.pCoefficients[i], i);
        }
    }

    //把x帶進y
    int32_t result_size = x.pPowers[x.size-1]*y.pPowers[y.size-1]+1;
    int32_t ans[result_size];
    int32_t temp[result_size];

    for (int32_t n = 0; n < y.size; n++){
        if (y.pPowers[n] <= 1){
            continue;
        }
        //算出(ax+b)^n
        for (int32_t i = 0; i < result_size; i++){
            ans[i] = 0;
        }
        for (int32_t i = 0; i <= x.pPowers[x.size-1]; i++){
            temp[i] = x.pCoefficients[i];
        }
        for (int32_t i = x.pPowers[x.size-1]+1; i < result_size; i++){
            temp[i] = 0;
        }

        for (int32_t i = 0; i < result_size; i++){
            // printf("%d\n", temp[i]);
        }

        for (int32_t i = 1; i < y.pPowers[n]; i++){
            for (int32_t j = 0; j < x.size*i; j++){
                for (int32_t k = 0; k < x.size; k++){
                    ans[x.pPowers[j]+x.pPowers[k]] += temp[j] * x.pCoefficients[k];
                    // printf("%d += %d * %d\n", ans[x.pPowers[j]+x.pPowers[k]], temp[j] ,x.pCoefficients[k]);
                    // printf("[%d] += [%d] * [%d]\n", x.pPowers[j]+x.pPowers[k], x.pPowers[j], x.pPowers[k]);
                }
            }
            for (int32_t j = 0; j <= x.pPowers[x.size-1]*y.pPowers[n] && i < y.pPowers[n]-1; j++){
                temp[j] = ans[j];
                ans[j] = 0;
            }
        }
        //乘係數
        for (int32_t i = 0; i <= x.pPowers[x.size-1]*y.pPowers[n]; i++){
            ans[i] *= y.pCoefficients[n];
            // printf("%d ", ans[i]);
        }
        // printf("\n");

        for (int32_t i = 0; i <= x.pPowers[x.size-1]*y.pPowers[n]; i++){
            pResult->pCoefficients[i] += ans[i];
            pResult->pPowers[i] = i;
        }
        for (int32_t i = 0; i < result_size; i++){
            // printf("%d %d\n", pResult->pCoefficients[i], pResult->pPowers[i]);
        }
    }
    //calculas f(x) 升冪ver.
    for (int32_t i = 0; i < x.size; i++){
        //printf("%d %d %d\n", x.pCoefficients[i], x.pPowers[i], i);
    }
    for (int32_t i = x.size-1; i >= 0; i--){
        x.pCoefficients[i] *= x.pPowers[i];
        x.pPowers[i]--;
    }

    if (x.pPowers[0] > x.pPowers[x.size-1]){
        for (int32_t i = 1; i <= x.size-1; i++){
            x.pCoefficients[i-1] = x.pCoefficients[i];
            x.pPowers[i-1] = x.pPowers[i];
        }
        x.size--;
    }
    for (int32_t i = 0; i < x.size; i++){
        //printf("%d %d %d\n", x.pCoefficients[i], x.pPowers[i], i);
    }

    //result * f'(x)
    int32_t tmp[pResult->size];
    for (int32_t i = 0; i < result_size; i++){
        tmp[i] = pResult->pCoefficients[i];
        pResult->pCoefficients[i] = 0;
    }
    for (int32_t i = result_size; i < pResult->size; i++){
        tmp[i] = 0;
    }

    for (int32_t i = 0; i < result_size; i++){
        for (int32_t j = 0; j < x.size; j++){
            pResult->pCoefficients[pResult->pPowers[i]+x.pPowers[j]] += tmp[i] * x.pCoefficients[j];
            // printf("%d += %d * %d\n", pResult->pCoefficients[pResult->pPowers[i]+x.pPowers[j]], tmp[i] ,x.pCoefficients[j]);
            // printf("[%d] += [%d] * [%d]\n", pResult->pPowers[i]+x.pPowers[j], i, j);
        }
    }

    //轉成降冪
    int32_t TEMP[pResult->size];
    for (int32_t i = 0; i <= max_deg; i++){
        TEMP[i] = pResult->pCoefficients[max_deg-i];
        pResult->pPowers[i] = max_deg-i;
    }
    int32_t index = 0;
    for (int32_t i = 0; i <= max_deg; i++){
        if (TEMP[i] != 0){
            pResult->pCoefficients[index] = TEMP[i];
            pResult->pPowers[index] = max_deg-i;
            index++;
        }
        else{
            pResult->size--;
        }
    }

    for (int32_t i = 0; i < pResult->size; i++){
        // printf("%d %d %d\n", pResult->pCoefficients[i], pResult->pPowers[i], i);
    }
    return 0;
}