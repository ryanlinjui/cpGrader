#ifndef MYCAL_H
#define MYCAL_H

int32_t calculate( char *pExpr, int32_t base, char **ppResult );
int32_t decimal(char *pExpr, int32_t *num, int32_t *carry);

#endif