#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "mymaze.h"

int32_t find_min_path( const sRoom *pMaze, const uint8_t row, const uint8_t col, sPath *pMinPath ){

    if (pMaze == NULL || row < 1 || col < 1){
        return -1;
    }

    int32_t num[12][4] = {0};
    uint8_t base = 0x03;
    pMinPath->pPath = calloc(row*col, sizeof(sPoint));
    pMinPath->cost = 0;
    pMinPath->length = 0;
    for (int32_t i = 0; i < row*col; i++){
        for (int32_t j = 3; j >= 0; j--){
            num[i][3-j] = (pMaze[i].doors >> (j << 1) & base);
        }
    }

    //沒有考量到同時有多條路可以走的情況

    int32_t i = 0;
    int32_t check[row*col];
    for (int32_t j = 0; j < row*col; j++){
        check[j] = 0;
    }
    while (i < row*col){
        if (i == row*col-1){
            pMinPath->cost += pMaze[i].cost;
            pMinPath->pPath[pMinPath->length].row = i/col;
            pMinPath->pPath[pMinPath->length].col = i%col;
            pMinPath->length++;
            break;
        }
        if (i / col == 0){
            if (i % col == 0){
                if (num[i][1] == num[i+1][3] && (i+1 % col != 0) && check[i+1] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath->pPath[pMinPath->length].row = i/col;
                    pMinPath->pPath[pMinPath->length].col = i%col;
                    pMinPath->length++;
                    check[i]++;
                    i++;
                }
                else if (num[i][2] == num[i+col][0] && i+col <= col*row && check[i+col] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath[pMinPath->length].pPath->row = i/col;
                    pMinPath[pMinPath->length].pPath->col = i%col;
                    pMinPath->length++;
                    check[i]++;
                    i += col;
                }
                else{
                    return 0;
                }
            }
            else if (i % col == col-1){
                if (num[i][2] == num[i+col][0] && i+col <= col*row && check[i+col] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath->pPath[pMinPath->length].row = i/col;
                    pMinPath->pPath[pMinPath->length].col = i%col;
                    pMinPath->length++;
                    check[i]++;
                    i += col;
                }
                else if (num[i][3] == num[i-1][1] && i-1 % col != 0 && check[i-1] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath->pPath[pMinPath->length].row = i/col;
                    pMinPath->pPath[pMinPath->length].col = i%col;                    
                    pMinPath->length++;
                    check[i]++;
                    i--;
                }
                else{
                    return 0;
                }
            }
            else{
                if (num[i][3] == num[i-1][1] && i-1 % col != 0 && check[i-1] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath->pPath[pMinPath->length].row = i/col;
                    pMinPath->pPath[pMinPath->length].col = i%col;
                    pMinPath->length++;
                    check[i]++;
                    i--;
                }
                else if (num[i][1] == num[i+1][3] && (i+1 % col != 0) && check[i+1] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath->pPath[pMinPath->length].row = i/col;
                    pMinPath->pPath[pMinPath->length].col = i%col;
                    pMinPath->length++;
                    check[i]++;
                    i++;
                }
                else if (num[i][2] == num[i+col][0] && i+col <= col*row && check[i+col] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath->pPath[pMinPath->length].row = i/col;
                    pMinPath->pPath[pMinPath->length].col = i%col;
                    pMinPath->length++;
                    check[i]++;
                    i += col;
                }
                else{
                    return 0;
                }
            }
        }
        else if (i / col == col-1){
            if (i % col == 0){
                if (num[i][0] == num[i-col][2] && i-col >= 0 && check[i-col] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath->pPath[pMinPath->length].row = i/col;
                    pMinPath->pPath[pMinPath->length].col = i%col;
                    pMinPath->length++;
                    check[i]++;
                    i -= col;
                }
                else if (num[i][1] == num[i+1][3] && (i+1 % col != 0) && check[i+1] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath->pPath[pMinPath->length].row = i/col;
                    pMinPath->pPath[pMinPath->length].col = i%col;
                    pMinPath->length++;
                    check[i]++;
                    i++;
                }
                else{
                    return 0;
                }
            }
            else if (i % col == col-1){
                if (num[i][3] == num[i-1][1] && i-1 % col != 0 && check[i-1] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath->pPath[pMinPath->length].row = i/col;
                    pMinPath->pPath[pMinPath->length].col = i%col;
                    pMinPath->length++;
                    check[i]++;
                    i--;
                }
                else if (num[i][0] == num[i-col][2] && i-col >= 0 && check[i-col] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath->pPath[pMinPath->length].row = i/col;
                    pMinPath->pPath[pMinPath->length].col = i%col;
                    pMinPath->length++;
                    check[i]++;
                    i -= col;
                }
                else{
                    return 0;
                }
            }
            else{
                if (num[i][3] == num[i-1][1] && i-1 % col != 0 && check[i-1] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath->pPath[pMinPath->length].row = i/col;
                    pMinPath->pPath[pMinPath->length].col = i%col;
                    pMinPath->length++;
                    check[i]++;
                    i--;
                }
                else if (num[i][1] == num[i+1][3] && (i+1 % col != 0) && check[i+1] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath->pPath[pMinPath->length].row = i/col;
                    pMinPath->pPath[pMinPath->length].col = i%col;
                    pMinPath->length++;
                    check[i]++;
                    i++;
                }
                else if (num[i][0] == num[i-col][2] && i-col >= 0 && check[i-col] == 0){
                    pMinPath->cost += pMaze[i].cost;
                    pMinPath->pPath[pMinPath->length].row = i/col;
                    pMinPath->pPath[pMinPath->length].col = i%col;
                    pMinPath->length++;
                    check[i]++;
                    i--;
                }
                else{
                    return 0;
                }
            }
        }
        else{
            if (num[i][3] == num[i-1][1] && i-1 % col != 0 && check[i-1] == 0 && i%col != 0){
                pMinPath->cost += pMaze[i].cost;
                pMinPath->pPath[pMinPath->length].row = i/col;
                pMinPath->pPath[pMinPath->length].col = i%col;
                pMinPath->length++;
                check[i]++;
                i--;
            }
            else if (num[i][1] == num[i+1][3] && (i+1 % col != 0) && check[i+1] == 0 && i%col != col-1){
                pMinPath->cost += pMaze[i].cost;
                pMinPath->pPath[pMinPath->length].row = i/col;
                pMinPath->pPath[pMinPath->length].col = i%col;
                pMinPath->length++;
                check[i]++;
                i++;
            }
            else if (num[i][0] == num[i-col][2] && i-col >= 0 && check[i-col] == 0){
                pMinPath->cost += pMaze[i].cost;
                pMinPath->pPath[pMinPath->length].row = i/col;
                pMinPath->pPath[pMinPath->length].col = i%col;
                pMinPath->length++;
                check[i]++;
                i--;
            }
            else if (num[i][2] == num[i+col][0] && i+col <= col*row && check[i+col] == 0){
                pMinPath->cost += pMaze[i].cost;
                pMinPath->pPath[pMinPath->length].row = i/col;
                pMinPath->pPath[pMinPath->length].col = i%col;
                pMinPath->length++;
                check[i]++;
                i += col;
            }
            else{
                return 0;
            }
        }
        // printf("%d %d\n", i, check[i]);
    }

    return 1;
}
