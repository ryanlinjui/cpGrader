#ifndef DICEROLLS_H
#define DICEROLLS_H
#include <gtk/gtk.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
int high_calcl(int j,int dice_choosed[],int dice_num,int dice_result[]);
int low_calcl(int j,int dice_choosed[],int dice_num,int dice_result[]);
int dice____(int dice_face);

 #endif