#ifndef MYCIRCLE_H_
#define MYCIRCLE_H_
#include <stdint.h>
void transfer_plate(int32_t n, int32_t where_did_it_from, int32_t where_did_it_go , int32_t last);


#endif