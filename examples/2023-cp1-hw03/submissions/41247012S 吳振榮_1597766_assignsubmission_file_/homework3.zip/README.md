# Computer Programming I homework 3
## Author
- 我是資工系116級的吳振榮，學號是41247012S。

## Overview
台師大資工程式設計(一)第三次作業，共5+2道題目。

## Build and Run
Run `make` to compile my code.
```shell
$ make
```
After compiling the program, you can execute hw0301 code by entering `./hw0301` in the terminal, and the remaining programs follow the same pattern.
```shell
$ ./hw0301
$ ./hw0302
$ ./hw0303
$ ./hw0304-1
$ ./hw0304-2
$ ./hw0305
```

## homework description
### hw0301
- `int32_t set_radius(double r)`: Sets the radius of the circle. Returns 0 if the radius is successfully set, or -1 if the provided radius is non-positive.

- `double get_circle_circumference()`: Returns the circumference of the circle if the radius is set (returns -1 if not).

- `double get_circle_area()`: Returns the area of the circle if the radius is set (returns -1 if not).

- `double get_tangent_area(double x)`: Calculates the area between the circle and the tangent line at the specified x-coordinate. Returns the area if the radius is set and the input is valid, or -1 if not.

- `double get_inner_regular_polygon_area(int32_t n)`: Calculates the area of an inscribed regular polygon with 'n' sides. Returns the area if 'n' is valid (n >= 3), or -1 if not.

- `double get_outer_regular_polygon_area(int32_t n)`: Calculates the area of a circumscribed regular polygon with 'n' sides. Returns the area if 'n' is valid (n >= 3), or -1 if not.
### hw0302
- `void initialize(double x, double y, double a)`: Initializes the character's position and orientation. The arguments are the initial x and y coordinates and the angle in radians. The angle is normalized between 0 and 2π. 

- `int32_t forward(double length)`: Moves the character forward by a specified distance (length) in the direction of its current angle. Returns -1 if the axis has not been set.

- `int32_t clock_turn(double x)`: Rotates the character clockwise by a specified angle (x in radians). Returns -1 if the axis has not been set.

- `int32_t counterclock_turn(double x)`: Rotates the character counterclockwise by a specified angle (x in radians). Returns -1 if the axis has not been set.

- `int32_t print()`: Prints the current position (x, y) and angle in degrees of the character. Returns -1 if the axis has not been set.
### hw0303
- The program accepts 32-bit signed integers, which should fall within the range of -2147483648 to 2147483647. If the provided number is outside this range, the program will display an error message and terminate.
### hw0304
#### Input Range
In the hw0304.c program, the user is prompted to enter the number of disks. The input for the number of disks should be between 2 and 20. If the provided number falls outside this range, the program will display an error message and terminate.
#### File Description
- `hw0304.c`: This is the main program that prompts the user to enter the number of disks (between 2 and 20) and then calls the hanoi function to solve the puzzle using one of the implemented methods.

- `hw0304.h`: This header file defines the hanoi function prototype, which is used in the main program and the implementation files.

- `hw0304-1.c`: This file provides one implementation of the hanoi function using a recursive approach. It moves the disks step by step according to the rules of the puzzle.

- `hw0304-2.c`: This file provides an alternative implementation of the hanoi function that uses a more iterative approach. It calculates the necessary moves directly based on the number of disks and their positions.
#### Towers of Hanoi Solver (Implementation 1): hw0304-1
Once you have compiled hw0304-1, you can run it from the command line. It will prompt you to enter the number of disks (between 2 and 20), and then it will display the sequence of moves to solve the Towers of Hanoi puzzle using the recursive algorithm.
#### Towers of Hanoi Solver (Implementation 2): hw0304-2
Once you have compiled hw0304-2, you can run it from the command line. It will prompt you to enter the number of disks (between 2 and 20), and then it will display the sequence of moves to solve the Towers of Hanoi puzzle using the loop method.
### hw0305
#### Requirements
To successfully compile and run the hw0305 program, you need to meet the following requirements:

Linux operating system
Compiler (e.g., gcc)
ncurses library

#### Installing Dependencies
On most Linux distributions, you can use package management tools to install the necessary dependencies. Here are examples of commonly used package managers and how to install the dependencies:

Using apt on Debian/Ubuntu:
```bash
sudo apt update
sudo apt install gcc libncurses-dev libpthread-stubs0-dev
```
Using yum on CentOS/RHEL:
```bash
sudo yum update
sudo yum install gcc ncurses-devel glibc-headers
```
On other Linux distributions, you can install dependencies according to your package manager.

#### Action
<strong>Action 1 - One For One Dice</strong>

<strong>Description</strong>

Action 1, "One For One Dice," allows the player to roll a single six-sided die and displays the result. It's a simple and straightforward action.

<strong>Instructions</strong>

Select action 1 from the main menu.
The program will roll a six-sided die and display the outcome.
The result will be shown as a number between 1 and 6.


<strong>Action 2 - Custom Dice Roll</strong>
<strong>Description</strong>

Action 2, "Custom Dice Roll," enables the player to roll multiple custom dice with specified parameters. This action lets the player control the number of dice rolled and the range of possible outcomes for each die.

<strong>Instructions</strong>

Select action 2 from the main menu.
Enter the number of dice to roll (A) and the maximum value for each die (X).
The program will simulate the roll of A dice, each with X possible outcomes.
The individual results of each die roll will be displayed, along with the total sum of all the rolls.

<strong>Action 3 - Adding Dice Roll</strong>

<strong>Description</strong>

Action 3, "Adding Dice Roll," extends the custom dice rolling functionality by allowing the player to choose and sum specific dice rolls. This action introduces more complex gameplay by combining and calculating the results of selected dice rolls.

<strong>Instructions</strong>

Select action 3 from the main menu.
Enter the number of dice to roll (A), the maximum value for each die (X), the number of dice to choose from (Y), and a fixed bonus value (B).
The program will simulate rolling A dice, each with X possible outcomes.
The player will be prompted to choose Y dice from the results.
The program will calculate the total sum of the chosen dice rolls, adding the fixed bonus value B if provided.

<strong>Action 4 - Advanced Dice Roll</strong>

<strong>Description</strong>

Action 4, "Advanced Dice Roll," is a more complex action that allows the player to roll multiple dice with various characteristics, including highest and lowest values. This action introduces additional features for dice rolling and number selection.

<strong>Instructions</strong>

Select option 4 from the main menu.
Enter values for the number of dice to roll (A), the maximum value for each die (X), the number of highest values to consider (H), the number of lowest values to consider (L), the number of dice to choose from (C), and a fixed bonus value (B), and if (H) is larger than (A) or if (L) is larger than (A), the program will display an error message and terminate the action.
The program will simulate rolling A dice, each with X possible outcomes.
The player will be prompted to choose C dice from the results.
The program will calculate the total sum of the chosen dice rolls, adding or subtracting the fixed bonus value B as necessary.

<strong>Action 5 - Duck Duck Choosing Dice</strong>

<strong>Gameplay</strong>
The game presents a scenario where you control a cute duck to choose a number. Here's how to play:

Use arrow keys (UP, DOWN, LEFT, RIGHT) to control the duck's position on the screen.

Position the duck over a number and press the ENTER to select it.

Once a number is selected, it appears beneath the duck.

If you have finished selecting the number, press the 'p' key(lower case), and use the arrow keys (UP and DOWN) to navigate and select an option. If you choose "Finish," the program will ask you if you like Professor L Chi. If you select "Yes," the program will provide you with a surprise. Remember to ensure that your terminal is in full screen mode for an exceptional experience.

If you wish to exit the game immediately, press the 'q'(lower case) key.


#### The place I use char
I only use char in the action 5, getting the arrow keys and the key on the keyboard.
Moreover, I use it in the word selection, making me more easily to programming.
```c
int32_t key = getch(); 
```
```c
char options[5][30] = {
    "Yes, definitely!!!!!", "No way......."
};
```
```c
char options[5][30] = {
    "Continue....", "Finish!!!!"
};
```
## Something to notify TAs
None