#ifndef _DICEROLLS_H_
#define _DICEROLLS_H_
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <ncurses.h>
#include <unistd.h>
#include <string.h>
void option1();
void option2();
void option3();
void option4();
int32_t option5();
void print_dice();
void bubbleSort(int32_t arr[], int32_t n);
void super();
void chi();
int32_t menu();
int32_t yes_no();
int32_t detect(int32_t dx, int32_t dy);
void drawGrid(int32_t startY, int32_t startX, int32_t width, int32_t height);

#endif