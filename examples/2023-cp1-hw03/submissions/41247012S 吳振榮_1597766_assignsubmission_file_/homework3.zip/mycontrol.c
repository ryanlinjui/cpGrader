#include <stdio.h>
#include <stdint.h>
#include <math.h>
static int32_t axis_set = 0, angle_set = 0;
static double x_axis = 0.0, y_axis = 0.0;
static double angle = 0.0;
void initialize(double x, double y, double a){
    x_axis = x;
    y_axis = y;
    angle = (a / M_PI);
    axis_set = 1;
    angle_set = 1;
    if(angle < 0) angle = (angle + 2);
    if(angle > 2) angle = (angle - 2);
}
int32_t forward(double length){
    if(!axis_set)
        return -1;
    x_axis += (length * cos(angle * M_PI));
    y_axis += (length * sin(angle * M_PI));
    return 0;
}
int32_t clock_turn(double x){
    if(!axis_set) return -1;
    x = (x / M_PI);
    angle = (angle - x);
    if(angle < 0) angle = (angle + 2);
    return 0;
}
int32_t counterclock_turn(double x){
    if(!axis_set) return -1;
    x = (x / M_PI);
    angle = (angle + x);
    if(angle > 2) angle = (angle - 2);
    return 0;
}
int32_t print(){
    if(!axis_set) return -1;
    printf("position: (%.2lf,%.2lf), angle: %.2lf\n", x_axis, y_axis, angle);
    return 0;
}