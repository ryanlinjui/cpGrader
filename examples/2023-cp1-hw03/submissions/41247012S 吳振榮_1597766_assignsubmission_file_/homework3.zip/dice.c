#include <stdio.h>
#include <stdint.h>
void print_space(int64_t inp){
    for(int i = 0;i < inp;i++) printf(" ");
}
void print_dash(int64_t inp){
    for(int i = 0;i < inp;i++) printf("-");
}
void print_red(int64_t inp){
    for(int i = 0;i < inp;i++) printf("\x1b[41m \x1b[0m");
}
int main(){
    int64_t n, length;
    printf("Please enter n: ");
    scanf("%lld", &n);
    printf("Please enter length: ");
    scanf("%lld", &length);
    int32_t fminus = 0;
    for(int first = n - 1;first >= 0;first--){
        printf("+");
        print_dash(length * 2);
        printf("+");
        printf("\n");
        for(int i = 0;i < length;i++){
            print_space((length * 2 + 1) * (n - 1) - fminus);
            printf("|");
            print_red(length * 2);
            printf("|");
            if(i != length - 1) printf("\n");
        }
        printf("\n");
        print_space((length * 2 + 1) * (n - 1) - fminus);
        printf("+");
        print_dash(length * 2);
        printf("+");
        printf("\n");
        fminus += (length * 2 + 1);
    }

    return 0;
}