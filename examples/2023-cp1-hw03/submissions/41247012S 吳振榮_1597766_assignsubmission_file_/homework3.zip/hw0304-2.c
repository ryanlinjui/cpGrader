#include "hw0304.h"
// solve in one line !!!!!!! Remember to include math.h, if you want to execute the function.
// hanoi(int32_t a, int32_t b, int32_t c, int32_t n, int32_t disk){
    // for(int i = 1;i <= (1 << n) - 1;i++) printf("move disk %d to rod %d\n", (32 - __builtin_clz(i & -i)), (n & 1 ? (((((i | i - 1) + 1) % 3) + 1 == 2) ? 3 : ((((i | i - 1) + 1) % 3) + 1 == 1 ? 1 : 2)) : (((i | i - 1) + 1) % 3) + 1));
// }
  
// implement __builtin_clz() without utilizing function
void hanoi(int32_t a, int32_t b, int32_t c, int32_t n, int32_t disk){
    int32_t destination;
    for(int i = 1;i <= (1 << n) - 1;i++){
        destination = n & 1 ? (((((i | i - 1) + 1) % 3) + 1 == 2) ? 3 : ((((i | i - 1) + 1) % 3) + 1 == 1 ? 1 : 2)) : (((i | i - 1) + 1) % 3) + 1;
        int32_t cnt = 0, mask = 1 << (sizeof(int) * 8 - 1), test = i & -i;
        while ((test & mask) == 0) {
            cnt++;
            test <<= 1;
        }
        printf("move disk %d to rod %d\n", 32 - cnt, destination);
    }
}