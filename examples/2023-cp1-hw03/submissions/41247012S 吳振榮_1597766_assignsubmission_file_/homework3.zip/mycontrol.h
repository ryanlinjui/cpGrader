#ifndef _MYCONTROL_H_
#define _MYCONTROL_H_
#include <stdio.h>
#include <stdint.h>
#include <math.h>
static int32_t axis_set = 0, angle_set = 0;
static double x_axis = 0.0, y_axis = 0.0;
static double angle = 0.0;
void initialize(double x, double y, double a);
int32_t forward(double length);
int32_t clock_turn(double x);
int32_t counterclock_turn(double x);
int32_t print();

#endif