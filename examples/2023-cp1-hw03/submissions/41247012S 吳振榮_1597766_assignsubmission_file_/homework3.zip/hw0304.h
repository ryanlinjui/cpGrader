#ifndef _HW0304_H_
#define _HW0304_H_
#include <stdio.h>
#include <stdint.h>
// #include <math.h>
void hanoi(int32_t a, int32_t b, int32_t c, int32_t n, int32_t disk);
#endif