# 3.6 Bonus: diff and patch (5 pts)
假設有人寫好了一份code，檔名叫做main.c，如下
```c
#include <stdio.h>
#include <stdlib.h>
int main(){
    printf("Hello World");

    return 0;
}
```
而我要修改這份code，檔名叫做new.c，並修改成:
```c
#include <stdio.h>
#include <stdlib.h>
int main(){
    printf("Hello World\n");
    printf("Hello L\n");

    return 0;
}
```
我們可以使用diff指令來比較兩個code之間的差異，並生成包含資料差異的patch文件。
- diff parameters
    - -r
        遞歸。設置後diff會將兩個不同版本的程式在目錄中的所有對應文件全部都比較一次，包括子目錄的程式。
    - -N
        選項確保patch文件將正確地處理已經創建或刪除文件的情況。
    - -u
        輸出每個修改前後3行，也可以用-u6等指定輸出更多上下文。
```bash
$ diff -uN main.c new.c > pat.patch
```
我們可以利用該指令生成一個pat.patch，裡面的內容大致長的像這樣：

```bash
--- main.	1970-01-01 08:00:00.000000000 +0800
+++ new.c	2023-11-04 23:19:46.000000000 +0800
@@ -0,0 +1,8 @@
+#include <stdio.h>
+#include <stdlib.h>
+int main(){
+	printf("Hello World\n");
+	printf("Hello L\n");
+
+	return 0;
+}
```
接著我們可以把這份patch檔傳給其他人，讓其他人知道我做了哪些修改，而那些人可以用我給的patch檔進而更新他們的main.c。
- patch parameter
    - -pnum
        忽略幾層文件夾，
    - -E
        選項說明如果發現了空文件，那麼就刪除它
    - -R
        取消打上的patch

當他們拿到我的patch檔的時候，可以輸入以下指令，將patch檔中更新的資料與舊的main.c合併
```bash
$ patch -p0 < pat.patch
```
之後我們的main.c就會更新成
```c
#include <stdio.h>
#include <stdlib.h>
int main(){
	printf("Hello World\n");
	printf("new");

	return 0;
}
```
那如果想要取消修改，可以輸入
```bash
patch -R main.c < pat.patch
```
就可以回到原本的main.c了。