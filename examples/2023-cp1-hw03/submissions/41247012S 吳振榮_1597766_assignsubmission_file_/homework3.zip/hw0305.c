#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "diceRolls.h"
int main(){
    printf("\033[H\033[J");
    printf("Welcome to \"Super Duck Duck CHI dice\" !\n");
    printf("Please refer to README for more information.\n");
    printf("0. Terminate me\n");
    printf("1. One For One Dice\n");
    printf("2. Custom Dice Roll\n");
    printf("3. Adding Dice Roll\n");
    printf("4. Advanced Dice Roll\n");
    printf("5. Duck Duck Choosing Dice\n");
    printf("----------------------------------------\n");
    int32_t action;
    printf("Your action: ");
    while(scanf("%d", &action) && action != 0){
        if(action < 0 || action > 5){
            printf("Invalid Input. Your input should between 0 and 5");
            return 0;
        }
        if(action == 1) option1();
        else if(action == 2) option2();
        else if(action == 3) option3();
        else if(action == 4) option4();
        else if(action == 5) {
            int32_t ret = option5();
            if(ret != -1){
                printf("The dice you choose is %d\n", ret);
                printf("\\\\\\\\\\");
                printf("\n");
                printf("<(o )___");
                printf("\n");
                printf("(\033[1;31m%3d\033[0m_ >", ret);
                printf("\n");
                printf("\033[1;34mThank you for playing \"Duck Duck Choosing Dice\"\033[0m\n");
            }
            else{
                printf("Why don't you choose a dice?\n");
                printf("\033[1;31mThe cute Duck hate u!!!\033[0m\n");
            }
        }
        printf("Your action: ");
    }
    printf("bye\n>\n");
    
    return 0;
}