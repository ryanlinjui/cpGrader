#include <stdio.h>
#include <stdint.h>
#include "hw0304.h"
int main(){
    int32_t num;
    printf("Please enter the disk number (2-20): ");
    scanf("%d", &num);
    if(num < 2 || num > 20){
        printf("Invalid input. The number of disks should be between 2 and 20.\n");
        return 0;
    }
    hanoi(1, 2, 3, num, 1);
    
    return 0;
} 