#include <stdio.h>
#include <stdint.h>
void BinaryForm(int64_t num, int32_t digit){
    if(num == 0){
        for(int i = 1;i <= 32 - digit + 1;i++){
            printf("0");
            if(i % 8 == 0 && i != (32 - digit + 1)) printf(" ");
        }
        return;
    }
    if(num % 2){
        BinaryForm(num / 2, digit + 1);
        if(digit % 8 == 0 && digit != 32) printf(" ");
        printf("1");
    }
    else{
        BinaryForm(num / 2, digit + 1);
        if(digit % 8 == 0) printf(" ");
        printf("0");
    }
}
int main(){
    int64_t number;
    printf("Please enter the number: ");
    scanf("%lld", &number);
    if(number > 2147483647){
        printf("Invalid Input. The number is too large.\n");
        return 0;
    }
    else if(number < -2147483648){
        printf("Invalid Input. The number is too small.\n");
        return 0;
    }
    if(number < 0) number += 4294967296;
    BinaryForm(number, 1);
    printf("\n");
    
    return 0;
}