#include "hw0304.h"
void hanoi(int32_t a, int32_t b, int32_t c, int32_t n, int32_t disk){
    if(n == 1)
        printf("move disk %d to rod %d\n", disk, b);
    else{
        hanoi(a, c, b, n - 1, 1);
        hanoi(a, b, c, 1, n);
        hanoi(c, b, a, n - 1, 1);
    }
}