#include "diceRolls.h"
void bubbleSort(int32_t arr[], int32_t n){
    int32_t temp;
    int32_t swapped;
    for(int32_t i = 0; i < n - 1; i++) {
        swapped = 0;
        for(int32_t j = 0; j < n - i - 1; j++) {
            if(arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                swapped = 1;
            }
        }
        if(swapped == 0) {
            break;
        }
    }
}
void option1(){
    srand(time(0));
    printf("\n");
    int32_t number = (rand() % 6) + 1;
    printf("\\\\\\\\\\ \n");
    printf("<(o )___ \n");
    printf("(\033[1;31m%3d\033[0m_ >\n", number);
    printf("result: %d\n", number);
    printf("\n----------------------------------------\n");
}
void option2(){
    srand(time(0));
    int32_t a, b, x;
    printf("Please enter A, X: ");
    scanf("%d %d", &a, &x);
    if(a > 10 || a < 1){
        printf("Invalid Input. A should between 1 and 10.");
        return;
    }
    b = a;
    int32_t arr[25], cnt = 0;
    int32_t t = (a > 5) ? 1 : 0;
    a = (a > 5) ? 5 : a;
    for(int32_t i = 0;i <= t;i++){
        for(int32_t j = 0;j < a;j++){
            printf("\\\\\\\\\\");
            printf("           ");
        }
        printf("\n");
        for(int32_t j = 0;j < a;j++){
            printf("<(o )___");
            printf("        ");
        }
        printf("\n");
        for(int32_t j = 0;j < a;j++){
            int32_t number = (rand() % x) + 1;
            arr[cnt++] = number;
            printf("(\033[1;31m%3d\033[0m_ >", number);
            printf("         ");
        }
        printf("\n");
        a = (b > 5) ? b - 5 : 0;
    }
    printf("result: ");
    int32_t sum = 0;
    for(int32_t i = 0;i < b;i++){
        printf("%d ", arr[i]);
        sum += arr[i];
        if(i != b - 1) printf("+ ");
    }
    printf("= %d\n", sum);
    printf("\n----------------------------------------\n");
}
void option3(){
    int32_t a, x, y, b, tmp;
    printf("Please enter A, X, Y, B: ");
    scanf("%d %d %d %d", &a, &x, &y, &b);
    tmp = a;
    int32_t arr[20], cnt = 0, gen[20], ins = 0;
    int32_t t = (a > 5) ? 1 : 0;
    a = (a > 5) ? 5 : a;
    for(int32_t i = 0;i <= t;i++){
        for(int32_t j = 0;j < a;j++){
            printf("%d.", ++cnt);
            printf("              ");
        }
        printf("\n");
        for(int32_t j = 0;j < a;j++){
            printf("\\\\\\\\\\");
            printf("           ");
        }
        printf("\n");
        for(int32_t j = 0;j < a;j++){
            printf("<(o )___");
            printf("        ");
        }
        printf("\n");
        for(int32_t j = 0;j < a;j++){
            int32_t number = (rand() % x) + 1;
            gen[ins++] = number;
            printf("(\033[1;31m%3d\033[0m_ >", number);
            printf("         ");
        }
        printf("\n");
        a = (tmp > 5) ? tmp - 5 : 0;
    }
    printf("Please choose %d dice from above: ", y);
    for(int32_t i = 0;i < y;i++) scanf("%d", &arr[i]);
    // choose
    t = (y > 5) ? 1 : 0;
    int32_t temp = y;
    y = (y > 5) ? 5 : y;
    for(int32_t i = 0;i <= t;i++){
        for(int32_t j = 0;j < y;j++){
            printf("\\\\\\\\\\");
            printf("           ");
        }
        printf("\n");
        for(int32_t j = 0;j < y;j++){
            printf("<(o )___");
            printf("        ");
        }
        printf("\n");
        for(int32_t j = 0;j < y;j++){
            printf("(\033[1;31m%3d\033[0m_ >", gen[arr[j] - 1]);
            printf("         ");
        }
        printf("\n");
        y = (temp > 5) ? temp - 5 : 0;
    }
    printf("result: ");
    int32_t sum = 0;
    for(int32_t i = 0;i < temp;i++){
        printf("%d ", gen[arr[i] - 1]);
        sum += gen[arr[i] - 1];
        if(i != temp - 1) printf("+ ");
    }
    if(b < 0) printf("- ");
    else printf("+ ");
    printf("%d ", b);
    printf("= %d\n", sum + b);
    printf("\n----------------------------------------\n");
}
void option4(){ // 6 10 3 3 3 8
    int32_t a, x, h, l, c, b, tmp, total_len = 0;
    printf("Please enter A, X, H, L, C, B: ");
    scanf("%d %d %d %d %d %d", &a, &x, &h, &l, &c, &b);
    if(h > a){
        printf("The \"h\" value must be less than or equal to the \"a\" value.\n");
        return;
    }
    if(l > a){
        printf("The \"l\" value must be less than or equal to the \"a\" value.\n");
        return;
    }
    tmp = a;
    total_len = a;
    int32_t arr[20], cnt = 0, gen[20], ins = 0;
    int32_t t = (a > 5) ? 1 : 0;
    a = (a > 5) ? 5 : a;
    for(int32_t i = 0;i <= t;i++){
        printf("\n");
        for(int32_t j = 0;j < a;j++){
            printf("\\\\\\\\\\");
            printf("           ");
        }
        printf("\n");
        for(int32_t j = 0;j < a;j++){
            printf("<(o )___");
            printf("        ");
        }
        printf("\n");
        for(int32_t j = 0;j < a;j++){
            int32_t number = (rand() % x) + 1;
            gen[ins++] = number;
            printf("(\033[1;31m%3d\033[0m_ >", number);
            printf("         ");
        }
        printf("\n");
        a = (tmp > 5) ? tmp - 5 : 0;
    }
    bubbleSort(gen, ins);
    // for(int32_t i = 0;i < ins;i++) printf("%d ", gen[i]);
    int32_t new_h = h;
    t = (h > 5) ? 1 : 0;
    printf("\nHighest %d:", h);
    for(int32_t i = 0;i <= t;i++){
        printf("\n");
        for(int32_t j = 0;j < h;j++){
            printf("\\\\\\\\\\");
            printf("           ");
        }
        printf("\n");
        for(int32_t j = 0;j < h;j++){
            printf("<(o )___");
            printf("        ");
        }
        printf("\n");
        for(int32_t j = ins;j > ins - h;j--){
            printf("(\033[1;31m%3d\033[0m_ >", gen[j - 1]);
            printf("         ");
        }
        printf("\n");
        h = (new_h > 5) ? new_h - 5 : 0;
    }
    
    printf("Lowest %d:", l);
    int32_t new_l = l;
    t = (h > 5) ? 1 : 0;
    for(int32_t i = 0;i <= t;i++){
        printf("\n");
        for(int32_t j = 0;j < l;j++){
            printf("\\\\\\\\\\");
            printf("           ");
        }
        printf("\n");
        for(int32_t j = 0;j < l;j++){
            printf("<(o )___");
            printf("        ");
        }
        printf("\n");
        for(int32_t j = 0;j < l;j++){
            printf("(\033[1;31m%3d\033[0m_ >", gen[j]);
            printf("         ");
        }
        printf("\n");
        l = (new_l > 5) ? new_l - 5 : 0;
    }
    printf("Choose %d:\n", c);
    a = tmp;
    t = (a > 5) ? 1 : 0;
    a = (a > 5) ? 5 : a;
    cnt = 0;
    ins = 0;
    for(int32_t i = 0;i <= t;i++){
        for(int32_t j = 0;j < a;j++){
            printf("%d.", ++cnt);
            printf("              ");
        }
        printf("\n");
        for(int32_t j = 0;j < a;j++){
            printf("\\\\\\\\\\");
            printf("           ");
        }
        printf("\n");
        for(int32_t j = 0;j < a;j++){
            printf("<(o )___");
            printf("        ");
        }
        printf("\n");
        for(int32_t j = 0;j < a;j++){
            printf("(\033[1;31m%3d\033[0m_ >", gen[ins++]);
            printf("         ");
        }
        printf("\n");
        a = (tmp > 5) ? tmp - 5 : 0;
    }
    printf("Please choose %d dice from above: ", c);
    for(int32_t i = 0;i < c;i++) scanf("%d", &arr[i]);
    printf("\nresult: ");
    int32_t sum = 0;
    for(int32_t i = 0;i < new_h;i++){
        sum += gen[total_len - i - 1];
        printf("%d ", gen[total_len - i - 1]);
        printf("+ ");
    }
    for(int32_t i = 0;i < new_l;i++){
        sum += gen[i];
        printf("%d ", gen[i]);
        if(i != new_l - 1) printf("+ ");
    }
    if(c > 0) printf("+ ");
    for(int32_t i = 0;i < c;i++){
        sum += gen[arr[i] - 1];
        printf("%d ", gen[arr[i] - 1]);
        if(i != c - 1) printf("+ ");
    }
    if(b < 0) printf("- ");
    else printf("+ ");
    printf("%d ", (b > 0 ? b : -b));
    printf("= %d\n", sum + b);
    printf("\n----------------------------------------\n");
}