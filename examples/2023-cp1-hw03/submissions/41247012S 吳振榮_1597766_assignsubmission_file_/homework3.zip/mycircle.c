#include <stdio.h>
#include <stdint.h>
#include <math.h>
// pi in math.h = M_PI
static double radius = 0.0;
static int32_t rad = 0;
int32_t set_radius(double r){
    if(r <= 0) return -1;
    else{
        rad = 1;
        radius = r;
        return 0;
    }
}

double get_circle_circumference(){
    return rad ? ((double)2.0 * radius) * M_PI : -1;
}

double get_circle_area(){
    return rad ? (radius * radius * M_PI) : -1;
}

double get_tangent_area(double x){
    if(!rad) return -1;
    double y = sqrt((radius * radius) - (x * x));
    // if(sqrt(y * y + x * x) > radius || sqrt(y * y + x * x) < radius || x > radius || x < -radius) return -1;
    if(x > radius || x < -radius || sqrt((radius * radius) - (x * x)) < 0) return -1;
    double m = (-x / y);
    double k = y - (m * x);
    double a = (-k / m), b = k;
    return (a * b / (double)2.0 > 0) ? a * b / (double)2.0 : -(a * b / (double)2.0);
}

double get_inner_regular_polygon_area(int32_t n){
    if(n < 3) return -1;
    if(!rad) return -1;
    double area = (((radius * radius) * sin(2 * M_PI / n)) / (double)2.0) * (double)n;
    return area;
}

double get_outer_regular_polygon_area(int32_t n){
    if(n < 3) return -1;
    if(!rad) return -1;
    double area = (radius * radius) * tan(M_PI / n) * n;
    return area;
}