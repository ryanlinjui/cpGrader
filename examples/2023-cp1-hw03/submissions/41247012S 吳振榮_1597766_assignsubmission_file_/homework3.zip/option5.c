#include "diceRolls.h"
#define GRID_WIDTH 10
#define GRID_HEIGHT 5
#define GRID_START_X 0
#define GRID_START_Y 0
static int32_t arr[100];
void drawGrid(int32_t startY, int32_t startX, int32_t width, int32_t height){
    for(int32_t j = 0; j < width - 1; j++){
        mvprintw(startY, startX + j * 10, "+----------+");
        mvprintw(startY + 1, startX + j * 10, "|    %d     |", arr[j]);
        mvprintw(startY + 2, startX + j * 10, "+----------+");
    }
}
int32_t detect(int32_t dx, int32_t dy){
    int32_t max_x, max_y;
    getmaxyx(stdscr, max_y, max_x);
    int32_t WIDTH = max_x - GRID_START_X;
    for(int32_t j = 0;j <  WIDTH / GRID_WIDTH - 1;j++){
        int selected_grid_x = dx / GRID_WIDTH; 
        int selected_grid_y = dy / GRID_HEIGHT; 

        if (selected_grid_x == j && selected_grid_y == 0) {
            int selected_number = arr[selected_grid_x];
            return selected_number;
        }
    }
    return 0;
}
int32_t menu(){
    int32_t selectedOption = 0;
    while(1){
        char options[5][30] = {
            "Continue....", "Finish!!!!"
        };
        for(int32_t i = 0; i < 2; i++){
            if(i == selectedOption){
                attron(A_STANDOUT);
            }
            mvprintw(LINES / 2 + i, (COLS - strlen(options[i])) / 2, options[i]);
            attroff(A_STANDOUT);
        }
        int32_t key = getch();
        if(key == KEY_UP){
            if(selectedOption == 0) continue;
            selectedOption--;
        }
        else if(key == KEY_DOWN){
            if(selectedOption == 2) continue;
            selectedOption++;
        }
        else if(key == '\n'){
            if(selectedOption == 0) break;
            else if(selectedOption == 1) return 1;
        }
    }
    return 0;
}
int32_t yes_no(){
    int32_t selectedOption = 0;
    while(1){
        char options[5][30] = {
            "Yes, definitely!!!!!", "No way......."
        };
        for(int32_t i = 0; i < 2; i++){
            if(i == selectedOption){
                attron(A_STANDOUT);
            }
            mvprintw(LINES / 2 + i, (COLS - strlen(options[i])) / 2, options[i]);
            attroff(A_STANDOUT);
        }
        int32_t key = getch();
        if(key == KEY_UP){
            if(selectedOption == 0) continue;
            selectedOption--;
        }
        else if(key == KEY_DOWN){
            if(selectedOption == 2) continue;
            selectedOption++;
        }
        else if(key == '\n'){
            if(selectedOption == 0) return 1;
            else if(selectedOption == 1) return 0;
        }
    }
    return 0;
}
int32_t option5(){
    srand(time(0));
    // system("clear");
    // printf("\033[H\033[J");
    initscr();
    noecho();
    cbreak();
    curs_set(FALSE);
    keypad(stdscr, TRUE);
    
    int32_t max_x, max_y;
    getmaxyx(stdscr, max_y, max_x);

    int32_t WIDTH = max_x - GRID_START_X;
    int32_t HEIGHT = max_y - GRID_START_Y;
    int32_t arrow_x = max_x / 2;
    int32_t arrow_y = max_y / 2;
    
    mvprintw(LINES / 2, (COLS-strlen("Welcome to Duck Duck Choosing Dice!")) / 2, "Welcome to Duck Duck Choosing Dice!");
    mvprintw(LINES / 2 + 1, (COLS-strlen("              ")) / 2, "              ");
    mvprintw(LINES / 2 + 3, (COLS-strlen("You can choose the number you want by controlling the cute duck with the arrow keys.")) / 2, "You can choose the number you want by controlling the cute duck with the arrow keys.");
    mvprintw(LINES / 2 + 4, (COLS-strlen("Press the ENTER to make your selection.")) / 2, "Press the ENTER to make your selection.");
    mvprintw(LINES / 2 + 6, (COLS - strlen("Press Any Key to Continue.....")) / 2, "Press Any Key to Continue.....");
    refresh();
    for(int32_t i = 0;i < WIDTH / GRID_WIDTH - 1;i++) arr[i] = rand() % 99 + 1;
    getch();
    int32_t duck_number = -1, new_num = 0, right = 1;
    while(1){
        clear();
        drawGrid(GRID_START_Y, GRID_START_X, WIDTH / GRID_WIDTH, HEIGHT / GRID_HEIGHT);
        if(right){
            mvaddstr(arrow_y - 1, arrow_x - 5, "  /////");
            mvaddstr(arrow_y, arrow_x - 5, "___( o)>");
            if(new_num) mvprintw(arrow_y + 1, arrow_x - 3, "< _%d)", duck_number);
            else mvaddstr(arrow_y + 1, arrow_x - 3, "< _ )");
        }
        else{
            mvaddstr(arrow_y - 1, arrow_x - 5, "\\\\\\\\\\");
            mvaddstr(arrow_y, arrow_x - 5, "<(o )___");
            if(new_num) mvprintw(arrow_y + 1, arrow_x - 3, "(%d_ >", duck_number);
            else mvaddstr(arrow_y + 1, arrow_x - 3, "( _ >");
        }
        refresh();
        int32_t judge, res
        int32_t key = getch(); 
        switch(key){
            case KEY_UP:
                if(arrow_y > 1) arrow_y--;
                break;
            case KEY_DOWN:
                if(arrow_y < max_y - 1) arrow_y++;
                break;
            case KEY_LEFT:
                right = 0;
                if(arrow_x > 1) arrow_x--;
                break;
            case KEY_RIGHT:
                right = 1;
                if(arrow_x < max_x - 1) arrow_x++;
                break;
            case 'q':
                refresh();
                endwin();
                return -1;
            case '\n':
                judge = detect(arrow_x, arrow_y);
                if(judge > 0){
                    duck_number = judge;
                    new_num = 1;
                }
                break;
            case 'p':
                res = menu();
                if(res == 1){
                    mvprintw(LINES / 2 + 5, (COLS-strlen("Do you like Professor L Chi?")) / 2, "Do you like Professor L Chi?");
                    int32_t ans = yes_no();
                    refresh();
                    endwin();
                    if(ans) chi();
                    return duck_number;
                }
                break;
            default:
                break;
        }
    }
    return -1;
}