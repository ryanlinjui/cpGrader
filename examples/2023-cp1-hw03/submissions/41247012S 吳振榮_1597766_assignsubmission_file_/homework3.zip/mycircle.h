#ifndef _MYCIRCLE_H_
#define _MYCIRCLE_H_
#include <stdio.h>
#include <stdint.h>
#include <math.h>
// pi in math.h = M_PI
static double radius = 0.0;
static int32_t rad = 0;
int32_t set_radius(double r);
double get_circle_circumference();
double get_circle_area();
double get_tangent_area(double x);
double get_inner_regular_polygon_area(int32_t n);
double get_outer_regular_polygon_area(int32_t n);

#endif