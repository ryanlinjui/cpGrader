#include<stdio.h>
#include<stdint.h>
#include<math.h>
#include"hw0304.h"

int32_t hanoi ( int32_t n, int32_t start, int32_t end, int32_t mid );

int32_t hanoi ( int32_t n, int32_t start, int32_t end, int32_t mid )
{
    int32_t a = n;
    int32_t b = 0;
    int32_t c = 0;
    int32_t numa = 1;
    int32_t numb = 0;
    int32_t numc = 0;
    int32_t number = 0;
    int32_t count = n;
    int32_t line = 1;
    int32_t disk = 0;
    int32_t n2 = 0;
    int32_t olda = 2;
    int32_t oldb = 0;
    int32_t oldc = 0;
    
    n2 = pow ( 2, n ) - 1;
    
    int32_t n21 = n2/3;
    
    if ( n % 2 == 1 )
    {
        int32_t ncount = n/3;
        
        for ( int i = 0 ; i < n21 ; i++ )
        {
            //count number
            if ( line % 2 == 1 )
            {
                printf ( "move disk 1 to ");
                disk = 1;
            }
            else
            {
                for ( int j = n ; j > 0 ; j -- )
                {
                    if ( line % (int) pow ( 2, j-1 ) == 0 )
                    {
                        printf ( "move disk %d to ", j );
                        disk = j;
                        break;
                    }
                }
            }
            line = line + 1;
            
            //a vs c 
            if ( c == 0 || numc > numa )
            {
                printf ( "rod 3\n" );
                c = c + 1;
                a = a - 1;
                numa = olda;
                oldc = numc;
                numc = disk;
                
            }
            else
            {
                printf ( "rod 1\n");
                c = c - 1;
                a = a + 1;
                numc = oldc;
                olda = numa;
                numa = disk;
            }
            
            //count number
            if ( line % 2 == 1 )
            {
                printf ( "move disk 1 to ");
                disk = 1;
            }
            else
            {
                for ( int j = n ; j > 0 ; j -- )
                {
                    if ( line % (int) pow ( 2, j-1 ) == 0 )
                    {
                        printf ( "move disk %d to ", j );
                        disk = j;
                        break;
                    }
                }
            }
            line = line + 1;
            
            //a vs b 
            if ( b == 0 || numb > numa )
            {
                printf ( "rod 2\n" );
                b = b + 1;
                a = a - 1;
                numa = olda;
                oldb = numb;
                numb = disk;
            }
            else
            {
                printf ( "rod 1\n");
                b = b - 1;
                a = a + 1;
                numb = oldb;
                olda = numa;
                numa = disk;
            }
            
            //count number
            if ( line % 2 == 1 )
            {
                printf ( "move disk 1 to ");
                disk = 1;
            }
            else
            {
                for ( int j = n ; j > 0 ; j -- )
                {
                    if ( line % (int) pow ( 2, j-1 ) == 0 )
                    {
                        printf ( "move disk %d to ", j );
                        disk = j;
                        break;
                    }
                }
            }
            line = line + 1;
            
            //b vs c 
            if ( b == 0 || numb > numc )
            {
                printf ( "rod 2\n" );
                b = b + 1;
                c = c - 1;
                numc = oldc;
                oldb = numb;
                numb = disk;
            }
            else
            {
                printf ( "rod 3\n");
                b = b - 1;
                c = c + 1;
                numb = oldb;
                oldc = numc;
                numc = disk;
            }
        
        }
    
        //last
        printf ("move disk 1 to rod 3\n");
    
    }
    else
    {
        int32_t ncount = n/3;
        
        for ( int i = 0 ; i < n21 ; i++ )
        {
            //count number
            if ( line % 2 == 1 )
            {
                printf ( "move disk 1 to ");
                disk = 1;
            }
            else
            {
                for ( int j = n ; j > 0 ; j -- )
                {
                    if ( line % (int) pow ( 2, j-1 ) == 0 )
                    {
                        printf ( "move disk %d to ", j );
                        disk = j;
                        break;
                    }
                }
            }
            line = line + 1;
            
            //a vs b
            if ( b == 0 || numb > numa )
            {
                printf ( "rod 2\n" );
                b = b + 1;
                a = a - 1;
                numa = olda;
                oldb = numb;
                numb = disk;
                
            }
            else
            {
                printf ( "rod 1\n");
                b = b - 1;
                a = a + 1;
                numb = oldb;
                olda = numa;
                numa = disk;
            }
            
            //count number
            if ( line % 2 == 1 )
            {
                printf ( "move disk 1 to ");
                disk = 1;
            }
            else
            {
                for ( int j = n ; j > 0 ; j -- )
                {
                    if ( line % (int) pow ( 2, j-1 ) == 0 )
                    {
                        printf ( "move disk %d to ", j );
                        disk = j;
                        break;
                    }
                }
            }
            line = line + 1;
            
            //a vs c 
            if ( c == 0 || numc > numa )
            {
                printf ( "rod 3\n" );
                c = c + 1;
                a = a - 1;
                numa = olda;
                oldc = numc;
                numc = disk;
                
            }
            else
            {
                printf ( "rod 1\n");
                c = c - 1;
                a = a + 1;
                numc = oldc;
                olda = numa;
                numa = disk;
            }
            
            //count number
            if ( line % 2 == 1 )
            {
                printf ( "move disk 1 to ");
                disk = 1;
            }
            else
            {
                for ( int j = n ; j > 0 ; j -- )
                {
                    if ( line % (int) pow ( 2, j-1 ) == 0 )
                    {
                        printf ( "move disk %d to ", j );
                        disk = j;
                        break;
                    }
                }
            }
            line = line + 1;
            
            //b vs c 
            if ( b == 0 || numb > numc )
            {
                printf ( "rod 2\n" );
                b = b + 1;
                c = c - 1;
                numc = oldc;
                oldb = numb;
                numb = disk;
                
            }
            else
            {
                printf ( "rod 3\n");
                b = b - 1;
                c = c + 1;
                numb = oldb;
                oldc = numc;
                numc = disk;
            }
    
    
        }
    
    
    }



}
