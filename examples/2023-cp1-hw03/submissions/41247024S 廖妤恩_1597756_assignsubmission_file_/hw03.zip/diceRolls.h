#include<stdio.h>
#include<stdint.h>
#include<time.h>
#include<stdlib.h>

void d6 ();
int32_t adx ();
int32_t adxky ();
int32_t adxkh ();
void cool ();