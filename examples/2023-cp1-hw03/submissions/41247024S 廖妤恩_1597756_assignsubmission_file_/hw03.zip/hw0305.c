#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>
#include<time.h>
#include"diceRolls.h"

int main()
{
    int32_t n = 0;

    while (1)
    {
        printf ("Welcome to Taichung! The world of guns and violence!\n");
        printf ("Please refer to README for more information.\n");
        printf ("0. Escape bad Taichung!!!\n");
        printf ("1. Why don't you firing a shot?              [roll a 1d6 dice]\n");
        printf ("2. More bullet?                              [roll adx dices, mabye you could get more from it?]\n");
        printf ("3. Choose your own damage!                   [customize your damage!]\n");
        printf ("4. Would you want something more complex?    [another way to customize your damage:D]\n");
        printf ("5. Let's start a battle!                     [good luck:)]\n");
        
        printf ("------------------------------------------------------------------------------------------------\n");
        
        printf ("Your action: ");
        scanf ( "%d", &n );
        
        if ( n == 0 )
        {
            printf ("byebye:D\n");
            return 0;
        }
        else if ( n == 1 )
        {
            d6 ();    
        }
        else if ( n == 2 )
        {
            adx ();
        }
        else if ( n == 3 )
        {
            adxky ();
        }
        else if ( n == 4 )
        {
            adxkh ();
        }
        else if ( n == 5 )
        {
            cool ();
        }
        else
        {
            printf ("Wrong input, please input again.\n");
            return 0;
        }
            
    }

}