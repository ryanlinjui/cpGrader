#include<stdio.h>
#include<stdint.h>

int32_t BinaryForm ( int32_t n );
int32_t negBinaryForm ( int32_t n );
int32_t binarycount ( int32_t ncount );
int32_t negbinarycount ( int32_t ncount );
int32_t printzero ( int32_t zerocount );
static int32_t spacecount = 0;
static int32_t zerocount = 0;
static int32_t n = 0;
static int32_t caln = 0;

int main()
{
    int64_t ncheck = 0;
    printf ("Please enter the number: ");
    scanf ("%ld", &ncheck );
    
    //avoid idiot
    if ( ncheck > 2147483647 || ncheck < -2147483648 )
    {
        printf ("Your input is out of range, please input again.\n");
        return 0;
    }
    
    n = ncheck;
    int32_t ncount = 0;
    ncount = n;
    
    //calculate
    if ( n >= 0 )
    {
        binarycount ( ncount );
        zerocount = 32-zerocount;
        printzero ( zerocount );
        BinaryForm ( n );
    }
    else
    {
        caln = -n-1;
        ncount = caln;
        negbinarycount ( ncount );
        zerocount = 32-zerocount;
        
        printzero ( zerocount );
        
        negBinaryForm ( caln );
    }

    printf ("\n");

}

int32_t binarycount ( int32_t ncount )
{
    if ( ncount > 0 )
    {
        binarycount ( ncount/2 );
        zerocount = zerocount+1;
    }
    if ( ncount < 0 )
    {
        ncount = -ncount;
        binarycount ( ncount/2 );
        zerocount = zerocount+1;
    }
    
    return zerocount;

}

int32_t negbinarycount ( int32_t ncount )
{
    if ( ncount > 0 )
    {
        binarycount ( ncount/2 );
        zerocount = zerocount+1;
    }

    return zerocount;
}

int32_t printzero ( int32_t zerocount )
{
    if ( zerocount > 0 )
    {
        if ( n >= 0 )
        {
            printf ("0");
        
            spacecount = spacecount+1;
        
            if ( spacecount == 8 || spacecount == 16 || spacecount == 24 )
            {
                printf (" ");
            }	
        
            printzero ( zerocount-1 );
        }
        else 
        {
            printf ("1");

            spacecount = spacecount+1;

            if ( spacecount == 8 || spacecount == 16 || spacecount == 24 )
            {
                printf (" ");
            }   

            printzero ( zerocount-1 );
        
        }
    }
    
    return 0;
}

int32_t BinaryForm ( int32_t n )
{
    if ( n > 0 )
    {
        BinaryForm ( n/2 );
        printf ( "%d", n%2 );
        
        spacecount = spacecount+1;
        
        if ( spacecount == 8 || spacecount == 16 || spacecount == 24 )
        {
            printf (" ");
        }	
    
    }
       
    return 0;       
}

int32_t negBinaryForm ( int32_t caln )
{

    if ( caln > 0 )
    {
        negBinaryForm ( caln/2 );
        
        if ( (caln)%2 == 1 )
        {
            printf("0");
        }
        else if ( (caln)%2 == 0 )
        {
            printf("1");
        }
        //printf ( "%d", n%2 );

        spacecount = spacecount+1;

        if ( spacecount == 8 || spacecount == 16 || spacecount == 24 )
        {
            printf (" ");
        }
    
    } 

    return 0;
}