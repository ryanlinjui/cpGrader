#include<stdio.h>
#include<stdint.h>
#include<time.h>
#include<stdlib.h>

void d6 ();
int32_t adx ();
int32_t adxky ();
int32_t adxkh ();
void cool ();

void d6 ( )
{
    srand ( time(0) );
    int32_t fd6 = rand ();

    printf ( "\n" );

    printf ( "⁞ つ: •̀ ⌂ •́ : ⁞-︻╦̵̵͇̿̿̿̿══╤─ %d ———ﾟ･｡°. ﾟ·･\n", fd6%6+1 );

    printf ( "\n" );

    printf ( "result: %d\n", fd6%6+1 );
    printf ( "\n" );
    printf ("------------------------------------------------------------------------------------------------\n");

}

int32_t adx ( )
{

    int32_t a = 0;
    int32_t x = 0;
    
    printf ( "Please enter A, X: " );
    scanf ( "%d %d", &a, &x );
    
    printf ("\n");
    
    //avoid idiot
    if ( a <= 0 || a > 10 || x < 2 || x > 100 )
    {
        printf ("Wrong input, please input again.\n");
        printf ("------------------------------------------------------------------------------------------------\n");
        return 0;
    }

    int32_t ans [100] = {0};
    
    //dice number
    for ( int i = 0 ; i < a ; i ++ )
    {
        srand ( time(0)*i );
        ans [i] = ( rand () )%x+1;
        printf ("( う-´)づ︻╦̵̵̿╤── %d ———ﾟ･｡°. ﾟ·･\n", ans[i] );
    }
    
    printf ("\n");
    
    //result
    printf ("result:");
    
    for ( int i = 0 ; i < a-1 ; i ++ )
    {
        printf ( " %d +", ans [i] );
    }
    
    printf ( " %d = ", ans [a-1] );
    int32_t totalans = 0;
    
    for ( int i = 0 ; i < a ; i ++ )
    {
        totalans = totalans + ans[i];
    }

    printf ( "%d", totalans );
    
    printf ("\n");
    
    printf ("\n");
    
    printf ("------------------------------------------------------------------------------------------------\n");

}

int32_t adxky ( )
{
    int32_t a = 0;
    int32_t x = 0;
    int32_t y = 0;
    int32_t b = 0;
    
    //input
    printf ( "Please enter A, X, Y, B: " );
    scanf ( "%d %d %d %d", &a, &x, &y, &b );
    
    //avoid idiot 
    if ( a <= 0 || a > 10 || x < 2 || x > 100 || b < -10 || b > 10 || y < 0 || y > 10 || y > a )
    {
        printf ("Wrong input, please input again.\n");
        printf ("------------------------------------------------------------------------------------------------\n");
        return 0;
    }

    int32_t ans [100] = {0};
    
    printf ("\n");

    //dice number
    for ( int i = 0 ; i < a ; i ++ )
    {
        srand ( time(0)*i );
        ans [i] = ( rand () )%x+1;
        printf ( "%d.\n", i+1 );
        printf ("(҂`з´).っ︻デ═一 %d ———ﾟ･｡°. ﾟ·･\n", ans[i] );
        printf ("\n");
    }
    
    printf ( "Please choose %d dice from above: ", y );
    
    int32_t choose[10] = {0};
    
    for ( int i = 0 ; i < y ; i ++ )
    {
        scanf ("%d", &choose[i]);
        
        for ( int32_t j = 0 ; j < i ; j ++ )
        {
            if ( choose[i] == choose[j] )
            {
                printf ("You can't input the same number.\n");
                printf ("------------------------------------------------------------------------------------------------\n");
                return 0;
            }
        }

        if ( choose[i] < 1 || choose[i] > a )
        {
            printf ("Your input is out of range.\n");
            printf ("------------------------------------------------------------------------------------------------\n");
            return 0;
        }
        
    }
    
    printf ("\n");
    
    for ( int i = 0 ; i < y ; i ++ )
    {
        printf ("(҂`з´).っ︻デ═一 %d ———ﾟ･｡°. ﾟ·･\n", ans[choose[i]-1] );
        printf ("\n");
    }
    
    printf ("result: ");
    for ( int i = 0 ; i < y ; i ++ )
    {
        printf ( "%d + ", ans[choose[i]-1] );
    }
    
    printf ( "%d =", b );
    
    //ans
    int32_t totalans = 0;
    for ( int i = 0 ; i < y ; i ++ )
    {
        totalans = totalans + ans[choose[i]-1];
    }
    totalans = totalans + b;
    
    printf ( " %d", totalans );
    printf ("\n");
        
    printf ("------------------------------------------------------------------------------------------------\n");
    
    return 0;

}

int32_t adxkh ( )
{
    int32_t a = 0;
    int32_t x = 0;
    int32_t h = 0;
    int32_t l = 0;
    int32_t c = 0;
    int32_t b = 0;
    
    printf ( "Please enter A, X, H, L, C, B: " );
    scanf ( "%d %d %d %d %d %d", &a, &x, &h, &l, &c, &b );
    
    if ( a <= 0 || a > 10 || x < 2 || x > 100 || b < -10 || b > 10 || h < 0 || h > 10 || l < 0 || l > 10 || c < 0 || c > 10 || h + l + c > a )
    {
        printf ("Wrong input, please input again.\n");
        printf ("------------------------------------------------------------------------------------------------\n");
        return 0;
    }

    int32_t ans[20] = {0};
    
    printf ("\n");

    //dice number
    for ( int i = 0 ; i < a ; i ++ )
    {
        srand ( time(0)*i );
        ans [i] = ( rand () )%x+1;
        printf ( "(ﾒ▼皿▼)┳*—— %d ———ﾟ･｡°. ﾟ·･\n", ans[i] );
        printf ("\n");
    }
    
    int32_t sort[20] = {0};
    
    //sort from small to big
    for ( int i = 0 ; i < a ; i ++ )
    {
        for ( int j = 0 ; j < a ; j ++ )
        {
            if ( ans[i] < ans[j] )
            {
                int32_t temp = ans[i];
                ans[i] = ans[j];
                ans[j] = temp;   
            }
        }
    }
    
    printf ( "Highest %d:\n", h );
    
    for ( int i = a-1 ; i >= a-h ; i -- )
    {
        printf ( "(ﾒ▼皿▼)┳*—— %d ———ﾟ･｡°. ﾟ·･\n", ans[i] );
        printf ("\n");
    }
    
    printf ( "Lowest %d:\n", l );
    
    for ( int i = 0 ; i < l ; i ++ )
    {
        printf ( "(ﾒ▼皿▼)┳*—— %d ———ﾟ･｡°. ﾟ·･\n", ans[i] );
        printf ("\n");
    }
    
    printf ( "Choose %d:\n", c );
    
    for ( int i = l ; i < a-h ; i ++ )
    {
        printf ( "%d.\n", i-l+1 );
        printf ( "(ﾒ▼皿▼)┳*—— %d ———ﾟ･｡°. ﾟ·･\n", ans[i] );
        printf ("\n");
    }
    
    printf ( "Please choose %d dice from above: ", c );
    
    int32_t choose[10] = {0};

    for ( int i = 0 ; i < c ; i ++ )
    {
        scanf ("%d", &choose[i]);
        
        for ( int32_t j = 0 ; j < i ; j ++ )
        {
            if ( choose[i] == choose[j] )
            {
                printf ("You can't input the same number.\n");
                printf ("------------------------------------------------------------------------------------------------\n");
                return 0;
            }
        }
        
        if ( choose[i] < 1 || choose[i] > a-l-h )
        {
            printf ("Your input is out of range.\n");
            printf ("------------------------------------------------------------------------------------------------\n");
            return 0;
        }
    }
    
    printf ("\n");
    printf ("result: ");
    
    int32_t totalans = 0;
    
    //highest
    for ( int i = a-1 ; i >= a-h ; i -- )
    {
        printf ( "%d + ", ans[i] );
        totalans = totalans + ans[i];
    }
    
    //lowest
    for ( int i = 0 ; i < l ; i ++ )
    {
        printf ( "%d + ", ans[i] );
        totalans = totalans + ans[i];
    }
    
    //choose
    for ( int i = 0 ; i < c ; i ++ )
    {
        printf ( "%d + ", ans[choose[i]-1+l] );
        totalans = totalans + ans[choose[i]-1+l];
    }
    
    printf ( "%d =", b );
    totalans = totalans + b;
    printf ( " %d\n", totalans );
    printf ("\n");
    printf ("------------------------------------------------------------------------------------------------\n");

    return 0;

}

void cool ()
{
    int32_t a = 0;
    int32_t b = 0;
    
    srand ( time(0)*1 );
    a = ( rand () )%100+1;
    
    srand ( time(0)*2 );
    b = ( rand () )%100+1;
    
    printf ("You:                    Your enemy:\n");
    printf ("_/﹋\\_                           _/﹋\\_\n");
    printf ("(҂`_´)                           (`_´҂)\n");
    printf ("<,︻╦╤─ ҉ - %d -         - %d - ─ ҉ ╦╤︻,<\n", a, b );
    printf ("_/﹋\\_                           _/﹋\\_ \n");
    
    printf ("\n");
    
    if ( a > b )
    {
        printf ("YOU WIN!!!\n");
        printf ("   _/﹋\\_\n");
        printf ("＼(＾O＾)／\n");
        printf ("     |   \n");
        printf ("   _/﹋\\_\n");
        printf ("\n");
        printf ("------------------------------------------------------------------------------------------------\n");
    }
    else if ( a < b )
    {
        printf ("Your enemy win.\n");
        printf ("Well...just pratice:D (also as coding:()\n");
        printf ("\n");
        printf ("------------------------------------------------------------------------------------------------\n");
    }
    else
    {
        printf ("WOW, you guys are so in sync, aren't you?\n");
        printf ("\n");
        printf ("------------------------------------------------------------------------------------------------\n");
    }

} 