#include<stdio.h>
#include<stdint.h>
#include<math.h>

static double realx = 0;
static double realy = 0;
static double reala = 0;
static double reall = 0;
static double turn = 0;
static double decide = 0;
static int32_t check = 0;

void initialize ( double x, double y, double a );
int32_t forward ( double length );
int32_t clock_turn ( double x );
int32_t counterclock_turn ( double x );
int32_t print ();

void initialize ( double x, double y, double a )
{
    realx = x;
    realy = y;
    reala = a;
    check = check+1;
}

int32_t forward ( double length )
{
    if ( check == 0 )
    {
        return -1;
    }
    else
    {
        reall = length;
        
        if ( reala < 0 )
        {
            while ( reala < 0 )
            {
                reala = reala + 2*M_PI;
            }
        }
        else if ( reala > 2*M_PI )
        {
            while ( reala > 2*M_PI )
            {
                reala = reala - 2*M_PI;
            }
        }
        
        decide = (reala*2)/M_PI;
        
        if ( decide >= 0 && decide <= 1 )
        {
            realx = realx + reall*cos(reala);
            realy = realy + reall*sin(reala);
        }
        else if ( decide > 1 && decide <= 2 )
        {
            realx = realx + reall*cos(M_PI-reala);
            realy = realy + reall*sin(M_PI-reala);
        }
        else if ( decide > 2 && decide <= 3 )
        {
            realx = realx - reall*cos(reala-M_PI);
            realy = realy - reall*sin(reala-M_PI);
        }
        else
        {
            realx = realx + reall*cos(2*M_PI-reala);
            realy = realy - reall*sin(2*M_PI-reala);
        }
    
    }
    
    
}

int32_t clock_turn ( double x )
{
    if ( check == 0 )
    {
        return -1;
    }
    else
    {
        reala = reala-x; 
    }

}

int32_t counterclock_turn ( double x )
{
    if ( check == 0 )
    {
        return -1;
    }
    else
    {
        reala = reala+x;
    }

}

int32_t print ()
{
    if ( check == 0 )
    {
        return -1;
    }
    else
    {
    
        if ( reala < 0 )
        {
            while ( reala < 0 )
            {
                reala = reala + 2*M_PI;
            }
        }
        else if ( reala > 2*M_PI )
        {
            while ( reala > 2*M_PI )
            {
                reala = reala - 2*M_PI;
            }
        }
        
        printf ( "position: (%.2f,%.2f), angle: %.2f\n", realx, realy, reala/M_PI );
    }

}





