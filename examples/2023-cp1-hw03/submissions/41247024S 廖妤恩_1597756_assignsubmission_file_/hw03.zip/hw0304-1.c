#include<stdio.h>
#include<stdint.h>
#include"hw0304.h"

int32_t start = 1;
int32_t end = 2;
int32_t mid = 3;
int32_t n = 0;
int32_t hanoi ( int32_t n, int32_t start, int32_t end, int32_t mid );

/*
int main ()
{

    printf ("Please enter the disk number (2-20) : ");
    scanf ( "%d", &n );
    
    //avoid idiot
    if ( n <= 1 || n > 20 )
    {
        printf ("Out of range, please input again.\n");
        return 0;
    }
    
    move ( n, 1, 3, 2 );
    
    return 0;

}*/

int32_t hanoi ( int32_t n, int32_t start, int32_t end, int32_t mid )
{
    if ( n == 1 )
    {
        printf ( "move disk %d to rod %d\n", n, end ); 
        return 0;
    }
    else
    {
        hanoi ( n-1, start, mid, end );
        printf ("move disk %d to rod %d\n", n, end );
        hanoi ( n-1, mid, end, start );
    }

}


/*
int32_t move ( int32_t n, int32_t start, int32_t end, int32_t mid )
{
    if ( n == 1 )
    {
        printf ("move disk 1 to rod 2\n");
        return 0;
    }
    else
    {
        move ( n-1, start, mid, end );
        printf ("move disk %d to rod %d\n", n, end );
        move ( n-1, mid, end, start );
    }


}*/


