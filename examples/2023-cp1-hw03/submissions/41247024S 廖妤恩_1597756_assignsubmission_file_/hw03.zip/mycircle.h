#include<stdio.h>
#include<stdint.h>
#include<math.h>

static double radius = 0;
static double r_correct = 0;

int32_t set_radius ( double r );
double get_circle_circumference ();
double get_circle_area ();
double get_tangent_area ( double x );
double get_inner_regular_polygon_area ( int32_t n );
double get_outer_regular_polygon_area ( int32_t n );

int32_t set_radius ( double r )
{
    radius = r;
    
    if ( radius <= 0 )
    {
        return -1;
    }
    else
    {
        r_correct = radius;
        return 0; 
    }
}

double get_circle_circumference ()
{
    double circumference = 0;
    
    if ( r_correct <= 0 )
    {
        return -1;
    }
    else
    {
        circumference = 2*r_correct*M_PI;
        return circumference;
    }
        
}

double get_circle_area ()
{
    double area = 0;
    
    if ( r_correct <= 0 )
    {
        return -1;
    }
    else
    {
        area = r_correct*r_correct*M_PI;
        return area;
    }

}

double get_tangent_area ( double x )
{

    double y = 0;
    y = sqrt ( r_correct*r_correct-x*x );
    
    if ( x >= r_correct || x <= -r_correct || x == 0 )
    {
        return -1;
    }
    else if ( r_correct <= 0 )
    {
        return -1;
    }
    else
    {
        double m = 0;
        m = y/x;
        double realm = 0;
        realm = -1/m;
        double b = 0;
        b = y-realm*x;
        
        if ( b==0 )
        {
            return -1;
        }
        else
        {
            double a = -b/realm;
            
            if ( a<0 )
            {
                a = -a;
            }
            if ( b<0 )
            {
                b = -b;
            }
            
            double c = ( a*b )/2;
            return c;
            
        }    
    }
}

double get_inner_regular_polygon_area ( int32_t n )
{
    double area = 0;
    double angle = ( 360/n )*( M_PI/180.0 );
    
    if ( r_correct <= 0 || n < 3 )
    {
        return -1;
    }
    else
    {
        area = 0.5*n*r_correct*r_correct*sin(angle);
        return area;
    }
}

double get_outer_regular_polygon_area ( int32_t n )
{

    double area = 0;
    double angle = ( 180/n )*( M_PI/180.0 );

    if ( r_correct <= 0 || n < 3 )
    {
        return -1;
    }
    else
    {
        area = n*r_correct*r_correct*tan(angle);
        return area;
    }
}








