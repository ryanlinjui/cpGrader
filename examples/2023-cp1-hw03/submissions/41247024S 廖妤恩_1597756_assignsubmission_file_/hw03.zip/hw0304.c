#include<stdio.h>
#include<stdint.h>
#include"hw0304.h"

int main()
{
    printf ("Please enter the disk number (2-20): ");
    int32_t n = 0;
    scanf ( "%d", &n );
    
    //avoid idiot
    if ( n < 2 || n > 20 )
    {
        printf ( "Wrong input, please input again.\n" );
        return 0;
    }
    
    hanoi ( n, 1, 3, 2 );
    
    return 0;
}