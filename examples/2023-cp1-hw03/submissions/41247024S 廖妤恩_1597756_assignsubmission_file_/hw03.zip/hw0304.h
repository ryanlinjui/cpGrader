#include<stdio.h>
#include<stdint.h>

int32_t hanoi ( int32_t n, int32_t start, int32_t end, int32_t mid );