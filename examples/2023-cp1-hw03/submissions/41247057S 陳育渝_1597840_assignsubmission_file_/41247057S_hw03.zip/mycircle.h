#include <stdio.h>
#include <stdint.h>
#include <math.h>

int32_t set_radius ( double input );
double get_circle_circumference ();
double get_circle_area ();
double get_tangent_area ( double x );
double get_inner_regular_polygon_area ( int32_t n );
double get_outer_regular_polygon_area ( int32_t n );
static double r = 0;

int32_t set_radius ( double input ){
	if ( input <= 0 ){
		return -1;
	}
	else{
		r = input;
		return 0;
	}
}

double get_circle_circumference (){
	if ( set_radius(r) == -1 ){
		return -1;
	}
	else{
		return r * M_PI * 2;
	}
}

double get_circle_area (){
	if ( set_radius(r) == -1 ){
		return -1;
	}
	else{
		return r * r * M_PI;
	}
}

double get_tangent_area ( double x ){
	double y = 0;
	double a = 0;
	double b = 0;
	double area = 0;

	if ( set_radius(r) == -1 || x >= r || x < -r ){
		return -1;
	}

	y = sqrt ( r * r - x * x );
	a = x + y * y / x;
	b = y + x * x / y;

	area = a * b / 2;

	if ( area < 0 ){
		return - area;
	}
	else if ( area > 0 ){
		return area;
	}
	else{
		return -1;
	}
}

double get_inner_regular_polygon_area ( int32_t n ){
	if ( n < 3 || set_radius(r) == -1 ){
		return -1;
	}

	double area = 0;
	double r2 = 0;

	r2 = r * cos (M_PI / 2 - M_PI / n );

	area = r2 * r2 * sin ( 2 * M_PI / n ) * n / 2;

	return area;
}

double get_outer_regular_polygon_area ( int32_t n ){
	if ( n < 3 || set_radius(r) == -1 ){
		return -1;
	}

	double area = 0;

	area = r * r * sin ( 2 * M_PI / n ) * n / 2;

	return area;
}
