#include <stdio.h>
#include <stdint.h>
#include <math.h>

// interative function

void move (int32_t n, int32_t a, int32_t b, int32_t c);

void move (int32_t n, int32_t a, int32_t b, int32_t c){	
	int32_t aux = 0;
	if (n % 2 == 1){
		aux = b;
		b = c;
		c = aux;
	}
	for (int32_t i = 1; i < pow(2, n) - 1; i++){
		if (i % 3 == 1){
			printf("move disk %d to rod %d\n", n, b);
		}
		else if (i % 3 == 2){
			printf("move disk %d to rod %d\n", n, c);
		}
		else if (i % 3 == 0){
			printf("move disk %d to rod %d\n", n, c);
		}

		if (i % 3 == 1){
			aux = c;
			b = c;
			c = aux;
		}
	}
}
