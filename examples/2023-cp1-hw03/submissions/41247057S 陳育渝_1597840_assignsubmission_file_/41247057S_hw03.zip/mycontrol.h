#include <stdio.h>
#include <stdint.h>
#include <math.h>

void initialize ( double x, double y, double a );
int32_t forward ( double length );
int32_t clock_turn ( double x );
int32_t counterclock_turn ( double x );
int32_t print();

static int32_t i = 0;
static double X = 0;
static double Y = 0;
static double A = 0;

void initialize ( double x, double y, double a ){
	i++;
	X = x;
	Y = y;
	A = a;
}

int32_t forward ( double length ){
	if ( i == 0 ){
		return -1;
	}
	X = X + length * cos(A);
        Y = Y + length * sin(A);
}

int32_t clock_turn ( double x ){
	if ( i == 0 ){
		return -1;
	}
	A = A - x;
}

int32_t counterclock_turn ( double x ){
	if ( i == 0 ){
		return -1;
	}
	A = A + x;
}

int32_t print(){
	if ( i == 0 ){
		return -1;
	}
	A = A / M_PI;
	while(A>2) A-=2;
	while(A<0) A+=2;
	printf("position: (%.2lf,%.2lf), angle: %.2lf\n", X, Y, A);
	A = A * M_PI;
}
