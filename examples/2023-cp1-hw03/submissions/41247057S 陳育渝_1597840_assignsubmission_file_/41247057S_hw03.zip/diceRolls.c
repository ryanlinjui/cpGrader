#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

int32_t color = 42;

void action01 ();
void action02 (int32_t a, int32_t x);
void action03 (int32_t a, int32_t x, int32_t y, int32_t b);
void action04 (int32_t a, int32_t x, int32_t h, int32_t l, int32_t c, int32_t b);
void action05 (int32_t input);

void action01 (){
	srand (time(0));
	int32_t num = rand() % 6;
	printf("\n");
	printf("\e[0;%dm6  6  6\e[0m\n", color);
	if (num == 0){
		printf("\e[0;%dm6 \e[0m\e[30;47m 6 \e[0m\e[0;%dm 6\e[0m\n", color, color);
	}
	else{
		printf("\e[0;%dm6 \e[0m\e[30;47m %d \e[0m\e[0;%dm 6\e[0m\n", color, num, color);
	}
	printf("\e[0;%dm6  6  6\e[0m\n", color);
	if (num == 0){
		printf("result: 6\n");
	}
	else{
		printf("result: %d\n", num);
	}
}

void action02(int32_t a, int32_t x){
	int32_t result = 0;
	int32_t number[x - 1];
	srand (time(0));
	printf("\n");
	if (a == 0){
		printf ("result: 0\n");
		return;
	}
	for (int32_t i = 0; i < a; i++){
		printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
		int32_t num = rand() % x;
		if (num == 0){
			number[i] = x;
			result = result + x;
			printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, x, color, x);
		}
		else{
			number[i] = num;
			result = result + num;
			if (num < 10 && num > 0 && x == 100){
				printf("\e[0;%dm%d \e[0m\e[30;47m  %d  \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
			}
			else if (num < 10 && num > 0 && x < 100 && x >= 10){
				printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
			}
			else if (10 <= num && num < 100 && x < 100 && x >= 10){
				printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
			}
			else if (10 <= num && num < 100 && x == 100){
				printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
			}
			else{
				printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
			}
		}
               	printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
		printf("\n");
	}
	printf("result: ");
	for (int32_t i = 0; i < a - 1; i++){
		printf("%d + ", number[i]);
	}
	printf("%d = %d\n", number[a - 1], result);
}

void action03 (int32_t a, int32_t x, int32_t y, int32_t b){
        int32_t number[x - 1];
	int32_t result = 0;
	srand(time(0));
        printf("\n");
	if (y == 0){
		printf("result: %d\n", b);
		return;
	}
	for (int32_t i = 0; i < a; i++){
		printf("%d.\n", i + 1);
		printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
		int32_t num = rand() % x;
		if (num == 0){
			number[i] = x;
			printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, x, color, x);
		}
		else{
			number[i] = num;
			if (num < 10 && num > 0 && x == 100){
				printf("\e[0;%dm%d \e[0m\e[30;47m  %d  \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
			}
			else if (num < 10 && num > 0 && x < 100 && x >= 10){
				printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
			}
			else if (10 <= num && num < 100 && x < 100 && x >= 10){
				printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
			}
			else if (10 <= num && num < 100 && x == 100){
				printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
			}
			else{
				printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
			}
		}
		printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
		printf("\n");
        }

	int32_t choose[y];
	printf("Please choose %d dice from above: ", y);
	for (int32_t i = 0; i < y; i++){
		scanf("%d", &choose[i]);
		for (int32_t j = 0; j < i; j++){
                        if (choose[i] == choose[j]){
                                printf("you can't choose the same number\n");
                                return;
                        }
                }
	}
	for (int32_t i = 0; i < y; i++){
		choose[i] = number[choose[i] - 1];
		result = result + choose[i];
		printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
		if (choose[i] == 0){
			printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, x, color, x);
	                }
	        else{
			if (choose[i] < 10 && choose[i] > 0 && x == 100){
				printf("\e[0;%dm%d \e[0m\e[30;47m  %d  \e[0m\e[0;%dm %d\e[0m\n", color, x, choose[i], color, x);
			}
			else if (choose[i] < 10 && choose[i] > 0 && x < 100 && x >= 10){
				printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, choose[i], color, x);
			}
			else if (10 <= choose[i] && choose[i] < 100 && x < 100 && x >= 10){
				printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, choose[i], color, x);
			}
			else if (10 <= choose[i] && choose[i] < 100 && x == 100){
				printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, choose[i], color, x);
			}
			else{
				printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, choose[i], color, x);
			}
		}
		printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
		printf("\n");
	}
	printf("result: ");
	for (int32_t i = 0; i < y - 1; i++){
		printf(" %d +", choose[i]);
	}
	result = result + b;
	if (b >= 0){
		printf(" %d + %d = %d\n", choose[y - 1], b, result);
	}
	else{
		printf(" %d - %d = %d\n", choose[y - 1], -b, result);
	} 
}

void action04 (int32_t a, int32_t x, int32_t h, int32_t l, int32_t c, int32_t b){
	int32_t number[x - 1];
        int32_t result = 0;
        srand(time(0));
        printf("\n");
        for (int32_t i = 0; i < a; i++){
                printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
                int32_t num = rand() % x;
                if (num == 0){
                        number[i] = x;
                        printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, x, color, x);
                }
                else{
			number[i] = num;
                        if (num < 10 && num > 0 && x == 100){
                                printf("\e[0;%dm%d \e[0m\e[30;47m  %d  \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
                        }
                        else if (num < 10 && num > 0 && x < 100 && x >= 10){
                                printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
                        }
                        else if (10 <= num && num < 100 && x < 100 && x >= 10){
                                printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
                        }
                        else if (10 <= num && num < 100 && x == 100){
                                printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
                        }
                        else{
                                printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, num, color, x);
                        }
                }
                printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
                printf("\n");
        }

	if (h > 0){
		printf("Highest %d:\n", h);
	}
	for (int32_t j = 0; j < a; j++){
		for (int32_t i = 0; i < a - 1; i++){
			if (number[i] > number[i + 1]){
				int32_t temp = number[i + 1];
				number[i + 1] = number[i];
				number[i] = temp;
			}
		}
	}
	for (int32_t i = a - 1; i >= a - h; i--){
		printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
		if (number[i] == 0){
                        printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, x, color, x);
                        }
                else{
                        if (number[i] < 10 && number[i] > 0 && x == 100){
                                printf("\e[0;%dm%d \e[0m\e[30;47m  %d  \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                        else if (number[i] < 10 && number[i] > 0 && x < 100 && x >= 10){
                                printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                        else if (10 <= number[i] && number[i] < 100 && x < 100 && x >= 10){
                                printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                        else if (10 <= number[i] && number[i] < 100 && x == 100){
                                printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                        else{
                                printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                }
                printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
                printf("\n");
	}
	if (l > 0){
		printf("Lowest %d:\n", l);
	}
	for (int32_t i = 0; i < l; i++){
                printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
                if (number[i] == 0){
                        printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, x, color, x);
                        }
                else{
                        if (number[i] < 10 && number[i] > 0 && x == 100){
                                printf("\e[0;%dm%d \e[0m\e[30;47m  %d  \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                        else if (number[i] < 10 && number[i] > 0 && x < 100 && x >= 10){
                                printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                        else if (10 <= number[i] && number[i] < 100 && x < 100 && x >= 10){
                                printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                        else if (10 <= number[i] && number[i] < 100 && x == 100){
                                printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                        else{
                                printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                }
                printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
                printf("\n");
        }
	if (c > 0){
		printf("choose %d:\n", c);
	}
	for (int32_t i = l, j = 1; i < a - h &&j <= a - h - l; i++, j++){
		printf("%d.\n", j);
                printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
                if (number[i] == 0){
                        printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, x, color, x);
                        }
                else{
                        if (number[i] < 10 && number[i] > 0 && x == 100){
                                printf("\e[0;%dm%d \e[0m\e[30;47m  %d  \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                        else if (number[i] < 10 && number[i] > 0 && x < 100 && x >= 10){
                                printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                        else if (10 <= number[i] && number[i] < 100 && x < 100 && x >= 10){
                                printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                        else if (10 <= number[i] && number[i] < 100 && x == 100){
                                printf("\e[0;%dm%d \e[0m\e[30;47m  %d \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                        else{
                                printf("\e[0;%dm%d \e[0m\e[30;47m %d \e[0m\e[0;%dm %d\e[0m\n", color, x, number[i], color, x);
                        }
                }
                printf("\e[0;%dm%d \e[0m\e[0;%dm %d \e[0m\e[0;%dm %d\e[0m\n", color, x, color, x, color, x);
                printf("\n");
        }
	if (c > 0){
		printf("Please choose %d dice from above: ", c);
	}
	else{
		printf("result: %d\n", b);
		return;
	}
	int32_t choose[c];
	for (int32_t i = 0; i < c; i++){
		scanf ("%d", &choose[i]);
		for (int32_t j = 0; j < i; j++){
			if (choose[i] == choose[j]){
				printf("you can't choose the same number\n");
				return;
			}
		}
		result = result + number[choose[i] + 1];
	}
	printf("\n");
	printf("result: ");
	for (int32_t i = a - 1; i >= a - h; i--){
		printf("%d + ", number[i]);
		result = result + number[i];
	}
	for (int32_t i = 0; i < l; i++){
		printf("%d + ", number[i]);
		result = result + number[i];
	}
	for (int32_t i = 0; i < c - 1; i++){
		printf("%d + ", number[choose[i] + 1]);
	}
	result = result + b;
	if (b >= 0){
		printf("%d + %d = %d\n", number[choose[c - 1] + 1], b, result);
	}
	else{
		printf("%d - %d = %d\n", number[choose[c - 1] + 1], -b, result);
	}
}

void action05(int32_t input){
	color = input;
}
