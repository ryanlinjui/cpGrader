#include <stdio.h>
#include <stdint.h>
#include "diceRolls.h"

int main()
{
	int32_t act = 1;
	int32_t A = 0;
	int32_t X = 0;
	int32_t Y = 0;
	int32_t B = 0;
	int32_t H = 0;
	int32_t L = 0;
	int32_t C = 0;
	int32_t color = 0;
	printf("Welcome to \"The most convenient dice rolling machine\" !\n");
	printf("Please refer to README for more information.\n");
	while (act != 0){
		printf("0. Terminate me\n");
		printf("1. rolling a six-faced dice\n");
		printf("2. rolling A X-faced dice\n");
		printf("3. rolling A X-faced dice, and select Y dice, plus B to the points\n");
		printf("4. rolling A X-faced dice, show the top H highest and top L lowest dice. Select C dice, and plus B to the points\n");
		printf("5. select the color of dice\n");
		printf("----------------------------------------\n");
		printf("Your action: ");
		scanf("%d", &act);
		if (act == 0){
			printf("Wish you have a good day!\n");
			return 0;
		}
		else if (act == 1){
			action01();
			printf("\n");
			printf("----------------------------------------\n");
		}
		else if (act == 2){
			printf("Please enter A, X: ");
			scanf("%d %d", &A, &X);
			if ((A < 0 || A > 10) && (X < 2 || X > 100)){
				printf("A and X are out of range! (0 ≤ A ≤ 10, 2 ≤ X ≤ 100)\n");
				printf("----------------------------------------\n");
				continue;
			}
			else if (A < 0 || A > 10){
				printf("A is out of range! (0 ≤ A ≤ 10)\n");
				printf("----------------------------------------\n");
				continue;
			}
			else if (X < 2 || X > 100){
				printf("X is out of range! (2 ≤ X ≤ 100)\n");
				printf("----------------------------------------\n");
				continue;
			}
			action02(A,X);
			printf("\n");
			printf("----------------------------------------\n");
		}
		else if (act == 3){
			printf("Please enter A, X, Y, B: ");
			scanf("%d %d %d %d", &A, &X, &Y, &B);
			if (A < 0 || A > 10){
				printf("A is out of range! (0 ≤ A ≤ 10)\n");
				printf("----------------------------------------\n");
				continue;
			}
			if (X < 2 || X > 100){
				printf("X is out of range! (2 ≤ X ≤ 100)\n");
				printf("----------------------------------------\n");
				continue;
			}
			if (Y < 0 || Y > 10){
				printf("Y is out of range! (0 ≤ Y ≤ 10)\n");
				printf("----------------------------------------\n");
				continue;
			}
			if (B < -10 || B > 10){
				printf("B is out of range! (-10 ≤ B ≤ 10\n");
				printf("----------------------------------------\n");
				continue;
			}
			if (Y > A){
				printf("Y can't bigger than A!\n");
				printf("----------------------------------------\n");
				continue;
			}
			action03(A,X,Y,B);
			printf("\n");
			printf("----------------------------------------\n");
		}
		else if (act == 4){
			printf("Please enter A, X, H, L, C, B: ");
			scanf("%d %d %d %d %d %d", &A, &X, &H, &L, &C, &B);
			if (A < 0 || A > 10){
				printf("A is out of range! (0 ≤ A ≤ 10)\n");
				printf("----------------------------------------\n");
				continue;
			}
			else if (X < 2 || X > 100){
				printf("X is out of range! (2 ≤ X ≤ 100)\n");
				printf("----------------------------------------\n");
				continue;
			}
			else if (H < 0 || H > 10 || H > A){
				printf("H is out of range! (0 ≤ H ≤ 10, H ≤ A)\n");
				printf("----------------------------------------\n");
				continue;
			}
			else if (L < 0 || L > 10 || L > A){
				printf("L is out of range! (0 ≤ L ≤ 10, L ≤ A)\n");
				printf("----------------------------------------\n");
				continue;
			}
			else if (C < 0 || C > 10 || C > A || C > A - H - L){
				printf("C is out of range! (0 ≤ C ≤ 10, C ≤ A)\n");
				printf("----------------------------------------\n");
				continue;
			}
			else if (B < -10 || B > 10){
				printf("B is out of range! (-10 ≤ B ≤ 10)\n");
				printf("----------------------------------------\n");
				continue;
			}
			else{
				action04(A,X,H,L,C,B);
			}
			printf("\n");
			printf("----------------------------------------\n");			
		}
		else if (act == 5){
			printf("which color do you want? ");
			scanf("%d", &color);
			if (color >= 0){
				action05(color);
			}
			else{
				printf("the number of color should ≥ 0!\n");
				continue;
			}
		}
		else if (act > 5 && act <= 18){
			printf("━━━━━┒\n");
			printf("┓┏┓┏┓┃ 這裡風好大\n");
			printf("┛┗┛┗┛┃ 我好害怕\n");
			printf("┓┏┓┏┓┃＼😭／\n");
			printf("┛┗┛┗┛┃　/\n");
			printf("┓┏┓┏┓┃ノ)\n");
			printf("┛┗┛┗┛┃\n");
			for (int32_t i = 4; i < act; i++){
				printf("┓┏┓┏┓┃\n");
				printf("┛┗┛┗┛┃\n");
			}
			printf("┓┏┓┏┓┃\n");
			printf("┃┃┃┃┃┃\n");
			printf("┻┻┻┻┻┻\n");
		}
		else{
			printf("wrong input, please input 0 ~ 5\n");
		}
	}
}
