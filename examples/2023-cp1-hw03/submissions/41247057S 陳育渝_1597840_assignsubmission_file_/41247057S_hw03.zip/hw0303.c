#include <stdio.h>
#include <stdint.h>

int32_t sign = 0;

void BinaryForm ( int64_t i, int32_t n );

void BinaryForm ( int64_t i, int32_t n ){
	n--;
	if ( i >= 0 && n > 0 && sign == 1){
		BinaryForm ( i / 2 , n);
		if ( n == 9 ){
			printf(" ");
		}
		if ( n == 17 ){
			printf(" ");
		}
		if ( n == 25 ){
			printf(" ");
		}
		printf("%lld", i % 2);
	}
	if ( i <= 0 && n > 0 && sign == -1){
		BinaryForm ( i / 2 , n);
		if ( n == 9 ){
			printf(" ");
		}
		if ( n == 17 ){
			printf(" ");
		}
		if ( n == 25 ){
			printf(" ");
		}
		if ( -i % 2 == 0 ){
			printf("1");
		}
		else if ( -i % 2 == 1 ){
			printf("0");
		}
	}
}

int main()
{
	int64_t num = 0;

	printf("Please enter the number: ");
	scanf("%lld", &num);
	if (!( num < 2147483648 && num > -2147483648 )){
		printf("Please input signed 32-bit integer :(\n");
		return 0;
	}

	if ( num >= 0 ){
		sign = 1;
		BinaryForm ( num, 33 );
	}
	else{
		sign = -1;
		BinaryForm ( num + 1, 33 );
	}
	printf("\n");

	return 0;
}
