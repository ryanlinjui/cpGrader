#include <stdio.h>
#include <stdint.h>

void move ( int32_t n, int32_t a, int32_t b, int32_t c);

