#include <stdio.h>
#include <stdint.h>

void action01 ();
void action02 (int32_t a, int32_t x);
void action03 (int32_t a, int32_t x, int32_t y, int32_t b);
void action04 (int32_t a, int32_t x, int32_t h, int32_t l, int32_t c, int32_t b);
void action05 (int32_t input);
