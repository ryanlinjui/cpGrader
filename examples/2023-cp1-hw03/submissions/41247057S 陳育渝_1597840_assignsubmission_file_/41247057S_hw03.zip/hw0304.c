#include <stdio.h>
#include <stdint.h>
#include "hw0304.h"

int main()
{
	int32_t num = 0;
	printf("Please enter the disk number (2-20): ");
	scanf("%d", &num);
	if (num < 2 || num > 20){
		printf("Please enter the number in the range :(\n");
		return 0;
	}
	move(num, 1, 2, 3);
	return 0;
}
