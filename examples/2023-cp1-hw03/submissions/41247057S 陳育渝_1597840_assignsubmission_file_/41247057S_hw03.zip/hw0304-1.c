#include <stdio.h>
#include <stdint.h>

// recursive version

void move (int32_t n, int32_t a, int32_t b, int32_t c);

void move (int32_t n, int32_t a, int32_t b, int32_t c){
	if (n == 1){
		printf("move disk %d to rod %d\n", n, b);
		return;
	}
	else if (n > 0){
		move (n - 1, a, c, b);
		printf("move disk %d to rod %d\n", n, b);
		move (n - 1, c, b, a);
	}
}
