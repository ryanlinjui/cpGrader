/*
                                                        .-------.    ______
  _____  _            _____       _ _           _      /   o   /|   /\     \
 |  __ \(_)          |  __ \     | | |         | |    /_______/o|  /o \  o  \
 | |  | |_  ___ ___  | |__) |___ | | | ___ _ __| |    | o     | | /   o\_____\
 | |  | | |/ __/ _ \ |  _  // _ \| | |/ _ \ '__| |    |   o   |o/ \o   /o    /
 | |__| | | (_|  __/ | | \ \ (_) | | |  __/ |  |_|    |     o |/   \ o/  o  /
 |_____/|_|\___\___| |_|  \_\___/|_|_|\___|_|  (_)    '-------'     \/____o/   
*/
#include "diceRolls.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define PAUSE printf("Press Enter key to continue..."); fgetc(stdin); 
#define red "\x1b[;31;1m"
#define blue "\x1b[;34;1m"
#define reset "\x1b[0;m"
#define yellow "\033[0;33m"
#define purple "\033[0;35m"
#define green_bg "\033[42m"
#define red_bg "\033[41m"
#define blue_bg "\033[44m"
#define reset_bg "\x1b[0;m"



long long actions=-1;

int main(){
    title();
    while(actions!=0){
        system("clear");
        title();
        mainScreen();
        scanf("%lld", &actions);
        if(actions == 1){
            oneDsix();
        } else if(actions == 2){
            ADX();
        } else if(actions == 3){
            AdXkYplusB();
        } else if(actions == 4){
            AdXkhHklLkcCplusB();
        } else if(actions == 0){
            printf("\nThanks for using!\n");
            return 0;
        } else if(actions==2007){
            easter();
        } else {
            printf("\nError 0: Invalid Input!\nPlease enter the number in the screen\n\n");
            printf("Press enter to continue...\n");
            getchar();
            getchar();
        }
    }
    
}