Name: 吳俊廷
Student ID: 41247032S

## How to build the program?
Open the terminal and type "make" to build the program.

## How to execute your built programs?
Open the terminal and type "./<hw03YY>" to execute the program, which YY is the problem number.
For example, ./hw0202 is the executable program for homework #2 problem 2.
NOTICE: You should prepare hw0301.c and hw0302.c in the directory before you make.

## About hw0305
### Introductions
I love TRPG, too! This program is a dice roller for TRPG. You can use this program to roll dice for your TRPG games.
This program can roll dice with any number of faces, and you can roll multiple dice at the same time.
For example, you can roll 3 dice with 6 faces, or roll 1 dice with 20 faces.

You can also add a modifier to the result of the dice roll.
For example, you can roll 1 dice with 20 faces and add 5 to the result.

### How to use the program?
1. Open the program, and type the number of which action you want to do.
NOTICE: Please only type integer. If you type other characters in menu page, you will only see the beautiful dice animations. (Yes! It's a wonderful feature)
2. Follow the instructions on the screen.
3. If you want to exit the program, type 0 when you are in the menu page.

### Features Implemented
1. Let users call for a roll of 1d6
2. Let users call for a roll of AdX
3. Let users call for a roll of AdXkY+B
4. Let users call for a roll of AdXkhHklLkcC+B

### Other Features
1. A cool name of the simulator, "Dice Roller!"
2. Outstanding User Interface and Experience
3. Wonderful dice animations when you roll the dice.
4. Record the number of dice you roll and the result of the dice roll.
5. Beautiful title banner for your eyes. (with colors!)
6. Output error messages when you type wrong input.
7. Cool dice skin with different colors.
8. Auto clean the screen when you enter every page.
(Easter egg) If you type 2007 in the menu page, you will see "Cake is a lie!", which is a famous quote from the game "Portal".

###Special Note 
When you choose the dice, each dice can only be chose once. 