#include "diceRolls.h"

#define PAUSE printf("Press Enter key to continue..."); fgetc(stdin); 
#define red "\x1b[;31;1m"
#define blue "\x1b[;34;1m"
#define reset "\x1b[0;m"
#define yellow "\033[0;33m"
#define purple "\033[0;35m"


int compare(const void * a, const void * b) {
    return ( *(long long*)b - *(long long*)a );
}

void title(){
    printf("                                                        .-------.    ______\n");
    printf("  _____  _            _____       _ _           _      /   "red"o"reset"   /|   /\\     \\\n");
    printf(" |  __ \\(_)          |  __ \\     | | |         | |    /_______/o|  /o \\  "red"o"reset"  \\\n");
    printf(" | |  | |_  ___ ___  | |__) |___ | | | ___ _ __| |    | o     | | /   o\\_____\\\n");
    printf(" | |  | | |/ __/ _ \\ |  _  // _ \\| | |/ _ \\ '__| |    |   o   |o/ \\o   /o    /\n");
    printf(" | |__| | | (_|  __/ | | \\ \\ (_) | | |  __/ |  |_|    |     o |/   \\ o/  o  /\n");
    printf(" |_____/|_|\\___\\___| |_|  \\_\\___/|_|_|\\___|_|  (_)    '-------'     \\/____o/   \n");
    printf("\n");
   // printf("                                                             Made by: Junting Wu\n\n");
    printf("-----------------------------------------------------------------------------------\n\n\n\n");
}

void mainScreen(){
    printf("Welcome To Dice Roller!\n\n\n");
    printf("  1. (1d6)             :Roll One 6-sided die.\n\n");
    printf("  2. (AdX)             :Roll [A] dice(s) with [X] sides each.\n\n");
    printf("  3. (AdXkY+B)         :Roll [A] dice(s) with [X] sides each and add [B] to the result.\n\n");
    printf("  4. (AdXkhHklLkcC+B)  :Roll [A] dice with [X] sides each, keeping the [H] highest, the [L] lowest,\n"); 
    printf("                        and [C] of the player’s choice, and add [B] to the result.\n\n");
    printf("  0. Exit The Program!\n\n");
    printf("-----------------------------------------------------------------------------------\n\n");
    printf("Please type a number to choose your action: ");
}

void diceAnimation(){
    for(int i=0;i<2;i++){
        system("clear");
        printf("               (( _______\n");
        printf("     _______     /\\O    O\\\n");
        printf("    /O     /\\   /  \\      \\\n");
        printf("   /   O  /O \\ / O  \\O____O\\ ))\n");
        printf("((/_____O/    \\\\    /O     /\n");
        printf("  \\O    O\\    / \\  /   O  /\n");
        printf("   \\O    O\\ O/   \\/_____O/\n");
        printf("    \\O____O\\/             ))\n");
        printf("  ((                        \n");
        printf("\nRolling.\n");
        usleep(300000);
        system("clear");
        printf("                  _______))\n");
        printf("     _______ ))  /\\O    O\\\n");
        printf("    /O     /\\   /  \\      \\\n");
        printf("   /   O  /O \\ / O  \\O____O\\ ))\n");
        printf("  /_____O/    \\\\    /O     /\n");
        printf("  \\O    O\\    / \\  /   O  /\n");
        printf("   \\O    O\\ O/   \\/_____O/\n");
        printf("    \\O____O\\/ ))  ((          \n");
        printf("                            \n");
        printf("\nRolling..\n");
        usleep(300000);
    }
    system("clear");
    printf("               (( _______\n");
    printf("     _______     /\\O    O\\\n");
    printf("    /O     /\\   /  \\      \\\n");
    printf("   /   O  /O \\ / O  \\O____O\\ ))\n");
    printf("((/_____O/    \\\\    /O     /\n");
    printf("  \\O    O\\    / \\  /   O  /\n");
    printf("   \\O    O\\ O/   \\/_____O/\n");
    printf("    \\O____O\\/             ))\n");
    printf("  ((                        \n\n\n\n");
    
}

void showNumber(long long number){
    printf(purple);
    printf("   __________\n");
    printf("  /\\__________\\\n");
    printf(" | /          /\n");
    printf(" `. _________.\n");
    printf("  |\\   ");
    printf(yellow);

    printf("%lld", number);
    printf(purple);
    if(number<10){
        printf("  ");
    }else if(number<100){
        printf(" ");
    }

    printf("   \\\n");
    printf("  | |---------|\n");
    printf("  \\ | Neokent!|\n");
    printf("   \\|_________|\n");
    printf(reset);
}

void oneDsix(){
    srand(time(0)); // use current time as seed for random generator
    long long random_number = rand() % 6 + 1; // generate a random number between 1 and 6
    diceAnimation();
    showNumber(random_number);
    printf("\n\n");
    printf("----------------------------------------\n");
    printf("Final Result: \n\n");
    printf("Total: %lld\n\n", random_number);
    printf("Press enter to continue...\n");
    getchar();
    getchar();
}

void ADX(){
    long long total=0;
    long long total_each[105]={0};
    system("clear");
    long long A, X;
    printf("Please enter the number of dice(s) you want to roll [A]: ");
    scanf("%lld", &A);
    if(A>10||A<0){
        printf("\nError 0: Invalid Input!\n[A] should be a integer between 0~10\n\n");
        printf("Press enter to continue...\n");
        getchar();
        getchar();
        return;
    }

    printf("Please enter the number of sides of the dice(s) [X]: ");
    scanf("%lld", &X);
    if(X>100||X<2){
        printf("\nError 0: Invalid Input!\n[X] should be a integer between 2~100\n\n");
        printf("Press enter to continue...\n");
        getchar();
        getchar();
        return;
    }
    diceAnimation();
    srand(time(0)); // use current time as seed for random generator
    for(long long i=0;i<A;i++){
        
        long long random_number = rand() % X + 1; // generate a random number between 1 and X
        total+=random_number;
        total_each[i]=random_number;
        showNumber(random_number);
    }
    printf("\n\n");
    printf("----------------------------------------\n");
    printf("Final Result: \n\n");
    printf("Total: ");
    for(int i=0;i<A;i++){
        printf("%lld", total_each[i]);
        if(i!=A-1){
            printf(" + ");
        }
    }
    printf(" = %lld\n\n", total);
    printf("\n\n");
    printf("Press enter to continue...\n");
    getchar();
    getchar();
}

void AdXkYplusB(){
    long long total=0;
    long long total_each[105]={0};
    long long B;
    long long Y;
    system("clear");
    long long A, X;
    printf("Please enter the number of dice(s) you want to roll [A]: ");
    scanf("%lld", &A);
    if(A>10||A<0){
        printf("\nError 0: Invalid Input!\n[A] should be a integer between 0~10\n\n");
        printf("Press enter to continue...\n");
        getchar();
        getchar();
        return;
    }

    printf("Please enter the number of sides of the dice(s) [X]: ");
    scanf("%lld", &X);
    if(X>100||X<2){
        printf("\nError 0: Invalid Input!\n[X] should be a integer between 2~100\n\n");
        printf("Press enter to continue...\n");
        getchar();
        getchar();
        return;
    }
    printf("Please enter the number you want to add to the result [B]: ");
    scanf("%lld", &B);
    if(B>10||B<-10){
        printf("\nError 0: Invalid Input!\n[B] should be a integer between -10~10\n\n");
        printf("Press enter to continue...\n");
        getchar();
        getchar();
        return;
    }

    printf("Please enter the number of dice(s) you want to keep [Y]: ");
    scanf("%lld", &Y);
    if(Y>A||Y<0){
        printf("\nError 0: Invalid Input!\n[Y] should be a integer between 0~[A]\n\n");
        printf("Press enter to continue...\n");
        getchar();
        getchar();
        return;
    }

    diceAnimation();

    srand(time(0)); // use current time as seed for random generator
    for(long long i=0;i<A;i++){
        
        long long random_number = rand() % X + 1; // generate a random number between 1 and X
        
        total_each[i]=random_number;
        printf("ID: %lld\n", i+1);
        showNumber(random_number);
        printf("\n\n");
    }
    printf("\n\n");

    long long already_choose[105]={0};
    long long already_choose_each[105]={0};
    printf("You can choose %lld dice(s) to keep.\n", Y);
    for(long long i=0;i<Y;i++){
        printf("(%lld/%lld) Please enter the ID of the dice(s) you want to keep: ", i+1, Y);
        long long ID;
        scanf("%lld", &ID);
        if(ID>A||ID<1){
            printf("\nError 0: Invalid Input!\n[ID] should be a integer between 1~[A]\n\n");
            printf("Press enter to continue...\n");
            getchar();
            getchar();
            return;
        }else if(already_choose[ID-1]==1){
            printf("\nError 1: Invalid Input!\nYou have already choose this dice!\n\n");
            printf("Press enter to continue...\n");
            getchar();
            getchar();
            return;
        }else{
            already_choose[ID-1]=1;
            already_choose_each[i]=total_each[ID-1];
            total+=total_each[ID-1];
        }
    }
    printf("\n\n");
    printf("You have choose: \n\n");
    if(Y==0){
        printf("Nothing :)\n\n");
    }else{
        for(int i=0;i<Y;i++){
            showNumber(already_choose_each[i]);
        }
    }
    
    printf("----------------------------------------\n");
    printf("Final Result: \n\n");
    printf("\n\nB=%lld\n", B);
    printf("\nTotal: ");
    for(int i=0;i<Y;i++){
        printf("%lld", already_choose_each[i]);
        if(i!=Y-1){
            printf(" + ");
        }
    }
    if(B>0){
        printf(" + %lld", B);
        total+=B;
    }
    printf(" = %lld\n\n", total);
    printf("\n\n");
    printf("Press enter to continue...\n");
    getchar();
    getchar();

}

void AdXkhHklLkcCplusB(){
    long long total=0;
    long long total_each[105]={0};
    long long B;
    long long Y;
    long long H;
    long long L;

    system("clear");
    long long A, X;
    printf("Please enter the number of dice(s) you want to roll [A]: ");
    scanf("%lld", &A);
    if(A>10||A<0){
        printf("\nError 0: Invalid Input!\n[A] should be a integer between 0~10\n\n");
        printf("Press enter to continue...\n");
        getchar();
        getchar();
        return;
    }

    printf("Please enter the number of sides of the dice(s) [X]: ");
    scanf("%lld", &X);
    if(X>100||X<2){
        printf("\nError 0: Invalid Input!\n[X] should be a integer between 2~100\n\n");
        printf("Press enter to continue...\n");
        getchar();
        getchar();
        return;
    }
    printf("Please enter the number you want to add to the result [B]: ");
    scanf("%lld", &B);
    if(B>10||B<-10){
        printf("\nError 0: Invalid Input!\n[B] should be a integer between -10~10\n\n");
        printf("Press enter to continue...\n");
        getchar();
        getchar();
        return;
    }

    printf("Please enter the number of dice(s) you want to keep [Y]: ");
    scanf("%lld", &Y);
    if(Y>A||Y<0){
        printf("\nError 0: Invalid Input!\n[Y] should be a integer between 0~[A]\n\n");
        printf("Press enter to continue...\n");
        getchar();
        getchar();
        return;
    }

    printf("Please enter the number of highest dice(s) you want to keep [H]: ");
    scanf("%lld", &H);
    if(H>A||H<0){
        printf("\nError 0: Invalid Input!\n[H] should be a integer between 0~[A]\n\n");
        printf("Press enter to continue...\n");
        getchar();
        getchar();
        return;
    }

    printf("Please enter the number of lowest dice(s) you want to keep [L]: ");
    scanf("%lld", &L);
    if(L>A||L<0){
        printf("\nError 0: Invalid Input!\n[L] should be a integer between 0~[A]\n\n");
        printf("Press enter to continue...\n");
        getchar();
        getchar();
        return;
    }

    if(H+L+Y>A){
        printf("\nError 2: H+L+Y>A\nYou don't have enough dices to keep.\n[H]+[L]+[Y] should be less than or equal to [A]\n\n");
        printf("Press enter to continue...\n");
        getchar();
        getchar();
        return;
    }
    diceAnimation();

    srand(time(0)); // use current time as seed for random generator
    for(long long i=0;i<A;i++){
        
        long long random_number = rand() % X + 1; // generate a random number between 1 and X
        
        total_each[i]=random_number;
        //printf("ID: %lld\n", i+1);
        showNumber(random_number);
        printf("\n\n");
    }
    
    //sort
    qsort(total_each, A, sizeof(long long), compare);
    // choose highest
    printf("\n\n");
    printf("You choose %lld highest dice(s) to keep.\n", H);
    for(long long i=0;i<H;i++){
        showNumber(total_each[i]);
        total+=total_each[i];
    }
    
    // choose lowest
    printf("\n\n");
    printf("You choose %lld lowest dice(s) to keep.\n", L);
    for(long long i=A-1;i>A-1-L;i--){
        showNumber(total_each[i]);
        total+=total_each[i];
    }


    // choose Y
    printf("\n\n");
    long long new_dice_each[105]={0};
    long long newA=A-H-L;
    if(Y!=0){
        printf("Here is the left dice(s) you can choose: \n\n");
        for(int i=0;i<A-H-L;i++){
            new_dice_each[i]=total_each[i+H];
            printf("ID: %d\n", i+1);
            showNumber(new_dice_each[i]);
            printf("\n\n");
        }
    }
    
    
    long long already_choose[105]={0};
    long long already_choose_each[105]={0};
    printf("You can choose %lld dice(s) to keep.\n", Y);
    for(long long i=0;i<Y;i++){
        printf("(%lld/%lld) Please enter the ID of the dice(s) you want to keep: ", i+1, Y);
        long long ID;
        scanf("%lld", &ID);
        if(ID>newA||ID<1){
            printf("\nError 0: Invalid Input!\n[ID] should be a integer between 1~%lld\n\n", newA);
            printf("Press enter to continue...\n");
            getchar();
            getchar();
            return;
        }else if(already_choose[ID-1]==1){
            printf("\nError 1: Invalid Input!\nYou have already choose this dice!\n\n");
            printf("Press enter to continue...\n");
            getchar();
            getchar();
            return;
        }else{
            already_choose[ID-1]=1;
            already_choose_each[i]=new_dice_each[ID-1];
            total+=new_dice_each[ID-1];
        }
    }
    printf("\n\n");
    printf("You have choose: \n\n");
    if(Y==0){
        printf("Nothing :)\n\n");
    }else{
        for(int i=0;i<Y;i++){
            showNumber(already_choose_each[i]);
        }
    }
    
    printf("----------------------------------------\n");
    printf("Final Result: \n\n");
    printf("\n\nB=%lld\n", B);
    // process each element of output
    long long output_total_each[105]={0};
    for(int i=0;i<H;i++){
        output_total_each[i]=total_each[i];
    }
    for(int i=0;i<Y;i++){
        output_total_each[i+H]=already_choose_each[i];
    }
    for(int i=0;i<L;i++){
        output_total_each[i+H+Y]=total_each[A-1-i];
    }
    output_total_each[H+Y+L]=B;
    printf("\nTotal: ");
    for(int i=0;i<H+Y+L+1;i++){
        printf("%lld", output_total_each[i]);
        if(i!=H+Y+L){
            printf(" + ");
        }
    }
    total+=B;
    printf(" = %lld\n\n", total);
    printf("\n\n");
    printf("Press enter to continue...\n");
    getchar();
    getchar();
}

void easter(){
    system("clear");
    printf("              .,-:;//;:=,\n");
    printf("          . :H@@@MM@M#H/.,+%%;,\n");
    printf("       ,/X+ +M@@M@MM%%=,-%%HMMM@X/,\n");
    printf("     -+@MM; $M@@MH+-,;XMMMM@MMMM@+-\n");
    printf("    ;@M@@M- XM@X;. -+XXXXXHHH@M@M#@/.\n");
    printf("  ,%%MM@@MH ,@%%=             .---=-=:=,.\n");
    printf("  =@#@@@MX.,                -%%HX$$%%%%:;\n");
    printf(" =-./@M@M$                   .;@MMMM@MM:\n");
    printf(" X@/ -$MM/                    . +MM@@@M$\n");
    printf(",@M@H: :@:                    . =X#@@@@-\n");
    printf(",@@@MMX, .                    /H- ;@M@M=\n");
    printf(".H@@@@M@+,                    %%MM+..%%#$.\n");
    printf(" /MMMM@MMH/.                  XM@MH; =;\n");
    printf("  /%%+%%$XHH@$=              , .H@@@@MX,\n");
    printf("   .=--------.           -%%H.,@@@@@MX,\n");
    printf("   .%%MM@@@HHHXX$$$%%+- .:$MMX =M@@MM%%.\n");
    printf("     =XMMM@MM@MM#H;,-+HMM@M+ /MMMX=\n");
    printf("       =%%@M@M#@$-.=$@MM@@@M; %%M%%=\n");
    printf("         ,:+$+-,/H#MMMMMMM@= =,\n");
    printf("               =++%%%%+/:-.\n");
    printf("\n\n");
    printf("Cake is a lie!\n\n");
    printf("Press enter to continue...\n");
    getchar();
    getchar();

}
