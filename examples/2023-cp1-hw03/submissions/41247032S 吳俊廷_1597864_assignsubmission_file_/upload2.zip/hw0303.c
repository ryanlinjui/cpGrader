#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
long long num=-1;
void print_binary_recursive(int n, int bit) {
    
    if (bit < 0) {
        return;
    }

    int current_bit = n / (int)pow(2, bit) % 2;
    if(num<0&&bit==31){
        current_bit=1;
    }
    printf("%d", abs(current_bit));

    if (bit % 8 == 0 && bit != 0) {
        printf(" ");
    }

    print_binary_recursive(n, bit - 1);
}

void BinaryForm(int n) {
    if (n < 0) {
        n = pow(2, 31) - abs(n);
    }

    print_binary_recursive(n, 31);
}

int main() {
    printf("Please enter the number: ");
    scanf("%lld", &num);
    if(num>2147483647){
        printf("Error: The number is too large.\n");
        return 0;
    }else if(num<-2147483648){
        printf("Error: The number is too small.\n");
        return 0;
    }
    BinaryForm(num);
    printf("\n");
    return 0;
}