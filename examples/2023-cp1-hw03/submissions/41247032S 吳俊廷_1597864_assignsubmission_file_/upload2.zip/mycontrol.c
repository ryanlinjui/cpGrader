#include "mycontrol.h"
#define M_PI 3.14159265358979323846
// Setup the initial position to (x,y) and the moving direction.
// a is the angle counterclockwise from x axis.
double init_x=-1;
double init_y=-1;
double init_angle=-1;
int64_t already=0;//0: uninitialize, 1: initialize
void initialize( double x, double y, double a){
    init_x=x;
    init_y=y;
    init_angle=a/M_PI;
    already=1;
}

// From the current , move forward length with the given direction.
// If the initial position is not set, return -1.
int32_t forward( double length ){
    if(already==0){
        return -1;
    }else{
        init_x+=length*cos(init_angle);
        init_y+=length*sin(init_angle);
        return 0;
    }
}

// From the current direction , turn clockwise/counterclockwise x.
// If the initial position is not set, return -1.
int32_t clock_turn( double x ){
    if(already==0){
        return -1;
    }else{
        init_angle-=x;
        if(init_angle<0){
            init_angle+=2*M_PI;
        }
        return 0;
    }
}
int32_t counterclock_turn( double x ){
    if(already==0){
        return -1;
    }else{
        init_angle+=x;
        if(init_angle>=2*M_PI){
            init_angle-=2*M_PI;
        }
        return 0;
    }
}

// Print the current location and the direction.
// The print format is "position: (x,y), angle: a".
// a is the angle counterclockwise from x axis and 0 <= a < 2pi
// If the initial position is not set, return -1.
int32_t print(){
    if(already==0){
        return -1;
    }else{
        printf("position: (%.2lf,%.2lf), angle: %.2lf\n",init_x,init_y,init_angle/M_PI);
        return 0;
    }
}