#include <stdio.h>
#include <stdlib.h>

#define MAX_DISKS 20
#define MAX_STATES 2000

typedef struct {
    int top;
    int disks[MAX_DISKS];
} Pole;

typedef struct {
    int n;
    char from;
    char aux;
    char to;
    int pos;
} State;

Pole pole[3];
State stack[MAX_STATES];
int top = -1;

void push(State state) {
    stack[++top] = state;
}

State pop() {
    return stack[top--];
}

int main() {
    long long n = 2; // Number of disks
    printf("Please enter the disk number (2-20): ");
    scanf("%lld", &n);
    if(n < 2 || n > 20) {
        printf("Invalid input.\n");
        return 0;
    }
    for (int i = n; i >= 1; i--) {
        pole[0].disks[++pole[0].top] = i;
    }
    push((State){n, '1', '3', '2', 1});
    while (top != -1) {
        State state = pop();
        if (state.n == 1) {
            printf("Move disk 1 to %c\n", state.to);
            pole[state.to - '1'].disks[++pole[state.to - '1'].top] = pole[state.from - '1'].disks[pole[state.from - '1'].top--];
        } else if (state.pos == 1) {
            push((State){state.n, state.from, state.aux, state.to, 2});
            push((State){state.n - 1, state.from, state.to, state.aux, 1});
        } else if (state.pos == 2) {
            printf("Move disk %d to %c\n", state.n, state.to);
            pole[state.to - '1'].disks[++pole[state.to - '1'].top] = pole[state.from - '1'].disks[pole[state.from - '1'].top--];
            push((State){state.n - 1, state.aux, state.from, state.to, 1});
        }
    }
    return 0;
}