#include "mycircle.h"
// Setup the radius r of the circle.
// This function must be called before all other functions.
// If r <= 0, return -1; otherwise , return 0.
long long already=0;//0->radis is undefined; 1->radius is defined
static double radius=-1;

double find_triangle_area(int32_t ax, int32_t ay, int32_t bx, int32_t by){
    // Check if the points are distinct or the line is parallel to axis X/Y
    if (ax == bx && ay == by) {
        //printf("Error: Points A and B are not distinct.\n");
        return -1;
    }
    if (ax == bx) {
        //printf("Error: The line is parallel to axis Y.\n");
        return -1;
    }
    if (ay == by) {
        //printf("Error: The line is parallel to axis X.\n");
        return -1;
    }

    // Find the equation of the line AB using the point-slope form
    // y - y1 = m(x - x1)
    // where m is the slope and (x1, y1) is a point on the line

    long double m = (long double)(by - ay) / (bx - ax); // Slope of the line

    // Find the x and y intercepts of this line using the slope-intercept form
    long double y_intercept = ay - (m * ax);
    long double x_intercept = -1 * (y_intercept / m);

    // Calculate the area of the triangle
    long double area = 0.5 * x_intercept * y_intercept;
    if(area < 0) area = -area;

    // Print error message if area is 0
    if (area == 0) {
        //printf("Error: Area is 0. Please enter valid points.\n");
        return -1;
    }

    return area;

}

int32_t set_radius( double r){
    if(r<=0){
        return -1;
    }else{
        already=1;
        radius=r;
        return 0;
    }
}

// Return the circumference of the circle
// If the radius is not set, return a negative number.
double get_circle_circumference(){
    if(already==0){
        return -1;
    }else{
        return 2*3.14159265358979323846*radius;
    }
}

// Return the area of the circle
// If the radius is not set, return a negative number.
double get_circle_area(){
    if(already==0){
        return -1;
    }else{
        return 3.14159265358979323846*radius*radius;
    }
}

// Given x, (x,y) is a point on the upper circle.
// Return the area bounded by the tangent line at (x,y), x-axis
// and y-axis.
// If the radius is not set, return a negative number.
// If it cannot form a triangle , return a negative number.
// If x is not a reasonable input , return a negative number.
double get_tangent_area( double x ){
    if(already==0||radius<=0){
        return -1;
    }else{
        if(x<=-radius||x>=radius||x==0){
            return -2;
        }else{
            double y=sqrt(radius*radius-x*x);
            //printf("DEBUG:y=%f\n",y);
            double m=-1*((x-0)/(y-0));
            //printf("DEBUG:m=%f\n",m);
            double y_intercept=y-(m*x);
            double x_intercept = -y_intercept/m;
            return fabs(x_intercept*y_intercept/2);
        }
    }

}
// Return the inner and outer regular polygon area.
// If the radius is not set, return a negative number.
// If n < 3, return a negative number.
double get_inner_regular_polygon_area( int32_t n ){
    if (n < 3 || already==0|| radius <= 0) {
        return -1.0; // 如果邊數小於3或半徑無效，返回負數
    }

    //double triangleOuterAngle = 360/n;
    double triangleInnerAngle = 360/n;


    double polygonArea = 0.5*radius*radius * sin(triangleInnerAngle * 3.14159265358979323846 / 180.0);
    //printf("DEBUG:triangleInnerAngle=%f\n",triangleInnerAngle);
    //printf("DEBUG:sin:%f\n",sin(triangleInnerAngle * 3.14159265358979323846 / 180.0));
    //printf("DEBUG:polygonArea=%f\n",polygonArea);



    return n*polygonArea;
}

double get_outer_regular_polygon_area( int32_t n ){
    if (n < 3 || already==0|| radius <= 0) {
        return -1.0; // 如果邊數小於3或半徑無效，返回負數
    }

    //double triangleOuterAngle = 360/n;
    double triangleInnerAngle = 360/n;

    double newRadius=radius/(cos(triangleInnerAngle/2 * 3.14159265358979323846 / 180.0));
    double polygonArea = 0.5*newRadius*newRadius * sin(triangleInnerAngle * 3.14159265358979323846 / 180.0);
    //printf("DEBUG:triangleInnerAngle=%f\n",triangleInnerAngle);
    //printf("DEBUG:sin:%f\n",sin(triangleInnerAngle * 3.14159265358979323846 / 180.0));
    //printf("DEBUG:polygonArea=%f\n",polygonArea);



    return n*polygonArea;
}