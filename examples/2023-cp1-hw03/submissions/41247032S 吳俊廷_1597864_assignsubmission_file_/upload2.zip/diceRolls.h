#pragma once
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
void title();
void mainScreen();
void diceAnimation();
void showNumber(long long number);
void oneDsix();
void ADX();
void AdXkYplusB();
void AdXkhHklLkcCplusB();
void easter();
int compare(const void * a, const void * b);

/*Image Asserts*/
/*

               (( _______
     _______     /\O    O\
    /O     /\   /  \      \
   /   O  /O \ / O  \O____O\ ))
((/_____O/    \\    /O     /
  \O    O\    / \  /   O  /
   \O    O\ O/   \/_____O/
    \O____O\/ ))          ))
  ((                                                
                                
         __________
        /\__________\
       | /         /
       `. ________.
        |\         \
        | |---------|
        \ | Neokent!|
         \| ________|
*/
