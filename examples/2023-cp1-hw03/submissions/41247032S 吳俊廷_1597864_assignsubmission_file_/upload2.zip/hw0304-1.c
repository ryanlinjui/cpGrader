#include <stdio.h>
#include <stdlib.h>

#define MAX_DISKS 20

typedef struct {
    int top;
    int disks[MAX_DISKS];
} Pole;

Pole pole[3];

void moveDisks(int n, char from, char aux, char to) {
    if (n == 1) {
        printf("Move disk 1 to %c\n", to);
        pole[to - '1'].disks[++pole[to - '1'].top] = pole[from - '1'].disks[pole[from - '1'].top--];
        return;
    }
    moveDisks(n - 1, from, to, aux);
    printf("Move disk %d to %c\n", n, to);
    pole[to - '1'].disks[++pole[to - '1'].top] = pole[from - '1'].disks[pole[from - '1'].top--];
    moveDisks(n - 1, aux, from, to);
}

int main() {
    long long n = 2; // Number of disks
    printf("Please enter the disk number (2-20): ");
    scanf("%lld", &n);
    if(n < 2 || n > 20) {
        printf("Invalid input.\n");
        return 0;
    }
    for (int i = n; i >= 1; i--) {
        pole[0].disks[++pole[0].top] = i;
    }
    moveDisks(n, '1', '3', '2');  // A, B and C are names of rods
    return 0;
}