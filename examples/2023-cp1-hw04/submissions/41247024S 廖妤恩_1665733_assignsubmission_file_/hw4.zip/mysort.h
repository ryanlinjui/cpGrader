#include<stdio.h>
#include<stdint.h>

void mysort ( int32_t array[], int32_t size );
void myprint ( int32_t array[], int32_t size );

void mysort ( int32_t array[], int32_t size )
{
    if ( size < 0 )
    {
        printf ("Wrong input.\n");
    }
    
    for ( int i = 0 ; i < size ; i ++ )
    {
        for ( int j = 0 ; j < size ; j ++ )
        {
            if ( array[i]%2 == 0  &&  array[j]%2 == 1 )
            {
                int32_t temp = array[i];
                array[i] = array[j];
                array[j] = temp;   
            }
        }
    }  
    
    for ( int i = 0 ; i < size ; i ++ )
    {
        for ( int j = 0 ; j < size ; j ++ )
        {
            if ( array[i]%2 == 1  &&  array[j]%2 == 1 && array[i] < array[j] )
            {
                int32_t temp = array[i];
                array[i] = array[j];
                array[j] = temp;   
            }
            else if ( array[i]%2 == 0  &&  array[j]%2 == 0 && array[i] > array[j] )
            {
                int32_t temp = array[i];
                array[i] = array[j];
                array[j] = temp;   
            }
        }
    }
    
}


void myprint ( int32_t array[], int32_t size )
{
    for ( int i = 0 ; i < size ; i++ )
    {
        printf ( "%d ", array[i] );
    }
    
    printf ("\n");

}