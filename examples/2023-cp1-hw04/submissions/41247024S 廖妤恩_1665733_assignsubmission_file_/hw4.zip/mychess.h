#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>

#define EMPTY (0)
#define RED_GENERAL (1)
#define RED_ADVISOR (2)
#define RED_ELEPHANT (3)
#define RED_HORSE (4)
#define RED_CHARIOT (5)
#define RED_CANNON (6)
#define RED_SOLDIER (7)
#define BLACK_GENERAL (11)
#define BLACK_ADVISOR (12)
#define BLACK_ELEPHANT (13)
#define BLACK_HORSE (14)
#define BLACK_CHARIOT (15)
#define BLACK_CANNON (16)
#define BLACK_SOLDIER (17)

static int32_t error = 0;
static int32_t returnnum = 0;

int32_t checkmate ( int32_t board[10][9] );
int32_t check ( int32_t arr[10][9], int32_t num, int32_t big, int32_t small );
int32_t horsemove ( int32_t xhorse, int32_t yhorse, int32_t xaim, int32_t yaim );

int32_t horsemove ( int32_t xhorse, int32_t yhorse, int32_t xaim, int32_t yaim )
{
    if ( ( abs ( xhorse - xaim ) == 1 || abs ( xhorse - xaim ) == 2 ) && abs ( xhorse - xaim ) + abs ( yhorse - yaim ) == 3 )
    {
        printf ("Move Horse from (%d,%d) to (%d,%d)\n", xhorse, yhorse, xaim, yaim );
        returnnum++;
    }
}

int32_t check ( int32_t arr[10][9], int32_t num, int32_t big, int32_t small )
{
    int32_t count = 0;
    for ( int i = 0 ; i < 10 ; i ++ )
    {
        for ( int j = 0 ; j < 9 ; j ++ )
        {
            if ( arr[i][j] == num )
            {
                count = count + 1;
            }
        }
    }
    if ( count > big || count < small )
    {
        error = error + 1;
    }
}

int32_t checkmate ( int32_t board[10][9] )
{
    //check board 
    //number
    //general
    check ( board, 1, 1, 1 );
    check ( board, 11, 1, 1 );
    //advisor
    check ( board, 2, 2, 0 );
    check ( board, 12, 2, 0 );
    //elephant
    check ( board, 3, 2, 0 );
    check ( board, 13, 2, 0 );
    //horse
    check ( board, 4, 2, 0 );
    check ( board, 14, 2, 0 );
    //chariot
    check ( board, 5, 2, 0 );
    check ( board, 15, 2, 0 );
    //cannon
    check ( board, 6, 2, 0 );
    check ( board, 16, 2, 0 );
    //soldier
    check ( board, 7, 5, 0 );
    check ( board, 17, 5, 0 );
    if ( error > 0 ) return-1;
    
    for ( int i = 0 ; i < 10 ; i ++ )
    {
        for ( int j = 0 ; j < 9 ; j ++ )
        {
             if ( board[i][j] < 0 || ( board[i][j] > 7 && board[i][j] < 11 ) || board[i][j] > 17 )
             {
                  return -1;
             }
        }
    }
    
    //site
    //general
    for ( int i = 0 ; i < 10 ; i ++ )
    {
        for ( int j = 0 ; j < 3 ; j ++ )
        {
            if ( board[i][j] == 1 || board[i][j] == 11 || board[i][j] == 2 || board[i][j] == 12 )
            {
                return -1;
            }
        }
    }
    for ( int i = 3 ; i < 7 ; i ++ )
    {
        for ( int j = 3 ; j < 6 ; j ++ )
        {
            if ( board[i][j] == 1 || board[i][j] == 11 || board[i][j] == 2 || board[i][j] == 12 )
            {
                return -1;
            }
        }
    }
    for ( int i = 0 ; i < 10 ; i ++ )
    {
        for ( int j = 6 ; j < 9 ; j ++ )
        {
            if ( board[i][j] == 1 || board[i][j] == 11 || board[i][j] == 2 || board[i][j] == 12 )
            {
                return -1;
            }
        }
    }
    
    int32_t red_general[2];
    int32_t black_general[2];
    //check exact site
    int32_t condition = 0;
    for ( int i = 0 ; i < 3 ; i ++ )
    {
        for ( int j = 3 ; j < 6 ; j ++ )
        {
            if ( board[i][j] == 1 )
            {
                if ( condition == 2 )
                {
                    return -1;
                }
                else
                {
                    //red down
                    red_general[0] = i;
                    red_general[1] = j;
                    condition = 1;
                }
            }
            else if ( board[i][j] == 11 )
            {
                if ( condition == 1 )
                {
                    return -1;
                }
                else
                {
                    //black down
                    black_general[0] = i;
                    black_general[1] = j;
                    condition = 2;
                }           
            }
        }
    }
    if ( condition == 1 )
    {
        for ( int i = 7 ; i < 10 ; i ++ )
        {
            for ( int j = 3 ; j < 6 ; j ++ )
            {
                if ( board[i][j] == 11 )
                {
                    black_general[0] = i;
                    black_general[1] = j;
                }
            }
        }
    }
    else if ( condition == 2 )
    {
        for ( int i = 7 ; i < 10 ; i ++ )
        {
            for ( int j = 3 ; j < 6 ; j ++ )
            {
                if ( board[i][j] == 1 )
                {
                    red_general[0] = i;
                    red_general[1] = j;
                }
            }
        }
    }
    //advisor
    if ( condition == 1 )
    {
        for ( int i = 0 ; i < 10 ; i ++ )
        {
            for ( int j = 0 ; j < 9 ; j ++ )
            {
                 if ( board[i][j] == 2 )
                 {
                      if ( i > 2 ) return -1;
                      else if ( i == 2 )
                      {
                           if ( j != 3 && j != 5 ) return -1;   
                      }
                      else if ( i == 1 )
                      {
                           if ( j != 4 ) return -1;
                      }
                      else if ( i == 0 )
                      {
                           if ( j != 3 && j != 5 ) return -1;
                      } 
                 }
                 if ( board[i][j] == 12 )
                 {
                      if ( i < 7 ) return -1;
                      else if ( i == 7 )
                      {
                           if ( j != 3 && j != 5 ) return -1;   
                      }
                      else if ( i == 8 )
                      {
                           if ( j != 4 ) return -1;
                      }
                      else if ( i == 9 )
                      {
                           if ( j != 3 && j != 5 ) return -1;
                      }
                 }
            }
        }
    }
    else if ( condition == 2 )
    {
        for ( int i = 0 ; i < 10 ; i ++ )
        {
            for ( int j = 0 ; j < 9 ; j ++ )
            {
                 if ( board[i][j] == 12 )
                 {
                      if ( i > 2 ) return -1;
                      else if ( i == 2 )
                      {
                           if ( j != 3 && j != 5 ) return -1;   
                      }
                      else if ( i == 1 )
                      {
                           if ( j != 4 ) return -1;
                      }
                      else if ( i == 0 )
                      {
                           if ( j != 3 && j != 5 ) return -1;
                      } 
                 }
                 if ( board[i][j] == 2 )
                 {
                      if ( i < 7 ) return -1;
                      else if ( i == 7 )
                      {
                           if ( j != 3 && j != 5 ) return -1;   
                      }
                      else if ( i == 8 )
                      {
                           if ( j != 4 ) return -1;
                      }
                      else if ( i == 9 )
                      {
                           if ( j != 3 && j != 5 ) return -1;
                      }
                 }
            }
        }
    }
    
    //elephant
    if ( condition == 1 )
    {
        for ( int i = 0 ; i < 10 ; i ++ )
        {
            for ( int j = 0 ; j < 9 ; j ++ )
            {
                 if ( board[i][j] == 3 )
                 {
                     if ( i > 4 || i == 3 || i == 1 )
                     {
                          return -1;
                     }
                     else if ( i == 4 || i == 0 )
                     {
                          if ( j != 2 && j != 6 ) return -1;
                     }
                     else if ( i == 2 )
                     {
                          if ( j != 0 && j != 4 && j != 8 ) return -1;		
                     }
                 }
                 if ( board[i][j] == 13 )
                 {
                     if ( i < 4 || i == 6 || i == 8 )
                     {
                          return -1;
                     }
                     else if ( i == 5 || i == 9 )
                     {
                          if ( j != 2 && j != 6 ) return -1;
                     }
                     else if ( i == 7 )
                     {
                          if ( j != 0 && j != 4 && j != 8 ) return -1;   
                     }
                 }
            }
        }
    }
    else
    {
        for ( int i = 0 ; i < 10 ; i ++ )
        {
            for ( int j = 0 ; j < 9 ; j ++ )
            {
                 if ( board[i][j] == 13 )
                 {
                     if ( i > 4 || i == 3 || i == 1 )
                     {
                          return -1;
                     }
                     else if ( i == 4 || i == 0 )
                     {
                          if ( j != 2 && j != 6 ) return -1;
                     }
                     else if ( i == 2 )
                     {
                          if ( j != 0 && j != 4 && j != 8 ) return -1;
                     }
                 }
                 if ( board[i][j] == 3 )
                 {
                     if ( i < 4 || i == 6 || i == 8 )
                     {
                          return -1;
                     }
                     else if ( i == 5 || i == 9 )
                     {
                          if ( j != 2 && j != 6 ) return -1;
                     }
                     else if ( i == 7 )
                     {
                          if ( j != 0 && j != 4 && j != 8 ) return -1;   
                     }
                 }
            }
        }
    
    }
    
    //soldier
    if ( condition == 1 )
    {
        for ( int i = 0 ; i < 3 ; i ++ )
        {
            for ( int j = 0 ; j < 9 ; j ++ )
            {
                if ( board[i][j] == 7 )
                {
                    return -1;
                }
            }
        }
        for ( int j = 1 ; j < 9 ; j = j + 2 )
        {
            if ( board[3][j] == 7 )
            {
                return -1;
            }
        }
        for ( int i = 7 ; i < 9 ; i ++ )
        {
            for ( int j = 0 ; j < 9 ; j ++ )
            {
                if ( board[i][j] == 17 )
                {
                    return -1;
                }
            }
        }
        for ( int j = 1 ; j < 9 ; j = j + 2 )
        {
            if ( board[6][j] == 17 )
            {
                return -1;
            }
        }
    }
    else if ( condition == 2 )
    {
        for ( int i = 0 ; i < 3 ; i ++ )
        {
            for ( int j = 0 ; j < 9 ; j ++ )
            {
                if ( board[i][j] == 17 )
                {
                    return -1;
                }
            }
        }
        for ( int j = 1 ; j < 9 ; j = j + 2 )
        {
            if ( board[3][j] == 17 )
            {
                return -1;
            }
        }
        for ( int i = 7 ; i < 9 ; i ++ )
        {
            for ( int j = 0 ; j < 9 ; j ++ )
            {
                if ( board[i][j] == 7 )
                {
                    return -1;
                }
            }
        }
        for ( int j = 1 ; j < 9 ; j = j + 2 )
        {
            if ( board[6][j] == 7 )
            {
                return -1;
            }
        }
    }

    //move
    //king vs king
    int32_t sum = 0;
    if ( condition == 1 )
    {
        sum = 0;
        if ( red_general[1]-1 > 2 && red_general[1]-1 < 6 && board[red_general[0]][red_general[1]-1] == 0 && red_general[1]-1 == black_general[1] ) 
        {
            for ( int i = red_general[0] ; i < black_general[0] ; i ++ )
            {
                sum = sum + board[i][red_general[1]-1];
            }
            if ( sum == 0 )
            {
                printf ("Move General from (%d,%d) to (%d,%d)\n", red_general[0], red_general[1], red_general[0], red_general[1]-1 );
                returnnum++;
            }
        }
        sum = 0;
        if ( red_general[1]+1 > 2 && red_general[1]+1 < 6 && board[red_general[0]][red_general[1]+1] == 0 && red_general[1]+1 == black_general[1] ) 
        {
            for ( int i = red_general[0] ; i < black_general[0] ; i ++ )
            {
                sum = sum + board[i][red_general[1]+1];
            }
            if ( sum == 0 )
            {
                printf ("Move General from (%d,%d) to (%d,%d)\n", red_general[0], red_general[1], red_general[0], red_general[1]+1 );
                returnnum++;
            }
        }      
    }
    else if ( condition == 2 )
    {
    	sum = 0;
        if ( red_general[1]-1 > 2 && red_general[1]-1 < 6 && board[red_general[0]][red_general[1]-1] == 0 && red_general[1]-1 == black_general[1] ) 
        {
            for ( int i = red_general[0] ; i > black_general[0] ; i -- )
            {
                sum = sum + board[i][red_general[1]-1];
            }
            if ( sum == 0 )
            {
                printf ("Move General from (%d,%d) to (%d,%d)\n", red_general[0], red_general[1], red_general[0], red_general[1]-1 );
                returnnum++;
            }
        }
        sum = 0;
        if ( red_general[1]+1 > 2 && red_general[1]+1 < 6 && board[red_general[0]][red_general[1]+1] == 0 && red_general[1]+1 == black_general[1] ) 
        {
            for ( int i = red_general[0] ; i > black_general[0] ; i -- )
            {
                sum = sum + board[i][red_general[1]+1];
            }
            if ( sum == 0 )
            {
                printf ("Move General from (%d,%d) to (%d,%d)\n", red_general[0], red_general[1], red_general[0], red_general[1]+1 );
                returnnum++;
            }
        }
    }
    
    //horse
    //find site
    int32_t horse[2][2] = { {10, 10}, {10, 10} };
    for ( int i = 0 ; i < 10 ; i ++ )
    {
        for ( int j = 0 ; j < 9 ; j ++ )
        {
            if ( board[i][j] == 4 )
            {
                if ( horse[0][0] == 10 )
                {
                    horse[0][0] = i;
                    horse[0][1] = j;
                }
                else
                {
                    horse[1][0] = i;
                    horse[1][1] = j;
                }
            } 
        }
    }
    
    //move   
    if ( board[black_general[0]+1][black_general[1]] == 0 )
    {
        if ( board[black_general[0]+2][black_general[1]-1] == 0 )
        {
            if ( horse[0][0] != 10 )
            {
                //xhorse yhorse xaim yaim
                horsemove ( horse[0][0], horse[0][1], black_general[0]+2, black_general[1]-1 );
            }
            if ( horse[1][0] != 10 )
            {
                horsemove ( horse[1][0], horse[1][1], black_general[0]+2, black_general[1]-1 );
            }
        }
        if ( board[black_general[0]+2][black_general[1]+1] == 0 )
        {
            if ( horse[0][0] != 10 )
            {
                //xhorse yhorse xaim yaim
                horsemove ( horse[0][0], horse[0][1], black_general[0]+2, black_general[1]+1 );
            }
            if ( horse[1][0] != 10 )
            {
                horsemove ( horse[1][0], horse[1][1], black_general[0]+2, black_general[1]+1 );
            }
        }
    }    
    if ( board[black_general[0]-1][black_general[1]] == 0 )
    {
        if ( board[black_general[0]-2][black_general[1]-1] == 0 )
        {
            if ( horse[0][0] != 10 )
            {
                //xhorse yhorse xaim yaim
                horsemove ( horse[0][0], horse[0][1], black_general[0]-2, black_general[1]-1 );
            }
            if ( horse[1][0] != 10 )
            {
                horsemove ( horse[1][0], horse[1][1], black_general[0]-2, black_general[1]-1 );
            }
        }
        if ( board[black_general[0]-2][black_general[1]+1] == 0 )
        {
            if ( horse[0][0] != 10 )
            {
                //xhorse yhorse xaim yaim
                horsemove ( horse[0][0], horse[0][1], black_general[0]-2, black_general[1]+1 );
            }
            if ( horse[1][0] != 10 )
            {
                horsemove ( horse[1][0], horse[1][1], black_general[0]-2, black_general[1]+1 );
            }
        }
    }
    if ( board[black_general[0]][black_general[1]+1] == 0 )
    {
        if ( board[black_general[0]+1][black_general[1]+2] == 0 )
        {
            if ( horse[0][0] != 10 )
            {
                //xhorse yhorse xaim yaim
                horsemove ( horse[0][0], horse[0][1], black_general[0]+1, black_general[1]+2 );
            }
            if ( horse[1][0] != 10 )
            {
                horsemove ( horse[1][0], horse[1][1], black_general[0]+1, black_general[1]+2 );
            }
        }
        if ( board[black_general[0]-1][black_general[1]+2] == 0 )
        {
            if ( horse[0][0] != 10 )
            {
                //xhorse yhorse xaim yaim
                horsemove ( horse[0][0], horse[0][1], black_general[0]-1, black_general[1]+2 );
            }
            if ( horse[1][0] != 10 )
            {
                horsemove ( horse[1][0], horse[1][1], black_general[0]-1, black_general[1]+2 );
            }
        }
    }
    if ( board[black_general[0]][black_general[1]-1] == 0 )
    {
        if ( board[black_general[0]+1][black_general[1]-2] == 0 )
        {
            if ( horse[0][0] != 10 )
            {
                //xhorse yhorse xaim yaim
                horsemove ( horse[0][0], horse[0][1], black_general[0]+1, black_general[1]-2 );
            }
            if ( horse[1][0] != 10 )
            {
                horsemove ( horse[1][0], horse[1][1], black_general[0]+1, black_general[1]-2 );
            }
        }
        if ( board[black_general[0]-1][black_general[1]-2] == 0 )
        {
            if ( horse[0][0] != 10 )
            {
                //xhorse yhorse xaim yaim
                horsemove ( horse[0][0], horse[0][1], black_general[0]-1, black_general[1]-2 );
            }
            if ( horse[1][0] != 10 )
            {
                horsemove ( horse[1][0], horse[1][1], black_general[0]-1, black_general[1]-2 );
            }
        }
    }
    
    //car!
    //find car
    int32_t car[2][2] = { {10,10}, {10,10} };
    for ( int i = 0 ; i < 10 ; i ++ )
    {
        for ( int j = 0 ; j < 9 ; j ++ )
        {
            if ( board[i][j] == 5 )
            {
                if ( car[0][0] == 10 )
                {
                    car[0][0] = i;
                    car[0][1] = j;
                }
                else
                {
                    car[1][0] = i;
                    car[1][1] = j;
                }
            }
        }
    }
    //general x 
    int32_t maybe[2][2];
    sum = 0;
    for(int j=0;j<2;j++){
    if ( car[j][0] != 10 )
    {
        if( car[j][0] == black_general[0] )
        {
            int obstacle = 0, target_y = 0;
            int start_y = car[j][1] > black_general[1] ? black_general[1] : car[j][1];
            for (int i = start_y+1 ; i < car[j][1] - start_y + black_general[1] ; i++ )
            {
        	if ( board[car[j][0]][i] != EMPTY )
        	{
        		obstacle += 1;
        		target_y = i;
                }
            }
        if ( obstacle == 1 ) 
        {
            printf("Move Chariot from (%d,%d) to (%d,%d)\n",car[j][0],car[j][1],car[j][0],target_y);
            returnnum++;
        }
        
    }
    else if ( car[j][1] == black_general[1] )
    {
        int obstacle = 0, target_y = 0;
        int start_y = car[j][0] > black_general[0] ? black_general[0] : car[j][0];
        
        for ( int i = start_y+1 ; i < car[j][0] - start_y + black_general[0] ; i++ )
        {
        	if ( board[i][car[j][1]] != EMPTY )
        	{
        	    obstacle += 1;
        	    target_y = i;
                }
        }
        if ( obstacle == 1 ) 
        {
        	printf("Move Chariot from (%d,%d) to (%d,%d)\n",car[j][0],car[j][1],target_y,car[j][1]);
        	returnnum++;
        }
   }
   else
   {    
       int start_x = car[j][0];
       int start_y = car[j][1];
       
       if (start_x > black_general[0]) start_x = black_general[0];
       if (start_y > black_general[1]) start_y = black_general[1];
       	
       int end_x = car[j][0] + black_general[0] - start_x;
       int end_y = car[j][1] + black_general[1] - start_y;
       
       int possible = 1;
       if ( car[j][0] < black_general[0] )
       {
          for(int i=start_y+1;i<end_y;i++)
          {
              if(board[car[j][0]][i]!=EMPTY) possible = 0;
          }
       //printf("%d",possible);
       if(possible){
       for(int i=start_x+1;i<end_x;i++){
       
          if(board[i][black_general[1]]!=EMPTY) possible = 0;
       
       }
          //printf("%d",possible);
       if(possible) 
       {
           returnnum++;
           printf("Move Chariot from (%d,%d) to (%d,%d)\n",car[j][0],car[j][1],car[j][0],black_general[1]);
       }
       }
       
       possible = 1;
      
       for(int i=start_x+1;i<end_x;i++){
       	//printf("%d %d %d %d\n",possible,i,car[j][1],board[i][car[j][1]]);
          if(board[i][car[j][1]]!=EMPTY) possible = 0;
       
       }
       if(possible){
          for(int i=start_y+1;i<end_y;i++){
       
          if(board[black_general[0]][i]!=EMPTY) possible = 0;
       
       }
       if(possible) 
       {
           returnnum++;
           printf("Move Chariot from (%d,%d) to (%d,%d)\n",car[j][0],car[j][1],black_general[0],car[j][1]);
       }
       }
       }
       else{
       for(int i=start_x+1;i<end_x;i++){
          if(board[i][car[j][1]]!=EMPTY) possible = 0;
       
       }//printf("%d",possible);
       if(possible){
          for(int i=start_y+1;i<end_y;i++){
       
          if(board[black_general[0]][i]!=EMPTY) possible = 0;
       
       }//printf("%d",possible);
       if(possible) 
       {
           returnnum++;
           printf("Move Chariot from (%d,%d) to (%d,%d)\n",car[j][0],car[j][1],black_general[0],car[j][1]);
       }
       }
       
       possible = 1;
       for(int i=start_y+1;i<end_y;i++){
       
          if(board[car[j][0]][i]!=EMPTY) possible = 0;
       
       }
       //printf("%d",possible);
       if(possible){
       for(int i=start_x+1;i<end_x;i++){
       
          if(board[i][black_general[1]]!=EMPTY) possible = 0;
       
       }
          //printf("%d",possible);
       if(possible) 
       {
            returnnum++;
            printf("Move Chariot from (%d,%d) to (%d,%d)\n",car[j][0],car[j][1],car[j][0],black_general[1]);
       }
       }}
       
       }}
        
    } 
    
    //CANNON
    //find cannon
    int32_t cannon[2][2] = { {10,10}, {10,10} };
    for ( int i = 0 ; i < 10 ; i ++ )
    {
    	for ( int j = 0 ; j < 9 ; j ++ )
    	{
            if ( board[i][j] == 6 )
            {
               if ( cannon[0][0] == 10 )
               {
                    cannon[0][0] = i;
                    cannon[0][1] = j;
               }
               else
               {
                    cannon[1][0] = i;
                    cannon[1][1] = j;
               }	  
            }
    	}
    }
    
    //eat
    int32_t start = 0;
    int32_t end = 0;
    for ( int i = 0 ; i < 2 ; i ++ )
    {
        int32_t chessnumber = 0;
        if ( cannon[i][0] == black_general[0] )
        {
            if ( cannon[i][1] > black_general[1] ) start = black_general[1]+1, end = cannon[i][1]-1;
            if ( cannon[i][1] < black_general[1] ) start = cannon[i][1]+1, end = black_general[1]-1; 
            for ( int j = start ; j < end ; j ++ )
            {
                 if ( board[black_general[0]][j] != 0 ) chessnumber++;
            }
            if ( chessnumber == 1 )
            {
                 returnnum++;
                 for ( int j = start ; j < end ; j ++ )
                 {
                      if ( board[black_general[0]][j] != 0 )
                      {
                           if ( cannon[i][1] > black_general[1] ) printf ("Move Cannon from (%d,%d) to (%d,%d)\n", cannon[i][0], cannon[i][1], cannon[i][0], j+1 );     
                           else printf ("Move Cannon from (%d,%d) to (%d,%d)\n", cannon[i][0], cannon[i][1], cannon[i][0], j-1 );
                      }
                 }
            }
            else if ( chessnumber == 3 )
            {
                 int32_t count = 0;
                 returnnum++;
                 for ( int j = start ; j < end ; j ++ )
                 {
                      if ( board[black_general[0]][j] != 0 ) count++;
                      if ( count == 2 ) 
                      {
                          printf ("Move Cannon from (%d,%d) to (%d,%d)\n", cannon[i][0], cannon[i][1], cannon[i][0], j );
                      }
                 }
            }
        }
        else if ( cannon[i][1] == black_general[1] )
        {
            if ( cannon[i][0] > black_general[0] ) start = black_general[0]+1, end = cannon[i][0]-1;
            if ( cannon[i][0] < black_general[0] ) start = cannon[i][0]+1, end = black_general[0]-1; 
            for ( int j = start ; j < end ; j ++ )
            {
                 if ( board[j][black_general[1]] != 0 ) chessnumber++;
            }
            if ( chessnumber == 1 )
            {
                 returnnum++;
                 for ( int j = start ; j < end ; j ++ )
                 {
                      if ( board[j][black_general[1]] != 0 )
                      {
                           if ( cannon[i][0] > black_general[0] ) printf ("Move Cannon from (%d,%d) to (%d,%d)\n", cannon[i][0], cannon[i][1], j+1, cannon[i][1] );     
                           else printf ("Move Cannon from (%d,%d) to (%d,%d)\n", cannon[i][0], cannon[i][1], j-1, cannon[i][1] );
                      }
                 }
            }
            else if ( chessnumber == 3 )
            {
                 int32_t count = 0;
                 returnnum++;
                 for ( int j = start ; j < end ; j ++ )
                 {
                      if ( board[j][black_general[1]] != 0 ) count++;
                      if ( count == 2 ) printf ("Move Cannon from (%d,%d) to (%d,%d)\n", cannon[i][0], cannon[i][1], j, cannon[i][1] );
                 }
            }
        }
        else
        {
            //point a
            chessnumber = 0;
            if ( cannon[i][0] > black_general[0] ) start = black_general[0]+1, end = cannon[i][0]-1;
            else start = cannon[i][0]+1, end = black_general[0]-1;
            for ( int j = start ; j < end ; j ++ )
            {
                 if ( board[j][black_general[1]] != 0 ) chessnumber++;
            }
            if ( chessnumber == 1 )
            {
                 chessnumber = 0;
                 if ( cannon[i][1] > black_general[1] ) start = black_general[1]+1, end = cannon[i][1]-1;
                 else start = cannon[i][1]+1, end = black_general[1]-1;
                 for ( int j = start ; j < end ; j ++ )
                 {
                      if ( board[cannon[i][0]][j] != 0 ) chessnumber++;
                 }
                 if ( chessnumber == 0 || ( chessnumber == 1 && board[cannon[i][0]][black_general[1]] > 10 ) ) 
                 {
                      returnnum++;
                      printf ("Move Cannon from (%d,%d) to (%d,%d)\n", cannon[i][0], cannon[i][1], cannon[i][0], black_general[1] );
                 }
            }
            //point b
            chessnumber = 0;
            if ( cannon[i][1] > black_general[1] ) start = black_general[1]+1, end = cannon[i][1]-1;
            else start = cannon[i][1]+1, end = black_general[1]-1;
            for ( int j = start ; j < end ; j ++ )
            {
                 if ( board[black_general[0]][j] != 0 ) chessnumber++;
            }
            if ( chessnumber == 1 )
            {
                 chessnumber = 0;
                 if ( cannon[i][0] > black_general[0] ) start = black_general[0]+1, end = cannon[i][0]-1;
                 else start = cannon[i][0]+1, end = black_general[0]-1;
                 for ( int j = start ; j < end ; j ++ )
                 {
                      if ( board[j][cannon[i][1]] != 0 ) chessnumber++;
                 }
                 if ( chessnumber == 0 || ( chessnumber == 1 && board[black_general[0]][cannon[i][1]] > 10 ) ) 
                 {
                      returnnum++;
                      printf ("Move Cannon from (%d,%d) to (%d,%d)\n", cannon[i][0], cannon[i][1], black_general[0], cannon[i][1] );
                 }
            }
        }
    } 
        
    //soldier
    //find soldier
    int32_t soldiercount = 0;
    int32_t soldier[5][2] = { {10,10}, {10,10}, {10,10}, {10,10}, {10,10} };
    for ( int i = 0 ; i < 10 ; i ++ )
    {
        for ( int j = 0 ; j < 9 ; j ++ )
        {
            if ( board[i][j] == 7 )
            {
                 soldier[soldiercount][0] = i;
                 soldier[soldiercount][1] = j; 
                 soldiercount++;
            }
        }
    }
    
    //eat
    for ( int i = 0 ; i < 5 ; i ++ )
    {
        if ( soldier[i][0] != 10 )
        {
             if ( abs (soldier[i][0]-black_general[0]) + abs (soldier[i][1]-black_general[1]) == 2 )
             {
                  if ( abs(soldier[i][0]-black_general[0]) == 2 )
                  {
                       if ( condition == 1 )
                       {
                            if ( soldier[i][0]-black_general[0] < 0 ) 
                            {
                                 returnnum++;
                                 printf ("Move Soldier from (%d,%d) to (%d,%d)\n", soldier[i][0], soldier[i][1], soldier[i][0]+1, soldier[i][1] );
                            }
                       }
                       else
                       {
                            if ( soldier[i][0]-black_general[0] > 0 ) 
                            {
                                 returnnum++;
                                 printf ("Move Soldier from (%d,%d) to (%d,%d)\n", soldier[i][0], soldier[i][1], soldier[i][0]-1, soldier[i][1] );
                            }
                       }                            
                  }
                  else if ( abs(soldier[i][1]-black_general[1]) == 2 )
                  {
                       if ( soldier[i][1]-black_general[1] > 0 )
                       {
                            returnnum++;
                            printf ("Move Soldier from (%d,%d) to (%d,%d)\n", soldier[i][0], soldier[i][1], soldier[i][0], soldier[i][1]-1 );
                       }
                       else
                       {
                            returnnum++;
                            printf ("Move Soldier from (%d,%d) to (%d,%d)\n", soldier[i][0], soldier[i][1], soldier[i][0], soldier[i][1]+1 );
                       }
                  }
                  else
                  {
                       if ( condition == 1 )
                       {
                            if ( soldier[i][0]-black_general[0] == 1 )
                            {
                                 returnnum++;
                                 printf ("Move Soldier from (%d,%d) to (%d,%d)\n", soldier[i][0], soldier[i][1], soldier[i][0]-1, soldier[i][1] );
                                 if ( soldier[i][1] > black_general[1] )
                                 {
                                      returnnum++;
                                      printf ("Move Soldier from (%d,%d) to (%d,%d)\n", soldier[i][0], soldier[i][1], soldier[i][0], soldier[i][1]-1 );
                                 }
                                 else
                                 {
                                      returnnum++;
                                      printf ("Move Soldier from (%d,%d) to (%d,%d)\n", soldier[i][0], soldier[i][1], soldier[i][0], soldier[i][1]+1 );
                                 }
                            } 
                       }
                       else
                       {
                            if ( soldier[i][0]-black_general[0] == -1 )
                            {
                                 returnnum++;
                                 printf ("Move Soldier from (%d,%d) to (%d,%d)\n", soldier[i][0], soldier[i][1], soldier[i][0]+1, soldier[i][1] );
                                 if ( soldier[i][1] > black_general[1] )
                                 {
                                      returnnum++;
                                      printf ("Move Soldier from (%d,%d) to (%d,%d)\n", soldier[i][0], soldier[i][1], soldier[i][0], soldier[i][1]-1 );
                                 }
                                 else
                                 {
                                      returnnum++;
                                      printf ("Move Soldier from (%d,%d) to (%d,%d)\n", soldier[i][0], soldier[i][1], soldier[i][0], soldier[i][1]+1 );
                                 }
                            }
                       }
                  }
             }    
        }
    }
    
    return returnnum;
    
}