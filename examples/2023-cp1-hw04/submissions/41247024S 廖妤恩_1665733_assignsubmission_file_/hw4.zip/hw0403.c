#include<stdio.h>
#include<stdint.h>
#include<math.h>
#include"gsat.h"

int32_t sort ( int32_t subject, int32_t time );

int32_t sort ( int32_t subject, int32_t time )
{
    for ( int i = 0 ; i < time ; i ++ )
    {
        for ( int j = 0 ; j < time ; j ++ )
        {
            if ( score[i][subject] < score[j][subject] )
            {
                int32_t temp = score[i][subject];
                score[i][subject] = score[j][subject];
                score[j][subject] = temp;
            }
        }
    }
    /*
    for ( int i = 0 ; i < time ; i ++ )
    {
        printf ( "%d ", score[i][subject] );
    }
    printf ("\n");*/

}

int main()
{   
    //chinese
    sort ( 0, STUDENT_NUMBER );
    //english
    sort ( 1, STUDENT_NUMBER );
    //math_a
    sort ( 2, STUDENT_NUMBER );
    //math_b
    sort ( 3, STUDENT_NUMBER );
    //social
    sort ( 4, STUDENT_NUMBER );
    //science
    sort ( 5, STUDENT_NUMBER );
    
    int32_t list[5][6];
    
    double din = STUDENT_NUMBER*0.88;
    double chen = STUDENT_NUMBER*0.75;
    double gin = STUDENT_NUMBER*0.50;
    double ho = STUDENT_NUMBER*0.25;
    double di = STUDENT_NUMBER*0.12;
    
    int32_t realdin = (int)floor(din);
    int32_t realchen = (int)floor(chen);
    int32_t realgin = (int)floor(gin);
    int32_t realho = (int)floor(ho);
    int32_t realdi = (int)floor(di);
    
    /*
    printf ( "%f %f %f %f %f\n", din, chen, gin, ho, di );
    printf ( "%d %d %d %d %d\n", realdin, realchen, realgin, realho, realdi );
    */
    
    //printf
    printf ("           CHINESE | ENGLISH | MATH_A | MATH_B | SOCIAL | SCIENCE\n");
    printf ("TOP 12%%         %2d        %2d       %2d       %2d       %2d        %2d\n", score[realdin][0], score[realdin][1], score[realdin][2], score[realdin][3], score[realdin][4], score[realdin][5] );
    printf ("TOP 25%%         %2d        %2d       %2d       %2d       %2d        %2d\n", score[realchen][0], score[realchen][1], score[realchen][2], score[realchen][3], score[realchen][4], score[realchen][5] );
    printf ("TOP 50%%         %2d        %2d       %2d       %2d       %2d        %2d\n", score[realgin][0], score[realgin][1], score[realgin][2], score[realgin][3], score[realgin][4], score[realgin][5] );
    printf ("TOP 75%%         %2d        %2d       %2d       %2d       %2d        %2d\n", score[realho][0], score[realho][1], score[realho][2], score[realho][3], score[realho][4], score[realho][5] );
    printf ("TOP 88%%         %2d        %2d       %2d       %2d       %2d        %2d\n", score[realdi][0], score[realdi][1], score[realdi][2], score[realdi][3], score[realdi][4], score[realdi][5] );
        
    
    



}