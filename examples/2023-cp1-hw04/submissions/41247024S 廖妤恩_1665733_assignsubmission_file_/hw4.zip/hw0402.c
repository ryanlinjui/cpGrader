#include<stdio.h>
#include<stdint.h>

int32_t gcd ( int32_t a, int32_t b );
int32_t numcount ( int32_t array[], int32_t time );
int32_t print ( int32_t array[], int32_t time );

int32_t gcd ( int32_t a, int32_t b )
{
    while ( b != 0 )
    {
        int temp = b;
        b = a % b;
        a = temp;
    }
    
    return a;
}

int32_t numcount ( int32_t array[], int32_t time )
{
    
    int32_t num = 0;
    int32_t fu = 0;
    int32_t addcount = 0;
    
    for ( int i = time ; i >= 0 ; i -- )
    {
        
        if ( array[i] == 0 )
        {
            continue;
        }
        
        if ( fu == 0)
        {
            if ( array[i] < 0 )
            {
                num = num + 1;
            }
            fu = fu + 1;
        }
        
        //x^?
        if ( i >= 10 )
        {
            num = num + 4;
        }
        else if ( i >= 2 )
        {
            num = num + 3;
        }
        else if ( i == 1 )
        {
            num = num + 1;
        }
        
        if ( array[i] < 0 )
        {
            array[i] = -array[i];
        }
        else if ( array[i] == 1 )
        {
            addcount = addcount + 1;
            continue;
        }
            
        while ( array[i] >= 1 )
        {
            array[i] = array[i]/10;
            num = num + 1;
        }
        
        addcount = addcount + 1;
            
    }
    
    num = num + addcount - 1;
    return num;
}

int32_t print ( int32_t array[], int32_t time )
{
    for ( int i = time ; i >= 0 ; i -- )
    {
        if ( i == time )
        {
            if ( i == 0 )
            {
                printf ( "%d", array[i] );
                continue;
            }
            if ( array[i] == 1 )
            {
                if ( i == 1 )
                {
                    printf ( "x" );
                    continue;
                }
                else
                {
                    printf ( "x^%d", i );
                    continue;
                }
            }
            else if ( array[i] == -1 )
            {
                printf ( "-x^%d", i );
                continue;
            }
            else if ( i == 1 )
            {
                printf ( "%dx", array[i] );
                continue;
            }
            else
            {
                printf ( "%dx^%d", array[i], i );
                continue;
            }
        }
        
        if ( i == 0 && array[i] == 0 )
        {
            continue;
        }
        if ( i == 0 )
        {
            if ( array[i] > 0 )
            {
                printf ("+%d", array[i]);
                continue;
            }
            else
            {
                printf ("%d", array[i]);
                continue;
            }
        }
        if ( array[i] == 0 )
        {
            continue;
        }
        
        if ( array[i] > 0 )
        {
            printf ("+");
        }
        
        if ( array[i] == 1 )
        {
            if ( i == 1 )
            {
                printf ("x");
            }
            else
            {
                printf ("x^%d", i);
            }
        }
        else if ( array[i] == -1 ) 
        {
            if ( i == 1 )
            {
                printf ("-x");
            }
            else
            {
                printf ("-x^%d", i);
            }
        }
        else
        {
            if ( i == 1 )
            {
                printf ( "%dx", array[i] );
            }
            else
            {
                printf ( "%dx^%d", array[i], i );
            }
        }        
    }
}

int main ()
{
    
    int32_t sizef = 0;
    int32_t sizeg = 0;
    
    printf ("Please enter f(x) degree: ");
    scanf ("%d", &sizef);
    
    if ( sizef < 0 )
    {
        printf ("Wrong input, the degree cannot be under zero.\n");
        return 0;
    }
    
    int32_t fx[sizef+1];
    printf ("Please enter f(x) coefficients: ");
    for ( int i = sizef ; i >= 0 ; i -- )
    {
        fx[i] = 0;
    }
    for ( int i = sizef ; i >= 0 ; i -- )
    {
        scanf ("%d", &fx[i]);
    }
    //avoid idiot
    if ( fx[sizef] == 0 )
    {
        printf ("Wrong input, the first coefficient cannot be zero.\n");
        return 0;
    }
    
    printf ("Please enter g(x) degree: ");
    scanf ("%d", &sizeg);
    
    if ( sizeg < 0 )
    {
        printf ("Wrong input, the degree cannot be under zero.\n");
        return 0;
    }
    
    int32_t gx[sizeg+1];
    printf ("Please enter g(x) coefficients: ");
    for ( int i = sizeg ; i >= 0 ; i -- )
    {
        gx[i] = 0;
    }
    for ( int i = sizeg ; i >= 0 ; i -- )
    {
        scanf ("%d", &gx[i]);
    }
    //avoid idiot
    if ( gx[sizeg] == 0 )
    {
        printf ("Wrong input, the first coefficient cannot be zero.\n");
        return 0;
    }
    
    printf ("f(x): ");
    print ( fx, sizef );    
    printf ("\n");
    
    printf ("g(x): ");
    print ( gx, sizeg );
    printf ("\n");
    
    int32_t multi[sizeg+sizef+1];
    printf ("(f(x)g(x))': ");
    
    for ( int i = 0 ; i <= sizeg+sizef ; i ++ )
    {
        multi[i] = 0;
    }
    
    for ( int i = 0 ; i <= sizef ; i ++ )
    {
        for ( int j = 0 ; j <= sizeg ; j ++ )
        {
            multi[i+j] = multi[i+j] + fx[i]*gx[j];
        }
    }
    
    //wei
    int32_t wei[sizef+sizeg];
    
    for ( int i = sizef+sizeg-1 ; i >= 0 ; i -- )
    {
        wei[i] = 0;
    }
    
    for ( int i = sizef+sizeg-1 ; i >= 0 ; i -- )
    {
        wei[i] = multi[i+1] * (i+1);
    }
    
    //print wei
    if ( sizef == sizeg && sizeg == 0 )
    {
        printf ("0");
    }
    else
    {
        print ( wei, sizef+sizeg-1 );
    }
    printf ("\n");
    
    //f(x)'
    int32_t ffx[sizef];
    
    for ( int i = sizef-1 ; i >= 0 ; i -- )
    {
        ffx[i] = 0;
    }
    
    for ( int i = sizef-1 ; i >= 0 ; i -- )
    {
        ffx[i] = fx[i+1] * (i+1);
    }
    
    //g(x)'
    int32_t ggx[sizeg];
    for ( int i = sizeg-1 ; i >= 0 ; i -- )
    {
        ggx[i] = 0;
    }
    
    for ( int i = sizeg-1 ; i >= 0 ; i -- )
    {
        ggx[i] = gx[i+1] * (i+1);
    }
    
    //g(x)f(x)'
    int32_t gffx[sizeg+sizef];
    for ( int i = sizeg+sizef-1 ; i >= 0 ; i -- )
    {
        gffx[i] = 0;
    }    
    for ( int i = 0 ; i <= sizeg ; i ++ )
    {
        for ( int j = 0 ; j <= sizef-1 ; j ++ )
        {
            gffx[i+j] = gffx[i+j] + gx[i]*ffx[j];
        }
    }

    //f(x)'g(x)
    int32_t ffgx[sizef+sizeg];
    for ( int i = sizeg+sizef-1 ; i >= 0 ; i -- )
    {
        ffgx[i] = 0;
    }
    for ( int i = 0 ; i <= sizeg-1 ; i ++ )
    {
        for ( int j = 0 ; j <= sizef ; j ++ )
        {
            ffgx[i+j] = ffgx[i+j] + ggx[i]*fx[j];
        }
    }
    
    //son
    int32_t son[sizef+sizeg];
    for ( int i = sizeg+sizef-1 ; i >= 0 ; i -- )
    {
        son[i] = 0;
    }
    for ( int i = sizeg+sizef-1 ; i >= 0 ; i -- )
    {
        son[i] = gffx[i] - ffgx[i];
    }
    
    //gcd
    int32_t count = 0;
    int32_t gcds = 0;
    for ( int i = sizeg+sizef-1 ; i >= 0 ; i -- )
    {
        if ( count == 0 )
        {
            gcds = gcd( son[i], son[i-1] );
            count = count + 1;
        }
        else if ( son[i] == 0 )
        {
            continue;
        }
        else
        {
            gcds = gcd ( son[i], gcds );
        }
    }
    
    //mother
    int32_t mom[2*sizeg+1];
    for ( int i = 2*sizeg ; i >= 0 ; i -- )
    {
        mom[i] = 0;
    }
    for ( int i = 0 ; i <= sizeg ; i ++ )
    {
        for ( int j = 0 ; j <= sizeg ; j ++ )
        {
            mom[i+j] = mom[i+j] + gx[i]*gx[j];
        }
    }
    
    //gcd
    count = 0;
    int32_t gcdm = 0;
    for ( int i = 2*sizeg ; i >= 0 ; i -- )
    {
        if ( count == 0 )
        {
            gcdm = gcd( mom[i], mom[i-1] );
            count = count + 1;
        }
        else if ( mom[i] == 0 )
        {
            continue;
        }
        else
        {
            gcdm = gcd ( mom[i], gcdm );
        }
    }
    
    int32_t gcdr = gcd ( gcds, gcdm );
    
    //%
    for ( int i = sizef+sizeg-1 ; i >= 0 ; i -- )
    {
        son[i] = son[i]/gcdr;
    }
    for ( int i = 2*sizeg ; i >= 0 ; i -- )
    {
        mom[i] = mom[i]/gcdr;
    }
    
    int32_t movea = 0;
    for ( int i = 0 ; i <= sizef+sizeg-1 ; i ++ )
    {
        if ( son[i] == 0 )
        {
            movea = movea + 1;
        }
        else
        {
            break;
        }
    }
    int32_t moveb = 0;
    for ( int i = 0 ; i <= 2*sizeg+1 ; i ++ )
    {
        if ( mom[i] == 0 )
        {
            moveb = moveb + 1;
        }
        else
        {
            break;
        }
    }
        
    if ( moveb < movea )
    {
        movea = moveb;
    }
    
    //son
    int i = 0;
    while ( i < movea )
    {
        for ( int j = 0 ; j <= sizef+sizeg-1-i-1 ; j ++ )
        {
            son[j] = son[j+1];
        }
        i = i + 1;
    }
    
    //mother
    i = 0;
    while ( i < movea )
    {
        for ( int j = 0 ; j <= 2*sizeg-1-i ; j ++ )
        {
            mom[j] = mom[j+1];
        }
        i = i + 1;
    }
    
    //ctrl c
    int32_t cson[sizef+sizeg-movea];
    for ( int i = sizef+sizeg-1-movea ; i >= 0 ; i -- )
    {
        cson[i] = son[i];
    }
    int32_t cmom[2*sizeg-movea+1];
    for ( int i = 2*sizeg-movea ; i >= 0 ; i -- )
    {
        cmom[i] = mom[i];
    }
    
    //num son
    int32_t numson = 0; 
    numson = numcount ( cson, sizef+sizeg-1-movea );
    
    //nummom
    int32_t nummom = 0;
    nummom = numcount ( cmom, 2*sizeg-movea );
    
    //0/0
    int32_t zeroson = 0;
    for ( int i = sizeg+sizef-1 ; i >= 0 ; i -- )
    {
        if ( son[i] == 0 )
        {
            zeroson++;
        }
    }
    if ( zeroson == sizeg + sizef )
    {
        printf (" f(x)    0\n");
        printf ("(----)': ");
        if ( sizef == sizeg && sizeg == 0 )
        {
            printf ("-");
        }
        else
        {
            for ( int i = 0 ; i < nummom ; i ++ )
            {
                printf ("-");
            }
        }
        printf ("\n");
        printf (" g(x)    ");
        print ( mom, 2*sizeg-movea );
        printf ("\n");
        return 0;
    }
    
    printf (" f(x)    ");
    print ( son, sizef+sizeg-1-movea ); 
    printf ("\n");
    
    //line
    printf ("(----)': ");
    
    if ( nummom > numson )
    {
        for ( int i = 0 ; i < nummom ; i ++ )
        {
            printf ("-");
        }
    }
    else
    {
        for ( int i = 0 ; i < numson ; i ++ )
        {
            printf ("-");
        }
    }
    
    printf ("\n");
    
    //mom
    printf (" g(x)    ");
    print ( mom, 2*sizeg-movea );
    printf ("\n");
    return 0;
    
}

