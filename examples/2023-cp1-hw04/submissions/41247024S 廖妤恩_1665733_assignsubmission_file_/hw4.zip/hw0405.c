#include<stdio.h>
#include<stdint.h>


void error()
{
    printf("The Score is...\n");
    printf("    Unreasonable case\n");
    printf("Total: 0 Han\n");
}

int main()
{
    int32_t temp, total = 0;
    int32_t this_meld = 0;
    int32_t count[34] = {0}, entered = 0;
    while ( total < 14 )
    {
        if ( total == 12 ) break;
        if ( !entered && total < 12 ) printf ( "Please input meld: " );
    
        entered = 1;
    
        scanf ( "%d", &temp );
        
        if ( !temp )
        {
            if ( this_meld == 4 )
            {
                total += 3;
                entered = 0;
                this_meld = 0;
            }
            else if ( this_meld == 3 )
            {
                total+= this_meld;
            }
            else if ( this_meld == 14 )
            {
                total += 14;
                break;
            }
            else
            {
                error();
                return 0;
            }
            printf ( "Is open group(1: YES 0: NO): ");
            scanf ( "%d", &temp );
            if ( temp > 1 || temp < 0 )
            {
                error();
                return 0;
            }
            entered = 0;
            this_meld = 0;
        }
        else if ( temp < 0 && temp > 34 )
        {
            error();
            return 0;
        }
        else
        {
            count[temp] += 1;
            this_meld += 1;
            if ( count[temp] > 4 )
            {
                error();
                return 0;    
            }
        }
    }
    if ( total == 12 )
    {
        printf ( "Please enter pair: " );
        for ( int32_t i = 0 ; i < 2 ; i ++ )
        {
            scanf ( "%d" , &temp );
            if ( temp < 0 && temp > 34 )
            {
                error();
                return 0;
            }
            else
            {
                count[temp] += 1;
                total += 1;
                if ( count[temp] > 4 )
                {
                    error();
                    return 0;    
                }
            }
        }
        if ( total != 14 )
        {
            printf ( "%d", total );
            error();
            return 0;
        }
    }
    printf ( "Please enter the winning tile: ");
    scanf ( "%d", &temp );
    if ( !count[temp] || temp < 0 || temp > 34 )
    {
        error();
        return 0;
    }
    printf ( "Player's wind(0:E 1:S 2:W 3:N): ");
    scanf ( "%d", &temp );
    if ( temp<0 || temp>3 )
    {
        error(); 
        return 0; 
    }
    printf ( "Prevailing wind(0:E 1:S 2:W 3:N): ");
    scanf ( "%d",&temp ); 
    
    if ( temp < 0 || temp > 3 )
    {
        error();
        return 0;
    }
    
    printf("The Score is...\n");
    printf("    No Yaku\n");
    printf("Total: 0 Han\n");
}
