#include <stdio.h>
#include <stdint.h>
#define N 65540

int findGCD(int64_t a, int64_t b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

void reduceFractions(int64_t arr1[], int64_t arr2[], int64_t size){
    int64_t gcd = arr1[0];
    // printf("\n\n size: %d \n\n", size);
    // for(int32_t i = 0;i < size;i++) printf("%d ", arr2[i]);
    // printf("\n");
    for(int32_t i = 0;i <= size;i++){
        if(arr1[i] == 0) continue;
        gcd = findGCD(arr1[i], gcd);
        // printf("arr: %d", arr1[i]);
    }
    // printf("\n");
    for(int32_t i = 0; i <= size; i++){
        if(arr2[i] == 0) continue;
        gcd = findGCD(gcd, arr2[i]);
    }
    // printf("gcd: %lld\n", gcd);
    if(gcd < 0) gcd = -gcd;
    for(int32_t i = 0; i <= size;i++){
        // if(arr1[i] == 0 || arr2[i] == 0) continue;
        arr1[i] /= gcd;
        arr2[i] /= gcd;
    }
}
int64_t digit(int64_t num){
    int64_t tmp = 0;
    while(num){
        num /= 10;
        tmp++;
    }
    return tmp;
}
void print(int64_t arr[], int64_t degree){
    int64_t cons = 0;
    for(int64_t i = 0;i <= degree;i++){
        if(arr[i] == 0) continue;
        if(i == degree){
            if(!cons){
                if(arr[i] > 0) printf("%lld", arr[i]);
                else printf("-%lld", -arr[i]);
                continue;
            }
            if(arr[i] > 0) printf(" + %lld", arr[i]);
            else printf(" - %lld", -arr[i]);
            continue;
        }
        if(arr[i] == 1 || arr[i] == -1){
            cons = 1;
            if(i != 0){
                if(arr[i] > 0) printf(" + ");
                else printf(" - ");
            }
            else if(i == 0){
                if(arr[i] < 0) printf("-");
            }
            if(degree - i == 1) printf("x");
            else printf("x^%lld", degree - i);
        }
        else{
            cons = 1;
            if(i != 0){
                if(arr[i] > 0) printf(" + ");
                else printf(" - ");
            }
            else if(i == 0){
                if(arr[i] < 0) printf("-");
            }
            if(degree - i == 1) printf("%lldx", arr[i]);
            else printf("%lldx^%lld", arr[i], degree - i);
        }
    }
}
int main(){
    // freopen("test.in", "r", stdin);
    int64_t f_degree, g_degree, fc[N], gc[N];
    printf("Please enter f(x) degree: ");
    scanf("%lld", &f_degree);
    if(f_degree < 0){
        printf("Invalid Input. The degree must larger than 0.\n");
        return 0;
    }
    if(f_degree > 65535){
        printf("Invalid Input. The degree must less than 65535.\n");
        return 0;
    }
    printf("Please enter f(x) coefficients: ");
    for(int64_t i = 0;i < f_degree + 1;i++){
        scanf("%lld", &fc[i]);
        if(i == 0 && fc[i] == 0){
            printf("Invalid Input. The first coeﬀicient cannot be zero.\n");
            return 0;
        }
        if(fc[i] < -2146483648 || fc[i] > 214147483647){
            printf("Invalid Input. The coefficient should between -2146483648 and 214147483647.\n");
            return 0;
        }
    }
    int64_t remain;
    scanf("%*[^\n]%n", &remain);
    if(remain != 0 && remain != 1){
        printf("Invalid Input. The number of coefficients cannot exceed the degree + 1.\n");
        return 0;
    }
    printf("Please enter g(x) degree: ");
    scanf("%lld", &g_degree);
    if(g_degree < 0){
        printf("Invalid Input. The degree must larger than 0.\n");
        return 0;
    }
    if(g_degree > 65535){
        printf("Invalid Input. The degree must less than 65535.\n");
        return 0;
    }
    printf("Please enter g(x) coefficients: ");
    for(int64_t i = 0;i < g_degree + 1;i++){
        scanf("%lld", &gc[i]);
        if(i == 0 && gc[i] == 0){
            printf("Invalid Input. The first coeﬀicient cannot be zero.\n");
            return 0;
        }
        if(gc[i] < -2146483648 || gc[i] > 214147483647){
            printf("Invalid Input. The coefficient should between -2146483648 and 214147483647.\n");
            return 0;
        }
    }
    int64_t remain2;
    scanf("%*[^\n]%n", &remain2);
    if(remain2 != 0 && remain2 != 1){
        printf("Invalid Input. The number of coefficients cannot exceed the degree + 1.\n");
        return 0;
    }
    printf("f(x): ");
    print(fc, f_degree);
    printf("\n");
    printf("g(x): ");
    print(gc, g_degree);
    printf("\n");
    printf("(f(x)g(x))': ");
    int64_t df[N], dg[N];
    for(int64_t i = 0;i < N;i++) df[i] = 0;
    for(int64_t i = 0;i < N;i++) dg[i] = 0;
    for(int64_t i = 0;i <= f_degree;i++){
        if(fc[i] != 0){
            if(i == f_degree) continue;
            int64_t tmp = (f_degree - i) * fc[i];
            df[i + 1] = tmp;
        }
    }
    for(int64_t i = 0;i <= g_degree;i++){
        if(gc[i] != 0){
            if(i == g_degree) continue;
            int64_t tmp = (g_degree - i) * gc[i];
            dg[i + 1] = tmp;
        }
    }
    int64_t product[N];
    for(int64_t i = 0;i < N;i++) product[i] = 0;
    for(int64_t i = 0;i <= f_degree;i++){
        for(int64_t j = 0;j <= g_degree;j++){
            int64_t degree_tmp = (f_degree - i) + (g_degree - j);
            product[degree_tmp] += (df[i] * gc[j]);
        }
    }
    for(int64_t i = 0;i <= f_degree;i++){
        for(int64_t j = 0;j <= g_degree;j++){
            int64_t degree_tmp = (f_degree - i) + (g_degree - j);
            product[degree_tmp] += (fc[i] * dg[j]);
        }
    }
    int64_t cnt = 0;
    for(int64_t i = f_degree + g_degree;i >= 0;i--){
        if(i == 0){
            if(product[i] != 0){
                if(product[i] > 0) printf("+%lld", product[i]);
                else printf("-%lld", -product[i]);
            }
            continue;
        }
        if(product[i] == 1 || product[i] == -1){
            if(cnt){
                if(product[i] > 0) printf("+");
                else printf("-");
            }
            if(i == 1) printf("x");
            else printf("x^%lld", i);
            cnt = 1;
        }
        else if(product[i] == 0) continue;
        else{
            if(cnt){
                if(product[i] > 0) printf("+");
                else printf("-");
            }
            if(i == 1) printf("%lldx", product[i]);
            else printf("%lldx^%lld", product[i], i);
            cnt = 1;
        }
    }
    printf("\n");
    printf(" f(x)    ");
    int64_t quotient[N], gsquare[N];
    for(int64_t i = 0;i < N;i++){
        quotient[i] = 0;
        gsquare[i] = 0;
    }
    for(int64_t i = 0;i <= f_degree;i++){
        for(int64_t j = 0;j <= g_degree;j++){
            int64_t degree_tmp = (f_degree - i) + (g_degree - j);
            quotient[degree_tmp] += (df[i] * gc[j]);
        }
    }
    for(int64_t i = 0;i <= f_degree;i++){
        for(int64_t j = 0;j <= g_degree;j++){
            int64_t degree_tmp = (f_degree - i) + (g_degree - j);
            quotient[degree_tmp] -= (fc[i] * dg[j]);
        }
    }
    for(int64_t i = 0;i <= g_degree;i++){
        for(int64_t j = 0;j <= g_degree;j++){
            int64_t degree_tmp = (g_degree - i) + (g_degree - j);
            gsquare[degree_tmp] += (gc[i] * gc[j]);
        }
    }
    while(quotient[0] == 0 && gsquare[0] == 0){
        for(int64_t i = 1;i <= (f_degree + g_degree) + 1;i++){
            quotient[i - 1] = quotient[i];
        }
        for(int64_t i = 1;i <= (2 * g_degree) + 1;i++){
            gsquare[i - 1] = gsquare[i];
        }
    }
    // for(int64_t i = 0;i <= (f_degree + g_degree);i++) printf("%d ", quotient[i]);
    // printf("\n");
    // for(int64_t i = 0;i <= (2 * g_degree);i++) printf("%d ", gsquare[i]);
    int64_t numerator = 0, denominator = 0, c = 0;
    for(int64_t i = 0;i <= f_degree + g_degree;i++){
        if(quotient[i] != 0){
            if(c) numerator++;
            if(i == 0){
                if(quotient[i] < 0){
                    numerator += digit(-quotient[i]);
                    c = 1;
                }
                else{
                    numerator += digit(quotient[i]);
                    c = 1;
                }

            }
            else if(i == 1){
                numerator += (digit(quotient[i]) + 1);
                c = 1;
            }
            else{
                if(quotient[i] == 1) numerator += (digit(i) + 2);
                else numerator += (digit(quotient[i]) + digit(i) + 2);
                c = 1;
            }
        }
    }
    c = 0;
    for(int64_t i = 0;i <= 2 * g_degree;i++){
        if(gsquare[i] != 0){
            if(c) denominator++;
            if(i == 0){
                if(gsquare[i] < 0){
                    denominator += digit(-gsquare[i]);
                    c = 1;
                }
                else{
                    denominator += digit(gsquare[i]);
                    c = 1;
                }
            }
            else if(i == 1){
                denominator += (digit(gsquare[i]) + 1);
                c = 1;
            }
            else{
                if(gsquare[i] == 1) denominator += (digit(i) + 2);
                else denominator += (digit(gsquare[i]) + digit(i) + 2);
                c = 1;
            }
        }
    }
    // printf("\n%d\n", numerator);
    // printf("\n%d\n", denominator);
    // for(int64_t i = 0;i <= g_degree + g_degree;i++) printf("%d ", gsquare[i]);
    reduceFractions(quotient, gsquare, ((f_degree + g_degree) > (2 * g_degree) ? (f_degree + g_degree) : (2 * g_degree)));
    cnt = 0;
    int64_t first = 1;
    for(int64_t i = f_degree + g_degree;i >= 0;i--){
        if(i == 0){
            if(quotient[i] != 0){
                if(!cnt){
                    if(quotient[i] > 0) printf("%lld", quotient[i]);
                    else printf("-%lld", -quotient[i]);
                }
                else{
                    if(quotient[i] > 0) printf("+%lld", quotient[i]);
                    else printf("-%lld", -quotient[i]);
                }
            }
            continue;
        }
        if(quotient[i] == 1 || quotient[i] == -1){
            if(first){
                if(quotient[i] < 0) printf("-");
            }
            else if(cnt){
                if(quotient[i] > 0) printf("+");
                else printf("-");
            }
            if(i == 1) printf("x");
            else printf("x^%lld", i);
            cnt = 1;
            first = 0;
        }
        else if(quotient[i] == 0) continue;
        else{
            if(first){
                if(quotient[i] < 0) printf("-");
            }
            else if(cnt){
                if(quotient[i] > 0) printf("+");
                else printf("-");
            }
            int64_t tmp = (quotient[i] > 0 ? quotient[i] : -quotient[i]);
            if(i == 1) printf("%lldx", tmp);
            else printf("%lldx^%lld", tmp, i);
            cnt = 1;
            first = 0;
        }
        if(i == 2 * g_degree){
            if(gsquare[i] < 0) denominator++;
        }
    }
    if(quotient[0] == 0) printf("0\n");
    else printf("\n");
    printf("(----)\': ");
    for(int64_t i = 0;i < (denominator > numerator ? denominator : numerator);i++) printf("-");
    printf("\n");
    printf(" g(x)    ");
    cnt = 0;
    first = 1;
    for(int64_t i = 2 * g_degree;i >= 0;i--){
        if(i == 0){
            if(gsquare[i] != 0){
                if(!cnt){
                    if(gsquare[i] > 0) printf("%lld", gsquare[i]);
                    else printf("-%lld", -gsquare[i]);
                }
                else{
                    if(gsquare[i] > 0) printf("+%lld", gsquare[i]);
                    else printf("-%lld", -gsquare[i]);
                }
            }
            continue;
        }
        if(gsquare[i] == 1 || gsquare[i] == -1){
            if(first){
                if(gsquare[i] < 0) printf("-");
            }
            else if(cnt){
                if(gsquare[i] > 0) printf("+");
                else printf("-");
            }
            if(i == 1) printf("x");
            else printf("x^%lld", i);
            cnt = 1;
            first = 0;
        }
        else if(gsquare[i] == 0) continue;
        else{
            if(first){
                if(gsquare[i] < 0) printf("-");
            }
            else if(cnt){
                if(gsquare[i] > 0) printf("+");
                else printf("-");
            }
            int64_t tmp = (gsquare[i] > 0 ? gsquare[i] : -gsquare[i]);
            if(i == 1) printf("%lldx", tmp);
            else printf("%lldx^%lld", tmp, i);
            cnt = 1;
            first = 0;
        }
        if(i == 2 * g_degree){
            if(gsquare[i] < 0) denominator++;
        }
    }
    printf("\n");
    
    return 0;
}

// 3
// 2 3 8 0
// 4
// 2 9 0 9 8