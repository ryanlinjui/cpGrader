#include <stdio.h>
#include <stdint.h>
#include "gsat.h"
void _sort(int32_t arr[]){
    for(int32_t i = 0;i < STUDENT_NUMBER;i++){
        int32_t idx = i;
        for(int32_t j = i + 1;j < STUDENT_NUMBER;j++){
            if(arr[j] < arr[idx]){
                idx = j;
            }
        }
        int32_t tmp = arr[i];
        arr[i] = arr[idx];
        arr[idx] = tmp;
    }
}
int main(){
    int32_t column = sizeof(score) / 24;
    int32_t ch[STUDENT_NUMBER], en[STUDENT_NUMBER], ma[STUDENT_NUMBER], mb[STUDENT_NUMBER], so[STUDENT_NUMBER], sc[STUDENT_NUMBER];
    for(int32_t i = 0;i < STUDENT_NUMBER;i++) ch[i] = score[i][CHINESE];
    for(int32_t i = 0;i < STUDENT_NUMBER;i++) en[i] = score[i][ENGLISH];
    for(int32_t i = 0;i < STUDENT_NUMBER;i++) ma[i] = score[i][MATH_A];
    for(int32_t i = 0;i < STUDENT_NUMBER;i++) mb[i] = score[i][MATH_B];
    for(int32_t i = 0;i < STUDENT_NUMBER;i++) so[i] = score[i][SOCIAL];
    for(int32_t i = 0;i < STUDENT_NUMBER;i++) sc[i] = score[i][SCIENCE];
    _sort(ch);
    _sort(en);
    _sort(ma);
    _sort(mb);
    _sort(so);
    _sort(sc);
    printf("\tCHINESE | ENGLISH | MATH_A | MATH_B | SOCIAL | SCIENCE");
    printf("\n");
    printf("TOP 12%%");
    double r = STUDENT_NUMBER * 0.88;
    int32_t rank = (int32_t)r;
    if(r - rank > 0) rank++;
    printf("%6d\t%7d\t%9d\t%2d\t%3d\t%4d\n", ch[rank - 1], en[rank - 1], ma[rank - 1], mb[rank - 1], so[rank - 1], sc[rank - 1]);
    printf("TOP 25%%");
    r = STUDENT_NUMBER * 0.75;
    rank = (int32_t)r;
    if(r - rank > 0) rank++;
    printf("%6d\t%7d\t%9d\t%2d\t%3d\t%4d\n", ch[rank - 1], en[rank - 1], ma[rank - 1], mb[rank - 1], so[rank - 1], sc[rank - 1]);
    // printf("%6d\t%6d\t%6d\t%6d\t%6d\t%6d", ch[rank], en[rank]);
    // printf("\n");
    printf("TOP 50%%");
    r = STUDENT_NUMBER * 0.50;
    rank = (int32_t)r;
    if(r - rank > 0) rank++;
    printf("%6d\t%7d\t%9d\t%2d\t%3d\t%4d\n", ch[rank - 1], en[rank - 1], ma[rank - 1], mb[rank - 1], so[rank - 1], sc[rank - 1]);
    printf("TOP 75%%");
    r = STUDENT_NUMBER * 0.25;
    rank = (int32_t)r;
    if(r - rank > 0) rank++;
    printf("%6d\t%7d\t%9d\t%2d\t%3d\t%4d\n", ch[rank - 1], en[rank - 1], ma[rank - 1], mb[rank - 1], so[rank - 1], sc[rank - 1]);
    printf("TOP 88%%");
    r = STUDENT_NUMBER * 0.12;
    rank = (int32_t)r;
    if(r - rank > 0) rank++;
    printf("%6d\t%7d\t%9d\t%2d\t%3d\t%4d\n", ch[rank - 1], en[rank - 1], ma[rank - 1], mb[rank - 1], so[rank - 1], sc[rank - 1]);

    return 0;
}