#include "mychess.h"
static int32_t cnt = 1, rg = 0, rad = 0, re = 0, rh = 0, rc = 0, rcan = 0, rsol = 0, bg = 0, bad = 0, be = 0, bh = 0, bc = 0, bcan = 0, bsol = 0;
int32_t checkmate( int32_t board[10][9] ){
    // int32_t cnt = 1;
    for(int32_t i = 0;i < 10;i++){
        for(int32_t j = 0;j < 9;j++){
            int32_t res = checkall(board, i, j);
            if(res == -1) return -1;
        }
    }
    for(int32_t k = 1;k <= 7;k++){
        for(int32_t i = 0;i < 10;i++){
            for(int32_t j = 0;j < 9;j++){
                if(board[i][j] == EMPTY){
                    continue;
                }
                else if(board[i][j] == RED_GENERAL && board[i][j] == k){
                    int32_t ret = general(board, i, j);
                    if(ret == -1) return -1;
                }
                else if(board[i][j] == RED_ADVISOR && board[i][j] == k){
                    int32_t ret = advisor(board, i, j);
                    if(ret == -1) return -1;
                }
                else if(board[i][j] == RED_ELEPHANT && board[i][j] == k){
                    int32_t ret = elephant(board, i, j);
                    if(ret == -1) return -1;
                }
                else if(board[i][j] == RED_HORSE && board[i][j] == k){
                    int32_t ret = horse(board, i, j);
                    if(ret == -1) return -1;
                }
                else if(board[i][j] == RED_CHARIOT && board[i][j] == k){
                    int32_t ret = chariot(board, i, j);
                    if(ret == -1) return -1;
                }
                else if(board[i][j] == RED_CANNON && board[i][j] == k){
                    int32_t ret = cannon(board, i, j);
                    if(ret == -1) return -1;
                }
                else if(board[i][j] == RED_SOLDIER && board[i][j] == k){
                    int32_t ret = soldier(board, i, j);
                    if(ret == -1) return -1;
                }
            }
        }
    }
    return cnt - 1;
}
int32_t checkall(int32_t board[10][9], int32_t x, int32_t y){
    if(board[x][y] == RED_GENERAL){
        rg++;
        if(rg > 1) return -1;
        if(x > 2 || y < 3 || y > 5) return -1;
    }
    else if(board[x][y] == RED_ADVISOR){
        rad++;
        if(rad > 2) return -1;
        if(x > 2 || y < 3 || y > 5 || (x == 1 && y == 3) || (x == 2 && y == 4) || (x == 1 && y == 5) || (x == 0 && y == 4)) return -1;
    }
    else if(board[x][y] == RED_ELEPHANT){
        re++;
        if(re > 2) return -1;
        if(x > 4) return -1;
        if((x == 0 && y == 2) || (x == 0 && y == 6) || (x == 2 && y == 4) || (x == 2 && y == 0) || (x == 2 && y == 8) || (x == 4 && y == 2) || (x == 4 && y == 6)) return 0;
        else return -1;
    }
    else if(board[x][y] == RED_HORSE){
        rh++;
        if(rh > 2) return -1;
        return 0;
    }
    else if(board[x][y] == RED_CHARIOT){
        rc++;
        if(rc > 2) return -1;
        return 0;
    }
    else if(board[x][y] == RED_CANNON){
        rcan++;
        if(rcan > 2) return -1;
        return 0;
    }
    else if(board[x][y] == RED_SOLDIER){
        rsol++;
        if(rsol > 5) return -1;
        if(x < 3) return -1;
        else if((x == 3 || x == 4) && (y == 1 || y == 3 || y == 5 || y == 7)) return -1;
    }
    else if(board[x][y] == BLACK_GENERAL){
        bg++;
        if(bg > 1) return -1;
        if(x < 7 || y < 3 || y > 5) return -1;
    }
    else if(board[x][y] == BLACK_ADVISOR){
        bad++;
        if(bad > 2) return -1;
        if(x < 7 || y < 3 || y > 5 || (x == 8 && y == 3) || (x == 9 && y == 4) || (x == 8 && y == 5) || (x == 7 && y == 4)) return -1;
    }
    else if(board[x][y] == BLACK_ELEPHANT){
        be++;
        if(be > 2) return -1;
        if(x < 5) return -1;
        if((x == 9 && y == 2) || (x == 9 && y == 6) || (x == 7 && y == 4) || (x == 7 && y == 0) || (x == 7 && y == 8) || (x == 5 && y == 2) || (x == 5 && y == 6)) return 0;
        else return -1;
    }
    else if(board[x][y] == BLACK_HORSE){
        bh++;
        if(bh > 2) return -1;
        if((x == 0 && y == 2) || (x == 0 && y == 6) || (x == 2 && y == 4) || (x == 2 && y == 0) || (x == 2 && y == 8) || (x == 4 && y == 2) || (x == 4 && y == 6)) return 0;
        else return -1;
    }
    else if(board[x][y] == BLACK_CHARIOT){
        bc++;
        if(bc > 2) return -1;
        return 0;
    }
    else if(board[x][y] == BLACK_CANNON){
        bcan++;
        if(bcan > 2) return -1;
        return 0;
    }
    else if(board[x][y] == BLACK_SOLDIER){
        bsol++;
        if(bsol > 5) return -1;
        if(x > 6) return -1;
        else if((x == 5 || x == 6) && (y == 1 || y == 3 || y == 5 || y == 7)) return -1;
    }
    return 0;
}
int32_t general(int32_t board[10][9], int32_t x, int32_t y){
    if(x > 2 || y < 3 || y > 5) return -1;
    int32_t dx[4] = {-1, 0, 1, 0}, dy[4] = {0, -1, 0, 1};
    int32_t jdg = 0;
    for(int32_t i = 0;i < 4;i++){
        if(x + dx[i] < 0 || x + dx[i] > 2 || y + dy[i] < 3 || y + dy[i] > 5 || (board[x + dx[i]][y + dy[i]] >= 1 && board[x + dx[i]][y + dy[i]] <= 7)) continue;
        int32_t judge = 1;
        for(int32_t j = x + 1;j <= 6;j++){
            if(board[j + dx[i]][y + dy[i]] != EMPTY) judge = 0;
        }
        if(judge){
            for(int32_t j = 7;j <= 9;j++){
                if(board[j + dx[i]][y + dy[i]] == BLACK_GENERAL){
                    printf("%d) Move General from (%d,%d) to (%d,%d)\n", cnt++, x, y, x + dx[i], y + dy[i]);
                    // return 1;
                    jdg = 1;
                }
            }
        }
    }
    if(jdg) return 1;
    else return 0;
}
int32_t advisor(int32_t board[10][9], int32_t x, int32_t y){
    int32_t dx[4] = {-1, -1, 1, 1}, dy[4] = {-1, 1, -1, 1};
    int32_t jdg = 0;
    if(x > 2 || y < 3 || y > 5 || (x == 1 && y == 3) || (x == 2 && y == 4) || (x == 1 && y == 5) || (x == 0 && y == 4)) return -1;
    for(int32_t i = 0;i < 4;i++){
        if(x + dx[i] < 0 || x + dx[i] > 2 || y + dy[i] < 3 || y + dy[i] > 5 || (board[x + dx[i]][y + dy[i]] >= 1 && board[x + dx[i]][y + dy[i]] <= 7)) continue;
        for(int32_t j = 0;j < 4;j++){
            if(x + dx[i] + dx[j] < 0 || x + dx[i] + dx[j] > 2 || y + dy[i] + dy[j] < 3 || y + dy[i] + dy[j] > 5 || (board[x + dx[i] + dx[j]][y + dy[i] + dy[j]] >= 1 && board[x + dx[i] + dx[j]][y + dy[i] + dy[j]] <= 7)) continue;
            int32_t judge = 1;
            if(board[x + dx[i] + dx[j]][y + dy[i] + dy[j]] == BLACK_GENERAL){
                printf("%d) Move Advisor from (%d,%d) to (%d,%d)\n", cnt++, x, y, x + dx[i], y + dy[i]);
                // return 1;
                jdg = 1;
            }
        }
    }
    if(jdg) return 1;
    else return 0;
}
int32_t elephant(int32_t board[10][9], int32_t x, int32_t y){
    int32_t dx[4] = {-2, -2, 2, 2}, dy[4] = {-2, 2, -2, 2};
    int32_t ex[4] = {-1, -1, 1, 1}, ey[4] = {-1, 1, -1, 1};
    int32_t jdg = 0;
    if(x > 4) return -1;
    for(int32_t i = 0;i < 4;i++){
        if(x + dx[i] < 0 || x + dx[i] > 4 || y + dy[i] < 0 || y + dy[i] > 8 || (board[x + dx[i]][y + dy[i]] >= 1 && board[x + dx[i]][y + dy[i]] <= 7)) continue;
        if(board[x + ex[i]][y + ey[i]] != EMPTY) continue;
        if(board[x + dx[i]][y + dy[i]] == BLACK_GENERAL){
            printf("%d) Move Elephant from (%d,%d) to (%d,%d)\n", cnt++, x, y, x + dx[i], y + dy[i]);
            // return 1;
            jdg = 1;
        }
    }
    if(jdg) return 1;
    else return 0;
}
int32_t horse(int32_t board[10][9], int32_t x, int32_t y){
    int32_t dx[8] = {-2, -2, -1, -1, 1, 1, 2, 2}, dy[8] = {-1, 1, -2, 2, -2, 2, -1, 1};
    int32_t lx[8] = {-1, -1, 0, 0, 0, 0, 1, 1}, ly[8] = {0, 0, -1, 1, -1, 1, 0, 0};
    int32_t jdg = 0;
    for(int32_t i = 0;i < 8;i++){
        if(x + dx[i] < 0 || x + dx[i] > 9 || y + dy[i] < 0 || y + dy[i] > 8 || (board[x + dx[i]][y + dy[i]] >= 1 && board[x + dx[i]][y + dy[i]] <= 7)) continue;
        if(board[x + lx[i]][y + ly[i]] != EMPTY) continue;
        for(int32_t j = 0;j < 8;j++){
            if(x + dx[i] + dx[j] < 0 || x + dx[i] + dx[j] > 9 || y + dy[i] + dy[j] < 0 || y + dy[i] + dy[j] > 8 || (board[x + dx[i] + dx[j]][y + dy[i] + dy[j]] >= 1 && board[x + dx[i] + dx[j]][y + dy[i] + dy[j]] <= 7)) continue;
            
            if(board[x + dx[i] + lx[j]][y + dy[i] + ly[j]] != EMPTY) continue;
            // printf("fsdakfjsdklf");
            // printf("%d %d\n", x + dx[i] + dx[j], y + dy[i] + dy[j]);
            if(board[x + dx[i] + dx[j]][y + dy[i] + dy[j]] == BLACK_GENERAL){
                printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", cnt++, x, y, x + dx[i], y + dy[i]);
                // return 1;
                jdg = 1;
            }
        }
    }
    if(jdg) return 1;
    else return 0;
}
int32_t chariot(int32_t board[10][9], int32_t x, int32_t y){
    int32_t jdg = 0;
    for(int32_t i = x - 1;i >= 0;i--){ // backward
        if(board[i][y] >= 1 && board[i][y] <= 7) break;
        for(int32_t j = y - 1;j >= 0;j--){ // left
            if((board[i][j] >= 1 && board[i][j] <= 7) || (board[i][j] >= 11 && board[i][j] <= 17 && board[i][j] != BLACK_GENERAL)) break;
            if(board[i][j] == BLACK_GENERAL){
                printf("%d) Move Chariot from (%d,%d) to (%d,%d)\n", cnt++, x, y, i, y);
                // return 1;
                jdg = 1;
            }
        }
        for(int32_t j = y + 1;j <= 8;j++){ // right
            if((board[i][j] >= 1 && board[i][j] <= 7) || (board[i][j] >= 11 && board[i][j] <= 17 && board[i][j] != BLACK_GENERAL)) break;
            // printf("%d %d\n", i, j);
            if(board[i][j] == BLACK_GENERAL){
                printf("%d) Move Chariot from (%d,%d) to (%d,%d)\n", cnt++, x, y, i, y);
                // return 1;
                jdg = 1;
            }
        }
        if((board[i][y] >= 1 && board[i][y] <= 7)) break;
    }
    for(int32_t i = y - 1;i >= 0;i--){ // left
        if(board[x][i] >= 1 && board[x][i] <= 7) break;
        for(int32_t j = x - 1;j >= 0;j--){
            if((board[j][i] >= 1 && board[j][i] <= 7) || (board[j][i] >= 11 && board[j][i] <= 17 && board[j][i] != BLACK_GENERAL)) break;
            if(board[j][i] == BLACK_GENERAL){
                printf("%d) Move Chariot from (%d,%d) to (%d,%d)\n", cnt++, x, y, x, i);
                // return 1;
                jdg = 1;
            }
        }
        for(int32_t j = x + 1;j <= 9;j++){
            if((board[j][i] >= 1 && board[j][i] <= 7) || (board[j][i] >= 11 && board[j][i] <= 17 && board[j][i] != BLACK_GENERAL)) break;
            if(board[j][i] == BLACK_GENERAL){
                printf("%d) Move Chariot from (%d,%d) to (%d,%d)\n", cnt++, x, y, x, i);
                // return 1;
                jdg = 1;
            }
        }
    }
    for(int32_t i = y + 1;i <= 8;i++){ // right
        if(board[x][i] >= 1 && board[x][i] <= 7) break;
        for(int32_t j = x - 1;j >= 0;j--){
            if((board[j][i] >= 1 && board[j][i] <= 7) || (board[j][i] >= 11 && board[j][i] <= 17 && board[j][i] != BLACK_GENERAL)) break;
            if(board[j][i] == BLACK_GENERAL){
                printf("%d) Move Chariot from (%d,%d) to (%d,%d)\n", cnt++, x, y, x, i);
                // return 1;
                jdg = 1;
            }
        }
        for(int32_t j = x + 1;j <= 9;j++){
            if((board[j][i] >= 1 && board[j][i] <= 7) || (board[j][i] >= 11 && board[j][i] <= 17 && board[j][i] != BLACK_GENERAL)) break;
            if(board[j][i] == BLACK_GENERAL){
                printf("%d) Move Chariot from (%d,%d) to (%d,%d)\n", cnt++, x, y, x, i);
                // return 1;
                jdg = 1;
            }
        }
    }
    for(int32_t i = x + 1;i <= 9;i++){ // forward
        if(board[i][y] >= 1 && board[i][y] <= 7) break;
        for(int32_t j = y - 1;j >= 0;j--){ // left
            if((board[i][j] >= 1 && board[i][j] <= 7) || (board[i][j] >= 11 && board[i][j] <= 17 && board[i][j] != BLACK_GENERAL)) break;
            if(board[i][j] == BLACK_GENERAL){
                printf("%d) Move Chariot from (%d,%d) to (%d,%d)\n", cnt++, x, y, i, y);
                // return 1;
                jdg = 1;
            }
        }
        for(int32_t j = y + 1;j <= 8;j++){ // right
            if((board[i][j] >= 1 && board[i][j] <= 7) || (board[i][j] >= 11 && board[i][j] <= 17 && board[i][j] != BLACK_GENERAL)) break;
            if(board[i][j] == BLACK_GENERAL){
                printf("%d) Move Chariot from (%d,%d) to (%d,%d)\n", cnt++, x, y, i, y);
                // return 1;
                jdg = 1;
            }
        }
        if((board[i][y] >= 1 && board[i][y] <= 7)) break;
    }
    if(jdg) return 1;
    else return 0;
}
int32_t fly(int32_t board[10][9], int32_t x, int32_t y, int32_t ox, int32_t oy){
    int32_t jdg = 0;
    for(int32_t j = x - 1;j >= 0;j--){
        if(board[j][y] != EMPTY){
            for(int32_t k = j - 1;k >= 0;k--){
                if(board[k][y] == BLACK_GENERAL){
                    printf("%d) Move Cannon from (%d,%d) to (%d,%d)\n", cnt++, ox, oy, x, y);
                    // return 1;
                    jdg = 1;
                }
                else if(board[k][y] != EMPTY){
                    break;
                }
            }
            break;
        }
    }
    for(int32_t j = y - 1;j >= 0;j--){
        if(board[x][j] != EMPTY){
            for(int32_t k = j - 1;k >= 0;k--){
                if(board[x][k] == BLACK_GENERAL){
                    printf("%d) Move Cannon from (%d,%d) to (%d,%d)\n", cnt++, ox, oy, x, y);
                    // return 1;
                    jdg = 1;
                }
                else if(board[x][k] != EMPTY){
                    break;
                }
            }
            break;
        }
    }
    for(int32_t j = y + 1;j <= 8;j++){
        if(board[x][j] != EMPTY){
            for(int32_t k = j + 1;k <= 9;k++){
                if(board[x][k] == BLACK_GENERAL){
                    printf("%d) Move Cannon from (%d,%d) to (%d,%d)\n", cnt++, ox, oy, x, y);
                    // return 1;
                    jdg = 1;
                }
                else if(board[x][k] != EMPTY){
                    break;
                }
            }
            break;
        }
    }
    for(int32_t j = x + 1;j <= 9;j++){
        if(board[j][y] != EMPTY){
            for(int32_t k = j + 1;k <= 9;k++){
                // printf("%d %d\n", k, y);
                if(board[k][y] == BLACK_GENERAL){
                    printf("%d) Move Cannon from (%d,%d) to (%d,%d)\n", cnt++, ox, oy, x, y);
                    // return 1;
                    jdg = 1;
                }
                else if(board[k][y] != EMPTY){
                    break;
                }
            }
            break;
        }
    }
    if(jdg) return 1;
    else return 0;
}
// (board[i][j] >= 11 && board[i][j] <= 17)
int32_t cannon(int32_t board[10][9], int32_t x, int32_t y){
    int32_t jdg = 1;
    for(int32_t i = x - 1;i >= 0;i--){ // backward
        if(board[i][y] == EMPTY){
            int32_t ret = fly(board, i, y, x, y);
            // printf("ret: %d\n", ret);
            if(ret == 1) break;
        }
    }
    for(int32_t i = x - 1;i >= 0;i--){
        if(board[i][y] != EMPTY){
            int32_t tmp = 0;
            for(int32_t j = i - 1;j >= 0;j--){
                if((board[j][y] >= 11 && board[j][y] <= 17)){
                    int32_t ret = fly(board, j, y, x, y);
                    if(ret == 1) break;
                }
                else if((board[j][y] >= 1 && board[j][y] <= 7)) break;
            }
        }
    }
    for(int32_t i = y - 1;i >= 0;i--){ // left
        if(board[x][i] == EMPTY){
            int32_t ret = fly(board, x, i, x, y);
            if(ret == 1) break;
        }
    }
    for(int32_t i = y - 1;i >= 0;i--){
        if(board[x][i] != EMPTY){
            int32_t tmp = 0;
            for(int32_t j = i - 1;j >= 0;j--){
                if((board[x][j] >= 11 && board[x][j] <= 17)){
                    int32_t ret = fly(board, x, j, x, y);
                    if(ret == 1) break;
                }
                else if((board[x][j] >= 1 && board[x][j] <= 7)) break;
            }
        }
    }
    for(int32_t i = y + 1;i <= 8;i++){ // right
        if(board[x][i] == EMPTY){
            int32_t ret = fly(board, x, i, x, y);
            if(ret == 1) break;
        }
    }
    for(int32_t i = y + 1;i <= 8;i++){
        if(board[i][y] != EMPTY){
            int32_t tmp = 0;
            for(int32_t j = i + 1;j <= 8;j++){
                if((board[x][j] >= 11 && board[x][j] <= 17)){
                    int32_t ret = fly(board, x, j, x, y);
                    if(ret == 1) break;
                }
                else if((board[x][j] >= 1 && board[x][j] <= 7)) break;
            }
        }
    }
    for(int32_t i = x + 1;i <= 9;i++){ // forward
        if(board[i][y] == EMPTY){
            int32_t ret = fly(board, i, y, x, y);
            if(ret == 1) break;
        }
    }
    for(int32_t i = x + 1;i <= 9;i++){
        if(board[i][y] != EMPTY){
            int32_t tmp = 0;
            for(int32_t j = i + 1;j <= 9;j++){
                if((board[j][y] >= 11 && board[j][y] <= 17)){
                    int32_t ret = fly(board, x, j, x, y);
                    if(ret == 1) break;
                }
                else if((board[j][y] >= 1 && board[j][y] <= 7)) break;
            }
        }
    }
    return 0;
}
int32_t soldier(int32_t board[10][9], int32_t x, int32_t y){
    int32_t jdg = 0;
    if(x < 3) return -1;
    else if(x <= 4 && (y == 1 || y == 3 || y == 5 || y == 7)) return -1;
    int32_t dx[3] = {0, 0, 1}, dy[3] = {-1, 1, 0};
    if(x >= 5){
        for(int32_t i = 0;i < 3;i++){
            if(x + dx[i] > 9 || y + dy[i] < 0 || y + dy[i] > 8) continue;
            for(int32_t j = 0;j < 3;j++){
                if(x + dx[i] + dx[j] > 9 || y + dy[i] + dy[j] < 0 || y + dy[i] + dy[j] > 8) continue;
                if(board[x + dx[i] + dx[j]][y + dy[i] + dy[j]] == BLACK_GENERAL){
                    printf("%d) Move Soldier from (%d,%d) to (%d,%d)\n", cnt++, x, y, x + dx[i], y + dy[i]);
                    // return 1;
                    jdg = 1;
                }
            }
        }
    }
    if(jdg) return 1;
    else return 0;
}