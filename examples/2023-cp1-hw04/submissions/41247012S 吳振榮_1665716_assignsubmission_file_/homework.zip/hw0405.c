#include <stdio.h>
#include <stdint.h>
#define PIN_1 1
#define PIN_2 2
#define PIN_3 3
#define PIN_4 4
#define PIN_5 5
#define PIN_6 6
#define PIN_7 7
#define PIN_8 8
#define PIN_9 9

#define SO_1 10
#define SO_2 11
#define SO_3 12
#define SO_4 13
#define SO_5 14
#define SO_6 15
#define SO_7 16
#define SO_8 17
#define SO_9 18

#define WAN_1 19
#define WAN_2 20
#define WAN_3 21
#define WAN_4 22
#define WAN_5 23
#define WAN_6 24
#define WAN_7 25
#define WAN_8 26
#define WAN_9 27

#define EAST 28
#define SOUTH 29
#define WEST 30
#define NORTH 31

#define WHITE 32
#define GREEN 33
#define RED 34
void error_input(){
    printf("\nThe Score is...\n    Unreasonable case\nTotal: 0 Han\n");
}
void no_yaku(){
    printf("\nThe Score is...\n    No Yaku\nTotal: 0 Han\n");
}
void sort(int32_t arr[30], int32_t n){
    int32_t key, j;
    for(int32_t i = 1;i < n;i++){
        key = arr[i];
        j = i - 1;
        while(j >= 0 && key < arr[j]){
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}
int32_t seven_pairs(int32_t meld[10][30], int32_t closed[30], int32_t pair[10]){
    int32_t arr[30];
    for(int32_t i = 0;i < 14;i++) arr[i] = meld[0][i];
    sort(arr, 14);
    int32_t judge = 1;
    for(int32_t i = 0;i < 13;i+=2){
        if(arr[i] != arr[i + 1] || (i != 12 && arr[i] == arr[i + 2])) judge = 0;
    }
    return judge;
}
// int32_t Thirteen_orphans(int32_t meld[10][30], int32_t closed[30], int32_t pair[10]){
    
// }
// int32_t Thirteen_orphans_13wait(int32_t meld[10][30], int32_t closed[30], int32_t pair[10]){
    
// }
int32_t No_points_hand(int32_t meld[10][30], int32_t closed[30], int32_t pair[10], int32_t winning){
    int32_t jdg = 1, ten1, ten2;
    for(int32_t j = 0;j < 4;j++){
        for(int32_t i = 1;i < 3;i++){
            if(meld[j][i] == 0){
                if(meld[j][i - 1] == meld[j][i - 2]) continue;
                else{
                    ten1 = meld[j][i - 2] - 1;
                    ten2 = meld[j][i - 1] + 1;
                }
            }
            else if((meld[j][i] - meld[j][i - 1] != 1) || closed[j] != 1){
                jdg = 0;
                // printf("%d %d\n", meld[j][i])
            }
        }
    }
    if(jdg){
        if(ten1 == winning || ten2 == winning) return 1;
        else return 0;
    }
    return 0;
}
int main(){
    // freopen("test.in", "r", stdin);
    int32_t han = 0, yakuman = 0, player_wind, pre_wind, winning, suit_len = 0;
    int32_t meld[10][30], closed[30], pair[10];
    for(int32_t i = 0;i < 10;i++){
        for(int32_t j = 0;j < 30;j++){
            meld[i][j] = 0;
        }
    }
    int32_t tmp, def = 4, fourteen = 0;
    for(int32_t i = 0;i < 4;i++){
        int32_t idx = 0;
        printf("Please input meld: ");
        while(scanf("%d", &tmp)){
            if(tmp == 0) break;
            else if(tmp < 0){
                error_input();
                return 0;
            }
            else if(tmp > 34){
                error_input();
                return 0;
            }
            meld[i][idx++] = tmp;
            suit_len++;
        }
        if(idx == 14){
            fourteen = 1;
            break;
        }
        printf("Is open group(1: YES 0: NO): ");
        scanf("%d", &closed[i]);
        if(closed[i] != 1 && closed[i] != 0){
            printf("Invalid Input. You must input 0 or 1.\n");
            error_input();
            return 0;
        }
    }
    if(!fourteen){
        printf("Please input pair: ");
        scanf("%d %d", &pair[0], &pair[1]);
    }
    printf("Please input winning tile: ");
    scanf("%d", &winning);
    printf("Player's wind(0:E 1:S 2:W 3:N): ");
    scanf("%d", &player_wind);
    printf("Prevailing wind(0:E 1:S 2:W 3:N): ");
    scanf("%d", &pre_wind);
    if(fourteen){
        int32_t ret = seven_pairs(meld, closed, pair);
        if(ret){
            printf("\nThe Score is...\n    Seven pairs (2 Han)\nTotal: 2 Han\n");
            return 0;
        }
        else{
            printf("\nThe Score is...\n    Thirteen orphans (2 Yakuman)\nTotal: 2 Yakuman\n");
            return 0;
        }
        // ret = Thirteen_orphans();
    }
    else{
        no_yaku();
    }
    
    return 0;
}