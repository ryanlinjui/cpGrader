# 4.6 Bonus: What Happens? (5 pts)
這個程式在編譯雖然無誤，但執行程式後會發現出現了Segmentation fault (core dumped)，這是因為區域變數，記憶體會被分配在 stack 區段，而這塊區域一般來說並不夠大，大到可以放巨大陣列，因此只要陣列太大，就會立刻 stack overflow。那解決方式可以將變數宣告放在全域變數，因為全域變數不會被配置到 stack 區。或者可以利用malloc來做動態記憶體的分配也可以解決這隻程式的問題。
```c=
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
int main(){
    // int32_t array[100000000] = {0};
    int32_t *array = (int32_t *)malloc(100000000 * sizeof(int32_t));
    for(int32_t i = 0;i < 100000000;i++) array[i] = 0;

    return 0;
}
```