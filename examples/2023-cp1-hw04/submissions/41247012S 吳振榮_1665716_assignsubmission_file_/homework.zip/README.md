# Computer Programming I homework 4
## Author
- 我是資工系116級的吳振榮，學號是41247012S。

## Overview
台師大資工程式設計(一)第四次作業，共5+1道題目。

## Build and Run
Run `make` to compile my code.
```shell
$ make
```
After compiling the program, you can execute hw0301 code by entering `./hw0401` in the terminal, and the remaining programs follow the same pattern.
```shell
$ ./hw0401
$ ./hw0402
$ ./hw0403
$ ./hw0404
$ ./hw0405
```

## homework description
### hw0401
The user needs to pass two parameters to mysort() and myprint, and the size must be greater than or equal to 0. If it is less than 0, it will print an error message and terminate the program.
### hw0402
The user needs to input the exponents of two functions and their coefficients. The first coefficient cannot be zero, and the number of coefficients cannot exceed degree + 1. If any of these errors occur, the program should output an error message and terminate.
### hw0403
All score must be greater than or equal to 0.
### hw0404
If the given position is error, it will return -1.
### hw0405
If the input mahjong tile combination does not meet the criteria, it will output 'Unreasonable case'.
## Something to notify TAs
None