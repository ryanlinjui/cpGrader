#include "mysort.h" 
void _swap(int32_t *from, int32_t *to){
    *from = *from ^ *to;
    *to = *from ^ *to;
    *from = *from ^ *to;
}
void mysort( int32_t array[], int32_t size ){
    if(size < 0){
        printf("Invalid Input. The size should larget than 0\n");
        return;
    }
    for(int32_t i = 0;i < size;i++){
        int32_t idx = i;
        for(int32_t j = i + 1;j < size;j++){
            if(array[j] % 2 == 0){ // even
                if(array[idx] % 2 == 0){ // even
                    if(array[idx] < array[j]) idx = j;
                }
                else idx = j;
            }
            else{ // odd
                if(array[idx] & 1){ // odd
                    if(array[j] < array[idx]) idx = j;
                }
            }
        }
        if(idx != i) _swap(&array[idx], &array[i]);
    }
}
void myprint( int32_t array[], int32_t size ){
    if(size < 0){
        printf("Invalid Input. The size should larget than 0\n");
        return;
    }
    for(int32_t i = 0;i < size - 1;i++) printf("%d ", array[i]);
    printf("%d", array[size - 1]);
    printf("\n");
}