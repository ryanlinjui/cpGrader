#ifndef _MYSORT_H_
#define _MYSORT_H_
#include <stdio.h>
#include <stdint.h>
void _swap(int32_t *from, int32_t *to);
void mysort( int32_t array[], int32_t size );
void myprint( int32_t array[], int32_t size );

#endif