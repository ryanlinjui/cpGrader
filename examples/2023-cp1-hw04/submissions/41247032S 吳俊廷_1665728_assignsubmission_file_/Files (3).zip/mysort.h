#pragma once
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
// Sort array according to the given policies.
void mysort( int32_t array[], int32_t size );

// Print array elements in order.
void myprint( int32_t array[], int32_t size );