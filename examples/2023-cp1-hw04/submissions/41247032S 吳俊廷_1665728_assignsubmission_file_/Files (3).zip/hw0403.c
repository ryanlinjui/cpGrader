#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "gsat.h"

long long raw_chinese[STUDENT_NUMBER];
long long raw_english[STUDENT_NUMBER];
long long raw_math_a[STUDENT_NUMBER];
long long raw_math_b[STUDENT_NUMBER];
long long raw_social[STUDENT_NUMBER];
long long raw_science[STUDENT_NUMBER];

long double k;
long long outputt;

int compare(const void *a, const void *b) {
    long long A = *((long long*)a);
    long long B = *((long long*)b);
    return A - B;
}

int isInteger(double num) {
    return floor(num) == ceil(num);
}

void printChineseScore(long double percentage){
    k = (double) STUDENT_NUMBER * percentage;
    //printf("k = %Lf\n", k);
    //printf("%d\n",isInteger(k));
    if(!isInteger(k)){
        // k is not an integer
        outputt = raw_chinese[(int)ceil(k)-1];
        //printf("Debug Output:%d ",(int)ceil(k));
        //printf("%lld\n", raw_chinese[(int)ceil(k)]);
        
    }else{
        // k is an integer
        //printf("DEBUG:raw_chinese[(int)k] = %lld\n", raw_chinese[(int)k]);
        outputt=raw_chinese[(((int)k)+(int)k+1)/2];
        //printf("%lld\n", raw_chinese[(((int)k)+(int)k+1)/2]);
    }
    if(outputt>=10){
        printf("%lld",outputt);
    }else{
        printf(" %lld",outputt);;
    }
}

void printEnglishScore(long double percentage){
    k = (double) STUDENT_NUMBER * percentage;
    //printf("k = %Lf\n", k);
    //printf("%d\n",isInteger(k));
    if(!isInteger(k)){
        // k is not an integer
        outputt = raw_english[(int)ceil(k)-1];
        //printf("%lld\n", raw_chinese[(int)ceil(k)]);
        
    }else{
        // k is an integer
        //printf("DEBUG:raw_chinese[(int)k] = %lld\n", raw_chinese[(int)k]);
        outputt=raw_english[(((int)k)+(int)k+1)/2];
        //printf("%lld\n", raw_chinese[(((int)k)+(int)k+1)/2]);
    }
    if(outputt>=10){
        printf("%lld",outputt);
    }else{
        printf(" %lld",outputt);;
    }
}

void printMathAScore(long double percentage){
    k = (double) STUDENT_NUMBER * percentage;
    //printf("k = %Lf\n", k);
    //printf("%d\n",isInteger(k));
    if(!isInteger(k)){
        // k is not an integer
        outputt = raw_math_a[(int)ceil(k)-1];
        //printf("%lld\n", raw_chinese[(int)ceil(k)]);
        
    }else{
        // k is an integer
        //printf("DEBUG:raw_chinese[(int)k] = %lld\n", raw_chinese[(int)k]);
        outputt=raw_math_a[(((int)k)+(int)k+1)/2];
        //printf("%lld\n", raw_chinese[(((int)k)+(int)k+1)/2]);
    }
    if(outputt>=10){
        printf("%lld",outputt);
    }else{
        printf(" %lld",outputt);;
    }
}

void printMathBScore(long double percentage){
    k = (double) STUDENT_NUMBER * percentage;
    //printf("k = %Lf\n", k);
    //printf("%d\n",isInteger(k));
    if(!isInteger(k)){
        // k is not an integer
        outputt = raw_math_b[(int)ceil(k)-1];
        //printf("%lld\n", raw_chinese[(int)ceil(k)]);
        
    }else{
        // k is an integer
        //printf("DEBUG:raw_chinese[(int)k] = %lld\n", raw_chinese[(int)k]);
        outputt=raw_math_b[(((int)k)+(int)k+1)/2];
        //printf("%lld\n", raw_chinese[(((int)k)+(int)k+1)/2]);
    }
    if(outputt>=10){
        printf("%lld",outputt);
    }else{
        printf(" %lld",outputt);;
    }
}

void printSocialScore(long double percentage){
    k = (double) STUDENT_NUMBER * percentage;
    //printf("DEBUG:k = %Lf\n", k);
    //printf("%d\n",isInteger(k));
    if(!isInteger(k)){
        // k is not an integer
        outputt = raw_social[(int)ceil(k)-1];
        //printf("%lld\n", raw_chinese[(int)ceil(k)]);
        
    }else{
        // k is an integer
        //printf("DEBUG:raw_chinese[(int)k] = %lld\n", raw_chinese[(int)k]);
        outputt=raw_social[(((int)k)+(int)k+1)/2];
        //printf("%lld\n", raw_chinese[(((int)k)+(int)k+1)/2]);
    }
    if(outputt>=10){
        printf("%lld",outputt);
    }else{
        printf(" %lld",outputt);;
    }
}

void printScienceScore(long double percentage){
    k = (double) STUDENT_NUMBER * percentage;
    //printf("DEBUG:k = %Lf\n", k);
    //printf("%d\n",isInteger(k));
    if(!isInteger(k)){
        // k is not an integer
        outputt = raw_science[(int)ceil(k)-1];
        //printf("Debug Output:%d ",(int)ceil(k));
        //printf("%lld\n", raw_chinese[(int)ceil(k)]);
        
    }else{
        // k is an integer
        //printf("DEBUG:raw_chinese[(int)k] = %lld\n", raw_chinese[(int)k]);
        outputt=raw_science[(((int)k)+(int)k+1)/2];
        printf("Debug Output:%d ",(((int)k)+(int)k+1)/2);
        //printf("%lld\n", raw_chinese[(((int)k)+(int)k+1)/2]);
    }
    
    if(outputt>=10){
        printf("%lld",outputt);
    }else{
        printf(" %lld",outputt);;
    }
}

int main(){
    // Import Data from score[][] to raw_*
    for (int i = 0; i < STUDENT_NUMBER; i++){
        raw_chinese[i] = score[i][CHINESE];
        raw_english[i] = score[i][ENGLISH];
        raw_math_a[i] = score[i][MATH_A];
        raw_math_b[i] = score[i][MATH_B];
        raw_social[i] = score[i][SOCIAL];
        raw_science[i] = score[i][SCIENCE];
    }
    // Sort raw_* from low to high
    qsort(raw_chinese, STUDENT_NUMBER, sizeof(long long), compare);
    qsort(raw_english, STUDENT_NUMBER, sizeof(long long), compare);
    qsort(raw_math_a, STUDENT_NUMBER, sizeof(long long), compare);
    qsort(raw_math_b, STUDENT_NUMBER, sizeof(long long), compare);
    qsort(raw_social, STUDENT_NUMBER, sizeof(long long), compare);
    qsort(raw_science, STUDENT_NUMBER, sizeof(long long), compare);

    //DEBUG:show raw_* data
    // for (int i = 0; i < STUDENT_NUMBER; i++){
    //     printf("%lld ", raw_chinese[i]);
    // }
    // printf("\n");
    // for (int i = 0; i < STUDENT_NUMBER; i++){
    //     printf("%lld ", raw_english[i]);
    // }
    // printf("\n");
    // for (int i = 0; i < STUDENT_NUMBER; i++){
    //     printf("%lld ", raw_math_a[i]);
    // }
    // printf("\n");
    // for (int i = 0; i < STUDENT_NUMBER; i++){
    //     printf("%lld ", raw_math_b[i]);
    // }
    // printf("\n");
    // for (int i = 0; i < STUDENT_NUMBER; i++){
    //     printf("%lld ", raw_social[i]);
    // }
    // printf("\n");
    // for (int i = 0; i < STUDENT_NUMBER; i++){
    //     printf("%lld ", raw_science[i]);
    // }
    // printf("\n");

    // Calculate the 12% of each subject
    

    printf("\t CHINESE | ENGLISH | MATH_A | MATH_B | SOCIAL | SCIENCE\n");
    printf("TOP 12%%     ");
    printChineseScore(0.88);
    printf("        ");
    printEnglishScore(0.88);
    printf("        ");
    printMathAScore(0.88);
    printf("       ");
    printMathBScore(0.88);
    printf("       ");
    printSocialScore(0.88);
    printf("       ");
    printScienceScore(0.88);
    printf("\nTOP 25%%     ");
    printChineseScore(0.75);
    printf("        ");
    printEnglishScore(0.75);
    printf("        ");
    printMathAScore(0.75);
    printf("       ");
    printMathBScore(0.75);
    printf("       ");
    printSocialScore(0.75);
    printf("       ");
    printScienceScore(0.75);
    printf("\nTOP 50%%     ");
    printChineseScore(0.50);
    printf("        ");
    printEnglishScore(0.50);
    printf("        ");
    printMathAScore(0.50);
    printf("       ");
    printMathBScore(0.50);
    printf("       ");
    printSocialScore(0.50);
    printf("       ");
    printScienceScore(0.50);
    printf("\nTOP 75%%     ");
    printChineseScore(0.25);
    printf("        ");
    printEnglishScore(0.25);
    printf("        ");
    printMathAScore(0.25);
    printf("       ");
    printMathBScore(0.25);
    printf("       ");
    printSocialScore(0.25);
    printf("       ");
    printScienceScore(0.25);
    printf("\nTOP 88%%     ");
    printChineseScore(0.12);
    printf("        ");
    printEnglishScore(0.12);
    printf("        ");
    printMathAScore(0.12);
    printf("       ");
    printMathBScore(0.12);
    printf("       ");
    printSocialScore(0.12);
    printf("       ");
    printScienceScore(0.12);
    printf("\n");
    //printf("%d\t", score[0][CHINESE]);
    return 0;
}