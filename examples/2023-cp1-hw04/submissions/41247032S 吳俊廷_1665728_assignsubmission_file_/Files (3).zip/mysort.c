#include "mysort.h"
/*
1. All even numbers should be before odd numbers.
2. All odd numbers are in ascending order.
3. All even numbers are in descending order.
*/

int compare(const void *a, const void *b) {
    int A = *((int*)a);
    int B = *((int*)b);
    // 偶數在前，奇數在後
    if (A % 2 == 0 && B % 2 != 0) return -1;
    if (A % 2 != 0 && B % 2 == 0) return 1;
    // 偶數降序
    if (A % 2 == 0) return B - A;
    // 奇數升序
    return A - B;
}

void mysort( int32_t array[], int32_t size ){
    qsort(array, size, sizeof(int32_t), compare);
}

void myprint( int32_t array[], int32_t size ){
    for(int i=0; i<size; i++){
        printf("%d ", array[i]);
    }
    printf("\n");
}