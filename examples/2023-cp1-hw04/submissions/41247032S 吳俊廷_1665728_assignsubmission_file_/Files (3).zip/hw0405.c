/*
Japanese Mahjong Scoring Caculator
For input, I will use 1-34 to present the tile.
• 1 ∼ 9: 1 Pin(餅) ∼ 9 Pin(餅)
• 10 ∼ 18: 1 So(索) ∼ 9 So(索)
• 19 ∼ 27: 1 Wan(萬) ∼ 9 Wan(萬)
• 28 ∼ 31: East(東) South(南) West(西) North(北)
• 32 ∼ 34: White(白) Green(發) Red(中)

For input, I will input the tiles meld(面子) by meld(面子) and stop with
0, then I will tell you the meld(面子) is open or close(the tile in one meld(面
子) which would not be order), and promise the scoring combination will
fixed, you don’t need to shuffle the tiles and find higher combination. For
Special case, such as Seven-pair(七對子) and Thirteen orphans(國士無雙),
I will input as one meld(面子).
Then, I will give your pair(對子), winning tile(和張), Player’s wind(自風), Prevailing wind(場風).
For output, you need to show each Yaku(役) or Yakumen(役滿), and
calculate the sum of Han(番) or Yakumen(役滿). Your need to show the
Yaku(役) by decreasing according to Han(番). However, in this homework,
you don’t need to consider Dora(寶牌), Ancient(古役), local(當地特殊牌
型) Yaku(役) and any Yaku(役) which not depend on hand-tiles. All legal
Yaku(役) please see Yaku.pdf
If there’s multiple same Han(番) of Yaku(役), You need to show them by
lexicographical order.
If the sum of Han larger than 13 Han(番), you still need to show total
Han(番), and need to show ”(Kazoe-yakuman)” after show total.
If there no any Yaku(役), you need to show
”The Score is... No Yaku Total: 0 Han”.
If there’s any unreasonable case, you need to stop all input event and show
”The Score is... Unreasonable case Total: 0 Han”.
*/

#include <stdio.h>
#include <stdlib.h>
long long input=-1;
long long openornot=-1;
long long each_tile_count[40]={0};//統計各種牌出現幾次

int compare(const void * a, const void * b) {
    return ( *(int*)a - *(int*)b );
}

void sortArray(long long int arr[], long long int n) {
    qsort(arr, n, sizeof(long long ), compare);
}

int maxx(int a, int b) {
    return (a > b) ? a : b;
}

long long hand[20]={0};//手牌
long long now_tile=0;//目前發到第幾張牌
long long now_meld=0;//目前第幾組面子
long long total_tile=0;//總共發了幾張牌
long long total_meld=0;//總共有幾組面子
long long pair[3]={0};//對子
long long player_wind;//(0:E 1:S 2:W 3:N)
long long prevailing_wind;//(0:E 1:S 2:W 3:N)
long long winningtile;//和張
long long special_case=0;//0=no,1=yes


struct meld{
    long long meld_type;//0:順子 1:刻子或槓
    long long meld_tile[20];
    long long meld_openornot;//0:close 1:open
    long long meld_tile_count;//面子裡有幾張牌
    long long start_number;//如果是刻子，表示重複的數字;如果是順子，表示開始的數字
};

struct meld linee[50]; // 面子集合 Notice: didn't include pair, and special case


//DEBUG:顯示我的所有手牌
void DEBUG_print_my_hand(){
    printf("DEBUG print my hand: ");
    for(int i=0;i<total_tile;i++){
        printf("%lld ",hand[i]);
    }
    printf("\n");
}

//DEBUG:按組別顯示我的所有面子
void DEBUG_print_my_meld(){
    printf("DEBUG print my meld: ");
    for(int i=0;i<total_meld;i++){
        for(int j=0;j<linee[i].meld_tile_count;j++){
            printf("%lld ",linee[i].meld_tile[j]);
        }
        printf(" | ");
    }
    printf("\n");
}

//DEBUG:顯示每種牌出現幾次
void DEBUG_print_each_tile_count(){
    printf("DEBUG print each tile count: ");
    for(int i=0;i<35;i++){
        printf("%lld ",each_tile_count[i]);
    }
    printf("\n");
}

//DEBUG:顯示牌眼
void DEBUG_print_pair(){
    printf("DEBUG print pair: ");
    for(int i=0;i<2;i++){
        printf("%lld ",pair[i]);
    }
    printf("\n");
}

//DEBUG:顯示場風和自家風
void DEBUG_print_wind(){
    printf("DEBUG print player wind: %lld\n",player_wind);
    printf("DEBUG print prevailing wind: %lld\n",prevailing_wind);
}

//DEBUG:顯示和張
void DEBUG_print_winningtile(){
    printf("DEBUG print winningtile: %lld\n",winningtile);
}

//DEBUG:顯示每組面子的種類
void DEBUG_print_meld_type(){
    printf("DEBUG print meld type: ");
    for(int i=0;i<total_meld;i++){
        printf("%lld ",linee[i].meld_type);
    }
    printf("\n");
}

//DEBUG:顯示每組面子是開或閉
void DEBUG_print_meld_openornot(){
    printf("DEBUG print meld openornot: ");
    for(int i=0;i<total_meld;i++){
        printf("%lld ",linee[i].meld_openornot);
    }
    printf("\n");
}

//DEBUG:顯示每組面子的開始數字（如果是刻子，表示重複的數字;如果是順子，表示開始的數字）
void DEBUG_print_meld_start_number(){
    printf("DEBUG print meld start number: ");
    for(int i=0;i<total_meld;i++){
        printf("%lld ",linee[i].start_number);
    }
    printf("\n");
}

//DEBUG:顯示所有除錯資訊
void DEBUG_print_all(){
    printf("\n\n");
    printf("====================================\n");
    printf("DEBUG total melds: %lld\n",total_meld);
    printf("DEBUG total tiles: %lld\n",total_tile);
    DEBUG_print_my_hand();
    DEBUG_print_my_meld();
    DEBUG_print_each_tile_count();
    DEBUG_print_pair();
    DEBUG_print_wind();
    DEBUG_print_winningtile();
    DEBUG_print_meld_type();
    DEBUG_print_meld_openornot();
    DEBUG_print_meld_start_number();
}


void tile_checker(long long tile){
    if(tile<1 || tile>34){
        printf("The Score is...\n    Unreasonable case \nTotal: 0 Han\n");
        exit(0);
    }
    if(each_tile_count[tile]>4){
        printf("The Score is...\n    Unreasonable case \nTotal: 0 Han\n");
        exit(0);
    }
}

void winningtile_checker(long long tile){
    if(each_tile_count[tile]==0){
        printf("The Score is...\n    Unreasonable case \nTotal: 0 Han\n");
        exit(0);
    }
}

void inputRegularMeld(){
    long long now_mild_tile_count=0;//目前面子裡有幾張牌
    input=-1;
    printf("Please input meld: ");
    while(input!=0){
        scanf("%lld",&input);
        if(input==0){
            break;
        }
        each_tile_count[input]++;
        hand[now_tile]=input;
        linee[now_meld].meld_tile[now_mild_tile_count]=input;
        now_mild_tile_count++;
        linee[now_meld].meld_tile_count=now_mild_tile_count;

        //printf("DEBUG: linee[%lld].meld_tile_count=%lld\n",now_meld,linee[now_meld].meld_tile_count);

        tile_checker(input);
        now_tile++;
    }
    now_mild_tile_count=0;
    printf("Is open group(1: YES 0: NO): ");
    scanf("%lld",&openornot);
    if(openornot<0||openornot>1){
        printf("The Score is...\n    Unreasonable case \nTotal: 0 Han\n");
        exit(0);
    }else{
        linee[now_meld].meld_openornot=openornot;
        now_meld++;
    }
}



void verify_each_meld(){
    for(int i=0;i<total_meld;i++){
        sortArray(linee[i].meld_tile,linee[i].meld_tile_count);
        if(linee[i].meld_tile_count==3){
            //DEBUG_print_my_meld();
            if(linee[i].meld_tile[0]==linee[i].meld_tile[1]&&linee[i].meld_tile[1]==linee[i].meld_tile[2]){
                linee[i].meld_type=1;
                linee[i].start_number=linee[i].meld_tile[0];
            }else if(linee[i].meld_tile[0]+1==linee[i].meld_tile[1]&&linee[i].meld_tile[1]+1==linee[i].meld_tile[2]){
                linee[i].meld_type=0;
                linee[i].start_number=linee[i].meld_tile[0];
            }else{
                printf("The Score is...\n    Unreasonable case \nTotal: 0 Han\n");
                exit(0);
            }
        }else if(linee[i].meld_tile_count==4){
            if(linee[i].meld_tile[0]==linee[i].meld_tile[1]&&linee[i].meld_tile[1]==linee[i].meld_tile[2]&&linee[i].meld_tile[2]==linee[i].meld_tile[3]){
                linee[i].meld_type=1;
                linee[i].start_number=linee[i].meld_tile[0];
            }else{
                printf("The Score is...\n    Unreasonable case \nTotal: 0 Han\n");
                exit(0);
            }
        }
    }

}

/*Count Yaku Score*/
long long all_green_status=0;
long long all_honors_status=0;
long long all_terminals_status=0;
long long big_four_winds_status=0;
long long big_three_dragons_status=0;
long long four_concealed_triplets_status=0;
long long four_concealed_triplets_single_wait_status=0;
long long four_kans_status=0;
long long nine_gates_status=0;
long long nine_gates_nine_wait_status=0;
long long little_four_winds_status=0;
long long sever_pairs_status=0;
long long thirteen_orphans_status=0;

long long all_simples_status=0;
long long all_terminals_and_honors_status=0;
long long all_triplets_status=0;
long long flush_status=0;
long long half_flush_status=0;
long long honor_tiles_of_white_or_green_or_red_status=0;
long long little_three_dragons_status=0;
long long No_points_hand_status=0;
long long one_set_of_identical_sequences_status=0;
long long player_wind_status=0;
long long prevailing_wind_status=0;
long long straight_status=0;
long long Terminal_in_each_set_status=0;
long long Terminal_or_honor_in_each_set_status=0;
long long three_kans_status=0;


//以下為役滿計算
//驗證是否是綠一色
void all_green(){
    long long not_green_counter=0;
    for(int i=0;i<total_tile;i++){
        if(hand[i]!=11&&hand[i]!=12&&hand[i]!=13&&hand[i]!=15&&hand[i]!=17&&hand[i]!=33){
            //printf("DEBUG: hand[%d]=%lld\n",i,hand[i]);
            not_green_counter++;
        }
    }
    //printf("DEBUG: not_green_counter=%lld\n",not_green_counter);
    if(not_green_counter==0){
        all_green_status=1;
        //printf("DEBUG:All Green\n");
    }
}

//驗證是否是字一色
void all_honors(){
    long long not_honors_counter=0;
    for(int i=0;i<total_tile;i++){
        if(hand[i]!=28&&hand[i]!=29&&hand[i]!=30&&hand[i]!=31&&hand[i]!=32&&hand[i]!=33&&hand[i]!=34){
            //printf("DEBUG: hand[%d]=%lld\n",i,hand[i]);
            not_honors_counter++;
        }
    }
    //printf("DEBUG: not_honors_counter=%lld\n",not_honors_counter);
    if(not_honors_counter==0){
        //printf("DEBUG:All Honors\n");
        all_honors_status=1;
    }
}

//驗證是否是清老頭
void all_terminals(){
    long long not_terminals_counter=0;
    for(int i=0;i<total_tile;i++){
        if(hand[i]!=1&&hand[i]!=9&&hand[i]!=10&&hand[i]!=18&&hand[i]!=19&&hand[i]!=27){
            //printf("DEBUG: hand[%d]=%lld\n",i,hand[i]);
            not_terminals_counter++;
        }
    }
    //printf("DEBUG: not_terminals_counter=%lld\n",not_terminals_counter);
    if(not_terminals_counter==0){
        //printf("DEBUG:All Terminals\n");
        all_terminals_status=1;
    }
}

//驗證是否是大四喜
void big_four_winds(){
    long long counter=0;
    for(int i=0;i<total_meld;i++){
        if(linee[i].meld_type==1&&(linee[i].start_number==28||linee[i].start_number==29||linee[i].start_number==30||linee[i].start_number==31)){
            counter++;
        }
    }
    if(counter==4){
        //printf("DEBUG: Big Four Winds\n");
        big_four_winds_status=1;
    }
}

//驗證是否是大三元
void big_three_dragons(){
    long long counter=0;
    for(int i=0;i<total_meld;i++){
        if(linee[i].meld_type==1&&(linee[i].start_number==32||linee[i].start_number==33||linee[i].start_number==34)){
            counter++;
        }
    }
    if(counter==3){
        //printf("DEBUG: Big Three Dragons\n");
        big_three_dragons_status=1;
    }
}

//驗證是否是四暗刻
void four_concealed_triplets(){
    long long meld_type_counter=0;
    long long closed_meld_counter=0;
    for(int i=0;i<total_meld;i++){
        if(linee[i].meld_openornot==0){
            closed_meld_counter++;
        }
        if(linee[i].meld_type==1){
            meld_type_counter++;
        }
    }
    if(meld_type_counter==4&&closed_meld_counter==4){
        //printf("DEBUG: Concealed Triplets\n");
        four_concealed_triplets_status=1;
    }
}

//驗證是否是四暗刻單騎
void four_concealed_triplets_single_wait(){
    long long meld_type_counter=0;
    long long closed_meld_counter=0;
    for(int i=0;i<total_meld;i++){
        if(linee[i].meld_openornot==0){
            closed_meld_counter++;
        }
        if(linee[i].meld_type==1){
            meld_type_counter++;
        }
    }
    if(meld_type_counter==4&&closed_meld_counter==4&&winningtile==pair[0]){
        //printf("DEBUG: Concealed Triplets\n");
        four_concealed_triplets_single_wait_status=1;
    }
}

//驗證是否是四槓子
void four_kans(){
    long long counter=0;
    for(int i=0;i<total_meld;i++){
        if(linee[i].meld_type==1){
            counter++;
        }
    }
    if(counter==4&&total_tile==18){
        //printf("DEBUG: Four Kans\n");
        four_kans_status=1;
    }
}

//驗證是否是九蓮寶燈（待改：目前無法分辨是否純種）
void nine_gates(){
    long long closed_meld_counter=0;
    long long composed_checker=0;
    for(int i=0;i<total_meld;i++){
        if(linee[i].meld_openornot==0){
            closed_meld_counter++;
        }
    }
    if(each_tile_count[1]>=3&&each_tile_count[2]>=1&&each_tile_count[3]>=1&&each_tile_count[4]>=1&&each_tile_count[5]>=1&&each_tile_count[6]>=1&&each_tile_count[7]>=1&&each_tile_count[8]>=1&&each_tile_count[9]>=3){
        composed_checker=1;
    }
    if(each_tile_count[10]>=3&&each_tile_count[11]>=1&&each_tile_count[12]>=1&&each_tile_count[13]>=1&&each_tile_count[14]>=1&&each_tile_count[15]>=1&&each_tile_count[16]>=1&&each_tile_count[17]>=1&&each_tile_count[18]>=3){
        composed_checker=1;
    }
    if(each_tile_count[19]>=3&&each_tile_count[20]>=1&&each_tile_count[21]>=1&&each_tile_count[22]>=1&&each_tile_count[23]>=1&&each_tile_count[24]>=1&&each_tile_count[25]>=1&&each_tile_count[26]>=1&&each_tile_count[27]>=3){
        composed_checker=1;
    }
    if(closed_meld_counter==4&&composed_checker==1){
        //printf("DEBUG: Nine Gates\n");
        nine_gates_status=1;
    }
}

//驗證是否是純正九蓮寶燈（待改：目前無法分辨是否純種）
void nine_gates_nine_wait(){
    long long closed_meld_counter=0;
    long long composed_checker=0;
    for(int i=0;i<total_meld;i++){
        if(linee[i].meld_openornot==0){
            closed_meld_counter++;
        }
    }
    if(each_tile_count[1]==3&&each_tile_count[2]==1&&each_tile_count[3]==1&&each_tile_count[4]==1&&each_tile_count[5]==1&&each_tile_count[6]==1&&each_tile_count[7]==1&&each_tile_count[8]==1&&each_tile_count[9]==3){
        composed_checker=1;
    }
    if(each_tile_count[10]==3&&each_tile_count[11]==1&&each_tile_count[12]==1&&each_tile_count[13]==1&&each_tile_count[14]==1&&each_tile_count[15]==1&&each_tile_count[16]==1&&each_tile_count[17]==1&&each_tile_count[18]==3){
        composed_checker=1;
    }
    if(each_tile_count[19]==3&&each_tile_count[20]==1&&each_tile_count[21]==1&&each_tile_count[22]==1&&each_tile_count[23]==1&&each_tile_count[24]==1&&each_tile_count[25]==1&&each_tile_count[26]==1&&each_tile_count[27]==3){
        composed_checker=1;
    }
    if(closed_meld_counter==4&&composed_checker==1){
        //printf("DEBUG: Nine Gates\n");
        nine_gates_nine_wait_status=1;
    }
}

//驗證是否是小四喜
void little_four_winds(){
    long long counter=0;
    long long pair_wind_checker=0;
    if(pair[0]==28||pair[0]==29||pair[0]==30||pair[0]==31){
        pair_wind_checker=1;
    }
    for(int i=0;i<total_meld;i++){
        if(linee[i].meld_type==1&&(linee[i].start_number==28||linee[i].start_number==29||linee[i].start_number==30||linee[i].start_number==31)){
            counter++;
        }
    }
    if(pair_wind_checker==1&&counter==3){
        //printf("DEBUG: Little Four Winds\n");
        little_four_winds_status=1;
    }
}

//驗證是否是國士無雙
void thirteen_orphans(){
    for(int i=1;i<=34;i++){
        if(each_tile_count[i]==1){
            //printf("DEBUG: each_tile_count[%d]=%lld\n",i,each_tile_count[i]);
            if(each_tile_count[1]>=1&&each_tile_count[9]>=1&&each_tile_count[10]>=1&&each_tile_count[18]>=1&&each_tile_count[19]>=1&&each_tile_count[27]>=1&&each_tile_count[28]>=1&&each_tile_count[29]>=1&&each_tile_count[30]>=1&&each_tile_count[31]>=1&&each_tile_count[32]>=1&&each_tile_count[33]>=1&&each_tile_count[34]>=1){
                //printf("DEBUG: Thirteen Orphans\n");
                thirteen_orphans_status=1;
            }
        }
    }
}

 //以下為番數計算
 
 //驗證是否是斷幺九
 void all_simples(){
    long long not_Yaochu_counter=0;//非幺九的牌有幾張
    for(int i=0;i<35;i++){
        if(each_tile_count[i]>0&&i!=1&&i!=9&&i!=10&&i!=18&&i!=19&&i!=27&&i!=28&&i!=29&&i!=30&&i!=31&&i!=32&&i!=33&&i!=34){
            not_Yaochu_counter+=each_tile_count[i];
            //printf("DEBUG: %lld\n",not_Yaochu_counter);
        }
    }
    if(not_Yaochu_counter==total_tile){
        all_simples_status=1;
    }
 }

//驗證是否是混老頭
 void all_terminals_and_honors(){
    long long meld_type_checker=0;//計算面子裡有幾個刻子
    long long meld_Yaochu_counter=0;//計算面子裡有幾組幺九
    for(int i=0;i<total_meld;i++){
        if(linee[i].meld_type==1){
            meld_type_checker++;
        }
        if(linee[i].start_number==1||linee[i].start_number==9||linee[i].start_number==10||linee[i].start_number==18||linee[i].start_number==19||linee[i].start_number==27||linee[i].start_number==28||linee[i].start_number==29||linee[i].start_number==30||linee[i].start_number==31||linee[i].start_number==32||linee[i].start_number==33||linee[i].start_number==34){
            meld_Yaochu_counter++;
        }
    }
    if(meld_type_checker==total_meld&&meld_Yaochu_counter==total_meld){
        //printf("DEBUG: All Terminals and Honors\n");
        //printf("DEBUG: meld_type_checker:%lld",meld_type_checker);
        all_terminals_and_honors_status=1;
    }
 }

 //判斷是否是對對和
 void all_triplets(){
    long long meld_type_checker=0;//計算面子裡有幾個刻子
    for(int i=0;i<total_meld;i++){
        if(linee[i].meld_type==1){
            meld_type_checker++;
        }
    }
    if(meld_type_checker==total_meld){
        //printf("DEBUG: All Triplets\n");
        all_triplets_status=1;
    }
}

//判斷是否是清一色
void flush(){
    long long card_suit_checker[4]={0};//計算每種花色有幾組牌（在此pair也算一組），0:餅 1:索 2:萬 3:字
    for(int i=0;i<total_meld;i++){
        if(linee[i].start_number>=1&&linee[i].start_number<=9){
            card_suit_checker[0]++;
        }else if(linee[i].start_number>=10&&linee[i].start_number<=18){
            card_suit_checker[1]++;
        }else if(linee[i].start_number>=19&&linee[i].start_number<=27){
            card_suit_checker[2]++;
        }else if(linee[i].start_number>=28&&linee[i].start_number<=34){
            card_suit_checker[3]++;
        }
    }
    if(pair[0]>=1&&pair[0]<=9){
        card_suit_checker[0]++;
    }else if(pair[0]>=10&&pair[0]<=18){
        card_suit_checker[1]++;
    }else if(pair[0]>=19&&pair[0]<=27){
        card_suit_checker[2]++;
    }else if(pair[0]>=28&&pair[0]<=34){
        card_suit_checker[3]++;
    }

    if(card_suit_checker[3]==0&&(card_suit_checker[0]==total_meld+1||card_suit_checker[1]==total_meld+1||card_suit_checker[2]==total_meld+1)){
        //printf("DEBUG: Flush\n");
        flush_status=1;
    }
    
}

//判斷是否是混一色
void half_flush(){
    long long card_suit_checker[4]={0};//計算每種花色有幾組牌（在此pair也算一組），0:餅 1:索 2:萬 3:字
    for(int i=0;i<total_meld;i++){
        if(linee[i].start_number>=1&&linee[i].start_number<=9){
            card_suit_checker[0]++;
        }else if(linee[i].start_number>=10&&linee[i].start_number<=18){
            card_suit_checker[1]++;
        }else if(linee[i].start_number>=19&&linee[i].start_number<=27){
            card_suit_checker[2]++;
        }else if(linee[i].start_number>=28&&linee[i].start_number<=34){
            card_suit_checker[3]++;
        }
    }
    if(pair[0]>=1&&pair[0]<=9){
        card_suit_checker[0]++;
    }else if(pair[0]>=10&&pair[0]<=18){
        card_suit_checker[1]++;
    }else if(pair[0]>=19&&pair[0]<=27){
        card_suit_checker[2]++;
    }else if(pair[0]>=28&&pair[0]<=34){
        card_suit_checker[3]++;
    }

    if((card_suit_checker[0]+card_suit_checker[3]==total_meld+1||card_suit_checker[1]+card_suit_checker[3]==total_meld+1||card_suit_checker[2]+card_suit_checker[3]==total_meld+1)){
        //printf("DEBUG: Flush\n");
        half_flush_status=1;
    }
}

//驗證是否是役牌（在此場風和自家風另外算）
void honor_tiles_of_white_or_green_or_red(){
    long long meld_honor_checker=0;//計算面子裡有幾組役牌(白、發、中)
    for(int i=0;i<total_meld;i++){
        if(linee[i].start_number==32||linee[i].start_number==33||linee[i].start_number==34){
            meld_honor_checker++;
        }
    }
    if(meld_honor_checker>0){
        //printf("DEBUG: Honor\n");
        honor_tiles_of_white_or_green_or_red_status=1;
    }

}

//驗證是否是小三元
void little_three_dragons(){
    long long meld_honor_checker=0;//計算面子裡有幾組役牌(白、發、中)
    long long pair_honor_checker=0;//計算對子裡有幾張役牌(白、發、中)
    for(int i=0;i<total_meld;i++){
        if(linee[i].start_number==32||linee[i].start_number==33||linee[i].start_number==34){
            meld_honor_checker++;
        }
    }
    if(pair[0]==32||pair[0]==33||pair[0]==34){
        pair_honor_checker++;
    }
    if(meld_honor_checker==2&&pair_honor_checker==1){
        //printf("DEBUG: Little Three Dragons\n");
        little_three_dragons_status=1;
    }
}

//驗證是否是平和
void no_points_hand(){
    //printf("DEBUG: ERROR! WAITING FOR FIX\n");
}

//驗證是否是一盃口
void one_set_of_identical_sequences(){
    long long sequences_checker[30]={0};//計算面子裡相同的順子個出現幾次
    long long maxium_same_sequences=0;//最多相同的順子個數
    for(int i=0;i<total_meld;i++){
        if(linee[i].meld_type==0&&linee[i].start_number>=1&&linee[i].start_number<=27){
            sequences_checker[linee[i].start_number]++;
        }
    }
    for(int i=0;i<28;i++){
        maxium_same_sequences=maxx(maxium_same_sequences,sequences_checker[i]);
    }
    if(maxium_same_sequences==2){
        //printf("DEBUG: One Set of Identical Sequences\n");
        one_set_of_identical_sequences_status=1;
    }
}

//驗證是否是自家風
void players_wind(){
    long long meld_wind_checker=0;//計算面子裡有沒有自家風
    for(int i=0;i<total_meld;i++){
        if(linee[i].start_number-28==player_wind){
            meld_wind_checker=1;
        }
    }
    if(meld_wind_checker==1){
        //printf("DEBUG: Player's Wind\n");
        player_wind_status=1;
    }
}

//驗證是否是場風
void prevalling_wind(){
    long long meld_wind_checker=0;//計算面子裡有沒有場風
    for(int i=0;i<total_meld;i++){
        if(linee[i].start_number-28==prevailing_wind){
            meld_wind_checker=1;
        }
    }
    if(meld_wind_checker==1){
        //printf("DEBUG: Prevalling Wind\n");
        player_wind_status=1;
    }
}

//驗證是否是一氣通貫
void straight(){
    long long straight_pin_checker=0;
    long long straight_sou_checker=0;
    long long straight_wan_checler=0;
    for(int i=0;i<total_meld;i++){
        //確認餅是否有123 456 789
        if(linee[i].meld_type==0&&linee[i].start_number==1){
            straight_pin_checker++;
        }
        if(linee[i].meld_type==0&&linee[i].start_number==4){
            straight_pin_checker++;
        }
        if(linee[i].meld_type==0&&linee[i].start_number==7){
            straight_pin_checker++;
        }
        //確認索是否有123 456 789
        if(linee[i].meld_type==0&&linee[i].start_number==10){
            straight_sou_checker++;
        }
        if(linee[i].meld_type==0&&linee[i].start_number==13){
            straight_sou_checker++;
        }
        if(linee[i].meld_type==0&&linee[i].start_number==16){
            straight_sou_checker++;
        }
        //確認萬是否有123 456 789
        if(linee[i].meld_type==0&&linee[i].start_number==19){
            straight_wan_checler++;
        }
        if(linee[i].meld_type==0&&linee[i].start_number==22){
            straight_wan_checler++;
        }
        if(linee[i].meld_type==0&&linee[i].start_number==25){
            straight_wan_checler++;
        }
    }
    if(straight_pin_checker==3||straight_sou_checker==3||straight_wan_checler==3){
        //printf("DEBUG: Straight\n");
        straight_status=1;
    }
}

//驗證是否是純全帶幺九
void Terminal_in_each_set(){
    long long terminal_in_each_set_checker=0;
    for(int i=0;i<total_meld;i++){
        for(int j=0;j<linee[i].meld_tile_count;j++){
            if(linee[i].meld_tile[j]==1||linee[i].meld_tile[j]==9||linee[i].meld_tile[j]==10||linee[i].meld_tile[j]==18||linee[i].meld_tile[j]==19||linee[i].meld_tile[j]==27){
                terminal_in_each_set_checker++;
                break;
            }
        }
    }
    if(pair[0]==1||pair[0]==9||pair[0]==10||pair[0]==18||pair[0]==19||pair[0]==27){
        terminal_in_each_set_checker++;
    }
    if(terminal_in_each_set_checker==5){
        //printf("DEBUG: Terminal in each set\n");
        Terminal_in_each_set_status=1;
    }
}

//驗證是否是混全帶幺九
void Terminal_or_honor_in_each_set(){
    long long terminal_or_honor_in_each_set_checker=0;
    for(int i=0;i<total_meld;i++){
        for(int j=0;j<linee[i].meld_tile_count;j++){
            if(linee[i].meld_tile[j]==1||linee[i].meld_tile[j]==9||linee[i].meld_tile[j]==10||linee[i].meld_tile[j]==18||linee[i].meld_tile[j]==19||linee[i].meld_tile[j]==27||linee[i].meld_tile[j]==28||linee[i].meld_tile[j]==29||linee[i].meld_tile[j]==30||linee[i].meld_tile[j]==31||linee[i].meld_tile[j]==32||linee[i].meld_tile[j]==33||linee[i].meld_tile[j]==34){
                terminal_or_honor_in_each_set_checker++;
                break;
            }
        }
    }
    if(pair[0]==1||pair[0]==9||pair[0]==10||pair[0]==18||pair[0]==19||pair[0]==27||pair[0]==28||pair[0]==29||pair[0]==30||pair[0]==31||pair[0]==32||pair[0]==33||pair[0]==34){
        terminal_or_honor_in_each_set_checker++;
    }
    if(terminal_or_honor_in_each_set_checker==5){
        //printf("DEBUG: Terminal in each set\n");
        Terminal_or_honor_in_each_set_status=1;
    }
}

//驗證是否是七對子
void seven_pair(){
    long long pair_checker=0;
    for(int i=1;i<=34;i++){
        if(each_tile_count[i]==2){
            pair_checker++;
        }
    }
    if(pair_checker==7){
        sever_pairs_status=1;
    }
}

//驗證是否是三槓子
void three_kans(){
    long long counter=0;
    for(int i=0;i<total_meld;i++){
        if(linee[i].meld_type==1&&linee[i].meld_tile_count==4){
            counter++;
        }
    }
    if(counter==3){
        //printf("DEBUG: Three Kans\n");
        three_kans_status=1;
    }
}


//DEBUG: 顯示所有役種的狀態
void DEBUG_print_all_yahu_status(){
    printf("DEBUG print all yaku status: \n");
    printf("DEBUG print all_green_status: %lld\n",all_green_status);
    printf("DEBUG print all_honors_status: %lld\n",all_honors_status);
    printf("DEBUG print all_terminals_status: %lld\n",all_terminals_status);
    printf("DEBUG print big_four_winds_status: %lld\n",big_four_winds_status);
    printf("DEBUG print big_three_dragons_status: %lld\n",big_three_dragons_status);
    printf("DEBUG print four_concealed_triplets_status: %lld\n",four_concealed_triplets_status);
    printf("DEBUG print four_concealed_triplets_single_wait_status: %lld\n",four_concealed_triplets_single_wait_status);
    printf("DEBUG print four_kans_status: %lld\n",four_kans_status);
    printf("DEBUG print nine_gates_status: %lld\n",nine_gates_status);
    printf("DEBUG print nine_gates_nine_wait_status: %lld\n",nine_gates_nine_wait_status);
    printf("DEBUG print little_four_winds_status: %lld\n",little_four_winds_status);
    printf("DEBUG print sever_pairs_status: %lld\n",sever_pairs_status);
    printf("DEBUG print thirteen_orphans_status: %lld\n",thirteen_orphans_status);
    
    printf("DEBUG print all_simples_status: %lld\n",all_simples_status);
    printf("DEBUG print all_terminals_and_honors_status: %lld\n",all_terminals_and_honors_status);
    printf("DEBUG print all_triplets_status: %lld\n",all_triplets_status);
    printf("DEBUG print flush_status: %lld\n",flush_status);
    printf("DEBUG print half_flush_status: %lld\n",half_flush_status);
    printf("DEBUG print honor_tiles_of_white_or_green_or_red_status: %lld\n",honor_tiles_of_white_or_green_or_red_status);
    printf("DEBUG print little_three_dragons_status: %lld\n",little_three_dragons_status);
    printf("DEBUG print No_points_hand_status: %lld\n",No_points_hand_status);
    printf("DEBUG print one_set_of_identical_sequences_status: %lld\n",one_set_of_identical_sequences_status);
    printf("DEBUG print player_wind_status: %lld\n",player_wind_status);
    printf("DEBUG print prevailing_wind_status: %lld\n",prevailing_wind_status);
    printf("DEBUG print straight_status: %lld\n",straight_status);
    printf("DEBUG print Terminal_in_each_set_status: %lld\n",Terminal_in_each_set_status);
    printf("DEBUG print Terminal_or_honor_in_each_set_status: %lld\n",Terminal_or_honor_in_each_set_status);
    printf("DEBUG print three_kans_status: %lld\n",three_kans_status);
}


void judge_yakuman(){
    long long now_yakuman=0;
    if(thirteen_orphans_status==1){
        now_yakuman+=1;
    }
    if(all_green_status==1){
        now_yakuman+=1;
    }
    if(all_honors_status==1){
        now_yakuman+=1;
    }
    if(all_terminals_status==1){
        now_yakuman+=1;
    }
    if(big_four_winds_status==1){
        now_yakuman+=2;
    }
    if(big_three_dragons_status==1){
        now_yakuman+=1;
    }
    if(four_concealed_triplets_status==1){
        now_yakuman+=1;
    }
    if(four_concealed_triplets_single_wait_status==1){
        now_yakuman+=2;
    }
    if(four_kans_status==1){
        now_yakuman+=1;
    }
    if(nine_gates_status==1){
        now_yakuman+=1;
    }
    // if(nine_gates_nine_wait_status==1){
    //     now_yakuman+=2;
    // }
    if(little_four_winds_status==1){
        now_yakuman+=1;
    }
    if(now_yakuman>0){
        printf("\nThe Score is...\n");
        if(big_four_winds_status==1){
            printf("    Big Four Winds (2 Yakuman)\n");
            //now_yakuman+=2;
        }
        if(four_concealed_triplets_single_wait_status==1){
            printf("    Four Concealed Triplets Single Wait (2 Yakuman)\n");
            //now_yakuman+=2;
        }
        if(thirteen_orphans_status==1){
            printf("    Thirteen Orphans (1 Yakuman)\n");
        }
        if(all_green_status==1){
            printf("    All Green (1 Yakuman)\n");
            //now_yakuman+=1;
        }
        if(all_honors_status==1){
            printf("    All Honors (1 Yakuman)\n");
            //now_yakuman+=1;
        }
        if(all_terminals_status==1){
            printf("    All Terminals (1 Yakuman)\n");
            //now_yakuman+=1;
        }
        if(big_three_dragons_status==1){
            printf("    Big Three Dragons (1 Yakuman)\n");
            //now_yakuman+=1;
        }
        if(four_concealed_triplets_status==1){
            printf("    Four Concealed Triplets (1 Yakuman)\n");
            //now_yakuman+=1;
        }
        
        if(four_kans_status==1){
            printf("    Four Kans (1 Yakuman)\n");
            //now_yakuman+=1;
        }
        if(little_four_winds_status==1){
            printf("    Little Four Winds (1 Yakuman)\n");
            //now_yakuman+=1;
        }
        if(nine_gates_status==1){
            printf("    Nine Gates (1 Yakuman)\n");
            //now_yakuman+=1;
        }
        printf("Total: %lld Yakuman\n",now_yakuman);
        exit(0);
    
    }
}

void judge_han(){
    long long now_han=0;
    if(all_simples_status==1){
        now_han+=1;
    }
    if(sever_pairs_status==1){
        now_han+=2;
    }
    if(one_set_of_identical_sequences_status==1){
        now_han+=1;
    }
    if(all_triplets_status==1){
        now_han+=2;
    }
    if(three_kans_status==1){
        now_han+=2;
    }
    if(all_terminals_and_honors_status==1){
        now_han+=2;
    }
    if(little_three_dragons_status==1){
        now_han+=2;
    }
    if(honor_tiles_of_white_or_green_or_red_status==1){
        long long temp=0;
        for(int i=0;i<total_meld;i++){
            if(linee[i].start_number==32||linee[i].start_number==33||linee[i].start_number==34){
                temp++;
            }
        }
        now_han+=temp;
    }
    if(player_wind_status==1){
        now_han+=1;
    }
    if(prevailing_wind_status==1){
        now_han+=1;
    }
    if(straight_status==1){
        long long open_counter=0;
        for(int i=0;i<total_meld;i++){
            if(linee[i].meld_openornot==1){
                open_counter++;
            }
        }
        if(open_counter==0){
            now_han+=2;
        }else{
            now_han+=1;
        }
    }
    if(flush_status==1){
        long long open_counter=0;
        for(int i=0;i<total_meld;i++){
            if(linee[i].meld_openornot==1){
                open_counter++;
            }
        }
        if(open_counter==0){
            now_han+=6;
        }else{
            now_han+=5;
        }
    }
    if(half_flush_status==1){
        long long open_counter=0;
        for(int i=0;i<total_meld;i++){
            if(linee[i].meld_openornot==1){
                open_counter++;
            }
        }
        if(open_counter==0){
            now_han+=3;
        }else{
            now_han+=2;
        }
    }
    if(Terminal_or_honor_in_each_set_status==1){
        long long open_counter=0;
        for(int i=0;i<total_meld;i++){
            if(linee[i].meld_openornot==1){
                open_counter++;
            }
        }
        if(open_counter==0){
            now_han+=2;
        }else{
            now_han+=1;
        }
    }
    if(Terminal_in_each_set_status==1){
        long long open_counter=0;
        for(int i=0;i<total_meld;i++){
            if(linee[i].meld_openornot==1){
                open_counter++;
            }
        }
        if(open_counter==0){
            now_han+=3;
        }else{
            now_han+=2;
        }
    }
    if(now_han>0){
        printf("\nThe Score is...\n");
        if(flush_status==1){
            long long open_counter=0;
            for(int i=0;i<total_meld;i++){
                if(linee[i].meld_openornot==1){
                    open_counter++;
                }
            }
            if(open_counter==0){
                printf("    Flush (6 Han)\n");
                //now_han+=6;
            }else{
                printf("    Flush (5 Han)\n");
                //now_han+=5;
            }
        }
        if(half_flush_status==1){
            long long open_counter=0;
            for(int i=0;i<total_meld;i++){
                if(linee[i].meld_openornot==1){
                    open_counter++;
                }
            }
            if(open_counter==0){
                printf("    Half Flush (3 Han)\n");
                //now_han+=3;
            }else{
                printf("    Half Flush (2 Han)\n");
                //now_han+=2;
            }
        }
        if(Terminal_in_each_set_status==1){
            long long open_counter=0;
            for(int i=0;i<total_meld;i++){
                if(linee[i].meld_openornot==1){
                    open_counter++;
                }
            }
            if(open_counter==0){
                printf("    Terminal in Each Set (3 Han)\n");
                //now_han+=3;
            }else{
                printf("    Terminal in Each Set (2 Han)\n");
                //now_han+=2;
            }
        }
        if(all_terminals_and_honors_status==1){
            printf("    All Terminals and Honors (2 Han)\n");
            //now_han+=2;
        }
        if(all_triplets_status==1){
            printf("    All Triplets (2 Han)\n");
            //now_han+=2;
        }
        if(little_three_dragons_status==1){
            printf("    Little Three Dragons (2 Han)\n");
            //now_han+=2;
        }
        if(sever_pairs_status==1){
            printf("    Seven Pairs (2 Han)\n");
        }
        if(straight_status==1){
            long long open_counter=0;
            for(int i=0;i<total_meld;i++){
                if(linee[i].meld_openornot==1){
                    open_counter++;
                }
            }
            if(open_counter==0){
                printf("    Straight (2 Han)\n");
                //now_han+=2;
            }else{
                printf("    Straight (1 Han)\n");
                //now_han+=1;
            }
        }
        if(three_kans_status==1){
            printf("    Three Kans (2 Han)\n");
            //now_han+=2;
        }
        if(all_simples_status==1){
            printf("    All Simples (1 Han)\n");
            //now_han+=1;
        }
        if(honor_tiles_of_white_or_green_or_red_status==1){
            long long temp=0;
            for(int i=0;i<total_meld;i++){
                if(linee[i].start_number==32||linee[i].start_number==33||linee[i].start_number==34){
                    temp++;
                }
            }
            printf("    Honor Tiles of White or Green or Red (%lld Han)\n",temp);
            //now_han+=temp;
        }
        if(one_set_of_identical_sequences_status==1){
            printf("    One Set of Identical Sequences (1 Han)\n");
            //now_han+=1;
        }
        if(player_wind_status==1){
            printf("    Player's Wind (1 Han)\n");
            //now_han+=1;
        }
        if(prevailing_wind_status==1){
            printf("    Prevailing Wind (1 Han)\n");
            //now_han+=1;
        }
        if(Terminal_or_honor_in_each_set_status==1){
            long long open_counter=0;
            for(int i=0;i<total_meld;i++){
                if(linee[i].meld_openornot==1){
                    open_counter++;
                }
            }
            if(open_counter==0){
                printf("    Terminal or Honor in Each Set (2 Han)\n");
                //now_han+=2;
            }else{
                printf("    Terminal or Honor in Each Set (1 Han)\n");
                //now_han+=1;
            }
        }           
        printf("Total: %lld han\n",now_han);
    }else{
        printf("The Score is...\n    No Yaku \nTotal: 0 Han\n");
    }

}

int main(){
    now_tile=0;//目前發到第幾張牌
    now_meld=0;//目前第幾組面子
    total_tile=0;//總共發了幾張牌
    total_meld=0;
    long long now_mild_tile_count=0;//目前面子裡有幾張牌
    printf("Please input meld: ");
    while(input!=0){
        scanf("%lld",&input);
        if(input==0){
            break;
        }
        each_tile_count[input]++;
        hand[now_tile]=input;
        linee[now_meld].meld_tile[now_mild_tile_count]=input;
        now_mild_tile_count++;
        linee[now_meld].meld_tile_count=now_mild_tile_count;

        //printf("DEBUG: linee[%lld].meld_tile_count=%lld\n",now_meld,linee[now_meld].meld_tile_count);

        tile_checker(input);
        now_tile++;
    }
    now_mild_tile_count=0;
    //printf("DEBUG: %lld\n",now_tile);
    
    /*Find is special case or not*/
    if(now_tile==3||now_tile==4){
        printf("Is open group(1: YES 0: NO): ");
        scanf("%lld",&openornot);
        if(openornot<0||openornot>1){
            printf("The Score is...\n    Unreasonable case \nTotal: 0 Han\n");
            exit(0);
        }else{
            linee[now_meld].meld_openornot=openornot;
            now_meld++;
        }

        inputRegularMeld();
        inputRegularMeld();
        inputRegularMeld();

        /*Input pair*/
        printf("Please input pair: ");
        scanf("%lld %lld",&pair[0],&pair[1]);
        each_tile_count[pair[0]]++;
        each_tile_count[pair[1]]++;
        hand[now_tile]=pair[0];
        now_tile++;
        hand[now_tile]=pair[1];

        tile_checker(pair[0]);
        tile_checker(pair[1]);
        if(pair[0]!=pair[1]){
            printf("The Score is...\n    Unreasonable case \nTotal: 0 Han\n");
            exit(0);
        }
        now_tile++;

    }else{
        //judge special case
        special_case=1;
        while(input!=0){
            printf("Please input meld: ");
            scanf("%lld",&input);
            if(input==0){
                break;
            }
            
            hand[now_tile]=input;
            each_tile_count[input]++;
            now_tile++;
            //now_mild_tile_count++;
            //linee[now_meld].meld_tile_count=now_mild_tile_count;
            //printf("DEBUG: linee[%lld].meld_tile_count=%lld\n",now_meld,linee[now_meld].meld_tile_count);
            tile_checker(input);
            //printf("DEBUG: %lld\n",now_tile);
        }
    }
    
    
    /*DEBUG*/
    // for(int i=0;i<total_tile;i++){
    //     printf("%lld ",hand[i]);
    // }

    
    printf("Please input winning tile: ");
    scanf("%lld",&input);
    //each_tile_count[input]++;
    //hand[now_tile]=input;
    now_mild_tile_count++;
    tile_checker(input);
    winningtile_checker(input);
    winningtile=input;

    total_tile=now_tile;
    total_meld=now_meld;
    if(total_tile>14&&special_case==1){
        printf("The Score is...\n    Unreasonable case \nTotal: 0 Han\n");
        exit(0);
    }
    printf("Player's wind(0:E 1:S 2:W 3:N): ");
    scanf("%lld",&player_wind);
    if(player_wind<0||player_wind>3){
        printf("The Score is...\n    Unreasonable case \nTotal: 0 Han\n");
        exit(0);
    }
    
    printf("Prevailing wind(0:E 1:S 2:W 3:N): ");
    scanf("%lld",&prevailing_wind);
    if(prevailing_wind<0||prevailing_wind>3){
        printf("The Score is...\n    Unreasonable case \nTotal: 0 Han\n");
        exit(0);
    }


    verify_each_meld();
    
    //DEBUG_print_all();

    all_green();
    all_honors();
    all_terminals();
    big_four_winds();
    big_three_dragons();
    four_concealed_triplets();
    four_concealed_triplets_single_wait();
    four_kans();
    nine_gates();
    nine_gates_nine_wait();
    little_four_winds();
    thirteen_orphans();
    seven_pair();

    all_simples();
    all_terminals_and_honors();
    all_triplets();
    flush();
    half_flush();
    honor_tiles_of_white_or_green_or_red();
    little_three_dragons();
    no_points_hand();
    one_set_of_identical_sequences();
    players_wind();
    prevalling_wind();
    straight();
    Terminal_in_each_set();
    Terminal_or_honor_in_each_set();
    three_kans();
    four_kans();

    //DEBUG_print_all_yahu_status();

    judge_yakuman();
    if(thirteen_orphans_status==0){
        judge_han();
    }else{
        printf("The Score is...\n    No Yaku \nTotal: 0 Han\n");
    }
}