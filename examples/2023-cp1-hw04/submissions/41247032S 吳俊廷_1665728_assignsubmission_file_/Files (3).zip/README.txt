Name: 吳俊廷
Student ID: 41247032S

## How to build the program?
Open the terminal and type "make" to build the program.

## How to execute your built programs?
Open the terminal and type "./<hw04YY>" to execute the program, which YY is the problem number.
For example, ./hw0402 is the executable program for homework #4 problem 2.


