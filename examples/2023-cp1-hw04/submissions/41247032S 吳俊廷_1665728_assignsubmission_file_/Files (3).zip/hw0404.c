#include <stdio.h>
#include "mychess.h"

int main(){

    return 0;
}