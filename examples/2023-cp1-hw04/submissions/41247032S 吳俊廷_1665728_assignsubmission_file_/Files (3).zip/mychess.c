#include "mychess.h"

int32_t checkmate( int32_t board[10][9] ){
    return -1;
}