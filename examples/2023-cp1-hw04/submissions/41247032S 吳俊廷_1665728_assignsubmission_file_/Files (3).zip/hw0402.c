#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
long long f_degree;//f(x)的最高次數
long long g_degree;//g(x)的最高次數
long long f_derivative_degree;//f'(x)的最高次數
long long g_derivative_degree;//g'(x)的最高次數
long long f_times_gp_degree;//f(x)*g'(x)的最高次數
long long fp_times_g_degree;//f'(x)*g(x)的最高次數
long long d_f_times_g_degree;//(f(x)*g(x))'的最高次數
long long d_f_on_g_numerator_degree;//(f(x)/g(x))'的分子最高次數
long long d_f_on_g_denominator_degree;//(f(x)/g(x))'的分母最高次數
long long ans_d_f_on_g_numerator_degree;//化簡(f(x)/g(x))'的分子最高次數
long long ans_d_f_on_g_denominator_degree;//化簡(f(x)/g(x))'的分母最高次數


long long f_coefficients[5000];//f(x)的各項係數
long long g_coefficients[5000];//g(x)的各項係數
long long f_derivative_coefficients[5000];//f'(x)的各項係數
long long g_derivative_coefficients[5000];//g'(x)的各項係數
long long f_times_gp_coefficients[5000];//f(x)*g'(x)的各項係數
long long fp_times_g_coefficients[5000];//f'(x)*g(x)的各項係數
long long d_f_times_g_coefficients[5000];//(f(x)*g(x))'的各項係數
long long d_f_on_g_numerator_coefficients[5000];//(f(x)/g(x))'的分子各項係數
long long d_f_on_g_denominator_coefficients[5000];//(f(x)/g(x))'的分母各項係數


//計算微分
void calculate_derivative(long long degree, long long* coefficients, long long* derivative_coefficients) {
    long long now_degree=degree;
    for(int i = 0; i < degree; i++) {
        //printf("%lld ",coefficients[i]);
        derivative_coefficients[i] = coefficients[i] * now_degree;
        now_degree--;
    }
}

//印出多項式
void print_poly(long long degree,long long coefficients[]){
    long long is_first=1;
    //檢查室否為零多項式
    long long is_zero=1;
    for(int i=0;i<=degree;i++){
        if(coefficients[i]!=0){
            is_zero=0;
            break;
        }
    }
    if(is_zero==1){
        printf("0\n");
        return;
    }
    //印出常數項以外的項
    for(int i=0;i<degree;i++){
        if(coefficients[i]>0){         
            if(is_first==0){
                printf("+");
            }
            if(coefficients[i]==1){
                if(degree-i==1){
                    printf("x");
                }else{
                    printf("x^%lld",degree-i);
                }
                
            }else{
                if(degree-i==1){
                    printf("%lldx",coefficients[i]);
                }else{
                    printf("%lldx^%lld",coefficients[i],degree-i);
                }
            }
            if(is_first==1){
                is_first=0;
            }
        }else if(coefficients[i]<0){
            if(coefficients[i]==-1){
                if(degree-i==1){
                    printf("-x");
                }else{
                    printf("-x^%lld",degree-i);
                }
                
            }else{
                if(degree-i==1){
                    printf("%lldx",coefficients[i]);
                }else{
                    printf("%lldx^%lld",coefficients[i],degree-i);
                }
                
            }
            if(is_first==1){
                is_first=0;
            }
        }
    }
    
    //印出常數項
    if(coefficients[degree]>0){
        if(is_first==0){
            printf("+");
        }
        printf("%lld",coefficients[degree]);
    }else if(coefficients[degree]<0){
        printf("%lld",coefficients[degree]);
    }
    printf("\n");
}

long long print_poly_count(long long degree,long long coefficients[]){
    long long is_first=1;
    long long char_count=0;

    //檢查室否為零多項式
    long long is_zero=1;
    for(int i=0;i<=degree;i++){
        if(coefficients[i]!=0){
            is_zero=0;
            break;
        }
    }
    if(is_zero==1){
        //printf("0\n");
        return 1;
    }
    //印出常數項以外的項
    for(int i=0;i<degree;i++){
        if(coefficients[i]>0){         
            if(is_first==0){
                //printf("+");
                char_count += 1; // for "+"
            }
            if(coefficients[i]==1){
                if(degree-i==1){
                    //printf("x");
                    char_count += 1; // for "x"
                }else{
                    //printf("x^%lld",degree-i);
                    char_count += 2 + snprintf(NULL, 0, "%lld", degree-i); // for "x^" and the exponent
                }
                
            }else{
                if(degree-i==1){
                    //printf("%lldx",coefficients[i]);
                    char_count += snprintf(NULL, 0, "%lld", coefficients[i])+1; // for the coefficient
                }else{
                    //printf("%lldx^%lld",coefficients[i],degree-i);
                    char_count += snprintf(NULL, 0, "%lld", coefficients[i])+2 + snprintf(NULL, 0, "%lld", degree-i); // for the coefficient
                }
            }
            if(is_first==1){
                is_first=0;
            }
        }else if(coefficients[i]<0){
            if(coefficients[i]==-1){
                if(degree-i==1){
                    //printf("-x");
                    char_count += 2; // for "-x"
                }else{
                    //printf("-x^%lld",degree-i);
                    char_count += 3 + snprintf(NULL, 0, "%lld", degree-i); // for "-x^" and the exponent
                }
                
            }else{
                if(degree-i==1){
                    //printf("%lldx",coefficients[i]);
                    char_count += snprintf(NULL, 0, "%lld", coefficients[i])+1; // for the coefficient
                }else{
                    //printf("%lldx^%lld",coefficients[i],degree-i);
                    char_count += snprintf(NULL, 0, "%lld", coefficients[i])+2 + snprintf(NULL, 0, "%lld", degree-i); // for the coefficient
                }
                
            }
            if(is_first==1){
                is_first=0;
            }
        }
    }
    
    //印出常數項
    if(coefficients[degree]>0){
        //printf("+");
        if(is_first==0){
            char_count += 1; // for "+"
        }
        //printf("%lld",coefficients[degree]);
        char_count += snprintf(NULL, 0, "%lld", coefficients[degree]); // for the coefficient
    }else if(coefficients[degree]<0){
        //printf("%lld",coefficients[degree]);
        char_count += snprintf(NULL, 0, "%lld", coefficients[degree]); // for the coefficient
    }
    return char_count;
    //printf("\n");
}

//計算兩個多項式的乘積
void calculate_product(long long  f_degree, long long* f_coefficients, long long g_degree, long long* g_coefficients, long long* product_coefficients) {
    for(int i = f_degree; i >=0; i--) {
        for(int j = g_degree; j >=0; j--) {
            
            product_coefficients[f_degree+g_degree-i-j] += f_coefficients[f_degree-i] * g_coefficients[g_degree-j];
            //printf("DEBUG: i=%d,j=%d, times=%lld\n",i,j,f_coefficients[f_degree-i] * g_coefficients[g_degree-j]);
        }
    }
}

//計算兩個多項式的和
void calculate_sum(long long f_degree, long long* f_coefficients, long long g_degree, long long* g_coefficients, long long* sum_coefficients) {
    long long max_degree = f_degree > g_degree ? f_degree : g_degree;

    for(int i = 0; i <= max_degree; i++) {
        if(i <= f_degree) {
            sum_coefficients[i] += f_coefficients[i];
        }
        if(i <= g_degree) {
            sum_coefficients[i] += g_coefficients[i];
        }
    }
}

//計算兩個多項式的差
void caculate_difference(long long f_degree, long long* f_coefficients, long long g_degree, long long* g_coefficients, long long* difference_coefficients) {
    long long max_degree = f_degree > g_degree ? f_degree : g_degree;

    for(int i = 0; i <= max_degree; i++) {
        if(i <= f_degree) {
            difference_coefficients[i] += f_coefficients[i];
        }
        if(i <= g_degree) {
            difference_coefficients[i] -= g_coefficients[i];
        }
    }
}

//檢查輸入的degree是否合法
void check_degree(long long degree){
    if(degree>255){
        printf("degree is too large!\n");
        exit(0);
    }else if(degree<0){
        printf("degree is too small!\n");
        exit(0);
    }
}

//輾轉相除法
long long gcd(long long a, long long b) {
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

//化簡分數
void simplify_poly_fraction(long long numerator_degree, long long* numerator_coefficients, long long denominator_degree, long long* denominator_coefficients) {
    long long gcd_value = gcd(numerator_coefficients[numerator_degree], denominator_coefficients[denominator_degree]);

    for(long long i = numerator_degree - 1; i >= 0; i--) {
        gcd_value = gcd(gcd_value, numerator_coefficients[i]);
    }

    for(long long i = denominator_degree - 1; i >= 0; i--) {
        gcd_value = gcd(gcd_value, denominator_coefficients[i]);
    }

    for(long long i = 0; i <= numerator_degree; i++) {
        numerator_coefficients[i] /= gcd_value;
    }

    for(long long i = 0; i <= denominator_degree; i++) {
        denominator_coefficients[i] /= gcd_value;
    }
}

//檢查輸入的係數是否合法
void check_coefficients_element(long long coefficients_element){
    if(coefficients_element>2147483647){
        printf("coefficient is too large!\n");
        exit(0);
    }else if(coefficients_element<-2147483648){
        printf("coefficient is too small!\n");
        exit(0);
    }
}

//DEBUG:印出f和g的一次微分
void DEBUG_print_derivative(){
    printf("f'(x): ");
    print_poly(f_derivative_degree,f_derivative_coefficients);
    printf("g'(x): ");
    print_poly(g_derivative_degree,g_derivative_coefficients);
}

//找出多項式的最小次數
long long find_min_degree(long long degree, long long* coefficients) {
    long long min_degree = degree;

    for(int i = 0; i <= degree; i++) {
        if(coefficients[i] != 0 && degree-i < min_degree) {
            min_degree = degree-i;
        }
    }

    return min_degree;
}


int main(){
    printf("Please enter f(x) degree: ");
    scanf("%lld",&f_degree);
    check_degree(f_degree);

    printf("Please enter f(x) coefficient: ");
    for(int i=0;i<=f_degree;i++){
        scanf("%lld",&f_coefficients[i]);
        if(i==0&&f_coefficients[i]==0){
            printf("The first coefficient cannot be zero.\n");
            exit(0);
        }
        check_coefficients_element(f_coefficients[i]);
    }

    printf("Please enter g(x) degree: ");
    scanf("%lld",&g_degree);
    check_degree(g_degree);

    printf("Please enter g(x) coefficient: ");
    for(int i=0;i<=g_degree;i++){
        scanf("%lld",&g_coefficients[i]);
        if(i==0&&g_coefficients[i]==0){
            printf("The first coefficient cannot be zero.\n");
            exit(0);
        }
        check_coefficients_element(g_coefficients[i]);
    }
    
    f_derivative_degree=f_degree-1;
    g_derivative_degree=g_degree-1;
    f_times_gp_degree=f_degree+g_derivative_degree;
    fp_times_g_degree=f_derivative_degree+g_degree;
    d_f_times_g_degree=f_times_gp_degree > fp_times_g_degree ? f_times_gp_degree : fp_times_g_degree;
    d_f_on_g_numerator_degree=f_times_gp_degree > fp_times_g_degree ? f_times_gp_degree : fp_times_g_degree;
    d_f_on_g_denominator_degree=g_degree+g_degree;


    calculate_derivative(f_degree,f_coefficients,f_derivative_coefficients);
    calculate_derivative(g_degree,g_coefficients,g_derivative_coefficients);

    printf("f(x): ");
    print_poly(f_degree,f_coefficients);

    printf("g(x): ");
    print_poly(g_degree,g_coefficients);


    //DEBUG_print_derivative();

    calculate_product(f_degree,f_coefficients,g_derivative_degree,g_derivative_coefficients,f_times_gp_coefficients);
    calculate_product(f_derivative_degree, f_derivative_coefficients, g_degree, g_coefficients, fp_times_g_coefficients);

    calculate_sum(f_times_gp_degree,f_times_gp_coefficients,fp_times_g_degree,fp_times_g_coefficients,d_f_times_g_coefficients);

    //print_poly(f_times_gp_degree,f_times_gp_coefficients);
    //print_poly(fp_times_g_degree,fp_times_g_coefficients); 
    printf("(f(x)g(x))': ");
    print_poly(d_f_times_g_degree,d_f_times_g_coefficients);
    caculate_difference(fp_times_g_degree,fp_times_g_coefficients,f_times_gp_degree,f_times_gp_coefficients,d_f_on_g_numerator_coefficients);
    calculate_product(g_degree,g_coefficients,g_degree,g_coefficients,d_f_on_g_denominator_coefficients);
    simplify_poly_fraction(d_f_on_g_numerator_degree,d_f_on_g_numerator_coefficients,d_f_on_g_denominator_degree,d_f_on_g_denominator_coefficients);
    //printf("charater count: %lld\n",print_poly_count(d_f_times_g_degree,d_f_times_g_coefficients));

    long long line_length;
    long long x_reduce=0;
    long long numerator_min_degree = find_min_degree(d_f_on_g_numerator_degree, d_f_on_g_numerator_coefficients);
    long long denominator_min_degree = find_min_degree(d_f_on_g_denominator_degree, d_f_on_g_denominator_coefficients);
    
    if(numerator_min_degree > denominator_min_degree) {
        x_reduce = denominator_min_degree;
    }else if(numerator_min_degree < denominator_min_degree){
        x_reduce = numerator_min_degree;
    }
    ans_d_f_on_g_numerator_degree = d_f_on_g_numerator_degree - x_reduce;
    ans_d_f_on_g_denominator_degree = d_f_on_g_denominator_degree - x_reduce;
    // long long ans_d_f_on_g_numerator_coefficients[5000];
    // long long ans_d_f_on_g_denominator_coefficients[5000];

    // for(int i = 0; i <= ans_d_f_on_g_numerator_degree; i++) {
    //     ans_d_f_on_g_numerator_coefficients[i] = d_f_on_g_numerator_coefficients[i + x_reduce];
    // }
    // for(int i = 0; i <= ans_d_f_on_g_denominator_degree; i++) {
    //     ans_d_f_on_g_denominator_coefficients[i] = d_f_on_g_denominator_coefficients[i + x_reduce];
    // }

    //printf("DEBUG: x_reduce=%lld\n",x_reduce);


    printf(" f(x)    ");
    print_poly(ans_d_f_on_g_numerator_degree,d_f_on_g_numerator_coefficients);
    printf("(----)': ");
    
    
    if(print_poly_count(ans_d_f_on_g_denominator_degree,d_f_on_g_denominator_coefficients)>print_poly_count(ans_d_f_on_g_numerator_degree,d_f_on_g_numerator_coefficients)){
        line_length=print_poly_count(ans_d_f_on_g_denominator_degree,d_f_on_g_denominator_coefficients);
    }else{
        line_length=print_poly_count(ans_d_f_on_g_numerator_degree,d_f_on_g_numerator_coefficients);
    }
    //printf("DEBUG: line_length=%lld\n",print_poly_count(ans_d_f_on_g_denominator_degree,d_f_on_g_denominator_coefficients));
    //printf("DEBUG: line_length=%lld\n",print_poly_count(ans_d_f_on_g_numerator_degree,d_f_on_g_numerator_coefficients));

    for(int i=0;i<line_length;i++){
        printf("-");
    }
    printf("\n g(x)    ");
    print_poly(ans_d_f_on_g_denominator_degree,d_f_on_g_denominator_coefficients);
    printf("\n");



}