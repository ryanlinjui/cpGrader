#include <stdio.h>
#include "mysort.h"
int main(){
    int a[10] = {1, 2, 3, 4, 5, 6, 7, 9, 8, 10};
    myprint(a, 10);
    mysort(a, 10);
    myprint(a, 10);
    return 0;
}