/*Seven-pair(七對子)*/
long long pair_count=0;
for(long long i=1;i<=34;i++){
    if(each_tile_count[i]==2){
        pair_count++;
    }
}
if(pair_count==7){
    printf("The Score is...\n    Seven-pair\nTotal: 2 Han");
    exit(0);
}
/*Thirteen orphans(國士無雙)*/
long long orphans_count=0;
for(long long i=1;i<=34;i++){
    if(each_tile_count[i]==1){
        orphans_count++;
    }
}
if(orphans_count==13){
    printf("The Score is...\n    Thirteen orphans\nTotal: 13 Han");
    exit(0);
}