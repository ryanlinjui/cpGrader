#include <stdint.h>

#define STUDENT_NUMBER (11) // Of course , the number may not be 100.
#define CHINESE (0)
#define ENGLISH (1)
#define MATH_A (2)
#define MATH_B (3)
#define SOCIAL (4)
#define SCIENCE (5)

int32_t score[][6]={{10,8,2,3,4,1},
{14,8,15,5,4,4},
{4,2,6,14,6,8},
{6,11,8,0,8,8},
{5,6,7,13,14,9},
{13,9,9,13,10,11},
{8,12,3,5,4,13},
{6,10,7,6,1,3},
{7,10,3,10,11,9},
{7,4,1,8,12,15},
{4,8,9,12,0,1},
};