#include <stdio.h>
#include <stdint.h>

int main(){
	int32_t i=0;
	int32_t meld[14];
	int32_t group1=0;
	int32_t group2=0;
	int32_t group3=0;
	int32_t group4=0;
	int32_t pair1=0;
	int32_t pair2=0;
	int32_t tile=0;
	int32_t wind1=0;
	int32_t wind2=0;
	int32_t han=0;
	printf("Please input meld: ");
	while (i<14 && scanf("%d", &meld[i]) == 1 && meld[i] != 0){
        	i++;
	}
	if (i<14){
		printf("Is open group(1: YES 0: NO): ");
		scanf("%d", &group1);
		if (group1<0 || group1>1){
			printf("wrong input\n");
			return 0;
		}
	}
	printf("Please input meld: ");
	while (i<14 && scanf("%d", &meld[i]) == 1 && meld[i] != 0){ 
		i++;
	}
	if (i<14){
		printf("Is open group(1: YES 0: NO): ");
		scanf("%d", &group2);
		if (group2<0 || group2>1){
			printf("wrong input\n");
			return 0;
		}
	}
	printf("Please input meld: ");
	while (i<14 && scanf("%d", &meld[i]) == 1 && meld[i] != 0){
		i++;
	}
	if (i<14){
		printf("Is open group(1: YES 0: NO): ");
		scanf("%d", &group3);
		if (group3<0 || group3>1){
			printf("wrong input\n");
			return 0;
		}
	}
	printf("Please input meld: ");
	while (i<14 && scanf("%d", &meld[i]) == 1 && meld[i] != 0){
		i++;
	}
	if (i<14){
		printf("Is open group(1: YES 0: NO): ");
		scanf("%d", &group4);
		if (group4<0 || group4>1){
			printf("wrong input\n");
			return 0;
		}
	}
	printf("Please input pair: ");
	scanf("%d %d", &pair1, &pair2);
	printf("Please input winning tile: ");
	scanf("%d", &tile);
	printf("Player's wind(0:E 1:S 2:W 3:N): ");
	scanf("%d", &wind1);
	if (wind1<0 || wind1>3){
		printf("wrong input\n");
		return 0;
	}
	printf("Prevailing wind(0:E 1:S 2:W 3:N): ");
	scanf("%d", &wind2);
	if (wind2<0 || wind2>3){
		printf("wrong input\n");
		return 0;
	}
	printf("\n");
	printf("The score is...\n");
	printf("Total: %d Han\n", han);
}
