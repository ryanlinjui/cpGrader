#include <stdio.h>
#include <stdint.h>

void mysort (int32_t array[], int32_t size);
void myprint (int32_t array[], int32_t size);

void mysort (int32_t array[], int32_t size){
	//sort even and odd
	for (int32_t j = 0; j < size; j++){
		for (int32_t i = 0; i < size; i++){
			if (array[i] % 2 == 1 && array[i+1] % 2 == 0 && i+1 < size){
				int32_t temp = 0;
				temp = array[i];
				array[i] = array[i+1];
				array[i+1] = temp;
			}
		}
	}
	for (int32_t j = 0; j < size; j++){
		for (int32_t i = 0; i < size; i++){
			//ascending odd
			if (array[i] % 2 == 1 && array[i] > array[i+1] && i+1 < size && array[i+1] % 2 == 1){
				int32_t temp = 0;
				temp = array[i];
				array[i] = array[i+1];
				array[i+1] = temp;
			}
			//descending even
			if (array[i] % 2 == 0 && array[i] < array[i+1] && i+1 < size && array[i+1] % 2 == 0){
				int32_t temp = 0;
				temp = array[i+1];
				array[i+1] = array[i];
				array[i] = temp;
			}
		}
	}
}

void myprint(int32_t array[], int32_t size){
	for (int32_t i = 0; i < size; i++){
		printf("%d ", array[i]);
	}
	printf("\n");
}
