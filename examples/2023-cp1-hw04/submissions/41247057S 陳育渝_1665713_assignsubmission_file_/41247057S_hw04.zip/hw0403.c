#include <stdio.h>
#include <stdint.h>
#include "gsat.h"

void change (int32_t sub[STUDENT_NUMBER]);
void test (int32_t array[STUDENT_NUMBER]);

void change (int32_t sub[STUDENT_NUMBER]){
	for (int32_t i = 0; i < STUDENT_NUMBER; i++){
		for (int32_t j = 0; j < STUDENT_NUMBER; j++){
			if (sub[j] > sub[j+1] && j+1 < STUDENT_NUMBER){
				int32_t temp = sub[j];
				sub[j] = sub[j+1];
				sub[j+1] = temp;
			}
		}
	}
}

void test (int32_t array[STUDENT_NUMBER]){
	for (int32_t i = 0; i < STUDENT_NUMBER; i++){
		printf("%d ", array[i]);
	}
	printf("\n");
}

int main(){

	int32_t top12 = STUDENT_NUMBER * 0.88;
	int32_t top25 = STUDENT_NUMBER * 0.75;
	int32_t top50 = STUDENT_NUMBER * 0.5;
	int32_t top75 = STUDENT_NUMBER * 0.25;
	int32_t top88 = STUDENT_NUMBER * 0.12;
	//printf("%d %d %d %d %d\n", top12, top25, top50, top75, top88);
	
	//chinese
	int32_t CH[STUDENT_NUMBER] = {0};
	for (int32_t i = 0; i < STUDENT_NUMBER; i++){
		CH[i] = score[i][CHINESE];
	}
	change(CH);
	//test(CH);

	//english
	int32_t EN[STUDENT_NUMBER] = {0};
	for (int32_t i = 0; i < STUDENT_NUMBER; i++){
		EN[i] = score[i][ENGLISH];
	}
	change(EN);
	//test(EN);

	//math A
	int32_t MA[STUDENT_NUMBER] = {0};
	for (int32_t i = 0; i < STUDENT_NUMBER; i++){
		MA[i] = score[i][MATH_A];
	}
	change(MA);
	//test(MA);

	//math B
	int32_t MB[STUDENT_NUMBER] = {0};
	for (int32_t i = 0; i < STUDENT_NUMBER; i++){
		MB[i] = score[i][MATH_B];
	}
	change(MB);
	//test(MB);

	//social
	int32_t SO[STUDENT_NUMBER] = {0};
	for (int32_t i = 0; i < STUDENT_NUMBER; i++){
		SO[i] = score[i][SOCIAL];
	}
	change(SO);
	//test(SO);

	//science
	int32_t SC[STUDENT_NUMBER] = {0};
	for (int32_t i = 0; i < STUDENT_NUMBER; i++){
		SC[i] = score[i][SCIENCE];
	}
	change(SC);
	//test(SC);

	printf("        CHINESE | ENGLISH | MATH_A | MATH_B | SOCIAL | SCIENCE\n");
	printf("TOP 12%%    ");
	printf("%2d %9d %8d %8d %8d %8d\n", CH[top12], EN[top12], MA[top12], MB[top12], SO[top12], SC[top12]);
	printf("TOP 25%%    ");
	printf("%2d %9d %8d %8d %8d %8d\n", CH[top25], EN[top25], MA[top25], MB[top25], SO[top25], SC[top25]);
	printf("TOP 50%%    ");
	printf("%2d %9d %8d %8d %8d %8d\n", CH[top50], EN[top50], MA[top50], MB[top50], SO[top50], SC[top50]);
	printf("TOP 75%%    ");
	printf("%2d %9d %8d %8d %8d %8d\n", CH[top75], EN[top75], MA[top75], MB[top75], SO[top75], SC[top75]);
	printf("TOP 88%%    ");
	printf("%2d %9d %8d %8d %8d %8d\n", CH[top88], EN[top88], MA[top88], MB[top88], SO[top88], SC[top88]);
}
