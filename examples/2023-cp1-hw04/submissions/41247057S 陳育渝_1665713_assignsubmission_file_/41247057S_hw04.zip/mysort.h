#include <stdio.h>
#include <stdint.h>

void mysort (int32_t array[], int32_t size);
void myprint (int32_t array[], int32_t size);
