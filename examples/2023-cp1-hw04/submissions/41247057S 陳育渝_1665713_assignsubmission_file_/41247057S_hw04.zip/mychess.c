#include <stdio.h>
#include <stdint.h>

static int32_t RETURN=0;
static int32_t BGI=0;
static int32_t BGJ=0;
static int32_t RHI1=0;
static int32_t RHJ1=0;
static int32_t RHI2=0;
static int32_t RHJ2=0;
static int32_t RCHI1=0;
static int32_t RCHJ1=0;
static int32_t RCHI2=0;
static int32_t RCHJ2=0;
static int32_t RCAI1=0;
static int32_t RCAJ1=0;
static int32_t RCAI2=0;
static int32_t RCAJ2=0;
static int32_t soldier[5][2]={{0}, {0}};

int32_t checkhorse(int32_t horse[10][9], int32_t i, int32_t j, int32_t n);
int32_t checkchariot(int32_t chariot[10][9], int32_t i, int32_t j, int32_t n);
int32_t checkcannon(int32_t cannon[10][9], int32_t i, int32_t j, int32_t n);
int32_t checksoldier(int32_t i, int32_t j, int32_t n);
int32_t checkmate(int32_t board[10][9]);

int32_t checkhorse(int32_t horse[10][9], int32_t i, int32_t j, int32_t n){
	if (i+2 == BGI && j+1 == BGJ && horse[i+1][j]==0 && ((horse[i][j]>=11 && horse[i][j]<=17) || horse[i][j]==0)){
		RETURN++;
		if (n==1){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI1, RHJ1, i, j);
			return 0;
		}
		else if (n==2){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI2, RHJ2, i, j);
			return 0;
		}
	}
	else if (i-2 == BGI && j+1 == BGJ && horse[i-1][j]==0 && ((horse[i][j]>=11 && horse[i][j]<=17) || horse[i][j]==0)){
		RETURN++;
		if (n==1){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI1, RHJ1, i, j);
			return 0;
		}
		else if (n==2){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI2, RHJ2, i, j);
			return 0;
		}
	}
	else if (i+2 == BGI && j-1 == BGJ && horse[i+1][j]==0 && ((horse[i][j]>=11 && horse[i][j]<=17) || horse[i][j]==0)){
		RETURN++;
		if (n==1){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI1, RHJ1, i, j);
			return 0;
		}
		else if (n==2){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI2, RHJ2, i, j);
			return 0;
		}
	}
	else if (i-2 == BGI && j-1 == BGJ && horse[i-1][j]==0 && ((horse[i][j]>=11 && horse[i][j]<=17) || horse[i][j]==0)){
		RETURN++;
		if (n==1){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI1, RHJ1, i, j);
			return 0;
		}
		else if (n==2){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI2, RHJ2, i, j);
			return 0;
		}
	}
	else if (i+1 == BGI && j+2 == BGJ && horse[i][j+1]==0 && ((horse[i][j]>=11 && horse[i][j]<=17) || horse[i][j]==0)){
		RETURN++;
		if (n==1){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI1, RHJ1, i, j);
			return 0;
		}
		else if (n==2){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI2, RHJ2, i, j);
			return 0;
		}
	}
	else if (i-1 == BGI && j+2 == BGJ && horse[i][j+1]==0 && ((horse[i][j]>=11 && horse[i][j]<=17) || horse[i][j]==0)){
		RETURN++;
		if (n==1){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI1, RHJ1, i, j);
			return 0;
		}
		else if (n==2){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI2, RHJ2, i, j);
			return 0;
		}
	}
	else if (i+1 == BGI && j-2 == BGJ && horse[i][j-1]==0 && ((horse[i][j]>=11 && horse[i][j]<=17) || horse[i][j]==0)){
		RETURN++;
		if (n==1){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI1, RHJ1, i, j);
			return 0;
		}
		else if (n==2){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI2, RHJ2, i, j);
			return 0;
		}
	}
	else if (i-1 == BGI && j-2 == BGJ && horse[i][j-1]==0 && ((horse[i][j]>=11 && horse[i][j]<=17) || horse[i][j]==0)){
		if (n==1){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI1, RHJ1, i, j);
			return 0;
		}
		else if (n==2){
			printf("%d) Move Horse from (%d,%d) to (%d,%d)\n", RETURN, RHI2, RHJ2, i, j);
			return 0;
		}
	}
	else{
		return 0;
	}
	return 0;
}

int32_t checkchariot(int32_t chariot[10][9], int32_t i, int32_t j, int32_t n){
	int32_t count=0;
	if (i==BGI && j!=BGJ){
		if (j<BGJ){
			for (int32_t a=j+1; a<BGJ; a++){
				if (chariot[i][a]==0){
					count++;
				}
			}
		}
		else if (BGJ<j){
			for (int32_t a=BGJ+1; a<j; a++){
				if (chariot[i][a]==0){
					count++;
				}
			}
		}
		int32_t dis=BGJ-j;
                if (dis<0){
                        dis = -dis;
                }
                if (count==dis-1 && ((chariot[i][j]>=11 && chariot[i][j]) || chariot[i][j]==0)){
			RETURN++;
			if (n==1){
				printf("%d) Move Chariot from (%d,%d) to (%d,%d)\n", RETURN, RCHI1, RCHJ1, i, j);
			}
			else if (n==2){
				printf("%d) Move Chariot from (%d,%d) to (%d,%d)\n", RETURN, RCHI2, RCHJ2, i, j);
			}
		}
	}
	else if (i!=BGI && j==BGJ){
		count=0;
		if (i<BGI){
			for (int32_t a=i+1; a<BGI; a++){
				if (chariot[a][j]==0){
					count++;
				}
			}
		}
		else if (BGI<i){
			for (int32_t a=BGI+1; a<i; a++){
				if (chariot[a][j]==0){
					count++;
				}
			}
		}
		int32_t dis=BGI-i;
		if (dis<0){
			dis = -dis;
		}
		if (count==dis-1 && ((chariot[i][j]>=11 && chariot[i][j]) || chariot[i][j]==0)){
			RETURN++;
			if (n==1){
				printf("%d) Move Chariot from (%d,%d) to (%d,%d)\n", RETURN, RCHI1, RCHJ1, i, j);
			}
			else if (n==2){
				printf("%d) Move Chariot from (%d,%d) to (%d,%d)\n", RETURN, RCHI2, RCHJ2, i, j);
			}
		}
	}
	else{
		return 0;
	}
	return 0;
}

int32_t checkcannon(int32_t cannon[10][9], int32_t i, int32_t j, int32_t n){
	int32_t count=0;
	if (i==BGI && j!=BGJ){
		if (j<BGJ){
			for (int32_t a=j+1; a<BGJ; a++){
				if (cannon[i][a]!=0){
					count++;
				}
			}
		}
		else if (BGJ<j){
			for (int32_t a=BGJ+1; a<j; a++){
				if (cannon[i][a]!=0){
					count++;
				}
			}
		}
		if (count==1){
			RETURN++;
			if (n==1){
				printf("%d) Move Cannon from (%d,%d) to (%d,%d)\n", RETURN, RCAI1, RCAJ1, i, j);
			}
			else if (n==2){
				printf("%d) Move Chariot from (%d,%d) to (%d,%d)\n", RETURN, RCAI2, RCAJ2, i, j);
			}
		}
	}
	else if (i!=BGI && j==BGJ){
		count=0;
		if (i<BGI){
			for (int32_t a=i+1; a<BGI; a++){
				if (cannon[a][j]!=0){
					count++;
				}
			}
		}
		else if (BGI<i){
			for (int32_t a=BGI+1; a<i; a++){
				if (cannon[a][j]!=0){
					count++;
				}
			}
		}
		if (count==1){
			RETURN++;
			if (n==1){
				printf("%d) Move Cannon from (%d,%d) to (%d,%d)\n", RETURN, RCAI1, RCAJ1, i, j);
			}
			else if (n==2){
				printf("%d) Move Cannon from (%d,%d) to (%d,%d)\n", RETURN, RCAI2, RCAJ2, i, j);
			}
		}
	}
	else{
		return 0;
	}
	return 0;
}

int32_t checksoldier(int32_t i, int32_t j, int32_t n){
	if (i+1 == BGI && j == BGJ){
		RETURN++;
		printf("%d) Move Soldier from (%d,%d) to (%d,%d)\n", RETURN, soldier[n][0], soldier[n][1], i, j);
	}
	else if (i == BGI && j+1 == BGJ){
		RETURN++;
		printf("%d) Move Soldier from (%d,%d) to (%d,%d)\n", RETURN, soldier[n][0], soldier[n][1], i, j);
	}
	else if (i == BGI && j-1 == BGJ){
		RETURN++;
		printf("%d) Move Soldier from (%d,%d) to (%d,%d)\n", RETURN, soldier[n][0], soldier[n][1], i, j);
	}
	else{
		return 0;
	}
	return 0;
}

int32_t checkmate(int32_t board[10][9]){
	//check the board invalid or not
	//check black general
	int32_t RGI = 0;
	int32_t RGJ = 0;
	int32_t check[18] = {0};
	for (int32_t i=0; i<10; i++){
		for (int32_t j=0; j<9; j++){
			if (board[i][j]==11 && i>=7 && i<=9 && j>=3 && j<=5){ //black general
				BGI = i;
				BGJ = j;
				check[11]++;
			}
			if (board[i][j]==1 && i>=0 && i<=2 && j>=3 && j<=5){ //red general
				RGI = i;
				RGJ = j;
				check[1]++;
			}
			if (board[i][j]==2 && i<=2 && j>=3 && j<=5){ //red advisor
				check[2]++;
			}
			if (board[i][j]==12 && i>=7 && j>=3 && j<=5){ //black advisor
				check[12]++;
			}
			if (board[i][j]==3 && i<=4 && i%2==0 && j%2==0){ //red elephant
				check[3]++;
			}
			if (board[i][j]==13 && i>=5 && i%2==1 && j%2==0){ //black elephant
				check[13]++;
			}
			if (board[i][j]==4){ //red horse
				check[4]++;
			}
			if (board[i][j]==14){ //black horse
				check[14]++;
			}
			if (board[i][j]==5){ //red chariot
				check[5]++;
			}
			if (board[i][j]==15){ //black chariot
				check[15]++;
			}
			if (board[i][j]==6){ //red cannon
				check[6]++;
			}
			if (board[i][j]==16){ //black cannon
				check[16]++;
			}
			if (board[i][j]==7 && (((i==3 || i==4) && j%2==0)|| i>=5)){ //red solider
				check[3]++;
			}
			if (board[i][j]==17 && (((i==5 || i==6) && j%2==0)|| i<=4)){ //black solider
				check[17]++;
			}
		}
	}
	if (check[1]!=1 || check[11]!=1){
		return -1;
	}
	if (check[7]<0 || check[7]>5 || check[17]<0 || check[17]>5){
		return -1;
	}
	for (int32_t i=2; i<7; i++){
		if (check[i]<0 || check[i]>2){
			return -1;
		}
	}
	for (int32_t i=12; i<17; i++){
		if (check[i]<0 || check[i]>2){
			return -1;
		}
	}

	//check red general
	int32_t count = 0;
	if (BGJ == RGJ+1 || BGJ == RGJ-1){
		for (int32_t i=RGI+1; i<BGI; i++){
			if (board[i][BGJ] == 0){
				count++;
			}
		}
	}
	if (count == BGI-RGI-1){
		RETURN++;
		if (BGJ == RGJ+1 && ((board[RGI][BGJ]>=11 && board[RGI][BGJ]<=17) || board[RGI][BGJ]==0)){
			printf("%d) Move General from (%d,%d) to (%d,%d)\n", RETURN, RGI, RGJ, RGI, RGJ+1);
		}
		else if (BGJ == RGJ-1 && ((board[RGI][BGJ]>=11 && board[RGI][BGJ]<=17) || board[RGI][BGJ]==0)){
			printf("%d) Move General from (%d,%d) to (%d,%d)\n", RETURN, RGI, RGJ, RGI, RGJ-1);
		}
	}

	//check horse
	for (int32_t i=0; i<10; i++){
		for (int32_t j=0; j<9; j++){
			if (board[i][j] == 4){
				RHI1=i;
				RHJ1=j;
				break;
			}
		}
		if (i==RHI1 && i!=0){
			break;
		}
	}
	for (int32_t i=0; i<10; i++){
		for (int32_t j=0; j<9; j++){
			if (board[i][j] == 4 && (i!=RHI1 || j!=RHJ1)){
				RHI2=i;
				RHJ2=j;
				break;
			}
		}
		if (i==RHI2 && i!=0){
			break;
		}
	}
	if (RHI1!=0 || RHJ1!=0){
		if (board[RHI1+1][RHJ1]==0){
			checkhorse(board, RHI1+2, RHJ1+1, 1);
		}
		if (board[RHI1-1][RHJ1]==0){
			checkhorse(board, RHI1-2, RHJ1+1, 1);
		}
		if (board[RHI1+1][RHJ1]==0){
			checkhorse(board, RHI1+2, RHJ1-1, 1);
		}
		if (board[RHI1-1][RHJ1]==0){
			checkhorse(board, RHI1-2, RHJ1-1, 1);
		}
		if (board[RHI1][RHJ1+1]==0){
			checkhorse(board, RHI1+1, RHJ1+2, 1);
		}
		if (board[RHI1][RHJ1+1]==0){
			checkhorse(board, RHI1-1, RHJ1+2, 1);
		}
		if (board[RHI1][RHJ1-1]==0){
			checkhorse(board, RHI1+1, RHJ1-2, 1);
		}
		if (board[RHI1][RHJ1-1]==0){
			checkhorse(board, RHI1-1, RHJ1-2, 1);
		}
	}
	if (RHI2!=0 || RHJ2!=0){
		if (board[RHI2+1][RHJ2]==0){
			checkhorse(board, RHI2+2, RHJ2+1, 2);
		}
		if (board[RHI2-1][RHJ2]==0){
			checkhorse(board, RHI2-2, RHJ2+1, 2);
		}
		if (board[RHI2+1][RHJ2]==0){
			checkhorse(board, RHI2+2, RHJ2-1, 2);
		}
		if (board[RHI2-1][RHJ2]==0){
			checkhorse(board, RHI2-2, RHJ2-1, 2);
		}
		if (board[RHI2][RHJ2+1]==0){
			checkhorse(board ,RHI2+1, RHJ2+2, 2);
		}
		if (board[RHI2][RHJ2+1]==0){
			checkhorse(board, RHI2-1, RHJ2+2, 2);
		}
		if (board[RHI2][RHJ2-1]==0){
			checkhorse(board, RHI2+1, RHJ2-2, 2);
		}
		if (board[RHI2][RHJ2-1]==0){
			checkhorse(board, RHI2-1, RHJ2-2, 2);
		}
	}

	//check chariot
	for (int32_t i=0; i<10; i++){
		for (int32_t j=0; j<9; j++){
			if (board[i][j]==5){
				RCHI1=i;
				RCHJ1=j;
				break;
			}
		}
		if (i==RCHI1 && i!=0){
			break;
		}
	}

	for (int32_t i=0; i<10; i++){
		for (int32_t j=0; j<9; j++){
			if (board[i][j]==5 && (i!=RCHI1 || j!=RCHJ1)){
				RCHI2=i;
				RCHJ2=j;
				break;
			}
		}
		if (i==RCHI2 && i!=0){
			break;
		}
	}
	count = 0;
	if (RCHI1!=0 || RCHJ1!=0){
		if (RCHI1<BGI){
			for (int32_t i=RCHI1+1; i<BGI; i++){
				if (board[i][RCHJ1]==0){
					count++;
				}
			}
			if (count==BGI-RCHI1-1){
				checkchariot(board, BGI, RCHJ1, 1);
			}
		}
		else if (BGI<RCHI1){
			for (int32_t i=BGI+1; i<RCHI1; i++){
				if (board[i][RCHJ1]==0){
					count++;
				}
			}
			if (count==RCHI1-BGI-1){
				checkchariot(board, BGI, RCHJ1, 1);
			}
		}
		count=0;
		if (RCHJ1<BGJ){
			for (int32_t j=RCHJ1+1; j<BGJ; j++){
				if (board[RCHI1][j]==0){
					count++;
				}
			}
			if (count==BGJ-RCHJ1-1){
				checkchariot(board, RCHI1, BGJ, 1);
			}
		}
		else if (BGJ<RCHJ1){
			for (int32_t j=BGJ+1; j<RCHJ1; j++){
				if (board[RCHI1][j]==0){
					count++;
				}
			}
			if (count==RCHJ1-BGJ-1){
				checkchariot(board, RCHI1, BGJ, 1);
			}
		}
	}

	if (RCHI2!=0 || RCHJ2!=0){
                if (RCHI2<BGI){
                        for (int32_t i=RCHI2+1; i<BGI; i++){
                                if (board[i][RCHJ2]==0){
                                        count++;
                                }
                        }
                        if (count==BGI-RCHI2-1){
                                checkchariot(board, BGI, RCHJ2, 2);
                        }
                }
                else if (BGI<RCHI2){
                        for (int32_t i=BGI+1; i<RCHI2; i++){
                                if (board[i][RCHJ2]==0){
                                        count++;
                                }
                        }
                        if (count==RCHI2-BGI-1){
                                checkchariot(board, BGI, RCHJ2, 2);
                        }
                }
		count=0;
                if (RCHJ2<BGJ){
                        for (int32_t j=RCHJ2+1; j<BGJ; j++){
                                if (board[RCHI2][j]==0){
                                        count++;
                                }
                        }
                        if (count==BGJ-RCHJ2-1){
                                checkchariot(board, RCHI2, BGJ, 2);
                        }
                }
                else if (BGJ<RCHJ2){
                        for (int32_t j=BGJ+1; j<RCHJ2; j++){
                                if (board[RCHI2][j]==0){
                                        count++;
                                }
                        }
                        if (count==RCHJ2-BGJ-1){
                                checkchariot(board, RCHI2, BGJ, 2);
                        }
                }
        }
	
	//check cannon
	int32_t tempI=0;
	int32_t tempJ=0;
	for (int32_t i=0; i<10; i++){
		for (int32_t j=0; j<9; j++){
			if (board[i][j]==6){
				RCAI1=i;
				RCAJ1=j;
				break;
			}
		}
		if (i==RCAI1 && i!=0){
			break;
		}
	}
	for (int32_t i=0; i<10; i++){
		for (int32_t j=0; j<9; j++){
			if (board[i][j]==6 && (i!=RCAI1 || j!=RCAJ1)){
				RCAI2=i;
				RCAJ2=j;
				break;
			}
		}
		if (i==RCAI2 && i!=0){
			break;
		}
	}
	count=0;
	if (RCAI1!=0 || RCAJ1!=0){
		if (RCAI1<BGI){
			for (int32_t i=RCAI1+1; i<=BGI; i++){
				if (board[i][RCAJ1]==0){
					count++;
				}
				else if (board[i][RCAJ1]!=0){
					tempI=i;
					tempJ=RCAJ1;
					break;
				}
			}
			if (count==BGI-RCAI1){
				checkcannon(board, BGI, RCAJ1, 1);
			}
			count=0;
			for (int32_t i=tempI+1; i<BGI; i++){
				if (board[i][RCAJ1]==0){
					count++;
				}
			}
			if (count==BGI-tempI-1 && ((board[BGI][RCAJ1]>=11 && board[BGI][RCAJ1]<=17) || board[BGI][RCAJ1]==0)){
				checkcannon(board, BGI, RCAJ1, 1);
			}	
		}
		else if (BGI<RCAI1){
			for (int32_t i=RCAI1-1; i>=BGI; i--){
				if (board[i][RCAJ1]==0){
					count++;
				}
				else if (board[i][RCAJ1]!=0){
					tempI=i;
					tempJ=RCAJ1;
					break;
				}
			}
			if (count==RCAI1-BGI){
				checkcannon(board, BGI, RCAJ1, 1);
			}
			count=0;
			for (int32_t i=tempI-1; i>BGI; i--){
				if (board[i][RCAJ1]==0){
					count++;
				}
			}
			if (count==tempI-BGI-1 && ((board[BGI][RCAJ1]>=11 && board[BGI][RCAJ1]<=17) || board[BGI][RCAJ1]==0)){
				checkcannon(board, BGI, RCAJ1, 1);
			}
		}
		count=0;
		if (RCAJ1<BGJ){
			for (int32_t j=RCAJ1+1; j<=BGJ; j++){
				if (board[RCAI1][j]==0){
					count++;
				}
				else if (board[RCAI1][j]!=0){
					tempI=RCAI1;
					tempJ=j;
					break;
				}
			}
			if (count==BGJ-RCAJ1){
				checkcannon(board, RCAI1, BGJ, 1);
			}
			count=0;
			for (int32_t j=tempJ+1; j<BGJ; j++){
				if (board[RCAI1][j]==0){
					count++;
				}
			}
			if (count==BGJ-tempJ-1 && ((board[RCAI1][BGJ]>=11 && board[RCAI1][BGJ]<=17) || board[RCAI1][BGJ]==0)){
				checkcannon(board, RCAI1, BGJ, 1);
			}
		}
		else if (BGJ<RCAJ1){
			for (int32_t j=RCAJ1-1; j>=BGJ; j--){
				if (board[RCAI1][j]==0){
					count++;
				}
				else if (board[RCAI1][j]!=0){
					tempI=RCAI1;
					tempJ=j;
					break;
				}
			}
			if (count==RCAJ1-BGJ){
				checkcannon(board, RCAI1, BGJ, 1);
			}
			count=0;
			for (int32_t j=tempJ-1; j>BGJ; j--){
				if (board[RCAI1][j]==0){
					count++;
				}
			}
			if (count==tempJ-BGJ-1 && ((board[RCAI1][BGJ]>=11 && board[RCAI1][BGJ]<=17) || board[RCAI1][BGJ]==0)){
				checkcannon(board, RCAI1, BGJ, 1);
			}
		}
	}

	count=0;
        if (RCAI2!=0 || RCAJ2!=0){
                if (RCAI2<BGI){
                        for (int32_t i=RCAI2+1; i<=BGI; i++){
                                if (board[i][RCAJ2]==0){
                                        count++;
                                }
				else if (board[i][RCAJ2]!=0){
					tempI=i;
					tempJ=RCAJ2;
					break;
				}
                        }
                        if (count==BGI-RCAI2){
                                checkcannon(board, BGI, RCAJ2, 1);
                        }
			count=0;
			for (int32_t i=tempI+1; i<BGI; i++){
				if (board[i][RCAJ2]==0){
					count++;
				}
			}
			if (count==BGI-tempI-1 && ((board[BGI][RCAJ2]>=11 && board[BGI][RCAJ2]>=17) || board[BGI][RCAJ2]==0)){
				checkcannon(board, BGI, RCAJ2, 2);
			}
                }
                else if (BGI<RCAI2){
                        for (int32_t i=RCAI2-1; i>=BGI; i--){
                                if (board[i][RCAJ2]==0){
                                        count++;
                                }
				else if (board[i][RCAJ2]!=0){
					tempI=i;
					tempJ=RCAJ2;
					break;
				}
                        }
                        if (count==RCAI2-BGI){
                                checkcannon(board, BGI, RCAJ2, 1);
                        }
			count=0;
			for (int32_t i=tempI-1; i>BGI; i--){
				if (board[i][RCAJ2]==0){
					count++;
				}
			}
			if (count==tempI-BGI-1 && ((board[BGI][RCAJ2]>=11 && board[BGI][RCAJ2]>=17) || board[BGI][RCAJ2]==0)){
				checkcannon(board, BGI, RCAJ2, 2);
			}
                }
		count=0;
		if (RCAJ2<BGJ){
                        for (int32_t j=RCAJ2+1; j<=BGJ; j++){
                                if (board[RCAI2][j]==0){
                                        count++;
                                }
				else if (board[RCAI2][j]!=0){
					tempI=RCAI2;
					tempJ=j;
					break;
				}
                        }
                        if (count==BGJ-RCAJ2){
                                checkcannon(board, RCAI2, BGJ, 2);
                        }
			count=0;
			for (int32_t j=tempJ+1; j<BGJ; j++){
				if (board[RCAI2][j]==0){
					count++;
				}
			}
			if (count==BGJ-tempJ-1 && ((board[BGI][RCAJ1]>=11 && board[BGI][RCAJ1]>=17) || board[BGI][RCAJ1]==0)){
				checkcannon(board, RCAI2, BGJ, 2);
			}
                }
                else if (BGJ<RCAJ2){
                        for (int32_t j=RCAJ2-1; j>=BGJ; j--){
                                if (board[RCAI2][j]==0){
                                        count++;
                                }
				else if (board[RCAI2][j]!=0){
					tempI=RCAI2;
					tempJ=j;
					break;
				}
                        }
                        if (count==RCAJ2-BGJ){
                                checkcannon(board, RCAI2, BGJ, 2);
                        }
			count=0;
			for (int32_t j=tempJ-1; j>BGJ; j--){
				if (board[RCAI2][j]==0){
					count++;
				}
			}
			if (count==tempJ-BGJ-1 && ((board[BGI][RCAJ2]>=11 && board[BGI][RCAJ2]>=17) || board[BGI][RCAJ2]==0)){
				checkcannon(board, RCAI2, BGJ, 2);
			}
                }
        }

	//check soldier
	int32_t k=0;
	for (int32_t i=0; i<10; i++){
		for (int32_t j=0; j<9; j++){
			if (board[i][j] == 7 && i>=5){
				soldier[k][0] = i;
				soldier[k][1] = j;
				k++;
			}
		}
	}
	for (int32_t i=0; i<5; i++){
		if (soldier[i][0] != 0 || soldier[i][1] != 0){
			if ((board[soldier[i][0]+1][soldier[i][1]]>=11 && board[soldier[i][0]+1][soldier[i][1]]>=17) || board[soldier[i][0]+1][soldier[i][1]]==0){
				checksoldier(soldier[i][0]+1, soldier[i][1], i);
			}
			if ((board[soldier[i][0]][soldier[i][1]+1]>=11 && board[soldier[i][0]][soldier[i][1]+1]>=17) || board[soldier[i][0]][soldier[i][1]+1]==0){
				checksoldier(soldier[i][0], soldier[i][1]+1, i);
			}
			if ((board[soldier[i][0]][soldier[i][1]-1]>=11 && board[soldier[i][0]][soldier[i][1]-1]>=17) || board[soldier[i][0]][soldier[i][1]-1]==0){
				checksoldier(soldier[i][0], soldier[i][1]-1, i);
			}
		}
	}

	//return
	if (RETURN>0){
		return RETURN;
	}
	else{
		return -1;
	}
}
