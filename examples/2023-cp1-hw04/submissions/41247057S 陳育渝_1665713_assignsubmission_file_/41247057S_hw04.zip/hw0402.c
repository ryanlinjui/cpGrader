#include <stdio.h>
#include <stdint.h>

void print (int64_t coefficients[], int64_t degree);
void derivative (int64_t coefficients[], int64_t degree);
int64_t count (int64_t coefficients[], int64_t degree);

void print (int64_t coefficients[], int64_t degree){
	if (degree > 1){
		for (int64_t i = degree; i > 1; i--){
                	if (coefficients[i] != 0){
                        	if (coefficients[i] != 1){
                                	printf("%lldx^%lld", coefficients[i], i);
                        	}
                        	else if (coefficients[i] == 1 || coefficients[i] == -1){
                                	printf("x^%lld", i);
                 	      	}
                        	for (int64_t j = i-1; j >= 0; j--){
                                	if (coefficients[j] > 0){
                                        	printf("+");
                                        	break;
                                	}
					else if (coefficients[j] < 0){
						break;
					}
                        	}
                	}
        	}
	}
	if (degree >= 1){
        	if (coefficients[1] != 0){
                	if (coefficients[1] == 1){
				if (degree > 1){
					printf("+x");
				}
				else{
					printf("x");
				}
			}
			else if (coefficients[1] == -1){
				if (degree > 1){
                        		printf("-x");
				}
				else{
					printf("x");
				}
                	}
                	else{
                        	printf("%lldx", coefficients[1]);
                	}
                	if (coefficients[0] > 0){
                        	printf("+");
                	}
        	}
	}
	if (degree >= 0){
        	if (coefficients[0] != 0){
                	printf("%lld\n", coefficients[0]);
 	       	}
        	else{
        	        printf("\n");
 	       	}
	}
	if (degree < 0){
		printf("0\n");
	}
}

void derivative (int64_t coefficients[], int64_t degree){
	int64_t temp[degree];
        for (int64_t i = degree; i >= 0; i--){
                temp[i] = coefficients[i];
        }
        for (int64_t i = degree, j = degree; j > 0; i--, j--){
                        coefficients[i-1] = temp[i] * j;
        }
}

int64_t count (int64_t coefficients[], int64_t degree){
	int64_t counts = 0;
	for (int64_t i = degree, temp = 0; i >= 0; i--){
                temp = i;
		if (coefficients[degree] < 0 && temp == degree){ //when the first coefficient < 0
                        counts++;
                }
                if (coefficients[i] != 0 && temp > 1){ //calculate'ax^b+' or 'ax^b-'
                        counts = counts + 3;
                        //printf("2 %lld %lld\n", coefficients[i], counts);
                }
                if (coefficients[i] != 0 && temp == 1){ //when degree == 1, only calculate 'x+' or 'x-'
                        counts = counts + 2;
                        //printf("3 %lld %lld\n", coefficients[i], counts);
                }
                if (coefficients[0] != 0 && temp == 0){ //plus one '+' to minus
                        counts++;
                }
		if (degree == 0 && coefficients[0] != 0){ //when degree only 0
			while(coefficients[0] != 0){
				coefficients[0] = coefficients[0] / 10;
				counts++;
			}
		}
                if (temp > 1 && coefficients[i] != 0){ //calculate degree
                        while (temp != 0){
                                temp = temp / 10;
                                counts++;
                        }
                        //printf("4 %lld %lld\n", coefficients[i], counts);
                }
                //when coefficient == 1 or -1, no need to print '1'
                if (coefficients[i] > 1 || coefficients[i] < -1){
                        while (coefficients[i] != 0){ //calculate coefficient
                                coefficients[i] = coefficients[i] / 10;
                                counts++;
				//printf("5 %lld %lld\n", coefficients[i], counts);
                        }
                }
		//but I still print 1 or -1 when degree == 0
		if (coefficients[0] == 1 && i == 0){
			counts++;
		}
		else if (coefficients[0] == -1 && i == 0){
			counts = counts+2;
		}
        }
	return counts;
}

int main(){
	int64_t fd = 0;
	int64_t gd = 0;
	printf("Please enter f(x) degree: ");
	scanf("%lld", &fd);
	if (fd < 0 || fd > 4294967296){
		printf("wrong input, please input again:)\n");
		return 0;
	}
	int64_t fc[fd+1];
	printf("Please enter f(x) coefficients: ");
	for (int64_t i = fd; i >= 0; i--){
		scanf("%lld", &fc[i]);
		if (fc[fd] == 0){
			printf("the first coefficient can't be zero!\n");
			return 0;
		}
	}
	for (int64_t i = 0; i <= fd; i++){
		if (fc[i] > 2147483647 || fc[i] < -2147483647){
			printf("out of range!!\n");
			return 0;
		}
	}
	char exceed_count_char[10000];
	int32_t exceed_count;
	scanf("%[^\n]%n",exceed_count_char,&exceed_count);
	if(exceed_count > 1){printf("Over Input!\n"); 
		return 0;
	}

	printf("Please enter g(x) degree: ");
	scanf("%lld", &gd);
	if (gd < 0 || gd > 4294967296){
		printf("wrong input, please input again:)\n");
		return 0;
	}
	int64_t gc[gd+1];
	printf("Please enter g(x) coefficients: ");
	for (int32_t i = gd; i >= 0; i--){
		scanf("%lld", &gc[i]);
		if (gc[gd] == 0){
			printf("the first coefficient can't be zero!\n");
			return 0;
		}
	}
	for (int64_t i = 0; i <= gd; i++){
		if (gc[i] > 2147483647 || gc[i] < -2147483647){
			printf("out of range!!\n");
			return 0;
		}
	}
	scanf("%[^\n]%n",exceed_count_char,&exceed_count);
	if(exceed_count > 1){
	printf("Over Input!\n");
return 0;}
	printf("f(x): ");
	print(fc, fd);
	printf("g(x): ");
	print(gc, gd);
	printf("(f(x)g(x))': ");
	int64_t fgd = fd + gd;
	int64_t fgc[fgd+1];
	for (int64_t i = fgd; i >= 0; i--){
		fgc[i] = 0;
	}
	//f(x) * g(x)
	for (int64_t i = fgd; i >= 0; i--){
		for (int64_t j = fd; j >= 0; j--){
			for (int64_t k = gd; k >= 0; k--){
				if (i == j + k){
					fgc[i] = fgc[i] + fc[j] * gc[k];
				}
			}
		}
	}
	derivative(fgc, fgd);
	print(fgc, fgd-1);
	printf(" f(x)    ");
	int64_t temp1[fd+1];
	for (int64_t i = fd; i >= 0; i--){
		temp1[i] = fc[i];
	}
	derivative(temp1, fd);
	fgd = fd + gd - 1;
	for (int64_t i = fgd; i >= 0; i--){
		fgc[i] = 0;
	}
	//f'(x) * g(x)
	for (int64_t i = fgd; i >= 0; i--){
                for (int64_t j = fd-1; j >= 0; j--){
                        for (int64_t k = gd; k >= 0; k--){
                                if (i == j + k){
                                        fgc[i] = fgc[i] + temp1[j] * gc[k];
                                }
                        }
                }
        }
	int64_t total[fgd+1];
	for (int64_t i = fgd; i >= 0; i--){
		total[i] = fgc[i];
	}
	int64_t temp2[gd+1];
	for (int64_t i = gd; i >= 0; i--){
		temp2[i] = gc[i];
	}
	derivative(temp2, gd);
	for (int64_t i = fgd; i >= 0; i--){
		fgc[i] = 0;
	}
	//f(x) * g'(x)
	for (int64_t i = fgd; i >= 0; i--){ 
                for (int64_t j = gd-1; j >= 0; j--){ 
                        for (int64_t k = fd; k >= 0; k--){
                                if (i == j + k){ 
                                        fgc[i] = fgc[i] + temp2[j] * fc[k];
                                }
                        }
                }
        }
	for (int64_t i = fgd; i >= 0; i--){
		total[i] = total[i] - fgc[i];
	}

	//if f'(x)g(x)-f(x)g'(x) = 0
	int64_t j = 0;
	for (int64_t i = fgd; i >= 0; i--){
		if (total[i] == 0){
			j++;
		}
	}
	if (j == fgd+1){
		printf("0\n");
	}
	else{
		print(total, fgd);
	}
	//g(x) * g(x)
	int64_t ggd = 2 * gd;
	int64_t ggc[ggd+1];
	for (int64_t i = ggd; i >= 0; i--){
		ggc[i] = 0;
	}
	for (int64_t i = ggd; i >= 0; i--){
                for (int64_t j = gd; j >= 0; j--){
                        for (int64_t k = gd; k >= 0; k--){
                                if (i == j + k){
                                        ggc[i] = ggc[i] + gc[j] * gc[k];
                                }
                        }
                }
        }
	int64_t countf = count(total, fgd) - 1;
	int64_t ggg[ggd+1];
	for (int64_t i = ggd; i >= 0; i--){
		ggg[i] = ggc[i];
	}
	int64_t countg = count(ggg, ggd) - 1;
	printf("(----)': ");
	if (countf > countg){
		for (int64_t i = 0; i < countf; i++){
			printf("-");
		}
		printf("\n");
	}
	else{
		for (int64_t i = 0; i < countg; i++){
			printf("-");
		}
		printf("\n");
	}
	printf(" g(x)    ");
	print(ggc, ggd);
}
