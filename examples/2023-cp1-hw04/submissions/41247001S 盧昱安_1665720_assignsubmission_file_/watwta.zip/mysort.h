#ifndef DICEROLLS_H
#define DICEROLLS_H
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
void mysort( int32_t array[], int32_t size );
void myprint( int32_t array[], int32_t size );
 #endif