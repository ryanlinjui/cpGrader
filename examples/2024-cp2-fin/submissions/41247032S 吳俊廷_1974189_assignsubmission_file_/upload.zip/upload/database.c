#include "database.h"

int32_t setup_table(const struct list_head *pLabelList) {

    return 0; // Success
}

int32_t add( struct list_head *pRecordList , sRecord *pRecord )
{
    return 0;
}

int32_t get_size( struct list_head *pRecordList ){
    return 0;
}

int32_t query( struct list_head *pResultList , struct list_head *pRecordList ,char *pCmd ){
    return 0;
}