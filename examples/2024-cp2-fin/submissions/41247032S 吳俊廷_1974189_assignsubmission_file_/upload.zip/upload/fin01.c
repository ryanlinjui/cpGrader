#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>

typedef struct __attribute__((packed)) {
    unsigned char blue;
    unsigned char green;
    unsigned char red;
} Pixel;

// BMP header structure
typedef struct __attribute__((packed)){
    unsigned short type;
    unsigned int size;
    unsigned int reserved;
    unsigned int offset;
} BMPHeader ;

// BMP info header structure
typedef struct __attribute__((packed)){
    unsigned int size;
    int width;
    int height;
    unsigned short planes;
    unsigned short bits;
    unsigned int compression;
    unsigned int imagesize;
    int xresolution;
    int yresolution;
    unsigned int ncolours;
    unsigned int importantcolours;
} BMPInfoHeader;


// Function to print BMP header data
void printBMPHeader(BMPHeader header) {
    printf("BMP Header:\n");
    printf("Type: %hu\n", header.type);
    printf("Size: %u\n", header.size);
    printf("Reserved1: %d\n", header.reserved);
    printf("Offset: %u\n", header.offset);
}

void printBMPInfoHeader(BMPInfoHeader infoHeader) {
    printf("BMP Info Header:\n");
    printf("Size: %u\n", infoHeader.size);
    printf("Width: %d\n", infoHeader.width);
    printf("Height: %d\n", infoHeader.height);
    printf("Planes: %hu\n", infoHeader.planes);
    printf("Bits: %hu\n", infoHeader.bits);
    printf("Compression: %u\n", infoHeader.compression);
    printf("Image Size: %u\n", infoHeader.imagesize);
    printf("X Resolution: %d\n", infoHeader.xresolution);
    printf("Y Resolution: %d\n", infoHeader.yresolution);
    printf("Number of Colours: %u\n", infoHeader.ncolours);
    printf("Important Colours: %u\n", infoHeader.importantcolours);
}


// Function to read BMP file
void readBMP(char* filename) {
    FILE* f = fopen(filename, "rb");
    if(f == NULL) {
        printf("Error opening file!\n");
        return;
    }

    BMPHeader header;
    BMPInfoHeader infoHeader;

    // Read the BMP header
    fread(&header, sizeof(BMPHeader), 1, f);

    // Read the BMP info header
    fread(&infoHeader, sizeof(BMPInfoHeader), 1, f);

    // Read the image data
    Pixel* data = malloc(infoHeader.imagesize);
    fread(data, 1, infoHeader.imagesize, f);

    // Print the BMP header data
    printBMPHeader(header);

    // Print the BMP info header data
    printBMPInfoHeader(infoHeader);
    

    // Print the data
    printf("%d %d %d",data[0].blue,data[0].green,data[0].red);
    fclose(f);
}

// Assumes little endian
void printBits(size_t const size, void const * const ptr)
{
    unsigned char *b = (unsigned char*) ptr;
    unsigned char byte;
    int i, j;
    
    for (i = size-1; i >= 0; i--) {
        for (j = 7; j >= 0; j--) {
            byte = (b[i] >> j) & 1;
            printf("%u", byte);
        }
    }
    puts("");
}

int main(int argc, char** argv){

    int option;
    char widthxheight[100] = "1024x768";
    char prefix[100] = "output";


    struct option long_options[] = {
        {"help", no_argument, NULL, 'h'},
        {"prefix", required_argument, NULL, 'p'},
        {"resolution", required_argument, NULL, 'r'},
        {0, 0, 0, 0}
    };

    while ((option = getopt_long(argc, argv, "hp:r:", long_options, NULL)) != -1) {
        switch (option) {
            case 'h':
                printf("Usage: fin01 [options] file\n");
                printf("  -r, --resolution=widthxheight Setup the resolution. Default: 1024x768.\n");
                printf("  -p, --prefix=str Setup the file name prefix. Default: output.\n");
                printf("  -h, --help Display this information and exit.\n");
                return 0;
            case 'p':
                //printf("Prefix: %s\n", optarg);
                break;
            case 'r':
                //printf("Resolution: %s\n", optarg);
                break;
            default:
                printf("Operation failed\n");
                return 1;
        }
    }

    if(optind < argc) {
        //readBMP(argv[optind]);
        FILE* fp = fopen(argv[1], "rb");
        if (!fp) {
            printf("Error: Cannot open file %s\n", argv[1]);
            return 1;
        }

        int i = 0;
        while (!feof(fp)) {
            BMPHeader nowBMPHeader;
            BMPInfoHeader nowBMPInfoHeader;
            fread(&nowBMPHeader, sizeof(BMPHeader), 1, fp);
            fread(&nowBMPInfoHeader, sizeof(BMPInfoHeader), 1, fp);

            

            char filename[256];
            sprintf(filename, "output%d.bmp", i++);
            FILE* out = fopen(filename, "wb");
            if (out) {
                fwrite(&nowBMPHeader, sizeof(nowBMPHeader), 1, out);  // 寫入檔案標頭
                fwrite(&nowBMPInfoHeader, sizeof(nowBMPInfoHeader), 1, out);  // 寫入資訊標頭
                fclose(out);
            }


        }

        fclose(fp);
        }
    return 0;
}