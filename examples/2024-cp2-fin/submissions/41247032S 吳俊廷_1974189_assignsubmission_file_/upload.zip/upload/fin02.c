#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <curl/curl.h>
#include <stdint.h>
#include <math.h>

char line[2048];
char line2[2048];

typedef struct __attribute__((packed)) {
    unsigned char blue;
    unsigned char green;
    unsigned char red;
} Pixel;

// BMP header structure
typedef struct __attribute__((packed)){
    unsigned short type;
    unsigned int size;
    unsigned int reserved;
    unsigned int offset;
} BMPHeader ;

// BMP info header structure
typedef struct __attribute__((packed)){
    unsigned int size;
    int width;
    int height;
    unsigned short planes;
    unsigned short bits;
    unsigned int compression;
    unsigned int imagesize;
    int xresolution;
    int yresolution;
    unsigned int ncolours;
    unsigned int importantcolours;
} BMPInfoHeader;


// Function to print BMP header data
void printBMPHeader(BMPHeader header) {
    printf("BMP Header:\n");
    printf("Type: %hu\n", header.type);
    printf("Size: %u\n", header.size);
    printf("Reserved1: %d\n", header.reserved);
    printf("Offset: %u\n", header.offset);
}

void printBMPInfoHeader(BMPInfoHeader infoHeader) {
    printf("BMP Info Header:\n");
    printf("Size: %u\n", infoHeader.size);
    printf("Width: %d\n", infoHeader.width);
    printf("Height: %d\n", infoHeader.height);
    printf("Planes: %hu\n", infoHeader.planes);
    printf("Bits: %hu\n", infoHeader.bits);
    printf("Compression: %u\n", infoHeader.compression);
    printf("Image Size: %u\n", infoHeader.imagesize);
    printf("X Resolution: %d\n", infoHeader.xresolution);
    printf("Y Resolution: %d\n", infoHeader.yresolution);
    printf("Number of Colours: %u\n", infoHeader.ncolours);
    printf("Important Colours: %u\n", infoHeader.importantcolours);
}


// Function to read BMP file
void readBMP(char* filename) {
    FILE* f = fopen(filename, "rb");
    if(f == NULL) {
        printf("Error opening file!\n");
        return;
    }

    BMPHeader header;
    BMPInfoHeader infoHeader;

    // Read the BMP header
    fread(&header, sizeof(BMPHeader), 1, f);

    // Read the BMP info header
    fread(&infoHeader, sizeof(BMPInfoHeader), 1, f);

    // Read the image data
    Pixel* data = malloc(infoHeader.imagesize);
    fread(data, 1, infoHeader.imagesize, f);

    // Print the BMP header data
    printBMPHeader(header);

    // Print the BMP info header data
    printBMPInfoHeader(infoHeader);
    

    // Print the data
    printf("%d %d %d",data[0].blue,data[0].green,data[0].red);
    fclose(f);
}

// Assumes little endian
void printBits(size_t const size, void const * const ptr)
{
    unsigned char *b = (unsigned char*) ptr;
    unsigned char byte;
    int i, j;
    
    for (i = size-1; i >= 0; i--) {
        for (j = 7; j >= 0; j--) {
            byte = (b[i] >> j) & 1;
            printf("%u", byte);
        }
    }
    puts("");
}

int main(int argc, char** argv){
    int option;
    int countTable[10]={0};
    bool valid =0;

    struct option long_options[] = {
        {"help", no_argument, NULL, 'h'},
        {0, 0, 0, 0}
    };

    while ((option = getopt_long(argc, argv, "h", long_options, NULL)) != -1) {
        switch (option) {
            case 'h':
                printf("Usage: fin02 date\n");
                printf("  -h, --help Display this information and exit.\n");
                return 0;
            default:
                printf("Operation failed\n");
                return 1;
        }
    }


    char request[200] = "https://cpe.cse.nsysu.edu.tw/cpe/scoreboard/";


    /*Download data*/
    //有參數的話
    if (optind < argc) {
        //printf("DEBUG: Date: %s\n", argv[optind]);
        sprintf(request, "%s%s", request, argv[optind]);

        //printf("DEBUG: Request: %s\n", request);
        CURL *curl;
        CURLcode res;
        curl = curl_easy_init();
        if(curl) {
            curl_easy_setopt(curl, CURLOPT_URL, request);
            
            FILE *pfile = fopen("data.html", "w");
            
            curl_easy_setopt(curl, CURLOPT_WRITEDATA, pfile);

            res = curl_easy_perform(curl);

            if(res != CURLE_OK) {
                fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
            }
            curl_easy_cleanup(curl);
            fclose(pfile);
        }

        FILE *file = fopen("data.html", "r");
        if (file == NULL) {
            printf("Could not open file\n");
            return 1;
        }


        

        /*Parse the data*/

        //Open file again
        FILE *parseFile = fopen("data.html", "r");
        if (parseFile == NULL) {
            printf("Could not open file\n");
            return 1;
        }


        int currentID = 1;

        char resultTd[1024];
        sprintf(resultTd, "<td>%d</td>", currentID);
        while (fgets(line2, sizeof(line2), parseFile)) {

            if (strstr(line2, resultTd) != NULL) {
                valid =1;
                //printf("DEBUG: %s", line2);
                fgets(line2, sizeof(line2), parseFile);
                fgets(line2, sizeof(line2), parseFile);
                fgets(line2, sizeof(line2), parseFile);

                int num;
                //printf("DEBUG: %s", line2);
                sscanf(line2, "%*[^<]<td>%d</td>", &num);
                countTable[num]++;
                //printf("DEBUG: num: %d\n", countTable[num]);

                fgets(line2, sizeof(line2), parseFile);

                // for(int i=0;i<num+3;i++){
                //     fgets(line2, sizeof(line2), parseFile);
                // }

                currentID++;
                sprintf(resultTd, "<td>%d</td>", currentID);
            }
        }
        fclose(parseFile);
    }

    /*Check the date is valid*/     
    if (valid == 0) {
        printf("Invalid date\n");
        return 1;
    }


    int total=0;
    for(int i=0;i<8;i++){
        total+=countTable[i];
    }
    for(int i = 0; i < 8; i++) {
        printf("%d: %d (%.2f%%)\n", i, countTable[i], (double)countTable[i]/(double)total*100);
    }
    //printf("Total: %d\n", total);
    
    BMPHeader fileHeader = {0x4D42, 0, 0, 54};  // 初始化檔案標頭
    BMPInfoHeader infoHeader = {40, 600, 600, 1, 24, 0, 0, 0, 0, 0, 0};  // 初始化資訊標頭

    FILE *file = fopen("output.bmp", "wb");  // 創建一個新的檔案
    if (!file) {
        printf("Unable to open file!\n");
        return 1;
    }

    fwrite(&fileHeader, sizeof(fileHeader), 1, file);  // 寫入檔案標頭
    fwrite(&infoHeader, sizeof(infoHeader), 1, file);  // 寫入資訊標頭

    // 創建一個像素陣列
    Pixel pixels[600][600];

    // 初始化像素陣列
    for (int i = 0; i < 600; i++) {
        for (int j = 0; j < 600; j++) {
            pixels[i][j].red = 255;
            pixels[i][j].green = 255;
            pixels[i][j].blue = 255;
        }
    }
    
    // 圓餅圖的半徑
    int radius = 300;

    // 圓餅圖的中心點
    int centerX = 300;
    int centerY = 300;

    // 圓餅圖的各個部分的角度
    double angles[8] = {0};
    int nowCountingIndex=7;
    for (int i = 0; i < 8; i++) {
        
        angles[i] = angles[i-1] + (double)countTable[nowCountingIndex] / (double)total *360;
        nowCountingIndex--;
    }

    // for(int i=0;i<8;i++){
    //     printf("Angle %d: %f\n",i,angles[i]);
    // }


    // 圓餅圖的各個部分的顏色(BGR)
    Pixel colors[] = {{148, 180, 164}, {173, 197, 190}, {73, 82, 59},{114, 152, 81}, {47, 37, 52},{216, 203, 219},{119, 61, 8},{94, 211, 244}};


    // 初始化像素陣列
    // 初始化像素陣列
    for (int y = 0; y < 600; y++) {
        for (int x = 0; x < 600; x++) {
            // 計算像素與圓心的距離和角度
            int dx = x - centerX;
            int dy = y - centerY;
            double distance = sqrt(dx * dx + dy * dy);
            double angle = atan2(-dy, dx) * 180 / M_PI + 90; // 從12點鐘方向開始
            if (angle < 0) angle += 360; // 確保角度在0到360度之間

            // 如果像素在圓內，則設置它的顏色
            if (distance <= radius) {
                for (int i = 0; i < sizeof(angles) / sizeof(double); i++) {
                    if (angle < angles[i]) {
                        pixels[y][x] = colors[i];
                        break;
                    }
                }
            } else {
                pixels[y][x].red = 255;
                pixels[y][x].green = 255;
                pixels[y][x].blue = 255;
            }
        }
    }

    // 寫入像素資料
    for (int i = 0; i < 600; i++) {
        fwrite(pixels[i], sizeof(Pixel), 600, file);
        // 如果每一行的像素數不是 4 的倍數，則需要添加填充字元

    }

    fclose(file);


    return 0;
}