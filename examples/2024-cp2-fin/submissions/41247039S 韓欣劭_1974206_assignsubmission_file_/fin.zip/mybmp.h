#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

typedef struct __attribute__ ((__packed__)) _BmpHeader {
    char	 bm[2];
    uint32_t size;
    uint32_t reserve;
    uint32_t offset;
    uint32_t header_size;
    int32_t  width;
    int32_t  height;
    uint16_t planes;
    uint16_t bpp;
    uint32_t compression;
    uint32_t bitmap_size;
    int32_t  hres;
    int32_t  vres;
    uint32_t used;
    uint32_t important;
} BmpHeader;

typedef struct __attribute__ ((__packed__)) _bmpPixel {
    uint8_t b;
    uint8_t g;
    uint8_t r;
} BmpPixel;

typedef struct _BMP {
    BmpHeader *header;
    BmpPixel **pixels;
} BMP;

/**
 * Initialize BMP from file stream.
 * @param bmp BMP struct
 * @param file file stream
 * @return 0 if success, otherwise non-zero value
 */
int32_t initBMP(BMP *bmp, FILE *file);

/**
 * Initialize BMP header.
 * @param bmp BMP struct
 * @return 0 if success, otherwise non-zero value
 */
int32_t initBMPHeader(BMP *bmp);

/**
 * Initialize BMP pixels.
 * @param bmp BMP struct
 * @return 0 if success, otherwise non-zero value
 */
int32_t initBMPPixels(BMP *bmp);

/**
 * Create empty BMP.
 * @param bmp BMP struct
 * @param width BMP width
 * @param height BMP height
 * @return 0 if success, otherwise non-zero value
 */
int32_t createEmptyBMP(BMP *bmp, int32_t width, int32_t height);

/**
 * Parse BMP header from file stream.
 * @param bmp BMP struct
 * @param file file stream
 * @return 0 if success, otherwise non-zero value
 */
int32_t parseBMPHeader(BMP *bmp, FILE *file);

/**
 * Parse BMP pixels from file stream.
 * @param bmp BMP struct
 * @param file file stream
 * @return 0 if success, otherwise non-zero value
 */
int32_t parseBMPPixels(BMP *bmp, FILE *file);

int32_t resizeBMP(BMP *bmp, int32_t width, int32_t height);

/**
 * Write BMP to file stream.
 * @param bmp BMP struct
 * @param file file stream
 * @return 0 if success, otherwise non-zero value
 */
int32_t writeBMP(BMP *bmp, FILE *file);

/**
 * Free BMP.
 * @param bmp BMP struct
 * @return 0 if success, otherwise non-zero value
 */
int32_t freeBMP(BMP *bmp);

/**
 * Free BMP header.
 * @param header BMP header
 */
void freeBMPHeader(BmpHeader *header);

/**
 * Free BMP pixels.
 * @param pixels BMP pixels
 * @param height BMP height
 */
void freeBMPPixels(BmpPixel **pixels, int32_t height);
