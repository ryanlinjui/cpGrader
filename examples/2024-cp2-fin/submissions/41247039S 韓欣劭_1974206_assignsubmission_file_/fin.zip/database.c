#include "database.h"

static struct list_head *g_pLabelList = NULL;
// static struct list_head *g_pRecordList = NULL;

int32_t setup_table(const struct list_head *pLabelList) {
    // struct list_head *list_label = NULL;

    // list_for_each(list_label, pLabelList) {
    //     sLabel *label = list_entry(list_label, sLabel, list);
    //     printf("%s\n", label->pStr);
    // }

    if (pLabelList == NULL) {
        return -1;
    }

    g_pLabelList = (struct list_head *) pLabelList;

    return 0;
}

int32_t add(struct list_head *pRecordList, sRecord *pRecord) {
    if (pRecordList == NULL || pRecord == NULL) {
        return -1;
    }

    list_add_tail(&pRecord->list, pRecordList);

    return 0;
}

int32_t get_size(struct list_head *pRecordList) {
    int32_t size = 0;
    struct list_head *list_record = NULL;

    if (pRecordList == NULL) {
        return -1;
    }

    list_for_each(list_record, pRecordList) {
        size++;
    }

    return size;
}

int32_t query(struct list_head *pResultList, struct list_head *pRecordList, char *pCmd) {
    // if (pResultList == NULL || pRecordList == NULL || pCmd == NULL) {
    //     return -1;
    // }

    // char *head = strstr(pCmd, "SELECT");
    // char *tail = strstr(pCmd, "WHERE");

    // if (head == NULL || tail == NULL) {
    //     return -1;
    // }

    // head += strlen("SELECT");

    // while (*head == ' ') {
    //     head++;
    // }

    // while (*(tail - 1) == ' ') {
    //     tail--;
    // }

    // char temp[512] = {0};
    // strncpy(temp, head, tail - head);

    // printf("Query: ==%s==\n", temp);

    return 0;
}
