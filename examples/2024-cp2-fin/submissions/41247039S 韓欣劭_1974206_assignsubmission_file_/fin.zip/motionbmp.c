#include "motionbmp.h"

int32_t parseMBMP(FILE *file, char *prefix, int32_t width, int32_t height) {
    if (file == NULL || prefix == NULL) {
        return 1;
    }

    int32_t count = 1;
    int32_t size  = 0;

    fseek(file, 0, SEEK_END);
    size = ftell(file);
    rewind(file);

    while (ftell(file) < size) {
        BMP bmp = { NULL, NULL };

        if (initBMP(&bmp, file) != 0) {
            return 1;
        }

        // Resize BMP

        if (resizeBMP(&bmp, width, height) != 0) {
            return 1;
        }

        char filename[STR_LEN];

        snprintf(filename, STR_LEN, "%s%03d.bmp", prefix, count);

        FILE *output = NULL;

        if (openFile(&output, filename, "wb") != 0) {
            return 1;
        }

        if (writeBMP(&bmp, output) != 0) {
            return 1;
        }

        freeBMP(&bmp);

        count++;
    }

    return 0;
}
