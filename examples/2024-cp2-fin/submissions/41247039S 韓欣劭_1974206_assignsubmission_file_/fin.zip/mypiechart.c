#include "mypiechart.h"

int32_t parseHtml(char *filename, int32_t *data) {
    FILE *file = NULL;

    if (openFile(&file, filename, "r") != 0) {
        return 1;
    }

    char buffer[F_SIZE] = {0};

    int32_t flag = 0;
    int32_t row_flag = 0;
    int32_t col_flag = 0;

    while (readLine(file, buffer, F_SIZE) == 0) {
        // Remove leading and trailing spaces

        char temp[F_SIZE] = {0};
        char *head = buffer;
        char *tail = buffer + strlen(buffer) - 1;

        while (*head == ' ' || *head == '\t') {
            head++;
        }

        while (*tail == ' ' || *tail == '\t') {
            *tail = '\0';
            tail--;
        }

        strncpy(temp, head, tail - head);

        if (strlen(temp) == 0) {
            continue;
        }

        if (strstr(temp, "<tbody>") != NULL || strstr(temp, "</tbody>") != NULL) {
            flag = !flag;
            continue;
        }

        if (!flag) {
            continue;
        }

        if (strstr(temp, "<tr>") != NULL || strstr(temp, "</tr>") != NULL) {
            row_flag = !row_flag;
            col_flag = 0;
            continue;
        }

        if (!row_flag) {
            continue;
        }

        col_flag++;

        if (col_flag == 4) {
            // printf("temp: %s\n", temp);

            int32_t score = 0;

            if (sscanf(temp, "<td>%d</td>", &score) != 1) {
                printf("read data failed\n");
                return 1;
            }

            if (score < 0 || score > 7) {
                printf("score out of range\n");
                return 1;
            }

            data[score]++;
        }
    }

    closeFile(file);

    return 0;
}

int32_t createPieChart(int32_t *data) {
    FILE *file = NULL;

    if (openFile(&file, "output.bmp", "wb") != 0) {
        return 1;
    }

    BMP bmp = {NULL, NULL};

    int32_t width  = 600;
    int32_t height = 600;

    if (createEmptyBMP(&bmp, width, height) != 0) {
        return 1;
    }

    // Fill the background with white color

    for (int32_t i = 0; i < height; i++) {
        for (int32_t j = 0; j < width; j++) {
            bmp.pixels[i][j].r = 255;
            bmp.pixels[i][j].g = 255;
            bmp.pixels[i][j].b = 255;
        }
    }

    int32_t sum = 0;

    for (int32_t i = 0; i < 8; i++) {
        sum += data[i];
    }

    int32_t radius = 300;
    int32_t start_angle = 0;

    uint8_t color[8][3] = {
        {255, 0, 0},
        {255, 165, 0},
        {255, 255, 0},
        {0, 255, 0},
        {0, 255, 255},
        {0, 0, 255},
        {128, 0, 128},
        {255, 0, 255}
    };

    for (int32_t i = 0; i < 8; i++) {
        int32_t end_angle = start_angle + data[8 - i - 1] * 360 / sum;

        if (i == 7) {
            end_angle = 360;
        }

        // Draw full circle and skip the rest if out of range of angle

        for (int32_t j = 0; j < 600; j++) {
            if (j < 0 || j >= height) {
                continue;
            }

            for (int32_t k = 0; k < 600; k++) {
                if (k < 0 || k >= width) {
                    continue;
                }

                int64_t dst = (j - 300) * (j - 300) + (k - 300) * (k - 300);
                int64_t rad = radius * radius;

                if (dst > rad) {
                    continue;
                }

                // Skip if out of range of start_angle and end_angle

                int32_t x = j - 300;
                int32_t y = k - 300;

                int32_t angle = atan2(x, y) * 180 / PI;

                if (angle < 0) {
                    angle += 360;
                }

                if (angle < start_angle || angle >= end_angle) {
                    continue;
                }

                bmp.pixels[k][j].r = color[i][0];
                bmp.pixels[k][j].g = color[i][1];
                bmp.pixels[k][j].b = color[i][2];
            }
        }

        start_angle = end_angle;
    }

    if (writeBMP(&bmp, file) != 0) {
        return 1;
    }

    closeFile(file);

    freeBMP(&bmp);

    return 0;
}

void printData(int32_t *data) {
    int32_t sum = 0;

    for (int32_t i = 0; i < 8; i++) {
        sum += data[i];
    }

    for (int32_t i = 0; i < 8; i++) {
        printf("%d: %d (%.2f%%)\n", i, data[i], (float)data[i] / sum * 100);
    }
}
