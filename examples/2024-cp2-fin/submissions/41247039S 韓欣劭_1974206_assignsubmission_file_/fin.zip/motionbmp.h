#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "myfile.h"
#include "mybmp.h"

#define STR_LEN 512

int32_t parseMBMP(FILE *file, char *prefix, int32_t width, int32_t height);
