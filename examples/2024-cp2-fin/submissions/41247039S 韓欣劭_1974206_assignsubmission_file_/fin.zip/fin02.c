#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>

#include <curl/curl.h>
#include <assert.h>

#include "myfile.h"
#include "mypiechart.h"

const char *g_short_opts = "h";
const struct option g_long_opts[] = {
    {"help", no_argument, NULL, 'h'},
    {0, 0, 0, 0},
};

const char *g_help_usage = "Usage: fin02 date\n";
const char *g_help_info  = "Try fin02 --help for more information.\n";
const char *g_help_msg   = "\
  -h, --help    Display this infomation and exit\n\
";

int main(int argc, char *argv[]) {
    int8_t c = 0;

    while ((c = getopt_long(argc, argv, g_short_opts, g_long_opts, NULL)) != -1) {
        if (c == '?' || c == 'h') {
            printf("%s%s", g_help_usage, g_help_msg);
            return (c == '?');
        }
    }

    if (argc - optind != 1) {
        printf("%s%s", g_help_usage, g_help_info);
        return EXIT_FAILURE;
    }

    char url[1024] = {0};
    char *tmp_html = "scoreboard.html";

    snprintf(url, sizeof(url), "https://cpe.cse.nsysu.edu.tw/cpe/scoreboard/%s", argv[optind]);

    CURL *curl = curl_easy_init();
    FILE *file = NULL;

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url);

        if (openFile(&file, tmp_html, "w") != 0) {
            return EXIT_FAILURE;
        }

        curl_easy_setopt(curl, CURLOPT_WRITEDATA, file);

        int32_t ret = curl_easy_perform(curl);

        if (ret != CURLE_OK) {
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(ret));
            return EXIT_FAILURE;
        }

        curl_easy_cleanup(curl);

        closeFile(file);
    }

    int32_t result[8] = {0};

    if (parseHtml(tmp_html, result) != 0) {
        printf("parseHtml() failed\n");
        return EXIT_FAILURE;
    }

    remove(tmp_html);

    printData(result);

    createPieChart(result);

    return 0;
}
