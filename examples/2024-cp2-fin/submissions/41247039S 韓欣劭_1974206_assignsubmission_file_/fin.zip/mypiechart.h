#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

#include "myfile.h"
#include "mybmp.h"

#define PI 3.14159265358979323846

int32_t parseHtml(char *filename, int32_t *data);

int32_t createPieChart(int32_t *data);

void printData(int32_t *data);
