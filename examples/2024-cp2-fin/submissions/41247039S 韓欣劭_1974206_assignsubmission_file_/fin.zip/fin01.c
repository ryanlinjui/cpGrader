#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>

#include "myfile.h"
#include "motionbmp.h"

const char *g_short_opts = "r:p:h";
const struct option g_long_opts[] = {
    {"resolution", required_argument, NULL, 'r'},
    {"prefix", required_argument, NULL, 'p'},
    {"help", no_argument, NULL, 'h'},
    {0, 0, 0, 0},
};

const char *g_help_usage = "Usage: fin01 [options] file\n";
const char *g_help_info  = "Try fin01 --help for more information.\n";
const char *g_help_msg   = "\
    -r, --resolution    Setup the resolution. Default: 1024x768.\n\
    -p, --prefix        Setup the prefix. Default: output.\n\
    -h, --help          Display this infomation and exit\n\
";

int main(int argc, char *argv[]) {
    int8_t c = 0;
    int32_t width  = 1024;
    int32_t height = 768;
    char prefix[STR_LEN] = "output";

    while ((c = getopt_long(argc, argv, g_short_opts, g_long_opts, NULL)) != -1) {
        if (c == '?' || c == 'h') {
            printf("%s%s", g_help_usage, g_help_msg);
            return (c == '?');
        }
        else if (c == 'r') {
            if (sscanf(optarg, "%dx%d", &width, &height) != 2) {
                printf("error: invalid resolution\n");
                return EXIT_FAILURE;
            }

            if (width <= 0 || height <= 0) {
                printf("error: invalid resolution\n");
                return EXIT_FAILURE;
            }
        }
        else if (c == 'p') {
            strncpy(prefix, optarg, STR_LEN);
        }
    }

    if (argc - optind != 1) {
        printf("%s%s", g_help_usage, g_help_info);
        return EXIT_FAILURE;
    }

    FILE *file = NULL;

    if (openFile(&file, argv[optind], "rb") != 0) {
        return EXIT_FAILURE;
    }

    if (parseMBMP(file, prefix, width, height) != 0) {
        return EXIT_FAILURE;
    }

    return 0;
}
