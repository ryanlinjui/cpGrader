#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

int main(int32_t argc, char *argv[]){
    for (int32_t i = 1; i < argc; i++){
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0){
            printf("Usage: fin01 [options] file\n");
            printf("  -r, --resolution=widthxheight   Setup the resolution. Default: 1024x768.\n");
            printf("  -p, --prefix=str          Setup the file name prefix. Default: output.\n");
            printf("  -h, --help              Display this information and exit.\n");
            return 0;
        }
    }
    int32_t height = 0;
    int32_t width = 0;
    char OutputName[100] = "output.bmp";
    for (int32_t i = 1; i < argc; i++){
        if (strcmp(argv[i], "-r") == 0){
        }
    }
}