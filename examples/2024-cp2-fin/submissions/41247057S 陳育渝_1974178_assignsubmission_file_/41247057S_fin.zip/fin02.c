#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "mybmp.h"
#include <curl/curl.h>

size_t write_callback(void *ptr, size_t size, size_t nmemb, FILE *stream){
    return fwrite(ptr, size, nmemb, stream);
}

int main(int32_t argc, char *argv[]){
    for (int32_t i = 0; i < argc; i++){
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0){
            printf("Usage: fin02 date\n");
            printf("  -h, --help           Display this information and exit.\n");
            return 0;
        }
    }
    char date[20] = {0};
    strncpy(date, argv[1], strlen(argv[1]));
    CURL *curl;
    CURLcode res;
    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    if (curl == 0){
        printf("wrong input\n");
        return 0;
    }
    char url[512];
    snprintf(url, sizeof(url), "https://cpe.cse.nsysu.edu.tw/cpe/scoreboard/%s", date);
    curl_easy_setopt(curl, CURLOPT_URL, url);
    FILE *file = fopen("output_file.txt", "wb");
    if (!file) {
        fprintf(stderr, "Error opening file for writing\n");
        return -1;
    }
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, file);
    res = curl_easy_perform(curl);
    if (res != CURLE_OK){
        printf("wrong input\n");
        return 0;
    }
    fclose(file);
    file = fopen("output_file.txt", "rb");
    char buffer[2048] = {0};
    int32_t seven = 0;
    int32_t six = 0;
    int32_t five = 0;
    int32_t four = 0;
    int32_t three = 0;
    int32_t two = 0;
    int32_t one = 0;
    int32_t zero = 0;
    while(fgets(buffer, sizeof(buffer), file) != NULL){
        if (strstr(buffer, "new ScoreBoardClient") != NULL) {
            break;
        }
    }
    fseek(file, -2048, SEEK_CUR);
    while(fscanf(file, "%[^\{}]%*[\{}]", buffer)){
        if (strstr(buffer, "var targetDate") != 0){
            break;
        }
        if (strstr(buffer, "SCORE") != 0){
            // printf("%s\n", buffer);
            if (strstr(buffer, "\"SCORE\":\"7\"") != 0){
                seven++;
            }
            else if (strstr(buffer, "\"SCORE\":\"6\"") != 0){
                six++;
            }
            else if (strstr(buffer, "\"SCORE\":\"5\"") != 0){
                five++;
            }
            else if (strstr(buffer, "\"SCORE\":\"4\"") != 0){
                four++;
            }
            else if (strstr(buffer, "\"SCORE\":\"3\"") != 0){
                three++;
            }
            else if (strstr(buffer, "\"SCORE\":\"2\"") != 0){
                two++;
            }
            else if (strstr(buffer, "\"SCORE\":\"1\"") != 0){
                one++;
            }
            else if (strstr(buffer, "\"SCORE\":\"0\"") != 0){
                zero++;
            }
        }
    }
    int32_t total = seven+six+five+four+three+two+one+zero;
    printf("0: %d (%.2f%%)\n", zero, ((double)zero/(double)total)*100);
    printf("1: %d (%.2f%%)\n", one, ((double)one/(double)total)*100);
    printf("2: %d (%.2f%%)\n", two, ((double)two/(double)total)*100);
    printf("3: %d (%.2f%%)\n", three, ((double)three/(double)total)*100);
    printf("4: %d (%.2f%%)\n", four, ((double)four/(double)total)*100);
    printf("5: %d (%.2f%%)\n", five, ((double)five/(double)total)*100);
    printf("6: %d (%.2f%%)\n", six, ((double)six/(double)total)*100);
    printf("7: %d (%.2f%%)\n", seven, ((double)seven/(double)total)*100);

    BMPHeader myheader;
    myheader.signature = 19778;
    myheader.fileSize = 2764856;
    myheader.reserved = 0;
    myheader.dataOffset = 54;
    myheader.headerSize = 40;
    myheader.height = 600;
    myheader.width = 600;
    myheader.planes = 1;
    myheader.bitsPerPixel = 24;
    myheader.compression = 0;
    myheader.dataSize = 2764802;
    myheader.horizontalResolution = 2834;
    myheader.verticalResolution = 2834;
    myheader.colorsUsed = 0;
    myheader.importantColors = 0;
    FILE *bmp = fopen("output.bmp", "wb");
    uint8_t **color = calloc(myheader.height*myheader.width*sizeof(uint8_t *), sizeof(uint8_t *));
    for (int32_t i = 0; i < myheader.height*myheader.width; i++){
        color[i] = calloc(3, sizeof(uint8_t));
    }
    for (int y = 0; y < myheader.height; y++) {
        for (int x = 0; x < myheader.width; x++) {
            if ((x - myheader.width / 2) * (x - myheader.width / 2) + (y - myheader.height / 2) * (y - myheader.height / 2) <= 300 * 300) {
                color[y*myheader.width+x][0] = 255;
                color[y*myheader.width+x][1] = 255;
                color[y*myheader.width+x][2] = 255;
            }
        }
    }

    write_array(color, &myheader, bmp);
    fclose(bmp);
    remove("output_file.txt");
    curl_easy_cleanup(curl);
    curl_global_cleanup();
}