#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <ctype.h>
#include <curl/curl.h>
#include <assert.h>
#include <stddef.h>
#include <math.h>
#include "bmp_func.h"

struct option long_options[] = {
    {"help", 0, NULL, 'h'},
    {0, 0, 0, 0},
};

void help_interface(){
    printf("Usage: fin02 date\n");
    printf("    -h, --help Display this information and exit.\n");
}

size_t write_data(void *ptr, size_t size, size_t nmemb, FILE *stream){
    size_t written = fwrite(ptr, size, nmemb, stream);
    return written;
}


void parse_html_and_count(FILE *file, int counts[8]){
    char buffer[1024];
    memset(counts, 0, 8 * sizeof(int));

    int in_tbody = 0;

    while(fgets(buffer, sizeof(buffer), file)){
        if(strstr(buffer, "<tbody>")){
            in_tbody = 1;
            continue;
        }
        if(strstr(buffer, "</tbody>") || strstr(buffer, "<tfoot>")){
            break;
        }
        if(in_tbody){
            if(strstr(buffer, "<tr>")){
                int column = 0;
                while(fgets(buffer, sizeof(buffer), file)){
                    char *ptr = strstr(buffer, "<td>");
                    if(!ptr) break; // End of <tr>
                    ptr += 4; // Move past "<td>"
                    char *end_ptr = strstr(ptr, "</td>");
                    if(end_ptr){
                        *end_ptr = '\0';
                    }

                    if(column == 3){ // 4th column contains the number of problems solved
                        int solved;
                        if(sscanf(ptr, "%d", &solved) == 1){
                            if(solved >= 0 && solved < 8){
                                counts[solved]++;
                            }
                        }
                    }
                    column++;
                    if(strstr(buffer, "</tr>")){
                        break;
                    }
                }
            }
        }
    }
}

void draw_pie_chart(const int counts[8], const char *filename, int radius){
    sBmpHeader header;
    sPixel *pixels;
    FILE *file;

    header.bm[0] = 'B';
    header.bm[1] = 'M';
    header.size = 54 + 3 * 2 * radius * 2 * radius;
    header.reserve = 0;
    header.offset = 54;
    header.header_size = 40;
    header.width = 2 * radius;
    header.height = 2 * radius;
    header.planes = 1;
    header.bpp = 24;
    header.compression = 0;
    header.bitmap_size = 3 * 2 * radius * 2 * radius;
    header.horizontal_res = 2835;
    header.vertical_res = 2835;
    header.used = 0;
    header.important = 0;

    pixels = (sPixel *)malloc(header.bitmap_size);
    memset(pixels, 255, header.bitmap_size); // White background

    int total = 0;
    for (int i = 0; i < 8; ++i) {
        total += counts[i];
    }

    float start_angle = -M_PI / 2; // Start at 12 o'clock
    float colors[8][3] = {
        {255, 0, 0}, {0, 255, 0}, {0, 0, 255}, {255, 255, 0},
        {0, 255, 255}, {255, 0, 255}, {128, 0, 128}, {0, 128, 128}
    };

    for(int i = 7; i >= 0; i--){
        if(counts[i] == 0) continue;
        float percentage = (float)counts[i] / total;
        float end_angle = start_angle + percentage * 2.0f * M_PI;

        for(int y = -radius; y < radius; ++y){
            for(int x = -radius; x < radius; ++x){
                float angle = atan2(y, x);
                if(angle < -M_PI / 2) angle += 2.0f * M_PI;

                float dist = sqrt(x * x + y * y);
                if(dist <= radius && angle >= start_angle && angle < end_angle){
                    int px = x + radius;
                    int py = radius - y;
                    sPixel *pixel = &pixels[py * header.width + px];
                    pixel->r = (uint8_t)colors[i][0];
                    pixel->g = (uint8_t)colors[i][1];
                    pixel->b = (uint8_t)colors[i][2];
                }
            }
        }

        start_angle = end_angle;
    }

    file = fopen(filename, "wb");
    assert(file);
    fwrite(&header, sizeof(header), 1, file);
    fwrite(pixels, header.bitmap_size, 1, file);
    fclose(file);

    free(pixels);
}

int main(int argc, char *argv[]) {
    int8_t _help = 0;
    int32_t c;

    while((c = getopt_long(argc, argv, "h", long_options, NULL)) != -1){
        if (c == 'h') {
            _help = 1;
        }
    }

    if(_help){
        help_interface();
        return 0;
    }
    if(optind >= argc){
        printf("No input date specified.\n");
        return 0;
    }

    char *input_date = argv[optind];

    CURL *curl;
    CURLcode res;

    curl = curl_easy_init();
    if(curl){
        char url[512];
        snprintf(url, 512, "https://cpe.cse.nsysu.edu.tw/cpe/scoreboard/%s", input_date);
        // printf("%s\n", url);
        curl_easy_setopt(curl, CURLOPT_URL, url);

        FILE *pFile = fopen("data.html", "w");
        assert(pFile);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, pFile);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data);

        res = curl_easy_perform(curl);
        if(res != CURLE_OK){
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
            fclose(pFile);
            curl_easy_cleanup(curl);
            return 1;
        }

        curl_easy_cleanup(curl);
        fclose(pFile);

        pFile = fopen("data.html", "r");
        assert(pFile);
        int counts[8];
        parse_html_and_count(pFile, counts);
        int32_t total_people = 0;
        for(int32_t i = 0;i < 8;i++) total_people += counts[i];
        if(total_people == 0){
            printf("Invalid date. Please check the date you entered and try again with a valid date.\n");
            fclose(pFile);
            return 0;
        }
        for(int32_t i = 0;i < 8;i++){
            printf("%d: %d (%.2f%%)\n", i, counts[i], ((float)counts[i] / (float)total_people) * 100);
        }
        fclose(pFile);

        draw_pie_chart(counts, "output.bmp", 300);
    }

    return 0;
}