#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include "bmp_func.h"

struct option long_options[] = {
    {"help", 0, NULL, 'h'},
    {"resolution", 1, NULL, 'r'},
    {"prefix", 1, NULL, 'p'},
    {0, 0, 0, 0},
};

void help_interface(){
    printf("Usage: fin01 [options] file\n");
    printf("    -r, --resolution=widthxheight Setup the resolution. Default: 1024x768.\n");
    printf("    -p, --prefix=str Setup the file name prefix. Default: output.\n");
    printf("    -h, --help Display this information and exit.\n");
}

void resize_bmp(sPixel* src, sBmpHeader* srcHeader, sPixel* dest, sBmpHeader* destHeader){
    int32_t newWidth = destHeader->width;
    int32_t newHeight = destHeader->height;
    for(int32_t y = 0; y < newHeight; y++){
        for(int32_t x = 0; x < newWidth; x++){
            int32_t srcX = x * srcHeader->width / newWidth;
            int32_t srcY = y * srcHeader->height / newHeight;
            dest[y * newWidth + x] = src[srcY * srcHeader->width + srcX];
        }
    }
}

int main(int argc, char *argv[]){
    int8_t _help = 0, _resol = 0, _prefix = 0;
    int32_t c;
    char *resolution = "1024x768", *prefix_name = "output";
    int32_t width = 1024, height = 768;

    while((c = getopt_long(argc, argv, "hr:p:", long_options, NULL)) != -1){
        if(c == 'h'){
            _help = 1;
        }
        else if(c == 'r'){
            _resol = 1;
            resolution = optarg;
        }
        else if(c == 'p'){
            _prefix = 1;
            prefix_name = optarg;
        }
    }

    if(_help){
        help_interface();
        return 0;
    }

    if(_resol){
        if(sscanf(resolution, "%dx%d", &width, &height) != 2){
            printf("Invalid resolution format. Expected format: widthxheight\n");
            return 0;
        }
        if(width < 0 || height < 0){
            printf("Invalid resolution input. The resolution must >= 0.\n");
            return 0;
        }
    }
    
    if(optind >= argc){
        printf("No input file specified.\n");
        return 0;
    }

    char *input_file = argv[optind];
    FILE *pFile = fopen(input_file, "rb");
    if (!pFile) {
        printf("Cannot open file: %s\n", input_file);
        return 0;
    }

    int fileIndex = 1;
    char filename[256];
    sBmpHeader header;
    sBmpHeader newHeader;
    sPixel *pixelData;
    sPixel *resizedData = malloc(width * height * sizeof(sPixel));
    if(!resizedData){
        printf("Memory allocation error.\n");
        fclose(pFile);
        return 0;
    }
    parseheader(pFile, &header);
    fseek(pFile, 0, SEEK_END);
    int64_t file_size = ftell(pFile);
    fseek(pFile, 0, SEEK_SET);
    int32_t numFrame = file_size / header.size;
    // printf("frame: %d\n", numFrame);

    while(numFrame--){
        parseheader(pFile, &header);
        pixelData = malloc(header.width * header.height * sizeof(sPixel));
        if (!pixelData) {
            printf("Memory allocation error.\n");
            fclose(pFile);
            return 0;
        }
        readbmp(pFile, pixelData, &header);
        // print_bmp_header(&header);
        // break;
        newHeader = header;
        newHeader.width = width;
        newHeader.height = height;
        newHeader.size = sizeof(sBmpHeader) + width * height * sizeof(sPixel);
        newHeader.bitmap_size = width * height * sizeof(sPixel);

        resize_bmp(pixelData, &header, resizedData, &newHeader);

        snprintf(filename, sizeof(filename), "%s%03d.bmp", prefix_name, fileIndex);
        FILE *outFile = fopen(filename, "wb");
        if(!outFile){
            printf("Cannot create file: %s\n", filename);
            free(pixelData);
            fclose(pFile);
            return 0;
        }

        fwrite(&newHeader, sizeof(sBmpHeader), 1, outFile);
        writebmp(outFile, resizedData, &newHeader);
        fclose(outFile);

        free(pixelData);
        fileIndex++;
    }

    free(resizedData);
    fclose(pFile);

    return 0;
}
