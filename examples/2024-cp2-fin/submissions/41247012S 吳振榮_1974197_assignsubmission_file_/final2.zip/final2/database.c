#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "database.h"

static struct list_head *gLabelList = NULL;

int32_t setup_table(const struct list_head *pLabelList) {
    if(!pLabelList){
        return -1;
    }
    gLabelList = (struct list_head *)pLabelList;
    return 0;
}

int32_t add(struct list_head *pRecordList, sRecord *pRecord) {
    if(!pRecordList || !pRecord){
        return -1;
    }
    list_add_tail(&pRecord->list, pRecordList);
    return 0;
}

int32_t get_size(struct list_head *pRecordList) {
    if(!pRecordList){
        return -1;
    }
    int32_t size = 0;
    struct list_head *pos;
    list_for_each(pos, pRecordList){
        size++;
    }
    return size;
}

int32_t query(struct list_head *pResultList, struct list_head *pRecordList, char *pCmd) {
    if(!pResultList || !pRecordList || !pCmd){
        return -1;
    }

    char *select = strstr(pCmd, "SELECT");
    char *where = strstr(pCmd, "WHERE");
    if(!select || !where){
        return -1;
    }
    

    return get_size(pResultList);
}