#pragma once

#include <stdint.h>
#include "linuxlist.h"

typedef struct _sLabel{
    char *pStr;
    struct list_head list;
}sLabel;

typedef struct _sRecord{
    struct list_head data;
    struct list_head list;
}sRecord;

typedef struct _sItem{
    char *pData;
    struct list_head next;
}sItem;

int32_t setup_table(const struct list_head *pLabelList);

int32_t add(struct list_head *pRecordList, sRecord *pRecord);

int32_t get_size(struct list_head *pRecordList);

int32_t query(struct list_head *pResultList, struct list_head *pRecordList, char *pCmd);