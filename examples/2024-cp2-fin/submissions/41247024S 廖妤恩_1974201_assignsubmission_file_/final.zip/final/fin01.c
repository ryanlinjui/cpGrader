#include<stdio.h>
#include<stdint.h>
#include<unistd.h>
#include<getopt.h>
#include<string.h>
#include<stdlib.h>

int main( int argc, char *argv[] )
{
    char *input = calloc(1025,sizeof(input));
    for ( int32_t i = 0 ; i < argc ; i ++ )
    {
        //help
        if ( strcmp ( argv[i], "--help" ) == 0 || strcmp ( argv[i], "-h" ) == 0 )
        {
            printf("Usage: fin01 [options] file\n");
            printf("-r, --resolution=widthxheight Setup the resolution. Default: 1024x768.\n");
            printf("-p, --prefix=str Setup the file name prefix. Default: output.\n");
            printf("-h, --help Display this information and exit.\n");
            free(input);
            return 0;
        }
        else
        {
            strcpy(input,argv[i]);
        }
    }
    //printf("%s\n",input);
    if ( input[strlen(input)-1] == '\n' ) input[strlen(input)-1] = '\0';
    FILE *file = fopen(input,"rb");
    if ( file == NULL )
    {
        printf("No such file.\n");
        return 0;
    }
    free(input);
}