#include<stdio.h>
#include<stdint.h>
#include<unistd.h>
#include<getopt.h>
#include<string.h>
#include<stdlib.h>
#include<curl/curl.h>
#include<time.h>
#include<assert.h>
#include<math.h>

int main( int argc, char *argv[] )
{
    char *date = calloc(1025,sizeof(char));
    for ( int32_t i = 0 ; i < argc ; i ++ )
    {
        //help
        if ( strcmp ( argv[i], "--help" ) == 0 || strcmp ( argv[i], "-h" ) == 0 )
        {
            printf("Usage: fin02 date\n");
            printf("-h, --help Display this information and exit.\n");
            free(date);
            return 0;
        }
        else
        {
            strcpy(date,argv[i]);
        }
    }
    //printf("%s\n",date);
    if ( strlen(date) != 10 )
    {
        printf("Wrong date.\n");
        return 0;
    }
    char *link = calloc(1025,sizeof(char));
    strcpy(link,"https://cpe.cse.nsysu.edu.tw/cpe/scoreboard/");
    strcpy(link+strlen(link),date);
    //printf("%ld\n",strlen(date));
    //printf("%s\n",link);
    CURL *curl;
    CURLcode res;
    curl = curl_easy_init();
    if ( curl )
    {
        //printf("hi\n");
        curl_easy_setopt( curl, CURLOPT_URL,link );
        FILE *file = fopen("a.html","w");
        assert(file);
        curl_easy_setopt( curl, CURLOPT_WRITEDATA, file );
        res = curl_easy_perform(curl);
        if (res != CURLE_OK) 
        {
            
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
        }
        fclose(file);
        curl_easy_cleanup(curl);
    }

    FILE *file = fopen("a.html","r");
    char input[1025];
    int32_t line = 0;
    int32_t tr = 0;
    int32_t adata = 0;
    int32_t seven = 0;
    int32_t six = 0;
    int32_t five = 0;
    int32_t four = 0;
    int32_t three = 0;
    int32_t two = 0;
    int32_t one = 0;
    int32_t zero = 0;
    int32_t record = 0;
    int32_t tbody = 0;
    int32_t tfoot = 0;
    //int32_t end = 0;
    while ( fgets(input,1025,file) != NULL )
    {
        line++;
        //printf("line %d\n",line);
        if ( tfoot == 1 )
        {
            //printf("line %d\n",line);
            break;
        }
        if ( line < 280 ) continue;
        //if ( end == 1 ) break;
        if ( record == line )
        {
            for ( int32_t j = 0 ; input[j] != '\0' ; j ++ )
            {
                if ( input[j] == '<' && input[j+1] == 't' && input[j+2] == 'd' && input[j+3] == '>')
                {
                    if ( input[j+4]-48 == 7 )
                    {
                        seven++;
                        //printf("re: %d\n",record);
                    }
                    else if ( input[j+4]-48 == 6 ) six++;
                    else if ( input[j+4]-48 == 5 ) five++;
                    else if ( input[j+4]-48 == 4 ) four++;
                    else if ( input[j+4]-48 == 3 ) three++;
                    else if ( input[j+4]-48 == 2 ) two++;
                    else if ( input[j+4]-48 == 1 )
                    {
                        one++;
                        //printf("find %d\n",line);
                    }
                    else if ( input[j+4]-48 == 0 )
                    {
                        zero++;
                        //printf("find %d\n",line);
                    }
                    break;
                }
            }   
            continue;
        }
        for ( int32_t j = 0 ; input[j] != '\0' ; j ++ )
        {
            if ( input[j] == '<' && input[j+1] == 't' && input[j+2] == 'r' && input[j+3] == '>')
            {
                tr += 1;
                //printf("tr %d\n",tr);
                if ( tr == 2 ) tr = 1;
                if ( tr == 1 )
                {
                    record = line+4;
                    //printf("re: %d\n",record);
                }
                break;
            }
            /*if ( input[j] == '<' && input[j+1] == 't' && input[j+2] == 'b' && input[j+3] == 'o' && input[j+4] == 'd' && input[j+5] == 'y' && input[j+6] == '>' )
            {
                tbody++;
                printf("find %d\n",line);
                printf("hi]\n");
            }*/
            if ( input[j] == '<' && input[j+1] == 't' && input[j+2] == 'f' && input[j+3] == 'o' && input[j+4] == 'o' && input[j+5] == 't' && input[j+6] == '>' )
            {
                tfoot++;
            }    
        } 
    }
    fclose(file);
    int32_t total = seven + six + five + four + three + two + one + zero;
    //printf("total: %d %d %d %d %d %d %d %d\n",seven,six,five,four,three,two,one,zero);
    printf("0: %d (%.2lf%%)\n",zero,(double)(((double)zero/(double)total)*100));
    printf("1: %d (%.2lf%%)\n",one,(double)(((double)one/(double)total)*100));
    printf("2: %d (%.2lf%%)\n",two,(double)(((double)two/(double)total)*100));
    printf("3: %d (%.2lf%%)\n",three,(double)(((double)three/(double)total)*100));
    printf("4: %d (%.2lf%%)\n",four,(double)(((double)four/(double)total)*100));
    printf("5: %d (%.2lf%%)\n",five,(double)(((double)five/(double)total)*100));
    printf("6: %d (%.2lf%%)\n",six,(double)(((double)six/(double)total)*100));
    printf("7: %d (%.2lf%%)\n",seven,(double)(((double)seven/(double)total)*100));
    FILE *outputfile = fopen("output.bmp","wb");
    //header
    char bm[2] = "BM";
    int32_t size = 360000;
    int32_t reserve = 0;
    int32_t offset = 54;
    fwrite( &bm[0], 1, 1, outputfile );
    fwrite( &bm[1], 1, 1, outputfile );
    fwrite( &size, 4, 1, outputfile );
    fwrite( &reserve, 4, 1, outputfile );
    fwrite( &offset, 4, 1, outputfile );
    int32_t infoheader = 40;
    fwrite( &infoheader, 4, 1, outputfile );
    int32_t width = 600;
    int32_t height = 600;
    fwrite( &width, 4, 1, outputfile );
    fwrite( &height, 4, 1, outputfile );
    int32_t plane = 1;
    fwrite( &plane, 2, 1, outputfile );
    int32_t bpp = 24;
    fwrite( &bpp, 2, 1, outputfile );
    int32_t compress = 0;
    fwrite( &compress, 4, 1, outputfile );
    int32_t bmpsize = 360000;
    fwrite( &bmpsize, 4, 1, outputfile );
    int32_t xpi = 1800;
    fwrite( &xpi, 4, 1, outputfile );
    int32_t ypi = 600;
    fwrite( &ypi, 4, 1, outputfile );
    int32_t used = 0;
    fwrite( &used, 4, 1, outputfile );
    int32_t import = 0;
    fwrite( &import, 4, 1, outputfile );

    int32_t *** a = calloc(600,sizeof(int32_t **));
    for ( int32_t i = 0 ; i < 600 ; i ++ )
    {
        a[i] = calloc(600,sizeof(int32_t *));
        for ( int32_t j = 0 ; j < 600 ; j ++ )
        {
            a[i][j] = calloc(3,sizeof(int32_t));
        }
    }
    for ( int32_t i = 0 ; i < 600 ; i ++ )
    {
        for ( int32_t j = 0 ; j < 600 ; j ++ )
        {
            for ( int32_t k = 0 ; k < 3 ; k ++ )
            {
                a[i][j][k] = 255;
            }
        }
    }
    double zerodegree = 360*(double)((double)zero/(double)total);
    double onedegree = zerodegree+360*(double)((double)one/(double)total);
    double twodegree = onedegree+360*(double)((double)two/(double)total);
    double threedegree = twodegree+360*(double)((double)three/(double)total);
    double fourdegree = threedegree+360*(double)((double)four/(double)total);
    double fivedegree = fourdegree+360*(double)((double)five/(double)total);
    double sixdegree = fivedegree+360*(double)((double)six/(double)total);
    double sevendegree = sixdegree+360*(double)((double)seven/(double)total);
    //printf("%lf %lf %lf %lf %lf %lf %lf %lf\n",zerodegree,onedegree,twodegree,threedegree,fourdegree,fivedegree,sixdegree,sevendegree);
    //circle
    for ( int32_t i = 0 ; i < 600 ; i ++ )
    {
        for ( int32_t j = 0 ; j < 600 ; j ++ )
        {
            if ( abs(i-300)*abs(i-300) + abs(j-300)*abs(j-300) > 90000 ) continue;
            
            double degree = 0;
            if ( i < 600 && i >= 300 && j < 300 && j >= 0 )
            {
                double tan = (double)(i-300)/(double)(300-j);
                degree = atan(tan)*180/M_PI;
                degree = 90-degree;
            }
            else if ( j == 300 && i <= 600 && i > 300 ) degree = 0;
            else if ( i < 300 && i >= 0 && j < 300 && j >= 0 )
            {
                double tan = (double)(300-j)/(double)(300-i);
                degree = atan(tan)*180/M_PI;
                degree = 180-degree;
            }
            else if ( j == 300 && i <= 300 && i >= 0 ) degree = 180;
            else if ( i < 300 && i >= 0 && j > 300 && j < 600 )
            {
                double tan = (double)(300-i)/(double)(j-300);
                degree = atan(tan)*180/M_PI;
                degree = 270-degree;
            }
            else if ( i == 300 && j >= 300 && j <= 600 ) degree = 270;
            else
            {
                double tan = (double)(i-300)/(double)(j-300);
                degree = atan(tan)*180/M_PI;
                degree = 270+degree;
            }
            if ( degree >= 0 && degree <= zerodegree )
            {
                a[i][j][0] = 133;
                a[i][j][1] = 157;
                a[i][j][2] = 255;
            }
            else if ( degree > zerodegree && degree <= onedegree )
            {
                a[i][j][0] = 155;
                a[i][j][1] = 248;
                a[i][j][2] = 222;
            }
            else if ( degree > onedegree && degree <= twodegree )
            {
                a[i][j][0] = 111;
                a[i][j][1] = 239;
                a[i][j][2] = 255;
            }
            else if ( degree > twodegree && degree <= threedegree )
            {
                a[i][j][0] = 92;
                a[i][j][1] = 167;
                a[i][j][2] = 253;
            }
            else if ( degree > threedegree && degree <= fourdegree )
            {
                a[i][j][0] = 193;
                a[i][j][1] = 204;
                a[i][j][2] = 255;
            }
            else if ( degree > fourdegree && degree <= fivedegree )
            {
                a[i][j][0] = 142;
                a[i][j][1] = 180;
                a[i][j][2] = 242;
            }
            else if ( degree > fivedegree && degree <= sixdegree )
            {
                a[i][j][0] = 189;
                a[i][j][1] = 229;
                a[i][j][2] = 209;
            }
            else
            {
                a[i][j][0] = 177;
                a[i][j][1] = 236;
                a[i][j][2] = 255;
            }
        }
    }
    for ( int32_t i = 0 ; i < 600 ; i ++ )
    {
        for ( int32_t j = 0 ; j < 600 ; j ++ )
        {
            for ( int32_t k = 0 ; k < 3 ; k ++ )
            {
                fwrite(&a[i][j][k],1,1,outputfile);
            }
        }
    }
    free(a);
    fclose(outputfile);
    free(date);
    free(link);
    system("rm a.html");
}
